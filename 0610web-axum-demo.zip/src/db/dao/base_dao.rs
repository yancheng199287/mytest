use std::marker::PhantomData;
use sea_orm::{DatabaseConnection, EntityTrait, DbErr, ActiveModelTrait, InsertResult};
use crate::db::pool::mysql_pool::{get_db_pool};

pub struct BaseDao<E, A>
    where
        E: EntityTrait,
        A: ActiveModelTrait
{
    pub db: &'static DatabaseConnection,
    _marker: PhantomData<E>,
    _marker1: PhantomData<A>,

}

impl<E, A> BaseDao<E, A>
    where
        E: EntityTrait,
        A: ActiveModelTrait<Entity=E> {
    pub async fn new() -> Self {
        BaseDao {
            db: get_db_pool(),
            _marker: PhantomData,
            _marker1: PhantomData,
        }
    }

    pub async fn create(&self, model: A) -> Result<InsertResult<A>, DbErr> {
        E::insert(model).exec(self.db).await
    }
}
