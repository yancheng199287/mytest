use sea_orm::entity::prelude::*;
use sea_orm::IntoActiveModel;
use crate::db::dao::base_dao::BaseDao;
use crate::entity::user::Entity as UserEntity;
use crate::entity::user::ActiveModel as UserActiveModel;

pub struct UserDao {
    pub base_dao: BaseDao<UserEntity, UserActiveModel>,
}

impl UserDao {
    pub async fn new() -> Self {
        UserDao {
            base_dao: BaseDao::new().await,
        }
    }

    // UserDao 特定的方法，可以在这里添加
}

