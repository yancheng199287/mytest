use sea_orm::{ActiveModelTrait, ConnectionTrait, DatabaseConnection, DbBackend, DbErr, EntityTrait, PaginatorTrait, Statement};
use sea_orm::ActiveValue::Set;
use crate::db::dao::user_dao::UserDao;
use crate::db::pool::mysql_pool::initialize_pool;
use crate::entity::user;

mod db;
mod entity;


#[tokio::main]
async fn main() {
    println!("Hello, world!");
    tracing_subscriber::fmt()
        .with_max_level(tracing::Level::DEBUG)
        .with_test_writer()
        .init();

    // 初始化全局连接池
    initialize_pool().await;


    let userdao = UserDao::new().await;
    // 插入新用户
    let new_user = user::ActiveModel {
        name: Set(Some("Alice".to_string())),
        ..Default::default()
    };
    let inserted_user = userdao
        .base_dao.create(new_user).await.unwrap();
    println!("Inserted user: {:?}", inserted_user);


    // let ref_db_connection = db::pool::mysql_pool::get_db_pool();
    // //  raw_query(ref_db_connection).await;
    // model_query(ref_db_connection).await;
}


async fn model_query(db_connection: &DatabaseConnection) {
    let user = entity::user::Entity::find().one(db_connection).await.unwrap();
    println!("{:?}", user);

    // 创建一个新用户
    let new_user: entity::user::ActiveModel = entity::user::ActiveModel {
        name: Set(Some("Alice".to_string())),
        avatar: Set(Some("avatar_url".to_string())),
        phone: Set(Some("123456789".to_string())),
        email: Set(Some("alice@example.com".to_string())),
        address: Set(Some("Wonderland".to_string())),
        age: Set(Some(25)),
        ..Default::default()
    };
    let result = new_user.insert(db_connection).await.unwrap();
    println!("New user created: {:?}", result);

    // 读取用户信息
    let users: Vec<entity::user::Model> = entity::user::Entity::find().all(db_connection).await.unwrap();
    println!("All users: {:?}", users);

    // 分页查询：每页 10 条记录，查询第 1 页的数据
    let paginator = entity::user::Entity::find().paginate(db_connection, 10);
    let users_page_1: Vec<entity::user::Model> = paginator.fetch_page(0).await.unwrap();
    println!("users_page_1 : {:?}", users_page_1);
}

async fn raw_query(db_connection: &DatabaseConnection) {
    let stmt = Statement::from_sql_and_values(DbBackend::MySql, "SELECT * FROM user", vec![]);
    let result = db_connection.query_all(stmt).await.unwrap();

    // 打印查询结果
    result.iter().for_each(|row| {
        let id: i32 = row.try_get::<i32>("", "id").unwrap();
        let name: String = row.try_get::<String>("", "name").unwrap();
        let avatar: String = row.try_get::<String>("", "avatar").unwrap();
        let phone: String = row.try_get::<String>("", "phone").unwrap();
        let email: String = row.try_get::<String>("", "email").unwrap();
        let address: String = row.try_get::<String>("", "address").unwrap();
        let age: i32 = row.try_get::<i32>("", "age").unwrap();
        println!("id: {}, name: {}, avatar: {}, phone: {}, email: {}, address: {}, age: {}", id, name, avatar, phone, email, address, age)
    });
}
