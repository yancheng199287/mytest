#  RESTful API设计规范

在使用Spring Boot设计RESTful API时，遵循一些常见的标准和最佳实践可以帮助团队创建一致、易于维护和扩展的API。以下是一些常用且必须遵守的设计规则：

### 1. **使用HTTP动词**
RESTful API应该利用HTTP动词来表示操作：
- `GET`：用于获取资源。
- `POST`：用于创建资源。
- `PUT`：用于更新资源。
- `DELETE`：用于删除资源。
- `PATCH`：用于部分更新资源。

### 2. **使用有意义的资源命名**
#### 1. **使用名词**

资源名称应使用名词而不是动词，因为资源表示实体。例如：

- `/users` 而不是 `/getUsers`
- `/orders` 而不是 `/createOrder`

#### 2. 避免动词

操作由HTTP方法表示，资源名称不应该包含操作动词。例如：

- 使用 `/users` 而不是 `/getUsers`
- 使用 `/orders` 而不是 `/createOrder`

#### 3.  层级关系

利用URL路径表达资源之间的层级关系。例如，一个用户的订单可以表示为：

- `/users/{userId}/orders`

#### 4. 使用连字符

为了提高URL的可读性，建议使用连字符而不是下划线或驼峰命名法。例如：

- `/user-orders` 而不是 `/user_orders` 或 `/userOrders`

#### 5. HTTP动词与资源路径的配合

确保HTTP动词与资源路径表示的资源相匹配。例如：

- `GET /users`：获取用户集合
- `POST /users`：创建新用户
- `GET /users/{id}`：获取特定用户
- `PUT /users/{id}`：更新特定用户
- `DELETE /users/{id}`：删除特定用户

#### 6. 嵌套资源

对于有明确从属关系的资源，可以使用嵌套的URL路径。例如：

- `/users/{userId}/orders`：表示特定用户的订单集合
- `/users/{userId}/orders/{orderId}`：表示特定用户的特定订单

### 3. **版本控制**
使用版本号来管理API的不同版本。常见做法是在URL中包含版本号：
- `/api/v1/users`
- `/api/v2/products`

### 4. **使用标准的HTTP状态码**
根据操作结果返回合适的HTTP状态码：
- `200 OK`：成功的GET、PUT、PATCH或DELETE操作。
- `201 Created`：成功的POST操作。
- `204 No Content`：成功的DELETE操作且无返回内容。
- `400 Bad Request`：请求参数有误。
- `401 Unauthorized`：身份验证失败。
- `403 Forbidden`：拒绝访问。
- `404 Not Found`：资源未找到。
- `500 Internal Server Error`：服务器内部错误。



### 5. **统一返回格式**
采用统一的返回格式来包装响应数据，通常包括状态、数据和消息。例如：
```json
{
  "status": "success",
  "data": {
    "id": 1,
    "name": "John Doe"
  },
  "message": "User retrieved successfully"
}
```

### 6. **错误处理**
提供详细的错误信息，使用统一的错误响应格式：
```json
{
  "status": "error",
  "message": "The user with ID 1 does not exist"
}
```

### 7. **分页、过滤和排序**
对于返回大量数据的API，支持分页、过滤和排序：
- 分页：使用`limit`和`offset`参数。
- 过滤：使用查询参数，例如`/users?age=25`。
- 排序：使用`sort`参数，例如`/users?sort=name,asc`。

### 8. **安全性**
确保API的安全性，使用身份验证和授权机制（例如OAuth2）。
- 所有的敏感操作应使用HTTPS。
- 使用Token（例如JWT）来进行身份验证。

### 9. **文档化**
使用工具（如Swagger或SpringFox）生成API文档，确保API使用者能够方便地理解和使用API。

```java
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/users")
public class UserController {

    @GetMapping("/{id}")
    public ResponseEntity<User> getUserById(@PathVariable Long id) {
        User user = userService.findById(id);
        if (user == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(null);
        }
        return ResponseEntity.ok(user);
    }
}
```

通过遵循这些标准和最佳实践，您的团队可以创建健壮、易于使用的RESTful API。