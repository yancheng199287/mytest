use std::fs::File;
use std::io::Read;
use tauri::{Config, Manager, Url};
use tauri::utils::config::WindowConfig;
use crate::mnp_window_config::MNPWindowConfig;

#[tauri::command]
pub async fn open_new_window(app_handle: tauri::AppHandle, app_id: String)  {
    println!("heelo:{}", app_id);
    let window_app_handle = app_handle.clone();
    let result = app_handle.run_on_main_thread(move || {
        let label = app_id.replace('.', "_");

        let window_config = read_manifest_file(window_app_handle.clone(), app_id).unwrap();

        let webview_window = tauri::WebviewWindowBuilder::new(&window_app_handle, window_config.label, window_config.url)
            .title(window_config.title)
            .user_agent(&window_config.user_agent.unwrap())
            .inner_size(window_config.width, window_config.height)
            .max_inner_size(window_config.max_width.unwrap(), window_config.max_height.unwrap())
            .min_inner_size(window_config.min_width.unwrap(), window_config.min_height.unwrap())
            .resizable(window_config.resizable)
            .drag_and_drop(window_config.drag_drop_enabled)
            .build();
        match webview_window {
            Ok(_) => {
                println!("open_new_window success");
            }
            Err(err) => {
                println!("open_new_window error:{:?}", err);
            }
        }
    });
}


pub fn read_manifest_file(app_handle: tauri::AppHandle, app_id: String) -> anyhow::Result<WindowConfig> {
    let path = app_handle.path();

    let app_config: &Config = app_handle.config();
    let app_identifier = &app_config.identifier;
    let local_data_dir = path.local_data_dir().unwrap();

    let manifest_file_path: std::path::PathBuf = local_data_dir.join(app_identifier).join("miniProgram").join(app_id).join("manifest.json");
    println!("{}", manifest_file_path.display());
    let mut file = File::open(manifest_file_path.as_path()).unwrap();
    let mut contents = String::new();
    // 读取文件内容到字符串中
    file.read_to_string(&mut contents).unwrap();

    let mnp_window_config_result = MNPWindowConfig::from_json_str(&contents);
    if mnp_window_config_result.is_err() {
        println!("open_new_window error:{:?}", mnp_window_config_result.err());
        return Err(anyhow::anyhow!("open_new_window error"));
    }
    let window_config = mnp_window_config_result.unwrap();
    println!("window_config:{:?}", window_config);
    Ok(window_config)
}