use serde::{Serialize, Deserialize};

#[derive(Debug, Serialize, Deserialize)]
pub struct TauriCommandError {
    pub code: u32,
    pub message: String,
}

impl TauriCommandError {
    pub fn new(code: u32, message: &str) -> Self {
        Self {
            code,
            message: message.to_string(),
        }
    }

    pub fn error_msg(message: &str) -> Self {
        Self {
            code: 500,
            message: message.to_string(),
        }
    }
}

