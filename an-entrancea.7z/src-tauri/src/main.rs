// Prevents additional console window on Windows in release, DO NOT REMOVE!!
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

mod web_server;
mod command;
mod mnp_window_config;
mod error;

use std::sync::{Arc, Mutex};
use log::info;
use tauri::{Config, Manager};
use tokio::runtime::Runtime;
use tokio::sync::oneshot;

// Learn more about Tauri commands at https://tauri.app/v1/guides/features/command
#[tauri::command]
fn greet(name: &str) -> String {
    format!("Hello, {}! You've been greeted from Rust!", name)
}


fn main() {
    let static_dir = "C:\\Users\\yancheng\\AppData\\Local\\com.oneinlet.app\\miniProgram".to_string(); // 静态文件目录
    let warp_server = web_server::start_web_server(static_dir);

    let rt = Arc::new(Mutex::new(Runtime::new().unwrap()));
    tauri::Builder::default()
        .plugin(tauri_plugin_shell::init())
        .invoke_handler(tauri::generate_handler![greet, command::window::open_new_window])
        .on_window_event(move |window, event| match event {
            tauri::WindowEvent::CloseRequested { api, .. } => {
                // 获取 WarpServer 实例并停止服务器
                let app_handler = window.app_handle();
                let warp_server = app_handler.state::<Arc<Mutex<web_server::WarpServer>>>();
                let mut warp_server = warp_server.lock().unwrap();
                warp_server.stop();
                println!("停止web服务");
            }
            tauri::WindowEvent::Focused(focused) => {
                // hide window whenever it loses focus
                if !focused {
                  //  window.hide().unwrap();
                }
            }
            _ => {}
        })
        .setup(|app| {
            create_app_local_data_dir(&app).expect("can not create local app  data dir");

            // 存储 WarpServer 实例
            app.manage(warp_server);

            Ok(())
        })
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}


fn create_app_local_data_dir(app: &tauri::App) -> Result<(), Box<dyn std::error::Error>> {
    let app_config: &Config = app.config();
    let app_identifier = &app_config.identifier;
    let path = app.app_handle().path();
    let local_data_dir = path.local_data_dir();

    if local_data_dir.is_ok() {
        info!("create_app_local_data_dir local_data_dir:{:?}",local_data_dir);
        let local_data_dir = local_data_dir.unwrap();

        let local_mini_program = local_data_dir.join(app_identifier).join("miniProgram");
        let local_mini_program_data_dir = local_data_dir.join(app_identifier).join("miniProgram-data");

        info!("create_app_local_data_dir local_mini_program:{:?}",local_mini_program);
        info!("create_app_local_data_dir local_mini_program_data_dir:{:?}",local_mini_program_data_dir);

        if !local_mini_program.is_dir() {
            std::fs::create_dir_all(&local_mini_program)?;
        }
        if !local_mini_program_data_dir.is_dir() {
            std::fs::create_dir_all(&local_mini_program_data_dir)?
        }
    }
    Ok(())
}