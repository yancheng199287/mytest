use serde::{Deserialize, Serialize};
use tauri::utils::config::WindowConfig;
use tauri::{Url, WebviewUrl};


#[derive(Serialize, Deserialize, Debug)]
enum AppType {
    Web,
    Script,
}

#[derive(Serialize, Deserialize, Debug)]
struct Manifest {
    identifier: String,
    name: String,
    version: String,
    version_number: u8,
    description: String,
    author: String,
    url: String,
    app_type: AppType,
    windows: MNPWindowConfig,
}

#[derive(Serialize, Deserialize, Debug)]
pub struct MNPWindowConfig {
    pub title: String,
    /// The window identifier. It must be alphanumeric.
    pub label: String,
    /// The window webview URL.
    #[serde(skip)]
    pub url: WebviewUrl,
    /// The user agent for the webview
    pub user_agent: Option<String>,
    /// Whether the drag and drop is enabled or not on the webview. By default it is enabled.
    ///
    /// Disabling it is required to use HTML5 drag and drop on the frontend on Windows.
    pub drag_drop_enabled: bool,
    /// Whether or not the window starts centered or not.
    pub center: bool,
    /// The horizontal position of the window's top left corner
    pub x: Option<f64>,
    /// The vertical position of the window's top left corner
    pub y: Option<f64>,
    /// The window width.
    pub width: f64,
    /// The window height.
    pub height: f64,
    /// The min window width.
    pub min_width: Option<f64>,
    /// The min window height.
    pub min_height: Option<f64>,
    /// The max window width.
    pub max_width: Option<f64>,
    /// The max window height.
    pub max_height: Option<f64>,
    /// Whether the window is resizable or not. When resizable is set to false, native window's maximize button is automatically disabled.
    pub resizable: bool,
}

impl MNPWindowConfig {
    pub fn from_json_str(manifest_json: &str) -> Result<WindowConfig, String> {
        let manifest_result = serde_json::from_str(manifest_json);
        if manifest_result.is_err() {
            return Err(manifest_result.err().unwrap().to_string());
        }
        let manifest: Manifest = manifest_result.unwrap();
        let window_config = manifest.windows.create_window_config(&manifest);
        return Ok(window_config);
    }
    fn check_window_config() -> MNPWindowConfig {
        return MNPWindowConfig {
            title: "我的小程序测试".to_string(),
            label: "mnp".to_string(),
            url: WebviewUrl::App("mnp".into()),
            user_agent: None,
            drag_drop_enabled: true,
            center: true,
            x: None,
            y: None,
            width: 800.0,
            height: 600.0,
            min_width: None,
            min_height: None,
            max_width: None,
            max_height: None,
            resizable: true,
        };
    }


    fn create_window_config(&self, manifest: &Manifest ) -> WindowConfig {
        let identifier: String = manifest.identifier.clone();
        let host = "http://localhost:3030/web";
        let app_url = format!("{}/{}/index.html", host, identifier);
        println!("open_new_window url:{}", app_url);
        let url = Url::parse(app_url.as_str()).unwrap();
        let app_url = tauri::WebviewUrl::External(url);

        let mut window_config = WindowConfig::default();
        window_config.title = self.title.clone();
        window_config.label = self.label.clone();
        window_config.url = app_url;
        window_config.user_agent = Some(String::from("Lua-Mini-Program"));
        window_config.drag_drop_enabled = self.drag_drop_enabled;
        window_config.center = self.center;
        window_config.x = self.x;
        window_config.y = self.y;
        window_config.width = self.width;
        window_config.height = self.height;
        window_config.min_width = self.min_width;
        window_config.min_height = self.min_height;
        window_config.max_width = self.max_width;
        window_config.max_height = self.max_height;
        window_config.resizable = self.resizable;
        return window_config;
    }
}


#[test]
fn test_mnp_window_config() {
    let json = r#"
   {
  "identifier":"com.oneinlet.app",
  "name": "MyPlugin",
  "version": "1.0.0",
  "version_number": 1,
  "description": "This is a sample plugin for the host application.",
  "author": "Your Name",
  "url": "https://example.com/updates/myplugin",
  "app_type": "Web",
  "windows": {
    "label": "com.oneinlet.app",
    "title": "我的小程序测试",
    "resizable": true,
    "drag_drop_enabled": true,
    "focus": true,
    "maximized": false,
    "center": false,
    "fileDropEnabled": true,
    "width": 800,
    "height": 600,
    "minWidth": 800,
    "minHeight": 600,
    "maxHeight": 800,
    "maxWidth": 600
  }
}
    "#;
    let manifest: Manifest = serde_json::from_str(json).unwrap();
    println!("manifest:{:?}", manifest)
}