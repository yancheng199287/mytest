<script setup lang="ts">
import {invoke} from '@tauri-apps/api/core';


async function openMiniProgram() {
  try {
    await invoke('open_new_window', {
      appId: 'my.app.name'
    })
        .then(() => {
          console.log('Window opened successfully');
        })
        .catch((error) => {
          console.error('Failed to open window1:', error);
        });
  } catch (error) {
    console.error('Failed to open new window:', error);
  }
}


</script>

<template>

  <div>
    <button id="open-window" type="button" @click="openMiniProgram">打开小程序</button>
  </div>

</template>

<style scoped>

</style>