use axum::body::Body;
use axum::response::Response;
use serde::Serialize;

pub  fn build_json_response<T: Serialize>(code: u16, data: &T) -> Response {
    let json = serde_json::to_string(data).unwrap();
    return Response::builder()
        .status(code)
        .header("Content-Type", "application/json")
        .body(Body::new(json))
        .unwrap();
}