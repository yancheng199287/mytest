use axum::body::Body;
use axum::response::{IntoResponse, Response};
use serde::Serialize;
use once_cell::sync::OnceCell;
use paste::paste;
use crate::bean::build_response::build_json_response;
use crate::bean::response_data::ApiResponse;


/**
paste! 可以拼接变量名 [<$name _CELL>]
 */
macro_rules! create_app_error {
    ($name:ident, $code:expr, $message:expr) => {
        paste! {
            static [<$name _CELL>]: OnceCell<AppError> = OnceCell::new();

            pub fn $name() -> &'static AppError {
                [<$name _CELL>].get_or_init(|| error_app_response($code, $message))
            }
        }
    };
}
#[derive(Debug)]
#[derive(Serialize)]
pub struct AppError {
    pub code: u16,
    pub message: Option<String>,
}

// 使用宏来创建全局变量
create_app_error!(NOT_FOUND_ERROR, 404, "Not Found");
create_app_error!(JWT_AUTH_FAILED, 401, "Invalid or missing token");
create_app_error!(INTERNAL_ERROR, 500, "Internal Server Error");

impl AppError {
    pub fn ok(message: &str) -> Self {
        Self {
            code: 0,
            message: None,
        }
    }
    pub fn error(message: &str) -> Self {
        Self {
            code: 1001,
            message: Some(message.to_string()),
        }
    }

    pub fn error_code(code: u16, message: &str) -> Self {
        Self {
            code,
            message: Some(message.to_string()),
        }
    }
}

impl IntoResponse for AppError {
    fn into_response(self) -> Response<Body> {
        let response = ApiResponse {
            code: self.code,
            message: self.message,
            data: None::<()>,
        };
        return build_json_response(500, &response);
    }
}


pub fn error_app_response(code: u16, message: &str) -> AppError {
    AppError {
        code,
        message: Some(message.to_string()),
    }
}