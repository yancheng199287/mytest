use chrono::{Duration, Utc};
use jsonwebtoken::{decode, DecodingKey, encode, EncodingKey, Header, Validation};
use once_cell::sync::OnceCell;
use serde::{Deserialize, Serialize};
use tracing::error;
use crate::vo::login::UserLoginRespVo;


/**
JWT安全密钥
 */
const SECRET_KEY: &[u8] = "a5s&5d99711#6a5@s346a5das6".as_bytes();

static INSTANCE_DECODING_KEY: OnceCell<DecodingKey> = OnceCell::new();

const ACCESS_TOKEN_AUDIENCE: &str = "session_access_token";
const REFRESH_ACCESS_TOKEN_AUDIENCE: &str = "refresh_access_token";


static INSTANCE_REFRESH_TOKEN_VALIDATION: OnceCell<Validation> = OnceCell::new();
static INSTANCE_ACCESS_TOKEN_VALIDATION: OnceCell<Validation> = OnceCell::new();


#[derive(Clone, Debug)]
#[derive(Serialize)]
pub struct User {
    pub id: u64,
    pub name: String,
    pub email: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct Claims {
    pub sub: String,
    pub company: String,
    pub aud: String,
    pub iat: i64,
    pub exp: i64,
    pub id: u64,
    pub name: String,
    pub email: String,
}


impl Claims {
    pub fn new(user: &User, expire: Duration, aud: &str) -> Claims {
        let user = user.clone();
        let now = Utc::now();
        let expiration = now + expire; // 会话保持有效期是七天，超过了使用刷新token去请求刷新接口
        let expiration_timestamp = expiration.timestamp();
        Claims {
            sub: "com.oneinlet".to_string(),
            company: "A.B.C".to_string(),
            aud: aud.to_string(),  // 受众群体，这里可以用来区分用途，我们标识当前的jwt是用来会话访问的令牌，另外还要刷新的令牌，刷新令牌只能访问刷新令牌接口，其他接口无效
            iat: now.timestamp(),
            exp: expiration_timestamp, // Example expiration timestamp
            id: user.id,
            name: user.name,
            email: user.email,
        }
    }

    pub fn new_access_token(user: &User) -> Claims {
        let expiration = Duration::days(7); // 会话保持有效期是七天，超过了使用刷新token去请求刷新接口
        return Self::new(user, expiration, ACCESS_TOKEN_AUDIENCE);
    }

    fn new_refresh_access_token(user: &User) -> Claims {
        let expiration = Duration::days(30); // 前端如果发现请求鉴权失败401，使用刷新接口刷新token，如果刷新失败，前端跳转到登录页面重新登陆
        return Self::new(user, expiration, REFRESH_ACCESS_TOKEN_AUDIENCE);
    }
}

/**
创建JWT令牌对，包含访问令牌和刷新令牌，刷新令牌只能访问刷新接口
 */
pub fn create_jwt_pair(user: &User) -> UserLoginRespVo {
    let encoding_key = EncodingKey::from_secret(SECRET_KEY);
    let claims = Claims::new_access_token(user);
    let access_token = encode(&Header::default(), &claims, &encoding_key).unwrap();

    let claims = Claims::new_refresh_access_token(user);
    let refresh_token = encode(&Header::default(), &claims, &encoding_key).unwrap();
    return UserLoginRespVo {
        access_token,
        refresh_token,
    };
}


pub fn get_decoding_key() -> &'static DecodingKey {
    INSTANCE_DECODING_KEY.get_or_init(|| {
        return DecodingKey::from_secret(SECRET_KEY);
    })
}


fn get_access_token_validation() -> &'static Validation {
    INSTANCE_ACCESS_TOKEN_VALIDATION.get_or_init(|| {
        let mut validation = Validation::default();
        // 默认有一分钟的时间缓冲，防止时间不对称，我们这里禁止
        validation.leeway = 0;
        validation.set_audience(&[ACCESS_TOKEN_AUDIENCE]);
        return validation;
    })
}

/**
获取刷新令牌验证规则
 */
pub fn get_refresh_token_validation() -> &'static Validation {
    INSTANCE_REFRESH_TOKEN_VALIDATION.get_or_init(|| {
        let mut validation = Validation::default();
        // 默认有一分钟的时间缓冲，防止时间不对称，我们这里禁止
        validation.leeway = 0;
        validation.set_audience(&[REFRESH_ACCESS_TOKEN_AUDIENCE]);
        return validation;
    })
}


pub fn decode_jwt(token: &str, validation_type: u8) -> Result<User, jsonwebtoken::errors::Error> {
    let validation = match validation_type {
        0 => get_access_token_validation(),
        1 => get_refresh_token_validation(),
        _ => get_access_token_validation(),
    };
    let token_data_result = decode::<Claims>(token, get_decoding_key(), validation);
    match token_data_result {
        Ok(token_data) => {
            let claims = token_data.claims;
            let user = User {
                id: claims.id,
                name: claims.name,
                email: claims.email,
            };
            Ok(user)
        }
        Err(err) => {
            error!("decode failed {:?}", err);
            return Err(err);
        }
    }
}

