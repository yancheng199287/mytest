use axum::body::Body;
use axum::Json;
use axum::response::{IntoResponse, Response};
use serde::Serialize;
use crate::bean::build_response::build_json_response;
use crate::bean::error::AppError;

#[derive(Serialize)]
pub struct ApiResponse<T> {
    pub code: u16,
    pub message: Option<String>,
    pub data: Option<T>,
}


pub fn ok_response<T: Serialize>(data: T) -> Result<ApiResponse<T>, AppError> {
    Ok(ApiResponse {
        code: 0,
        message: None,
        data: Some(data),
    })
}


pub fn error_message_response<T: Serialize>(message: &str) -> Result<ApiResponse<T>, AppError> {
    Err(AppError {
        code: 0,
        message: Some(message.to_string()),
    })
}



pub fn error_code_message_response<T: Serialize>(code: u16, message: &str) -> Result<ApiResponse<T>, AppError> {
    Err(AppError {
        code,
        message: Some(message.to_string()),
    })
}


impl<T: Serialize> IntoResponse for ApiResponse<T> {
    fn into_response(self) -> Response<Body> {
        let response: ApiResponse<T> = self;
        let code = if response.code == 0 {
            200
        } else {
            500
        };
        return build_json_response(code, &response);
    }
}

