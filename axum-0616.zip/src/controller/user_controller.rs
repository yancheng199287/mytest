use axum::{Extension, Json, Router};
use axum::extract::Request;
use axum::response::{IntoResponse, Response};
use chrono::{Duration, Utc};
use http::{StatusCode};
use jsonwebtoken::{decode, encode, EncodingKey, Header};
use crate::bean::build_response::build_json_response;
use crate::bean::error;
use crate::bean::error::AppError;
use crate::bean::jwt::{Claims, create_jwt_pair, decode_jwt, User};
use crate::bean::response_data::{ApiResponse, ok_response};
use crate::vo::login::{RefreshTokenVo, UserLoginRespVo, UserLoginVo};

/*使用 tokio::spawn_blocking：在 protected_route 处理函数中，
使用 tokio::spawn_blocking 将阻塞操作移到 Tokio 的专用阻塞线程池中进行处理。这
确保了阻塞操作不会影响 Tokio 的异步任务调度和整体性能。
*/


/*pub fn create_user_router() -> Router {
  return   Router::new()
        .route("/login", post(crate::controller::user_controller::login))
        .route("/test", get(crate::controller::user_controller::test))
        .layer(ServiceBuilder::new().layer(axum::middleware::from_fn(jwt_auth)));
}*/


pub async fn login(Json(user_login_info): Json<UserLoginVo>) -> Result<ApiResponse<UserLoginRespVo>, AppError> {
    let user = User {
        id: 1,
        name: "李德华".to_string(),
        email: "123456@gmail.com".to_string(),
    };
    let user_login_resp_vo = create_jwt_pair(&user);
    let resp = ok_response(user_login_resp_vo);
    return resp;
}

pub async fn refresh_token(Json(refresh_token_vo): Json<RefreshTokenVo>) -> Response {
    let result = decode_jwt(refresh_token_vo.refresh_token.as_str(), 1);
    if let Ok(user) = result {
        let user = User {
            id: user.id,
            name: user.name,
            email: user.email,
        };
        let user_login_resp_vo = create_jwt_pair(&user);
        let resp = ok_response(user_login_resp_vo).unwrap();
        return build_json_response(StatusCode::OK.as_u16(), &resp);
    }
    return build_json_response(StatusCode::UNAUTHORIZED.as_u16(), error::JWT_AUTH_FAILED());
}

pub(crate) async fn test(Extension(user): Extension<User>) -> Result<ApiResponse<User>, AppError> {
    // 这里模拟一个成功的处理
    return ok_response(user);
}

async fn logout() -> impl IntoResponse {
    // 这里只是一个示例，实际可以处理 session 等
    (StatusCode::OK, Json("Logged out"))
}

