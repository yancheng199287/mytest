use std::marker::PhantomData;
use sea_orm::{DatabaseConnection, EntityTrait, DbErr, ActiveModelTrait, InsertResult, DeleteResult, PrimaryKeyTrait, Select, Insert, UpdateResult, QueryFilter, IntoActiveModel};
use crate::db::pool::mysql_pool::{get_db_pool};

pub struct BaseDao<E, A>
    where
        E: EntityTrait,
        A: ActiveModelTrait,
{
    pub db: &'static DatabaseConnection,
    _marker: PhantomData<E>,
    _marker1: PhantomData<A>,
}

impl<E, A> BaseDao<E, A>
    where
        E: EntityTrait,
        A: ActiveModelTrait<Entity=E>,
{
    pub fn new() -> Self {
        BaseDao {
            db: get_db_pool(),
            _marker: PhantomData,
            _marker1: PhantomData,
        }
    }
    pub async fn find_by_id<P>(&self, id: P) -> Result<Vec<<E as EntityTrait>::Model>, DbErr>
        where
            P: Into<<E::PrimaryKey as PrimaryKeyTrait>::ValueType>,
    {
        E::find_by_id(id).all(self.db).await
    }
    pub async fn find_all(&self) -> Result<Vec<<E as EntityTrait>::Model>, DbErr>
    {
        E::find().all(self.db).await
    }
    pub async fn insert(&self, model: A) -> Result<InsertResult<A>, DbErr> {
        E::insert(model).exec(self.db).await
    }
    async fn insert_many<I>(&self, models: I) -> Result<InsertResult<A>, DbErr>
        where
            A: ActiveModelTrait<Entity=E>,
            I: IntoIterator<Item=A>,
    {
        E::insert_many(models).exec(self.db).await
    }
    pub async fn update(&self, model: A) -> Result<E::Model, DbErr> where
        E::Model: IntoActiveModel<A>,
    {
        E::update(model).exec(self.db).await
    }

    pub async fn delete(&self, model: A) -> Result<DeleteResult, DbErr> {
        E::delete(model).exec(self.db).await
    }
    pub async fn delete_by_id<P>(&self, id: P) -> Result<DeleteResult, DbErr>
        where P: Into<<E::PrimaryKey as PrimaryKeyTrait>::ValueType>
    {
        E::delete_by_id(id).exec(self.db).await
    }
}