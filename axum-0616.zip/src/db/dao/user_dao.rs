use once_cell::sync::OnceCell;
use sea_orm::entity::prelude::*;
use crate::db::dao::base_dao::BaseDao;
use crate::entity::user::Entity as UserEntity;
use crate::entity::user::ActiveModel as UserActiveModel;


pub const INSTANCE: OnceCell<UserDao> = OnceCell::with_value(UserDao::new());
const INSTANCE1: OnceCell<UserDao> = OnceCell::new();


pub fn get_user_dao() -> &'static UserDao {
    INSTANCE1.get_or_init(async || {
        UserDao::new().await
    })
}

pub struct UserDao {
    pub base_dao: BaseDao<UserEntity, UserActiveModel>,
}

impl UserDao {
    pub fn new() -> Self {
        UserDao
        {
            base_dao: BaseDao::new(),
        }
    }

    // UserDao 特定的方法，可以在这里添加
}

