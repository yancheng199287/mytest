// src/middleware.rs
use axum::{body::{Body}, body, http::{Request, Response}, middleware::Next, response::{IntoResponse, Json}};
use hyper::StatusCode;
use std::convert::Infallible;
use bytes::Bytes;
use crate::bean::error::AppError;
use crate::bean::response_data::ApiResponse;


/*pub(crate) async fn response_transformer(req: Request<Body>, next: Next) -> Result<impl IntoResponse, Infallible> {
    let mut response = next.run(req).await;

    if response.headers().contains_key("X-Direct-Response") {
        // 如果响应包含 "X-Direct-Response" 头，直接返回响应
        response.headers_mut().remove("X-Direct-Response");
        Ok(response)
    } else if response.status().is_success() {
        // 如果响应成功，尝试解析响应体
        let (parts, body) = response.into_parts();
        let body_bytes = match body::to_bytes(body, usize::MAX).await {
            Ok(bytes) => bytes,
            Err(_) => {
                let app_error = AppError {
                    code: StatusCode::INTERNAL_SERVER_ERROR.as_u16(),
                    message: Some("Internal Server Error".to_string()),
                };
                return Ok(app_error.into_response());
            }
        };
        // 尝试解析为 ApiResponse
        match serde_json::from_slice::<serde_json::Value>(&body_bytes) {
            Ok(data) => {
                let api_response = ApiResponse {
                    code: parts.status.as_u16(),
                    message: None,
                    data: Some(data),
                };
                Ok(api_response.into_response())
            }
            Err(_) => {
                // 如果无法解析，直接返回原始响应
                let response = Response::from_parts(parts, Body::from(body_bytes));
                Ok(response)
            }
        }
    } else {
        // 处理异常情况
        let (parts, body) = response.into_parts();
        let body_bytes = body::to_bytes(body, usize::MAX).await.unwrap_or_else(|_| Bytes::new());

        let message = String::from_utf8(body_bytes.to_vec()).unwrap_or_else(|_| "Unknown error".to_string());
        let app_error = AppError {
            code: parts.status.as_u16(),
            message: Some(message),
        };
        Ok(app_error.into_response())
    }
}
*/

