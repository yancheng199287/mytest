use axum::Router;
use tracing::info;
use crate::router::app_router::app_router;
use crate::router::nested_router::nested_router;

mod router;
mod bean;
mod interceptor;
mod middle;
mod controller;
mod vo;

#[tokio::main]
async fn main() {
    log4rs::init_file("config/log4rs.yaml", Default::default()).unwrap();

    info!("web server started!  port 3000 ");
    start_server(app_router()).await;
}


async fn start_server(app_router: Router) {
    let listener = tokio::net::TcpListener::bind("0.0.0.0:3000").await.unwrap();
    axum::serve(listener, app_router).await.unwrap();
}


