use axum::extract::Request;
use axum::middleware::Next;
use axum::response::IntoResponse;
use http::StatusCode;
use crate::bean::build_response::build_json_response;
use crate::bean::error;
use crate::bean::jwt::{decode_jwt};


const WHITELIST_PATHS: [&str; 2] = ["/user/login", "/user/refresh_token"];


pub async fn jwt_auth(mut req: Request, next: Next) -> impl IntoResponse {
    let path = req.uri().to_string();3
    if WHITELIST_PATHS.contains(&path.as_str()) {
        return next.run(req).await;
    }
    let auth_header = req.headers().get("Authorization");
    if let Some(auth_header) = auth_header {
        if let Ok(auth_str) = auth_header.to_str() {
            if let Ok(user) = decode_jwt(auth_str, 0) {
                req.extensions_mut().insert(user);
                return next.run(req).await;
            }
        }
    }
    let code = StatusCode::UNAUTHORIZED.as_u16();
    build_json_response(code, error::JWT_AUTH_FAILED())
}