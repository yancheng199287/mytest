use axum::{Router};
use axum::routing::{get, post};
use tower::ServiceBuilder;
use crate::middle::jwt_auth_middle::jwt_auth;


pub fn app_router() -> Router {
    return Router::new()
        .route("/user/login", post(crate::controller::user_controller::login))
        .route("/user/test", get(crate::controller::user_controller::test))
        .route("/user/refresh_token", post(crate::controller::user_controller::refresh_token))
        .layer(ServiceBuilder::new().layer(axum::middleware::from_fn(jwt_auth)));
}