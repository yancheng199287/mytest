use axum::{routing::get, Router};
use std::net::SocketAddr;
use tower::ServiceBuilder;
use crate::bean::error::AppError;
use crate::middle::jwt_auth_middle::jwt_auth;

async fn root() -> Result<&'static str, AppError> {
    // 这里模拟一个成功的处理
    Ok("Hello, World!")
}

async fn error_handler() -> Result<&'static str, AppError> {
    // 这里模拟一个失败的处理
    Err(AppError::error("Something went wrong"))
}

#[tokio::test]
async fn main() {
    let app = Router::new()
        .route("/", get(root))
        .route("/error", get(error_handler))
        .layer(ServiceBuilder::new().layer(axum::middleware::from_fn(jwt_auth)));

    let listener = tokio::net::TcpListener::bind("127.0.0.1:3000").await.unwrap();
    println!("Listening on {:?}", listener);
    axum::serve(listener, app).await.unwrap();
}
