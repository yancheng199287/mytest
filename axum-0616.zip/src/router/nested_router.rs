use axum::{routing::{get, post}, Router, middleware};
use axum::extract::Request;
use axum::middleware::Next;
use axum::response::Response;
use tracing::info;

async fn list_users() -> &'static str {
    "List of users"
}

async fn create_user() -> &'static str {
    "Create a user"
}

async fn log_request(req: Request, next: Next) -> Response {
    info!("Received request: {:?}", req);
    next.run(req).await
}

pub fn nested_router() -> Router {
    let user_routes = Router::new()
        .route("/", get(list_users))
        .route("/create", post(create_user));
    // 嵌套路由
    let app = Router::new().nest("/users", user_routes)
        // 中间件可以在请求到达处理函数前进行预处理。
        .layer(middleware::from_fn(log_request));
    ;
    app
}

