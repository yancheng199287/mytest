use serde::{Deserialize, Serialize};


#[derive(Deserialize, Serialize)]
pub struct UserLoginVo {
    // 登陆方式 1 用户名密码登陆 2 手机号登陆 3 邮箱登陆
    pub login_type: u8,
    // 根据登陆方式，可能是 用户名 手机号 邮箱
    pub username: String,
    #[serde(default)]
    pub password: String,
    // 如果是手机号登陆 必须输入手机短信验证码
    #[serde(default)]
    pub sms_validate_code: String,
    // 如果检测登陆频繁 必须输入 验证码
    #[serde(default)]
    pub validate_code: String,
}



#[derive(Debug, Serialize)]
pub struct UserLoginRespVo {
    pub access_token: String,
    pub refresh_token: String,
}

#[derive(Debug, Deserialize)]
pub struct RefreshTokenVo {
    pub refresh_token: String,
}