import 'package:drift/drift.dart';

@DataClassName('BaseModel')
class BaseTable extends Table {
  DateTimeColumn get createdAt =>
      dateTime().clientDefault(() => DateTime.now())();

  DateTimeColumn get updatedAt => dateTime().nullable()();
}

class User extends BaseTable {
  IntColumn get id => integer().autoIncrement()();

  TextColumn get name => text().withLength(min: 1, max: 50)();

  TextColumn get email => text().withLength(min: 1, max: 50)();
}
