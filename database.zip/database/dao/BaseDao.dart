import 'package:drift/drift.dart';

import '../BaseTable.dart';
import '../app_database.dart';

abstract class BaseDao<T extends Table, P extends DataClass>
    extends DatabaseAccessor<AppDatabase> {
  BaseDao(AppDatabase attachedDatabase) : super(attachedDatabase);

  TableInfo<T, P> get entityTable;

  Future<List<P>> getAll() => select(entityTable).get();

  Stream<List<P>> watchAll() => select(entityTable).watch();

  Future<int> insert(Insertable<P> entity) => into(entityTable).insert(entity);

  Future<bool> updateEntity(Insertable<P> entity) =>
      update(entityTable).replace(entity);

  Future<int> deleteEntity(Insertable<P> entity) =>
      delete(entityTable).delete(entity);

  Future<List<QueryRow>> customQuery(String query, List<Variable> arguments) {
    return customSelect(query, variables: arguments, readsFrom: {entityTable})
        .get();
  }

  Future<List<P>> getPaginated(int page, int size) async {
    final rows = await (customSelect(
        'SELECT * FROM ${entityTable.actualTableName} LIMIT $size OFFSET ${(page - 1) * size}',
        readsFrom: {entityTable})).get();
    return Future.wait(rows.map((row) => entityTable.mapFromRow(row)));
  }
}

class UserMapper extends BaseDao<User, UserData> {
  UserMapper(AppDatabase db) : super(db);

  @override
  $UserTable get entityTable => db.user;
}

void main() async {
  adad();
}

Future<void> adad() async {
  // 创建数据库
  final db = AppDatabase();

// 创建UserMapper
  final userMapper = UserMapper(db);

// 插入数据
  final user = UserCompanion(
    name: Value('Tom11ss'),
    email: Value("648811ss")
  );
  await userMapper.insert(user);
}
