
import 'package:drift/drift.dart';

@DataClassName('BaseModel')
class BaseTables extends Table {
  DateTimeColumn get createdAt => dateTime().withDefault(Constant(DateTime.now()))();
  DateTimeColumn get updatedAt => dateTime().nullable().customConstraint('NULL ON UPDATE CURRENT_TIMESTAMP')();
}


class Users extends BaseTables {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get name => text().withLength(min: 1, max: 50)();
  TextColumn get email => text().withLength(min: 1, max: 50)();
}
