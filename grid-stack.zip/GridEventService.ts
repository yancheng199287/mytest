import {th} from "vuetify/locale";

const GRID_CONTENT_CLASS_NAME = 'grid-item-content';
const QUERY_GRID_CONTENT_CLASS_NAME = '.' + GRID_CONTENT_CLASS_NAME;

export class GridEventService {

    observer: MutationObserver

    constructor(public handleGridContentEvent: (event: any) => void) {
        console.log(handleGridContentEvent)
        this.observer = this.createMutationObserver();
    }


    // 处理真正点击事件的逻辑
    /*    handleGridContentEvent(event: any) {
            const id = event.currentTarget.dataset.id;
            if (event.type === 'click') {
                console.log('Item clicked:', id);
            } else if (event.type === 'contextmenu') {
                event.preventDefault();
                console.log('Item right-clicked:', id);
            }
        };*/


    initBindGridItemEvent(gridContainerElement: HTMLDivElement) {
        this.observer.observe(gridContainerElement, {childList: true, subtree: true});
        // 初次绑定
        this.bindEventsToGridItemContents();
    }


    private bindEventsToGridItemContents() {
        // 不能使用foreach  如果使用了  那么 this 不是指向本类的对象，而是其他的，无法引用到本对象的其他函数或者属性，改成for循环
        let elements = document.querySelectorAll(QUERY_GRID_CONTENT_CLASS_NAME);
        for (let i = 0; i < elements.length; i++) {
            this.bindEventsToElement(elements[i]);
        }
    };

    /// 卸载监听器
    disconnectMutationObserver() {
        if (this.observer) {
            this.observer.disconnect();
        }
        // Unbind events from all elements
        document.querySelectorAll(QUERY_GRID_CONTENT_CLASS_NAME).forEach(this.unbindEventsFromElement);
    }


    // 绑定点击事件和右击事件
    private bindEventsToElement(element: Element) {
        console.log("this.handleGridContentEvent:", this)
        const htmlElement = element as HTMLElement;
        console.log("bindEventsToElement element", element, htmlElement.dataset.eventsBound)
        if (!htmlElement.dataset.eventsBound && htmlElement.classList.contains(GRID_CONTENT_CLASS_NAME)) {
            htmlElement.addEventListener('click', this.handleGridContentEvent);
            htmlElement.addEventListener('contextmenu', this.handleGridContentEvent);
            htmlElement.dataset.eventsBound = 'true'; // Use dataset to flag bound elements
        }
    }


    // 解绑事件，防止内存泄漏
    private unbindEventsFromElement(element: Element) {
        const htmlElement = element as HTMLElement;
        if (htmlElement.dataset.eventsBound && htmlElement.classList.contains(GRID_CONTENT_CLASS_NAME)) {
            htmlElement.removeEventListener('click', this.handleGridContentEvent);
            htmlElement.removeEventListener('contextmenu', this.handleGridContentEvent);
            delete htmlElement.dataset.eventsBound;
        }
    };


    private createMutationObserver(): MutationObserver {
        return new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                if (mutation.type === 'childList') {
                    mutation.addedNodes.forEach(node => {
                        if (node.nodeType === Node.ELEMENT_NODE) {
                            const element = node as Element;
                            const contentElement = element.querySelector(QUERY_GRID_CONTENT_CLASS_NAME);
                            if (contentElement) {
                                this.bindEventsToElement(contentElement);
                            }
                        }
                    });
                    mutation.removedNodes.forEach(node => {
                        if (node.nodeType === Node.ELEMENT_NODE) {
                            const element = node as Element;
                            const contentElement = element.querySelector(QUERY_GRID_CONTENT_CLASS_NAME);
                            if (contentElement) {
                                this.unbindEventsFromElement(contentElement);
                            }
                        }
                    });
                }
            });
        });
    }


}