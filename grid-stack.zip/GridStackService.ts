import {GridStack} from "gridstack";
import {th} from "vuetify/locale";

const GRID_CONTENT_CLASS_NAME = 'grid-item-content';
const QUERY_GRID_CONTENT_CLASS_NAME = '.' + GRID_CONTENT_CLASS_NAME;

export class AppInfo {
    constructor(
        public id: number,
        public icon: string,
        public text: string,
    ) {
    }
}

export class GridSwitchStatus {
    constructor(
        public noResizeStatus: boolean,
        public noMoveStatus: boolean,
        public lockedStatus: boolean,
        public staticStatus: boolean
    ) {
    }
}


export class GridStackService {

    public grid: GridStack;

    constructor(public gridContainerElement: HTMLDivElement) {
    }

    initGrid(appInfos: AppInfo[], gridStatus: {
        noResizeStatus: boolean,
        noMoveStatus: boolean,
        lockedStatus: boolean,
        staticStatus: boolean
    }) {
        if (!this.gridContainerElement) {
            return;
        }
        this.grid = GridStack.init({
            float: true,
            columnOpts: {
                layout: "compact",
                breakpoints: [
                    {w: 200, c: 1}, {w: 400, c: 2}, {w: 600, c: 3}, {w: 800, c: 4}, {w: 1000, c: 6}, {w: 1200, c: 7}
                ]
            },
            // maxRow: 5,
            cellHeight: '8rem',
            resizable: {
                handles: 'e, se, s, sw, w'
            }
        }, this.gridContainerElement);


        console.log("this.grid", this.grid)

        this.grid.removeAll(true, true);
        const gridItems = appInfos.map((item, index) => (createGridNode(item, gridStatus)));
        //  grid.column(columnCount.value);
        this.grid.load(gridItems); // 加载新的项目
    }

    addNewGrid(appInfo: AppInfo, gridStatus: GridSwitchStatus) {
        let index = this.grid.engine.nodes.length + 1;
        // appInfo.id = index;
        // let appInfo = new AppInfo(index, 'fa-solid fa-gamepad', 'Game');
        const newNode = createGridNode(appInfo, gridStatus);
        this.grid.addWidget(newNode);
    }

    updateGrid(columnCount: number, gridStatus: GridSwitchStatus) {
        this.grid.column(columnCount);
        let items = this.grid.engine.nodes;
        let gridCols = this.grid.opts.column;
        let gridColumnCount: number = typeof gridCols === 'number' ? gridCols : 0;
        if (columnCount >= gridColumnCount) {
            items.forEach((item, index) => {
                let x = index % columnCount;
                let y = Math.floor(index / columnCount);
                this.grid.update(item.el, {
                    x: x, y: y,
                    noResize: gridStatus.noResizeStatus,
                    noMove: gridStatus.noMoveStatus,
                    locked: gridStatus.lockedStatus,
                })
            })
        }
    }


}

function createGridNode(appInfo: AppInfo, gridStatus: {
    noResizeStatus: boolean,
    noMoveStatus: boolean,
    lockedStatus: boolean,
    staticStatus: boolean
}): object {
    return {
        id: appInfo.id,
        // x: index % columnCount.value,  不填写xy 自动寻找空白填充，注意这里的xy 响应式列  自定义列 有一定的冲突。
        // y: Math.floor(index / columnCount.value),
        w: 1,
        h: 1,
        noResize: gridStatus.noResizeStatus,
        noMove: gridStatus.noMoveStatus,
        locked: gridStatus.lockedStatus,
        static: gridStatus.staticStatus,
        content: `<div class="${GRID_CONTENT_CLASS_NAME}" data-id="${appInfo.id}">
                  <i class="${appInfo.icon}  v-icon notranslate v-theme--light v-icon--size-large text-blue darken-2"></i>
                  <div class="icon-text">${appInfo.text}</div>
                </div>`
    }

}


