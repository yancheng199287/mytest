<template>
  <v-container fluid>+
    <v-row justify="start">
      <v-col>
        <v-switch
            v-model="isDraggable"
            label="Toggle Draggable"
            class="my-4"
        />
      </v-col>
      <v-col cols="12" md="4">
        <v-slider
            v-model="blurAmount"
            :min="0"
            :max="10"
            step="0.5"
            label="Blur Amount"
            class="my-4"
        />
      </v-col>

      <v-col>
        <v-select
            v-model="selectedImage"
            :items="imageOptions"
            item-text="text"
            item-value="value"
            label="Select Background Image"
            class="my-4"
        />
      </v-col>
    </v-row>


    <v-row justify="start">
      <v-col cols="12" md="4">
        <button @click="addNewGrid">新增网格</button>
      </v-col>
    </v-row>
    <v-row justify="center">
      <v-col>
        <v-text-field
            v-model="columnCount"
            label="每列数量"
            type="number"
            min="1"
            max="12"
        ></v-text-field>
      </v-col>
    </v-row>

    <v-row justify="center">
      <v-col>
        <div id="background-container" :style="backgroundStyle"></div>
        <div id="grid-container">
          <div ref="gridContainer" class="grid-stack"></div>
        </div>
      </v-col>
    </v-row>
  </v-container>
</template>
<script lang="ts" setup>
import {ref, onMounted, watch, computed, onBeforeUnmount, nextTick} from 'vue';
import {GridStack} from 'gridstack';
import 'gridstack/dist/gridstack.min.css';
import 'gridstack/dist/gridstack-extra.css';
import ContextMenu from "@imengyu/vue3-context-menu";
import {toast} from "vue3-toastify";
import {AppInfo, GridStackService} from "./GridStackService.ts";
import {GridEventService} from "./GridEventService.ts";

//图标搜索 https://fontawesome.com/search
const appInfoList = [
  new AppInfo(1, 'fa-solid fa-wand-magic-sparkles', 'sparkles'),
  new AppInfo(2, 'fa-solid fa-image', 'image'),
  new AppInfo(3, 'fa-solid fa-coffee', 'Coffee'),
  new AppInfo(4, 'fa-solid fa-apple-alt', 'Apple'),
  new AppInfo(5, 'fa-solid fa-bell', 'Bell'),
  new AppInfo(6, 'fa-solid fa-camera', 'Camera'),
  new AppInfo(7, 'fa-solid fa-envelope', 'Mail'),
  new AppInfo(8, 'fa-solid fa-heart', 'Heart'),
  new AppInfo(9, 'fa-solid fa-star', 'Star'),
  new AppInfo(10, 'fa-solid fa-music', 'Music'),
  new AppInfo(11, 'fa-solid fa-film', 'Film'),
];

const columnCount = ref<number>(6); // 初始列数为3

const gridContainer = ref<HTMLDivElement | null>(null);

// GridStack  UI组件的管理，增加 修改，刷新，删除
let gridService: GridStackService;

const handleGridContentEvent = (event) => {
  console.log(event.currentTarget.parentElement)
  const id = event.currentTarget.dataset.id;
  if (event.type === 'click') {
    console.log('UI VUE Item clicked:', id);
    handleClick(event, id);
  } else if (event.type === 'contextmenu') {
    event.preventDefault();
    console.log('UI VUE  Item right-clicked:', id);
    handleRightClick(event, id);
  }
};
// 网格事件的处理
let gridEventService: GridEventService = new GridEventService(handleGridContentEvent);
;

const gridNoResizeStatus = ref(false);
const gridNoMoveStatus = ref(false);
const gridLockedStatus = ref(false);
const gridNStaticStatus = ref(false);


const updateGrid = () => {
  let cols = columnCount.value;
  gridService.updateGrid(cols, {
    noResizeStatus: gridNoResizeStatus.value,
    noMoveStatus: gridNoMoveStatus.value,
    lockedStatus: gridLockedStatus.value,
    staticStatus: gridNStaticStatus.value,
  });
};


onMounted(() => {
  let htmlElement = gridContainer.value;
  gridService = new GridStackService(htmlElement);
  gridService.initGrid(appInfoList, {
    noResizeStatus: gridNoResizeStatus.value,
    noMoveStatus: gridNoMoveStatus.value,
    lockedStatus: gridLockedStatus.value,
    staticStatus: gridNStaticStatus.value,
  });


  gridEventService.initBindGridItemEvent(htmlElement);


});

onBeforeUnmount(() => {
  // Cleanup observer
  gridEventService.disconnectMutationObserver()
});


watch(columnCount, updateGrid);

function addNewGrid() {
  let appInfo = new AppInfo(appInfoList.length , 'fa-solid fa-gamepad', 'Game');
  appInfoList.push(appInfo);
  gridService.addNewGrid(appInfo, {
    noResizeStatus: gridNoResizeStatus.value,
    noMoveStatus: gridNoMoveStatus.value,
    lockedStatus: gridLockedStatus.value,
    staticStatus: gridNStaticStatus.value,
  })
}


// 控制是否可以拖动网格的开关,拖动的时候禁止点击
const isDraggable = ref(false);

// 计算属性，是否可以拖动
const isResizeable = computed(() => {
  return isDraggable;
});

// 处理点击事件
const handleClick = (event, id) => {
  if (!isDraggable.value) {
    let text = appInfoList[id].text
    toast.success(`打开: ${text}`)
  }
};


// 控制右击菜单的显示
const menuOptions = ref([
  {label: '运行', icon: 'fa-solid fa-coffee', onClick: () => toast.success("运行")},
  {label: '查看', icon: 'fa-solid fa-robot', onClick: () => toast.success('查看')},
  {label: '更新', icon: 'fa-solid fa-cogs', onClick: () => toast.success('更新')},
  {label: '卸载', icon: 'fa-solid fa-wind', onClick: () => toast.success('卸载')},
]);

// 打开右键菜单
const handleRightClick = (event, id) => {
  if (isDraggable.value) {
    return
  }
  event.preventDefault();

  ContextMenu.showContextMenu({
    theme: "flat",
    x: event.clientX,
    y: event.clientY,
    items: menuOptions.value,
  });
};


// 高斯模糊量
const blurAmount = ref(0); // 初始值为10

// 背景图片选项
const imageOptions = [
  '11.jpg',
  '22.jpg',
  '33.jpg',
];


// 选中的背景图片
const selectedImage = ref(imageOptions[0]);

// 计算属性，用于动态绑定背景图片和高斯模糊效果
const backgroundStyle = computed(() => {
  const imagePath = (`/bg/${selectedImage.value}`);
  return {
    backgroundImage: `url(${imagePath})`,
    filter: `blur(${blurAmount.value}px)`,
  };
});


</script>

<style>
#background-container {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: url("/bg/11.jpg") no-repeat center center / cover;
  filter: blur(7px);
  background-size: cover;
  background-attachment: fixed;
  background-position: center;
  z-index: -1;
}

.grid-stack-item {
  border: 10px #646cff;
  margin: 15px;
}

.grid-stack-item-content {
  overflow: hidden;
  font-size: 20px;
  user-select: none;
}

.icon-text {
  margin-top: 6px;
  font-size: calc(0.5em + 0.5vw); /* 动态调整文本大小 */
  user-select: none;
}
</style>

<style scoped>


</style>

<!--
https://www.cnblogs.com/easonturing/p/6495180.html
-->