yarn pack  打成一个本地压缩包


然后在其他项目引入
 yarn add  绝对路径的压缩包