import {WebSocketSDK} from "./LuaWebSocketClient"
import {Header, ScriptFunctionTask, RequestBody, TASK_TYPE, RequestData} from "./LuaRequestPayload"
import {Encoder} from "@msgpack/msgpack";

const encoder = new Encoder();


export class LuaEngineClientSdk {

    private webSocketSDK!: WebSocketSDK;

    public initScriptClient(func: (success: boolean) => void) {
        let url = "ws://localhost:8080";
        this.webSocketSDK = new WebSocketSDK(url, func);
    }

    sendWebsocketMessage(request_data: RequestData, isStream: boolean): Promise<any> {
        return new Promise((resolve, reject) => {
            const startTime = new Date().getTime();
            this.webSocketSDK.callbacks[request_data.header.msg_id] = {resolve, reject, isStream, startTime};
            if (this.webSocketSDK.socket) {
                console.log("request_data:", request_data);
                const messageEncoded: Uint8Array = encoder.encode(request_data);
                this.webSocketSDK.socket.send(messageEncoded);
            } else {
                reject('WebSocket is not connected');
            }
        });
    }

    public callScriptFunction(scriptFunctionTask: Object) {
        let header = new Header("com.miniapp", "1as46a54sda6daasdasd");
        let requestBody = new RequestBody(TASK_TYPE.ScriptFunction, scriptFunctionTask);
        let requestData: RequestData = new RequestData(header, null, requestBody)
        return this.sendWebsocketMessage(requestData, false);
    }

    public callScriptFunction1(scriptFunctionTask: ScriptFunctionTask) {
        let header = new Header("com.miniapp", "1as46a54sda6daasdasd");
        let requestBody = new RequestBody(TASK_TYPE.ScriptFunction, scriptFunctionTask);
        let requestData: RequestData = new RequestData(header, null, requestBody)
        return this.sendWebsocketMessage(requestData, false);
    }

}

