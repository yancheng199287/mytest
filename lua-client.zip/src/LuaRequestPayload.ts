//const PROTOCOL_VERSION: string = "v1.0.0";
const PROTOCOL_VERSION_NUMBER: number = 1;

class Header {
    app_id: string;
    session_id: string;
    msg_id: string;
    version: number;
    datetime: string;

    constructor(app_id: string, session_id: string) {
        this.app_id = app_id;
        this.session_id = session_id;
        this.msg_id = app_id + "_" + this.getUuid();
        this.version = PROTOCOL_VERSION_NUMBER;
        this.datetime = new Date().toString();
    }

    // 生成唯一性id
    private getUuid(): string {
        return Number(Math.random().toString().slice(2, 10) + Date.now()).toString(36);
    }
}

class MetaData {
    name: string;
    type: string;
    length: number;
    chunkTotal: number;
    chunkIndex: number;

    constructor(name: string, type: string, length: number, chunkTotal: number, chunkIndex: number) {
        this.name = name;
        this.type = type;
        this.length = length;
        this.chunkTotal = chunkTotal;
        this.chunkIndex = chunkIndex;
    }
}

class ScriptFunctionTask {
    script_file_path: string;
    function_name: string;
    function_params: object;

    constructor(script_file_path: string, function_name: string, function_params: object) {
        this.script_file_path = script_file_path;
        this.function_name = function_name;
        this.function_params = function_params;
    }
}

const TASK_TYPE = {
    Script: "Script",
    ScriptFunction: "ScriptFunction",
    /// 订阅响应流，开启或者关闭，持续监听消息的响应
    Subscription: "Subscription",
}

type TaskType = typeof TASK_TYPE[keyof typeof TASK_TYPE];

class RequestBody {
    task_type: TaskType;
    data: Object;

    constructor(task_type: TaskType, data: Object) {
        this.task_type = task_type;
        this.data = data instanceof String ? data : JSON.stringify(data);
    }
}

class RequestData {
    header: Header;
    meta_data: MetaData | null;
    request_body: RequestBody;

    constructor(header: Header, metaData: MetaData | null, requestBody: RequestBody) {
        this.header = header;
        this.meta_data = metaData;
        this.request_body = requestBody
    }
}


export {Header, MetaData, RequestBody, TASK_TYPE, ScriptFunctionTask, RequestData}
