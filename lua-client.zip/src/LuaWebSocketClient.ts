import {decode, Decoder} from "@msgpack/msgpack";

type ConnectCallback = (success: boolean) => void;

const decoder = new Decoder();

interface CallbackObject {
    resolve: (value?: any) => void;
    reject: (reason?: any) => void;
    isStream: boolean;
    startTime: number;
}

class ResponseData {
    private _app_id: string
    private _msg_id: string
    private _code: number
    private _msg: string
    private _data: string


    constructor(app_id: string, msg_id: string, code: number, msg: string, data: string) {
        this._app_id = app_id;
        this._msg_id = msg_id;
        this._code = code;
        this._msg = msg;
        this._data = data;
    }


    get app_id(): string {
        return this._app_id;
    }

    set app_id(value: string) {
        this._app_id = value;
    }

    get msg_id(): string {
        return this._msg_id;
    }

    set msg_id(value: string) {
        this._msg_id = value;
    }


    get code(): number {
        return this._code;
    }

    set code(value: number) {
        this._code = value;
    }

    get msg(): string {
        return this._msg;
    }

    set msg(value: string) {
        this._msg = value;
    }

    get data(): string {
        return this._data;
    }

    set data(value: string) {
        this._data = value;
    }
}

class WebSocketSDK {
    private readonly url: string;
    private _socket: WebSocket | null;
    private _callbacks: { [key: string]: CallbackObject };
    private readonly connectCallback: ConnectCallback;

    constructor(url: string, connectCallback: ConnectCallback) {
        this.url = url;
        this._socket = null;
        this._callbacks = {};
        this.connectCallback = connectCallback;
        this.connect();
    }

    private connect(): void {
        this._socket = new WebSocket(this.url);
        this._socket.onopen = () => {
            console.log('WebSocket connected');
            this.connectCallback(true);
        };
        // @ts-ignore
        this._socket.onmessage = async (event: MessageEvent) => {
            // console.log("WebSocket Receive data：", event);
            let responseData: ResponseData = await this.decodeMessagePack(event.data).then((data) => {
                return this.arrayToResponseData(data)
            }).catch((error => {
                throw new Error(error);
            }));
            // console.log("responseData:", responseData);
            //let response_data = JSON.parse(responseData);
            let msg_id = responseData.msg_id;
            let callbackObject = this._callbacks[msg_id];
            let startTime = callbackObject.startTime;
            let endTime = new Date().getTime();

            let startTimeStr = this.formatDate(new Date(startTime));
            let endTimeStr = this.formatDate(new Date(endTime));

            console.log("responseData:", responseData);
            console.log("responseData.data:", responseData.data);
            console.log("脚本耗时：", "msg_id:", msg_id, "startTime:", startTimeStr, "endTime:", endTimeStr, "costTime:", endTime - startTime, "ms");
            if (!callbackObject) {
                console.log("can not find callback id: ", msg_id);
                return;
            }
            if (responseData.code !== 0) {
                callbackObject.reject({
                    "code": responseData.code,
                    "msg": responseData.msg
                });
            } else {
                try {
                    const jsonObject = JSON.parse(responseData.data);
                    callbackObject.resolve(jsonObject);
                } catch (e) {
                    console.error("response.data,invalid JSON string", e);
                    callbackObject.resolve(responseData.data);
                }
            }
            // console.log("callbacks:", this._callbacks[msg_id]);
            if (!callbackObject.isStream) {
                delete this._callbacks[msg_id];
            }
        };
        this._socket.onerror = (error) => {
            console.error('WebSocket error:', error);
            this.connectCallback(false);
        }
        this._socket.onclose = () => {
            console.log('WebSocket closed');
            this._callbacks = {};
            setTimeout(() => {
                this.connect();
            }, 3000);
        };
    }

    // 将数组转换为 Person 对象
    arrayToResponseData(data: any[]): ResponseData {
        if (!data || data.length < 4) {
            throw new Error("data length is not validate,can not parse ResponseData")
        }
        return new ResponseData(data[0], data[1], data[2], data[3], data[4])
    }

    get socket(): WebSocket | null {
        return this._socket;
    }


    get callbacks(): { [p: string]: CallbackObject } {
        return this._callbacks;
    }

    set callbacks(value: { [p: string]: CallbackObject }) {
        this._callbacks = value;
    }

    closeLongRequest(id: string): void {
        delete this._callbacks[id];
    }

    close(): void {
        if (this._socket) {
            this._socket.close();
        }
    }

    // 独立的解码函数
    decodeMessagePack(data: ArrayBuffer | Blob): Promise<any> {
        return new Promise((resolve, reject) => {
            // MessagePack 字节数组
            if (data instanceof ArrayBuffer) {
                try {
                    const decodedData = decoder.decode(new Uint8Array(data));
                    resolve(decodedData);
                } catch (e) {
                    reject(e);
                }
                // 大块二进制
            } else if (data instanceof Blob) {
                const reader = new FileReader();
                reader.onload = () => {
                    const arrayBuffer = reader.result as ArrayBuffer;
                    try {
                        const decodedData = decode(new Uint8Array(arrayBuffer));
                        resolve(decodedData);
                    } catch (e) {
                        reject(e);
                    }
                };
                reader.onerror = () => reject(reader.error);
                reader.readAsArrayBuffer(data);
                // json字符串
            } else if (typeof data === 'string') {
                try {
                    const decodedData = JSON.parse(data);
                    resolve(decodedData);
                } catch (e) {
                    reject(e);
                }
            } else {
                reject(new Error("Unsupported data type"));
            }
        });
    }


    padZero(num: number, length = 2) {
        let str = num.toString();
        while (str.length < length) {
            str = '0' + str;
        }
        return str;
    }

    formatDate(date: Date) {
        const year = date.getFullYear();
        const month = this.padZero(date.getMonth() + 1); // 月份从0开始
        const day = this.padZero(date.getDate());
        const hours = this.padZero(date.getHours());
        const minutes = this.padZero(date.getMinutes());
        const seconds = this.padZero(date.getSeconds());
        const milliseconds = this.padZero(date.getMilliseconds(), 3);
        return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}.${milliseconds}`;
    }
}

export {WebSocketSDK};
