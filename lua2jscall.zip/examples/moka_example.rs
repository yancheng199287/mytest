use std::time::Duration;
use moka::future::Cache;

#[tokio::main]
pub async fn main() {
    // 创建一个缓存，容量为 100，条目在 30 秒后过期
    let cache = Cache::builder()
        .max_capacity(200)
        // time_to_live（生存时间）参数设置缓存条目的固定存活时间。无论条目是否被访问，只要存活时间到期，条目就会被自动移除
        .time_to_live(Duration::from_secs(60 * 15))// 最大存活10分钟
        // time_to_idle（闲置时间）参数设置条目在闲置状态下的存活时间。如果在指定的时间内条目没有被访问，它就会被移除。
        .time_to_idle(Duration::from_secs(60 * 10))// 最大空闲10分钟
        // expire_after 参数允许对条目过期的策略进行更细粒度的控制，可以基于自定义逻辑确定条目何时过期。它可以同时包含 create, update 和 access 三种过期策略。
        // .expire_after(Duration::from_secs(30)) // 基于创建时间的过期策略，设置为30秒
        .build();

    // 插入一个键值对
    cache.insert(1, "a").await;

    // 在 30 秒内获取该键的值
    if let Some(value) = cache.get(&1).await {
        println!("Value for key 1: {}", value);
    } else {
        println!("Key not found or expired");
    }
}

