use std::{env, fs};
use std::fs::File;
use std::io::Write;
use std::path::{Path, PathBuf};
use std::time::Duration;
use askama::Template;
use log::info;
use notify::{Config, Event, EventKind, RecommendedWatcher, RecursiveMode, Watcher};
use regex::Regex;


#[derive(Template)]
#[template(path = "ts_template.txt")] // ts_template.txt 位于您的源文件目录下
struct TsTemplate {
    functions: Vec<(String, String)>, // 函数名和路径
}

fn main() {
    log4rs::init_file("config/log4rs.yaml", Default::default()).unwrap();

    let (tx, rx) = crossbeam_channel::unbounded();


    // 创建去抖事件发射器和接收器


    let mut watcher = RecommendedWatcher::new(tx, Config::default()).unwrap();

    // 创建文件监听器，递归监听 lua-script 目录
    let mut current_dir = env::current_dir().unwrap();
    current_dir.push("lua-script");
    println!("watch lua script dir: {:?}", &current_dir.display());
    watcher.watch(&current_dir, RecursiveMode::Recursive).unwrap();

    for event in rx {
        let event = event.unwrap();
        println!("Change detected: {:?}", event);
        handle_event(event);
    }
}


fn handle_event(event: Event) {
    match event.kind {
        notify::EventKind::Create(_) | notify::EventKind::Modify(_) => {
            if let Some(path) = event.paths.first() {
                if path.extension().map_or(false, |ext| ext == "lua") {
                    update_ts_file(path);
                }
            }
        }
        notify::EventKind::Remove(_) => {
            if let Some(path) = event.paths.first() {
                if let Some(ts_path) = lua_to_ts_path(path) {
                    fs::remove_file(ts_path).unwrap_or_else(|e| println!("Failed to delete ts file: {}", e));
                }
            }
        }
        notify::EventKind::Modify(_) => {
            if let Some(path) = event.paths.first() {
                update_ts_file(path);
            }
        }
        _ => {}
    }
}


fn update_ts_file(lua_path: &Path) {
    info!("update_ts_file: {:?}",lua_path);
    let content = fs::read_to_string(lua_path).unwrap();
    let functions = parse_lua_functions(&content, lua_path);
    let ts_template = TsTemplate { functions };
    let ts_content = ts_template.render().unwrap();
    let ts_path = lua_to_ts_path(lua_path).unwrap();
    write_to_file(&ts_path, &ts_content)
}

fn write_to_file(ts_path: &PathBuf, ts_content: &str) {
    // 检查文件是否存在
    let exists = ts_path.exists();

    // 创建或截断文件
    let mut file = match File::create(ts_path) {
        Ok(file) => file,
        Err(e) => {
            eprintln!("Failed to create file {}: {}", ts_path.display(), e);
            return;
        }
    };

    // 写入内容
    if let Err(e) = file.write_all(ts_content.as_bytes()) {
        eprintln!("Failed to write to file {}: {}", ts_path.display(), e);
    } else if exists {
        println!("Updated file {}", ts_path.display());
    } else {
        println!("Created new file {}", ts_path.display());
    }
}

fn lua_to_ts_path(lua_path: &Path) -> Option<PathBuf> {
    lua_path.with_extension("ts").file_name().map(PathBuf::from)
}

fn parse_lua_functions(content: &str, lua_path: &Path) -> Vec<(String, String)> {
    // 匹配 "local function" 后跟一个或多个空格，再跟以 "pub_" 开头的函数名和参数列表
    let re = Regex::new(r"local\s+function\s+(pub_\w+)\s*\(\s*\)").unwrap();
    re.captures_iter(content)
        .map(|cap| {
            // 提取函数名和计算相对路径
            (cap[1].to_string(), lua_path_to_relative(lua_path))
        })
        .collect()
}

fn lua_path_to_relative(lua_path: &Path) -> String {
    // 将给定的全路径转换为相对于 "/lua-script" 的相对路径
    // 使用 `strip_prefix` 方法尝试移除基路径前缀
    match lua_path.strip_prefix("/lua-script") {
        Ok(rel_path) => {
            // 将 Path 转换为字符串，并替换所有反斜杠为正斜杠，确保路径格式在所有系统下一致
            rel_path.to_str().unwrap_or_default().replace("\\", "/")
        }
        Err(_) => {
            // 如果路径前缀不匹配或其他问题，返回空字符串或处理错误
            String::new()
        }
    }
}