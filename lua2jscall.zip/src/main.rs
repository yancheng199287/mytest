use std::{env, fs};
use std::fs::File;
use std::io::Write;
use std::path::{Path, PathBuf};
use std::time::{Duration, Instant};
use askama::Template;
use log::info;
use notify::{Config, Event, EventKind, RecommendedWatcher, RecursiveMode, Watcher};
use regex::Regex;
use moka::sync::Cache;

#[derive(Template)]
#[template(path = "ts_template.txt")] // ts_template.txt 位于您的源文件目录下
struct TsTemplate {
    lua_file_path: String, //lua路径
    functions: Vec<String>, // 函数名
}

fn main() {
    log4rs::init_file("config/log4rs.yaml", Default::default()).unwrap();

    /// 使用缓存来控制事件抖动，防止触发多次变动的事件，
    let cache = Cache::builder()
        .max_capacity(200)
        .time_to_live(Duration::from_secs(60 * 15))// 最大存活15分钟
        .time_to_idle(Duration::from_secs(60 * 10))// 最大空闲10分钟
        .build();

    // 变动事件时间间隔（1秒）
    let time_interval = Duration::from_secs(1);

    let (tx, rx) = crossbeam_channel::unbounded();
    let mut watcher = RecommendedWatcher::new(tx, Config::default()).unwrap();

    // 创建文件监听器，递归监听 lua-script 目录
    let mut current_dir = env::current_dir().unwrap();
    current_dir.push("lua-script");
    println!("watch lua script dir: {:?}", &current_dir.display());
    watcher.watch(&current_dir, RecursiveMode::Recursive).unwrap();

    for event in rx {
        let event = event.unwrap();
        println!("Change detected: {:?}", event);
        if let Some(path) = event.paths.first() {
            if path.extension().map_or(false, |ext| ext == "lua") {
                let file_path = path.to_str().unwrap().to_string();

                let now = Instant::now();
                // 检查缓存中的时间
                let should_process = cache.get(&file_path).map_or(true, |last_time| {
                    now.duration_since(last_time) >= time_interval
                });
                if should_process {
                    // 更新缓存中的时间
                    cache.insert(file_path.clone(), now);
                    // 处理文件修改事件
                    info!("接收到文件变动，间隔1S触发处理：{:?}",event);
                    handle_event(event);
                }
            }
        }
    }
}


fn handle_event(event: Event) {
    match event.kind {
        notify::EventKind::Create(_) | notify::EventKind::Modify(_) => {
            if let Some(path) = event.paths.first() {
                if path.extension().map_or(false, |ext| ext == "lua") {
                    update_ts_file(path);
                }
            }
        }
        notify::EventKind::Remove(_) => {
            if let Some(path) = event.paths.first() {
                if let Some(ts_path) = lua_to_ts_path(path) {
                    fs::remove_file(ts_path).unwrap_or_else(|e| println!("Failed to delete ts file: {}", e));
                }
            }
        }
        notify::EventKind::Modify(_) => {
            if let Some(path) = event.paths.first() {
                update_ts_file(path);
            }
        }
        _ => {}
    }
}


fn update_ts_file(lua_path: &Path) {
    info!("update_ts_file: {:?}",lua_path);
    let content = fs::read_to_string(lua_path).unwrap();
    let functions = parse_lua_functions(&content, lua_path);
    let lua_file_path = get_lua_file_relative_path(lua_path.to_str().unwrap());
    let ts_template = TsTemplate { lua_file_path, functions };
    let ts_content = ts_template.render().unwrap();
    let ts_path = lua_to_ts_path(lua_path).unwrap();
    write_to_file(&ts_path, &ts_content)
}

fn write_to_file(ts_path: &PathBuf, ts_content: &str) {
    // 检查文件是否存在
    let exists = ts_path.exists();

    // 创建或截断文件
    let mut file = match File::create(ts_path) {
        Ok(file) => file,
        Err(e) => {
            eprintln!("Failed to create file {}: {}", ts_path.display(), e);
            return;
        }
    };

    // 写入内容
    if let Err(e) = file.write_all(ts_content.as_bytes()) {
        eprintln!("Failed to write to file {}: {}", ts_path.display(), e);
    } else if exists {
        println!("Updated file {}", ts_path.display());
    } else {
        println!("Created new file {}", ts_path.display());
    }
}

fn lua_to_ts_path(lua_path: &Path) -> Option<PathBuf> {
    lua_path.with_extension("ts").file_name().map(PathBuf::from)
}

fn parse_lua_functions(content: &str, lua_path: &Path) -> Vec<String> {
    // 匹配 "local function" 后跟一个或多个空格，再跟以 "pub_" 开头的函数名和参数列表
    let re = Regex::new(r"local\s+function\s+(pub_\w+)\s*\(\s*\)").unwrap();
    re.captures_iter(content)
        .map(|cap| {
            // 提取函数名和计算相对路径
            cap[1].to_string()
        })
        .collect()
}


fn get_lua_file_relative_path<'a>(absolute_path: &str) -> String {
    // 获取当前工作目录
    let current_dir = env::current_dir().unwrap();
    let path_str = current_dir.as_path().to_str().unwrap();
    // 去除前缀以获取相对路径
    return absolute_path.strip_prefix(path_str).unwrap().to_string();
}


fn lua_path_to_relative(lua_path: &Path) -> String {
    // 将给定的全路径转换为相对于 "/lua-script" 的相对路径
    // 使用 `strip_prefix` 方法尝试移除基路径前缀
    match lua_path.strip_prefix("/lua-script") {
        Ok(rel_path) => {
            // 将 Path 转换为字符串，并替换所有反斜杠为正斜杠，确保路径格式在所有系统下一致
            rel_path.to_str().unwrap_or_default().replace("\\", "/")
        }
        Err(_) => {
            // 如果路径前缀不匹配或其他问题，返回空字符串或处理错误
            String::new()
        }
    }
}