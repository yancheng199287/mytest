import { callLuaFunction } from './luaLoader';

const my_lua_functions = {
  
  pub_say_hello: (...args: any[]) => callLuaFunction('', 'pub_say_hello', ...args),
  
  pub_login: (...args: any[]) => callLuaFunction('', 'pub_login', ...args),
  
  pub_logout: (...args: any[]) => callLuaFunction('', 'pub_logout', ...args),
  
};

export default my_lua_functions;