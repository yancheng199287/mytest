import { callLuaFunction } from './luaLoader';

const  lua_absolute_path = '\lua-script\test.lua';
const my_lua_functions = {
  
  pub_say_hello: (...args: any[]) => callLuaFunction(lua_absolute_path, 'pub_say_hello', ...args),
  
  pub_login: (...args: any[]) => callLuaFunction(lua_absolute_path, 'pub_login', ...args),
  
  pub_logout: (...args: any[]) => callLuaFunction(lua_absolute_path, 'pub_logout', ...args),
  
  pub_test1213: (...args: any[]) => callLuaFunction(lua_absolute_path, 'pub_test1213', ...args),
  
  pub_ass: (...args: any[]) => callLuaFunction(lua_absolute_path, 'pub_ass', ...args),
  
  pub_aasedaass: (...args: any[]) => callLuaFunction(lua_absolute_path, 'pub_aasedaass', ...args),
  
};
export default my_lua_functions;