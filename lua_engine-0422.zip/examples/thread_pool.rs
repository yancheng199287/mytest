use std::cell::RefCell;
use rayon::ThreadPoolBuilder;
use crossbeam_channel::{bounded, Receiver, Sender, TrySendError};
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::Duration;

// 任务结构
struct Task {
    name: String,
    data: i32,
}

impl Task {
    fn new(name: &str, data: i32) -> Self {
        Task {
            name: name.to_string(),
            data,
        }
    }

    fn execute(&self) -> i32 {
        // 模拟任务处理
        thread::sleep(Duration::from_secs(1));
        self.data * 2
    }
}

// 任务调度器
struct TaskScheduler {
    thread_pool: rayon::ThreadPool,
    task_sender: Sender<Task>,
    task_receiver: Receiver<Task>,
    notification_sender: Sender<String>,
}

impl TaskScheduler {
    fn new(max_threads: usize, max_queue_size: usize) -> Self {
        // 创建线程池和任务队列
        let (task_sender, task_receiver) = bounded(max_queue_size);
        let (notification_sender, notification_receiver) = bounded(max_queue_size);

        let thread_pool = ThreadPoolBuilder::new()
            .num_threads(max_threads)
            .build()
            .expect("无法创建线程池");

        // 启动通知处理线程
        thread::spawn(move || {
            while let Ok(notification) = notification_receiver.recv() {
                println!("任务完成: {}", notification);
            }
        });

        TaskScheduler {
            thread_pool,
            task_sender,
            task_receiver,
            notification_sender,
        }
    }

    fn try_add_task(&self, task: Task) {
        match self.task_sender.try_send(task) {
            Ok(_) => (),
            Err(TrySendError::Full(_)) => {
                println!("任务队列已满，丢弃任务");
            }
            Err(e) => {
                println!("无法添加任务: {:?}", e);
            }
        }
    }

    fn start(&self) {
        let task_receiver = Arc::new(Mutex::new(self.task_receiver.clone()));
        let notification_sender = self.notification_sender.clone();

        self.thread_pool.install(|| {
            rayon::scope(|s| {
                for _ in 0..self.thread_pool.current_num_threads() {

                    let task_receiver = task_receiver.clone();
                    let notification_sender = notification_sender.clone();

                    // 定义线程本地状态
                    thread_local! {
                        static IS_INITIALIZED: RefCell<bool> = RefCell::new(false);
                    }

                    s.spawn(move |_| {
                        // 线程初始化，只执行一次
                        IS_INITIALIZED.with(|initialized| {
                            if !*initialized.borrow() {
                                println!("初始化线程");
                                *initialized.borrow_mut() = true;
                            }
                        });

                        while let Ok(task) = task_receiver.lock().unwrap().recv() {
                            let result = task.execute();
                            let notification = format!("任务 {} 完成，结果是 {}", task.name, result);
                            notification_sender.send(notification).expect("发送通知失败");
                        }
                    });
                }
            });
        });
    }
}

// 主函数
fn main() {
    let scheduler = TaskScheduler::new(4, 10); // 4个线程，10个任务队列容量

    // 使用 try_add_task 避免阻塞
    for i in 0..15 {
        let task = Task::new(&format!("任务_{}", i), i);
        scheduler.try_add_task(task);
    }


    scheduler.start();

    // 等待所有任务完成
    thread::sleep(Duration::from_secs(10));
}
