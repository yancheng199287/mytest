use std::sync::{Arc, MutexGuard};
use std::time::Duration;
use chrono::{DateTime, Local};
use mlua::{Lua, MetaMethod, Table, UserData, Variadic};
use mlua::prelude::{LuaFunction, LuaResult, LuaTable, LuaValue};
use crate::engine::lua_engine::LuaEngine;
use crate::set_global_module;


pub fn log(lua: &Lua, vec_content: Variadic<LuaValue>) -> mlua::Result<()> {
    let str_content = vec_content
        .iter()
        .clone()
        .map(|item| {
            item.to_string().unwrap()
        })
        .collect::<Vec<_>>()
        .join(" ");
    let now: DateTime<Local> = Local::now();
    println!("{} {}", now.format("%Y-%m-%d %H:%M:%S%.3f"), str_content);
    Ok(())
}


pub async fn sleep(lua: &Lua, (func, ms): (LuaFunction<'_>, u64)) -> mlua::Result<()> {
    tokio::time::sleep(Duration::from_millis(ms)).await;
    func.call::<_, ()>(()).unwrap();
    Ok(())
}