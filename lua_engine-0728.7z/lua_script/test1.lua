config_module = require("module_config")
local config = config_module.new()
config:set_string("name", "config test")
config:set_bool("is_ok", true)
config:set_integer("age", 18)
config:set_float("weight", 55.63)
config:set_null("desc")
local table = {"小明","小刚","小花"}
config:set_list_string("arrayName",table)

local arrayName = config:get_list_string("arrayName")
log("arrayName==>",arrayName)
if arrayName then
    for i = 1, #arrayName do
        log(i,"==>",arrayName[i])
    end
end


local is_contain = config:contain_key("name")
log("is_contain:", is_contain)

config:remove_key("name1")

config:save()


