local function log(data)
    print("this is a test log fn")
    print(data)
end

log("Hello world!")

