use std::fs::{File, OpenOptions};
use std::io::{Read, Write};
use std::collections::HashMap;
use mlua::{Integer, Lua, UserData, UserDataFields, UserDataMethods};
use mlua::prelude::{LuaResult, LuaTable};
use serde_json::{Value};
use num_traits::cast::ToPrimitive;
use crate::{LuaEngine, set_global_module};

#[derive(Debug)]
pub struct Config {
    file_name: String,
    data: HashMap<String, Value>,
}

pub fn new(lua: &Lua, _: ()) -> mlua::Result<Config> {
    let app_name: String = lua.globals().get("APP_NAME").unwrap();
    let mut file_name = "resource/".to_string();
    file_name.push_str(&app_name);
    file_name.push_str(".json");
    let mut file = OpenOptions::new()
        .read(true)
        .write(true)
        .create(true)
        .open(file_name.clone()).unwrap();
    let mut content = String::new();
    file.read_to_string(&mut content).unwrap();
    let mut data: HashMap<String, Value> = HashMap::default();
    if !content.is_empty() {
        data = serde_json::from_str(&content).unwrap();
    }
    Ok(Config {
        file_name,
        data,
    })
}

impl Config {
    fn set(&mut self, key: String, value: Value) {
        self.data.insert(key.to_string(), value);
    }
    fn get(&mut self, key: String) -> Option<Value> {
        let option_value = self.data.get(&key);
        if option_value.is_none() {
            return None;
        }
        let value = option_value.unwrap();
        return Some(value.clone());
    }
    pub fn set_string(&mut self, key: String, value: String) -> LuaResult<()> {
        self.set(key, Value::String(value));
        Ok(())
    }
    pub fn get_string(&mut self, key: String) -> Option<String> {
        let value = self.get(key);
        if let Some(v) = value {
            let aa = v.as_str().unwrap();
            return Some(aa.to_string());
        }
        None
    }

    pub fn put_list_string(&mut self, key: String, value: Vec<Value>) {
        self.data.insert(key, Value::Array(value));
    }

    pub fn get_list_string(&mut self, key: String) -> Option<Vec<Value>> {
        let value = self.get(key);
        if let Some(v) = value {
            let aa = v.as_array().unwrap().clone();
            return Some(aa);
        }
        None
    }
    pub fn set_integer(&mut self, key: String, value: Integer) {
        self.set(key, Value::Number(serde_json::value::Number::from(value.to_i64().unwrap())));
    }
    pub fn set_float(&mut self, key: String, value: mlua::Number) {
        let str = value.to_string();
        let ff = str.parse::<f64>().unwrap();
        let ff = serde_json::value::Number::from_f64(ff).unwrap();
        self.set(key, Value::Number(ff));
    }
    pub fn set_bool(&mut self, key: String, value: bool) {
        self.set(key, Value::Bool(value));
    }
    pub fn set_null(&mut self, key: String) {
        self.set(key, Value::Null);
    }
    pub fn contain_key(&mut self, key: String) -> bool {
        self.data.contains_key(&key)
    }
    pub fn remove_key(&mut self, key: String) {
        self.data.remove(&key);
    }
    pub fn clear(&mut self) {
        self.data.clear();
    }
    pub fn save(&mut self) -> LuaResult<()> {
        let json = serde_json::to_string_pretty(&self.data).unwrap();
        let mut file = File::create(&self.file_name).unwrap();
        file.write_all(json.as_bytes()).unwrap();
        Ok(())
    }
}

impl UserData for Config {
    fn add_fields<'lua, F: UserDataFields<'lua, Self>>(fields: &mut F) {}
    fn add_methods<'lua, M: UserDataMethods<'lua, Self>>(methods: &mut M) {
        methods.add_method_mut("set_string", |lua, this, (key, value): (String, String)| {
            this.set_string(key, value).unwrap();
            Ok(())
        });
        methods.add_method_mut("get_string", |lua, this, (key): (String)| {
            let str_option = this.get_string(key);
            if let Some(v) = str_option {
                let lua_str = lua.create_string(v).unwrap();
                return Ok(lua_str);
            }
            let lua_str = lua.create_string("empty").unwrap();
            Ok(lua_str)
        });

        methods.add_method_mut("set_string", |lua, this, (key, value): (String, String)| {
            this.set_string(key, value).unwrap();
            Ok(())
        });

        methods.add_method_mut("set_list_string", |lua, this, (key, value): (String, LuaTable)| {
            let mut array_value: Vec<Value> = Vec::new();
            for pair in value.pairs::<String, String>() {
                let (_, value) = pair.unwrap();
                array_value.push(Value::String(value))
            }
            this.put_list_string(key, array_value);
            Ok(())
        });

        methods.add_method_mut("get_list_string", |lua, this, (key): (String)| {
            let str_option = this.get_list_string(key);
            if let Some(v) = str_option {
                let arr = lua.create_table().unwrap();
                for (index, value) in v.iter().enumerate() {
                    let str_value = value.as_str().unwrap();
                    arr.set(index + 1, str_value).unwrap();
                }
                return Ok(mlua::Value::Table(arr));
            }
            /// 返回一个nil，不存在的值，这样不会报错
            Ok(mlua::Value::Nil)
        });


        methods.add_method_mut("set_integer", |lua, this, (key, value): (String, Integer)| {
            this.set_integer(key, value);
            Ok(())
        });
        methods.add_method_mut("set_float", |lua, this, (key, value): (String, mlua::Number)| {
            this.set_float(key, value);
            Ok(())
        });
        methods.add_method_mut("set_bool", |lua, this, (key, value): (String, bool)| {
            this.set_bool(key, value);
            Ok(())
        });
        methods.add_method_mut("set_null", |lua, this, (key): (String)| {
            this.set_null(key);
            Ok(())
        });

        methods.add_method_mut("contain_key", |lua, this, (key): (String)| {
            Ok(this.contain_key(key))
        });


        methods.add_method_mut("remove_key", |lua, this, key: String| {
            this.remove_key(key);
            Ok(())
        });

        methods.add_method_mut("clear", |lua, this, _: ()| {
            this.clear();
            Ok(())
        });

        methods.add_method_mut("save", |lua, this, _: ()| {
            this.save().unwrap();
            Ok(())
        });
    }
}


/// 注册成lua中一个模块，可以通过require("module_config")来使用
/// 其中 new 函数可以创建一个Config对象，然后就可以基于这个对象调用我定义的方法
pub fn register_lua_module1(lua_engine: &LuaEngine) {
    set_global_module!(lua_engine,"module_config",
        [],
        [("new", new)],
        []
        );
}

