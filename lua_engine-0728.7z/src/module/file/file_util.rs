use std::io::{Read, Write};
use std::sync::Arc;
use crate::engine::lua_engine::LuaEngine;
use crate::set_global_module;
use mlua::{Error, Lua, Result as LuaResult};
use mlua::Error::ExternalError;


/// 判断文件是否存在
pub fn file_exists(lua: &Lua, path: String) -> LuaResult<bool> {
    let exist = std::path::Path::new(&path).exists();
    Ok(exist)
}

/// 创建文件或文件夹
pub fn create(lua: &Lua, (path, recursive): (String, bool)) -> LuaResult<()> {
    if recursive {
        std::fs::create_dir_all(path).map_err(|error| ExternalError(Arc::new(error)))
    } else {
        let result = std::fs::File::create(path);
        match result {
            Ok(_) => Ok(()),
            Err(error) => Err(ExternalError(Arc::new(error)))
        }
    }
}

/// 读取文件内容
pub fn read(lua: &Lua, path: String) -> LuaResult<String> {
    let mut file = std::fs::File::open(path)?;
    let mut content = String::new();
    file.read_to_string(&mut content)?;
    Ok(content)
}

/// 删除文件或目录
pub fn delete(lua: &Lua, path: String) -> LuaResult<()> {
    if std::path::Path::new(&path).is_dir() {
        std::fs::remove_dir_all(path).map_err(|error| ExternalError(Arc::new(error)))
    } else {
        std::fs::remove_file(path).map_err(|error| ExternalError(Arc::new(error)))
    }
}

/// 修改文件内容并保存
pub fn write(lua: &Lua, (path, content): (String, String)) -> LuaResult<()> {
    let mut file = std::fs::OpenOptions::new().write(true).truncate(true).create(true).open(path).map_err(|error| ExternalError(Arc::new(error)));
    match file {
        Ok(mut file) => {
            file.write_all(content.as_bytes()).map_err(|error| ExternalError(Arc::new(error)))
        }
        Err(error) => Err(ExternalError(Arc::new(error)))
    }
}

pub fn copy_file(lua: &Lua, (src, dest): (String, String)) -> LuaResult<()> {
    let result = std::fs::copy(src, dest).map_err(|error| ExternalError(Arc::new(error)));
    if result.is_err() {
        return Err(result.unwrap_err());
    }
    Ok(())
}

/// 复制文件或目录
pub fn copy_dir(lua: &Lua, (src, dest): (String, String)) -> LuaResult<()> {
    let src_path = std::path::Path::new(&src);
    let dest_path = std::path::Path::new(&dest);
    if src_path.is_dir() {
        let result = std::fs::create_dir_all(&dest).map_err(|error| ExternalError(Arc::new(error)));
        if result.is_err() {
            return result;
        }
        for entry in std::fs::read_dir(src_path).map_err(|error| ExternalError(Arc::new(error)))? {
            let entry = entry?;
            let entry_path = entry.path();
            let file_name = entry.file_name();

            let mut dest_path_buf = std::path::PathBuf::from(dest_path);
            dest_path_buf.push(file_name);

            let entry_path_str = entry_path.to_str().unwrap().to_string();
            let dest_path_buf_str = dest_path_buf.to_str().unwrap().to_string();
            if entry_path.is_dir() {
                let result = copy_dir(lua, (entry_path_str, dest_path_buf_str));
                if result.is_err() {
                    return result;
                }
            } else {
                let result = copy_file(lua, (entry_path_str, dest_path_buf_str));
                if result.is_err() {
                    return result;
                }
            }
        }
    } else {
        return copy_file(lua, (src, dest));
    }
    Ok(())
}


pub fn register_lua_module1(lua_engine: &LuaEngine) {
    set_global_module!(lua_engine,"file_util",
        [],
        [("file_exists", file_exists),("create", create),("read", read),("delete", delete),("write", write),("copy_file",copy_file),("copy_dir", copy_dir)],
        []
        );
}


