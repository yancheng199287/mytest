use std::any::Any;
use std::future::Future;
use std::pin::Pin;
use std::time::Duration;
use async_trait::async_trait;
use tokio::time::sleep;
use crate::module::reuse::long_object::LongObject;
use crate::module::reuse::long_object_fatcory::LongObjectFactory;
use crate::task::lua_script_error::LuaScriptError;

pub struct DbPool {
    connection_string: String,
}

impl DbPool {
    pub fn new(connection_string: &str) -> Self {
        DbPool {
            connection_string: connection_string.to_string(),
        }
    }

    pub async fn execute_query(&self, query: &str) -> Result<(), Box<dyn std::error::Error>> {
        println!("执行SQL查询: {}", query);
        Ok(())
    }
}

#[async_trait]
impl LongObject for DbPool {
    async fn init(&mut self) -> Result<(), LuaScriptError> {
        sleep(Duration::from_secs(1)).await;
        // 这里是你的异步代码
        println!("进行数据库链接... {}", self.connection_string);
        Ok(())
    }

    fn as_any(&self) -> &dyn Any {
        self
    }

    async fn destroy(&mut self) {
        sleep(Duration::from_secs(1)).await;
        // 这里是你的异步代码
        println!("进行数据库销毁操作...");
    }
}


#[tokio::test]
async fn main1() {
    let factory = LongObjectFactory::new();

    // 创建一个数据库连接池
    factory.create_object("app1", || DbPool::new("postgres://user:password@localhost/dbname")).await;

    // 获取数据库连接池并使用
    if let Some(pool) = factory.get_object::<DbPool>("app1") {
        // 使用连接执行查询
        let sql = "SELECT * FROM users";
        let mysql_pool = pool.read().unwrap();
        let aa = mysql_pool.as_any().downcast_ref::<DbPool>().unwrap();
        let result = aa.execute_query(sql).await;
    }
    // 销毁所有长对象
    factory.destroy_all("app1").await;
}


