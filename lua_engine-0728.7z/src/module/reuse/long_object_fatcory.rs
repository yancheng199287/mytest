use dashmap::DashMap;
use std::sync::{Arc, RwLock};
use std::any::TypeId;
use std::ops::Deref;
use crate::module::reuse::long_object::LongObject;


pub struct LongObjectGuard<T: LongObject> {
    inner: Arc<RwLock<T>>,
    guard: std::sync::RwLockReadGuard<'static, dyn LongObject>,
}

impl<T: LongObject> Deref for LongObjectGuard<T> {
    type Target = T;

    fn deref(&self) -> &Self::Target {
        self.guard.as_any().downcast_ref::<T>().unwrap()
    }
}



pub struct LongObjectFactory {
    objects: DashMap<String, DashMap<TypeId, Arc<RwLock<dyn LongObject>>>>,
}

impl LongObjectFactory {
    pub fn new() -> Self {
        LongObjectFactory {
            objects: DashMap::new(),
        }
    }
    pub async fn create_object<T: LongObject + 'static>(&self, appid: &str, creator: impl Fn() -> T) {
        let app_objects = self.objects.entry(appid.to_string()).or_insert_with(DashMap::new);
        let mut object = creator();
        object.init().await.unwrap();
        app_objects.insert(TypeId::of::<T>(), Arc::new(RwLock::new(object)));
    }

    pub fn get_object<T: LongObject + 'static>(&self, appid: &str) -> Option<Arc<RwLock<dyn LongObject>>> {
        if let Some(app_objects) = self.objects.get(appid) {
            let value = app_objects.get(&TypeId::of::<T>())
                .map(|object| {
                    let aa = object.value().clone();
                    return aa;
                });
            if value.is_none() {
                return None;
            }
            return value;
        }
        return None;
    }


    pub async fn destroy_all(&self, appid: &str) {
        if let Some(app_objects) = self.objects.remove(appid) {
            let values = app_objects.1;
            let values_ref = &values;
            for value in values_ref {
                let mut obj = value.write().unwrap();
                obj.destroy().await;
            }
            values.clear();
        }
    }
}
