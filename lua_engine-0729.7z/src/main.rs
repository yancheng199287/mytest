use std::fs::{File, OpenOptions};
use std::io::Read;
use std::thread;
use std::time::Duration;
use rand::{Rng, thread_rng};
use crate::engine::lua_engine::LuaEngine;
use crate::task::lua_script_task::LuaScriptTask;

mod engine;
mod module;
mod task;
mod util;


fn read_file(file_name: &str) -> String {
    let mut script_dir = String::from("./lua_script/");
    script_dir.push_str(file_name);
    let mut file = OpenOptions::new()
        .read(true)
        .write(true)
        .create(false)
        .open(script_dir).unwrap();
    let mut content = String::new();
    file.read_to_string(&mut content).unwrap();
    return content;
}

#[tokio::main]
async fn main() {
    let lua_engine = LuaEngine::new();
    let file_name_vec = ["test11", "test22"];
    let suffix_name = ".lua";
    for i in 0..file_name_vec.len() {
        let file_name = file_name_vec[i];
        let file_name = file_name.to_string() + suffix_name;
        let file_content = read_file(file_name.as_str());
        let result = lua_engine.async_exec_script(file_content).await.unwrap();
        println!("execute script result:{:?}", result);
    }
}

fn main1() {
    let scheduler = task::scheduler::LuaTaskScheduler::new(3, 50);

    let sender = scheduler.task_sender.clone();


    std::thread::spawn(move || {
        let mut random = thread_rng();
        // 使用 try_add_task 避免阻塞
        for i in 0..30 {
            let source = r#"
            function hello()
                 log("hello, I am from lua, 你知道了吗","多个参数也是可以的",100,99.9999)
            end
            sleep(hello,1800)
            sleep(function()
                log("hello, I am from lua, 你知道了吗")
            end, 1500)
        "#;
            ///thread::sleep(Duration::from_secs(random.gen_range(1..2)));
            let task = LuaScriptTask::new(i, source.to_string());
            sender.try_send(task).expect("TODO: panic message");
        }
    });

    scheduler.start();
}