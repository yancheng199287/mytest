use std::time::Duration;
use chrono::{DateTime, Local};
use mlua::{Lua, MetaMethod, Table, UserData, Variadic};
use mlua::prelude::{LuaFunction, LuaResult, LuaTable, LuaValue};


pub fn log(lua: &Lua, vec_content: Variadic<LuaValue>) -> mlua::Result<()> {
    let str_content = vec_content
        .iter()
        .clone()
        .map(|item| {
            item.to_string().unwrap()
        })
        .collect::<Vec<_>>()
        .join(" ");
    let now: DateTime<Local> = Local::now();
    println!("{} {}", now.format("%Y-%m-%d %H:%M:%S%.3f"), str_content);
    Ok(())
}


pub async fn sleep(lua: &Lua, (func, ms): (LuaFunction<'_>, u64)) -> mlua::Result<()> {
    tokio::time::sleep(Duration::from_millis(ms)).await;
    func.call::<_, ()>(()).unwrap();
    Ok(())
}


/// 定时执行的函数，延迟执行的毫秒数，间隔的毫秒数，最大执行次数，最大执行次数如果是-1代表永远执行
pub async fn start_timer(lua: &Lua, (func, delay_ms, interval_ms, max_executions): (LuaFunction<'_>, u64, u64, i32)) -> mlua::Result<()> {
    let delay = Duration::from_millis(delay_ms);
    tokio::time::sleep(delay).await;
    let interval = tokio::time::interval(Duration::from_millis(interval_ms));
    let mut executions = 0;
    tokio::pin!(interval);
    while let _ = interval.tick().await {
        if max_executions != -1 && executions >= max_executions {
            break;
        }
        func.call::<_, ()>(()).unwrap();
        executions += 1;
    }
    Ok(())
}