use std::any::Any;
use std::future::Future;
use std::pin::Pin;
use async_trait::async_trait;
use crate::task::lua_script_error::LuaScriptError;


#[async_trait]
pub trait LongObject: Any + Send + Sync {
    async fn init(&mut self);

    // 添加 as_any 方法
    fn as_any(&self) -> &dyn Any;

    async fn destroy(&mut self);
}
