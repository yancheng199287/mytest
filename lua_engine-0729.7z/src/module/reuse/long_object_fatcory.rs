use dashmap::DashMap;
use std::sync::{Arc};
use std::any::TypeId;
use idgenerator::IdInstance;
use log::info;
use tokio::sync::RwLock;
use crate::module::reuse::long_object::LongObject;


pub struct LongObjectFactory {
    objects: DashMap<String, DashMap<i64, (TypeId, Arc<RwLock<dyn LongObject>>)>>,
    //objects: DashMap<String, DashMap<TypeId, Arc<RwLock<dyn LongObject>>>>,
}

impl LongObjectFactory {
    pub fn new() -> Self {
        LongObjectFactory {
            objects: DashMap::new(),
        }
    }
    pub async fn create_object<T: LongObject + 'static>(&self, appid: &str, mut object: T) -> i64 {
        object.init().await;
        let type_map = self.objects.entry(appid.to_string()).or_insert_with(DashMap::new);
        let object_id = IdInstance::next_id();
        type_map.insert(object_id, (TypeId::of::<T>(), Arc::new(RwLock::new(object))));
        return object_id;
    }

    pub fn get_object<T: LongObject + 'static>(&self, appid: &str, object_id: i64) -> Option<Arc<RwLock<T>>> {
        if let Some(app_objects) = self.objects.get(appid) {
            if let Some(object) = app_objects.get(&object_id) {
                if object.0 == TypeId::of::<T>() {
                    let value = object.1.clone();
                    // 将 object 转换为原始指针
                    let object = Arc::into_raw(value);
                    // 将原始指针转换为我们实际的实现目标类型
                    let object = unsafe { Arc::from_raw(object as *const RwLock<T>) };
                    return Some(object);
                }
            }
        }
        return None;
    }


    pub async fn destroy_app_object(&self, appid: &str) {
        if let Some(app_objects) = self.objects.remove(appid) {
            let values = app_objects.1;
            let values_ref = &values;
            for value in values_ref {
                let mut obj = value.1.write().await;
                obj.destroy().await;
            }
            values.clear();
            println!("destroy app long object,appid Key: {}", appid);
        }
    }

    pub async fn destroy_all_app_object(&self) {
        // 迭代获取所有的键
        // 迭代获取所有的键，并收集到一个 Vec 中
        let keys: Vec<String> = self.objects.iter().map(|entry| entry.key().clone()).collect();
        // 打印所有的键
        for key in keys {
            self.destroy_app_object(key.as_str()).await;
        }
        self.objects.clear();
    }
}
