use mlua::{Lua, UserData, UserDataFields, UserDataMethods, Result as LuaResult, Table, Error};
use chrono::{Datelike, DateTime, FixedOffset, Local, Timelike, TimeZone};
use crate::engine::lua_engine::LuaEngine;
use crate::set_global_module;

#[derive(Debug)]
pub struct Time {
    // 可以根据需要添加其他字段
}

pub fn parse_datetime(time: &str) -> mlua::Result<DateTime<FixedOffset>> {
    DateTime::parse_from_rfc3339(time).map_err(|_| mlua::Error::external("Invalid time format"))
}

pub fn new(lua: &Lua, _: ()) -> mlua::Result<Time> {
    // 可以在这里进行时间对象的初始化，如果有需要的话
    let time = Time {};
    Ok(time)
}

impl Time {
    pub fn current_time(&self) -> DateTime<Local> {
        let current_time = Local::now();
        current_time
    }

    pub fn format_time(&self, time: &str, format: &str) -> LuaResult<String> {
        let parsed_time = parse_datetime(time)?;
        Ok(parsed_time.format(format).to_string())
    }

    pub fn parse_time(&self, time_str: &str) -> LuaResult<DateTime<Local>> {
        let parsed_time = parse_datetime(time_str)?;
        Ok(Local.from_utc_datetime(&parsed_time.naive_utc()))
    }

    pub fn compare_time(&self, time_str1: &str, time_str2: &str) -> LuaResult<i64> {
        let parsed_time1 = parse_datetime(time_str1)?;
        let parsed_time2 = parse_datetime(time_str2)?;
        Ok((parsed_time1 - parsed_time2).num_seconds())
    }

    pub fn add_time(&self, time_str: &str, years: i32, months: i32, days: i32, hours: i32, minutes: i32, seconds: i32) -> LuaResult<String> {
        let parsed_time = parse_datetime(time_str)?;
        let new_time = parsed_time
            .checked_add_signed(chrono::Duration::days(days as i64))
            .and_then(|dt| dt.checked_add_signed(chrono::Duration::hours(hours as i64)))
            .and_then(|dt| dt.checked_add_signed(chrono::Duration::minutes(minutes as i64)))
            .and_then(|dt| dt.checked_add_signed(chrono::Duration::seconds(seconds as i64)))
            .and_then(|dt| dt.checked_add_signed(chrono::Duration::days(months as i64 * 30))) // Simplified month to days conversion
            .and_then(|dt| dt.checked_add_signed(chrono::Duration::days(years as i64 * 365))); // Simplified year to days conversion

        match new_time {
            Some(time) => Ok(time.to_rfc3339()),
            None => Err(mlua::Error::external("Failed to add time")),
        }
    }

    pub fn get_time_info(&self, time_str: &str) -> LuaResult<DateTime<Local>> {
        let parsed_time = parse_datetime(time_str)?;
        Ok(Local.from_utc_datetime(&parsed_time.naive_utc()))
    }

    pub fn get_timestamp(&self, time_str: &str) -> LuaResult<i64> {
        let parsed_time = parse_datetime(time_str)?;
        Ok(parsed_time.timestamp())
    }

    pub fn is_within_interval(&self, time_str: &str, start_time_str: &str, end_time_str: &str) -> LuaResult<bool> {
        let parsed_time = parse_datetime(time_str)?;
        let start = parse_datetime(start_time_str)?;
        let end = parse_datetime(end_time_str)?;
        Ok(parsed_time >= start && parsed_time <= end)
    }

    // 可以根据需要添加其他方法
}

impl UserData for Time {
    fn add_fields<'lua, F: UserDataFields<'lua, Self>>(fields: &mut F) {}

    fn add_methods<'lua, M: UserDataMethods<'lua, Self>>(methods: &mut M) {
        methods.add_method("current_time", |lua, this, _: ()| {
            let datetime = this.current_time();
            let table = lua.create_table()?;
            convert_datetime_to_table(table, datetime)
        });

        methods.add_method("format_time", |lua, this, (time, format): (String, String)| {
            this.format_time(&time, &format)
        });

        methods.add_method("parse_time", |lua, this, time: String| {
            let local_time = this.parse_time(&time)?;
            let table = lua.create_table()?;
            convert_datetime_to_table(table, local_time)
        });

        methods.add_method("compare_time", |_, this, (time1, time2): (String, String)| {
            this.compare_time(&time1, &time2)
        });

        methods.add_method("add_time", |_, this, (time, years, months, days, hours, minutes, seconds): (String, i32, i32, i32, i32, i32, i32)| {
            this.add_time(&time, years, months, days, hours, minutes, seconds)
        });

        methods.add_method("get_time_info", |lua, this, time: String| {
            let local_time = this.get_time_info(&time)?;
            let table = lua.create_table()?;
            convert_datetime_to_table(table, local_time)
        });

        methods.add_method("get_timestamp", |_, this, time: String| {
            this.get_timestamp(&time)
        });

        methods.add_method("is_within_interval", |_, this, (time, start_time, end_time): (String, String, String)| {
            this.is_within_interval(&time, &start_time, &end_time)
        });
    }
}


fn convert_datetime_to_table(table: Table, dt: DateTime<Local>) -> mlua::Result<Table> {
    table.set("year", dt.year()).unwrap();
    table.set("month", dt.month()).unwrap();
    table.set("day", dt.day()).unwrap();
    table.set("hour", dt.hour()).unwrap();
    table.set("minute", dt.minute()).unwrap();
    table.set("second", dt.second()).unwrap();
    table.set("millisecond", dt.timestamp_millis()).unwrap();
    table.set("weekday", dt.weekday().num_days_from_monday() + 1).unwrap(); // Convert from 0-based to 1-based
    Ok(table)
}


pub fn register_lua_module1(lua_engine: &LuaEngine) {
    set_global_module!(lua_engine,"module_time",
        [],
        [("new", new)],
        []
        );
}
