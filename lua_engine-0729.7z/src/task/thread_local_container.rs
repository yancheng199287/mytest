use std::cell::RefCell;
use tokio::runtime::Runtime;
use crate::engine::lua_engine::LuaEngine;



pub struct ThreadContainer {
    pub   lua_engine: LuaEngine,
    pub  runtime: Runtime,
}

impl ThreadContainer {

    pub(crate) fn new () -> Self {
        let lua_engine = LuaEngine::new();
        let runtime = tokio::runtime::Builder::new_current_thread().enable_all().build().unwrap();
        ThreadContainer {
            lua_engine,
            runtime,
        }
    }

}