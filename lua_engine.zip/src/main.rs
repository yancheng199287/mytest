use std::thread;
use std::time::Duration;
use crate::task::lua_script_task::LuaScriptTask;

mod engine;
mod module;
mod task;


fn main() {
    let scheduler = task::scheduler::LuaTaskScheduler::new(3, 100);
    // 使用 try_add_task 避免阻塞
    for i in 0..15 {
        let source = r#"
          print(utf8.len("我在"))
          print("Hello world! 我 来自 lua！")
        "#;
        let task = LuaScriptTask::new(i, source.to_string());
        scheduler.try_add_task(task);
    }
    scheduler.start();
    // 等待所有任务完成
    thread::sleep(Duration::from_secs(10));
}