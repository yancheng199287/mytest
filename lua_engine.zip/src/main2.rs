/*use std::sync::Arc;
use std::thread;
use std::time::Duration;
use crate::engine::lua_engine::LuaEngine;

mod engine;
mod module;
mod task;

#[tokio::main(flavor = "multi_thread", worker_threads = 10)]
async fn main() -> mlua::Result<()> {
    log4rs::init_file("config/log4rs.yaml", Default::default()).unwrap();

    let lua_engine = Arc::new(LuaEngine::new());
    // 初始化lua引擎参数，设置一些自定义参数，如模块加载
    lua_engine.init_lua_engine(|x| {
        let lua_module_path = "C:\\Program Files (x86)\\WinLua\\LuaRocks\\bin\\lua\\?.lua;C:\\Program Files (x86)\\WinLua\\LuaRocks\\bin\\lua\\?\\init.lua;C:\\Program Files (x86)\\WinLua\\LuaRocks\\bin\\?.lua;C:\\Program Files (x86)\\WinLua\\LuaRocks\\bin\\?\\init.lua;C:\\Program Files (x86)\\WinLua\\LuaRocks\\bin\\..\\share\\lua\\5.4\\?.lua;C:\\Program Files (x86)\\WinLua\\LuaRocks\\bin\\..\\share\\lua\\5.4\\?\\init.lua;.\\?.lua;.\\?\\init.lua;C:\\Users\\yancheng\\AppData\\Roaming\\luarocks\\share\\lua\\5.4\\?.lua;C:\\Users\\yancheng\\AppData\\Roaming\\luarocks\\share\\lua\\5.4\\?\\init.lua;D:\\dev-software\\Winlua\\lua\\5.4\\share\\lua\\5.4\\?.lua;D:\\dev-software\\Winlua\\lua\\5.4\\share\\lua\\5.4\\?\\init.lua";
        let c_module_path = "C:\\Program Files (x86)\\WinLua\\LuaRocks\\bin\\?.dll;C:\\Program Files (x86)\\WinLua\\LuaRocks\\bin\\..\\lib\\lua\\5.4\\?.dll;C:\\Program Files (x86)\\WinLua\\LuaRocks\\bin\\loadall.dll;.\\?.dll;C:\\Users\\yancheng\\AppData\\Roaming\\luarocks\\lib\\lua\\5.4\\?.dll;D:\\dev-software\\Winlua\\lua\\5.4\\lib\\lua\\5.4\\?.dll";
        lua_engine.set_custom_module_path(Some(lua_module_path), Some(c_module_path));
        module::lua_public_module::register_lua_module1(x);
    });

    let source2 = r#"
     print("Hello world!")
     module_person.sleep(3000)
     module_person.rust_print(123)
     return "一个返回值"
    "#;


    let handles: Vec<_> = (0..10).map(|i| {
        thread::spawn(move || {
            println!("Thread number: {}", i);
            let tokio_runtime = tokio::runtime::Builder::new_current_thread().enable_all().build().unwrap();
            let lua_engine = Arc::new(LuaEngine::new());
            // 初始化lua引擎参数，设置一些自定义参数，如模块加载
            lua_engine.init_lua_engine(|x| {
                let lua_module_path = "C:\\Program Files (x86)\\WinLua\\LuaRocks\\bin\\lua\\?.lua;C:\\Program Files (x86)\\WinLua\\LuaRocks\\bin\\lua\\?\\init.lua;C:\\Program Files (x86)\\WinLua\\LuaRocks\\bin\\?.lua;C:\\Program Files (x86)\\WinLua\\LuaRocks\\bin\\?\\init.lua;C:\\Program Files (x86)\\WinLua\\LuaRocks\\bin\\..\\share\\lua\\5.4\\?.lua;C:\\Program Files (x86)\\WinLua\\LuaRocks\\bin\\..\\share\\lua\\5.4\\?\\init.lua;.\\?.lua;.\\?\\init.lua;C:\\Users\\yancheng\\AppData\\Roaming\\luarocks\\share\\lua\\5.4\\?.lua;C:\\Users\\yancheng\\AppData\\Roaming\\luarocks\\share\\lua\\5.4\\?\\init.lua;D:\\dev-software\\Winlua\\lua\\5.4\\share\\lua\\5.4\\?.lua;D:\\dev-software\\Winlua\\lua\\5.4\\share\\lua\\5.4\\?\\init.lua";
                let c_module_path = "C:\\Program Files (x86)\\WinLua\\LuaRocks\\bin\\?.dll;C:\\Program Files (x86)\\WinLua\\LuaRocks\\bin\\..\\lib\\lua\\5.4\\?.dll;C:\\Program Files (x86)\\WinLua\\LuaRocks\\bin\\loadall.dll;.\\?.dll;C:\\Users\\yancheng\\AppData\\Roaming\\luarocks\\lib\\lua\\5.4\\?.dll;D:\\dev-software\\Winlua\\lua\\5.4\\lib\\lua\\5.4\\?.dll";
                lua_engine.set_custom_module_path(Some(lua_module_path), Some(c_module_path));
                module::lua_public_module::register_lua_module1(&lua_engine.clone());
            });
            tokio_runtime.block_on(async {
                println!("LocalSet running");
                let id = thread::current().id();
                print!("thread uid :{:?}", id);
                let source2 = r#"
                  print("Hello world!1111")
                  local count = math.random(1000,6000)
                  print("os.time()->", os.time())

                  local current_time = os.time()
                  local formatted_time = os.date("%Y-%m-%d %H:%M:%S", current_time)
                  print("current time: " .. formatted_time)

                  print("random number:",count)
                  print(module_person.sleep(count))
                    print("Hello world!22222")
              "#;
                let result = lua_engine.async_exec_script1(source2).await;
            });
        })
    }).collect();

    for handle in handles {
        handle.join().unwrap();  // 等待所有线程完成
    }


    Ok(())
}

async fn main1() -> mlua::Result<()> {
    log4rs::init_file("config/log4rs.yaml", Default::default()).unwrap();
    // 创建lua引擎
    let lua_engine = Arc::new(LuaEngine::get_lua_engine());
    // 初始化lua引擎参数，设置一些自定义参数，如模块加载
    lua_engine.init_lua_engine(|x| {
        let lua_module_path = "C:\\Program Files (x86)\\WinLua\\LuaRocks\\bin\\lua\\?.lua;C:\\Program Files (x86)\\WinLua\\LuaRocks\\bin\\lua\\?\\init.lua;C:\\Program Files (x86)\\WinLua\\LuaRocks\\bin\\?.lua;C:\\Program Files (x86)\\WinLua\\LuaRocks\\bin\\?\\init.lua;C:\\Program Files (x86)\\WinLua\\LuaRocks\\bin\\..\\share\\lua\\5.4\\?.lua;C:\\Program Files (x86)\\WinLua\\LuaRocks\\bin\\..\\share\\lua\\5.4\\?\\init.lua;.\\?.lua;.\\?\\init.lua;C:\\Users\\yancheng\\AppData\\Roaming\\luarocks\\share\\lua\\5.4\\?.lua;C:\\Users\\yancheng\\AppData\\Roaming\\luarocks\\share\\lua\\5.4\\?\\init.lua;D:\\dev-software\\Winlua\\lua\\5.4\\share\\lua\\5.4\\?.lua;D:\\dev-software\\Winlua\\lua\\5.4\\share\\lua\\5.4\\?\\init.lua";
        let c_module_path = "C:\\Program Files (x86)\\WinLua\\LuaRocks\\bin\\?.dll;C:\\Program Files (x86)\\WinLua\\LuaRocks\\bin\\..\\lib\\lua\\5.4\\?.dll;C:\\Program Files (x86)\\WinLua\\LuaRocks\\bin\\loadall.dll;.\\?.dll;C:\\Users\\yancheng\\AppData\\Roaming\\luarocks\\lib\\lua\\5.4\\?.dll;D:\\dev-software\\Winlua\\lua\\5.4\\lib\\lua\\5.4\\?.dll";
        lua_engine.set_custom_module_path(Some(lua_module_path), Some(c_module_path));
        module::lua_public_module::register_lua_module(lua_engine.clone());
    });

    let source = r#"
        print("hello world")
        print(module_person.name)
        print(module_person.age)
        print(module_person.rust_print(123))
        print(module_person.func(1,2))
        print(module_person.sleep(3000))
        print(module_person.func(2,2))
    "#;

    /*    let source1 = r#"
        local json = require "cjson"
        local util = require "cjson.util"
        print("aaaaaaa")

        local json_object= {name = "wx771720", age = 18, married = true, skills = {"typescript", "unity", "lua"}}
        local t = json.encode(json_object)
        print(t)
        print(util.serialise_value(t))

        local json_str = '{"hobby":["film","music","read"],"is_male":false,"name":"zhangsan","id":1,"age":null}'
        local obj = json.decode(json_str)
        print(util.serialise_value(obj))

        "#;*/


    let source2 = r#"
     print("Hello world!")
     module_person.sleep(3000)
     module_person.rust_print(123)
     return "一个返回值"
    "#;
    lua_engine.async_exec_script1(source2).await;


    Ok(())
}



*/