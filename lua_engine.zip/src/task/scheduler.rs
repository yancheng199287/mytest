use std::cell::RefCell;
use crossbeam_channel::{bounded, Receiver, Sender, TrySendError};
use std::sync::{Arc, Mutex};
use rayon::ThreadPool;
use crate::task::lua_script_task::LuaScriptTask;
use crate::task::scheduler;
use crate::task::thread_local_container::ThreadContainer;

// 任务调度器
pub struct LuaTaskScheduler<LuaScriptTask> {
    pub thread_pool: ThreadPool,
    pub task_sender: Sender<LuaScriptTask>,
    pub task_receiver: Receiver<LuaScriptTask>,
    pub notification_sender: Sender<String>,
}

impl LuaTaskScheduler<LuaScriptTask> {
    pub fn new(max_threads: usize, max_queue_size: usize) -> Self {
        // 创建线程池和任务队列
        let thread_pool = crate::task::thread_pool::create_thread_pool(max_threads);
        let (task_sender, task_receiver) = bounded(max_queue_size);

        let (notification_sender, notification_receiver) = bounded(max_queue_size);

        // 启动通知处理线程
        std::thread::spawn(move || {
            while let Ok(notification) = notification_receiver.recv() {
                println!("任务完成: {}", notification);
            }
        });

        LuaTaskScheduler {
            thread_pool,
            task_sender,
            task_receiver,
            notification_sender,
        }
    }

    // 非阻塞添加任务
    pub fn try_add_task(&self, task: LuaScriptTask) {
        match self.task_sender.try_send(task) {
            Ok(value) => {
                println!("任务添加成功");
            },
            Err(TrySendError::Full(_)) => {
                println!("任务队列已满，丢弃任务");
            }
            Err(e) => {
                println!("无法添加任务: {:?}", e);
            }
        }
    }

    // 开始任务调度
    pub fn start(&self) {
        let task_receiver = Arc::new(Mutex::new(self.task_receiver.clone()));
        let notification_sender = self.notification_sender.clone();

        self.thread_pool.install(|| {
            rayon::scope(|s| {
                for _ in 0..self.thread_pool.current_num_threads() {
                    let task_receiver = task_receiver.clone();
                    let notification_sender = notification_sender.clone();

                    // 定义线程本地状态
                    thread_local! {
                       pub static GLOBAL_THREAD_CONTAINER: RefCell<ThreadContainer> = RefCell::new(ThreadContainer::new());
                    }

                    s.spawn(move |_| {
                        GLOBAL_THREAD_CONTAINER.with(|local_thread_container| {
                            println!("初始化线程");
                            while let Ok(task) = task_receiver.lock().unwrap().recv() {
                                println!("接受到任务，准备执行");
                                let result = task.execute(local_thread_container);
                                let notification = format!("任务 {} 完成，结果是 {}", task.id, result);
                                notification_sender.send(notification).expect("发送通知失败");
                            }
                        });
                    });
                }
            });
        });
    }
}
