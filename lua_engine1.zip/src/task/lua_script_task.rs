use std::cell::RefCell;
use crate::task::thread_local_container::ThreadContainer;

// 定义任务结构
pub struct LuaScriptTask {
    pub id: i64,
    pub script: String,
}

impl LuaScriptTask {
    pub fn new(id: i64, script: String) -> Self {
        LuaScriptTask {
            id,
            script,
        }
    }

    pub fn execute(&self, thread_container: &RefCell<ThreadContainer>) -> String {
        &thread_container.borrow().runtime.block_on(async {
            let lua_engine = &thread_container.borrow().lua_engine;
            let script = self.script.as_str();
            lua_engine.async_exec_script1(script).await;
            "OK"
        });
        return "OK".to_string();
    }
}
