use warp::Filter;
use std::path::Path;
use warp::http::Response;

async fn start_server(static_dir: String, index_file: String) {
    // 检查静态目录路径
    let static_path = Path::new(&static_dir);
    if !static_path.exists() || !static_path.is_dir() {
        eprintln!("Static directory does not exist or is not a directory");
        std::process::exit(1);
    }

    // 创建 Warp 过滤器
    let static_route = warp::fs::dir(static_dir.clone());

    let index_route = warp::path::end()
        .and(warp::fs::file(static_path.join(index_file)));

    // 合并两个路由
    let routes = index_route.or(static_route);

    // 启动 Warp 服务器
    warp::serve(routes).run(([0, 0, 0, 0], 3030)).await;
}

#[tokio::main]
async fn main() {
    // 定义静态文件目录和索引文件名
    let static_dir = "F:\\workspace\\tauri\\simple-mini-app\\dist".to_string(); // 静态文件目录
    let index_file = "index.html".to_string(); // 索引文件

    // 启动服务器
    start_server(static_dir, index_file).await;
}
