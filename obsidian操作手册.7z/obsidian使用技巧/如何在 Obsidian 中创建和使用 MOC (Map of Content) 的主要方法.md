在 **Obsidian** 中，**Map of Content (MOC)** 是一种强大的 **组织和导航** 工具，旨在通过集中管理和关联笔记来提高工作效率。MOC 让你能够更好地管理复杂的笔记库，并通过清晰的结构和链接轻松访问和管理各个主题、项目和资源。以下是如何在 Obsidian 中创建和使用 **MOC (Map of Content)** 的主要方法：

---

### **1. MOC 的定义和作用**

**Map of Content (MOC)** 是一个索引或目录页面，用于将相关的笔记、项目、任务或主题按某种逻辑组织起来。它的作用是作为一个 **导航中心**，帮助你快速跳转到相关的笔记和资源，避免在大量笔记中迷失。

MOC 的主要功能包括：

- **导航**：通过链接轻松导航到相关笔记。
    
- **组织**：按主题、项目、时间、学科等方式组织笔记。
    
- **集中管理**：集中了相关的资源、任务和目标，方便查看和更新。
    

---

### **2. 创建 MOC 页面**

在 Obsidian 中创建 MOC 页面非常简单。你可以根据不同的需求设计 MOC 结构，并将相关的笔记或子主题链接到 MOC 页面。

#### 步骤 1：创建一个新的 MOC 页面

1. 打开 Obsidian，点击左侧栏的 **新建文件** 按钮，或者使用快捷键 `Ctrl + N` 创建一个新页面。
    
2. 给新页面命名为 **"Map of Content"** 或其他自定义名称，例如 `"Work MOC"`, `"Tech MOC"`。
    

#### 步骤 2：在 MOC 页面中添加组织结构

使用 **Markdown** 语法，按逻辑结构列出相关主题、项目或资源的链接。

```markdown
# Work MOC

## Major Projects
- [[Project A]]
- [[Project B]]
- [[Project C]]

## Tasks & Goals
- [[Quarterly Goals]]
- [[To-Do List]]

## Resources
- [[Work Documentation]]
- [[Team Wiki]]

## Personal Development
- [[Work-Life Balance]]
- [[Professional Skills]]
```

- **Major Projects**：列出当前的主要项目，点击链接进入每个项目的详细页面。
    
- **Tasks & Goals**：列出重要的目标或任务页面。
    
- **Resources**：链接到工作文档或团队相关的资源。
    
- **Personal Development**：链接到提升自己工作和生活的相关页面。
    

#### 步骤 3：使用标题和列表组织内容

你可以通过标题和子标题来更好地组织内容。例如，如果你的 MOC 页面涉及多个领域，可以使用层级标题来划分不同部分：

```markdown
# Knowledge Management MOC

## 1. Work-Related
- [[Project X]]
- [[Quarterly Goals]]
- [[Team Wiki]]

## 2. Learning & Development
- [[Python Programming]]
- [[Machine Learning Notes]]
- [[Public Speaking]]
```

---

### **3. 使用双向链接 (Bi-directional Links)**

**双向链接**（`[[link]]`）是 Obsidian 的一个强大功能，它允许你在笔记之间建立联系。当你在 MOC 页面中使用双向链接时，可以方便地跳转到相关的内容页面。此外，在每个子页面的顶部，使用 **返回链接**（如 `[[Work MOC]]`）将页面与 MOC 相互关联，方便你在不同页面之间导航。

#### 示例：

- 在 **"Project A"** 页面中，顶部可以插入返回链接，指向 MOC 页面：
    
    ```markdown
    # Project A
    [[Work MOC]]
    ```
    
    这样，在 **Project A** 页面中，你可以随时跳转回 **Work MOC** 页面。
    

#### 好处：

- 你可以从 **任何相关页面** 返回到主 MOC 页面，保持知识的联通性和流动性。
    
- 通过 **双向链接**，Obsidian 会自动为你记录哪些页面与 MOC 页面有关，帮助你更好地理解笔记之间的关系。
    

---

### **4. 按类别组织 MOC 页面**

根据你知识库的内容，你可以将 MOC 页面按不同的类别来组织。例如，你可以创建多个 MOC 页面，每个页面专注于某个特定领域或主题。

#### 示例：按学科组织

```markdown
# Tech MOC

## Programming
- [[Python]]
- [[JavaScript]]
- [[React]]

## Software Engineering
- [[System Design]]
- [[Version Control]]
```

- 通过这种方式，你可以很容易地通过点击链接，快速进入到相关的技术笔记中。
    

#### 示例：按个人项目组织

```markdown
# Personal Projects MOC

## Blog
- [[Blog Post Ideas]]
- [[Blog Writing Process]]

## Fitness Goals
- [[Workout Plan]]
- [[Nutrition Goals]]
```

这种方式可以帮助你根据不同的 **项目、任务或兴趣** 组织内容，让你能够在 Obsidian 中高效地管理多个领域。

---

### **5. MOC 页面更新和维护**

MOC 页面是一个 **动态** 的工具，随着你的笔记库不断增加，MOC 页面也应当定期更新。例如，添加新的项目、目标或学习资源，删除不再相关的内容。

#### 如何维护 MOC 页面：

- **定期审查**：每隔一段时间，查看你的 MOC 页面并确保链接都是最新的。
    
- **添加新链接**：随着新笔记的创建，将它们添加到相关的 MOC 页面。
    
- **删除过时内容**：如果某些内容不再适用，可以从 MOC 页面中移除它们。
    

---

### **6. 高级 MOC 用法：使用标签和模板**

你可以结合 **标签** 和 **模板** 来优化 MOC 的使用：

- **标签（Tags）**：通过为相关页面添加标签（例如 `#project`，`#learning`），你可以让 MOC 页面通过标签过滤和显示相关内容。
    
- **模板（Templates）**：使用 **Obsidian 插件** 的模板功能来自动化创建新的 MOC 页面和子页面，减少重复工作。
    

#### 标签示例：

```markdown
# Work MOC

## Major Projects
- [[Project A]] #project
- [[Project B]] #project
```

#### 模板示例：

```markdown
# {{title}} - Map of Content (MOC)

## Projects
- [[Project A]]
- [[Project B]]

## Resources
- [[Work Documentation]]
```

---

### **7. 进一步扩展 MOC 功能**

你可以使用 Obsidian 的插件来扩展 MOC 的功能，例如：

- **Kanban 插件**：如果你喜欢使用看板管理项目，可以将 MOC 页面与 **Kanban 插件** 配合使用来管理任务和项目。
    
- **Dataview 插件**：使用 **Dataview 插件** 动态显示与 MOC 相关的笔记内容，自动生成项目、任务等数据视图。
    

---

### **总结**

通过创建和使用 **MOC (Map of Content)** 页面，你可以在 Obsidian 中轻松实现 **知识组织** 和 **导航**。MOC 提供了以下优势：

- **集中管理**：将所有相关主题、项目、资源按逻辑组织。
    
- **方便导航**：通过链接快速跳转到相关笔记。
    
- **灵活更新**：随着笔记库增长，MOC 页面可以灵活调整和扩展。
    
- **增强知识结构**：使用双向链接、标签和模板提高工作效率。
    

MOC 是组织和管理复杂笔记库的强大工具，适合用于 **知识管理**、**项目管理**、**学习笔记** 等各种场景。通过不断优化和调整 MOC 页面，你可以提升 **Obsidian** 的使用效率，实现高效的知识管理和工作流。