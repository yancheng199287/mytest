# {{date:YYYY-MM-DD}}

当前日期是：<% tp.date.now("YYYY-MM-DD HH:mm:ss") %>


今天的计划：
- [ ] 完成工作任务
- [ ] 阅读书籍

## 反思
- 今天学到了什么？
- 明天的目标是什么？


<%* 
var tasks = ["任务1", "任务2", "任务3"];
tasks.forEach(task => {
  tR += `- [ ] ${task}\n`;
});
%>