<template>
  <PromotedPromoted class="mb-5" medium="discovery" type="discovery" />
</template>
