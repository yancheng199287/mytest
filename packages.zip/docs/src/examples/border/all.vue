<template>
  <v-container>
    <v-row justify="space-around">
      <v-col cols="auto">
        <div class="text-center">
          <div class="border-thin" style="height: 64px; width: 64px;"></div>
          <div class="text-caption">border-thin</div>
        </div>
      </v-col>

      <v-col cols="auto">
        <div class="text-center">
          <div class="border-sm" style="height: 64px; width: 64px;"></div>
          <div class="text-caption">border-sm</div>
        </div>
      </v-col>

      <v-col cols="auto">
        <div class="text-center">
          <div class="border-md" style="height: 64px; width: 64px;"></div>
          <div class="text-caption">border-md</div>
        </div>
      </v-col>

      <v-col cols="auto">
        <div class="text-center">
          <div class="border-lg" style="height: 64px; width: 64px;"></div>
          <div class="text-caption">border-lg</div>
        </div>
      </v-col>

      <v-col cols="auto">
        <div class="text-center">
          <div class="border-xl" style="height: 64px; width: 64px;"></div>
          <div class="text-caption">border-xl</div>
        </div>
      </v-col>
    </v-row>
  </v-container>
</template>
