<template>
  <div class="bg-purple-darken-2 text-center">
    <span>Lorem ipsum</span>
  </div>
</template>
