<template>
  <div>
    Lorem ipsum dolor sit amet, <strong class="text-red-lighten-1">inciderint</strong> definitionem est ea, explicari prodesset eam id. Mazim doctus vix an. <span class="text-indigo-darken-2">Amet causae probatus nec ex</span>.
  </div>
</template>
