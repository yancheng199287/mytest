<template>
  <div>
    <div class="float-left">
      Float left on all viewport sizes
    </div>
    <br>
    <div class="float-right">
      Float right on all viewport sizes
    </div>
    <br>
    <div class="float-none">
      Don't float on all viewport sizes
    </div>
  </div>
</template>
