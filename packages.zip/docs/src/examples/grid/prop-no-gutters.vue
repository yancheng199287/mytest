<template>
  <v-container class="bg-surface-variant">
    <v-row no-gutters>
      <v-col cols="12">
        <v-sheet class="pa-2">
          .v-col-12
        </v-sheet>
      </v-col>
      <v-col cols="6">
        <v-sheet class="pa-2">
          .v-col-6
        </v-sheet>
      </v-col>
    </v-row>
  </v-container>
</template>
