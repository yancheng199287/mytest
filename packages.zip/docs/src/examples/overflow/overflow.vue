<template>
  <v-row>
    <v-col cols="auto">
      <v-card class="overflow-auto" height="200" width="200">
        <v-card-text>
          <h3>Overflow Auto</h3>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis
          facilis dicta esse molestias vero hic laudantium provident nisi eos
          quasi iusto alias sequi, aut aliquid voluptatibus commodi! Minima, eum
          voluptates?
        </v-card-text>
      </v-card>
    </v-col>
    <v-col cols="auto">
      <v-card class="overflow-hidden" height="200" width="200">
        <v-card-text>
          <h3>Overflow Hidden</h3>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis
          facilis dicta esse molestias vero hic laudantium provident nisi eos
          quasi iusto alias sequi, aut aliquid voluptatibus commodi! Minima, eum
          voluptates?
        </v-card-text>
      </v-card>
    </v-col>
    <v-col cols="auto">
      <v-card class="overflow-visible" height="200" width="200">
        <v-card-text>
          <h3>Overflow visible</h3>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis
          facilis dicta esse molestias vero hic laudantium provident nisi eos
          quasi iusto alias sequi, aut aliquid voluptatibus commodi! Minima, eum
          voluptates?
        </v-card-text>
      </v-card>
    </v-col>
  </v-row>
</template>
