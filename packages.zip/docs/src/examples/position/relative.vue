<template>
  <div class="bg-surface-variant pa-4 position-relative rounded-lg ma-2">
    <div class="bg-surface-light position-relative pa-3 pb-16">
      <div class="mb-2">Relative parent</div>

      <div class="position-absolute bottom-0 right-0 bg-primary rounded-lg pa-3">
        Absolute child
      </div>
    </div>
  </div>
</template>
