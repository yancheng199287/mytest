<template>
  <div>
    Sizing / Width example
  </div>
</template>
