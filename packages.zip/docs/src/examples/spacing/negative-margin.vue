<template>
  <div>
    <v-card
      class="mx-auto"
      color="secondary"
      height="100"
      max-width="200"
    ></v-card>
    <v-card
      class="mt-n12 mx-auto"
      color="secondary"
      elevation="12"
      height="200"
      max-width="300"
    >
      <v-card-text>This card has negative top margin applied</v-card-text>
    </v-card>
  </div>
</template>
