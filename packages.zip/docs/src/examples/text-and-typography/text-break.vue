<template>
  <div>
    <p class="custom-transform-class text-none">
      Random TEXT cApitaLization
    </p>
    <p
      class="text-break"
      style="max-width: 4rem;"
    >
      SUBDERMATOGLYPHIC
    </p>
  </div>
</template>

<style lang="sass">
  .custom-transform-class
    text-transform: uppercase
</style>
