<template>
  <div>
    <p class="text-high-emphasis">
      High-emphasis has an opacity of 87% in light theme and 100% in dark.
    </p>
    <p class="text-medium-emphasis">
      Medium-emphasis text and hint text have opacities of 60% in light theme and 70% in dark.
    </p>
    <p class="text-disabled">
      Disabled text has an opacity of 38% in light theme and 50% in dark.
    </p>
  </div>
</template>
