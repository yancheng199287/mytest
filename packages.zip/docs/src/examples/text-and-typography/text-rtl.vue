<template>
  <div>
    <p class="text-subtitle-2 text-center">
      Agnostic RTL Alignment
    </p>

    <p class="text-left">
      Left aligned text, irrespective of RTL or LTR.
    </p>
    <p class="text-right">
      Right aligned text, irrespective of RTL or LTR.
    </p>

    <p class="text-subtitle-2 text-center">
      Responsive RTL Alignment
    </p>

    <p class="text-start">
      Left aligned text on LTR and right aligned on RTL.
    </p>
    <p class="text-end">
      Right aligned text on LTR and left aligned on RTL.
    </p>
  </div>
</template>
