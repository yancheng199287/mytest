<template>
  <div>
    <span
      class="d-inline-block text-truncate"
      style="max-width: 150px;"
    >
      Suspendisse faucibus, nunc et pellentesque egestas, lacus ante convallis tellus.
    </span>
  </div>
</template>
