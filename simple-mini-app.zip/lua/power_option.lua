local cmd = require("cmd")
local json = require("json")

local function pub_echo(arg)
    local str = json.encode(arg)
    log("jsonstr:", str)
    local program = arg["program"]
    local args = arg["args"]
    log("args:", args)
    local info;
    if args == nil or args == "" then
        info = cmd.get_cmd_result(program)
        log("info:", info)
    elseif args ~= "" then
        info = cmd.get_cmd_result(program, args)
    end
    local info = cmd.get_cmd_result(program, args)
    return info
end

local function pub_power_off()
    local info = cmd.execute_cmd("echo '准备关机'")
    return info
end