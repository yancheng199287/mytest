<script setup lang="ts">
import ChatApp from "./components/ChatApp.vue";
</script>

<template>
  <ChatApp></ChatApp>
</template>

<style scoped>
</style>
