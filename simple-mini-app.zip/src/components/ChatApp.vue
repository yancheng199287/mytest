<template>
  <div class="app-header" style="width: 1280px">
    <v-app>


      <v-container class="fill-height fill-width" fluid>
        <v-toolbar color="primary" dark>
          <v-toolbar-title>
            {{ selectedChat.title }}
          </v-toolbar-title>
        </v-toolbar>
        <v-row>
          <!-- 左侧聊天会话记录列表 -->
          <v-col cols="3" class="chat-list">
            <div class="chat-list-container">
              <v-list dense>
                <v-list-item v-for="chat in chats" :key="chat.id" @click="selectChat(chat)">
                  <v-list-item-content>
                    <v-list-item-title>{{ chat.title }}</v-list-item-title>
                  </v-list-item-content>
                </v-list-item>
              </v-list>
            </div>
          </v-col>
          <!-- 右侧聊天主窗口 -->
          <v-col cols="9" class="chat-main">

            <v-card class="chat-container">
              <v-card-text class="chat-history">
                <div v-for="message in selectedChat.messages" :key="message.id" class="message">
                  <div :class="['message-bubble', message.fromUser ? 'user' : 'bot']">
                    {{ message.text }}
                  </div>
                </div>
              </v-card-text>
              <v-card-actions>
                <v-text-field
                    v-model="newMessage"
                    @keyup.enter="sendMessage"
                    placeholder="Type a message"
                    outlined
                    dense
                    full-width
                ></v-text-field>
              </v-card-actions>
            </v-card>
          </v-col>
        </v-row>
      </v-container>
    </v-app>
  </div>
</template>

<script setup lang="ts">
import {ref} from 'vue';

const chats = ref([
  {
    id: 1,
    title: 'Chat with AI',
    messages: [
      {id: 1, text: 'Hello! How can I assist you today?', fromUser: false},
      {id: 2, text: 'I need some help with my project.', fromUser: true},
    ],
  },
  {
    id: 2,
    title: 'Support Chat',
    messages: [
      {id: 1, text: 'Welcome to support! How can  can I help you?', fromUser: false},
    ],
  },
]);

const selectedChat = ref(chats.value[0]);
const newMessage = ref('');

const selectChat = (chat) => {
  selectedChat.value = chat;
};

const sendMessage = () => {
  if (newMessage.value.trim()) {
    selectedChat.value.messages.push({
      id: Date.now(),
      text: newMessage.value,
      fromUser: true,
    });
    selectedChat.value.messages.push({
      id: Date.now() + 1,
      text: newMessage.value, // 模拟API响应
      fromUser: false,
    });
    newMessage.value = '';
  }
};
</script>

<style scoped>
.chat-list {
  background-color: #f5f5f5;
  overflow-y: auto;
}

.chat-main {
  display: flex;
  flex-direction: column;
  height: 80vh;
}

.chat-container {
  flex: 1;
  display: flex;
  flex-direction: column;
}

.chat-history {
  flex: 1;
  overflow-y: auto;
  padding: 16px;
}

.message {
  display: flex;
  margin-bottom: 8px;
}

.message-bubble {
  padding: 8px 16px;
  border-radius: 16px;
  max-width: 60%;
  word-wrap: break-word;
}

.message-bubble.user {
  background-color: #1976d2;
  color: white;
  margin-left: auto;
}

.message-bubble.bot {
  background-color: #e0e0e0;
  color: black;
  margin-right: auto;
}

v-card-actions {
  margin-top: auto;
}
</style>
