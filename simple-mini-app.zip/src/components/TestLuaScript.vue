<script setup lang="ts">
import {ref} from "vue";
import {power_option} from "../native/power_option.ts";
import {my_sqlite} from "../native/my_sqlite.ts";


const program = ref("netstat");
const program_args = ref("");


const lua_script_result = ref("");


function echo_cmd_result() {
  power_option.pub_echo({
    "program": program.value,
    "args": program_args.value
  })?.then((data) => {
    console.log(data);
    lua_script_result.value = data.stderr + "\n" + data.stdout;
  }).catch((err) => {
    lua_script_result.value = "error：" + JSON.stringify(err);
    console.log(err);
  });
}

function init_my_sqlite() {
  my_sqlite.init_db({
    "args": program_args.value
  })?.then((data) => {
    console.log("init_db ", data);
    lua_script_result.value = JSON.stringify(data);
  }).catch((err) => {
    lua_script_result.value = "error：" + JSON.stringify(err);
    console.log(err);
  });
}

</script>

<template>


  <div>
    <v-textarea v-model="program" label="program" outlined rows="1" auto-grow></v-textarea>

    <v-textarea v-model="program_args" label="cmd args" outlined rows="10" auto-grow></v-textarea>
    <div>
      <button @click="echo_cmd_result">执行脚本调用</button>
      <button @click="init_my_sqlite">初始化数据库</button>

    </div>
    <div>
      <v-textarea v-model="lua_script_result" label="Lua Script Result" outlined rows="10" auto-grow></v-textarea>
    </div>
  </div>

</template>

<style scoped>

</style>