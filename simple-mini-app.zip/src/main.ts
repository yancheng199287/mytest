import {createApp} from 'vue'
import './style.css'
import App from './App.vue'


// 支持字体样式
import '@fortawesome/fontawesome-free/css/all.css'
import {aliases, fa} from 'vuetify/iconsets/fa'

// 导入vuetify样式和组件，指令
import 'vuetify/styles'
import {createVuetify} from 'vuetify'
import * as components from 'vuetify/components'
import * as directives from 'vuetify/directives'


import {initializeWebSocketStore} from "./store/LuaStore.ts";


// 导入pinia
import {createPinia} from 'pinia'

const app = createApp(App);

// 初始化 createVuetify
const vuetify = createVuetify({
    components,
    directives,
    icons: {
        defaultSet: 'fa',
        aliases,
        sets: {
            fa,
        },
    },
})

// 加载插件到vue
app.use(vuetify);

// 加载插件到 pinia， 具体使用参考官网文档说明
const pinia = createPinia()
app.use(pinia);

app.mount("#app");

// 初始化WebSocket连接
initializeWebSocketStore();
