import {LuaEngineClient} from "../store/LuaStore.ts";

const  lua_absolute_path = "F:\\workspace\\rust\\ws_bridge_lua\\test_lua\\test_sqlite.lua";
export const my_sqlite = {

  init_db: (args: any) => LuaEngineClient?.callScriptFunction(lua_absolute_path, 'init_db', args),

  pub_power_off: (args: any) => LuaEngineClient?.callScriptFunction(lua_absolute_path, 'pub_power_off', args),

};
