import {LuaEngineClient} from "../store/LuaStore.ts";

const  lua_absolute_path = "F:\\workspace\\tauri\\simple-mini-app\\lua\\power_option.lua";
export const power_option = {

  pub_echo: (args: any) => LuaEngineClient?.callScriptFunction(lua_absolute_path, 'pub_echo', args),

  pub_power_off: (args: any) => LuaEngineClient?.callScriptFunction(lua_absolute_path, 'pub_power_off', args),

};
