import {defineStore} from 'pinia';

import  {LuaEngineClientSdk} from "lua-client";


const LuaDefineStore = defineStore('luaStore', {
    state: (): { isConnected: boolean; messages: any[]; luaEngineClientSdk: LuaEngineClientSdk } => ({
        luaEngineClientSdk: new LuaEngineClientSdk(),
        isConnected: false,
        messages: []
    }),
    getters: {},
    actions: {
        initializeLuaEngineClientSdk() {
            this.luaEngineClientSdk.initScriptClient((success: boolean) => {
                if (success) {
                    console.log("LuaEngineClientSdk init success");
                } else {
                    console.log("LuaEngineClientSdk init failed");
                }
            });
        },
        callScriptFunction(script_file_path: string, function_name: string, args: any) {
            let source = {
                "lua_file_path": script_file_path,
                "function_name": function_name,
                "function_params": args
            }
            return this.luaEngineClientSdk.callScriptFunction(source);
        },
    }
});


// 创建一个导出函数来初始化和返回 WebSocket store 实例
export let LuaEngineClient: ReturnType<typeof LuaDefineStore> | null = null;

export function initializeWebSocketStore() {
    LuaEngineClient = LuaDefineStore();
    LuaEngineClient.initializeLuaEngineClientSdk()
    return LuaEngineClient;
}


