<template>
  <div class="app-header" style="width: 1280px">
    <v-app>


      <v-container class="fill-height fill-width" fluid>
        <v-toolbar color="primary" dark>
          <v-toolbar-title>
            {{ selectedChat.title }}
          </v-toolbar-title>
        </v-toolbar>
        <v-row>
          <!-- 左侧聊天会话记录列表 -->
          <v-col cols="3" class="chat-list">
            <div class="chat-list-container">
              <v-list dense>
                <v-list-item v-for="chat in chats" :key="chat.id" @click="selectChat(chat)">
                  <v-list-item-content>
                    <v-list-item-title>{{ chat.title }}</v-list-item-title>
                  </v-list-item-content>
                </v-list-item>
              </v-list>
            </div>
          </v-col>
          <!-- 右侧聊天主窗口 -->
          <v-col cols="9" class="chat-main">
            <v-card class="chat-container">
              <v-card-text class="chat-history" ref="chatListRef">
                <div v-for="message in selectedChat.messages" :key="message.id" class="message">
                  <div :class="['message-bubble', message.fromUser ? 'user' : 'bot']">
                    <div v-highlight>
                      <div v-html="message.text"></div>
                    </div>

                  </div>
                </div>
              </v-card-text>
              <v-card-actions>
                <v-text-field
                    v-model="newMessage"
                    @keyup.enter="sendMessage"
                    placeholder="Type a message"
                    outlined
                    dense
                    full-width
                ></v-text-field>
              </v-card-actions>
            </v-card>
          </v-col>
        </v-row>
      </v-container>
    </v-app>
  </div>
</template>

<script setup lang="ts">
import {nextTick, onMounted, ref, watch} from 'vue';
import {marked} from "marked";
import hljs from "highlight.js";

const chatListRef = ref<HTMLElement | null>(null);
const scrollToBottom = () => {
 // let box = chatListRef.querySelector(".chat-history");
  chatListRef.value.$el.scrollTop = chatListRef.value.$el.scrollHeight;
  console.log(chatListRef.value)
};
onMounted(() => {
  scrollToBottom(); // 初次加载时滚动到底部
});


const chats = ref([
  {
    id: 1,
    title: 'Chat with AI',
    messages: [
      {
        id: 1,
        text: 'Hello! How can I assist you today? Hello! How can I assist you today? Hello! How can I assist you today? Hello! How can I assist you today?',
        fromUser: false
      },
      {id: 2, text: 'I need some help with my project.', fromUser: true},
    ],
  },
  {
    id: 2,
    title: 'Support Chat',
    messages: [
      {id: 1, text: 'Welcome to support! How can  can I help you?', fromUser: false},
    ],
  },
]);

const selectedChat = ref(chats.value[0]);
const newMessage = ref('');

const selectChat = (chat) => {
  selectedChat.value = chat;
};

const sendMessage = () => {
  if (newMessage.value.trim()) {
    selectedChat.value.messages.push({
      id: Date.now(),
      text: newMessage.value,
      fromUser: true,
    });
    fetch_result();
  }
};


watch(selectedChat, () => {
  console.log("chat.......");
  const blocks = document.querySelectorAll('pre code');
  blocks.forEach((block: HTMLElement) => {
    hljs.highlightElement(block);
  });
});

const fetch_result = () => {
  get_result().then(res => {
    selectedChat.value.messages.push({
      id: Date.now() + 1,
      text: res, // 模拟API响应
      fromUser: false,
    });
    nextTick(() => {
      scrollToBottom(); // 当内容数组变化时滚动到底部
    });
    /* const blocks = document.querySelectorAll('pre code');
     blocks.forEach((block: HTMLElement) => {
       hljs.highlightElement(block);
     });*/
    newMessage.value = '';
  });
}

const get_result = async () => {
  let makrdwon = `


### 安装 TypeScript 和其他依赖

\`\`\`
yarn add typescript @types/node --dev
yarn add @msgpack/msgpack
\`\`\`



### 配置 TypeScript 编译器

\`\`\`typescript
{
    "compilerOptions": {
      "outDir": "./dist",
      "module": "commonjs",
      "target": "ES2020",
      "strict": true,
      "declaration": true,
      "declarationMap": true,
      "lib": [
        "ES2020",
        "dom"
      ]
    },
    "include": ["src"]
  }

\`\`\`



### 在 \`package.json\` 中添加编译脚本

配置字段 main  types  scripts files

\`\`\`typescript
{
  "name": "lua-client",
  "version": "1.0.0",
  "main": "dist/index.js",
  "types": "dist/index.d.ts",
  "scripts": {
    "build": "tsc"
  },
  "files": [
    "dist"
  ],
  "keywords": [],
  "author": "",
  "license": "ISC",
  "description": "",
  "devDependencies": {
    "typescript": "^5.5.2"
  },
  "dependencies": {
    "@msgpack/msgpack": "^3.0.0-beta2"
  }
}
\`\`\`


## 配置打包

\`\`\`typescript
import {defineConfig} from 'vite'
import vue from '@vitejs/plugin-vue'
import {viteStaticCopy} from 'vite-plugin-static-copy'

// https://vitejs.dev/config/
export default defineConfig({
    plugins: [
        vue(),
        viteStaticCopy({
            targets: [
                {
                    src: 'manifest.json',
                    dest: '.'
                }
            ]
        })
    ],
})
\`\`\`


    `;

  return marked(makrdwon);
};
</script>

<style scoped>
.chat-list {
  background-color: #f5f5f5;
  overflow-y: auto;
}

.chat-main {
  display: flex;
  flex-direction: column;
  height: 80vh;
}

.chat-container {
  flex: 1;
  display: flex;
  flex-direction: column;
}

.chat-history {
  flex: 1;
  overflow-y: auto;
  padding: 16px;
}

.message {
  display: flex;
  margin-bottom: 8px;
}

.message-bubble {
  padding: 8px 16px;
  border-radius: 16px;
  max-width: 90%;
  word-wrap: break-word;
}

.message-bubble.user {
  background-color: #1976d2;
  color: white;
  margin-left: auto;
}

.message-bubble.bot {
  background-color: #e0e0e0;
  color: black;
  margin-right: auto;
}

v-card-actions {
  margin-top: auto;
}
</style>
