import {createApp} from 'vue'
import './style.css'
import App from './App.vue'


// 支持字体样式
import '@fortawesome/fontawesome-free/css/all.css'
import {aliases, fa} from 'vuetify/iconsets/fa'

// 导入vuetify样式和组件，指令
import 'vuetify/styles'
import {createVuetify} from 'vuetify'
import * as components from 'vuetify/components'
import * as directives from 'vuetify/directives'




import 'highlight.js/styles/monokai-sublime.css'; // 选择合适的样式
import hljs from 'highlight.js';

import clipboard from 'clipboard-js';



// 导入pinia
import {createPinia} from 'pinia'

const app = createApp(App);

// 初始化 createVuetify
const vuetify = createVuetify({
    components,
    directives,
    icons: {
        defaultSet: 'fa',
        aliases,
        sets: {
            fa,
        },
    },
})

// 加载插件到vue
app.use(vuetify);

// 加载插件到 pinia， 具体使用参考官网文档说明
const pinia = createPinia()
app.use(pinia);




app.directive('highlight', {
    mounted(el) {
        const blocks = el.querySelectorAll('pre code');
        blocks.forEach((block: HTMLElement) => {
            hljs.highlightElement(block);

            const language = block.className.split('-')[1] || 'code';
            const wrapper = document.createElement('div');
            wrapper.style.position = 'relative';
            wrapper.style.marginBottom = '1em';

            const titleBar = document.createElement('div');
            titleBar.style.display = 'flex';
            titleBar.style.justifyContent = 'space-between';
            titleBar.style.alignItems = 'center';
            titleBar.style.backgroundColor = '#f5f5f5';
            titleBar.style.border = '1px solid #ddd';
            titleBar.style.borderBottom = 'none';
            titleBar.style.padding = '5px 10px';
            titleBar.style.marginTop = '15px';


            const languageLabel = document.createElement('span');
            languageLabel.innerText = language;
            languageLabel.style.fontWeight = 'bold';

            const button = document.createElement('button');
            button.innerText = 'Copy';
            button.style.padding = '5px';
            button.style.backgroundColor = '#4CAF50';
            button.style.color = 'white';
            button.style.border = 'none';
            button.style.cursor = 'pointer';
            button.style.borderRadius = '3px';
            button.style.fontSize = '12px';

            button.addEventListener('click', () => {
                clipboard.copy(block.innerText).then(
                    () => {
                        button.innerText = 'Copied!';
                        setTimeout(() => {
                            button.innerText = 'Copy';
                        }, 2000);
                    },
                    () => {
                        button.innerText = 'Failed!';
                        setTimeout(() => {
                            button.innerText = 'Copy';
                        }, 2000);
                    }
                );
            });

            titleBar.appendChild(languageLabel);
            titleBar.appendChild(button);
            wrapper.appendChild(titleBar);

            const pre = block.parentElement!;
            pre.style.margin = '0';
            pre.style.border = '1px solid #ddd';
            pre.style.borderTop = 'none';
            pre.style.borderRadius = '0 0 5px 5px';

            wrapper.appendChild(pre.cloneNode(true));
            pre.replaceWith(wrapper);
        });
    },
    updated(el) {
        const blocks = el.querySelectorAll('pre code');
        blocks.forEach((block: HTMLElement) => {
            hljs.highlightElement(block);
        });
    }
});

app.mount("#app");

