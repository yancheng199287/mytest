import {defineConfig} from 'vite'
import vue from '@vitejs/plugin-vue'
import {viteStaticCopy} from 'vite-plugin-static-copy'
import fs from 'fs';
import path from 'path';
import archiver from 'archiver';
// https://vitejs.dev/config/
export default defineConfig({
    base: '/dist/my-app-name/', // 设置为包含 dist 和项目名称的路径
    plugins: [
        vue(),
        // copyLuaFiles(),
        viteStaticCopy({
                targets: [
                    {
                        src: 'manifest.json',
                        dest: '.'
                    },
                    {
                        src: 'lua/**/*',  // 源目录及其所有子目录和文件
                        dest: 'lua'           // 目标目录相对于 dist 目录
                    }
                ]
            }
        ),
        zipDistFolder('my-app-name') // Replace 'my-app-name' with your desired app name
    ],
})


function copyLuaFiles() {
    return {
        name: 'copy-lua-files',
        closeBundle() {
            const srcDir = path.resolve(__dirname, 'src', 'lua');
            const destDir = path.resolve(__dirname, 'dist', 'lua');

            fs.mkdirSync(destDir, {recursive: true});

            function copyDir(src, dest) {
                const entries = fs.readdirSync(src, {withFileTypes: true});

                for (let entry of entries) {
                    const srcPath = path.join(src, entry.name);
                    const destPath = path.join(dest, entry.name);

                    if (entry.isDirectory()) {
                        fs.mkdirSync(destPath, {recursive: true});
                        copyDir(srcPath, destPath);
                    } else {
                        fs.copyFileSync(srcPath, destPath);
                    }
                }
            }

            copyDir(srcDir, destDir);
        }
    };
}


function zipDistFolder(appName) {
    return {
        name: 'zip-dist-folder',
        closeBundle() {
            // Ensure the dist directory exists
            const distDir = path.resolve(__dirname, 'dist');
            if (!fs.existsSync(distDir)) {
                fs.mkdirSync(distDir, {recursive: true});
            }

            // Define the output zip file name and path
            const zipFileName = `${appName}.zip`;
            const zipFilePath = path.join(distDir, zipFileName);

            // Handle the output events
            const output = fs.createWriteStream(zipFilePath);
            const archive = archiver('zip', {
                zlib: {level: 9} // Maximum compression
            });

            output.on('close', () => {
                console.log(`${zipFilePath} has been finalized and the output file descriptor has closed.`);
            });

            archive.on('warning', (err) => {
                if (err.code !== 'ENOENT') {
                    throw err;
                }
            });

            archive.on('error', (err) => {
                throw err;
            });

            // Pipe the archive data to the file
            archive.pipe(output);

            // Append the dist directory to the archive, excluding the zip file itself
            archive.glob('**/*', {
                cwd: distDir,
                ignore: [zipFileName]
            });

            // Finalize the archive
            archive.finalize();
        }
    };
}
