<template>
  <swiper
      ref="swiper"
      :modules="[Mousewheel, Pagination]"
      direction="vertical"
      :mousewheel="true"
      :pagination="pagination"
      :loop="true"
      @slideChange="onSlideChange"
      class="mySwiper"
  >
    <swiper-slide v-for="(slide, index) in slides" :key="index">
      <slot :slide="slide" :index="index"></slot>
    </swiper-slide>
  </swiper>
  <div class="swiper-pagination"></div>
</template>

<script lang="ts" setup>
import { ref, watch, defineProps } from 'vue';

import {Swiper, SwiperSlide} from 'swiper/vue';
import 'swiper/css';
import 'swiper/swiper-bundle.css';
import 'swiper/css/pagination';
import {Mousewheel, Pagination} from 'swiper/modules';

// 定义组件属性
const props = defineProps({
  slides: {
    type: Array,
    required: true
  },
  onSlideChange: {
    type: Function,
    required: true
  }
});

const pagination = ref({
  clickable: true,
  el: '.swiper-pagination'
});

// 监听属性变化
watch(() => props.slides, (newSlides) => {
  swiperSlides.value = newSlides;
});

const swiperSlides = ref([...props.slides]);


</script>

<style scoped>
.mySwiper {
  width: 100%;
  height: 100vh;
}

.swiper-slide {
  text-align: center;
  font-size: 18px;
  background: #c58080;

  /* Center slide text vertically */
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>
