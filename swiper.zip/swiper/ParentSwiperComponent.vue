<template>
  <div>
    <MySwiper :slides="slides" :onSlideChange="handleSlideChange">
      <template #default="{ slide, index }">
        <div class="slide-content">
          <h3>{{ slide.title }}</h3>
          <p>{{ slide.content }}</p>
        </div>
      </template>
    </MySwiper>
  </div>
</template>

<script lang="ts" setup>
import {ref} from 'vue';
import MySwiper from './MySwiper.vue';
import Swiper from "swiper";

const slides = ref([
  { title: 'Slide 1', content: 'Content for slide 1' },
  { title: 'Slide 2', content: 'Content for slide 2' },
  { title: 'Slide 3', content: 'Content for slide 3' },
  { title: 'Slide 4', content: 'Content for slide 4' },
  { title: 'Slide 5', content: 'Content for slide 5' }
]);

const handleSlideChange = (swiper: Swiper) => {
  let realIndex = swiper.realIndex;
  let activeIndex = swiper.activeIndex;
  console.log('Current slide realIndex:', realIndex, ", realIndex:", realIndex, swiper);
  loadSlideData(realIndex);
};

const loadSlideData = (index: number) => {
  // 模拟一个异步数据加载
  setTimeout(() => {
    slides.value[index].content = `Slide ${index + 1} - Loaded`;
    console.log(`Data loaded for slide ${index + 1}`);
    // 根据需要更新 slides 数组中的数据
  }, 1000);
};
</script>

<style scoped>
/* 添加父组件样式 */
.slide-content {
  text-align: center;
}
</style>
