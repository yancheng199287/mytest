use std::time::Duration;
use tokio::select;
use crate::subscribe_task::{async_task_container, Client, subscription_manager, TOPIC_CLIPBOARD, TOPIC_CPU_LOAD};
use crate::subscribe_task::async_task_container::AsyncTaskContainerManager;
use crate::subscribe_task::subscription_manager::SubscriptionManager;

mod subscribe_task;

#[tokio::main]
async fn main() {
    println!("Hello, world!");
    log4rs::init_file("config/log4rs.yaml", Default::default()).unwrap();

    let id1 = idgenerator::IdInstance::next_id().to_string();
    let id2 = idgenerator::IdInstance::next_id().to_string();

    let (tx1, mut rx1) = tokio::sync::mpsc::channel(100);
    let (tx2, mut rx2) = tokio::sync::mpsc::channel(100);
    let client1 = Client::new(id1.clone(), tx1);
    let client2 = Client::new(id2.clone(), tx2);

    let subscription_manager = SubscriptionManager::new();
    subscription_manager.subscribe(TOPIC_CPU_LOAD, client1.clone());
    subscription_manager.subscribe(TOPIC_CPU_LOAD, client2.clone());

    subscription_manager.subscribe(TOPIC_CLIPBOARD, client1.clone());
    subscription_manager.subscribe(TOPIC_CLIPBOARD, client2.clone());


    let mut async_task_container = AsyncTaskContainerManager::new();

    async_task_container.add_task(id1.clone(), async move {
        while let Some(message) = rx1.recv().await {
            println!("Client1 received: {}", message);
        }
    });
    async_task_container.add_task(id2.clone(), async move {
        while let Some(message) = rx2.recv().await {
            println!("Client2 received: {}", message);
        }
    });
    async_task_container.wait_all().await;


    // 同时监听两个接收者
    /*    loop {
            select! {
                Some(msg) = rx1.recv() => {
                    println!("Client1 received: {}", msg);
                },
                Some(msg) = rx2.recv() => {
                    println!("Client2 received: {}", msg);
                },
                else => {
                    // 如果两个接收器都关闭了，跳出循环
                    break;
                }
            }
        }*/

    tokio::time::sleep(Duration::from_secs(50)).await
}
