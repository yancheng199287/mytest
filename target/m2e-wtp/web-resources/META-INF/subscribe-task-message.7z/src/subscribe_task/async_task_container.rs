use dashmap::DashMap;
use tokio::task::{JoinSet, AbortHandle};

// 创建一个异步任务管理器,支持 添加、移除和取消任务，支持多个任务运行，比 select!好，实现动态任务管理
pub struct AsyncTaskContainerManager {
    tasks: DashMap<String, AbortHandle>,
    join_set: JoinSet<()>,
}

impl AsyncTaskContainerManager {
    pub(crate) fn new() -> Self {
        AsyncTaskContainerManager {
            tasks: DashMap::new(),
            join_set: JoinSet::new(),
        }
    }

    pub(crate) fn add_task<F>(&mut self, id: String, future: F)
    where
        F: std::future::Future<Output=()> + Send + 'static,
    {
        let id_clone = id.clone();
        let handle = self.join_set.spawn(future);
        println!("Task {} completed", id_clone);
        self.tasks.insert(id, handle);
    }

    pub(crate) fn remove_task(&mut self, id: &str) {
        if let Some(handle) = self.tasks.remove(id) {
            handle.1.abort();
            println!("Task {} cancelled", id);
        }
    }

    pub(crate) fn cancel_all_tasks(&mut self) {
        for entry in self.tasks.iter_mut() {
            entry.value().abort();
            println!("Task {} cancelled", entry.key());
        }
    }

    pub(crate) async fn wait_all(&mut self) {
        while let Some(res) = self.join_set.join_next().await {
            let _ = res;
        }
    }
}