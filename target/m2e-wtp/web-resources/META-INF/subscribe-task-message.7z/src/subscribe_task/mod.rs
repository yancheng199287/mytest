mod task_manager;
pub(crate) mod task;
mod topic_manager;
pub mod subscription_manager;
pub(crate) mod async_task_container;

use std::sync::Arc;
use dashmap::DashMap;
use async_trait::async_trait;
use tokio::sync::mpsc::Sender;


pub const TOPIC_CPU_LOAD: &str = "cpu_load";
pub const TOPIC_CLIPBOARD: &str = "clipboard";


// 客户端信息
#[derive(Clone)]
pub struct Client {
    id: String,
    sender: Sender<String>,
}

impl Client {
    pub fn new(id: String, sender: Sender<String>) -> Self {
        Client { id, sender }
    }
}

// 主题信息
struct Topic {
    name: String,
    subscribers: Arc<DashMap<String, Client>>,
    broadcaster: Sender<String>,
}

// 任务接口
#[async_trait]
trait SubscriptionTask: Send + Sync {
    async fn run(&self, tx: Sender<String>);
    fn stop(&self);
}
