use std::sync::Arc;
use dashmap::DashMap;
use crate::subscribe_task::{Client, SubscriptionTask, TOPIC_CLIPBOARD, TOPIC_CPU_LOAD};
use crate::subscribe_task::task::clipboard_task::ClipboardTask;
use crate::subscribe_task::task::cpu_load_task::CpuLoadTask;
use crate::subscribe_task::topic_manager::TopicManager;
use anyhow::{Error, Result};

pub struct SubscriptionManager {
    topic_manager: Arc<TopicManager>,
    tasks: DashMap<String, Arc<dyn SubscriptionTask>>,
}

impl SubscriptionManager {
    pub fn new() -> Self {
        let mut manager = SubscriptionManager {
            topic_manager: Arc::new(TopicManager::new()),
            tasks: DashMap::new(),
        };
        manager.init_tasks();
        manager
    }

    fn init_tasks(&mut self) {
        self.tasks.insert(TOPIC_CPU_LOAD.to_string(), Arc::new(CpuLoadTask::new()));
        self.tasks.insert(TOPIC_CLIPBOARD.to_string(), Arc::new(ClipboardTask::new()));
    }

    pub fn subscribe(&self, topic_name: &str, client: Client) -> Result<()> {
        if !self.tasks.contains_key(topic_name) {
            return Err(Error::msg(format!("Task not found for topic from self tasks {}", topic_name)));
        }
        self.topic_manager.subscribe(topic_name, client)?;
        Ok(())
    }

    pub fn unsubscribe(&self, topic_name: &str, client_id: &str) -> Result<()> {
        self.topic_manager.unsubscribe(topic_name, client_id);
        Ok(())
    }

    // 其他必要的方法...
}
