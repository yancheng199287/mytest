use std::sync::Arc;
use std::time::Duration;
use dashmap::DashMap;
use crossbeam_channel::{unbounded, Receiver};
use async_trait::async_trait;
use log::{info, error};
use parking_lot::Mutex;
use tokio::sync::mpsc::Sender;
use tokio::time::interval;
use crate::subscribe_task::SubscriptionTask;

pub(crate) struct ClipboardTask {
    running: Arc<Mutex<bool>>,
}

impl ClipboardTask {
    pub(crate) fn new() -> Self {
        ClipboardTask {
            running: Arc::new(Mutex::new(false)),
        }
    }

    fn check_clipboard_change(&self) -> Option<String> {
        // 模拟检查剪贴板是否有变化
        // 实际应用中，这里应该调用适当的库来检查剪贴板是否有变化
        Some("New clipboard content".to_string())
    }
}

#[async_trait]
impl SubscriptionTask for ClipboardTask {
    async fn run(&self, tx: Sender<String>) {
        *self.running.lock() = true;

        while *self.running.lock() {
            // 模拟监听剪贴板
            // 实际应用中，这里应该使用适当的库来监听系统剪贴板
            tokio::time::sleep(Duration::from_secs(3)).await; // 避免过度消耗CPU

            if let Some(content) = self.check_clipboard_change() {
                let message = format!("Clipboard content: {}", content);
                if let Err(e) = tx.send(message).await {
                    error!("Failed to send clipboard content: {}", e);
                }
            }
        }
    }



    fn stop(&self) {
        *self.running.lock() = false;
    }
}