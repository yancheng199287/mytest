use std::sync::Arc;
use std::time::Duration;
use async_trait::async_trait;
use log::error;
use parking_lot::Mutex;
use tokio::sync::mpsc::Sender;
use tokio::time::interval;
use crate::subscribe_task::SubscriptionTask;

pub(crate)  struct CpuLoadTask {
    running: Arc<Mutex<bool>>,
}

impl CpuLoadTask {
    pub(crate) fn new() -> Self {
        CpuLoadTask {
            running: Arc::new(Mutex::new(false)),
        }
    }
}

#[async_trait]
impl SubscriptionTask for CpuLoadTask {
    async fn run(&self, tx: Sender<String>) {
        *self.running.lock() = true;
        let mut interval = interval(Duration::from_secs(5));

        while *self.running.lock() {
            interval.tick().await;
            // 模拟获取CPU负载
            let cpu_load = 50.0; // 实际应用中，这里应该调用系统API获取真实CPU负载
            let message = format!("CPU Load: {}%", cpu_load);
            if let Err(e) = tx.send(message).await {
                error!("Failed to send CPU load: {}", e);
            }
        }
    }

    fn stop(&self) {
        *self.running.lock() = false;
    }
}