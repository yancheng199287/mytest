pub(crate) mod clipboard_task;
pub(crate) mod cpu_load_task;