use std::sync::Arc;

use dashmap::DashMap;
use tokio::sync::Mutex;
use anyhow::Result;
use tokio::sync::mpsc::Sender;
use crate::subscribe_task::{SubscriptionTask};
use crate::subscribe_task::task::{clipboard_task::ClipboardTask, cpu_load_task::CpuLoadTask};

pub(crate) struct TaskManager {
    tasks: Arc<DashMap<String, Arc<Mutex<dyn SubscriptionTask>>>>,
}

impl TaskManager {
    pub(crate) fn new() -> Self {
        let mut tm = TaskManager {
            tasks: Arc::new(DashMap::new()),
        };
        // 预加载任务
        tm.tasks.insert("cpu_load".to_string(), Arc::new(Mutex::new(CpuLoadTask::new())));
        tm.tasks.insert("clipboard".to_string(), Arc::new(Mutex::new(ClipboardTask::new())));
        tm
    }

    // 批量添加任务到管理器
    async fn add_tasks(&self, tasks: Vec<(String, Arc<Mutex<dyn SubscriptionTask>>)>) {
        for (task_name, task) in tasks {
            self.tasks.insert(task_name.clone(), task);
            println!("任务 {} 已添加", task_name);
        }
    }
    async fn add_task(&self, task_name: String, task: Arc<Mutex<dyn SubscriptionTask>>) {
        self.tasks.insert(task_name.clone(), task);
        println!("任务 {} 已添加", task_name);
    }

    pub(crate) fn get_task(&self, name: &str) -> Option<Arc<Mutex<dyn SubscriptionTask>>> {
        self.tasks.get(name).map(|t| t.clone())
    }

    pub(crate) fn start_task(&self, topic_name: &str, sender: Sender<String>) -> Result<()> {
        let tasks = self.tasks.clone();
        let task_option = tasks.get(topic_name);
        if task_option.is_none() {
            return Err(anyhow::anyhow!("Subscription Task not found"));
        }
        let task = task_option.unwrap().clone();
        tokio::spawn(async move {
            let task_clone = task.clone();
            let mut locked_task = task_clone.lock().await;
            locked_task.run(sender).await;
        });
        return Ok(());
    }

    pub(crate) fn stop_task(&self, topic_name: &str) {
        if let Some(task) = self.tasks.get(topic_name) {
            let task_clone = task.clone();
            tokio::spawn(async move {
                task_clone.lock().await.stop();
            });
        }
    }
}