use std::sync::Arc;
use anyhow::{Error, Result};
use dashmap::DashMap;
use log::{error, info};
use tokio::sync::mpsc::Receiver;
use crate::subscribe_task::task_manager::TaskManager;
use crate::subscribe_task::{Client, Topic};


// 主题管理器
pub(crate) struct TopicManager {
    topics: DashMap<String, Arc<Topic>>,
    task_manager: TaskManager,
}


impl TopicManager {
    pub(crate) fn new() -> Self {
        TopicManager {
            topics: DashMap::new(),
            task_manager: TaskManager::new(),
        }
    }

    fn get_or_create_topic(&self, name: &str) -> Arc<Topic> {
        self.topics.entry(name.to_string()).or_insert_with(|| {
            let (tx, rx) = tokio::sync::mpsc::channel(1000);
            let topic = Arc::new(Topic {
                name: name.to_string(),
                subscribers: Arc::new(DashMap::new()),
                broadcaster: tx,
            });

            let topic_clone = topic.clone();
            tokio::spawn(async move {
                Self::run_broadcaster(topic_clone, rx).await;
            });

            topic
        }).clone()
    }

    async fn run_broadcaster(topic: Arc<Topic>, mut rx: Receiver<String>) {
        while let Some(message) = rx.recv().await {
            info!("message:{}",message);
            // 我们克隆了 subscribers DashMap，这样可以避免在发送消息时长时间持有锁。
            let subscribers = topic.subscribers.clone();
            // 我们将消息发送操作放在一个新的 tokio 任务中，这样可以并行处理多个消息，提高吞吐量。
            tokio::spawn(async move {
                info!("Sending message to {} subscribers", subscribers.len());
                for client in subscribers.iter() {
                    //  对于每个客户端，我们克隆 sender，这样可以避免在发送过程中持有 DashMap 的引用。
                    let client_sender = client.value().sender.clone();
                    info!("Sending message to client {}", client.key());
                    if let Err(e) = client_sender.send(message.clone()).await {
                        error!("Failed to send message to client {}: {}", client.key(), e);
                        // 可以考虑在这里移除失效的客户端
                    }
                }
            });
        }
    }


    pub(crate) fn subscribe(&self, topic_name: &str, client: Client) -> Result<()> {
        let topic = self.get_or_create_topic(topic_name);
        topic.subscribers.insert(client.id.clone(), client);
        if topic.subscribers.len() == 1 {
            return self.task_manager.start_task(&topic.name, topic.broadcaster.clone());
        }
        Ok(())
    }

    pub(crate) fn unsubscribe(&self, topic_name: &str, client_id: &str) {
        if let Some(topic) = self.topics.get(topic_name) {
            topic.subscribers.remove(client_id);
            // 停止任务(如果没有订阅者)
            if topic.subscribers.is_empty() {
                self.task_manager.stop_task(&topic.name)
            }
        }
    }
}
