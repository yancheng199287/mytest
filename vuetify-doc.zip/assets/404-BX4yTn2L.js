import { d as defineComponent, u as useHead, c as createBlock, w as withCtx, a as useRoute, r as resolveComponent, o as openBlock, b as createVNode, e as createBaseVNode, f as unref, g as rpath, h as createTextVNode, _ as _sfc_main$2 } from "./index-DGybHjCP.js";
import _sfc_main$1 from "./default-C0WtPqzz.js";
import "./Drawer-SbZ4cLFe.js";
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("h1", { class: "text-h3 text-primary" }, " Whoops, 404 ", -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "The page you were looking for does not exist", -1);
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "404",
  setup(__props) {
    const route = useRoute();
    useHead({
      title: "Page not found"
    });
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_AppLink = _sfc_main$2;
      const _component_v_col = resolveComponent("v-col");
      const _component_v_row = resolveComponent("v-row");
      const _component_v_container = resolveComponent("v-container");
      return openBlock(), createBlock(_sfc_main$1, null, {
        default: withCtx(() => [
          createVNode(_component_v_container, {
            style: { minHeight: "100%" },
            class: "d-flex"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_row, {
                align: "center",
                justify: "center"
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_col, { cols: "auto" }, {
                    default: withCtx(() => [
                      _hoisted_1,
                      _hoisted_2,
                      createBaseVNode("p", null, [
                        createVNode(_component_v_btn, {
                          to: ("rpath" in _ctx ? _ctx.rpath : unref(rpath))("/getting-started/installation/"),
                          color: "primary",
                          variant: "outlined"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Get me out of here! ")
                          ]),
                          _: 1
                        }, 8, ["to"])
                      ]),
                      createBaseVNode("p", null, [
                        createVNode(_component_AppLink, {
                          href: "https://v2.vuetifyjs.com" + unref(route).fullPath
                        }, {
                          default: withCtx(() => [
                            createTextVNode("Looking for Vuetify 2?")
                          ]),
                          _: 1
                        }, 8, ["href"])
                      ])
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default
};
