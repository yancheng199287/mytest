import { N as F, j as computed, r as resolveComponent, o as openBlock, c as createBlock, f as unref, d as defineComponent, a5 as P, l as createElementBlock, b as createVNode, e as createBaseVNode, q as createCommentVNode, F as Fragment, a6 as _sfc_main$4, a7 as _sfc_main$5, a8 as usePinsStore, n as useRouter, J as ref, K as onBeforeMount, O as watch, w as withCtx, a9 as mergeProps, V as withModifiers, E as isRef, aa as _sfc_main$6, m as useAppStore, ab as Pe, ac as useDisplay, ad as scrollTo, P as onMounted, ae as wait } from "./index-DGybHjCP.js";
const _sfc_main$3 = {
  __name: "DrawerToggleRail",
  setup(__props) {
    const user = F();
    const icon = computed(() => {
      return user.railDrawer ? "mdi-chevron-double-right" : "mdi-chevron-double-left";
    });
    function onClick() {
      user.railDrawer = !user.railDrawer;
    }
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      return openBlock(), createBlock(_component_v_btn, {
        icon: unref(icon),
        height: "28",
        size: "small",
        variant: "text",
        rounded: "",
        onClick
      }, null, 8, ["icon"]);
    };
  }
};
const _hoisted_1 = { class: "d-flex align-center text-caption text-medium-emphasis pa-2" };
const _hoisted_2 = { class: "d-flex ms-auto overflow-hidden" };
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "Append",
  setup(__props) {
    const one = P();
    return (_ctx, _cache) => {
      const _component_v_divider = resolveComponent("v-divider");
      const _component_AppDrawerDrawerToggleRail = _sfc_main$3;
      const _component_AppCommitBtn = _sfc_main$4;
      const _component_AppVersionBtn = _sfc_main$5;
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(_component_v_divider),
        createBaseVNode("div", _hoisted_1, [
          unref(one).isSubscriber ? (openBlock(), createBlock(_component_AppDrawerDrawerToggleRail, {
            key: 0,
            class: "me-2"
          })) : createCommentVNode("", true),
          createBaseVNode("div", _hoisted_2, [
            createVNode(_component_AppCommitBtn, { class: "me-2" }),
            createVNode(_component_AppVersionBtn)
          ])
        ])
      ], 64);
    };
  }
});
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "PinnedItems",
  props: {
    rail: { type: Boolean }
  },
  setup(__props) {
    const props = __props;
    const one = P();
    const pins = usePinsStore();
    const user = F();
    const router = useRouter();
    const _opened = ref([]);
    const opened = computed({
      get: () => props.rail ? [] : _opened.value,
      set: (val) => _opened.value = val
    });
    const pinned = computed(() => [{
      activeIcon: "mdi-pin",
      inactiveIcon: "mdi-pin-outline",
      items: [...pins.pins],
      title: "Pinned"
    }]);
    async function onClickPin(to) {
      pins.isPinning = true;
      await router.replace(to);
      pins.isPinning = false;
    }
    function onClickPinRemove(pin) {
      pins.toggle(false, pin);
    }
    onBeforeMount(() => {
      pins.load();
    });
    watch(() => pins.pins, (val, oldVal) => {
      if (val.length < oldVal.length)
        return;
      opened.value = ["Pinned"];
    });
    return (_ctx, _cache) => {
      const _component_v_icon = resolveComponent("v-icon");
      const _component_v_list_item = resolveComponent("v-list-item");
      const _component_v_hover = resolveComponent("v-hover");
      const _component_AppListList = _sfc_main$6;
      return unref(one).isSubscriber && unref(user).pins ? (openBlock(), createBlock(_component_AppListList, {
        key: 0,
        opened: unref(opened),
        "onUpdate:opened": _cache[0] || (_cache[0] = ($event) => isRef(opened) ? opened.value = $event : null),
        items: unref(pinned),
        class: "pb-0 mb-n2",
        nav: ""
      }, {
        item: withCtx(({ props: itemProps }) => [
          createVNode(_component_v_hover, null, {
            default: withCtx(({ props: activatorProps, isHovering }) => [
              createVNode(_component_v_list_item, mergeProps({
                title: itemProps.title,
                to: itemProps.to,
                class: "mb-1"
              }, activatorProps, {
                onClick: withModifiers(($event) => onClickPin(itemProps.to), ["prevent"])
              }), {
                append: withCtx(() => [
                  isHovering ? (openBlock(), createBlock(_component_v_icon, {
                    key: 0,
                    class: "me-1",
                    icon: "mdi-pin-off",
                    size: "16",
                    onClick: withModifiers(($event) => onClickPinRemove({
                      title: itemProps.title,
                      to: itemProps.to,
                      category: ""
                    }), ["prevent", "stop"])
                  }, null, 8, ["onClick"])) : createCommentVNode("", true)
                ]),
                _: 2
              }, 1040, ["title", "to", "onClick"])
            ]),
            _: 2
          }, 1024)
        ]),
        _: 1
      }, 8, ["opened", "items"])) : createCommentVNode("", true);
    };
  }
});
const _sfc_main = {
  __name: "Drawer",
  setup(__props) {
    const app = useAppStore();
    const pins = usePinsStore();
    const settings = Pe();
    const user = F();
    const { mobile } = useDisplay();
    const rail = ref(user.railDrawer);
    const _opened = ref([]);
    const opened = computed({
      get: () => rail.value ? [] : _opened.value,
      set: (val) => {
        if (pins.isPinning)
          return;
        _opened.value = val;
      }
    });
    const railEnabled = computed(() => user.railDrawer);
    let scrollingElement;
    let lastScroll = 0;
    watch(rail, (val) => {
      if (val) {
        lastScroll = scrollingElement.scrollTop;
      } else {
        scrollTo(lastScroll, {
          container: scrollingElement
        });
      }
    });
    watch(railEnabled, (val) => {
      rail.value = val;
    });
    onMounted(async () => {
      scrollingElement = document.querySelector("#app-drawer .v-navigation-drawer__content");
      if (pins.pageIsPinned) {
        _opened.value = [];
        return;
      }
      await wait(1e3);
      const element = document.querySelector("#app-drawer .v-list-item--active:not(.v-list-group__header)");
      if (!element)
        return;
      element.scrollIntoView({
        block: "center",
        inline: "center"
      });
    });
    function onUpdateRail(val) {
      if (railEnabled.value) {
        rail.value = val;
      }
    }
    return (_ctx, _cache) => {
      const _component_AppDrawerPinnedItems = _sfc_main$1;
      const _component_v_divider = resolveComponent("v-divider");
      const _component_AppListList = _sfc_main$6;
      const _component_AppDrawerAppend = _sfc_main$2;
      const _component_v_navigation_drawer = resolveComponent("v-navigation-drawer");
      return openBlock(), createBlock(_component_v_navigation_drawer, {
        id: "app-drawer",
        modelValue: unref(app).drawer,
        "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => unref(app).drawer = $event),
        "expand-on-hover": unref(railEnabled),
        image: unref(settings).suit["drawer"],
        order: unref(mobile) ? -1 : void 0,
        rail: unref(railEnabled),
        width: "300",
        "onUpdate:rail": onUpdateRail
      }, {
        append: withCtx(() => [
          createVNode(_component_AppDrawerAppend)
        ]),
        default: withCtx(() => [
          createVNode(_component_AppDrawerPinnedItems, { rail: unref(rail) }, null, 8, ["rail"]),
          createVNode(_component_AppListList, {
            opened: unref(opened),
            "onUpdate:opened": _cache[0] || (_cache[0] = ($event) => isRef(opened) ? opened.value = $event : null),
            items: unref(app).items,
            nav: ""
          }, {
            divider: withCtx(() => [
              createVNode(_component_v_divider, { class: "my-3 mb-4 ms-10" })
            ]),
            _: 1
          }, 8, ["opened", "items"])
        ]),
        _: 1
      }, 8, ["modelValue", "expand-on-hover", "image", "order", "rail"]);
    };
  }
};
export {
  _sfc_main as _
};
