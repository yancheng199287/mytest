import { ac as useDisplay, i as useI18n, J as ref, j as computed, ai as usePlayground, r as resolveComponent, o as openBlock, l as createElementBlock, b as createVNode, w as withCtx, f as unref, E as isRef, h as createTextVNode, F as Fragment, v as renderList, c as createBlock, t as toDisplayString, s as upperFirst, a9 as mergeProps, e as createBaseVNode, Z as renderSlot, q as createCommentVNode, U as normalizeClass, aj as _sfc_main$1 } from "./index-DGybHjCP.js";
const _hoisted_1 = { class: "flex-fill" };
const _hoisted_2 = { class: "px-4 usage-example pt-2" };
const _hoisted_3 = { key: 0 };
const _hoisted_4 = { class: "pa-2" };
const _hoisted_5 = {
  key: 0,
  class: "pa-2 pt-0"
};
const _sfc_main = {
  __name: "UsageExample",
  props: {
    name: String,
    code: String,
    options: {
      type: Array,
      default: () => []
    },
    modelValue: {
      type: [Array, String],
      default: () => [],
      required: true
    },
    script: String
  },
  emits: ["update:modelValue", "update:tuneValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const display = useDisplay();
    const { t } = useI18n();
    const tune = ref(true);
    const show = ref(true);
    const model = computed({
      get() {
        return props.modelValue;
      },
      set(val) {
        emit("update:modelValue", val);
      }
    });
    const playgroundLink = computed(() => usePlayground([
      {
        name: "template",
        language: "html",
        content: `<template>
  <v-app>
    <v-container>
      ${props.code.replaceAll("\n", "\n      ")}
    </v-container>
  </v-app>
</template>
${props.script}`
      }
    ]));
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_slide_group_item = resolveComponent("v-slide-group-item");
      const _component_v_slide_group = resolveComponent("v-slide-group");
      const _component_v_tooltip = resolveComponent("v-tooltip");
      const _component_v_toolbar = resolveComponent("v-toolbar");
      const _component_v_sheet = resolveComponent("v-sheet");
      const _component_v_main = resolveComponent("v-main");
      const _component_v_defaults_provider = resolveComponent("v-defaults-provider");
      const _component_v_list = resolveComponent("v-list");
      const _component_v_navigation_drawer = resolveComponent("v-navigation-drawer");
      const _component_v_layout = resolveComponent("v-layout");
      const _component_AppMarkup = _sfc_main$1;
      const _component_v_expand_transition = resolveComponent("v-expand-transition");
      return openBlock(), createElementBlock("div", null, [
        createVNode(_component_v_toolbar, {
          border: "b",
          class: "ps-1",
          height: "44",
          flat: ""
        }, {
          default: withCtx(() => [
            createVNode(_component_v_slide_group, {
              modelValue: unref(model),
              "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(model) ? model.value = $event : null),
              class: "flex-grow-1",
              mandatory: "",
              "show-arrows": ""
            }, {
              default: withCtx(() => [
                createVNode(_component_v_slide_group_item, { value: "default" }, {
                  default: withCtx(({ isSelected, toggle }) => [
                    createVNode(_component_v_btn, {
                      active: isSelected,
                      class: "ma-1 text-none",
                      size: "small",
                      variant: "text",
                      onClick: toggle
                    }, {
                      default: withCtx(() => [
                        createTextVNode(" Default ")
                      ]),
                      _: 2
                    }, 1032, ["active", "onClick"])
                  ]),
                  _: 1
                }),
                (openBlock(true), createElementBlock(Fragment, null, renderList(__props.options, (option, i) => {
                  return openBlock(), createBlock(_component_v_slide_group_item, {
                    key: i,
                    value: option
                  }, {
                    default: withCtx(({ isSelected, toggle }) => [
                      createVNode(_component_v_btn, {
                        active: isSelected,
                        class: "ma-1 text-none",
                        size: "small",
                        variant: "text",
                        onClick: toggle
                      }, {
                        default: withCtx(() => [
                          createTextVNode(toDisplayString(("upperFirst" in _ctx ? _ctx.upperFirst : unref(upperFirst))(option)), 1)
                        ]),
                        _: 2
                      }, 1032, ["active", "onClick"])
                    ]),
                    _: 2
                  }, 1032, ["value"]);
                }), 128))
              ]),
              _: 1
            }, 8, ["modelValue"]),
            createVNode(_component_v_tooltip, { location: "bottom" }, {
              activator: withCtx(({ props: activatorProps }) => [
                createVNode(_component_v_btn, mergeProps({
                  href: unref(playgroundLink),
                  class: "me-1 text-medium-emphasis",
                  density: "comfortable",
                  icon: "$vuetify-play",
                  target: "_blank"
                }, activatorProps), null, 16, ["href"])
              ]),
              default: withCtx(() => [
                createBaseVNode("span", null, toDisplayString(unref(t)("edit-in-playground")), 1)
              ]),
              _: 1
            }),
            createVNode(_component_v_tooltip, { location: "bottom" }, {
              activator: withCtx(({ props: activatorProps }) => [
                createVNode(_component_v_btn, mergeProps({
                  icon: !unref(show) ? "mdi-code-tags" : "mdi-chevron-up",
                  class: "me-1 text-medium-emphasis",
                  density: "comfortable"
                }, activatorProps, {
                  onClick: _cache[1] || (_cache[1] = ($event) => show.value = !unref(show))
                }), null, 16, ["icon"])
              ]),
              default: withCtx(() => [
                createBaseVNode("span", null, toDisplayString(unref(show) ? unref(t)("hide-source") : unref(t)("view-source")), 1)
              ]),
              _: 1
            })
          ]),
          _: 1
        }),
        createVNode(_component_v_layout, {
          class: normalizeClass(["border-b", !unref(show) && "border-opacity-0"])
        }, {
          default: withCtx(() => [
            createVNode(_component_v_main, null, {
              default: withCtx(() => [
                createVNode(_component_v_sheet, {
                  class: "py-14 px-4 d-flex align-center",
                  "min-height": "300",
                  rounded: "0"
                }, {
                  default: withCtx(() => [
                    createBaseVNode("div", _hoisted_1, [
                      renderSlot(_ctx.$slots, "default")
                    ])
                  ]),
                  _: 3
                })
              ]),
              _: 3
            }),
            unref(display).smAndUp.value && _ctx.$slots.configuration ? (openBlock(), createBlock(_component_v_navigation_drawer, {
              key: 0,
              modelValue: unref(tune),
              "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => isRef(tune) ? tune.value = $event : null),
              location: "right",
              name: "tune",
              width: "250",
              permanent: "",
              touchless: ""
            }, {
              default: withCtx(() => [
                createVNode(_component_v_list, null, {
                  default: withCtx(() => [
                    createBaseVNode("div", _hoisted_2, [
                      createVNode(_component_v_defaults_provider, { defaults: {
                        global: {
                          density: "compact",
                          hideDetails: true,
                          step: 1
                        }
                      } }, {
                        default: withCtx(() => [
                          renderSlot(_ctx.$slots, "configuration")
                        ]),
                        _: 3
                      })
                    ])
                  ]),
                  _: 3
                })
              ]),
              _: 3
            }, 8, ["modelValue"])) : createCommentVNode("", true)
          ]),
          _: 3
        }, 8, ["class"]),
        createVNode(_component_v_expand_transition, null, {
          default: withCtx(() => [
            unref(show) ? (openBlock(), createElementBlock("div", _hoisted_3, [
              createBaseVNode("div", _hoisted_4, [
                createVNode(_component_AppMarkup, { code: __props.code }, null, 8, ["code"])
              ]),
              __props.script ? (openBlock(), createElementBlock("div", _hoisted_5, [
                createVNode(_component_AppMarkup, {
                  code: __props.script,
                  language: "js"
                }, null, 8, ["code"])
              ])) : createCommentVNode("", true)
            ])) : createCommentVNode("", true)
          ]),
          _: 1
        })
      ]);
    };
  }
};
export {
  _sfc_main as _
};
