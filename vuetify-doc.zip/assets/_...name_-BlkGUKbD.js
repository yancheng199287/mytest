import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "api-explorer" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "Quickly search the Vuetify API for components, directives, and composables", -1);
const frontmatter = { "backmatter": false, "fluid": true, "meta": { "nav": "API Explorer", "title": "API Explorer", "description": "Explore the Vuetify API", "keywords": "vuetify api explorer" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "[...name]",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "API Explorer", "title": "API Explorer", "description": "Explore the Vuetify API", "keywords": "vuetify api explorer" } };
    useHead(head);
    __expose({ frontmatter: { "backmatter": false, "fluid": true, "meta": { "nav": "API Explorer", "title": "API Explorer", "description": "Explore the Vuetify API", "keywords": "vuetify api explorer" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_app_divider = resolveComponent("app-divider");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_doc_explorer = resolveComponent("doc-explorer");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#api-explorer",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("API Explorer")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_app_divider),
              createVNode(_component_promoted_entry),
              createVNode(_component_doc_explorer)
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
