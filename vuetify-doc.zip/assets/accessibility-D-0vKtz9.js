import { J as ref, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, b as createVNode, l as createElementBlock, F as Fragment, v as renderList, a9 as mergeProps, h as createTextVNode, y as _export_sfc, ak as normalizeProps, al as guardReactiveProps, t as toDisplayString } from "./index-DGybHjCP.js";
const _sfc_main$2 = {
  __name: "list-item-group",
  setup(__props) {
    const items = [
      {
        text: "Item 1",
        disabled: false
      },
      {
        text: "Item 2",
        disabled: true
      },
      {
        text: "Item 3",
        disabled: false
      }
    ];
    const model = ref(0);
    return (_ctx, _cache) => {
      const _component_v_list_item = resolveComponent("v-list-item");
      const _component_v_list_item_group = resolveComponent("v-list-item-group");
      const _component_v_list = resolveComponent("v-list");
      const _component_v_card = resolveComponent("v-card");
      return openBlock(), createBlock(_component_v_card, {
        class: "mx-auto",
        "max-width": "500"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_list, null, {
            default: withCtx(() => [
              createVNode(_component_v_list_item_group, {
                modelValue: model.value,
                "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => model.value = $event)
              }, {
                default: withCtx(() => [
                  (openBlock(), createElementBlock(Fragment, null, renderList(items, (item, i) => {
                    return createVNode(_component_v_list_item, {
                      key: i,
                      disabled: item.disabled,
                      title: item.text
                    }, null, 8, ["disabled", "title"]);
                  }), 64))
                ]),
                _: 1
              }, 8, ["modelValue"])
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __0 = _sfc_main$2;
const __0_raw = `<template>
  <v-card
    class="mx-auto"
    max-width="500"
  >
    <v-list>
      <v-list-item-group v-model="model">
        <v-list-item
          v-for="(item, i) in items"
          :key="i"
          :disabled="item.disabled"
          :title="item.text"
        >
        </v-list-item>
      </v-list-item-group>
    </v-list>
  </v-card>
</template>

<script setup>
  import { ref } from 'vue'

  const items = [
    {
      text: 'Item 1',
      disabled: false,
    },
    {
      text: 'Item 2',
      disabled: true,
    },
    {
      text: 'Item 3',
      disabled: false,
    },
  ]

  const model = ref(0)
<\/script>

<script>
  export default {
    data: () => ({
      items: [
        {
          text: 'Item 1',
          disabled: false,
        },
        {
          text: 'Item 2',
          disabled: true,
        },
        {
          text: 'Item 3',
          disabled: false,
        },
      ],
      model: 0,
    }),
  }
<\/script>
`;
const _hoisted_1 = { class: "text-center" };
const _sfc_main$1 = {
  __name: "menu",
  setup(__props) {
    function onClick() {
    }
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_list_item_title = resolveComponent("v-list-item-title");
      const _component_v_list_item = resolveComponent("v-list-item");
      const _component_v_list = resolveComponent("v-list");
      const _component_v_menu = resolveComponent("v-menu");
      return openBlock(), createElementBlock("div", _hoisted_1, [
        createVNode(_component_v_menu, null, {
          activator: withCtx(({ props: activatorProps }) => [
            createVNode(_component_v_btn, mergeProps({ text: "Click me" }, activatorProps), null, 16)
          ]),
          default: withCtx(() => [
            createVNode(_component_v_list, null, {
              default: withCtx(() => [
                createVNode(_component_v_list_item, { onClick }, {
                  default: withCtx(() => [
                    createVNode(_component_v_list_item_title, null, {
                      default: withCtx(() => [
                        createTextVNode("Option 1")
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                }),
                createVNode(_component_v_list_item, { disabled: "" }, {
                  default: withCtx(() => [
                    createVNode(_component_v_list_item_title, null, {
                      default: withCtx(() => [
                        createTextVNode("Option 2")
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                }),
                createVNode(_component_v_list_item, { onClick }, {
                  default: withCtx(() => [
                    createVNode(_component_v_list_item_title, null, {
                      default: withCtx(() => [
                        createTextVNode("Option 3")
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                })
              ]),
              _: 1
            })
          ]),
          _: 1
        })
      ]);
    };
  }
};
const __1 = _sfc_main$1;
const __1_raw = '<template>\n  <div class="text-center">\n    <v-menu>\n      <template v-slot:activator="{ props: activatorProps }">\n        <v-btn text="Click me" v-bind="activatorProps"></v-btn>\n      </template>\n\n      <v-list>\n        <v-list-item @click="onClick">\n          <v-list-item-title>Option 1</v-list-item-title>\n        </v-list-item>\n\n        <v-list-item disabled>\n          <v-list-item-title>Option 2</v-list-item-title>\n        </v-list-item>\n\n        <v-list-item @click="onClick">\n          <v-list-item-title>Option 3</v-list-item-title>\n        </v-list-item>\n      </v-list>\n    </v-menu>\n  </div>\n</template>\n\n<script setup>\n  function onClick () {\n        // Perform an action\n  }\n<\/script>\n\n<script>\n  export default {\n    methods: {\n      onClick () {\n        // Perform an action\n      },\n    },\n  }\n<\/script>\n';
const _sfc_main = {};
function _sfc_render(_ctx, _cache) {
  const _component_v_list_item = resolveComponent("v-list-item");
  const _component_v_select = resolveComponent("v-select");
  return openBlock(), createBlock(_component_v_select, {
    items: ["Foo", "Bar", "Fizz", "Buzz"],
    label: "Fizzbuzz"
  }, {
    item: withCtx(({ item, props }) => [
      createVNode(_component_v_list_item, normalizeProps(guardReactiveProps(props)), {
        title: withCtx(() => [
          createTextVNode(toDisplayString(item.raw), 1)
        ]),
        _: 2
      }, 1040)
    ]),
    _: 1
  });
}
const __2 = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
const __2_raw = `<template>
  <v-select
    :items="['Foo', 'Bar', 'Fizz', 'Buzz']"
    label="Fizzbuzz"
  >
    <template v-slot:item="{ item, props }">
      <v-list-item v-bind="props">
        <template v-slot:title>
          {{ item.raw }}
        </template>
      </v-list-item>
    </template>
  </v-select>
</template>
`;
const accessibility = {
  "list-item-group": {
    component: __0,
    source: __0_raw
  },
  "menu": {
    component: __1,
    source: __1_raw
  },
  "select-list-item": {
    component: __2,
    source: __2_raw
  }
};
export {
  accessibility as default
};
