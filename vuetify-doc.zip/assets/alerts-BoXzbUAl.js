import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "alerts" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-alert"),
  /* @__PURE__ */ createTextVNode(" component is used to convey important information to the user through the use of contextual types, icons, and colors.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-alert", -1);
const _hoisted_5 = { id: "api" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createTextVNode("Sub-component used to display the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-alert"),
  /* @__PURE__ */ createTextVNode(" title. Wraps the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "#title"),
  /* @__PURE__ */ createTextVNode(" slot")
], -1);
const _hoisted_9 = { id: "anatomy" };
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The recommended placement of elements inside of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-alert"),
  /* @__PURE__ */ createTextVNode(" is:")
], -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Place a "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-icon"),
    /* @__PURE__ */ createTextVNode(" on the far left")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Place "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-alert-title"),
    /* @__PURE__ */ createTextVNode(" to the right of the contextual icon")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, "Place textual content below the title"),
  /* @__PURE__ */ createBaseVNode("li", null, "Place closing actions to the far right")
], -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Element / Area"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("tbody", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "1. Container"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("The Alert container holds all "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-alert"),
      /* @__PURE__ */ createTextVNode(" components")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "2. Icon"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("An icon that correlates to the contextual state of the alert; "),
      /* @__PURE__ */ createBaseVNode("strong", null, "success, info, warning, error")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "3. Title"),
    /* @__PURE__ */ createBaseVNode("td", null, "A heading with increased font-size")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "4. Text"),
    /* @__PURE__ */ createBaseVNode("td", null, "A content area for displaying text and other inline elements")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "5. Close Icon (optional)"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("Used to hide the "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-alert"),
      /* @__PURE__ */ createTextVNode(" component")
    ])
  ])
], -1);
const _hoisted_14 = { id: "guide" };
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-alert", -1);
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-alert", -1);
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("strong", null, "type", -1);
const _hoisted_18 = { id: "props" };
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-alert", -1);
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("strong", null, "v-model", -1);
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("strong", null, "variants", -1);
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("strong", null, "density", -1);
const _hoisted_23 = { id: "content" };
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-alert"),
  /* @__PURE__ */ createTextVNode(" component supports simple content using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "title"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "text"),
  /* @__PURE__ */ createTextVNode(" props. This approach is best for strings that do not need custom styling.")
], -1);
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The following code snippet is an example of a basic "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-alert"),
  /* @__PURE__ */ createTextVNode(" component only containing text:")
], -1);
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-html" }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-alert")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "text"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus..."),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("v-alert")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("p", null, "Adding a title is as easy as defining its value. The next example adds a string title to accompany the content text:", -1);
const _hoisted_28 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Notice how the alert does not have a color or icon. This is defined using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "type"),
  /* @__PURE__ */ createTextVNode(" property.")
], -1);
const _hoisted_29 = { id: "type" };
const _hoisted_30 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Alerts have 4 contextual states: "),
  /* @__PURE__ */ createBaseVNode("strong", null, "success"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "info"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "warning"),
  /* @__PURE__ */ createTextVNode(", and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "error"),
  /* @__PURE__ */ createTextVNode(". Each state has a default "),
  /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "color"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "icon"),
  /* @__PURE__ */ createTextVNode(" associated with it. When a "),
  /* @__PURE__ */ createBaseVNode("strong", null, "type"),
  /* @__PURE__ */ createTextVNode(" is not provided, the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-alert"),
  /* @__PURE__ */ createTextVNode(" component defaults to a greyish background.")
], -1);
const _hoisted_31 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("With a basic alert rendered, add your choice of contextual type. The following example puts the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-alert"),
  /* @__PURE__ */ createTextVNode(" component in a success state:")
], -1);
const _hoisted_32 = { id: "type-reference" };
const _hoisted_33 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Type"),
    /* @__PURE__ */ createBaseVNode("th", null, "Color"),
    /* @__PURE__ */ createBaseVNode("th", null, "Icon alias"),
    /* @__PURE__ */ createBaseVNode("th", { style: { "text-align": "center" } }, "Icon")
  ])
], -1);
const _hoisted_34 = /* @__PURE__ */ createBaseVNode("td", null, "Success", -1);
const _hoisted_35 = /* @__PURE__ */ createBaseVNode("td", { class: "text-success" }, [
  /* @__PURE__ */ createBaseVNode("strong", null, "success")
], -1);
const _hoisted_36 = /* @__PURE__ */ createBaseVNode("td", null, "$success", -1);
const _hoisted_37 = { style: { "text-align": "center" } };
const _hoisted_38 = /* @__PURE__ */ createBaseVNode("td", null, "Info", -1);
const _hoisted_39 = /* @__PURE__ */ createBaseVNode("td", { class: "text-info" }, [
  /* @__PURE__ */ createBaseVNode("strong", null, "info")
], -1);
const _hoisted_40 = /* @__PURE__ */ createBaseVNode("td", null, "$info", -1);
const _hoisted_41 = { style: { "text-align": "center" } };
const _hoisted_42 = /* @__PURE__ */ createBaseVNode("td", null, "Warning", -1);
const _hoisted_43 = /* @__PURE__ */ createBaseVNode("td", { class: "text-warning" }, [
  /* @__PURE__ */ createBaseVNode("strong", null, "warning")
], -1);
const _hoisted_44 = /* @__PURE__ */ createBaseVNode("td", null, "$warning", -1);
const _hoisted_45 = { style: { "text-align": "center" } };
const _hoisted_46 = /* @__PURE__ */ createBaseVNode("td", null, "Error", -1);
const _hoisted_47 = /* @__PURE__ */ createBaseVNode("td", { class: "text-error" }, [
  /* @__PURE__ */ createBaseVNode("strong", null, "error")
], -1);
const _hoisted_48 = /* @__PURE__ */ createBaseVNode("td", null, "$error", -1);
const _hoisted_49 = { style: { "text-align": "center" } };
const _hoisted_50 = { id: "color-and-icon" };
const _hoisted_51 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "type"),
  /* @__PURE__ */ createTextVNode(" property acts as a shorthand for a "),
  /* @__PURE__ */ createBaseVNode("strong", null, "color"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "icon"),
  /* @__PURE__ */ createTextVNode(" combination, you can use both props individually to achieve the same effect. The following example produces the same result as using "),
  /* @__PURE__ */ createBaseVNode("strong", null, "type=“success”"),
  /* @__PURE__ */ createTextVNode(" by defining a custom color and using the icon lookup table to get the globally defined success icon:")
], -1);
const _hoisted_52 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-html" }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-alert")
      ]),
      /* @__PURE__ */ createTextVNode("\n  "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "color"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("success"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createTextVNode("\n  "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "icon"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("$success"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createTextVNode("\n  "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "title"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("Alert title"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createTextVNode("\n  "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "text"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus..."),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createTextVNode("\n"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("v-alert")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_53 = { id: "density" };
const _hoisted_54 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-alert"),
  /* @__PURE__ */ createTextVNode(" component has the ability to reduce its height in intervals using the density prop. This is useful when you need to reduce the vertical space a component needs. The following example reduces the vertical space by using "),
  /* @__PURE__ */ createBaseVNode("strong", null, "density=“compact”"),
  /* @__PURE__ */ createTextVNode(":")
], -1);
const _hoisted_55 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "density"),
  /* @__PURE__ */ createTextVNode(" prop supports 3 levels of component height; "),
  /* @__PURE__ */ createBaseVNode("strong", null, "default"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "comfortable"),
  /* @__PURE__ */ createTextVNode(", and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "compact"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_56 = { id: "variants" };
const _hoisted_57 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-alert"),
  /* @__PURE__ */ createTextVNode(" has 6 style variants, "),
  /* @__PURE__ */ createBaseVNode("strong", null, "elevated"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "flat"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "tonal"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "outlined"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "text"),
  /* @__PURE__ */ createTextVNode(", and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "plain"),
  /* @__PURE__ */ createTextVNode(". By default, the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-alert"),
  /* @__PURE__ */ createTextVNode(" component is "),
  /* @__PURE__ */ createBaseVNode("strong", null, "flat"),
  /* @__PURE__ */ createTextVNode("; which means that it has a solid background and no box-shadow (elevation). The following example modifies the overall styling of the alert with a custom variant:")
], -1);
const _hoisted_58 = { id: "closable" };
const _hoisted_59 = /* @__PURE__ */ createBaseVNode("strong", null, "closable", -1);
const _hoisted_60 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-alert", -1);
const _hoisted_61 = /* @__PURE__ */ createBaseVNode("strong", null, "false", -1);
const _hoisted_62 = /* @__PURE__ */ createBaseVNode("strong", null, "v-model", -1);
const _hoisted_63 = /* @__PURE__ */ createBaseVNode("strong", null, "model-value", -1);
const _hoisted_64 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-alert", -1);
const _hoisted_65 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The close icon automatically applies a default "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "aria-label"),
  /* @__PURE__ */ createTextVNode(" and is configurable by using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "close-label"),
  /* @__PURE__ */ createTextVNode(" prop or changing "),
  /* @__PURE__ */ createBaseVNode("strong", null, "close"),
  /* @__PURE__ */ createTextVNode(" value in your locale.")
], -1);
const _hoisted_66 = { id: "additional-examples" };
const _hoisted_67 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The following is a collection of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-alert"),
  /* @__PURE__ */ createTextVNode(" examples that demonstrate how different the properties work in an application.")
], -1);
const _hoisted_68 = { id: "border-color" };
const _hoisted_69 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "border-color"),
  /* @__PURE__ */ createTextVNode(" prop removes the alert background in order to accent the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "border"),
  /* @__PURE__ */ createTextVNode(" prop. If a "),
  /* @__PURE__ */ createBaseVNode("strong", null, "type"),
  /* @__PURE__ */ createTextVNode(" is set, it will use the type’s default color. If no "),
  /* @__PURE__ */ createBaseVNode("strong", null, "color"),
  /* @__PURE__ */ createTextVNode(" or "),
  /* @__PURE__ */ createBaseVNode("strong", null, "type"),
  /* @__PURE__ */ createTextVNode(" is set, the color will default to the inverted color of the applied theme (black for light and white/gray for dark).")
], -1);
const _hoisted_70 = { id: "icon" };
const _hoisted_71 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "icon"),
  /* @__PURE__ */ createTextVNode(" prop allows you to add an icon to the beginning of the alert component. If a "),
  /* @__PURE__ */ createBaseVNode("strong", null, "type"),
  /* @__PURE__ */ createTextVNode(" is provided, this will override the default type icon. Additionally, setting the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "icon"),
  /* @__PURE__ */ createTextVNode(" prop to "),
  /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "false"),
  /* @__PURE__ */ createTextVNode(" will remove the icon altogether.")
], -1);
const _hoisted_72 = { id: "outlined" };
const _hoisted_73 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "outlined"),
  /* @__PURE__ */ createTextVNode(" prop inverts the style of an alert, inheriting the currently applied "),
  /* @__PURE__ */ createBaseVNode("strong", null, "color"),
  /* @__PURE__ */ createTextVNode(", applying it to the text and border, and making its background transparent.")
], -1);
const _hoisted_74 = { id: "accessibility" };
const _hoisted_75 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-alert", -1);
const _hoisted_76 = /* @__PURE__ */ createBaseVNode("strong", null, "alert", -1);
const _hoisted_77 = /* @__PURE__ */ createBaseVNode("strong", null, "closable", -1);
const _hoisted_78 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "aria-label", -1);
const _hoisted_79 = /* @__PURE__ */ createBaseVNode("strong", null, "close-label", -1);
const _hoisted_80 = /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "close", -1);
const frontmatter = { "meta": { "nav": "Alerts", "title": "Alert component", "description": "The v-alert component is used to convey information to the user. Designed to stand out, the alerts come in four contextual styles.", "keywords": "v-alert, alerts, vue alert component, vuetify alert component" }, "related": ["/components/buttons/", "/components/icons/", "/components/snackbars/"], "features": { "figma": true, "github": "/components/VAlert/", "label": "C: VAlert", "report": true } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "alerts",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Alerts", "title": "Alert component", "description": "The v-alert component is used to convey information to the user. Designed to stand out, the alerts come in four contextual styles.", "keywords": "v-alert, alerts, vue alert component, vuetify alert component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Alerts", "title": "Alert component", "description": "The v-alert component is used to convey information to the user. Designed to stand out, the alerts come in four contextual styles.", "keywords": "v-alert, alerts, vue alert component, vuetify alert component" }, "related": ["/components/buttons/", "/components/icons/", "/components/snackbars/"], "features": { "figma": true, "github": "/components/VAlert/", "label": "C: VAlert", "report": true } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_app_figure = resolveComponent("app-figure");
      const _component_page_features = resolveComponent("page-features");
      const _component_app_link = resolveComponent("app-link");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_app_markup = resolveComponent("app-markup");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_v_icon = resolveComponent("v-icon");
      const _component_alert = resolveComponent("alert");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#alerts",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Alerts")
                ]),
                _: 1
              }),
              _hoisted_2,
              createBaseVNode("p", null, [
                createBaseVNode("div", null, [
                  createVNode(_component_app_figure, {
                    alt: "Alert Entry",
                    src: "https://cdn.vuetifyjs.com/docs/images/components-temp/v-alert/v-alert-entry.png"
                  })
                ])
              ]),
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("An alert is a "),
                  createVNode(_component_app_link, { href: "/components/sheets/" }, {
                    default: withCtx(() => [
                      createTextVNode("v-sheet")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" that specializes in getting the user’s attention. While similar to "),
                  createVNode(_component_app_link, { href: "/components/banners/" }, {
                    default: withCtx(() => [
                      createTextVNode("v-banner")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" in functionality, "),
                  _hoisted_4,
                  createTextVNode(" is typically inline with content and used multiple times throughout an application.")
                ]),
                createVNode(_component_examples_usage, { name: "v-alert" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_6,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-alert/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-alert")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-alert-title/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-alert-title")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_8
                      ])
                    ])
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_9, [
                createVNode(_component_app_heading, {
                  href: "#anatomy",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Anatomy")
                  ]),
                  _: 1
                }),
                _hoisted_10,
                _hoisted_11,
                createBaseVNode("p", null, [
                  createBaseVNode("div", null, [
                    createVNode(_component_app_figure, {
                      alt: "Alert Anatomy",
                      src: "https://cdn.vuetifyjs.com/docs/images/components-temp/v-alert/v-alert-anatomy.png"
                    })
                  ])
                ]),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_12,
                    _hoisted_13
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_14, [
                createVNode(_component_app_heading, {
                  href: "#guide",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Guide")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("The "),
                  _hoisted_15,
                  createTextVNode(" component is a callout element designed to attract the attention of a user. Unlike "),
                  createVNode(_component_app_link, { href: "/components/banners/" }, {
                    default: withCtx(() => [
                      createTextVNode("v-banner")
                    ]),
                    _: 1
                  }),
                  createTextVNode(", the "),
                  _hoisted_16,
                  createTextVNode(" component is intended to be used and re-used throughout your application. An alert’s color is derived from its "),
                  _hoisted_17,
                  createTextVNode(" property which corresponds to your application’s contextual "),
                  createVNode(_component_app_link, { href: "/features/theme/#custom-theme-colors" }, {
                    default: withCtx(() => [
                      createTextVNode("theme colors")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" and "),
                  createVNode(_component_app_link, { href: "/features/icon-fonts/#creating-a-custom-icon-set" }, {
                    default: withCtx(() => [
                      createTextVNode("iconfont aliases")
                    ]),
                    _: 1
                  }),
                  createTextVNode(".")
                ]),
                createBaseVNode("section", _hoisted_18, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("p", null, [
                    createTextVNode("In addition to the standard "),
                    createVNode(_component_app_link, { href: "/components/sheets/" }, {
                      default: withCtx(() => [
                        createTextVNode("v-sheet")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" properties such as elevation, dimension, and border-radius, the "),
                    _hoisted_19,
                    createTextVNode(" component supports "),
                    _hoisted_20,
                    createTextVNode(", "),
                    _hoisted_21,
                    createTextVNode(", and "),
                    _hoisted_22,
                    createTextVNode(".")
                  ]),
                  createBaseVNode("section", _hoisted_23, [
                    createVNode(_component_app_heading, {
                      href: "#content",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Content")
                      ]),
                      _: 1
                    }),
                    _hoisted_24,
                    _hoisted_25,
                    createVNode(_component_app_markup, {
                      resource: "",
                      class: "mb-4"
                    }, {
                      default: withCtx(() => [
                        _hoisted_26
                      ]),
                      _: 1
                    }),
                    _hoisted_27,
                    createVNode(_component_examples_example, { file: "v-alert/prop-content" }),
                    _hoisted_28
                  ]),
                  createBaseVNode("section", _hoisted_29, [
                    createVNode(_component_app_heading, {
                      href: "#type",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Type")
                      ]),
                      _: 1
                    }),
                    _hoisted_30,
                    _hoisted_31,
                    createVNode(_component_examples_example, { file: "v-alert/prop-type" }),
                    createBaseVNode("section", _hoisted_32, [
                      createVNode(_component_app_heading, {
                        href: "#type-reference",
                        level: "5"
                      }, {
                        default: withCtx(() => [
                          createTextVNode("Type reference")
                        ]),
                        _: 1
                      }),
                      createVNode(_component_app_table, null, {
                        default: withCtx(() => [
                          _hoisted_33,
                          createBaseVNode("tbody", null, [
                            createBaseVNode("tr", null, [
                              _hoisted_34,
                              _hoisted_35,
                              _hoisted_36,
                              createBaseVNode("td", _hoisted_37, [
                                createVNode(_component_v_icon, { icon: "$success" })
                              ])
                            ]),
                            createBaseVNode("tr", null, [
                              _hoisted_38,
                              _hoisted_39,
                              _hoisted_40,
                              createBaseVNode("td", _hoisted_41, [
                                createVNode(_component_v_icon, { icon: "$info" })
                              ])
                            ]),
                            createBaseVNode("tr", null, [
                              _hoisted_42,
                              _hoisted_43,
                              _hoisted_44,
                              createBaseVNode("td", _hoisted_45, [
                                createVNode(_component_v_icon, { icon: "$warning" })
                              ])
                            ]),
                            createBaseVNode("tr", null, [
                              _hoisted_46,
                              _hoisted_47,
                              _hoisted_48,
                              createBaseVNode("td", _hoisted_49, [
                                createVNode(_component_v_icon, { icon: "$error" })
                              ])
                            ])
                          ])
                        ]),
                        _: 1
                      })
                    ])
                  ]),
                  createBaseVNode("section", _hoisted_50, [
                    createVNode(_component_app_heading, {
                      href: "#color-and-icon",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Color and icon")
                      ]),
                      _: 1
                    }),
                    _hoisted_51,
                    createVNode(_component_app_markup, {
                      resource: "",
                      class: "mb-4"
                    }, {
                      default: withCtx(() => [
                        _hoisted_52
                      ]),
                      _: 1
                    })
                  ]),
                  createBaseVNode("section", _hoisted_53, [
                    createVNode(_component_app_heading, {
                      href: "#density",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Density")
                      ]),
                      _: 1
                    }),
                    _hoisted_54,
                    createVNode(_component_examples_example, { file: "v-alert/prop-density" }),
                    _hoisted_55
                  ]),
                  createBaseVNode("section", _hoisted_56, [
                    createVNode(_component_app_heading, {
                      href: "#variants",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Variants")
                      ]),
                      _: 1
                    }),
                    _hoisted_57,
                    createVNode(_component_examples_example, { file: "v-alert/prop-variant" })
                  ]),
                  createBaseVNode("section", _hoisted_58, [
                    createVNode(_component_app_heading, {
                      href: "#closable",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Closable")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("The "),
                      _hoisted_59,
                      createTextVNode(" prop adds a "),
                      createVNode(_component_app_link, { href: "/components/icons" }, {
                        default: withCtx(() => [
                          createTextVNode("v-icon")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" on the far right, after the main content. This control hides the "),
                      _hoisted_60,
                      createTextVNode(" when clicked, setting it’s internal model to "),
                      _hoisted_61,
                      createTextVNode(". Manually control the visibility of the alert by binding "),
                      _hoisted_62,
                      createTextVNode(" or using "),
                      _hoisted_63,
                      createTextVNode(". The following example uses a dynamic model that shows and hides the "),
                      _hoisted_64,
                      createTextVNode(" component:")
                    ]),
                    createVNode(_component_examples_example, { file: "v-alert/prop-closable" }),
                    _hoisted_65,
                    createVNode(_component_alert, { type: "info" }, {
                      default: withCtx(() => [
                        createBaseVNode("p", null, [
                          createTextVNode("For more information on how to global modify your locale settings, navigate to the "),
                          createVNode(_component_app_link, { href: "/features/internationalization" }, {
                            default: withCtx(() => [
                              createTextVNode("Internationalization page")
                            ]),
                            _: 1
                          }),
                          createTextVNode(".")
                        ])
                      ]),
                      _: 1
                    })
                  ])
                ])
              ]),
              createBaseVNode("section", _hoisted_66, [
                createVNode(_component_app_heading, {
                  href: "#additional-examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Additional Examples")
                  ]),
                  _: 1
                }),
                _hoisted_67,
                createBaseVNode("section", _hoisted_68, [
                  createVNode(_component_app_heading, {
                    href: "#border-color",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Border color")
                    ]),
                    _: 1
                  }),
                  _hoisted_69,
                  createVNode(_component_examples_example, { file: "v-alert/prop-border-color" })
                ]),
                createBaseVNode("section", _hoisted_70, [
                  createVNode(_component_app_heading, {
                    href: "#icon",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Icon")
                    ]),
                    _: 1
                  }),
                  _hoisted_71,
                  createVNode(_component_examples_example, { file: "v-alert/prop-icon" })
                ]),
                createBaseVNode("section", _hoisted_72, [
                  createVNode(_component_app_heading, {
                    href: "#outlined",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Outlined")
                    ]),
                    _: 1
                  }),
                  _hoisted_73,
                  createVNode(_component_examples_example, { file: "v-alert/prop-outlined" })
                ])
              ]),
              createBaseVNode("section", _hoisted_74, [
                createVNode(_component_app_heading, {
                  href: "#accessibility",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Accessibility")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("By default, "),
                  _hoisted_75,
                  createTextVNode(" components are assigned the "),
                  createVNode(_component_app_link, { href: "https://www.w3.org/WAI/standards-guidelines/aria/" }, {
                    default: withCtx(() => [
                      createTextVNode("WAI-ARIA")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" role of "),
                  createVNode(_component_app_link, { href: "https://www.w3.org/TR/wai-aria/#alert" }, {
                    default: withCtx(() => [
                      _hoisted_76
                    ]),
                    _: 1
                  }),
                  createTextVNode(' which denotes that the alert "is a live region with important and usually time-sensitive information." When using the '),
                  _hoisted_77,
                  createTextVNode(" prop, the close icon will receive a corresponding "),
                  _hoisted_78,
                  createTextVNode(". This value can be modified by changing either the "),
                  _hoisted_79,
                  createTextVNode(" prop or globally through customizing the "),
                  createVNode(_component_app_link, { href: "/features/internationalization" }, {
                    default: withCtx(() => [
                      createTextVNode("Internationalization")
                    ]),
                    _: 1
                  }),
                  createTextVNode("’s default value for the "),
                  _hoisted_80,
                  createTextVNode(" property.")
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
