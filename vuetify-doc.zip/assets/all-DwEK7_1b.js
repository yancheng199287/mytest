import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "components" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "Vuetify Components are interactive building blocks for creating user interfaces.", -1);
const _hoisted_3 = { id: "containment" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, "Containment components wrap other components and provide additional functionality. They are typically used to provide a consistent layout or styling.", -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("p", null, "The button component allows users to take actions or make choices with a single tap", -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("p", null, "The card component is a versatile and enhanced sheet of paper that provides a simple interface for headings, text, images, and actions", -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("p", null, "The list component is a display interface for items", -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("p", null, "Chips are useful for displaying small pieces of information", -1);
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("p", null, "Dividers are used to separate content into distinct sections or groups", -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("p", null, "Expansion panels are used to reveal additional content in a compact manner", -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("p", null, "The menu component is used to display a list of actions that the user can make", -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("p", null, "The dialog component informs a user about a specific task and may contain critical information", -1);
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("p", null, "The bottom sheet component elevates content from the bottom of the screen", -1);
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("p", null, "The overlay component is used to display a custom scrim that sits on top of the application", -1);
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("p", null, "Toolbars are used to label a content area and / or display a list of actions that the user can make", -1);
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("p", null, "Tooltips provide additional information about an element when the user hovers over it", -1);
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("p", null, "The sheet component is a simple piece of paper that can be used to style and customize a block of content", -1);
const _hoisted_18 = { id: "navigation" };
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("p", null, "Navigation components are used to navigate between different views or pages.", -1);
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("p", null, "The app bar is used for top level navigation items and current page actions", -1);
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("p", null, "The floating action button is used for a promoted actions within an application", -1);
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("p", null, "Navigation drawers contain primary application navigation links", -1);
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("p", null, "The Pagination component is used to separate long sets of data", -1);
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("p", null, "The bottom navigation component is used for displaying navigation links on mobile", -1);
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("p", null, "Breadcrumbs are navigational helpers for router pages", -1);
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("p", null, "The footer component is a simple navigation area with inner site links", -1);
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("p", null, "The speed dial component is a floating action button that can reveal additional actions when clicked", -1);
const _hoisted_28 = /* @__PURE__ */ createBaseVNode("p", null, "The system bar component shows application information with iconography, time, and more", -1);
const _hoisted_29 = /* @__PURE__ */ createBaseVNode("p", null, "Tabs are used to organize content into different sections that can be viewed independently", -1);
const _hoisted_30 = { id: "form-inputs-and-controls" };
const _hoisted_31 = /* @__PURE__ */ createBaseVNode("p", null, "Form components are used to collect user input in a variety of ways.", -1);
const _hoisted_32 = /* @__PURE__ */ createBaseVNode("p", null, "Autocompletes are used to provide suggestions to the user as they type into a field", -1);
const _hoisted_33 = /* @__PURE__ */ createBaseVNode("p", null, "The combobox component is used to select a value from a list of options with the ability to enter a custom value", -1);
const _hoisted_34 = /* @__PURE__ */ createBaseVNode("p", null, "The text field component accepts textual input from users and is a replacement for the native text input element", -1);
const _hoisted_35 = /* @__PURE__ */ createBaseVNode("p", null, "The checkbox component is a replacement for the native input checkbox", -1);
const _hoisted_36 = /* @__PURE__ */ createBaseVNode("p", null, "The switch component is an alternately styled checkbox", -1);
const _hoisted_37 = /* @__PURE__ */ createBaseVNode("p", null, "The radio component is a replacement for its native counterpart", -1);
const _hoisted_38 = /* @__PURE__ */ createBaseVNode("p", null, "The file input component is used to select files from the user’s device and is a replacement for the native file input element", -1);
const _hoisted_39 = /* @__PURE__ */ createBaseVNode("p", null, "The form component is used to wrap form elements and provide a consistent styling and a single source for validation", -1);
const _hoisted_40 = /* @__PURE__ */ createBaseVNode("p", null, "Create custom inputs that can be used with the v-model directive", -1);
const _hoisted_41 = /* @__PURE__ */ createBaseVNode("p", null, "The number input component is used for collecting numerical data from the user", -1);
const _hoisted_42 = /* @__PURE__ */ createBaseVNode("p", null, "The OTP input component is used for MFA authentication via input field", -1);
const _hoisted_43 = /* @__PURE__ */ createBaseVNode("p", null, "The select component is used to select a value from a list of options and is a replacement for the native select element", -1);
const _hoisted_44 = /* @__PURE__ */ createBaseVNode("p", null, "Sliders are used to select a value from a range of values by moving a slider thumb and are a replacement for the native input range element", -1);
const _hoisted_45 = /* @__PURE__ */ createBaseVNode("p", null, "Range sliders are regular sliders with the ability to select in a range", -1);
const _hoisted_46 = /* @__PURE__ */ createBaseVNode("p", null, "The textarea component is a replacement for the native textarea element", -1);
const _hoisted_47 = { id: "layouts" };
const _hoisted_48 = /* @__PURE__ */ createBaseVNode("p", null, "Layout components are used to create responsive layouts.", -1);
const _hoisted_49 = /* @__PURE__ */ createBaseVNode("p", null, "The grid component is used to create responsive layouts", -1);
const _hoisted_50 = { id: "selection" };
const _hoisted_51 = /* @__PURE__ */ createBaseVNode("p", null, "These components allow a user to select one or multiple items from a list of options.", -1);
const _hoisted_52 = /* @__PURE__ */ createBaseVNode("p", null, "Carousels are used to display multiple forms of visual content", -1);
const _hoisted_53 = /* @__PURE__ */ createBaseVNode("p", null, "Button groups are used to select between multiple options using the button component", -1);
const _hoisted_54 = /* @__PURE__ */ createBaseVNode("p", null, "Chip group is a wrapper component that makes chips interactive and allows them to be selected", -1);
const _hoisted_55 = /* @__PURE__ */ createBaseVNode("p", null, "The window component is used to display a block of content based upon a model", -1);
const _hoisted_56 = /* @__PURE__ */ createBaseVNode("p", null, "The stepper component is a linear progress control used to break lengthy forms into smaller logical sections", -1);
const _hoisted_57 = { id: "data-and-display" };
const _hoisted_58 = /* @__PURE__ */ createBaseVNode("p", null, "These components are used to display data and information in a variety of ways.", -1);
const _hoisted_59 = /* @__PURE__ */ createBaseVNode("p", null, "The confirm edit component is used to confirm changes to data", -1);
const _hoisted_60 = /* @__PURE__ */ createBaseVNode("p", null, "The data iterator component provides an easy interface for paginating and sorting data", -1);
const _hoisted_61 = /* @__PURE__ */ createBaseVNode("p", null, "Data tables are used to display large amounts of data in a small amount of space", -1);
const _hoisted_62 = /* @__PURE__ */ createBaseVNode("p", null, "The Infinite scroll component is a container that loads more items when scrolling", -1);
const _hoisted_63 = /* @__PURE__ */ createBaseVNode("p", null, "Server side data tables are intended to be used with a server side data source", -1);
const _hoisted_64 = /* @__PURE__ */ createBaseVNode("p", null, "The sparkline component creates beautiful and expressive simple graphs for displaying numerical data", -1);
const _hoisted_65 = /* @__PURE__ */ createBaseVNode("p", null, "The virtual data table component is used to display very large subsets of data", -1);
const _hoisted_66 = /* @__PURE__ */ createBaseVNode("p", null, "The table component is a barebones table for manually displaying data and is a replacement for the native table element", -1);
const _hoisted_67 = /* @__PURE__ */ createBaseVNode("p", null, "The virtual scroller component makes it possible to render large amounts of data without sacrificing performance", -1);
const _hoisted_68 = { id: "feedback" };
const _hoisted_69 = /* @__PURE__ */ createBaseVNode("p", null, "These components are used to provide feedback to the user within content, over content, or in response to user actions.", -1);
const _hoisted_70 = /* @__PURE__ */ createBaseVNode("p", null, "Alerts convey important information to the user", -1);
const _hoisted_71 = /* @__PURE__ */ createBaseVNode("p", null, "Badges superscript or subscript an avatar-like icon or text onto content.", -1);
const _hoisted_72 = /* @__PURE__ */ createBaseVNode("p", null, "Banners are used to communicate important information to the user", -1);
const _hoisted_73 = /* @__PURE__ */ createBaseVNode("p", null, "The empty state component is used to indicate that a page or area on a page has no content.", -1);
const _hoisted_74 = /* @__PURE__ */ createBaseVNode("p", null, "Displays a content, enhancing perceived performance during data-fetching & rendering", -1);
const _hoisted_75 = /* @__PURE__ */ createBaseVNode("p", null, "The snackbar component is used to display a message to the user that hovers over existing content", -1);
const _hoisted_76 = /* @__PURE__ */ createBaseVNode("p", null, "Ratings are useful for collecting user feedback", -1);
const _hoisted_77 = /* @__PURE__ */ createBaseVNode("p", null, "Timeline components are used to display a list of events in chronological order", -1);
const _hoisted_78 = /* @__PURE__ */ createBaseVNode("p", null, "The hover component is a wrapper component that allows you to react to hover events", -1);
const _hoisted_79 = /* @__PURE__ */ createBaseVNode("p", null, "Circular progress’s are a visual indicator of numerical data in a circle", -1);
const _hoisted_80 = /* @__PURE__ */ createBaseVNode("p", null, "The linear progress component is used to display numerical data in a horizontal line", -1);
const _hoisted_81 = { id: "images-and-icons" };
const _hoisted_82 = /* @__PURE__ */ createBaseVNode("p", null, "This subset of components are used to display media in a variety of ways.", -1);
const _hoisted_83 = /* @__PURE__ */ createBaseVNode("p", null, "The aspect ratio component enforces a defined ratio", -1);
const _hoisted_84 = /* @__PURE__ */ createBaseVNode("p", null, "Avatars are used in numerous components to display avatars and profile pictures", -1);
const _hoisted_85 = /* @__PURE__ */ createBaseVNode("p", null, "The icon component is an reusable component that can be used to display icons", -1);
const _hoisted_86 = /* @__PURE__ */ createBaseVNode("p", null, "The image component provides a flexible interface for displaying images", -1);
const _hoisted_87 = /* @__PURE__ */ createBaseVNode("p", null, "Creates a 3d effect that makes an image appear to move slower than the foreground", -1);
const _hoisted_88 = { id: "pickers" };
const _hoisted_89 = /* @__PURE__ */ createBaseVNode("p", null, "These components are used to select a value from a specifically styled set of options.", -1);
const _hoisted_90 = /* @__PURE__ */ createBaseVNode("p", null, "The color picker component is used to select a color from a palette", -1);
const _hoisted_91 = /* @__PURE__ */ createBaseVNode("p", null, "The date picker component is used to select a single date from a calendar month / year.", -1);
const _hoisted_92 = { id: "providers" };
const _hoisted_93 = /* @__PURE__ */ createBaseVNode("p", null, "The defaults provider component is used to set default values for all components within a template", -1);
const _hoisted_94 = /* @__PURE__ */ createBaseVNode("p", null, "The locale provider component allows you to change the language of all components within its slot", -1);
const _hoisted_95 = /* @__PURE__ */ createBaseVNode("p", null, "The theme provider component allows you to change the theme of all children components", -1);
const _hoisted_96 = { id: "miscellaneous" };
const _hoisted_97 = /* @__PURE__ */ createBaseVNode("p", null, "These components don’t fit into a traditional category and are used for a variety of purposes.", -1);
const _hoisted_98 = /* @__PURE__ */ createBaseVNode("p", null, "The lazy component is a wrapper component that prevents the rendering of its child components until it is visible in the viewport", -1);
const _hoisted_99 = /* @__PURE__ */ createBaseVNode("p", null, "This component is used to prevent the rendering of its child components on the server", -1);
const _hoisted_100 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("This page is under "),
  /* @__PURE__ */ createBaseVNode("strong", null, "design"),
  /* @__PURE__ */ createTextVNode(" construction and will be updated with the missing images over time.")
], -1);
const frontmatter = { "meta": { "nav": "All Components", "title": "All Vuetify Components", "description": "Browse all of the available Vuetify components or group by category.", "keywords": "components, all components, all Vuetify components" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "all",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "All Components", "title": "All Vuetify Components", "description": "Browse all of the available Vuetify components or group by category.", "keywords": "components, all components, all Vuetify components" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "All Components", "title": "All Vuetify Components", "description": "Browse all of the available Vuetify components or group by category.", "keywords": "components, all components, all Vuetify components" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_components_list_item = resolveComponent("components-list-item");
      const _component_v_row = resolveComponent("v-row");
      const _component_app_divider = resolveComponent("app-divider");
      const _component_alert = resolveComponent("alert");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#components",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Components")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_promoted_entry),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#containment",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Containment")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_v_row, null, {
                  default: withCtx(() => [
                    createVNode(_component_components_list_item, {
                      name: "Button component",
                      src: "buttons"
                    }, {
                      default: withCtx(() => [
                        _hoisted_5
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Card components",
                      src: "cards"
                    }, {
                      default: withCtx(() => [
                        _hoisted_6
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "List components",
                      src: "lists"
                    }, {
                      default: withCtx(() => [
                        _hoisted_7
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Chip component",
                      src: "chips"
                    }, {
                      default: withCtx(() => [
                        _hoisted_8
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Divider components",
                      src: "dividers"
                    }, {
                      default: withCtx(() => [
                        _hoisted_9
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Expansion panel components",
                      src: "expansion-panels"
                    }, {
                      default: withCtx(() => [
                        _hoisted_10
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Menu component",
                      src: "menus"
                    }, {
                      default: withCtx(() => [
                        _hoisted_11
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Dialog component",
                      src: "dialogs"
                    }, {
                      default: withCtx(() => [
                        _hoisted_12
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Bottom sheet component",
                      src: "bottom-sheets"
                    }, {
                      default: withCtx(() => [
                        _hoisted_13
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Overlay component",
                      src: "overlays"
                    }, {
                      default: withCtx(() => [
                        _hoisted_14
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Toolbar components",
                      src: "toolbars"
                    }, {
                      default: withCtx(() => [
                        _hoisted_15
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Tooltip component",
                      src: "tooltips"
                    }, {
                      default: withCtx(() => [
                        _hoisted_16
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Sheet component",
                      src: "sheets"
                    }, {
                      default: withCtx(() => [
                        _hoisted_17
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                }),
                createVNode(_component_app_divider)
              ]),
              createBaseVNode("section", _hoisted_18, [
                createVNode(_component_app_heading, {
                  href: "#navigation",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Navigation")
                  ]),
                  _: 1
                }),
                _hoisted_19,
                createVNode(_component_v_row, null, {
                  default: withCtx(() => [
                    createVNode(_component_components_list_item, {
                      name: "App bars",
                      src: "app-bars"
                    }, {
                      default: withCtx(() => [
                        _hoisted_20
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "FABs",
                      src: "floating-action-buttons"
                    }, {
                      default: withCtx(() => [
                        _hoisted_21
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Navigation drawers",
                      src: "navigation-drawers"
                    }, {
                      default: withCtx(() => [
                        _hoisted_22
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Pagination component",
                      src: "paginations"
                    }, {
                      default: withCtx(() => [
                        _hoisted_23
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Bottom navigation",
                      src: "bottom-navigation"
                    }, {
                      default: withCtx(() => [
                        _hoisted_24
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Breadcrumbs components",
                      src: "breadcrumbs"
                    }, {
                      default: withCtx(() => [
                        _hoisted_25
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Footer component",
                      src: "footers"
                    }, {
                      default: withCtx(() => [
                        _hoisted_26
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Speed dials",
                      src: "speed-dials"
                    }, {
                      default: withCtx(() => [
                        _hoisted_27
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "System bar",
                      src: "system-bars"
                    }, {
                      default: withCtx(() => [
                        _hoisted_28
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Tabs components",
                      src: "tabs"
                    }, {
                      default: withCtx(() => [
                        _hoisted_29
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                }),
                createVNode(_component_app_divider)
              ]),
              createBaseVNode("section", _hoisted_30, [
                createVNode(_component_app_heading, {
                  href: "#form-inputs-and-controls",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Form inputs and controls")
                  ]),
                  _: 1
                }),
                _hoisted_31,
                createVNode(_component_v_row, null, {
                  default: withCtx(() => [
                    createVNode(_component_components_list_item, {
                      name: "Autocomplete component",
                      src: "autocompletes"
                    }, {
                      default: withCtx(() => [
                        _hoisted_32
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Combobox components",
                      src: "combobox"
                    }, {
                      default: withCtx(() => [
                        _hoisted_33
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Text field",
                      src: "text-fields"
                    }, {
                      default: withCtx(() => [
                        _hoisted_34
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Checkbox components",
                      src: "checkboxes"
                    }, {
                      default: withCtx(() => [
                        _hoisted_35
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Switch components",
                      src: "switches"
                    }, {
                      default: withCtx(() => [
                        _hoisted_36
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Radio button",
                      src: "radio-buttons"
                    }, {
                      default: withCtx(() => [
                        _hoisted_37
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "File input",
                      src: "file-inputs"
                    }, {
                      default: withCtx(() => [
                        _hoisted_38
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Form component",
                      src: "forms"
                    }, {
                      default: withCtx(() => [
                        _hoisted_39
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Inputs component",
                      src: "inputs"
                    }, {
                      default: withCtx(() => [
                        _hoisted_40
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Number input component",
                      src: "number-inputs",
                      labs: ""
                    }, {
                      default: withCtx(() => [
                        _hoisted_41
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "OTP Input component",
                      src: "otp-input"
                    }, {
                      default: withCtx(() => [
                        _hoisted_42
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Select component",
                      src: "selects"
                    }, {
                      default: withCtx(() => [
                        _hoisted_43
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Slider component",
                      src: "sliders"
                    }, {
                      default: withCtx(() => [
                        _hoisted_44
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Range slider",
                      src: "range-sliders"
                    }, {
                      default: withCtx(() => [
                        _hoisted_45
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Textarea component",
                      src: "textareas"
                    }, {
                      default: withCtx(() => [
                        _hoisted_46
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                }),
                createVNode(_component_app_divider)
              ]),
              createBaseVNode("section", _hoisted_47, [
                createVNode(_component_app_heading, {
                  href: "#layouts",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Layouts")
                  ]),
                  _: 1
                }),
                _hoisted_48,
                createVNode(_component_v_row, null, {
                  default: withCtx(() => [
                    createVNode(_component_components_list_item, {
                      name: "grids",
                      src: "grids"
                    }, {
                      default: withCtx(() => [
                        _hoisted_49
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                }),
                createVNode(_component_app_divider)
              ]),
              createBaseVNode("section", _hoisted_50, [
                createVNode(_component_app_heading, {
                  href: "#selection",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Selection")
                  ]),
                  _: 1
                }),
                _hoisted_51,
                createVNode(_component_v_row, null, {
                  default: withCtx(() => [
                    createVNode(_component_components_list_item, {
                      name: "Carousel component",
                      src: "carousels"
                    }, {
                      default: withCtx(() => [
                        _hoisted_52
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Button group",
                      src: "button-groups"
                    }, {
                      default: withCtx(() => [
                        _hoisted_53
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Chip group",
                      src: "chip-groups"
                    }, {
                      default: withCtx(() => [
                        _hoisted_54
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Window components",
                      src: "windows"
                    }, {
                      default: withCtx(() => [
                        _hoisted_55
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Stepper components",
                      src: "steppers"
                    }, {
                      default: withCtx(() => [
                        _hoisted_56
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                }),
                createVNode(_component_app_divider)
              ]),
              createBaseVNode("section", _hoisted_57, [
                createVNode(_component_app_heading, {
                  href: "#data-and-display",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Data and display")
                  ]),
                  _: 1
                }),
                _hoisted_58,
                createVNode(_component_v_row, null, {
                  default: withCtx(() => [
                    createVNode(_component_components_list_item, {
                      name: "Confirm edit component",
                      src: "confirm-edit"
                    }, {
                      default: withCtx(() => [
                        _hoisted_59
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Data iterator component",
                      src: "data-iterators"
                    }, {
                      default: withCtx(() => [
                        _hoisted_60
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Data table component",
                      src: "data-tables/basics"
                    }, {
                      default: withCtx(() => [
                        _hoisted_61
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Infinite scroll component",
                      src: "infinite-scroller"
                    }, {
                      default: withCtx(() => [
                        _hoisted_62
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Server-side table component",
                      src: "data-tables/server-side-tables"
                    }, {
                      default: withCtx(() => [
                        _hoisted_63
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Sparkline component",
                      src: "sparkline"
                    }, {
                      default: withCtx(() => [
                        _hoisted_64
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Virtual Data table component",
                      src: "data-tables/virtual-tables"
                    }, {
                      default: withCtx(() => [
                        _hoisted_65
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Table component",
                      src: "tables"
                    }, {
                      default: withCtx(() => [
                        _hoisted_66
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Virtual scroll component",
                      src: "virtual-scroller"
                    }, {
                      default: withCtx(() => [
                        _hoisted_67
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                }),
                createVNode(_component_app_divider)
              ]),
              createBaseVNode("section", _hoisted_68, [
                createVNode(_component_app_heading, {
                  href: "#feedback",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Feedback")
                  ]),
                  _: 1
                }),
                _hoisted_69,
                createVNode(_component_v_row, null, {
                  default: withCtx(() => [
                    createVNode(_component_components_list_item, {
                      name: "Alert component",
                      src: "alerts"
                    }, {
                      default: withCtx(() => [
                        _hoisted_70
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Badge component",
                      src: "badges"
                    }, {
                      default: withCtx(() => [
                        _hoisted_71
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Banner component",
                      src: "banners"
                    }, {
                      default: withCtx(() => [
                        _hoisted_72
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Empty state component",
                      src: "empty-states"
                    }, {
                      default: withCtx(() => [
                        _hoisted_73
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Skeleton loader component",
                      src: "skeleton-loaders"
                    }, {
                      default: withCtx(() => [
                        _hoisted_74
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Snackbar component",
                      src: "snackbars"
                    }, {
                      default: withCtx(() => [
                        _hoisted_75
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Rating component",
                      src: "ratings"
                    }, {
                      default: withCtx(() => [
                        _hoisted_76
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Timeline components",
                      src: "timelines"
                    }, {
                      default: withCtx(() => [
                        _hoisted_77
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Hover component",
                      src: "hover"
                    }, {
                      default: withCtx(() => [
                        _hoisted_78
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Progress circular component",
                      src: "progress-circular"
                    }, {
                      default: withCtx(() => [
                        _hoisted_79
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Progress linear component",
                      src: "progress-linear"
                    }, {
                      default: withCtx(() => [
                        _hoisted_80
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                }),
                createVNode(_component_app_divider)
              ]),
              createBaseVNode("section", _hoisted_81, [
                createVNode(_component_app_heading, {
                  href: "#images-and-icons",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Images and icons")
                  ]),
                  _: 1
                }),
                _hoisted_82,
                createVNode(_component_v_row, null, {
                  default: withCtx(() => [
                    createVNode(_component_components_list_item, {
                      name: "Aspect ratios component",
                      src: "aspect-ratios"
                    }, {
                      default: withCtx(() => [
                        _hoisted_83
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Avatar component",
                      src: "avatars"
                    }, {
                      default: withCtx(() => [
                        _hoisted_84
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Icon component",
                      src: "icons"
                    }, {
                      default: withCtx(() => [
                        _hoisted_85
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Image component",
                      src: "images"
                    }, {
                      default: withCtx(() => [
                        _hoisted_86
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Parallax component",
                      src: "parallax"
                    }, {
                      default: withCtx(() => [
                        _hoisted_87
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                }),
                createVNode(_component_app_divider)
              ]),
              createBaseVNode("section", _hoisted_88, [
                createVNode(_component_app_heading, {
                  href: "#pickers",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Pickers")
                  ]),
                  _: 1
                }),
                _hoisted_89,
                createVNode(_component_v_row, null, {
                  default: withCtx(() => [
                    createVNode(_component_components_list_item, {
                      name: "Color picker component",
                      src: "color-pickers"
                    }, {
                      default: withCtx(() => [
                        _hoisted_90
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Date picker component",
                      src: "date-pickers"
                    }, {
                      default: withCtx(() => [
                        _hoisted_91
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                }),
                createVNode(_component_app_divider)
              ]),
              createBaseVNode("section", _hoisted_92, [
                createVNode(_component_app_heading, {
                  href: "#providers",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Providers")
                  ]),
                  _: 1
                }),
                createVNode(_component_v_row, null, {
                  default: withCtx(() => [
                    createVNode(_component_components_list_item, {
                      name: "Defaults provider component",
                      src: "defaults-providers"
                    }, {
                      default: withCtx(() => [
                        _hoisted_93
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Locale provider component",
                      src: "locale-providers"
                    }, {
                      default: withCtx(() => [
                        _hoisted_94
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "Theme provider component",
                      src: "theme-providers"
                    }, {
                      default: withCtx(() => [
                        _hoisted_95
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                }),
                createVNode(_component_app_divider)
              ]),
              createBaseVNode("section", _hoisted_96, [
                createVNode(_component_app_heading, {
                  href: "#miscellaneous",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Miscellaneous")
                  ]),
                  _: 1
                }),
                _hoisted_97,
                createVNode(_component_v_row, null, {
                  default: withCtx(() => [
                    createVNode(_component_components_list_item, {
                      name: "Lazy component",
                      src: "lazy"
                    }, {
                      default: withCtx(() => [
                        _hoisted_98
                      ]),
                      _: 1
                    }),
                    createVNode(_component_components_list_item, {
                      name: "No-ssr component",
                      src: "no-ssr"
                    }, {
                      default: withCtx(() => [
                        _hoisted_99
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                }),
                createVNode(_component_alert, { type: "info" }, {
                  default: withCtx(() => [
                    _hoisted_100
                  ]),
                  _: 1
                })
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
