import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
import { _ as __6 } from "./prop-scroll-behavior-Dyk0JIkp.js";
import "./UsageExample-M8CmNipa.js";
const _hoisted_1 = { id: "app-bars" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-app-bar"),
  /* @__PURE__ */ createTextVNode(" component is pivotal to any graphical user interface (GUI), as it generally is the primary source of site navigation.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-app-bar"),
  /* @__PURE__ */ createTextVNode(" component is used for application-wide actions and information.")
], -1);
const _hoisted_5 = { id: "api" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("em", null, "icon", -1);
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("strong", null, "$menu", -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createTextVNode("An extension of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-toolbar-title"),
  /* @__PURE__ */ createTextVNode(" that is used for scrolling techniques")
], -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "TIP:")
], -1);
const _hoisted_12 = { id: "anatomy" };
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The recommended placement of elements inside of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-app-bar"),
  /* @__PURE__ */ createTextVNode(" is:")
], -1);
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Place "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-app-bar-nav-icon"),
    /* @__PURE__ */ createTextVNode(" or other navigation items on the far left")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Place "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-app-bar-title"),
    /* @__PURE__ */ createTextVNode(" to the right of navigation")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, "Place contextual actions to the right of navigation"),
  /* @__PURE__ */ createBaseVNode("li", null, "Place overflow actions to the far right")
], -1);
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Element / Area"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("tbody", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "1. Container"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("The App Bar container holds all "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-app-bar"),
      /* @__PURE__ */ createTextVNode(" components")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "2. App Bar Icon (optional)"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("A styled icon button component created that is often used to control the state of a "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-navigation drawer")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "3. Title (optional)"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("A heading with increased "),
      /* @__PURE__ */ createBaseVNode("strong", null, "font-size")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "4. Action items (optional)"),
    /* @__PURE__ */ createBaseVNode("td", null, "Used to highlight certain actions not in the overflow menu")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "5. Overflow menu (optional)"),
    /* @__PURE__ */ createBaseVNode("td", null, "Place less often used action items into a hidden menu")
  ])
], -1);
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("When a "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn"),
  /* @__PURE__ */ createTextVNode(" with the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "icon"),
  /* @__PURE__ */ createTextVNode(" prop is used inside of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-toolbar"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-app-bar"),
  /* @__PURE__ */ createTextVNode(" they will automatically have their size increased and negative margin applied to ensure proper spacing according to the Material Design Specification. If you choose to wrap your buttons in any container, such as a "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "div"),
  /* @__PURE__ */ createTextVNode(", you will need to apply negative margin to that container in order to properly align them.")
], -1);
const _hoisted_18 = { id: "examples" };
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The following are a collection of examples that demonstrate more advanced and real world use of the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-app-bar"),
  /* @__PURE__ */ createTextVNode(" component.")
], -1);
const _hoisted_20 = { id: "props" };
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-app-bar"),
  /* @__PURE__ */ createTextVNode(" component has a variety of props that allow you to customize its look and feel, density, scroll behavior, and more.")
], -1);
const _hoisted_22 = { id: "scroll-behavior" };
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("p", null, "Available values:", -1);
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "hide"),
    /* @__PURE__ */ createTextVNode(": The default slot area will shift up and hide as the user scrolls down. The extension slot remains visible.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "collapse"),
    /* @__PURE__ */ createTextVNode(": Shrink horizontally to a small bar in one corner.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "elevate"),
    /* @__PURE__ */ createTextVNode(": Add a drop shadow to the app bar when scrolling. Ignores "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "scroll-threshold"),
    /* @__PURE__ */ createTextVNode(", will always be applied with any amount of scrolling.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "fade-image"),
    /* @__PURE__ */ createTextVNode(": Fade out the image as the user scrolls down.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "inverted"),
    /* @__PURE__ */ createTextVNode(": Has no effect on its own, but will reverse the behavior when combined with any other option.")
  ])
], -1);
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "scroll-threshold"),
  /* @__PURE__ */ createTextVNode(" prop is used to determine how far the user must scroll down (in pixels) before the behavior is applied.")
], -1);
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("A scroll listener is added to "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "window"),
  /* @__PURE__ */ createTextVNode(" by default, but can be changed to a custom element using the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "scroll-target"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_27 = { id: "density" };
const _hoisted_28 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can make "),
  /* @__PURE__ */ createBaseVNode("strong", null, "app-bar"),
  /* @__PURE__ */ createTextVNode(" dense. A dense app bar has lower height than regular one.")
], -1);
const _hoisted_29 = { id: "images" };
const _hoisted_30 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-app-bar"),
  /* @__PURE__ */ createTextVNode(" can contain background images. You can set source via the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "image"),
  /* @__PURE__ */ createTextVNode(" prop. If you need to customize the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-img"),
  /* @__PURE__ */ createTextVNode(" properties, the app-bar provides you with an "),
  /* @__PURE__ */ createBaseVNode("strong", null, "image"),
  /* @__PURE__ */ createTextVNode(" slot.")
], -1);
const _hoisted_31 = { id: "prominent" };
const _hoisted_32 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("An "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-app-bar"),
  /* @__PURE__ */ createTextVNode(" with the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, 'density="prominent"'),
  /* @__PURE__ */ createTextVNode(" prop can opt to have its height shrunk as the user scrolls down. This provides a smooth transition to taking up less visual space when the user is scrolling through content. Shrink height has 2 possible options, "),
  /* @__PURE__ */ createBaseVNode("strong", null, "compact"),
  /* @__PURE__ */ createTextVNode(" (48px) and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "comfortable"),
  /* @__PURE__ */ createTextVNode(" (56px) sizes.")
], -1);
const frontmatter = { "meta": { "nav": "App bars", "title": "App-bar component", "description": "The app bar component is a supercharged toolbar with advanced scrolling techniques and application layout support.", "keywords": "app bars, vuetify app bar component, vue app bar component" }, "related": ["/components/buttons/", "/components/icons/", "/components/toolbars/"], "features": { "figma": true, "label": "C: VAppBar", "report": true, "github": "/components/VAppBar/", "spec": "https://m2.material.io/components/app-bars-top" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "app-bars",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "App bars", "title": "App-bar component", "description": "The app bar component is a supercharged toolbar with advanced scrolling techniques and application layout support.", "keywords": "app bars, vuetify app bar component, vue app bar component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "App bars", "title": "App-bar component", "description": "The app bar component is a supercharged toolbar with advanced scrolling techniques and application layout support.", "keywords": "app bars, vuetify app bar component, vue app bar component" }, "related": ["/components/buttons/", "/components/icons/", "/components/toolbars/"], "features": { "figma": true, "label": "C: VAppBar", "report": true, "github": "/components/VAppBar/", "spec": "https://m2.material.io/components/app-bars-top" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_app_figure = resolveComponent("app-figure");
      const _component_page_features = resolveComponent("page-features");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_alert = resolveComponent("alert");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#app-bars",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("App bars")
                ]),
                _: 1
              }),
              _hoisted_2,
              createBaseVNode("p", null, [
                createBaseVNode("div", null, [
                  createVNode(_component_app_figure, {
                    alt: "App Bar Entry",
                    src: "https://cdn.vuetifyjs.com/docs/images/components-temp/v-app-bar/v-app-bar-entry.png"
                  })
                ])
              ]),
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_usage, { name: "v-app-bar" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_6,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-app-bar/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-app-bar")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-app-bar-nav-icon/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-app-bar-nav-icon")
                            ]),
                            _: 1
                          })
                        ]),
                        createBaseVNode("td", null, [
                          createTextVNode("A customized "),
                          createVNode(_component_app_link, { href: "/components/buttons/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-btn")
                            ]),
                            _: 1
                          }),
                          createTextVNode(" component that uses a default "),
                          _hoisted_8,
                          createTextVNode(" value of "),
                          _hoisted_9
                        ])
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-app-bar-title/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-app-bar-title")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_10
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" }),
                createVNode(_component_alert, { type: "tip" }, {
                  default: withCtx(() => [
                    _hoisted_11,
                    createBaseVNode("p", null, [
                      createTextVNode("The app-bar component works great in conjunction with a "),
                      createVNode(_component_app_link, { href: "/components/navigation-drawers" }, {
                        default: withCtx(() => [
                          createTextVNode("v-navigation-drawer")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" for providing site navigation in your application.")
                    ])
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_12, [
                createVNode(_component_app_heading, {
                  href: "#anatomy",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Anatomy")
                  ]),
                  _: 1
                }),
                _hoisted_13,
                _hoisted_14,
                createBaseVNode("p", null, [
                  createBaseVNode("div", null, [
                    createVNode(_component_app_figure, {
                      alt: "App Bar Anatomy",
                      src: "https://cdn.vuetifyjs.com/docs/images/components-temp/v-app-bar/v-app-bar-anatomy.png"
                    })
                  ])
                ]),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_15,
                    _hoisted_16
                  ]),
                  _: 1
                }),
                createVNode(_component_alert, { type: "warning" }, {
                  default: withCtx(() => [
                    _hoisted_17
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_18, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                _hoisted_19,
                createBaseVNode("section", _hoisted_20, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  _hoisted_21,
                  createBaseVNode("section", _hoisted_22, [
                    createVNode(_component_app_heading, {
                      href: "#scroll-behavior",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Scroll behavior")
                      ]),
                      _: 1
                    }),
                    _hoisted_23,
                    _hoisted_24,
                    _hoisted_25,
                    _hoisted_26,
                    createVNode(__6)
                  ]),
                  createBaseVNode("section", _hoisted_27, [
                    createVNode(_component_app_heading, {
                      href: "#density",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Density")
                      ]),
                      _: 1
                    }),
                    _hoisted_28,
                    createVNode(_component_examples_example, { file: "v-app-bar/prop-density" })
                  ]),
                  createBaseVNode("section", _hoisted_29, [
                    createVNode(_component_app_heading, {
                      href: "#images",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Images")
                      ]),
                      _: 1
                    }),
                    _hoisted_30,
                    createVNode(_component_examples_example, { file: "v-app-bar/prop-image" })
                  ]),
                  createBaseVNode("section", _hoisted_31, [
                    createVNode(_component_app_heading, {
                      href: "#prominent",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Prominent")
                      ]),
                      _: 1
                    }),
                    _hoisted_32,
                    createVNode(_component_examples_example, { file: "v-app-bar/prop-prominent" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
