import { J as ref, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _sfc_main = {
  __name: "theme",
  setup(__props) {
    const theme = ref("light");
    function onClick() {
      theme.value = theme.value === "light" ? "dark" : "light";
    }
    return (_ctx, _cache) => {
      const _component_v_spacer = resolveComponent("v-spacer");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_app_bar = resolveComponent("v-app-bar");
      const _component_v_container = resolveComponent("v-container");
      const _component_v_main = resolveComponent("v-main");
      const _component_v_app = resolveComponent("v-app");
      return openBlock(), createBlock(_component_v_app, {
        theme: theme.value,
        class: "rounded-lg border",
        style: { "max-height": "200px" }
      }, {
        default: withCtx(() => [
          createVNode(_component_v_app_bar, null, {
            default: withCtx(() => [
              createVNode(_component_v_spacer),
              createVNode(_component_v_btn, {
                "prepend-icon": theme.value === "light" ? "mdi-weather-sunny" : "mdi-weather-night",
                onClick
              }, {
                default: withCtx(() => [
                  createTextVNode("Toggle Theme")
                ]),
                _: 1
              }, 8, ["prepend-icon"])
            ]),
            _: 1
          }),
          createVNode(_component_v_main, null, {
            default: withCtx(() => [
              createVNode(_component_v_container, { class: "text-center" }, {
                default: withCtx(() => [
                  createTextVNode("Content area")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      }, 8, ["theme"]);
    };
  }
};
const __0 = _sfc_main;
const __0_raw = `<template>
  <v-app
    :theme="theme"
    class="rounded-lg border"
    style="max-height: 200px;"
  >
    <v-app-bar>
      <v-spacer></v-spacer>

      <v-btn
        :prepend-icon="theme === 'light' ? 'mdi-weather-sunny' : 'mdi-weather-night'"
        @click="onClick"
      >Toggle Theme</v-btn>
    </v-app-bar>

    <v-main>
      <v-container class="text-center">Content area</v-container>
    </v-main>
  </v-app>
</template>

<script setup>
  import { ref } from 'vue'

  const theme = ref('light')

  function onClick () {
    theme.value = theme.value === 'light' ? 'dark' : 'light'
  }
<\/script>
`;
const application = {
  "theme": {
    component: __0,
    source: __0_raw
  }
};
export {
  application as default
};
