import { y as _export_sfc, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, b as createVNode, h as createTextVNode, J as ref, e as createBaseVNode, am as useLayout } from "./index-DGybHjCP.js";
const _sfc_main$6 = {};
function _sfc_render$3(_ctx, _cache) {
  const _component_v_app_bar = resolveComponent("v-app-bar");
  const _component_v_list_item = resolveComponent("v-list-item");
  const _component_v_list = resolveComponent("v-list");
  const _component_v_navigation_drawer = resolveComponent("v-navigation-drawer");
  const _component_v_main = resolveComponent("v-main");
  const _component_v_layout = resolveComponent("v-layout");
  return openBlock(), createBlock(_component_v_layout, { class: "rounded rounded-md" }, {
    default: withCtx(() => [
      createVNode(_component_v_app_bar, { title: "Application bar" }),
      createVNode(_component_v_navigation_drawer, null, {
        default: withCtx(() => [
          createVNode(_component_v_list, null, {
            default: withCtx(() => [
              createVNode(_component_v_list_item, { title: "Navigation drawer" })
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_main, {
        class: "d-flex align-center justify-center",
        style: { "min-height": "300px" }
      }, {
        default: withCtx(() => [
          createTextVNode(" Main Content ")
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __0 = /* @__PURE__ */ _export_sfc(_sfc_main$6, [["render", _sfc_render$3]]);
const __0_raw = '<template>\n  <v-layout class="rounded rounded-md">\n    <v-app-bar title="Application bar"></v-app-bar>\n\n    <v-navigation-drawer>\n      <v-list>\n        <v-list-item title="Navigation drawer"></v-list-item>\n      </v-list>\n    </v-navigation-drawer>\n\n    <v-main class="d-flex align-center justify-center" style="min-height: 300px;">\n      Main Content\n    </v-main>\n  </v-layout>\n</template>\n';
const _sfc_main$5 = {};
function _sfc_render$2(_ctx, _cache) {
  const _component_v_system_bar = resolveComponent("v-system-bar");
  const _component_v_navigation_drawer = resolveComponent("v-navigation-drawer");
  const _component_v_app_bar = resolveComponent("v-app-bar");
  const _component_v_main = resolveComponent("v-main");
  const _component_v_layout = resolveComponent("v-layout");
  return openBlock(), createBlock(_component_v_layout, { class: "rounded rounded-md" }, {
    default: withCtx(() => [
      createVNode(_component_v_system_bar, { color: "grey-darken-3" }),
      createVNode(_component_v_navigation_drawer, {
        color: "grey-darken-2",
        width: "72",
        permanent: ""
      }),
      createVNode(_component_v_navigation_drawer, {
        color: "grey-darken-1",
        width: "150",
        permanent: ""
      }),
      createVNode(_component_v_app_bar, {
        color: "grey",
        height: "48",
        flat: ""
      }),
      createVNode(_component_v_navigation_drawer, {
        color: "grey-lighten-1",
        location: "right",
        width: "150",
        permanent: ""
      }),
      createVNode(_component_v_app_bar, {
        color: "grey-lighten-2",
        height: "48",
        location: "bottom",
        flat: ""
      }),
      createVNode(_component_v_main, {
        class: "d-flex align-center justify-center",
        style: { "min-height": "300px" }
      }, {
        default: withCtx(() => [
          createTextVNode(" Main Content ")
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __1 = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["render", _sfc_render$2]]);
const __1_raw = '<template>\n  <v-layout class="rounded rounded-md">\n    <v-system-bar color="grey-darken-3"></v-system-bar>\n\n    <v-navigation-drawer\n      color="grey-darken-2"\n      width="72"\n      permanent\n    ></v-navigation-drawer>\n\n    <v-navigation-drawer\n      color="grey-darken-1"\n      width="150"\n      permanent\n    ></v-navigation-drawer>\n\n    <v-app-bar\n      color="grey"\n      height="48"\n      flat\n    ></v-app-bar>\n\n    <v-navigation-drawer\n      color="grey-lighten-1"\n      location="right"\n      width="150"\n      permanent\n    ></v-navigation-drawer>\n\n    <v-app-bar\n      color="grey-lighten-2"\n      height="48"\n      location="bottom"\n      flat\n    ></v-app-bar>\n\n    <v-main class="d-flex align-center justify-center" style="min-height: 300px;">\n      Main Content\n    </v-main>\n  </v-layout>\n</template>\n';
const _sfc_main$4 = {
  __name: "dynamic",
  setup(__props) {
    const order = ref(0);
    return (_ctx, _cache) => {
      const _component_v_navigation_drawer = resolveComponent("v-navigation-drawer");
      const _component_v_switch = resolveComponent("v-switch");
      const _component_v_app_bar = resolveComponent("v-app-bar");
      const _component_v_main = resolveComponent("v-main");
      const _component_v_layout = resolveComponent("v-layout");
      return openBlock(), createBlock(_component_v_layout, { class: "rounded rounded-md" }, {
        default: withCtx(() => [
          createVNode(_component_v_navigation_drawer, {
            color: "grey-darken-2",
            permanent: ""
          }),
          createVNode(_component_v_app_bar, {
            order: order.value,
            color: "grey-lighten-2",
            title: "Application bar",
            flat: ""
          }, {
            append: withCtx(() => [
              createVNode(_component_v_switch, {
                modelValue: order.value,
                "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => order.value = $event),
                "false-value": "0",
                label: "Toggle order",
                "true-value": "-1",
                "hide-details": "",
                inset: ""
              }, null, 8, ["modelValue"])
            ]),
            _: 1
          }, 8, ["order"]),
          createVNode(_component_v_main, {
            class: "d-flex align-center justify-center",
            style: { "min-height": "300px" }
          }, {
            default: withCtx(() => [
              createTextVNode(" Main Content ")
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __2 = _sfc_main$4;
const __2_raw = `<template>
  <v-layout class="rounded rounded-md">
    <v-navigation-drawer color="grey-darken-2" permanent></v-navigation-drawer>

    <v-app-bar
      :order="order"
      color="grey-lighten-2"
      title="Application bar"
      flat
    >
      <template v-slot:append>
        <v-switch
          v-model="order"
          false-value="0"
          label="Toggle order"
          true-value="-1"
          hide-details
          inset
        ></v-switch>
      </template>
    </v-app-bar>

    <v-main class="d-flex align-center justify-center" style="min-height: 300px;">
      Main Content
    </v-main>
  </v-layout>
</template>

<script setup>
  import { ref } from 'vue'

  const order = ref(0)
<\/script>

<script>
  export default {
    data: () => ({
      order: 0,
    }),
  }
<\/script>
`;
const _hoisted_1$1 = { class: "d-flex justify-center align-center h-100" };
const _sfc_main$3 = {
  __name: "layout-information-composable",
  setup(__props) {
    const Child = {
      setup(props, ctx) {
        const { getLayoutItem } = useLayout();
        function print(key) {
          alert(JSON.stringify(getLayoutItem(key), null, 2));
        }
        return () => ctx.slots.default({ print });
      }
    };
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_app_bar = resolveComponent("v-app-bar");
      const _component_v_navigation_drawer = resolveComponent("v-navigation-drawer");
      const _component_v_main = resolveComponent("v-main");
      const _component_v_footer = resolveComponent("v-footer");
      const _component_v_layout = resolveComponent("v-layout");
      return openBlock(), createBlock(_component_v_layout, {
        ref: "app",
        class: "rounded rounded-md"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_app_bar, {
            color: "grey-lighten-2",
            name: "app-bar"
          }, {
            default: withCtx(() => [
              createVNode(Child, null, {
                default: withCtx(({ print }) => [
                  createVNode(_component_v_btn, {
                    class: "mx-auto",
                    onClick: ($event) => print("app-bar")
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Get data")
                    ]),
                    _: 2
                  }, 1032, ["onClick"])
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_navigation_drawer, {
            color: "grey-darken-2",
            name: "drawer",
            permanent: ""
          }, {
            default: withCtx(() => [
              createBaseVNode("div", _hoisted_1$1, [
                createVNode(Child, null, {
                  default: withCtx(({ print }) => [
                    createVNode(_component_v_btn, {
                      onClick: ($event) => print("drawer")
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Get data")
                      ]),
                      _: 2
                    }, 1032, ["onClick"])
                  ]),
                  _: 1
                })
              ])
            ]),
            _: 1
          }),
          createVNode(_component_v_main, {
            class: "d-flex align-center justify-center",
            style: { "min-height": "300px" }
          }, {
            default: withCtx(() => [
              createTextVNode(" Main Content ")
            ]),
            _: 1
          }),
          createVNode(_component_v_footer, {
            name: "footer",
            app: ""
          }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, {
                class: "mx-auto",
                variant: "text",
                onClick: _cache[0] || (_cache[0] = ($event) => _ctx.print("footer"))
              }, {
                default: withCtx(() => [
                  createTextVNode(" Get data ")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      }, 512);
    };
  }
};
const __3 = _sfc_main$3;
const __3_raw = `<template>
  <v-layout ref="app" class="rounded rounded-md">
    <v-app-bar color="grey-lighten-2" name="app-bar">
      <child v-slot="{ print }">
        <v-btn class="mx-auto" @click="print('app-bar')">Get data</v-btn>
      </child>
    </v-app-bar>

    <v-navigation-drawer
      color="grey-darken-2"
      name="drawer"
      permanent
    >
      <div class="d-flex justify-center align-center h-100">
        <child v-slot="{ print }">
          <v-btn @click="print('drawer')">Get data</v-btn>
        </child>
      </div>
    </v-navigation-drawer>

    <v-main class="d-flex align-center justify-center" style="min-height: 300px;">
      Main Content
    </v-main>

    <v-footer
      name="footer"
      app
    >
      <v-btn
        class="mx-auto"
        variant="text"
        @click="print('footer')"
      >
        Get data
      </v-btn>
    </v-footer>
  </v-layout>
</template>

<script setup>
  import { useLayout } from 'vuetify'

  const Child = {
    setup (props, ctx) {
      const { getLayoutItem } = useLayout()

      function print (key) {
        alert(JSON.stringify(getLayoutItem(key), null, 2))
      }

      return () => ctx.slots.default({ print })
    },
  }
<\/script>

<script>
  import { useLayout } from 'vuetify'

  const Child = {
    setup (props, ctx) {
      const { getLayoutItem } = useLayout()

      function print (key) {
        alert(JSON.stringify(getLayoutItem(key), null, 2))
      }

      return () => ctx.slots.default({ print })
    },
  }

  export default {
    components: { Child },
  }
<\/script>
`;
const _hoisted_1 = { class: "d-flex justify-center align-center h-100" };
const _sfc_main$2 = {
  __name: "layout-information-ref",
  setup(__props) {
    const app = ref();
    function print(key) {
      alert(JSON.stringify(app.value.getLayoutItem(key), null, 2));
    }
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_app_bar = resolveComponent("v-app-bar");
      const _component_v_navigation_drawer = resolveComponent("v-navigation-drawer");
      const _component_v_main = resolveComponent("v-main");
      const _component_v_footer = resolveComponent("v-footer");
      const _component_v_layout = resolveComponent("v-layout");
      return openBlock(), createBlock(_component_v_layout, {
        ref_key: "app",
        ref: app,
        class: "rounded rounded-md"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_app_bar, {
            color: "grey-lighten-2",
            name: "app-bar"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, {
                class: "mx-auto",
                onClick: _cache[0] || (_cache[0] = ($event) => print("app-bar"))
              }, {
                default: withCtx(() => [
                  createTextVNode("Get data")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_navigation_drawer, {
            color: "grey-darken-2",
            location: "end",
            name: "drawer",
            permanent: ""
          }, {
            default: withCtx(() => [
              createBaseVNode("div", _hoisted_1, [
                createVNode(_component_v_btn, {
                  onClick: _cache[1] || (_cache[1] = ($event) => print("drawer"))
                }, {
                  default: withCtx(() => [
                    createTextVNode("Get data")
                  ]),
                  _: 1
                })
              ])
            ]),
            _: 1
          }),
          createVNode(_component_v_main, {
            class: "d-flex align-center justify-center",
            style: { "min-height": "300px" }
          }, {
            default: withCtx(() => [
              createTextVNode(" Main Content ")
            ]),
            _: 1
          }),
          createVNode(_component_v_footer, {
            name: "footer",
            app: ""
          }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, {
                class: "mx-auto",
                variant: "text",
                onClick: _cache[2] || (_cache[2] = ($event) => print("footer"))
              }, {
                default: withCtx(() => [
                  createTextVNode(" Get data ")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      }, 512);
    };
  }
};
const __4 = _sfc_main$2;
const __4_raw = `<template>
  <v-layout ref="app" class="rounded rounded-md">
    <v-app-bar color="grey-lighten-2" name="app-bar">
      <v-btn class="mx-auto" @click="print('app-bar')">Get data</v-btn>
    </v-app-bar>

    <v-navigation-drawer
      color="grey-darken-2"
      location="end"
      name="drawer"
      permanent
    >
      <div class="d-flex justify-center align-center h-100">
        <v-btn @click="print('drawer')">Get data</v-btn>
      </div>
    </v-navigation-drawer>

    <v-main class="d-flex align-center justify-center" style="min-height: 300px;">
      Main Content
    </v-main>

    <v-footer
      name="footer"
      app
    >
      <v-btn
        class="mx-auto"
        variant="text"
        @click="print('footer')"
      >
        Get data
      </v-btn>
    </v-footer>
  </v-layout>
</template>

<script setup>
  import { ref } from 'vue'

  const app = ref()

  function print (key) {
    alert(JSON.stringify(app.value.getLayoutItem(key), null, 2))
  }
<\/script>

<script>
  export default {
    methods: {
      print (key) {
        alert(JSON.stringify(this.$refs.app.getLayoutItem(key), null, 2))
      },
    },
  }
<\/script>
`;
const _sfc_main$1 = {};
function _sfc_render$1(_ctx, _cache) {
  const _component_v_app_bar = resolveComponent("v-app-bar");
  const _component_v_list_item = resolveComponent("v-list-item");
  const _component_v_list = resolveComponent("v-list");
  const _component_v_navigation_drawer = resolveComponent("v-navigation-drawer");
  const _component_v_main = resolveComponent("v-main");
  const _component_v_layout = resolveComponent("v-layout");
  return openBlock(), createBlock(_component_v_layout, { class: "rounded rounded-md" }, {
    default: withCtx(() => [
      createVNode(_component_v_app_bar, {
        color: "surface-variant",
        title: "Application bar"
      }),
      createVNode(_component_v_navigation_drawer, null, {
        default: withCtx(() => [
          createVNode(_component_v_list, null, {
            default: withCtx(() => [
              createVNode(_component_v_list_item, { title: "Drawer left" })
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_navigation_drawer, { location: "right" }, {
        default: withCtx(() => [
          createVNode(_component_v_list, null, {
            default: withCtx(() => [
              createVNode(_component_v_list_item, { title: "Drawer right" })
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_main, {
        class: "d-flex align-center justify-center",
        style: { "min-height": "300px" }
      }, {
        default: withCtx(() => [
          createTextVNode(" Main Content ")
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __5 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["render", _sfc_render$1]]);
const __5_raw = '<template>\n  <v-layout class="rounded rounded-md">\n    <v-app-bar color="surface-variant" title="Application bar"></v-app-bar>\n\n    <v-navigation-drawer>\n      <v-list>\n        <v-list-item title="Drawer left"></v-list-item>\n      </v-list>\n    </v-navigation-drawer>\n\n    <v-navigation-drawer location="right">\n      <v-list>\n        <v-list-item title="Drawer right"></v-list-item>\n      </v-list>\n    </v-navigation-drawer>\n\n    <v-main class="d-flex align-center justify-center" style="min-height: 300px;">\n      Main Content\n    </v-main>\n  </v-layout>\n</template>\n';
const _sfc_main = {};
function _sfc_render(_ctx, _cache) {
  const _component_v_list_item = resolveComponent("v-list-item");
  const _component_v_list = resolveComponent("v-list");
  const _component_v_navigation_drawer = resolveComponent("v-navigation-drawer");
  const _component_v_app_bar = resolveComponent("v-app-bar");
  const _component_v_main = resolveComponent("v-main");
  const _component_v_layout = resolveComponent("v-layout");
  return openBlock(), createBlock(_component_v_layout, { class: "rounded rounded-md" }, {
    default: withCtx(() => [
      createVNode(_component_v_navigation_drawer, null, {
        default: withCtx(() => [
          createVNode(_component_v_list, null, {
            default: withCtx(() => [
              createVNode(_component_v_list_item, { title: "Navigation drawer" })
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_app_bar, { title: "Application bar" }),
      createVNode(_component_v_main, {
        class: "d-flex align-center justify-center",
        style: { "min-height": "300px" }
      }, {
        default: withCtx(() => [
          createTextVNode(" Main Content ")
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __6 = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
const __6_raw = '<template>\n  <v-layout class="rounded rounded-md">\n    <v-navigation-drawer>\n      <v-list>\n        <v-list-item title="Navigation drawer"></v-list-item>\n      </v-list>\n    </v-navigation-drawer>\n\n    <v-app-bar title="Application bar"></v-app-bar>\n\n    <v-main class="d-flex align-center justify-center" style="min-height: 300px;">\n      Main Content\n    </v-main>\n  </v-layout>\n</template>\n';
const applicationLayout = {
  "app-bar-first": {
    component: __0,
    source: __0_raw
  },
  "discord": {
    component: __1,
    source: __1_raw
  },
  "dynamic": {
    component: __2,
    source: __2_raw
  },
  "layout-information-composable": {
    component: __3,
    source: __3_raw
  },
  "layout-information-ref": {
    component: __4,
    source: __4_raw
  },
  "location": {
    component: __5,
    source: __5_raw
  },
  "nav-drawer-first": {
    component: __6,
    source: __6_raw
  }
};
export {
  applicationLayout as default
};
