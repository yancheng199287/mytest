import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "application-layout" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "Vuetify features an application layout system that allows you to easily create complex website designs.", -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("p", null, "The system is built around an outside-in principle, where each application layout component reserves space for itself in one of four directions (left, right, up, down), leaving the available free space for any subsequent layout component(s) to occupy.", -1);
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, "The following components are compatible with the layout system:", -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("td", null, "A container that is used navigation, branding, search, and actions", -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "A system bar replaces the native phone system bar", -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("td", null, "A persistent or temporary container that holds site navigation links", -1);
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("td", null, "A generic component used to replace the default html footer", -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("td", null, "A persistent or temporary container that holds navigation links and is typically used for smaller devices", -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The final part of the layout system is the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "v-main"),
  /* @__PURE__ */ createTextVNode(" component. Inside this is where you place your page content. It will use the remaining free space on the page after all layout components have reserved their space.")
], -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("In the following examples, "),
  /* @__PURE__ */ createBaseVNode("strong", null, "v-app"),
  /* @__PURE__ */ createTextVNode(" has been replaced by "),
  /* @__PURE__ */ createBaseVNode("strong", null, "v-layout"),
  /* @__PURE__ */ createTextVNode(". This is because "),
  /* @__PURE__ */ createBaseVNode("strong", null, "v-app"),
  /* @__PURE__ */ createTextVNode(" defaults to a minimum height of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "100dvh"),
  /* @__PURE__ */ createTextVNode(". In your own application you would always use "),
  /* @__PURE__ */ createBaseVNode("strong", null, "v-app"),
  /* @__PURE__ */ createTextVNode(" for the root layout.")
], -1);
const _hoisted_13 = { id: "placing-components" };
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("By default, the order in which layout components will attempt to reserve space is simply the order that they appear in your markup. To illustrate this concept, see the following two examples where a single "),
  /* @__PURE__ */ createBaseVNode("strong", null, "v-app-bar"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "v-navigation-drawer"),
  /* @__PURE__ */ createTextVNode(" have changed places in the markup.")
], -1);
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("As you can see, placing the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "v-app-bar"),
  /* @__PURE__ */ createTextVNode(" before the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "v-navigation-drawer"),
  /* @__PURE__ */ createTextVNode(" means that it will use the full width of the screen. When it it placed after the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "v-navigation-drawer"),
  /* @__PURE__ */ createTextVNode(", it will only use the free space left over.")
], -1);
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Some layout components accept a "),
  /* @__PURE__ */ createBaseVNode("strong", null, "location"),
  /* @__PURE__ */ createTextVNode(" prop with which you can place the component in the layout. In the example below, we use two "),
  /* @__PURE__ */ createBaseVNode("strong", null, "v-navigation-drawer"),
  /* @__PURE__ */ createTextVNode(" components, one on each side of the application.")
], -1);
const _hoisted_17 = { id: "complex-layouts" };
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Let’s create a more complex layout to show the flexibility of the system. In the following example we have re-created the general layout of the Discord application. This example also demonstrates that layout components accept either a "),
  /* @__PURE__ */ createBaseVNode("strong", null, "width"),
  /* @__PURE__ */ createTextVNode(" or "),
  /* @__PURE__ */ createBaseVNode("strong", null, "height"),
  /* @__PURE__ */ createTextVNode(" prop, and that multiple components of the same type can be stacked in the same position.")
], -1);
const _hoisted_19 = { id: "dynamic-layouts-and-order" };
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("p", null, "In most cases, it should be enough to simply place your layout components in the correct order in your markup to achieve the layout you want. There are however a couple of scenarios where this might not be possible. One of these is if you want to change the order of your layout components dynamically.", -1);
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("To solve this you can explicitly set the layout order by using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "order"),
  /* @__PURE__ */ createTextVNode(" prop. Explore the example below to see what happens when using the prop. By toggling the switch, you change the order of the app-bar to "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "-1"),
  /* @__PURE__ */ createTextVNode(", thus putting it above the navigation-drawer in the layout ordering.")
], -1);
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("All layout components have a default order of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "0"),
  /* @__PURE__ */ createTextVNode(". Layout components with the same order will be ordered as they appear in the markup.")
], -1);
const _hoisted_23 = { id: "accessing-layout-information" };
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The layout system exposes a function "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "getLayoutItem"),
  /* @__PURE__ */ createTextVNode(" that allows you to get size and position information about a specific layout component in your markup. To use it, you will need to add a "),
  /* @__PURE__ */ createBaseVNode("strong", null, "name"),
  /* @__PURE__ */ createTextVNode(" prop to the layout component, and give it a unique value. You can either access the method by using a ref on "),
  /* @__PURE__ */ createBaseVNode("strong", null, "v-app"),
  /* @__PURE__ */ createTextVNode(", or by using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "useLayout"),
  /* @__PURE__ */ createTextVNode(" composable.")
], -1);
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You will not be able to directly use the composable in the same component where you are rendering the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "v-app"),
  /* @__PURE__ */ createTextVNode(" component. The call to "),
  /* @__PURE__ */ createBaseVNode("strong", null, "useLayout"),
  /* @__PURE__ */ createTextVNode(" must happen in a child component, so that the layout can be properly injected.")
], -1);
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The combined size of all layout components is also available under "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "layout.mainRect"),
  /* @__PURE__ */ createTextVNode(". This is used internally by the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "v-main"),
  /* @__PURE__ */ createTextVNode(" component to determine the size of the main content area.")
], -1);
const frontmatter = { "meta": { "title": "Application layout", "description": "Vuetify provides functionality to create complex layouts using components such as app bars and navigation drawers", "keywords": "application, layout, default layout" }, "related": ["/components/app-bars/", "/components/navigation-drawers/", "/components/footers/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "application-layout",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "Application layout", "description": "Vuetify provides functionality to create complex layouts using components such as app bars and navigation drawers", "keywords": "application, layout, default layout" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "title": "Application layout", "description": "Vuetify provides functionality to create complex layouts using components such as app bars and navigation drawers", "keywords": "application, layout, default layout" }, "related": ["/components/app-bars/", "/components/navigation-drawers/", "/components/footers/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_alert = resolveComponent("alert");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#application-layout",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Application layout")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_promoted_entry),
              _hoisted_3,
              _hoisted_4,
              createVNode(_component_app_table, null, {
                default: withCtx(() => [
                  _hoisted_5,
                  createBaseVNode("tbody", null, [
                    createBaseVNode("tr", null, [
                      createBaseVNode("td", null, [
                        createVNode(_component_app_link, { href: "/components/app-bars/" }, {
                          default: withCtx(() => [
                            createTextVNode("v-app-bar")
                          ]),
                          _: 1
                        })
                      ]),
                      _hoisted_6
                    ]),
                    createBaseVNode("tr", null, [
                      createBaseVNode("td", null, [
                        createVNode(_component_app_link, { href: "/components/system-bars/" }, {
                          default: withCtx(() => [
                            createTextVNode("v-system-bar")
                          ]),
                          _: 1
                        })
                      ]),
                      _hoisted_7
                    ]),
                    createBaseVNode("tr", null, [
                      createBaseVNode("td", null, [
                        createVNode(_component_app_link, { href: "/components/navigation-drawers/" }, {
                          default: withCtx(() => [
                            createTextVNode("v-navigation-drawer")
                          ]),
                          _: 1
                        })
                      ]),
                      _hoisted_8
                    ]),
                    createBaseVNode("tr", null, [
                      createBaseVNode("td", null, [
                        createVNode(_component_app_link, { href: "/components/footers/" }, {
                          default: withCtx(() => [
                            createTextVNode("v-footer")
                          ]),
                          _: 1
                        })
                      ]),
                      _hoisted_9
                    ]),
                    createBaseVNode("tr", null, [
                      createBaseVNode("td", null, [
                        createVNode(_component_app_link, { href: "/components/bottom-navigation/" }, {
                          default: withCtx(() => [
                            createTextVNode("v-bottom-navigation")
                          ]),
                          _: 1
                        })
                      ]),
                      _hoisted_10
                    ])
                  ])
                ]),
                _: 1
              }),
              _hoisted_11,
              createVNode(_component_alert, { type: "info" }, {
                default: withCtx(() => [
                  _hoisted_12
                ]),
                _: 1
              }),
              createBaseVNode("section", _hoisted_13, [
                createVNode(_component_app_heading, {
                  href: "#placing-components",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Placing components")
                  ]),
                  _: 1
                }),
                _hoisted_14,
                createVNode(_component_examples_example, { file: "application-layout/app-bar-first" }),
                createVNode(_component_examples_example, { file: "application-layout/nav-drawer-first" }),
                _hoisted_15,
                _hoisted_16,
                createVNode(_component_examples_example, { file: "application-layout/location" })
              ]),
              createBaseVNode("section", _hoisted_17, [
                createVNode(_component_app_heading, {
                  href: "#complex-layouts",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Complex layouts")
                  ]),
                  _: 1
                }),
                _hoisted_18,
                createVNode(_component_examples_example, { file: "application-layout/discord" })
              ]),
              createBaseVNode("section", _hoisted_19, [
                createVNode(_component_app_heading, {
                  href: "#dynamic-layouts-and-order",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Dynamic layouts and order")
                  ]),
                  _: 1
                }),
                _hoisted_20,
                _hoisted_21,
                _hoisted_22,
                createVNode(_component_examples_example, { file: "application-layout/dynamic" })
              ]),
              createBaseVNode("section", _hoisted_23, [
                createVNode(_component_app_heading, {
                  href: "#accessing-layout-information",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Accessing layout information")
                  ]),
                  _: 1
                }),
                _hoisted_24,
                createVNode(_component_examples_example, { file: "application-layout/layout-information-ref" }),
                createVNode(_component_alert, { type: "warning" }, {
                  default: withCtx(() => [
                    _hoisted_25
                  ]),
                  _: 1
                }),
                createVNode(_component_examples_example, { file: "application-layout/layout-information-composable" }),
                _hoisted_26
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
