import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "autocompletes" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-autocomplete"),
  /* @__PURE__ */ createTextVNode(" component offers simple and flexible type-ahead functionality. This is useful when searching large sets of data or even dynamically requesting information from an API.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The autocomplete component extends "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-select"),
  /* @__PURE__ */ createTextVNode(" and adds the ability to filter items.")
], -1);
const _hoisted_5 = { id: "api" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("td", null, "A select component that allows for filtering and custom values", -1);
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createTextVNode("A replacement for the HTML "),
  /* @__PURE__ */ createBaseVNode("select")
], -1);
const _hoisted_10 = { id: "caveats" };
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("When using objects for the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "items"),
  /* @__PURE__ */ createTextVNode(" prop, you must associate "),
  /* @__PURE__ */ createBaseVNode("strong", null, "item-title"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "item-value"),
  /* @__PURE__ */ createTextVNode(" with existing properties on your objects. These values are defaulted to "),
  /* @__PURE__ */ createBaseVNode("strong", null, "title"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "value"),
  /* @__PURE__ */ createTextVNode(" and can be changed.")
], -1);
const _hoisted_12 = { id: "examples" };
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("p", null, "Below is a collection of simple to complex examples.", -1);
const _hoisted_14 = { id: "props" };
const _hoisted_15 = { id: "density" };
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can use "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "density"),
  /* @__PURE__ */ createTextVNode(" prop to adjust vertical spacing within the component.")
], -1);
const _hoisted_17 = { id: "filter" };
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "custom-filter"),
  /* @__PURE__ */ createTextVNode(" prop can be used to filter each individual item with custom logic. In this example we filter items by name.")
], -1);
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "TIP:")
], -1);
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "v-autocomplete"),
  /* @__PURE__ */ createTextVNode(" component updates the search model on focus/blur events. Focus sets search to the current model (if available), and blur clears it.")
], -1);
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Unlike "),
  /* @__PURE__ */ createBaseVNode("strong", null, "v-combobox"),
  /* @__PURE__ */ createTextVNode(", it doesn’t keep unlisted values. To prevent unnecessary API requests when querying, ensure that search is not empty and/or doesn’t match the current model.")
], -1);
const _hoisted_22 = { id: "slots" };
const _hoisted_23 = { id: "item-and-selection" };
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("p", null, "With the power of slots, you can customize the visual output of the select. In this example we add a profile picture for both the chips and list items.", -1);
const _hoisted_25 = { id: "misc" };
const _hoisted_26 = { id: "state-selector" };
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Using a combination of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-autocomplete"),
  /* @__PURE__ */ createTextVNode(" slots and transitions, you can create a stylish toggleable autocomplete field such as this state selector.")
], -1);
const _hoisted_28 = { id: "new-tab" };
const _hoisted_29 = /* @__PURE__ */ createBaseVNode("strong", null, "auto-select-first", -1);
const frontmatter = { "meta": { "nav": "Autocompletes", "title": "Autocomplete component", "description": "The autocomplete component provides type-ahead autocomplete functionality and provides a list of available options.", "keywords": "autocomplete, vuetify autocomplete component, vue autocomplete component" }, "related": ["/components/combobox/", "/components/forms/", "/components/selects/"], "features": { "figma": true, "label": "C: VAutocomplete", "report": true, "github": "/components/VAutocomplete/", "spec": "https://m2.material.io/components/text-fields" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "autocompletes",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Autocompletes", "title": "Autocomplete component", "description": "The autocomplete component provides type-ahead autocomplete functionality and provides a list of available options.", "keywords": "autocomplete, vuetify autocomplete component, vue autocomplete component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Autocompletes", "title": "Autocomplete component", "description": "The autocomplete component provides type-ahead autocomplete functionality and provides a list of available options.", "keywords": "autocomplete, vuetify autocomplete component, vue autocomplete component" }, "related": ["/components/combobox/", "/components/forms/", "/components/selects/"], "features": { "figma": true, "label": "C: VAutocomplete", "report": true, "github": "/components/VAutocomplete/", "spec": "https://m2.material.io/components/text-fields" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_alert = resolveComponent("alert");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_v_kbd = resolveComponent("v-kbd");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#autocompletes",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Autocompletes")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_usage, { name: "v-autocomplete" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_6,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-autocomplete/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-autocomplete")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-combobox/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-combobox")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_8
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-select/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-select")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_9
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_10, [
                createVNode(_component_app_heading, {
                  href: "#caveats",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Caveats")
                  ]),
                  _: 1
                }),
                createVNode(_component_alert, { type: "error" }, {
                  default: withCtx(() => [
                    _hoisted_11
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_12, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                _hoisted_13,
                createBaseVNode("section", _hoisted_14, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_15, [
                    createVNode(_component_app_heading, {
                      href: "#density",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Density")
                      ]),
                      _: 1
                    }),
                    _hoisted_16,
                    createVNode(_component_examples_example, { file: "v-autocomplete/prop-density" })
                  ]),
                  createBaseVNode("section", _hoisted_17, [
                    createVNode(_component_app_heading, {
                      href: "#filter",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Filter")
                      ]),
                      _: 1
                    }),
                    _hoisted_18,
                    createVNode(_component_examples_example, { file: "v-autocomplete/prop-filter" }),
                    createVNode(_component_alert, { type: "tip" }, {
                      default: withCtx(() => [
                        _hoisted_19,
                        _hoisted_20,
                        _hoisted_21
                      ]),
                      _: 1
                    })
                  ])
                ]),
                createBaseVNode("section", _hoisted_22, [
                  createVNode(_component_app_heading, {
                    href: "#slots",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Slots")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_23, [
                    createVNode(_component_app_heading, {
                      href: "#item-and-selection",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Item and selection")
                      ]),
                      _: 1
                    }),
                    _hoisted_24,
                    createVNode(_component_examples_example, { file: "v-autocomplete/slot-item-and-selection" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_25, [
                  createVNode(_component_app_heading, {
                    href: "#misc",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Misc")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_26, [
                    createVNode(_component_app_heading, {
                      href: "#state-selector",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("State selector")
                      ]),
                      _: 1
                    }),
                    _hoisted_27,
                    createVNode(_component_examples_example, { file: "v-autocomplete/misc-state-selector" })
                  ]),
                  createBaseVNode("section", _hoisted_28, [
                    createVNode(_component_app_heading, {
                      href: "#new-tab",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("New tab")
                      ]),
                      _: 1
                    }),
                    createVNode(_component_alert, { type: "success" }, {
                      default: withCtx(() => [
                        createBaseVNode("p", null, [
                          createTextVNode("This feature was introduced in "),
                          createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v3.3.0" }, {
                            default: withCtx(() => [
                              createTextVNode("v3.3.0 (Icarus)")
                            ]),
                            _: 1
                          })
                        ])
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("The "),
                      _hoisted_29,
                      createTextVNode(" property highlights the first result when searching, allowing you to press "),
                      createVNode(_component_v_kbd, null, {
                        default: withCtx(() => [
                          createTextVNode("tab")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" or "),
                      createVNode(_component_v_kbd, null, {
                        default: withCtx(() => [
                          createTextVNode("enter")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" to quickly select it.")
                    ]),
                    createVNode(_component_examples_example, { file: "v-autocomplete/misc-new-tab" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
