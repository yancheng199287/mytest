import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "avatars" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-avatar"),
  /* @__PURE__ */ createTextVNode(" component is typically used to display circular user profile pictures. This component will allow you to dynamically size and add a border radius of responsive images, icons, and text. When "),
  /* @__PURE__ */ createBaseVNode("strong", null, "rounded"),
  /* @__PURE__ */ createTextVNode(" prop set to "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "0"),
  /* @__PURE__ */ createTextVNode(" will display an avatar without border radius.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, "Avatars in their simplest form display content within a circular container.", -1);
const _hoisted_5 = { id: "api" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_8 = { id: "anatomy" };
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The recommended placement of elements inside of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-avatar"),
  /* @__PURE__ */ createTextVNode(" is:")
], -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("em", null, "slot", -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createTextVNode("Place textual content within the default "),
  /* @__PURE__ */ createBaseVNode("em", null, "slot")
], -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Element / Area"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("td", null, "1. Container", -1);
const _hoisted_14 = { id: "examples" };
const _hoisted_15 = { id: "props" };
const _hoisted_16 = { id: "size" };
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "size"),
  /* @__PURE__ */ createTextVNode(" prop allows you to change the height and width of the avatar.")
], -1);
const _hoisted_18 = { id: "tile" };
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "rounded"),
  /* @__PURE__ */ createTextVNode(" prop can be used to remove the border radius from v-avatar leaving you with a simple square avatar.")
], -1);
const _hoisted_20 = { id: "slots" };
const _hoisted_21 = { id: "default" };
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-avatar"),
  /* @__PURE__ */ createTextVNode(" default slot allows you to render content such as "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-icon"),
  /* @__PURE__ */ createTextVNode(" components, images, or text. Mix and match these with other props to create something unique.")
], -1);
const _hoisted_23 = { id: "misc" };
const _hoisted_24 = { id: "advanced-usage" };
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("p", null, "Combining an avatar with other components allows you to build beautiful user interfaces right out of the box.", -1);
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("p", null, "Another example combining avatar with menu.", -1);
const _hoisted_27 = { id: "profile-card" };
const _hoisted_28 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "rounded"),
  /* @__PURE__ */ createTextVNode(" prop value "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "0"),
  /* @__PURE__ */ createTextVNode(", we can create a sleek hard-lined profile card.")
], -1);
const frontmatter = { "meta": { "nav": "Avatars", "title": "Avatar component", "description": "The avatar component is used to control the size and border radius of an image. It can be used with numerous components to provide better visual context.", "keywords": "avatars, vuetify avatar component, vue avatar component" }, "related": ["/components/badges/", "/components/icons/", "/components/lists/"], "features": { "figma": true, "github": "/components/VAvatar/", "label": "C: VAvatar", "report": true } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "avatars",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Avatars", "title": "Avatar component", "description": "The avatar component is used to control the size and border radius of an image. It can be used with numerous components to provide better visual context.", "keywords": "avatars, vuetify avatar component, vue avatar component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Avatars", "title": "Avatar component", "description": "The avatar component is used to control the size and border radius of an image. It can be used with numerous components to provide better visual context.", "keywords": "avatars, vuetify avatar component, vue avatar component" }, "related": ["/components/badges/", "/components/icons/", "/components/lists/"], "features": { "figma": true, "github": "/components/VAvatar/", "label": "C: VAvatar", "report": true } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_app_figure = resolveComponent("app-figure");
      const _component_page_features = resolveComponent("page-features");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_promoted_promoted = resolveComponent("promoted-promoted");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#avatars",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Avatars")
                ]),
                _: 1
              }),
              _hoisted_2,
              createBaseVNode("p", null, [
                createBaseVNode("div", null, [
                  createVNode(_component_app_figure, {
                    alt: "Avatar Entry",
                    src: "https://cdn.vuetifyjs.com/docs/images/components-temp/v-avatar/v-avatar-entry.png"
                  })
                ])
              ]),
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_usage, { name: "v-avatar" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_6,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-avatar/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-avatar")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ])
                    ])
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_8, [
                createVNode(_component_app_heading, {
                  href: "#anatomy",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Anatomy")
                  ]),
                  _: 1
                }),
                _hoisted_9,
                createBaseVNode("ul", null, [
                  createBaseVNode("li", null, [
                    createTextVNode("Place a "),
                    createVNode(_component_app_link, { href: "/components/images/" }, {
                      default: withCtx(() => [
                        createTextVNode("v-img")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" or "),
                    createVNode(_component_app_link, { href: "/components/images/" }, {
                      default: withCtx(() => [
                        createTextVNode("v-icon")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" component within the default "),
                    _hoisted_10
                  ]),
                  _hoisted_11
                ]),
                createBaseVNode("p", null, [
                  createBaseVNode("div", null, [
                    createVNode(_component_app_figure, {
                      alt: "Avatar Anatomy",
                      src: "https://cdn.vuetifyjs.com/docs/images/components-temp/v-avatar/v-avatar-anatomy.png"
                    })
                  ])
                ]),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_12,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        _hoisted_13,
                        createBaseVNode("td", null, [
                          createTextVNode("The Avatar container that typically holds a "),
                          createVNode(_component_app_link, { href: "/components/icons/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-icon")
                            ]),
                            _: 1
                          }),
                          createTextVNode(" or "),
                          createVNode(_component_app_link, { href: "/components/images/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-img")
                            ]),
                            _: 1
                          }),
                          createTextVNode(" component")
                        ])
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_14, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_15, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_16, [
                    createVNode(_component_app_heading, {
                      href: "#size",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Size")
                      ]),
                      _: 1
                    }),
                    _hoisted_17,
                    createVNode(_component_examples_example, { file: "v-avatar/prop-size" })
                  ]),
                  createBaseVNode("section", _hoisted_18, [
                    createVNode(_component_app_heading, {
                      href: "#tile",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Tile")
                      ]),
                      _: 1
                    }),
                    _hoisted_19,
                    createVNode(_component_examples_example, { file: "v-avatar/prop-tile" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_20, [
                  createVNode(_component_app_heading, {
                    href: "#slots",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Slots")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_21, [
                    createVNode(_component_app_heading, {
                      href: "#default",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Default")
                      ]),
                      _: 1
                    }),
                    _hoisted_22,
                    createVNode(_component_examples_example, { file: "v-avatar/slot-default" }),
                    createVNode(_component_promoted_promoted)
                  ])
                ]),
                createBaseVNode("section", _hoisted_23, [
                  createVNode(_component_app_heading, {
                    href: "#misc",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Misc")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_24, [
                    createVNode(_component_app_heading, {
                      href: "#advanced-usage",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Advanced usage")
                      ]),
                      _: 1
                    }),
                    _hoisted_25,
                    createVNode(_component_examples_example, { file: "v-avatar/misc-advanced" }),
                    _hoisted_26,
                    createVNode(_component_examples_example, { file: "v-avatar/misc-avatar-menu" })
                  ]),
                  createBaseVNode("section", _hoisted_27, [
                    createVNode(_component_app_heading, {
                      href: "#profile-card",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Profile Card")
                      ]),
                      _: 1
                    }),
                    _hoisted_28,
                    createVNode(_component_examples_example, { file: "v-avatar/misc-profile-card" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
