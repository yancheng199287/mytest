import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "banners" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-banner"),
  /* @__PURE__ */ createTextVNode(" component is used as a middle-interrupting message to the user with one to two actions.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Banners come in two variations "),
  /* @__PURE__ */ createBaseVNode("strong", null, "single-line"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "multi-line"),
  /* @__PURE__ */ createTextVNode(" (implicit). These can have icons and actions that you can use with your message.")
], -1);
const _hoisted_5 = { id: "api" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createTextVNode("Sub-component used to display the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-banner"),
  /* @__PURE__ */ createTextVNode(" subtitle. Wraps the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "#text"),
  /* @__PURE__ */ createTextVNode(" slot")
], -1);
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "#actions", -1);
const _hoisted_10 = { id: "anatomy" };
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The recommended placement of elements inside of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-banner"),
  /* @__PURE__ */ createTextVNode(" is:")
], -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Place a "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-banner-avatar"),
    /* @__PURE__ */ createTextVNode(" or "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-banner-icon"),
    /* @__PURE__ */ createTextVNode(" on the far left")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Place "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-banner-text"),
    /* @__PURE__ */ createTextVNode(" to the right of any visual content")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Place "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-banner-actions"),
    /* @__PURE__ */ createTextVNode(" to the far right of textual content, offset bottom")
  ])
], -1);
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Element / Area"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("tr", null, [
  /* @__PURE__ */ createBaseVNode("td", null, "1. Container"),
  /* @__PURE__ */ createBaseVNode("td", null, [
    /* @__PURE__ */ createTextVNode("The Banner container holds all "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-banner"),
    /* @__PURE__ */ createTextVNode(" components")
  ])
], -1);
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("tr", null, [
  /* @__PURE__ */ createBaseVNode("td", null, "2. Avatar / Icon (optional)"),
  /* @__PURE__ */ createBaseVNode("td", null, "Leading media content intended to improve visual context")
], -1);
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("tr", null, [
  /* @__PURE__ */ createBaseVNode("td", null, "3. Text"),
  /* @__PURE__ */ createBaseVNode("td", null, "A content area for displaying text and other inline elements")
], -1);
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("td", null, "4. Actions (optional)", -1);
const _hoisted_18 = { id: "examples" };
const _hoisted_19 = { id: "props" };
const _hoisted_20 = { id: "lines" };
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The prop "),
  /* @__PURE__ */ createBaseVNode("strong", null, "lines"),
  /* @__PURE__ */ createTextVNode(" can be used to specify how the displayed text should be handled based on its length.")
], -1);
const _hoisted_22 = { id: "sticky" };
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can optionally turn on the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "sticky"),
  /* @__PURE__ */ createTextVNode(" prop to ensure that the content is pinned to the top of the screen.")
], -1);
const _hoisted_24 = { id: "slots" };
const _hoisted_25 = { id: "actions" };
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("p", null, "Banners may have one or two text buttons that don’t stand out that much.", -1);
const _hoisted_27 = { id: "icon" };
const _hoisted_28 = /* @__PURE__ */ createBaseVNode("p", null, "The icon slot allows you to to explicitly control the content and functionality within it.", -1);
const _hoisted_29 = { id: "prepend" };
const _hoisted_30 = /* @__PURE__ */ createBaseVNode("p", null, "The prepend slot allows you to to explicitly control the content and functionality within it. Icons also help to emphasize a banner’s message.", -1);
const frontmatter = { "meta": { "nav": "Banners", "title": "Banner component", "description": "The banner component displays an important and concise message for a user to address. It can also indicate actions that the user can take.", "keywords": "banners, vuetify banner component, vue banner component" }, "related": ["/components/alerts/", "/components/icons/", "/components/snackbars/"], "features": { "figma": true, "github": "/components/VBanner/", "label": "C: VBanner", "report": true, "spec": "https://m2.material.io/components/banners" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "banners",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Banners", "title": "Banner component", "description": "The banner component displays an important and concise message for a user to address. It can also indicate actions that the user can take.", "keywords": "banners, vuetify banner component, vue banner component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Banners", "title": "Banner component", "description": "The banner component displays an important and concise message for a user to address. It can also indicate actions that the user can take.", "keywords": "banners, vuetify banner component, vue banner component" }, "related": ["/components/alerts/", "/components/icons/", "/components/snackbars/"], "features": { "figma": true, "github": "/components/VBanner/", "label": "C: VBanner", "report": true, "spec": "https://m2.material.io/components/banners" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_app_figure = resolveComponent("app-figure");
      const _component_page_features = resolveComponent("page-features");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#banners",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Banners")
                ]),
                _: 1
              }),
              _hoisted_2,
              createBaseVNode("p", null, [
                createBaseVNode("div", null, [
                  createVNode(_component_app_figure, {
                    alt: "Banner Entry",
                    src: "https://cdn.vuetifyjs.com/docs/images/components-temp/v-banner/v-banner-entry.png"
                  })
                ])
              ]),
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_usage, { name: "v-banner" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_6,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-banner/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-banner")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-banner-text/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-banner-text")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_8
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-banner-actions/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-banner-actions")
                            ]),
                            _: 1
                          })
                        ]),
                        createBaseVNode("td", null, [
                          createTextVNode("Sub-component that modifies the default styling of "),
                          createVNode(_component_app_link, { href: "/components/buttons/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-btn")
                            ]),
                            _: 1
                          }),
                          createTextVNode(". Wraps the "),
                          _hoisted_9,
                          createTextVNode(" slot")
                        ])
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_10, [
                createVNode(_component_app_heading, {
                  href: "#anatomy",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Anatomy")
                  ]),
                  _: 1
                }),
                _hoisted_11,
                _hoisted_12,
                createBaseVNode("p", null, [
                  createBaseVNode("div", null, [
                    createVNode(_component_app_figure, {
                      alt: "Banner Anatomy",
                      src: "https://cdn.vuetifyjs.com/docs/images/components-temp/v-banner/v-banner-anatomy.png"
                    })
                  ])
                ]),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_13,
                    createBaseVNode("tbody", null, [
                      _hoisted_14,
                      _hoisted_15,
                      _hoisted_16,
                      createBaseVNode("tr", null, [
                        _hoisted_17,
                        createBaseVNode("td", null, [
                          createTextVNode("A content area that typically contains one or more "),
                          createVNode(_component_app_link, { href: "/components/buttons" }, {
                            default: withCtx(() => [
                              createTextVNode("v-btn")
                            ]),
                            _: 1
                          }),
                          createTextVNode(" components")
                        ])
                      ])
                    ])
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_18, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_19, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_20, [
                    createVNode(_component_app_heading, {
                      href: "#lines",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Lines")
                      ]),
                      _: 1
                    }),
                    _hoisted_21,
                    createVNode(_component_examples_example, { file: "v-banner/prop-lines" })
                  ]),
                  createBaseVNode("section", _hoisted_22, [
                    createVNode(_component_app_heading, {
                      href: "#sticky",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Sticky")
                      ]),
                      _: 1
                    }),
                    _hoisted_23,
                    createVNode(_component_examples_example, { file: "v-banner/prop-sticky" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_24, [
                  createVNode(_component_app_heading, {
                    href: "#slots",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Slots")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_25, [
                    createVNode(_component_app_heading, {
                      href: "#actions",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Actions")
                      ]),
                      _: 1
                    }),
                    _hoisted_26,
                    createVNode(_component_examples_example, { file: "v-banner/slot-actions" })
                  ]),
                  createBaseVNode("section", _hoisted_27, [
                    createVNode(_component_app_heading, {
                      href: "#icon",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Icon")
                      ]),
                      _: 1
                    }),
                    _hoisted_28,
                    createVNode(_component_examples_example, { file: "v-banner/slot-icon" })
                  ]),
                  createBaseVNode("section", _hoisted_29, [
                    createVNode(_component_app_heading, {
                      href: "#prepend",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Prepend")
                      ]),
                      _: 1
                    }),
                    _hoisted_30,
                    createVNode(_component_examples_example, { file: "v-banner/slot-prepend" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
