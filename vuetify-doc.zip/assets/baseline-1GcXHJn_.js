import { J as ref, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _sfc_main = {
  __name: "baseline",
  setup(__props) {
    const drawer = ref(null);
    return (_ctx, _cache) => {
      const _component_v_navigation_drawer = resolveComponent("v-navigation-drawer");
      const _component_v_app_bar_nav_icon = resolveComponent("v-app-bar-nav-icon");
      const _component_v_app_bar_title = resolveComponent("v-app-bar-title");
      const _component_v_app_bar = resolveComponent("v-app-bar");
      const _component_v_main = resolveComponent("v-main");
      const _component_v_app = resolveComponent("v-app");
      return openBlock(), createBlock(_component_v_app, { id: "inspire" }, {
        default: withCtx(() => [
          createVNode(_component_v_navigation_drawer, {
            modelValue: drawer.value,
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => drawer.value = $event)
          }, null, 8, ["modelValue"]),
          createVNode(_component_v_app_bar, null, {
            default: withCtx(() => [
              createVNode(_component_v_app_bar_nav_icon, {
                onClick: _cache[1] || (_cache[1] = ($event) => drawer.value = !drawer.value)
              }),
              createVNode(_component_v_app_bar_title, null, {
                default: withCtx(() => [
                  createTextVNode("Application")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_main)
        ]),
        _: 1
      });
    };
  }
};
const __0 = _sfc_main;
export {
  __0 as _
};
