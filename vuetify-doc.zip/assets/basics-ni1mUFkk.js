import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "data-tables" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-data-table"),
  /* @__PURE__ */ createTextVNode(" component is used for displaying tabular data. Features include sorting, searching, pagination, grouping, and row selection.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, "The standard data table presumes that the entire data set is available locally. Sorting, pagination, and filtering is supported and done internally by the component itself.", -1);
const _hoisted_5 = { id: "api" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("td", null, "Functional Component used to display Data-table headers", -1);
const _hoisted_9 = { id: "server-side-tables" };
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("p", null, "This variant of the data table is meant to be used for very large datasets, where it would be inefficient to load all the data into the client. It supports sorting, filtering, pagination, and selection like a standard data table, but all the logic must be handled externally by your backend or database.", -1);
const _hoisted_11 = { id: "virtual-tables" };
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("p", null, "The virtual variant of the data table relies, like the standard variant, on all data being available locally. But unlike the standard variant it uses virtualization to only render a small portion of the rows. This makes it well suited for displaying large data sets. It supports client-side sorting and filtering, but not pagination.", -1);
const _hoisted_13 = { id: "guide" };
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-data-table"),
  /* @__PURE__ */ createTextVNode(" component is a simple and powerful table manipulation component. It is perfect for showing large amounts of tabular data.")
], -1);
const _hoisted_15 = { id: "items" };
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("p", null, "Table items can be objects with almost any shape or number of properties. The only requirement is some form of unique identifier if row selection is being utilized.", -1);
const _hoisted_17 = { id: "headers" };
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The headers array is the core of the table. It defines which properties to display, their associated labels, how they should be sorted, and what they should look like. "),
  /* @__PURE__ */ createBaseVNode("br"),
  /* @__PURE__ */ createTextVNode(" All properties are optional, but at least one of "),
  /* @__PURE__ */ createBaseVNode("strong", null, "title"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "value"),
  /* @__PURE__ */ createTextVNode(", or "),
  /* @__PURE__ */ createBaseVNode("strong", null, "key"),
  /* @__PURE__ */ createTextVNode(" should be present to display more than just an empty column:")
], -1);
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-js" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-js" }, [
    /* @__PURE__ */ createTextVNode("headers "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "="),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "["),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "title"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'No data, just a label'"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "key"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'quantity'"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "value"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'price'"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "]"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("p", null, "Without any headers defined, the table will use all the keys of the first item as headers.", -1);
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Headers can also be a tree structure with a "),
  /* @__PURE__ */ createBaseVNode("strong", null, "children"),
  /* @__PURE__ */ createTextVNode(" property to create multi-row header labels with rowspan and colspan calculated automatically. "),
  /* @__PURE__ */ createBaseVNode("br"),
  /* @__PURE__ */ createTextVNode(" Leaf nodes (objects without "),
  /* @__PURE__ */ createBaseVNode("strong", null, "children"),
  /* @__PURE__ */ createTextVNode(") will be used as columns for each item. "),
  /* @__PURE__ */ createBaseVNode("br"),
  /* @__PURE__ */ createTextVNode(" Branch nodes (objects with "),
  /* @__PURE__ */ createBaseVNode("strong", null, "children"),
  /* @__PURE__ */ createTextVNode(") support all the same sorting and filtering options as leaf nodes, but cannot be used as columns.")
], -1);
const _hoisted_22 = { id: "keys-and-values" };
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "key"),
  /* @__PURE__ */ createTextVNode(" property is used to identify the column in slots, events, filters, and sort functions. It will default to the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "value"),
  /* @__PURE__ */ createTextVNode(" property if "),
  /* @__PURE__ */ createBaseVNode("strong", null, "value"),
  /* @__PURE__ */ createTextVNode(" is a string. "),
  /* @__PURE__ */ createBaseVNode("br"),
  /* @__PURE__ */ createBaseVNode("strong", null, "value"),
  /* @__PURE__ */ createTextVNode(" maps the column to a property in the items array. If "),
  /* @__PURE__ */ createBaseVNode("strong", null, "value"),
  /* @__PURE__ */ createTextVNode(" is not defined it will default to "),
  /* @__PURE__ */ createBaseVNode("strong", null, "key"),
  /* @__PURE__ */ createTextVNode(", so key and value are interchangeable in most cases. The exception to this is reserved keys like "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "data-table-select"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "data-table-expand"),
  /* @__PURE__ */ createTextVNode(" which must be defined as "),
  /* @__PURE__ */ createBaseVNode("strong", null, "key"),
  /* @__PURE__ */ createTextVNode(" to work properly. "),
  /* @__PURE__ */ createBaseVNode("br"),
  /* @__PURE__ */ createBaseVNode("strong", null, "key"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "value"),
  /* @__PURE__ */ createTextVNode(" both support dot notation to access properties of nested objects, and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "value"),
  /* @__PURE__ */ createTextVNode(" can also be a function to combine multiple properties or do other custom formatting. If "),
  /* @__PURE__ */ createBaseVNode("strong", null, "value"),
  /* @__PURE__ */ createTextVNode(" is not a string then "),
  /* @__PURE__ */ createBaseVNode("strong", null, "key"),
  /* @__PURE__ */ createTextVNode(" must be defined.")
], -1);
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-js" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-js" }, [
    /* @__PURE__ */ createTextVNode("items "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "="),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "["),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "id"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token number" }, "1"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "name"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "first"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'John'"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "last"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'Doe'"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "]"),
    /* @__PURE__ */ createTextVNode("\nheaders "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "="),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "["),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "title"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'First Name'"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "value"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'name.first'"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "title"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'Last Name'"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "key"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'name.last'"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "title"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'Full Name'"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "key"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'fullName'"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function-variable function" }, "value"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token parameter" }, "item"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "=>"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token template-string" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token template-punctuation string" }, "`"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token interpolation" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token interpolation-punctuation punctuation" }, "${"),
        /* @__PURE__ */ createTextVNode("item"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "."),
        /* @__PURE__ */ createTextVNode("name"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "."),
        /* @__PURE__ */ createTextVNode("first"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token interpolation-punctuation punctuation" }, "}")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, " "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token interpolation" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token interpolation-punctuation punctuation" }, "${"),
        /* @__PURE__ */ createTextVNode("item"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "."),
        /* @__PURE__ */ createTextVNode("name"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "."),
        /* @__PURE__ */ createTextVNode("last"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token interpolation-punctuation punctuation" }, "}")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token template-punctuation string" }, "`")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "]"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_25 = { id: "sorting-filtering-pagination" };
const _hoisted_26 = { id: "customization" };
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Other options are available for setting "),
  /* @__PURE__ */ createBaseVNode("strong", null, "width"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "align"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "fixed"),
  /* @__PURE__ */ createTextVNode(", or pass custom props to the header element with "),
  /* @__PURE__ */ createBaseVNode("strong", null, "headerProps"),
  /* @__PURE__ */ createTextVNode(" and row cells with "),
  /* @__PURE__ */ createBaseVNode("strong", null, "cellProps"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_28 = { id: "props" };
const _hoisted_29 = /* @__PURE__ */ createBaseVNode("p", null, "There are no shortable of properties available for customizing various aspects of the Data table components.", -1);
const _hoisted_30 = { id: "density" };
const _hoisted_31 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "density"),
  /* @__PURE__ */ createTextVNode(" prop you are able to give your data tables an alternate style.")
], -1);
const _hoisted_32 = { id: "selection" };
const _hoisted_33 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "show-select"),
  /* @__PURE__ */ createTextVNode(" prop will render a checkbox in the default header to toggle all rows, and a checkbox for each row.")
], -1);
const _hoisted_34 = { id: "simple-checkbox" };
const _hoisted_35 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("When wanting to use a checkbox component inside of a slot template in your data tables, use the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-checkbox-btn"),
  /* @__PURE__ */ createTextVNode(" component rather than the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-checkbox"),
  /* @__PURE__ */ createTextVNode(" component. The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-checkbox-btn"),
  /* @__PURE__ */ createTextVNode(" component is used internally and will respect header alignment.")
], -1);
const _hoisted_36 = { id: "slots" };
const _hoisted_37 = { id: "header-slot" };
const _hoisted_38 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can use the dynamic slots "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "header.<key>"),
  /* @__PURE__ */ createTextVNode(" to customize only certain columns. "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<key>"),
  /* @__PURE__ */ createTextVNode(" corresponds to the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "key"),
  /* @__PURE__ */ createTextVNode(" property in the items found in the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "headers"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_39 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("There are two built-in slots for customizing both the select ("),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "header.data-table-select"),
  /* @__PURE__ */ createTextVNode(") and expand ("),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "header.data-table-expand"),
  /* @__PURE__ */ createTextVNode(") columns when using "),
  /* @__PURE__ */ createBaseVNode("strong", null, "show-select"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "show-expand"),
  /* @__PURE__ */ createTextVNode(" props respectively.")
], -1);
const _hoisted_40 = { id: "headers-slot" };
const _hoisted_41 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can also override all the internal headers by using the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "headers"),
  /* @__PURE__ */ createTextVNode(" slot. Remember that you will have to re-implement any internal functionality like sorting.")
], -1);
const _hoisted_42 = { id: "item-slot" };
const _hoisted_43 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Normally you would use the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "item.<key>"),
  /* @__PURE__ */ createTextVNode(" slots to render custom markup in specific columns. If you instead need more control over the entire row, you can use the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "item"),
  /* @__PURE__ */ createTextVNode(" slot.")
], -1);
const _hoisted_44 = { id: "item-key-slot" };
const _hoisted_45 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can use the dynamic slots "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "item.<key>"),
  /* @__PURE__ */ createTextVNode(" to customize only certain columns. "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<key>"),
  /* @__PURE__ */ createTextVNode(" is the name of the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "key"),
  /* @__PURE__ */ createTextVNode(" property in header items sent to "),
  /* @__PURE__ */ createBaseVNode("strong", null, "headers"),
  /* @__PURE__ */ createTextVNode(". So to customize the calories column we’re using the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "item.calories"),
  /* @__PURE__ */ createTextVNode(" slot.")
], -1);
const _hoisted_46 = { id: "group-header-slot" };
const _hoisted_47 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("When using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "group-by"),
  /* @__PURE__ */ createTextVNode(" prop, you can customize the group header with the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "group-header"),
  /* @__PURE__ */ createTextVNode(" slot.")
], -1);
const _hoisted_48 = { id: "loading-slot" };
const _hoisted_49 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "loading", -1);
const _hoisted_50 = { id: "examples" };
const _hoisted_51 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The following are a collection of examples that demonstrate more advanced and real world use of the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-data-table"),
  /* @__PURE__ */ createTextVNode(" component.")
], -1);
const _hoisted_52 = { id: "crud-actions" };
const _hoisted_53 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-data-table"),
  /* @__PURE__ */ createTextVNode(" with CRUD actions using a "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-dialog"),
  /* @__PURE__ */ createTextVNode(" component for editing each row")
], -1);
const _hoisted_54 = { id: "expandable-rows" };
const _hoisted_55 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "show-expand"),
  /* @__PURE__ */ createTextVNode(" prop will render an expand icon on each row. You can customize this with the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "item.data-table-expand"),
  /* @__PURE__ */ createTextVNode(" slot. The position of this slot can be changed by adding a column with "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "key: 'data-table-expand'"),
  /* @__PURE__ */ createTextVNode(" to the headers array.")
], -1);
const _hoisted_56 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Just like selection, row items require a unique property on each item for expansion to work. The default is "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "id"),
  /* @__PURE__ */ createTextVNode(", but you can use the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "item-value"),
  /* @__PURE__ */ createTextVNode(" prop to specify a different item property.")
], -1);
const frontmatter = { "meta": { "nav": "Basics", "title": "Data table component", "description": "The data table component is used for displaying tabular data in a way that is easy for users to scan. It includes sorting, searching, pagination and selection.", "keywords": "data tables, vuetify data table component, vue data table component" }, "related": ["/components/paginations/", "/components/tables/", "/components/lists/"], "features": { "github": "/components/VDataTable/", "label": "C: VDataTable", "report": true, "spec": "https://m2.material.io/components/data-tables" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "basics",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Basics", "title": "Data table component", "description": "The data table component is used for displaying tabular data in a way that is easy for users to scan. It includes sorting, searching, pagination and selection.", "keywords": "data tables, vuetify data table component, vue data table component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Basics", "title": "Data table component", "description": "The data table component is used for displaying tabular data in a way that is easy for users to scan. It includes sorting, searching, pagination and selection.", "keywords": "data tables, vuetify data table component, vue data table component" }, "related": ["/components/paginations/", "/components/tables/", "/components/lists/"], "features": { "github": "/components/VDataTable/", "label": "C: VDataTable", "report": true, "spec": "https://m2.material.io/components/data-tables" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_app_markup = resolveComponent("app-markup");
      const _component_alert = resolveComponent("alert");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#data-tables",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Data tables")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_usage, { name: "v-data-table" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_6,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-data-table/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-data-table")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-data-table-footer/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-data-table-footer")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_8
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-checkbox-btn/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-checkbox-btn")
                            ]),
                            _: 1
                          })
                        ]),
                        createBaseVNode("td", null, [
                          createTextVNode("Reusable lightweight "),
                          createVNode(_component_app_link, { href: "/components/checkboxes" }, {
                            default: withCtx(() => [
                              createTextVNode("v-checkbox")
                            ]),
                            _: 1
                          })
                        ])
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" }),
                createBaseVNode("section", _hoisted_9, [
                  createVNode(_component_app_heading, {
                    href: "#server-side-tables",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Server side tables")
                    ]),
                    _: 1
                  }),
                  _hoisted_10,
                  createBaseVNode("p", null, [
                    createTextVNode("Find more information and examples on the "),
                    createVNode(_component_app_link, { href: "/components/data-tables/server-side-tables" }, {
                      default: withCtx(() => [
                        createTextVNode("Server side tables")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" page.")
                  ]),
                  createVNode(_component_examples_example, { file: "v-data-table/server" })
                ]),
                createBaseVNode("section", _hoisted_11, [
                  createVNode(_component_app_heading, {
                    href: "#virtual-tables",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Virtual tables")
                    ]),
                    _: 1
                  }),
                  _hoisted_12,
                  createBaseVNode("p", null, [
                    createTextVNode("Find more information and examples on the "),
                    createVNode(_component_app_link, { href: "/components/data-tables/virtual-tables" }, {
                      default: withCtx(() => [
                        createTextVNode("Virtual tables")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" page.")
                  ]),
                  createVNode(_component_examples_example, { file: "v-data-table/virtual" })
                ])
              ]),
              createBaseVNode("section", _hoisted_13, [
                createVNode(_component_app_heading, {
                  href: "#guide",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Guide")
                  ]),
                  _: 1
                }),
                _hoisted_14,
                createBaseVNode("section", _hoisted_15, [
                  createVNode(_component_app_heading, {
                    href: "#items",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Items")
                    ]),
                    _: 1
                  }),
                  _hoisted_16
                ]),
                createBaseVNode("section", _hoisted_17, [
                  createVNode(_component_app_heading, {
                    href: "#headers",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Headers")
                    ]),
                    _: 1
                  }),
                  _hoisted_18,
                  createVNode(_component_app_markup, {
                    resource: "",
                    class: "mb-4"
                  }, {
                    default: withCtx(() => [
                      _hoisted_19
                    ]),
                    _: 1
                  }),
                  _hoisted_20,
                  _hoisted_21,
                  createVNode(_component_examples_example, { file: "v-data-table/headers-multiple" }),
                  createBaseVNode("section", _hoisted_22, [
                    createVNode(_component_app_heading, {
                      href: "#keys-and-values",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Keys and values")
                      ]),
                      _: 1
                    }),
                    _hoisted_23,
                    createVNode(_component_app_markup, {
                      resource: "",
                      class: "mb-4"
                    }, {
                      default: withCtx(() => [
                        _hoisted_24
                      ]),
                      _: 1
                    })
                  ]),
                  createBaseVNode("section", _hoisted_25, [
                    createVNode(_component_app_heading, {
                      href: "#sorting-filtering-pagination",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Sorting, filtering, pagination")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("See "),
                      createVNode(_component_app_link, { href: "/components/data-tables/data-and-display" }, {
                        default: withCtx(() => [
                          createTextVNode("Data and display")
                        ]),
                        _: 1
                      }),
                      createTextVNode(".")
                    ])
                  ]),
                  createBaseVNode("section", _hoisted_26, [
                    createVNode(_component_app_heading, {
                      href: "#customization",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Customization")
                      ]),
                      _: 1
                    }),
                    _hoisted_27
                  ])
                ]),
                createBaseVNode("section", _hoisted_28, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  _hoisted_29,
                  createBaseVNode("section", _hoisted_30, [
                    createVNode(_component_app_heading, {
                      href: "#density",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Density")
                      ]),
                      _: 1
                    }),
                    _hoisted_31,
                    createVNode(_component_examples_example, { file: "v-data-table/prop-dense" })
                  ]),
                  createBaseVNode("section", _hoisted_32, [
                    createVNode(_component_app_heading, {
                      href: "#selection",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Selection")
                      ]),
                      _: 1
                    }),
                    _hoisted_33,
                    createBaseVNode("p", null, [
                      createTextVNode("For more information and examples, see the "),
                      createVNode(_component_app_link, { href: "/components/data-tables/data-and-display/#selection-examples" }, {
                        default: withCtx(() => [
                          createTextVNode("selection examples")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" page.")
                    ]),
                    createVNode(_component_examples_example, { file: "v-data-table/prop-row-selection" })
                  ]),
                  createBaseVNode("section", _hoisted_34, [
                    createVNode(_component_app_heading, {
                      href: "#simple-checkbox",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Simple checkbox")
                      ]),
                      _: 1
                    }),
                    _hoisted_35,
                    createVNode(_component_examples_example, { file: "v-data-table/slot-simple-checkbox" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_36, [
                  createVNode(_component_app_heading, {
                    href: "#slots",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Slots")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_37, [
                    createVNode(_component_app_heading, {
                      href: "#header-slot",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Header slot")
                      ]),
                      _: 1
                    }),
                    _hoisted_38,
                    createVNode(_component_alert, { type: "info" }, {
                      default: withCtx(() => [
                        _hoisted_39
                      ]),
                      _: 1
                    }),
                    createVNode(_component_examples_example, { file: "v-data-table/slot-header" })
                  ]),
                  createBaseVNode("section", _hoisted_40, [
                    createVNode(_component_app_heading, {
                      href: "#headers-slot",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Headers slot")
                      ]),
                      _: 1
                    }),
                    _hoisted_41,
                    createVNode(_component_examples_example, { file: "v-data-table/slot-headers" })
                  ]),
                  createBaseVNode("section", _hoisted_42, [
                    createVNode(_component_app_heading, {
                      href: "#item-slot",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Item slot")
                      ]),
                      _: 1
                    }),
                    _hoisted_43,
                    createVNode(_component_examples_example, { file: "v-data-table/slot-item" })
                  ]),
                  createBaseVNode("section", _hoisted_44, [
                    createVNode(_component_app_heading, {
                      href: "#item-key-slot",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Item key slot")
                      ]),
                      _: 1
                    }),
                    _hoisted_45,
                    createVNode(_component_examples_example, { file: "v-data-table/slot-item-key" })
                  ]),
                  createBaseVNode("section", _hoisted_46, [
                    createVNode(_component_app_heading, {
                      href: "#group-header-slot",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Group header slot")
                      ]),
                      _: 1
                    }),
                    _hoisted_47,
                    createVNode(_component_examples_example, { file: "v-data-table/slot-group-header" })
                  ]),
                  createBaseVNode("section", _hoisted_48, [
                    createVNode(_component_app_heading, {
                      href: "#loading-slot",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Loading slot")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("The "),
                      _hoisted_49,
                      createTextVNode(" slot allows you to customize your table’s display state when fetching data. In this example we utilize the "),
                      createVNode(_component_app_link, { href: "/components/skeleton-loaders" }, {
                        default: withCtx(() => [
                          createTextVNode("v-skeleton-loader")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" component to display a loading animation.")
                    ]),
                    createVNode(_component_examples_example, { file: "v-data-table/slot-loading" })
                  ])
                ])
              ]),
              createBaseVNode("section", _hoisted_50, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                _hoisted_51,
                createBaseVNode("section", _hoisted_52, [
                  createVNode(_component_app_heading, {
                    href: "#crud-actions",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("CRUD Actions")
                    ]),
                    _: 1
                  }),
                  _hoisted_53,
                  createVNode(_component_examples_example, { file: "v-data-table/misc-crud" })
                ]),
                createBaseVNode("section", _hoisted_54, [
                  createVNode(_component_app_heading, {
                    href: "#expandable-rows",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Expandable rows")
                    ]),
                    _: 1
                  }),
                  _hoisted_55,
                  _hoisted_56,
                  createVNode(_component_examples_example, { file: "v-data-table/misc-expand" })
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
