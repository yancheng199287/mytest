import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "blueprints" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "Vuetify blueprints are a new way to pre-configure your entire application with a completely unique design system.", -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "vuetify.js", -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-js" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "plugins/vuetify.js",
    class: "language-js"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" createVuetify "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify'"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" md1 "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify/blueprints'"),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "export"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "default"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "createVuetify"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "blueprint"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(" md1"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_6 = { id: "white-label-concept" };
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("strong", null, "white-label", -1);
const _hoisted_8 = { id: "available-blueprints" };
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Name"),
    /* @__PURE__ */ createBaseVNode("th", null, "Release date"),
    /* @__PURE__ */ createBaseVNode("th", null, "Status"),
    /* @__PURE__ */ createBaseVNode("th", null, "Resource")
  ])
], -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("td", null, "2014", -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("td", null, "✅ Available", -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("td", null, "2017", -1);
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("td", null, "✅ Available", -1);
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("td", null, "2022", -1);
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("td", null, "✅ Available", -1);
const _hoisted_16 = { id: "material-design-1" };
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("p", null, "Released in 2014, the original Material Design specification aimed to create a visual language that combined principles and good design with technical and scientific innovation.", -1);
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-javascript" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "plugins/vuetify.js",
    class: "language-javascript"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" md1 "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify/blueprints'"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Preview:")
], -1);
const _hoisted_20 = { id: "material-design-2" };
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("p", null, "Released in 2017, version 2 of Google’s design specification received a massive upgrade with new components, guidelines, and improved on the principles that made the first system so successful.", -1);
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-javascript" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "plugins/vuetify.js",
    class: "language-javascript"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" md2 "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify/blueprints'"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Preview:")
], -1);
const _hoisted_24 = { id: "material-design-3" };
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("p", null, "Material Design 3 is currently in active development and represents the next chapter of Google’s design system.", -1);
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-javascript" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "plugins/vuetify.js",
    class: "language-javascript"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" md3 "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify/blueprints'"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Preview:")
], -1);
const frontmatter = { "meta": { "title": "Blueprints", "description": "Setup your entire application with pre-made or custom styling and designs", "keywords": "vuetify blueprints, vuetify presets, vuetify schemas" }, "related": ["/features/global-configuration/", "/features/theme/", "/features/display-and-platform/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "blueprints",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "Blueprints", "description": "Setup your entire application with pre-made or custom styling and designs", "keywords": "vuetify blueprints, vuetify presets, vuetify schemas" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "title": "Blueprints", "description": "Setup your entire application with pre-made or custom styling and designs", "keywords": "vuetify blueprints, vuetify presets, vuetify schemas" }, "related": ["/features/global-configuration/", "/features/theme/", "/features/display-and-platform/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_markup = resolveComponent("app-markup");
      const _component_app_table = resolveComponent("app-table");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#blueprints",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Blueprints")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_promoted_entry),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("Blueprints are a collection of Vuetify configuration options that assign default values for components, colors, language, and more. Open your project’s "),
                  _hoisted_4,
                  createTextVNode(" file and import the desired blueprint. The follow example demonstrates how to apply the "),
                  createVNode(_component_app_link, { href: "#material-design-1" }, {
                    default: withCtx(() => [
                      createTextVNode("Material Design 1")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" preset:")
                ]),
                createVNode(_component_app_markup, {
                  resource: "plugins/vuetify.js",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_5
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_6, [
                  createVNode(_component_app_heading, {
                    href: "#white-label-concept",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("White-label concept")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("p", null, [
                    createTextVNode("While Vuetify is built under the guise of Google’s "),
                    createVNode(_component_app_link, { href: "https://material.io" }, {
                      default: withCtx(() => [
                        createTextVNode("Material Design")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" specification, it is still flexible enough to be used as the foundation for any design system. By default, Vuetify components have no color and are "),
                    _hoisted_7,
                    createTextVNode(" in nature. A white-label product is a product or service produced by one company that other companies rebrand to make it appear as if they had made it.")
                  ])
                ])
              ]),
              createBaseVNode("section", _hoisted_8, [
                createVNode(_component_app_heading, {
                  href: "#available-blueprints",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Available blueprints")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_9,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "#material-design-1" }, {
                            default: withCtx(() => [
                              createTextVNode("Material Design 1")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_10,
                        _hoisted_11,
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "https://m1.material.io" }, {
                            default: withCtx(() => [
                              createTextVNode("Specification")
                            ]),
                            _: 1
                          })
                        ])
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "#material-design-2" }, {
                            default: withCtx(() => [
                              createTextVNode("Material Design 2")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_12,
                        _hoisted_13,
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "https://m2.material.io" }, {
                            default: withCtx(() => [
                              createTextVNode("Specification")
                            ]),
                            _: 1
                          })
                        ])
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "#material-design-3" }, {
                            default: withCtx(() => [
                              createTextVNode("Material Design 3")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_14,
                        _hoisted_15,
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "https://m3.material.io" }, {
                            default: withCtx(() => [
                              createTextVNode("Specification")
                            ]),
                            _: 1
                          })
                        ])
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_16, [
                  createVNode(_component_app_heading, {
                    href: "#material-design-1",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Material Design 1")
                    ]),
                    _: 1
                  }),
                  _hoisted_17,
                  createVNode(_component_app_markup, {
                    resource: "plugins/vuetify.js",
                    class: "mb-4"
                  }, {
                    default: withCtx(() => [
                      _hoisted_18
                    ]),
                    _: 1
                  }),
                  _hoisted_19,
                  createVNode(_component_examples_example, {
                    file: "blueprints/md1",
                    preview: ""
                  })
                ]),
                createBaseVNode("section", _hoisted_20, [
                  createVNode(_component_app_heading, {
                    href: "#material-design-2",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Material Design 2")
                    ]),
                    _: 1
                  }),
                  _hoisted_21,
                  createVNode(_component_app_markup, {
                    resource: "plugins/vuetify.js",
                    class: "mb-4"
                  }, {
                    default: withCtx(() => [
                      _hoisted_22
                    ]),
                    _: 1
                  }),
                  _hoisted_23,
                  createVNode(_component_examples_example, {
                    file: "blueprints/md2",
                    preview: ""
                  })
                ]),
                createBaseVNode("section", _hoisted_24, [
                  createVNode(_component_app_heading, {
                    href: "#material-design-3",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Material Design 3")
                    ]),
                    _: 1
                  }),
                  _hoisted_25,
                  createVNode(_component_app_markup, {
                    resource: "plugins/vuetify.js",
                    class: "mb-4"
                  }, {
                    default: withCtx(() => [
                      _hoisted_26
                    ]),
                    _: 1
                  }),
                  _hoisted_27,
                  createVNode(_component_examples_example, {
                    file: "blueprints/md3",
                    preview: ""
                  })
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
