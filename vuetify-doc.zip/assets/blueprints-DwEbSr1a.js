import { an as mdi, r as resolveComponent, o as openBlock, l as createElementBlock, b as createVNode, w as withCtx, e as createBaseVNode, f as unref, h as createTextVNode } from "./index-DGybHjCP.js";
const md1 = {
  defaults: {
    global: {
      rounded: "sm"
    },
    VAvatar: {
      rounded: "circle"
    },
    VAutocomplete: {
      variant: "underlined"
    },
    VBanner: {
      color: "primary"
    },
    VBtn: {
      color: "primary",
      rounded: 0
    },
    VCheckbox: {
      color: "secondary"
    },
    VCombobox: {
      variant: "underlined"
    },
    VSelect: {
      variant: "underlined"
    },
    VSlider: {
      color: "primary"
    },
    VTabs: {
      color: "primary"
    },
    VTextarea: {
      variant: "underlined"
    },
    VTextField: {
      variant: "underlined"
    },
    VToolbar: {
      VBtn: {
        color: null
      }
    }
  },
  icons: {
    defaultSet: "mdi",
    sets: {
      mdi
    }
  },
  theme: {
    themes: {
      light: {
        colors: {
          primary: "#3F51B5",
          "primary-darken-1": "#303F9F",
          "primary-lighten-1": "#C5CAE9",
          secondary: "#FF4081",
          "secondary-darken-1": "#F50057",
          "secondary-lighten-1": "#FF80AB",
          accent: "#009688"
        }
      }
    }
  }
};
const md2 = {
  defaults: {
    global: {
      rounded: "md"
    },
    VAvatar: {
      rounded: "circle"
    },
    VAutocomplete: {
      variant: "filled"
    },
    VBanner: {
      color: "primary"
    },
    VBtn: {
      color: "primary"
    },
    VCheckbox: {
      color: "secondary"
    },
    VCombobox: {
      variant: "filled"
    },
    VSelect: {
      variant: "filled"
    },
    VSlider: {
      color: "primary"
    },
    VTabs: {
      color: "primary"
    },
    VTextarea: {
      variant: "filled"
    },
    VTextField: {
      variant: "filled"
    },
    VToolbar: {
      VBtn: {
        color: null
      }
    }
  },
  icons: {
    defaultSet: "mdi",
    sets: {
      mdi
    }
  },
  theme: {
    themes: {
      light: {
        colors: {
          primary: "#6200EE",
          "primary-darken-1": "#3700B3",
          secondary: "#03DAC6",
          "secondary-darken-1": "#018786",
          error: "#B00020"
        }
      }
    }
  }
};
const md3 = {
  defaults: {
    VAppBar: {
      flat: true
    },
    VAutocomplete: {
      variant: "filled"
    },
    VBanner: {
      color: "primary"
    },
    VBottomSheet: {
      contentClass: "rounded-t-xl overflow-hidden"
    },
    VBtn: {
      color: "primary",
      rounded: "xl"
    },
    VBtnGroup: {
      rounded: "xl",
      VBtn: {
        rounded: null
      }
    },
    VCard: {
      rounded: "lg"
    },
    VCheckbox: {
      color: "secondary",
      inset: true
    },
    VChip: {
      rounded: "sm"
    },
    VCombobox: {
      variant: "filled"
    },
    VNavigationDrawer: {
      // VList: {
      //   nav: true,
      //   VListItem: {
      //     rounded: 'xl',
      //   },
      // },
    },
    VSelect: {
      variant: "filled"
    },
    VSlider: {
      color: "primary"
    },
    VTabs: {
      color: "primary"
    },
    VTextarea: {
      variant: "filled"
    },
    VTextField: {
      variant: "filled"
    },
    VToolbar: {
      VBtn: {
        color: null
      }
    }
  },
  icons: {
    defaultSet: "mdi",
    sets: {
      mdi
    }
  },
  theme: {
    themes: {
      light: {
        colors: {
          primary: "#6750a4",
          secondary: "#b4b0bb",
          tertiary: "#7d5260",
          error: "#b3261e",
          surface: "#fffbfe"
        }
      }
    }
  }
};
const _hoisted_1$2 = { class: "d-flex align-center" };
const _hoisted_2$2 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_3$2 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _sfc_main$2 = {
  __name: "md1",
  setup(__props) {
    const color = md1.theme.themes.light.colors.primary;
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_tab = resolveComponent("v-tab");
      const _component_v_tabs = resolveComponent("v-tabs");
      const _component_v_avatar = resolveComponent("v-avatar");
      const _component_v_banner = resolveComponent("v-banner");
      const _component_v_text_field = resolveComponent("v-text-field");
      const _component_v_defaults_provider = resolveComponent("v-defaults-provider");
      return openBlock(), createElementBlock("div", null, [
        createVNode(_component_v_defaults_provider, {
          defaults: unref(md1).defaults
        }, {
          default: withCtx(() => [
            createBaseVNode("div", _hoisted_1$2, [
              createVNode(_component_v_btn, {
                color: unref(color),
                class: "me-6 text-white"
              }, {
                default: withCtx(() => [
                  createTextVNode("Button")
                ]),
                _: 1
              }, 8, ["color"]),
              createVNode(_component_v_tabs, { color: unref(color) }, {
                default: withCtx(() => [
                  createVNode(_component_v_tab, null, {
                    default: withCtx(() => [
                      createTextVNode("Tab One")
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_tab, null, {
                    default: withCtx(() => [
                      createTextVNode("Tab Two")
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_tab, null, {
                    default: withCtx(() => [
                      createTextVNode("Tab Three")
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }, 8, ["color"])
            ]),
            _hoisted_2$2,
            createVNode(_component_v_banner, {
              color: unref(color),
              text: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!"
            }, {
              prepend: withCtx(() => [
                createVNode(_component_v_avatar, {
                  class: "text-white",
                  icon: "$vuetify",
                  rounded: "circle"
                })
              ]),
              _: 1
            }, 8, ["color"]),
            _hoisted_3$2,
            createVNode(_component_v_text_field, {
              color: unref(color),
              label: "Text field",
              "model-value": "Material Design 1"
            }, null, 8, ["color"])
          ]),
          _: 1
        }, 8, ["defaults"])
      ]);
    };
  }
};
const __0 = _sfc_main$2;
const __0_raw = `<template>
  <div>
    <v-defaults-provider :defaults="md1.defaults">
      <div class="d-flex align-center">
        <v-btn :color="color" class="me-6 text-white">Button</v-btn>

        <v-tabs :color="color">
          <v-tab>Tab One</v-tab>
          <v-tab>Tab Two</v-tab>
          <v-tab>Tab Three</v-tab>
        </v-tabs>
      </div>

      <br>

      <v-banner
        :color="color"
        text="Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!"
      >
        <template v-slot:prepend>
          <!-- rounded added due to bug -->
          <v-avatar
            class="text-white"
            icon="$vuetify"
            rounded="circle"
          ></v-avatar>
        </template>
      </v-banner>

      <br>

      <v-text-field
        :color="color"
        label="Text field"
        model-value="Material Design 1"
      ></v-text-field>
    </v-defaults-provider>
  </div>
</template>

<script setup>
  import { md1 } from 'vuetify/blueprints'

  const color = md1.theme.themes.light.colors.primary
<\/script>
`;
const _hoisted_1$1 = { class: "d-flex align-center" };
const _hoisted_2$1 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_3$1 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _sfc_main$1 = {
  __name: "md2",
  setup(__props) {
    const color = md2.theme.themes.light.colors.primary;
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_tab = resolveComponent("v-tab");
      const _component_v_tabs = resolveComponent("v-tabs");
      const _component_v_avatar = resolveComponent("v-avatar");
      const _component_v_banner = resolveComponent("v-banner");
      const _component_v_text_field = resolveComponent("v-text-field");
      const _component_v_defaults_provider = resolveComponent("v-defaults-provider");
      return openBlock(), createElementBlock("div", null, [
        createVNode(_component_v_defaults_provider, {
          defaults: unref(md2).defaults
        }, {
          default: withCtx(() => [
            createBaseVNode("div", _hoisted_1$1, [
              createVNode(_component_v_btn, {
                color: unref(color),
                class: "me-6 text-white"
              }, {
                default: withCtx(() => [
                  createTextVNode("Button")
                ]),
                _: 1
              }, 8, ["color"]),
              createVNode(_component_v_tabs, { color: unref(color) }, {
                default: withCtx(() => [
                  createVNode(_component_v_tab, null, {
                    default: withCtx(() => [
                      createTextVNode("Tab One")
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_tab, null, {
                    default: withCtx(() => [
                      createTextVNode("Tab Two")
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_tab, null, {
                    default: withCtx(() => [
                      createTextVNode("Tab Three")
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }, 8, ["color"])
            ]),
            _hoisted_2$1,
            createVNode(_component_v_banner, {
              color: unref(color),
              text: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!"
            }, {
              prepend: withCtx(() => [
                createVNode(_component_v_avatar, {
                  class: "text-white",
                  icon: "$vuetify",
                  rounded: "circle"
                })
              ]),
              _: 1
            }, 8, ["color"]),
            _hoisted_3$1,
            createVNode(_component_v_text_field, {
              color: unref(color),
              label: "Text field",
              "model-value": "Material Design 2"
            }, null, 8, ["color"])
          ]),
          _: 1
        }, 8, ["defaults"])
      ]);
    };
  }
};
const __1 = _sfc_main$1;
const __1_raw = `<template>
  <div>
    <v-defaults-provider :defaults="md2.defaults">
      <div class="d-flex align-center">
        <v-btn :color="color" class="me-6 text-white">Button</v-btn>

        <v-tabs :color="color">
          <v-tab>Tab One</v-tab>
          <v-tab>Tab Two</v-tab>
          <v-tab>Tab Three</v-tab>
        </v-tabs>
      </div>

      <br>

      <v-banner
        :color="color"
        text="Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!"
      >
        <template v-slot:prepend>
          <!-- rounded added due to bug -->
          <v-avatar
            class="text-white"
            icon="$vuetify"
            rounded="circle"
          ></v-avatar>
        </template>
      </v-banner>

      <br>

      <v-text-field
        :color="color"
        label="Text field"
        model-value="Material Design 2"
      ></v-text-field>
    </v-defaults-provider>
  </div>
</template>

<script setup>
  import { md2 } from 'vuetify/blueprints'

  const color = md2.theme.themes.light.colors.primary
<\/script>
`;
const _hoisted_1 = { class: "d-flex align-center" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _sfc_main = {
  __name: "md3",
  setup(__props) {
    const color = md3.theme.themes.light.colors.primary;
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_tab = resolveComponent("v-tab");
      const _component_v_tabs = resolveComponent("v-tabs");
      const _component_v_avatar = resolveComponent("v-avatar");
      const _component_v_banner = resolveComponent("v-banner");
      const _component_v_text_field = resolveComponent("v-text-field");
      const _component_v_defaults_provider = resolveComponent("v-defaults-provider");
      return openBlock(), createElementBlock("div", null, [
        createVNode(_component_v_defaults_provider, {
          defaults: unref(md3).defaults
        }, {
          default: withCtx(() => [
            createBaseVNode("div", _hoisted_1, [
              createVNode(_component_v_btn, {
                color: unref(color),
                class: "me-6 text-white"
              }, {
                default: withCtx(() => [
                  createTextVNode("Button")
                ]),
                _: 1
              }, 8, ["color"]),
              createVNode(_component_v_tabs, { color: unref(color) }, {
                default: withCtx(() => [
                  createVNode(_component_v_tab, null, {
                    default: withCtx(() => [
                      createTextVNode("Tab One")
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_tab, null, {
                    default: withCtx(() => [
                      createTextVNode("Tab Two")
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_tab, null, {
                    default: withCtx(() => [
                      createTextVNode("Tab Three")
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }, 8, ["color"])
            ]),
            _hoisted_2,
            createVNode(_component_v_banner, {
              color: unref(color),
              text: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!"
            }, {
              prepend: withCtx(() => [
                createVNode(_component_v_avatar, {
                  class: "text-white",
                  icon: "$vuetify",
                  rounded: "circle"
                })
              ]),
              _: 1
            }, 8, ["color"]),
            _hoisted_3,
            createVNode(_component_v_text_field, {
              color: unref(color),
              label: "Text field",
              "model-value": "Material Design 3"
            }, null, 8, ["color"])
          ]),
          _: 1
        }, 8, ["defaults"])
      ]);
    };
  }
};
const __2 = _sfc_main;
const __2_raw = `<template>
  <div>
    <v-defaults-provider :defaults="md3.defaults">
      <div class="d-flex align-center">
        <v-btn :color="color" class="me-6 text-white">Button</v-btn>

        <v-tabs :color="color">
          <v-tab>Tab One</v-tab>
          <v-tab>Tab Two</v-tab>
          <v-tab>Tab Three</v-tab>
        </v-tabs>
      </div>

      <br>

      <v-banner
        :color="color"
        text="Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!"
      >
        <template v-slot:prepend>
          <!-- rounded added due to bug -->
          <v-avatar
            class="text-white"
            icon="$vuetify"
            rounded="circle"
          ></v-avatar>
        </template>
      </v-banner>

      <br>

      <v-text-field
        :color="color"
        label="Text field"
        model-value="Material Design 3"
      ></v-text-field>
    </v-defaults-provider>
  </div>
</template>

<script setup>
  import { md3 } from 'vuetify/blueprints'

  const color = md3.theme.themes.light.colors.primary
<\/script>
`;
const blueprints = {
  "md1": {
    component: __0,
    source: __0_raw
  },
  "md2": {
    component: __1,
    source: __1_raw
  },
  "md3": {
    component: __2,
    source: __2_raw
  }
};
export {
  blueprints as default
};
