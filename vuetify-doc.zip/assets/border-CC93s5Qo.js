import { y as _export_sfc, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, b as createVNode, e as createBaseVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _sfc_main$4 = {};
const _hoisted_1$4 = /* @__PURE__ */ createBaseVNode("div", { class: "text-center" }, [
  /* @__PURE__ */ createBaseVNode("div", {
    class: "border-thin",
    style: { "height": "64px", "width": "64px" }
  }),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "border-thin")
], -1);
const _hoisted_2$4 = /* @__PURE__ */ createBaseVNode("div", { class: "text-center" }, [
  /* @__PURE__ */ createBaseVNode("div", {
    class: "border-sm",
    style: { "height": "64px", "width": "64px" }
  }),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "border-sm")
], -1);
const _hoisted_3$4 = /* @__PURE__ */ createBaseVNode("div", { class: "text-center" }, [
  /* @__PURE__ */ createBaseVNode("div", {
    class: "border-md",
    style: { "height": "64px", "width": "64px" }
  }),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "border-md")
], -1);
const _hoisted_4$4 = /* @__PURE__ */ createBaseVNode("div", { class: "text-center" }, [
  /* @__PURE__ */ createBaseVNode("div", {
    class: "border-lg",
    style: { "height": "64px", "width": "64px" }
  }),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "border-lg")
], -1);
const _hoisted_5$2 = /* @__PURE__ */ createBaseVNode("div", { class: "text-center" }, [
  /* @__PURE__ */ createBaseVNode("div", {
    class: "border-xl",
    style: { "height": "64px", "width": "64px" }
  }),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "border-xl")
], -1);
function _sfc_render$4(_ctx, _cache) {
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, null, {
    default: withCtx(() => [
      createVNode(_component_v_row, { justify: "space-around" }, {
        default: withCtx(() => [
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              _hoisted_1$4
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              _hoisted_2$4
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              _hoisted_3$4
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              _hoisted_4$4
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              _hoisted_5$2
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __0 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["render", _sfc_render$4]]);
const __0_raw = '<template>\n  <v-container>\n    <v-row justify="space-around">\n      <v-col cols="auto">\n        <div class="text-center">\n          <div class="border-thin" style="height: 64px; width: 64px;"></div>\n          <div class="text-caption">border-thin</div>\n        </div>\n      </v-col>\n\n      <v-col cols="auto">\n        <div class="text-center">\n          <div class="border-sm" style="height: 64px; width: 64px;"></div>\n          <div class="text-caption">border-sm</div>\n        </div>\n      </v-col>\n\n      <v-col cols="auto">\n        <div class="text-center">\n          <div class="border-md" style="height: 64px; width: 64px;"></div>\n          <div class="text-caption">border-md</div>\n        </div>\n      </v-col>\n\n      <v-col cols="auto">\n        <div class="text-center">\n          <div class="border-lg" style="height: 64px; width: 64px;"></div>\n          <div class="text-caption">border-lg</div>\n        </div>\n      </v-col>\n\n      <v-col cols="auto">\n        <div class="text-center">\n          <div class="border-xl" style="height: 64px; width: 64px;"></div>\n          <div class="text-caption">border-xl</div>\n        </div>\n      </v-col>\n    </v-row>\n  </v-container>\n</template>\n';
const _sfc_main$3 = {};
const _hoisted_1$3 = /* @__PURE__ */ createBaseVNode("div", { class: "text-caption font-weight-bold" }, "Revenue", -1);
const _hoisted_2$3 = /* @__PURE__ */ createBaseVNode("div", { class: "text-h4 font-weight-black" }, "$ 9,232,215", -1);
const _hoisted_3$3 = { class: "text-caption text-medium-emphasis d-flex justify-space-between align-center" };
const _hoisted_4$3 = { class: "text-green" };
function _sfc_render$3(_ctx, _cache) {
  const _component_v_icon = resolveComponent("v-icon");
  const _component_v_chip = resolveComponent("v-chip");
  const _component_v_avatar = resolveComponent("v-avatar");
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_card = resolveComponent("v-card");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, null, {
    default: withCtx(() => [
      createVNode(_component_v_card, {
        border: "opacity-50 sm",
        class: "mx-auto",
        "max-width": "360",
        rounded: "xl",
        variant: "text"
      }, {
        title: withCtx(() => [
          _hoisted_1$3
        ]),
        append: withCtx(() => [
          createVNode(_component_v_chip, {
            border: "success sm opacity-100",
            color: "green",
            size: "small",
            variant: "text"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_icon, {
                icon: "mdi-arrow-up",
                start: ""
              }),
              createTextVNode(" 13% ")
            ]),
            _: 1
          })
        ]),
        text: withCtx(() => [
          _hoisted_2$3,
          createBaseVNode("small", _hoisted_3$3, [
            createBaseVNode("div", null, [
              createBaseVNode("span", _hoisted_4$3, [
                createVNode(_component_v_avatar, {
                  icon: "mdi-arrow-up",
                  size: "small",
                  variant: "tonal"
                }),
                createTextVNode(" + $ 3,295 ")
              ]),
              createTextVNode(" in the last week ")
            ]),
            createVNode(_component_v_btn, {
              icon: "mdi-arrow-right",
              size: "x-small",
              variant: "text",
              border: ""
            })
          ])
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __1 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["render", _sfc_render$3]]);
const __1_raw = '<template>\n  <v-container>\n    <v-card\n      border="opacity-50 sm"\n      class="mx-auto"\n      max-width="360"\n      rounded="xl"\n      variant="text"\n    >\n      <template v-slot:title>\n        <div class="text-caption font-weight-bold">Revenue</div>\n      </template>\n\n      <template v-slot:append>\n        <v-chip\n          border="success sm opacity-100"\n          color="green"\n          size="small"\n          variant="text"\n        >\n          <v-icon icon="mdi-arrow-up" start></v-icon> 13%\n        </v-chip>\n      </template>\n\n      <template v-slot:text>\n        <div class="text-h4 font-weight-black">$ 9,232,215</div>\n\n        <small class="text-caption text-medium-emphasis d-flex justify-space-between align-center">\n          <div>\n            <span class="text-green">\n              <v-avatar icon="mdi-arrow-up" size="small" variant="tonal"></v-avatar>\n              + $ 3,295\n            </span>\n\n            in the last week\n          </div>\n\n          <v-btn\n            icon="mdi-arrow-right"\n            size="x-small"\n            variant="text"\n            border\n          ></v-btn>\n        </small>\n      </template>\n    </v-card>\n  </v-container>\n</template>\n';
const _sfc_main$2 = {};
const _hoisted_1$2 = { class: "text-center" };
const _hoisted_2$2 = /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, '"primary thin"', -1);
const _hoisted_3$2 = { class: "text-center" };
const _hoisted_4$2 = /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, '"sucess sm"', -1);
const _hoisted_5$1 = { class: "text-center" };
const _hoisted_6$1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, '"info md"', -1);
const _hoisted_7$1 = { class: "text-center" };
const _hoisted_8$1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, '"warning lg"', -1);
const _hoisted_9 = { class: "text-center" };
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, '"error xl"', -1);
function _sfc_render$2(_ctx, _cache) {
  const _component_v_sheet = resolveComponent("v-sheet");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, null, {
    default: withCtx(() => [
      createVNode(_component_v_row, { justify: "space-around" }, {
        default: withCtx(() => [
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              createBaseVNode("div", _hoisted_1$2, [
                createVNode(_component_v_sheet, {
                  border: "primary thin",
                  class: "mx-auto",
                  height: "64",
                  width: "64",
                  rounded: ""
                }),
                _hoisted_2$2
              ])
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              createBaseVNode("div", _hoisted_3$2, [
                createVNode(_component_v_sheet, {
                  border: "success sm",
                  height: "64",
                  width: "64",
                  rounded: ""
                }),
                _hoisted_4$2
              ])
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              createBaseVNode("div", _hoisted_5$1, [
                createVNode(_component_v_sheet, {
                  border: "info md",
                  height: "64",
                  width: "64",
                  rounded: ""
                }),
                _hoisted_6$1
              ])
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              createBaseVNode("div", _hoisted_7$1, [
                createVNode(_component_v_sheet, {
                  border: "warning lg",
                  height: "64",
                  width: "64",
                  rounded: ""
                }),
                _hoisted_8$1
              ])
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              createBaseVNode("div", _hoisted_9, [
                createVNode(_component_v_sheet, {
                  border: "error xl",
                  height: "64",
                  width: "64",
                  rounded: ""
                }),
                _hoisted_10
              ])
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __2 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["render", _sfc_render$2]]);
const __2_raw = '<template>\n  <v-container>\n    <v-row justify="space-around">\n      <v-col cols="auto">\n        <div class="text-center">\n          <v-sheet border="primary thin" class="mx-auto" height="64" width="64" rounded></v-sheet>\n          <div class="text-caption">"primary thin"</div>\n        </div>\n      </v-col>\n\n      <v-col cols="auto">\n        <div class="text-center">\n          <v-sheet border="success sm" height="64" width="64" rounded></v-sheet>\n          <div class="text-caption">"sucess sm"</div>\n        </div>\n      </v-col>\n\n      <v-col cols="auto">\n        <div class="text-center">\n          <v-sheet border="info md" height="64" width="64" rounded></v-sheet>\n          <div class="text-caption">"info md"</div>\n        </div>\n      </v-col>\n\n      <v-col cols="auto">\n        <div class="text-center">\n          <v-sheet border="warning lg" height="64" width="64" rounded></v-sheet>\n          <div class="text-caption">"warning lg"</div>\n        </div>\n      </v-col>\n\n      <v-col cols="auto">\n        <div class="text-center">\n          <v-sheet border="error xl" height="64" width="64" rounded></v-sheet>\n          <div class="text-caption">"error xl"</div>\n        </div>\n      </v-col>\n    </v-row>\n  </v-container>\n</template>\n';
const _sfc_main$1 = {};
const _hoisted_1$1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-center" }, [
  /* @__PURE__ */ createBaseVNode("div", {
    class: "border border-t-lg",
    style: { "height": "64px", "width": "64px" }
  }),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "border-t-lg")
], -1);
const _hoisted_2$1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-center" }, [
  /* @__PURE__ */ createBaseVNode("div", {
    class: "border border-e-lg",
    style: { "height": "64px", "width": "64px" }
  }),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "border-e-lg")
], -1);
const _hoisted_3$1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-center" }, [
  /* @__PURE__ */ createBaseVNode("div", {
    class: "border border-b-lg",
    style: { "height": "64px", "width": "64px" }
  }),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "border-b-lg")
], -1);
const _hoisted_4$1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-center" }, [
  /* @__PURE__ */ createBaseVNode("div", {
    class: "border border-s-lg",
    style: { "height": "64px", "width": "64px" }
  }),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "border-s-lg")
], -1);
function _sfc_render$1(_ctx, _cache) {
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, null, {
    default: withCtx(() => [
      createVNode(_component_v_row, { justify: "space-around" }, {
        default: withCtx(() => [
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              _hoisted_1$1
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              _hoisted_2$1
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              _hoisted_3$1
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              _hoisted_4$1
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __3 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["render", _sfc_render$1]]);
const __3_raw = '<template>\n  <v-container>\n    <v-row justify="space-around">\n      <v-col cols="auto">\n        <div class="text-center">\n          <div class="border border-t-lg" style="height: 64px; width: 64px;"></div>\n          <div class="text-caption">border-t-lg</div>\n        </div>\n      </v-col>\n\n      <v-col cols="auto">\n        <div class="text-center">\n          <div class="border border-e-lg" style="height: 64px; width: 64px;"></div>\n          <div class="text-caption">border-e-lg</div>\n        </div>\n      </v-col>\n\n      <v-col cols="auto">\n        <div class="text-center">\n          <div class="border border-b-lg" style="height: 64px; width: 64px;"></div>\n          <div class="text-caption">border-b-lg</div>\n        </div>\n      </v-col>\n\n      <v-col cols="auto">\n        <div class="text-center">\n          <div class="border border-s-lg" style="height: 64px; width: 64px;"></div>\n          <div class="text-caption">border-s-lg</div>\n        </div>\n      </v-col>\n    </v-row>\n  </v-container>\n</template>\n';
const _sfc_main = {};
const _hoisted_1 = { class: "text-center" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "border", -1);
const _hoisted_3 = { class: "text-center" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "border-dashed", -1);
const _hoisted_5 = { class: "text-center" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "border-dotted", -1);
const _hoisted_7 = { class: "text-center" };
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "border-double", -1);
function _sfc_render(_ctx, _cache) {
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, null, {
    default: withCtx(() => [
      createVNode(_component_v_row, { justify: "space-around" }, {
        default: withCtx(() => [
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              createBaseVNode("div", _hoisted_1, [
                createVNode(_component_v_btn, {
                  text: "Button A",
                  variant: "text",
                  border: ""
                }),
                _hoisted_2
              ])
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              createBaseVNode("div", _hoisted_3, [
                createVNode(_component_v_btn, {
                  border: "dashed thin",
                  text: "Button A",
                  variant: "text"
                }),
                _hoisted_4
              ])
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              createBaseVNode("div", _hoisted_5, [
                createVNode(_component_v_btn, {
                  border: "dotted thin",
                  text: "Button A",
                  variant: "text"
                }),
                _hoisted_6
              ])
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              createBaseVNode("div", _hoisted_7, [
                createVNode(_component_v_btn, {
                  border: "double lg",
                  text: "Button A",
                  variant: "text"
                }),
                _hoisted_8
              ])
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __4 = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
const __4_raw = '<template>\n  <v-container>\n    <v-row justify="space-around">\n      <v-col cols="auto">\n        <div class="text-center">\n          <v-btn text="Button A" variant="text" border></v-btn>\n          <div class="text-caption">border</div>\n        </div>\n      </v-col>\n\n      <v-col cols="auto">\n        <div class="text-center">\n          <v-btn border="dashed thin" text="Button A" variant="text"></v-btn>\n          <div class="text-caption">border-dashed</div>\n        </div>\n      </v-col>\n\n      <v-col cols="auto">\n        <div class="text-center">\n          <v-btn border="dotted thin" text="Button A" variant="text"></v-btn>\n          <div class="text-caption">border-dotted</div>\n        </div>\n      </v-col>\n\n      <v-col cols="auto">\n        <div class="text-center">\n          <v-btn border="double lg" text="Button A" variant="text"></v-btn>\n          <div class="text-caption">border-double</div>\n        </div>\n      </v-col>\n    </v-row>\n  </v-container>\n</template>\n';
const border = {
  "all": {
    component: __0,
    source: __0_raw
  },
  "card": {
    component: __1,
    source: __1_raw
  },
  "colors": {
    component: __2,
    source: __2_raw
  },
  "sides": {
    component: __3,
    source: __3_raw
  },
  "styles": {
    component: __4,
    source: __4_raw
  }
};
export {
  border as default
};
