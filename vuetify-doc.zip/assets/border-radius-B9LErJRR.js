import { y as _export_sfc, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, b as createVNode, e as createBaseVNode } from "./index-DGybHjCP.js";
const _sfc_main$5 = {};
function _sfc_render$5(_ctx, _cache) {
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, { class: "text-center" }, {
    default: withCtx(() => [
      createVNode(_component_v_btn, {
        color: "primary",
        rounded: "pill",
        text: "Update Account",
        flat: ""
      })
    ]),
    _: 1
  });
}
const __0 = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["render", _sfc_render$5]]);
const __0_raw = '<template>\n  <v-container class="text-center">\n    <v-btn\n      color="primary"\n      rounded="pill"\n      text="Update Account"\n      flat\n    ></v-btn>\n  </v-container>\n</template>\n';
const _sfc_main$4 = {};
const _hoisted_1$3 = /* @__PURE__ */ createBaseVNode("div", { class: "text-center" }, [
  /* @__PURE__ */ createBaseVNode("div", {
    class: "bg-surface-variant rounded-pill mx-auto",
    style: { "height": "64px", "width": "164px" }
  }),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "rounded-pill")
], -1);
const _hoisted_2$3 = /* @__PURE__ */ createBaseVNode("div", { class: "text-center" }, [
  /* @__PURE__ */ createBaseVNode("div", {
    class: "bg-surface-variant rounded-circle mx-auto",
    style: { "height": "64px", "width": "64px" }
  }),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "rounded-circle")
], -1);
function _sfc_render$4(_ctx, _cache) {
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, null, {
    default: withCtx(() => [
      createVNode(_component_v_row, { justify: "space-around" }, {
        default: withCtx(() => [
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              _hoisted_1$3
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              _hoisted_2$3
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __1 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["render", _sfc_render$4]]);
const __1_raw = '<template>\n  <v-container>\n    <v-row justify="space-around">\n      <v-col cols="auto">\n        <div class="text-center">\n          <div class="bg-surface-variant rounded-pill mx-auto" style="height: 64px; width: 164px;"></div>\n          <div class="text-caption">rounded-pill</div>\n        </div>\n      </v-col>\n\n      <v-col cols="auto">\n        <div class="text-center">\n          <div class="bg-surface-variant rounded-circle mx-auto" style="height: 64px; width: 64px;"></div>\n          <div class="text-caption">rounded-circle</div>\n        </div>\n      </v-col>\n    </v-row>\n  </v-container>\n</template>\n';
const _sfc_main$3 = {};
function _sfc_render$3(_ctx, _cache) {
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, { class: "text-center" }, {
    default: withCtx(() => [
      createVNode(_component_v_btn, {
        color: "primary",
        rounded: "0",
        text: "Update Account",
        flat: ""
      })
    ]),
    _: 1
  });
}
const __2 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["render", _sfc_render$3]]);
const __2_raw = '<template>\n  <v-container class="text-center">\n    <v-btn\n      color="primary"\n      rounded="0"\n      text="Update Account"\n      flat\n    ></v-btn>\n  </v-container>\n</template>\n';
const _sfc_main$2 = {};
const _hoisted_1$2 = /* @__PURE__ */ createBaseVNode("div", { class: "text-center" }, [
  /* @__PURE__ */ createBaseVNode("div", {
    class: "bg-surface-variant rounded-sm mx-auto",
    style: { "height": "64px", "width": "64px" }
  }),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "rounded-sm")
], -1);
const _hoisted_2$2 = /* @__PURE__ */ createBaseVNode("div", { class: "text-center" }, [
  /* @__PURE__ */ createBaseVNode("div", {
    class: "bg-surface-variant rounded mx-auto",
    style: { "height": "64px", "width": "64px" }
  }),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "rounded")
], -1);
const _hoisted_3$2 = /* @__PURE__ */ createBaseVNode("div", { class: "text-center" }, [
  /* @__PURE__ */ createBaseVNode("div", {
    class: "bg-surface-variant rounded-md mx-auto",
    style: { "height": "64px", "width": "64px" }
  }),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "rounded-md")
], -1);
const _hoisted_4$2 = /* @__PURE__ */ createBaseVNode("div", { class: "text-center" }, [
  /* @__PURE__ */ createBaseVNode("div", {
    class: "bg-surface-variant rounded-lg mx-auto",
    style: { "height": "64px", "width": "64px" }
  }),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "rounded-lg")
], -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("div", { class: "text-center" }, [
  /* @__PURE__ */ createBaseVNode("div", {
    class: "bg-surface-variant rounded-xl mx-auto",
    style: { "height": "64px", "width": "64px" }
  }),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "rounded-xl")
], -1);
function _sfc_render$2(_ctx, _cache) {
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, null, {
    default: withCtx(() => [
      createVNode(_component_v_row, { justify: "space-around" }, {
        default: withCtx(() => [
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              _hoisted_1$2
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              _hoisted_2$2
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              _hoisted_3$2
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              _hoisted_4$2
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              _hoisted_5
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __3 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["render", _sfc_render$2]]);
const __3_raw = '<template>\n  <v-container>\n    <v-row justify="space-around">\n      <v-col cols="auto">\n        <div class="text-center">\n          <div class="bg-surface-variant rounded-sm mx-auto" style="height: 64px; width: 64px;"></div>\n          <div class="text-caption">rounded-sm</div>\n        </div>\n      </v-col>\n\n      <v-col cols="auto">\n        <div class="text-center">\n          <div class="bg-surface-variant rounded mx-auto" style="height: 64px; width: 64px;"></div>\n          <div class="text-caption">rounded</div>\n        </div>\n      </v-col>\n\n      <v-col cols="auto">\n        <div class="text-center">\n          <div class="bg-surface-variant rounded-md mx-auto" style="height: 64px; width: 64px;"></div>\n          <div class="text-caption">rounded-md</div>\n        </div>\n      </v-col>\n\n      <v-col cols="auto">\n        <div class="text-center">\n          <div class="bg-surface-variant rounded-lg mx-auto" style="height: 64px; width: 64px;"></div>\n          <div class="text-caption">rounded-lg</div>\n        </div>\n      </v-col>\n\n      <v-col cols="auto">\n        <div class="text-center">\n          <div class="bg-surface-variant rounded-xl mx-auto" style="height: 64px; width: 64px;"></div>\n          <div class="text-caption">rounded-xl</div>\n        </div>\n      </v-col>\n    </v-row>\n  </v-container>\n</template>\n';
const _sfc_main$1 = {};
const _hoisted_1$1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-center" }, [
  /* @__PURE__ */ createBaseVNode("div", {
    class: "bg-surface-variant rounded-ts-lg mx-auto",
    style: { "height": "64px", "width": "64px" }
  }),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "rounded-ts-lg")
], -1);
const _hoisted_2$1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-center" }, [
  /* @__PURE__ */ createBaseVNode("div", {
    class: "bg-surface-variant rounded-te-lg mx-auto",
    style: { "height": "64px", "width": "64px" }
  }),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "rounded-te-lg")
], -1);
const _hoisted_3$1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-center" }, [
  /* @__PURE__ */ createBaseVNode("div", {
    class: "bg-surface-variant rounded-be-lg mx-auto",
    style: { "height": "64px", "width": "64px" }
  }),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "rounded-be-lg")
], -1);
const _hoisted_4$1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-center" }, [
  /* @__PURE__ */ createBaseVNode("div", {
    class: "bg-surface-variant rounded-bs-lg mx-auto",
    style: { "height": "64px", "width": "64px" }
  }),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "rounded-bs-lg")
], -1);
function _sfc_render$1(_ctx, _cache) {
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, null, {
    default: withCtx(() => [
      createVNode(_component_v_row, { justify: "space-around" }, {
        default: withCtx(() => [
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              _hoisted_1$1
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              _hoisted_2$1
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              _hoisted_3$1
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              _hoisted_4$1
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __4 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["render", _sfc_render$1]]);
const __4_raw = '<template>\n  <v-container>\n    <v-row justify="space-around">\n      <v-col cols="auto">\n        <div class="text-center">\n          <div class="bg-surface-variant rounded-ts-lg mx-auto" style="height: 64px; width: 64px;"></div>\n          <div class="text-caption">rounded-ts-lg</div>\n        </div>\n      </v-col>\n\n      <v-col cols="auto">\n        <div class="text-center">\n          <div class="bg-surface-variant rounded-te-lg mx-auto" style="height: 64px; width: 64px;"></div>\n          <div class="text-caption">rounded-te-lg</div>\n        </div>\n      </v-col>\n\n      <v-col cols="auto">\n        <div class="text-center">\n          <div class="bg-surface-variant rounded-be-lg mx-auto" style="height: 64px; width: 64px;"></div>\n          <div class="text-caption">rounded-be-lg</div>\n        </div>\n      </v-col>\n\n      <v-col cols="auto">\n        <div class="text-center">\n          <div class="bg-surface-variant rounded-bs-lg mx-auto" style="height: 64px; width: 64px;"></div>\n          <div class="text-caption">rounded-bs-lg</div>\n        </div>\n      </v-col>\n    </v-row>\n  </v-container>\n</template>\n';
const _sfc_main = {};
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-center" }, [
  /* @__PURE__ */ createBaseVNode("div", {
    class: "bg-surface-variant rounded-t-lg mx-auto",
    style: { "height": "64px", "width": "64px" }
  }),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "rounded-t-lg")
], -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("div", { class: "text-center" }, [
  /* @__PURE__ */ createBaseVNode("div", {
    class: "bg-surface-variant rounded-e-lg mx-auto",
    style: { "height": "64px", "width": "64px" }
  }),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "rounded-e-lg")
], -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("div", { class: "text-center" }, [
  /* @__PURE__ */ createBaseVNode("div", {
    class: "bg-surface-variant rounded-b-lg mx-auto",
    style: { "height": "64px", "width": "64px" }
  }),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "rounded-b-lg")
], -1);
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("div", { class: "text-center" }, [
  /* @__PURE__ */ createBaseVNode("div", {
    class: "bg-surface-variant rounded-s-lg mx-auto",
    style: { "height": "64px", "width": "64px" }
  }),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "rounded-s-lg")
], -1);
function _sfc_render(_ctx, _cache) {
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, null, {
    default: withCtx(() => [
      createVNode(_component_v_row, { justify: "space-around" }, {
        default: withCtx(() => [
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              _hoisted_1
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              _hoisted_2
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              _hoisted_3
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              _hoisted_4
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __5 = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
const __5_raw = '<template>\n  <v-container>\n    <v-row justify="space-around">\n      <v-col cols="auto">\n        <div class="text-center">\n          <div class="bg-surface-variant rounded-t-lg mx-auto" style="height: 64px; width: 64px;"></div>\n          <div class="text-caption">rounded-t-lg</div>\n        </div>\n      </v-col>\n\n      <v-col cols="auto">\n        <div class="text-center">\n          <div class="bg-surface-variant rounded-e-lg mx-auto" style="height: 64px; width: 64px;"></div>\n          <div class="text-caption">rounded-e-lg</div>\n        </div>\n      </v-col>\n\n      <v-col cols="auto">\n        <div class="text-center">\n          <div class="bg-surface-variant rounded-b-lg mx-auto" style="height: 64px; width: 64px;"></div>\n          <div class="text-caption">rounded-b-lg</div>\n        </div>\n      </v-col>\n\n      <v-col cols="auto">\n        <div class="text-center">\n          <div class="bg-surface-variant rounded-s-lg mx-auto" style="height: 64px; width: 64px;"></div>\n          <div class="text-caption">rounded-s-lg</div>\n        </div>\n      </v-col>\n    </v-row>\n  </v-container>\n</template>\n';
const borderRadius = {
  "misc-components": {
    component: __0,
    source: __0_raw
  },
  "misc-pill-and-circle": {
    component: __1,
    source: __1_raw
  },
  "misc-removing-border-radius": {
    component: __2,
    source: __2_raw
  },
  "misc-rounded-corners": {
    component: __3,
    source: __3_raw
  },
  "misc-rounding-by-corner": {
    component: __4,
    source: __4_raw
  },
  "misc-rounding-by-side": {
    component: __5,
    source: __5_raw
  }
};
export {
  borderRadius as default
};
