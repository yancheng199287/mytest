import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "border-radius" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "Use border utilities to quickly style the border-radius of any element.", -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Class"),
    /* @__PURE__ */ createBaseVNode("th", null, "Properties")
  ])
], -1);
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("tbody", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-radius: 4px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-0")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-radius: 0;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-sm")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-radius: 2px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-lg")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-radius: 8px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-xl")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-radius: 24px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-pill")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-radius: 9999px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-circle")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-radius: 50%;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-shaped")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-radius: 24px 0")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-t")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("border-top-left-radius: 4px;"),
      /* @__PURE__ */ createBaseVNode("br"),
      /* @__PURE__ */ createTextVNode("border-top-right-radius: 4px;")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-t-0")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("border-top-left-radius: 0;"),
      /* @__PURE__ */ createBaseVNode("br"),
      /* @__PURE__ */ createTextVNode("border-top-right-radius: 0;")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-t-sm")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("border-top-left-radius: 2px;"),
      /* @__PURE__ */ createBaseVNode("br"),
      /* @__PURE__ */ createTextVNode("border-top-right-radius: 2px;")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-t-lg")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("border-top-left-radius: 8px;"),
      /* @__PURE__ */ createBaseVNode("br"),
      /* @__PURE__ */ createTextVNode("border-top-right-radius: 8px;")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-t-xl")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("border-top-left-radius: 24px;"),
      /* @__PURE__ */ createBaseVNode("br"),
      /* @__PURE__ */ createTextVNode("border-top-right-radius: 24px;")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-t-pill")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("border-top-left-radius: 9999px;"),
      /* @__PURE__ */ createBaseVNode("br"),
      /* @__PURE__ */ createTextVNode("border-top-right-radius: 9999px;")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-t-circle")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("border-top-left-radius: 50%;"),
      /* @__PURE__ */ createBaseVNode("br"),
      /* @__PURE__ */ createTextVNode("border-top-right-radius: 50%;")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-t-shaped")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-top-left-radius: 24px; border-top-right-radius: 0;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-te")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-top-right-radius: 4px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-te-0")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-top-right-radius: 0;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-te-sm")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-top-right-radius: 2px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-te-lg")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-top-right-radius: 8px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-te-xl")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-top-right-radius: 24px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-te-pill")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-top-right-radius: 9999px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-te-circle")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-top-right-radius: 50%;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-te-shaped")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("border-top-right-radius: 24px"),
      /* @__PURE__ */ createBaseVNode("br"),
      /* @__PURE__ */ createTextVNode("border-top-left-radius: 0;")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-ts")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-top-left-radius: 4px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-ts-0")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-top-left-radius: 0;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-ts-sm")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-top-left-radius: 2px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-ts-lg")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-top-left-radius: 8px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-ts-xl")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-top-left-radius: 24px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-ts-pill")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-top-left-radius: 9999px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-ts-circle")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-top-left-radius: 50%;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-ts-shaped")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-top-left-radius: 24px; border-top-right-radius: 0;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-e")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-inline-end-radius: 4px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-e-0")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-inline-end-radius: 0;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-e-sm")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-inline-end-radius: 2px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-e-lg")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-inline-end-radius: 8px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-e-xl")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-inline-end-radius: 24px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-e-pill")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-inline-end-radius: 9999px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-e-circle")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-inline-end-radius: 50%;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-e-shaped")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-inline-end-radius: 0; border-inline-start-radius: 24px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-b")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("border-bottom-left-radius: 4px;"),
      /* @__PURE__ */ createBaseVNode("br"),
      /* @__PURE__ */ createTextVNode("border-bottom-right-radius: 4px;")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-b-0")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("border-bottom-left-radius: 0;"),
      /* @__PURE__ */ createBaseVNode("br"),
      /* @__PURE__ */ createTextVNode("border-bottom-right-radius: 0;")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-b-sm")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("border-bottom-left-radius: 2px;"),
      /* @__PURE__ */ createBaseVNode("br"),
      /* @__PURE__ */ createTextVNode("border-bottom-right-radius: 2px;")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-b-lg")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("border-bottom-left-radius: 8px;"),
      /* @__PURE__ */ createBaseVNode("br"),
      /* @__PURE__ */ createTextVNode("border-bottom-right-radius: 8px;")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-b-xl")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("border-bottom-left-radius: 24px;"),
      /* @__PURE__ */ createBaseVNode("br"),
      /* @__PURE__ */ createTextVNode("border-bottom-right-radius: 24px;")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-b-pill")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("border-bottom-left-radius: 9999px;"),
      /* @__PURE__ */ createBaseVNode("br"),
      /* @__PURE__ */ createTextVNode("border-bottom-right-radius: 9999px;")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-b-circle")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("border-bottom-left-radius: 50%;"),
      /* @__PURE__ */ createBaseVNode("br"),
      /* @__PURE__ */ createTextVNode("border-bottom-right-radius: 50%;")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-b-shaped")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-bottom-left-radius: 0; border-bottom-right-radius: 24px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-be")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-bottom-right-radius: 4px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-be-0")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-bottom-right-radius: 0;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-be-sm")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-bottom-right-radius: 2px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-be-lg")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-bottom-right-radius: 8px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-be-xl")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-bottom-right-radius: 24px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-be-pill")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-bottom-right-radius: 9999px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-be-circle")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-bottom-right-radius: 50%;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-be-shaped")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-bottom-right-radius: 24px; border-bottom-left-radius: 0;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-bs")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-inline-start-radius: 4px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-bs-0")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-inline-start-radius: 0;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-bs-sm")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-inline-start-radius: 2px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-bs-lg")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-inline-start-radius: 8px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-bs-xl")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-inline-start-radius: 24px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-bs-pill")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-inline-start-radius: 9999px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-bs-circle")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-inline-start-radius: 50%;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-bs-shaped")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-inline-start-radius: 24px; border-inline-end-radius: 0;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-s")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-inline-start-radius: 4px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-s-0")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-inline-start-radius: 0;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-s-sm")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-inline-start-radius: 2px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-s-lg")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-inline-start-radius: 8px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-s-xl")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-inline-start-radius: 24px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-s-pill")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-inline-start-radius: 9999px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-s-circle")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-inline-start-radius: 50%;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "rounded-s-shaped")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-inline-start-radius: 24px; border-inline-end-radius: 0;")
  ])
], -1);
const _hoisted_5 = { id: "usage" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "border-radius"),
  /* @__PURE__ */ createTextVNode(" utilities allow you to quickly style the border-radius of any element.")
], -1);
const _hoisted_7 = { id: "rounded-corners" };
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Use the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "rounded"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "rounded-0"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "rounded-sm"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "rounded-lg"),
  /* @__PURE__ */ createTextVNode(", and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "rounded-xl"),
  /* @__PURE__ */ createTextVNode(" classes to set the border-radius of an element.")
], -1);
const _hoisted_9 = { id: "pill-and-circle" };
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Use the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "rounded-pill"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "rounded-circle"),
  /* @__PURE__ */ createTextVNode(" classes to create pill and circle shapes.")
], -1);
const _hoisted_11 = { id: "rounding-by-side" };
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Use the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "rounded-t-*"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "rounded-b-*"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "rounded-s-*"),
  /* @__PURE__ */ createTextVNode(", and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "rounded-e-*"),
  /* @__PURE__ */ createTextVNode(" classes to set the border-radius of an element on a specific side.")
], -1);
const _hoisted_13 = { id: "rounding-by-corner" };
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Use the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "rounded-te-*"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "rounded-ts-*"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "rounded-be-*"),
  /* @__PURE__ */ createTextVNode(", and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "rounded-bs-*"),
  /* @__PURE__ */ createTextVNode(" classes to set the border-radius of an element on a specific corner.")
], -1);
const _hoisted_15 = { id: "no-rounding" };
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Use the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "rounded-0"),
  /* @__PURE__ */ createTextVNode(" class to remove the border-radius from an element.")
], -1);
const _hoisted_17 = { id: "components" };
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("When using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "rounded"),
  /* @__PURE__ */ createTextVNode(" property on components, omit the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "rounded-"),
  /* @__PURE__ */ createTextVNode(" prefix. For example, use "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, 'rounded="sm"'),
  /* @__PURE__ */ createTextVNode(" instead of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "rounded-sm"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Setting the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "rounded"),
  /* @__PURE__ */ createTextVNode(" property applies a component specific border-radius class, such as "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-sheet--rounded"),
  /* @__PURE__ */ createTextVNode(". This is to ensure that basic rounded usage persists even if the utility classes are disabled.")
], -1);
const _hoisted_20 = { id: "sass-variables" };
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("p", null, "You can also use the following SASS variables to customize the border color and width:", -1);
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-scss" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-scss" }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token variable" }, "$rounded")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, "0"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(" 0"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'sm'"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token variable" }, "$border-radius-root"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "/"),
    /* @__PURE__ */ createTextVNode(" 2"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, "null"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token variable" }, "$border-radius-root"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'lg'"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token variable" }, "$border-radius-root"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "*"),
    /* @__PURE__ */ createTextVNode(" 2"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'xl'"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token variable" }, "$border-radius-root"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "*"),
    /* @__PURE__ */ createTextVNode(" 6"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'pill'"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(" 9999px"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'circle'"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(" 50%\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ";"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Disable border-radius class generation by setting the $rounded variable to "),
  /* @__PURE__ */ createBaseVNode("strong", null, "false"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-sass" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/styles/settings.scss",
    class: "language-sass"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token atrule-line" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token atrule" }, "@use"),
      /* @__PURE__ */ createTextVNode(" 'vuetify/settings' with (")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token variable-line" }, [
      /* @__PURE__ */ createTextVNode("  "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token variable" }, "$rounded"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
      /* @__PURE__ */ createTextVNode(" false")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token selector" }, ");"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const frontmatter = { "meta": { "title": "Border radius", "description": "Use border utilities to quickly style the border-radius of any element.", "keywords": "border radius classes, radius utilities, vuetify radius helper classes" }, "related": ["/styles/text-and-typography/", "/components/sheets/", "/components/buttons/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "border-radius",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "Border radius", "description": "Use border utilities to quickly style the border-radius of any element.", "keywords": "border radius classes, radius utilities, vuetify radius helper classes" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "title": "Border radius", "description": "Use border utilities to quickly style the border-radius of any element.", "keywords": "border radius classes, radius utilities, vuetify radius helper classes" }, "related": ["/styles/text-and-typography/", "/components/sheets/", "/components/buttons/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_app_table = resolveComponent("app-table");
      const _component_vo_promotions_card_vuetify = resolveComponent("vo-promotions-card-vuetify");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_alert = resolveComponent("alert");
      const _component_app_markup = resolveComponent("app-markup");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#border-radius",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Border Radius")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_app_table, {
                style: { "max-height": "420px" },
                "fixed-header": ""
              }, {
                default: withCtx(() => [
                  _hoisted_3,
                  _hoisted_4
                ]),
                _: 1
              }),
              createVNode(_component_vo_promotions_card_vuetify),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_6,
                createBaseVNode("section", _hoisted_7, [
                  createVNode(_component_app_heading, {
                    href: "#rounded-corners",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Rounded corners")
                    ]),
                    _: 1
                  }),
                  _hoisted_8,
                  createVNode(_component_examples_example, { file: "border-radius/misc-rounded-corners" })
                ]),
                createBaseVNode("section", _hoisted_9, [
                  createVNode(_component_app_heading, {
                    href: "#pill-and-circle",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Pill and circle")
                    ]),
                    _: 1
                  }),
                  _hoisted_10,
                  createVNode(_component_examples_example, { file: "border-radius/misc-pill-and-circle" })
                ]),
                createBaseVNode("section", _hoisted_11, [
                  createVNode(_component_app_heading, {
                    href: "#rounding-by-side",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Rounding by side")
                    ]),
                    _: 1
                  }),
                  _hoisted_12,
                  createVNode(_component_examples_example, { file: "border-radius/misc-rounding-by-side" })
                ]),
                createBaseVNode("section", _hoisted_13, [
                  createVNode(_component_app_heading, {
                    href: "#rounding-by-corner",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Rounding by corner")
                    ]),
                    _: 1
                  }),
                  _hoisted_14,
                  createVNode(_component_examples_example, { file: "border-radius/misc-rounding-by-corner" })
                ]),
                createBaseVNode("section", _hoisted_15, [
                  createVNode(_component_app_heading, {
                    href: "#no-rounding",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("No rounding")
                    ]),
                    _: 1
                  }),
                  _hoisted_16,
                  createVNode(_component_examples_example, { file: "border-radius/misc-removing-border-radius" })
                ]),
                createBaseVNode("section", _hoisted_17, [
                  createVNode(_component_app_heading, {
                    href: "#components",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Components")
                    ]),
                    _: 1
                  }),
                  createVNode(_component_alert, { type: "info" }, {
                    default: withCtx(() => [
                      _hoisted_18
                    ]),
                    _: 1
                  }),
                  _hoisted_19,
                  createVNode(_component_examples_example, { file: "border-radius/misc-components" })
                ])
              ]),
              createBaseVNode("section", _hoisted_20, [
                createVNode(_component_app_heading, {
                  href: "#sass-variables",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("SASS variables")
                  ]),
                  _: 1
                }),
                _hoisted_21,
                createVNode(_component_app_markup, {
                  resource: "",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_22
                  ]),
                  _: 1
                }),
                _hoisted_23,
                createVNode(_component_app_markup, {
                  resource: "src/styles/settings.scss",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_24
                  ]),
                  _: 1
                })
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
