import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "borders" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "Utilities for controlling the border of elements in your application.", -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Class"),
    /* @__PURE__ */ createBaseVNode("th", null, "Properties")
  ])
], -1);
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("tbody", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border: thin solid rgba(var(–v-border-color), var(–v-border-opacity));")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-thin")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-width: thin;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-sm")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-width: 1px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-md")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-width: 2px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-lg")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-width: 4px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-xl")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-width: 8px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-0")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-width: 0;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-t")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-top-width: thin;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-t-0")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-top-width: 0;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-t-thin")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-top-width: thin;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-t-sm")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-top-width: 1px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-t-md")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-top-width: 2px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-t-lg")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-top-width: 4px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-t-xl")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-top-width: 8px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-e")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-inline-end-width: thin;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-e-0")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-inline-end-width: 0;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-e-thin")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-inline-end-width: thin;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-e-sm")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-inline-end-width: 1px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-e-md")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-inline-end-width: 2px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-e-lg")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-inline-end-width: 4px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-e-xl")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-inline-end-width: 8px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-b")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-bottom-width: thin;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-b-0")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-bottom-width: 0;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-b-thin")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-bottom-width: thin;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-b-sm")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-bottom-width: 1px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-b-md")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-bottom-width: 2px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-b-lg")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-bottom-width: 4px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-b-xl")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-bottom-width: 8px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-s")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-inline-start-width: thin;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-s-0")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-inline-start-width: 0;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-s-thin")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-inline-start-width: thin;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-s-sm")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-inline-start-width: 1px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-s-md")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-inline-start-width: 2px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-s-lg")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-inline-start-width: 4px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-s-xl")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-inline-start-width: 8px;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-opacity-0")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "–v-border-opacity: 0;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-opacity")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "–v-border-opacity: .12;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-opacity-25")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "–v-border-opacity: .25;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-opacity-50")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "–v-border-opacity: .5;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-opacity-75")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "–v-border-opacity: .75;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-opacity-100")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "–v-border-opacity: 1;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-dashed")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-style: dashed;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-dotted")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-style: dotted;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-double")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-style: double;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-solid")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "border-style: solid;")
  ])
], -1);
const _hoisted_5 = { id: "usage" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "border"),
  /* @__PURE__ */ createTextVNode(" utilities allow you to quickly style the border of any element.")
], -1);
const _hoisted_7 = { id: "all-sides" };
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Use the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "border"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "border-0"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "border-sm"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "border-md"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "border-lg"),
  /* @__PURE__ */ createTextVNode(", and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "border-xl"),
  /* @__PURE__ */ createTextVNode(" classes to set the border width of an element.")
], -1);
const _hoisted_9 = { id: "individual-sides" };
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Use the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "border-*"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "border-*-0"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "border-*-sm"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "border-*-md"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "border-*-lg"),
  /* @__PURE__ */ createTextVNode(", and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "border-*-xl"),
  /* @__PURE__ */ createTextVNode(" classes to set the border width of an element on a specific side.")
], -1);
const _hoisted_11 = { id: "border-styles" };
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Use the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "border-dashed"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "border-dotted"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "border-double"),
  /* @__PURE__ */ createTextVNode(", and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "border-solid"),
  /* @__PURE__ */ createTextVNode(" classes to set the border style of an element.")
], -1);
const _hoisted_13 = { id: "theme-colors" };
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Components that support the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "border"),
  /* @__PURE__ */ createTextVNode(" property can take advantage of all border utility classes. This includes colors generated by your theme.")
], -1);
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Class"),
    /* @__PURE__ */ createBaseVNode("th", null, "Properties")
  ])
], -1);
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("tbody", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-primary")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "–v-border-color: var(–v-theme-primary);")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-secondary")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "–v-border-color: var(–v-theme-secondary);")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-accent")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "–v-border-color: var(–v-theme-accent);")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-error")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "–v-border-color: var(–v-theme-error);")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-info")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "–v-border-color: var(–v-theme-info);")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-success")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "–v-border-color: var(–v-theme-success);")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-warning")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "–v-border-color: var(–v-theme-warning);")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-surface")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "–v-border-color: var(–v-theme-surface);")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-background")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "–v-border-color: var(–v-theme-background);")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-surface-light")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "–v-border-color: var(–v-theme-surface-light);")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-surface-variant")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "–v-border-color: var(–v-theme-surface-variant);")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "border-surface-bright")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "–v-border-color: var(–v-theme-surface-bright);")
  ])
], -1);
const _hoisted_17 = { id: "components" };
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("When using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "border"),
  /* @__PURE__ */ createTextVNode(" property on components, omit the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "border-"),
  /* @__PURE__ */ createTextVNode(" prefix. For example, use "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, 'border="sm"'),
  /* @__PURE__ */ createTextVNode(" instead of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, 'border="border-sm"'),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Setting the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "border"),
  /* @__PURE__ */ createTextVNode(" property to true applies a component specific border class, such as "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-card--border"),
  /* @__PURE__ */ createTextVNode(". This is to ensure that basic border usage persists even if the utility classes are disabled.")
], -1);
const _hoisted_20 = { id: "sass-variables" };
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("p", null, "You can also use the following SASS variables to customize the border color and width:", -1);
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-sass" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/styles/settings.scss",
    class: "language-sass"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token atrule-line" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token atrule" }, "@use"),
      /* @__PURE__ */ createTextVNode(" 'vuetify/settings' with (")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token variable-line" }, [
      /* @__PURE__ */ createTextVNode("  "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token variable" }, "$borders"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
      /* @__PURE__ */ createTextVNode(" (")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property-line" }, [
      /* @__PURE__ */ createTextVNode("    "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, "0"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
      /* @__PURE__ */ createTextVNode(" 0,")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property-line" }, [
      /* @__PURE__ */ createTextVNode("    "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, "null"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
      /* @__PURE__ */ createTextVNode(" thin,")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property-line" }, [
      /* @__PURE__ */ createTextVNode("    "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, "thin"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
      /* @__PURE__ */ createTextVNode(" thin,")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property-line" }, [
      /* @__PURE__ */ createTextVNode("    "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, "sm"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
      /* @__PURE__ */ createTextVNode(" 1px,")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property-line" }, [
      /* @__PURE__ */ createTextVNode("    "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, "md"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
      /* @__PURE__ */ createTextVNode(" 2px,")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property-line" }, [
      /* @__PURE__ */ createTextVNode("    "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, "lg"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
      /* @__PURE__ */ createTextVNode(" 4px,")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property-line" }, [
      /* @__PURE__ */ createTextVNode("    "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, "xl"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
      /* @__PURE__ */ createTextVNode(" 8px")
    ]),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token selector" }, ")"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token selector" }, ");"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Disable border class generation by setting the $borders variable to "),
  /* @__PURE__ */ createBaseVNode("strong", null, "false"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-sass" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/styles/settings.scss",
    class: "language-sass"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token atrule-line" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token atrule" }, "@use"),
      /* @__PURE__ */ createTextVNode(" 'vuetify/settings' with (")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token variable-line" }, [
      /* @__PURE__ */ createTextVNode("  "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token variable" }, "$borders"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
      /* @__PURE__ */ createTextVNode(" false")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token selector" }, ");"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const frontmatter = { "emphasized": true, "meta": { "title": "Borders", "description": "Use border utilities to quickly style the border of any element.", "keywords": "border classes, border utilities, vuetify border helper classes" }, "related": ["/styles/border-radius/", "/styles/display/", "/styles/content/"], "features": { "report": true } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "borders",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "Borders", "description": "Use border utilities to quickly style the border of any element.", "keywords": "border classes, border utilities, vuetify border helper classes" } };
    useHead(head);
    __expose({ frontmatter: { "emphasized": true, "meta": { "title": "Borders", "description": "Use border utilities to quickly style the border of any element.", "keywords": "border classes, border utilities, vuetify border helper classes" }, "related": ["/styles/border-radius/", "/styles/display/", "/styles/content/"], "features": { "report": true } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_app_table = resolveComponent("app-table");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_alert = resolveComponent("alert");
      const _component_app_markup = resolveComponent("app-markup");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#borders",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Borders")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_app_table, {
                style: { "max-height": "420px" },
                "fixed-header": ""
              }, {
                default: withCtx(() => [
                  _hoisted_3,
                  _hoisted_4
                ]),
                _: 1
              }),
              createVNode(_component_promoted_entry),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_6,
                createBaseVNode("section", _hoisted_7, [
                  createVNode(_component_app_heading, {
                    href: "#all-sides",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("All sides")
                    ]),
                    _: 1
                  }),
                  _hoisted_8,
                  createVNode(_component_examples_example, { file: "border/all" })
                ]),
                createBaseVNode("section", _hoisted_9, [
                  createVNode(_component_app_heading, {
                    href: "#individual-sides",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Individual sides")
                    ]),
                    _: 1
                  }),
                  _hoisted_10,
                  createVNode(_component_examples_example, { file: "border/sides" })
                ]),
                createBaseVNode("section", _hoisted_11, [
                  createVNode(_component_app_heading, {
                    href: "#border-styles",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Border styles")
                    ]),
                    _: 1
                  }),
                  _hoisted_12,
                  createVNode(_component_examples_example, { file: "border/styles" })
                ]),
                createBaseVNode("section", _hoisted_13, [
                  createVNode(_component_app_heading, {
                    href: "#theme-colors",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Theme colors")
                    ]),
                    _: 1
                  }),
                  _hoisted_14,
                  createVNode(_component_examples_example, { file: "border/colors" }),
                  createVNode(_component_app_table, {
                    style: { "max-height": "420px" },
                    "fixed-header": ""
                  }, {
                    default: withCtx(() => [
                      _hoisted_15,
                      _hoisted_16
                    ]),
                    _: 1
                  })
                ]),
                createBaseVNode("section", _hoisted_17, [
                  createVNode(_component_app_heading, {
                    href: "#components",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Components")
                    ]),
                    _: 1
                  }),
                  createVNode(_component_alert, { type: "info" }, {
                    default: withCtx(() => [
                      _hoisted_18
                    ]),
                    _: 1
                  }),
                  _hoisted_19,
                  createVNode(_component_examples_example, { file: "border/card" })
                ])
              ]),
              createBaseVNode("section", _hoisted_20, [
                createVNode(_component_app_heading, {
                  href: "#sass-variables",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("SASS variables")
                  ]),
                  _: 1
                }),
                _hoisted_21,
                createVNode(_component_app_markup, {
                  resource: "src/styles/settings.scss",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_22
                  ]),
                  _: 1
                }),
                _hoisted_23,
                createVNode(_component_app_markup, {
                  resource: "src/styles/settings.scss",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_24
                  ]),
                  _: 1
                })
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
