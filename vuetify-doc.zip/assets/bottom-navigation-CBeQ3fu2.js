import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "bottom-navigation" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-bottom-navigation"),
  /* @__PURE__ */ createTextVNode(" component is an alternative to the sidebar. It is primarily used for mobile applications and comes in three variants, "),
  /* @__PURE__ */ createBaseVNode("strong", null, "icons"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "text"),
  /* @__PURE__ */ createTextVNode(", and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "shift"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-bottom navigation", -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("strong", null, "value", -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "index", -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-bottom-navigation", -1);
const _hoisted_8 = { id: "api" };
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createTextVNode("Sub-component used for modifying the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-bottom-navigation"),
  /* @__PURE__ */ createTextVNode(" state")
], -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("For styles to apply properly when using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "shift"),
  /* @__PURE__ */ createTextVNode(" prop, "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn"),
  /* @__PURE__ */ createTextVNode(" text is "),
  /* @__PURE__ */ createBaseVNode("strong", null, "required"),
  /* @__PURE__ */ createTextVNode(" to be wrapped in a "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "span"),
  /* @__PURE__ */ createTextVNode(" tag.")
], -1);
const _hoisted_13 = { id: "examples" };
const _hoisted_14 = { id: "props" };
const _hoisted_15 = { id: "color" };
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "color"),
  /* @__PURE__ */ createTextVNode(" prop applies a color to the background of the bottom navigation. We recommend using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "light"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "dark"),
  /* @__PURE__ */ createTextVNode(" props to properly contrast text color.")
], -1);
const _hoisted_17 = { id: "grow" };
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("strong", null, "grow", -1);
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "fill", -1);
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("strong", null, "168px", -1);
const _hoisted_21 = { id: "horizontal" };
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("strong", null, "horizontal", -1);
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("em", null, "inline", -1);
const _hoisted_24 = { id: "shift" };
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "shift"),
  /* @__PURE__ */ createTextVNode(" prop hides button text when not active. This provides an alternative visual style to the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-bottom-navigation"),
  /* @__PURE__ */ createTextVNode(" component.")
], -1);
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("For this to work, "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn"),
  /* @__PURE__ */ createTextVNode(" text is "),
  /* @__PURE__ */ createBaseVNode("strong", null, "required"),
  /* @__PURE__ */ createTextVNode(" to be wrapped in a "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "span"),
  /* @__PURE__ */ createTextVNode(" tag.")
], -1);
const _hoisted_27 = { id: "toggle" };
const _hoisted_28 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Since "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-bottom-navigation"),
  /* @__PURE__ */ createTextVNode(" supports v-model, use the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "active"),
  /* @__PURE__ */ createTextVNode(" prop to control the display state.")
], -1);
const frontmatter = { "meta": { "nav": "Bottom navigation", "title": "Bottom navigation component", "description": "The bottom navigation component is used for mobile devices and acts as the primary navigation for your application.", "keywords": "bottom navigation, vuetify bottom navigation component, vue bottom navigation component" }, "related": ["/components/buttons/", "/components/icons/", "/components/tabs/"], "features": { "figma": true, "label": "C: VBottomNavigation", "report": true, "github": "/components/VBottomNavigation/", "spec": "https://m2.material.io/components/bottom-navigation" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "bottom-navigation",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Bottom navigation", "title": "Bottom navigation component", "description": "The bottom navigation component is used for mobile devices and acts as the primary navigation for your application.", "keywords": "bottom navigation, vuetify bottom navigation component, vue bottom navigation component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Bottom navigation", "title": "Bottom navigation component", "description": "The bottom navigation component is used for mobile devices and acts as the primary navigation for your application.", "keywords": "bottom navigation, vuetify bottom navigation component, vue bottom navigation component" }, "related": ["/components/buttons/", "/components/icons/", "/components/tabs/"], "features": { "figma": true, "label": "C: VBottomNavigation", "report": true, "github": "/components/VBottomNavigation/", "spec": "https://m2.material.io/components/bottom-navigation" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_app_link = resolveComponent("app-link");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_alert = resolveComponent("alert");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#bottom-navigation",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Bottom navigation")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("While "),
                  _hoisted_4,
                  createTextVNode(" is meant to be used with "),
                  createVNode(_component_app_link, { href: "https://router.vuejs.org/" }, {
                    default: withCtx(() => [
                      createTextVNode("vue-router")
                    ]),
                    _: 1
                  }),
                  createTextVNode(", you can also programmatically control the active state of the buttons by using the "),
                  _hoisted_5,
                  createTextVNode(" property. A button is given a default value of its "),
                  _hoisted_6,
                  createTextVNode(" with "),
                  _hoisted_7,
                  createTextVNode(".")
                ]),
                createVNode(_component_examples_usage, { name: "v-bottom-navigation" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_8, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_9,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-bottom-navigation/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-bottom-navigation")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_10
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-btn/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-btn")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_11
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" }),
                createVNode(_component_alert, { type: "info" }, {
                  default: withCtx(() => [
                    _hoisted_12
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_13, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_14, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_15, [
                    createVNode(_component_app_heading, {
                      href: "#color",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Color")
                      ]),
                      _: 1
                    }),
                    _hoisted_16,
                    createVNode(_component_examples_example, { file: "v-bottom-navigation/prop-color" })
                  ]),
                  createBaseVNode("section", _hoisted_17, [
                    createVNode(_component_app_heading, {
                      href: "#grow",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Grow")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("Using the "),
                      _hoisted_18,
                      createTextVNode(" property forces "),
                      createVNode(_component_app_link, { href: "/components/buttons/" }, {
                        default: withCtx(() => [
                          createTextVNode("v-btn")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" components to "),
                      _hoisted_19,
                      createTextVNode(" all available space. Buttons have a maximum width of "),
                      _hoisted_20,
                      createTextVNode(" per the "),
                      createVNode(_component_app_link, { href: "https://material.io/components/bottom-navigation#specs" }, {
                        default: withCtx(() => [
                          createTextVNode("Bottom Navigation MD specification")
                        ]),
                        _: 1
                      }),
                      createTextVNode(".")
                    ]),
                    createVNode(_component_examples_example, { file: "v-bottom-navigation/prop-grow" })
                  ]),
                  createBaseVNode("section", _hoisted_21, [
                    createVNode(_component_app_heading, {
                      href: "#horizontal",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Horizontal")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("Adjust the style of buttons and icons by using the "),
                      _hoisted_22,
                      createTextVNode(" prop. This positions button text "),
                      _hoisted_23,
                      createTextVNode(" with the provided "),
                      createVNode(_component_app_link, { href: "/components/icons/" }, {
                        default: withCtx(() => [
                          createTextVNode("v-icon")
                        ]),
                        _: 1
                      }),
                      createTextVNode(".")
                    ]),
                    createVNode(_component_examples_example, { file: "v-bottom-navigation/prop-horizontal" })
                  ]),
                  createBaseVNode("section", _hoisted_24, [
                    createVNode(_component_app_heading, {
                      href: "#shift",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Shift")
                      ]),
                      _: 1
                    }),
                    _hoisted_25,
                    createVNode(_component_alert, { type: "info" }, {
                      default: withCtx(() => [
                        _hoisted_26
                      ]),
                      _: 1
                    }),
                    createVNode(_component_examples_example, { file: "v-bottom-navigation/prop-shift" })
                  ]),
                  createBaseVNode("section", _hoisted_27, [
                    createVNode(_component_app_heading, {
                      href: "#toggle",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Toggle")
                      ]),
                      _: 1
                    }),
                    _hoisted_28,
                    createVNode(_component_examples_example, { file: "v-bottom-navigation/prop-toggle" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
