import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "brand-kit" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "Explore the Vuetify Brand Kit, your source for official logos and branding assets.", -1);
const _hoisted_3 = { id: "vuetify-logo" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, "The Vuetify logo encapsulates the essence of modern web development, combining sleek design with Vue.js principles. Its symmetrical lines and bold color palette reflect the framework’s commitment to efficiency, flexibility, and elegance, resonating with developers and designers alike.", -1);
const _hoisted_5 = { id: "color-palette" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("p", null, "The Vuetify logo color palette is comprised of 4 colors, each used for a different shape. The colors are designed to work together harmoniously, creating a unified and balanced look.", -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const frontmatter = { "fluid": true, "meta": { "nav": "Brand Kit", "title": "Brand Kit & Assets", "description": "Get access to the Vuetify logo and other brand assets", "keywords": "vuetify logo, vuetify assets, vuetify media kit, vuetify brand kit" }, "related": ["/getting-started/installation/", "/features/blueprints/", "/about/meet-the-team/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "brand-kit",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Brand Kit", "title": "Brand Kit & Assets", "description": "Get access to the Vuetify logo and other brand assets", "keywords": "vuetify logo, vuetify assets, vuetify media kit, vuetify brand kit" } };
    useHead(head);
    __expose({ frontmatter: { "fluid": true, "meta": { "nav": "Brand Kit", "title": "Brand Kit & Assets", "description": "Get access to the Vuetify logo and other brand assets", "keywords": "vuetify logo, vuetify assets, vuetify media kit, vuetify brand kit" }, "related": ["/getting-started/installation/", "/features/blueprints/", "/about/meet-the-team/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_resources_logos = resolveComponent("resources-logos");
      const _component_resources_color_palette = resolveComponent("resources-color-palette");
      const _component_app_link = resolveComponent("app-link");
      const _component_alert = resolveComponent("alert");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#brand-kit",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Brand Kit")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_promoted_entry),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#vuetify-logo",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Vuetify Logo")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_resources_logos)
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#color-palette",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Color Palette")
                  ]),
                  _: 1
                }),
                _hoisted_6,
                createVNode(_component_resources_color_palette),
                _hoisted_7,
                createVNode(_component_alert, { type: "success" }, {
                  default: withCtx(() => [
                    createBaseVNode("p", null, [
                      createTextVNode("Need something not on this page? Reach out to us at "),
                      createVNode(_component_app_link, { href: "mailto:hello@vuetifyjs.com" }, {
                        default: withCtx(() => [
                          createTextVNode("hello@vuetifyjs.com")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" and we’ll be happy to help.")
                    ])
                  ]),
                  _: 1
                })
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
