import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "breadcrumbs" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-breadcrumbs"),
  /* @__PURE__ */ createTextVNode(" component is used as a navigational helper and hierarchy for pages.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, "By default, breadcrumbs use a text divider. This can be any string.", -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "TIP:")
], -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-breadcrumbs-item", -1);
const _hoisted_7 = { id: "api" };
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("td", null, "Sub-component used for each breadcrumb", -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("td", null, "Sub-component used for dividing breadcrumbs", -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("By default "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-breadcrumbs"),
  /* @__PURE__ */ createTextVNode(" will disable all crumbs up to the current page in a nested paths. You can prevent this behavior by using "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "exact: true"),
  /* @__PURE__ */ createTextVNode(" on each applicable breadcrumb in the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "items"),
  /* @__PURE__ */ createTextVNode(" array.")
], -1);
const _hoisted_13 = { id: "examples" };
const _hoisted_14 = { id: "props" };
const _hoisted_15 = { id: "divider" };
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Breadcrumbs separator can be set using "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "divider"),
  /* @__PURE__ */ createTextVNode(" property.")
], -1);
const _hoisted_17 = { id: "slots" };
const _hoisted_18 = { id: "prepend" };
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Prepend content with the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "prepend"),
  /* @__PURE__ */ createTextVNode(" slot.")
], -1);
const _hoisted_20 = { id: "dividers" };
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("To customize the divider, use the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "divider"),
  /* @__PURE__ */ createTextVNode(" slot.")
], -1);
const _hoisted_22 = { id: "title" };
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can use the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "title"),
  /* @__PURE__ */ createTextVNode(" slot to customize each breadcrumb title.")
], -1);
const frontmatter = { "meta": { "nav": "Breadcrumbs", "title": "Breadcrumbs component", "description": "The breadcrumbs component is a navigational helper for pages. It can accept a Material Icons icon or characters as a divider.", "keywords": "breadcrumbs, vuetify breadcrumbs component, vue breadcrumbs component, v-breadcrumbs component" }, "related": ["/components/buttons/", "/components/navigation-drawers/", "/components/icons/"], "features": { "figma": true, "label": "C: VBreadcrumbs", "report": true, "github": "/components/VBreadcrumbs/" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "breadcrumbs",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Breadcrumbs", "title": "Breadcrumbs component", "description": "The breadcrumbs component is a navigational helper for pages. It can accept a Material Icons icon or characters as a divider.", "keywords": "breadcrumbs, vuetify breadcrumbs component, vue breadcrumbs component, v-breadcrumbs component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Breadcrumbs", "title": "Breadcrumbs component", "description": "The breadcrumbs component is a navigational helper for pages. It can accept a Material Icons icon or characters as a divider.", "keywords": "breadcrumbs, vuetify breadcrumbs component, vue breadcrumbs component, v-breadcrumbs component" }, "related": ["/components/buttons/", "/components/navigation-drawers/", "/components/icons/"], "features": { "figma": true, "label": "C: VBreadcrumbs", "report": true, "github": "/components/VBreadcrumbs/" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_alert = resolveComponent("alert");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#breadcrumbs",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Breadcrumbs")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_usage, { name: "v-breadcrumbs" }),
                createVNode(_component_promoted_entry),
                createVNode(_component_alert, { type: "tip" }, {
                  default: withCtx(() => [
                    _hoisted_5,
                    createBaseVNode("p", null, [
                      createTextVNode("Use "),
                      createVNode(_component_app_link, { href: "/api/v-breadcrumbs/#slots" }, {
                        default: withCtx(() => [
                          createTextVNode("slots")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" for more control of the breadcrumbs, either utilizing "),
                      _hoisted_6,
                      createTextVNode(" or other custom markup.")
                    ])
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_7, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_8,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-breadcrumbs/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-breadcrumbs")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_9
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-breadcrumbs-item/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-breadcrumbs-item")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_10
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-breadcrumbs-divider/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-breadcrumbs-divider")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_11
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" }),
                createVNode(_component_alert, { type: "info" }, {
                  default: withCtx(() => [
                    _hoisted_12
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_13, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_14, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_15, [
                    createVNode(_component_app_heading, {
                      href: "#divider",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Divider")
                      ]),
                      _: 1
                    }),
                    _hoisted_16,
                    createVNode(_component_examples_example, { file: "v-breadcrumbs/prop-divider" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_17, [
                  createVNode(_component_app_heading, {
                    href: "#slots",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Slots")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_18, [
                    createVNode(_component_app_heading, {
                      href: "#prepend",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Prepend")
                      ]),
                      _: 1
                    }),
                    _hoisted_19,
                    createVNode(_component_examples_example, { file: "v-breadcrumbs/slot-prepend" })
                  ]),
                  createBaseVNode("section", _hoisted_20, [
                    createVNode(_component_app_heading, {
                      href: "#dividers",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Dividers")
                      ]),
                      _: 1
                    }),
                    _hoisted_21,
                    createVNode(_component_examples_example, { file: "v-breadcrumbs/slot-icon-dividers" })
                  ]),
                  createBaseVNode("section", _hoisted_22, [
                    createVNode(_component_app_heading, {
                      href: "#title",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Title")
                      ]),
                      _: 1
                    }),
                    _hoisted_23,
                    createVNode(_component_examples_example, { file: "v-breadcrumbs/slot-title" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
