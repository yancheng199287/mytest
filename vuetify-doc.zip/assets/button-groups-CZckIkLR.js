import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "button-toggles" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn-toggle"),
  /* @__PURE__ */ createTextVNode(" component is a simple wrapper for "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-item-group"),
  /* @__PURE__ */ createTextVNode(" built specifically to work with "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Toggle buttons allow you to create a styled group of buttons that can be selected or toggled under a single "),
  /* @__PURE__ */ createBaseVNode("strong", null, "v-model"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_5 = { id: "api" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "Primary component", -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createTextVNode("Sub-component used for modifying the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn-toggle"),
  /* @__PURE__ */ createTextVNode(" state")
], -1);
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createTextVNode("A stateless version of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn-toggle")
], -1);
const _hoisted_10 = { id: "examples" };
const _hoisted_11 = { id: "props" };
const _hoisted_12 = { id: "divided" };
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can add a visual divider between buttons with the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "divided"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_14 = { id: "variant" };
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can switch the button variant by using "),
  /* @__PURE__ */ createBaseVNode("strong", null, "variant"),
  /* @__PURE__ */ createTextVNode(" prop on "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn-toggle"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_16 = { id: "mandatory" };
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("A "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn-toggle"),
  /* @__PURE__ */ createTextVNode(" with the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "mandatory"),
  /* @__PURE__ */ createTextVNode(" prop will always have a value.")
], -1);
const _hoisted_18 = { id: "multiple" };
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("A "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn-toggle"),
  /* @__PURE__ */ createTextVNode(" with the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "multiple"),
  /* @__PURE__ */ createTextVNode(" prop will allow a user to select multiple return values as an array.")
], -1);
const _hoisted_20 = { id: "rounded" };
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can control the border radius with the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "rounded"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_22 = { id: "misc" };
const _hoisted_23 = { id: "wysiwyg" };
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("p", null, "Group similar actions and design your own WYSIWYG component.", -1);
const frontmatter = { "meta": { "nav": "Button toggles", "title": "Button toggle component", "description": "The button toggle component allows you to combine a series of selectable buttons together in a single element.", "keywords": "button groups, vuetify button group component, vue button group component" }, "related": ["/components/buttons/", "/components/icons/", "/components/toolbars/"], "features": { "github": "/components/VBtnToggle/", "label": "C: VBtnToggle", "report": true, "spec": "https://m2.material.io/components/buttons#toggle-button" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "button-groups",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Button toggles", "title": "Button toggle component", "description": "The button toggle component allows you to combine a series of selectable buttons together in a single element.", "keywords": "button groups, vuetify button group component, vue button group component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Button toggles", "title": "Button toggle component", "description": "The button toggle component allows you to combine a series of selectable buttons together in a single element.", "keywords": "button groups, vuetify button group component, vue button group component" }, "related": ["/components/buttons/", "/components/icons/", "/components/toolbars/"], "features": { "github": "/components/VBtnToggle/", "label": "C: VBtnToggle", "report": true, "spec": "https://m2.material.io/components/buttons#toggle-button" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#button-toggles",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Button toggles")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_example, { file: "v-btn-toggle/usage" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_6,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-btn-toggle/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-btn-toggle")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-btn/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-btn")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_8
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-btn-group/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-btn-group")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_9
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_10, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_11, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_12, [
                    createVNode(_component_app_heading, {
                      href: "#divided",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Divided")
                      ]),
                      _: 1
                    }),
                    _hoisted_13,
                    createVNode(_component_examples_example, { file: "v-btn-toggle/prop-divided" })
                  ]),
                  createBaseVNode("section", _hoisted_14, [
                    createVNode(_component_app_heading, {
                      href: "#variant",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Variant")
                      ]),
                      _: 1
                    }),
                    _hoisted_15,
                    createVNode(_component_examples_example, { file: "v-btn-toggle/prop-variant" })
                  ]),
                  createBaseVNode("section", _hoisted_16, [
                    createVNode(_component_app_heading, {
                      href: "#mandatory",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Mandatory")
                      ]),
                      _: 1
                    }),
                    _hoisted_17,
                    createVNode(_component_examples_example, { file: "v-btn-toggle/prop-mandatory" })
                  ]),
                  createBaseVNode("section", _hoisted_18, [
                    createVNode(_component_app_heading, {
                      href: "#multiple",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Multiple")
                      ]),
                      _: 1
                    }),
                    _hoisted_19,
                    createVNode(_component_examples_example, { file: "v-btn-toggle/prop-multiple" })
                  ]),
                  createBaseVNode("section", _hoisted_20, [
                    createVNode(_component_app_heading, {
                      href: "#rounded",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Rounded")
                      ]),
                      _: 1
                    }),
                    _hoisted_21,
                    createVNode(_component_examples_example, { file: "v-btn-toggle/prop-rounded" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_22, [
                  createVNode(_component_app_heading, {
                    href: "#misc",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Misc")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_23, [
                    createVNode(_component_app_heading, {
                      href: "#wysiwyg",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("WYSIWYG")
                      ]),
                      _: 1
                    }),
                    _hoisted_24,
                    createVNode(_component_examples_example, { file: "v-btn-toggle/misc-wysiwyg" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
