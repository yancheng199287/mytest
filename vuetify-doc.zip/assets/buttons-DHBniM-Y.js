import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "buttons" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn"),
  /* @__PURE__ */ createTextVNode(" component replaces the standard html button with a material design theme and a multitude of options. Any color helper class can be used to alter the background or text color.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, "Buttons in their simplest form contain uppercase text, a slight elevation, hover effect, and a ripple effect on click.", -1);
const _hoisted_5 = { id: "api" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_8 = { id: "anatomy" };
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The recommended placement of elements inside of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn"),
  /* @__PURE__ */ createTextVNode(" is:")
], -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, "Place text in the center"),
  /* @__PURE__ */ createBaseVNode("li", null, "Place visual content around container text")
], -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Element / Area"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("td", null, "1. Container", -1);
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("tr", null, [
  /* @__PURE__ */ createBaseVNode("td", null, "2. Icon (optional)"),
  /* @__PURE__ */ createBaseVNode("td", null, "Leading media content intended to improve visual context")
], -1);
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("tr", null, [
  /* @__PURE__ */ createBaseVNode("td", null, "3. Text"),
  /* @__PURE__ */ createBaseVNode("td", null, "A content area for displaying text and other inline elements")
], -1);
const _hoisted_15 = { id: "guide" };
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn"),
  /* @__PURE__ */ createTextVNode(" component is commonly used throughout Vuetify and is a staple for any application. It is used for everything from navigation to form submission; and can be styled in a multitude of ways.")
], -1);
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The following code snippet is an example of a basic "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn"),
  /* @__PURE__ */ createTextVNode(" component only containing text:")
], -1);
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-html" }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-btn")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("Button"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("v-btn")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_19 = { id: "props" };
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("A wide array of props can be employed to modify the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn"),
  /* @__PURE__ */ createTextVNode(" component’s look and functionality. Props like "),
  /* @__PURE__ */ createBaseVNode("strong", null, "prepend-icon"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "append-icon"),
  /* @__PURE__ */ createTextVNode(" offer a straightforward approach to incorporate positioned icons, whereas "),
  /* @__PURE__ */ createBaseVNode("strong", null, "block"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "stacked"),
  /* @__PURE__ */ createTextVNode(" props are utilized to manage the component’s form.")
], -1);
const _hoisted_21 = { id: "density" };
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "density"),
  /* @__PURE__ */ createTextVNode(" prop is used to control the vertical space that the button takes up.")
], -1);
const _hoisted_23 = { id: "size" };
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "size"),
  /* @__PURE__ */ createTextVNode(" property is used to control the size of the button and scales with density. The default size is "),
  /* @__PURE__ */ createBaseVNode("strong", null, "undefined"),
  /* @__PURE__ */ createTextVNode(" which essentially translates to "),
  /* @__PURE__ */ createBaseVNode("strong", null, "medium"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_25 = { id: "block" };
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("p", null, "Block buttons extend the full available width of their container. This is useful for creating buttons that span the full width of a card or dialog.", -1);
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Block applies "),
  /* @__PURE__ */ createBaseVNode("strong", null, "width: 100%"),
  /* @__PURE__ */ createTextVNode(" which can cause overflow issues inside a flex container.")
], -1);
const _hoisted_28 = { id: "rounded" };
const _hoisted_29 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Use the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "rounded"),
  /* @__PURE__ */ createTextVNode(" prop to control the border radius of a button.")
], -1);
const _hoisted_30 = { id: "elevation" };
const _hoisted_31 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "elevation"),
  /* @__PURE__ */ createTextVNode(" property provides up to 24 levels of shadow depth. By default, buttons rest at 2dp.")
], -1);
const _hoisted_32 = { id: "ripple" };
const _hoisted_33 = /* @__PURE__ */ createBaseVNode("strong", null, "ripple", -1);
const _hoisted_34 = { id: "variants" };
const _hoisted_35 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "variant"),
  /* @__PURE__ */ createTextVNode(" prop gives you easy access to several different button styles. Available variants are: "),
  /* @__PURE__ */ createBaseVNode("strong", null, "elevated"),
  /* @__PURE__ */ createTextVNode("(default), "),
  /* @__PURE__ */ createBaseVNode("strong", null, "flat"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "tonal"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "outlined"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "text"),
  /* @__PURE__ */ createTextVNode(", and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "plain"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_36 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Value"),
    /* @__PURE__ */ createBaseVNode("th", null, "Example"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_37 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "elevated")
], -1);
const _hoisted_38 = /* @__PURE__ */ createBaseVNode("td", null, "Elevates the button with a shadow", -1);
const _hoisted_39 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "flat")
], -1);
const _hoisted_40 = /* @__PURE__ */ createBaseVNode("td", null, "Removes button shadow", -1);
const _hoisted_41 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "tonal")
], -1);
const _hoisted_42 = /* @__PURE__ */ createBaseVNode("td", null, "Background color is a lowered opacity of the current text color", -1);
const _hoisted_43 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "outlined")
], -1);
const _hoisted_44 = /* @__PURE__ */ createBaseVNode("td", null, "Applies a thin border with the current text color", -1);
const _hoisted_45 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "text")
], -1);
const _hoisted_46 = /* @__PURE__ */ createBaseVNode("td", null, "Removes the background and removes shadow", -1);
const _hoisted_47 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "plain")
], -1);
const _hoisted_48 = /* @__PURE__ */ createBaseVNode("td", null, "Removes the background and lowers the opacity until hovered", -1);
const _hoisted_49 = { id: "icon" };
const _hoisted_50 = { id: "loaders" };
const _hoisted_51 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Using the loading prop, you can notify a user that there is processing taking place. The default behavior is to use a "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-progress-circular"),
  /* @__PURE__ */ createTextVNode(" component but this can be customized with the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "loader"),
  /* @__PURE__ */ createTextVNode(" slot.")
], -1);
const _hoisted_52 = { id: "inside-of-bars" };
const _hoisted_53 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn", -1);
const _hoisted_54 = /* @__PURE__ */ createBaseVNode("strong", null, "icon", -1);
const _hoisted_55 = { id: "slots" };
const _hoisted_56 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn"),
  /* @__PURE__ */ createTextVNode(" component provides slots that enable you to customize content created by its props or to add additional content.")
], -1);
const _hoisted_57 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Slot"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_58 = /* @__PURE__ */ createBaseVNode("tbody", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "1. Default"),
    /* @__PURE__ */ createBaseVNode("td", null, "The default slot")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "2. Prepend"),
    /* @__PURE__ */ createBaseVNode("td", null, "Content area before the default slot")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "3. Append"),
    /* @__PURE__ */ createBaseVNode("td", null, "Content area after the default slot")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "4. Loader"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("Content area shown when "),
      /* @__PURE__ */ createBaseVNode("strong", null, "loading"),
      /* @__PURE__ */ createTextVNode(" is set to "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "true")
    ])
  ])
], -1);
const _hoisted_59 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Slots give you greater control to customize the content of the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn"),
  /* @__PURE__ */ createTextVNode(" component while still taking advantage of the easy-to-use props.")
], -1);
const _hoisted_60 = { id: "icon-color" };
const _hoisted_61 = /* @__PURE__ */ createBaseVNode("strong", null, "prepend-icon", -1);
const _hoisted_62 = /* @__PURE__ */ createBaseVNode("strong", null, "append-icon", -1);
const _hoisted_63 = /* @__PURE__ */ createBaseVNode("strong", null, "prepend", -1);
const _hoisted_64 = /* @__PURE__ */ createBaseVNode("strong", null, "append", -1);
const _hoisted_65 = { id: "custom-loader" };
const _hoisted_66 = /* @__PURE__ */ createBaseVNode("strong", null, "loader", -1);
const _hoisted_67 = { id: "examples" };
const _hoisted_68 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The following are a collection of examples that demonstrate more advanced and real world use of the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn"),
  /* @__PURE__ */ createTextVNode(" component.")
], -1);
const _hoisted_69 = { id: "discord-event" };
const _hoisted_70 = /* @__PURE__ */ createBaseVNode("p", null, "In this example we utilize multiple different button variants and styles to create a copy of the Discord event card.", -1);
const _hoisted_71 = { id: "survey-group" };
const _hoisted_72 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn", -1);
const _hoisted_73 = /* @__PURE__ */ createBaseVNode("strong", null, "active", -1);
const _hoisted_74 = { id: "tax-form-confirmation" };
const _hoisted_75 = /* @__PURE__ */ createBaseVNode("strong", null, "loading", -1);
const _hoisted_76 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn", -1);
const _hoisted_77 = { id: "dialog-action" };
const _hoisted_78 = /* @__PURE__ */ createBaseVNode("strong", null, "outlined", -1);
const _hoisted_79 = /* @__PURE__ */ createBaseVNode("strong", null, "color", -1);
const _hoisted_80 = { id: "cookie-settings" };
const _hoisted_81 = { id: "readonly-buttons" };
const _hoisted_82 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("In this example, we change the properties of the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn"),
  /* @__PURE__ */ createTextVNode(" based upon a “subscription” state. When the user is subscribed, we want to disable interaction with the button, but not change its appearance; which is what occurs when using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "disabled"),
  /* @__PURE__ */ createTextVNode(" property.")
], -1);
const _hoisted_83 = { id: "global-configuration" };
const _hoisted_84 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn", -1);
const _hoisted_85 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-js" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/plugins/vuetify.js",
    class: "language-js"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" createVuetify "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetifyjs'"),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "export"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "default"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "createVuetify"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "defaults"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "VBtn"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "color"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'primary'"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "variant"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'outlined'"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "rounded"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "true"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_86 = { id: "aliasing" };
const _hoisted_87 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-js" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/plugins/vuetify.js",
    class: "language-js"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" createVuetify "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetifyjs'"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" VBtn "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetifyjs/components'"),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "export"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "createVuetify"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "aliases"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "VBtnSecondary"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(" VBtn"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "VBtnTertiary"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(" VBtn"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "defaults"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "VBtn"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "color"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'primary'"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "variant"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'text'"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "VBtnSecondary"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "color"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'secondary'"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "variant"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'flat'"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "VBtnTertiary"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "rounded"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "true"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "variant"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'plain'"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_88 = { id: "sass-variables" };
const _hoisted_89 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn", -1);
const _hoisted_90 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-scss" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/settings.scss",
    class: "language-scss"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "@use"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify/settings'"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token module-modifier keyword" }, "with"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token variable" }, "$button-banner-actions-padding")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(" 16px"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token variable" }, "$button-height")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(" 32px"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ";"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_91 = /* @__PURE__ */ createBaseVNode("strong", null, "height", -1);
const _hoisted_92 = { id: "defaults-side-effects" };
const _hoisted_93 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("There are instances where a set of default properties are injected or custom styling is applied to the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn"),
  /* @__PURE__ */ createTextVNode(". This can be for a variety of reasons, but the most common are:")
], -1);
const _hoisted_94 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, "to match a design specification"),
  /* @__PURE__ */ createBaseVNode("li", null, "to provide a better visual appearance based upon context"),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("to avoid creating proprietary components; e.g. "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-bottom-navigation-btn"),
    /* @__PURE__ */ createTextVNode(" and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-card-btn")
  ])
], -1);
const _hoisted_95 = { id: "banners" };
const _hoisted_96 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-banner-actions"),
  /* @__PURE__ */ createTextVNode(" component applies the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "text"),
  /* @__PURE__ */ createTextVNode(" variant and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "slim"),
  /* @__PURE__ */ createTextVNode(" prop, reducing button x-axis padding to "),
  /* @__PURE__ */ createBaseVNode("strong", null, "8px"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_97 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Documentation"),
    /* @__PURE__ */ createBaseVNode("th", null, "API")
  ])
], -1);
const _hoisted_98 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The following properties are modified when used within a "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-banner-actions"),
  /* @__PURE__ */ createTextVNode(" component:")
], -1);
const _hoisted_99 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Property"),
    /* @__PURE__ */ createBaseVNode("th", null, "Value")
  ])
], -1);
const _hoisted_100 = /* @__PURE__ */ createBaseVNode("tbody", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "color")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("provided by "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-banner-actions")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "density")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("provided by "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-banner-actions")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "slim")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "true")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "variant")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "text")
    ])
  ])
], -1);
const _hoisted_101 = { id: "bottom-navigation" };
const _hoisted_102 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-bottom-navigation", -1);
const _hoisted_103 = /* @__PURE__ */ createBaseVNode("strong", null, "scopes", -1);
const _hoisted_104 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn", -1);
const _hoisted_105 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-bottom-navigation", -1);
const _hoisted_106 = /* @__PURE__ */ createBaseVNode("strong", null, "model", -1);
const _hoisted_107 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Documentation"),
    /* @__PURE__ */ createBaseVNode("th", null, "API")
  ])
], -1);
const _hoisted_108 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The following properties are modified when used within a "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-bottom-navigation"),
  /* @__PURE__ */ createTextVNode(" component:")
], -1);
const _hoisted_109 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Property"),
    /* @__PURE__ */ createBaseVNode("th", null, "Value")
  ])
], -1);
const _hoisted_110 = /* @__PURE__ */ createBaseVNode("tbody", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "color")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("provided by "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-bottom-navigation")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "density")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("provided by "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-bottom-navigation")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "stacked")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "true"),
      /* @__PURE__ */ createTextVNode(" when "),
      /* @__PURE__ */ createBaseVNode("strong", null, "mode"),
      /* @__PURE__ */ createTextVNode(" is "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "shift")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "variant")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "text")
    ])
  ])
], -1);
const _hoisted_111 = { id: "button-groups" };
const _hoisted_112 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn-group"),
  /* @__PURE__ */ createTextVNode(" component makes multiple changes to the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn"),
  /* @__PURE__ */ createTextVNode(" component.")
], -1);
const _hoisted_113 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Documentation"),
    /* @__PURE__ */ createBaseVNode("th", null, "API")
  ])
], -1);
const _hoisted_114 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The following properties are modified when used within a "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn-group"),
  /* @__PURE__ */ createTextVNode(" component:")
], -1);
const _hoisted_115 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Property"),
    /* @__PURE__ */ createBaseVNode("th", null, "Value")
  ])
], -1);
const _hoisted_116 = /* @__PURE__ */ createBaseVNode("tbody", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "color")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("provided by "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn-group")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "height")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "auto")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "density")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("provided by "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn-group")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "flat")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "true")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "variant")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("provided by "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn-group")
    ])
  ])
], -1);
const _hoisted_117 = { id: "cards" };
const _hoisted_118 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-card-actions"),
  /* @__PURE__ */ createTextVNode(" component applies the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "text"),
  /* @__PURE__ */ createTextVNode(" variant and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "slim"),
  /* @__PURE__ */ createTextVNode(" prop, reducing button x-axis padding to "),
  /* @__PURE__ */ createBaseVNode("strong", null, "8px"),
  /* @__PURE__ */ createTextVNode(", and applies a start margin for all siblings. This is to ensure the text from the button lines up with the text and title of the card and that there is space between its actions.")
], -1);
const _hoisted_119 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Documentation"),
    /* @__PURE__ */ createBaseVNode("th", null, "API")
  ])
], -1);
const _hoisted_120 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The following properties are modified when used within a "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-card-actions"),
  /* @__PURE__ */ createTextVNode(" component:")
], -1);
const _hoisted_121 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Property"),
    /* @__PURE__ */ createBaseVNode("th", null, "Value")
  ])
], -1);
const _hoisted_122 = /* @__PURE__ */ createBaseVNode("tbody", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "slim")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "true")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "variant")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "text")
    ])
  ])
], -1);
const _hoisted_123 = { id: "snackbars" };
const _hoisted_124 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-snackbar"),
  /* @__PURE__ */ createTextVNode(" component applies the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "text"),
  /* @__PURE__ */ createTextVNode(" variant, "),
  /* @__PURE__ */ createBaseVNode("strong", null, "slim"),
  /* @__PURE__ */ createTextVNode(" prop, and removes ripples from all "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn"),
  /* @__PURE__ */ createTextVNode(" components.")
], -1);
const _hoisted_125 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Documentation"),
    /* @__PURE__ */ createBaseVNode("th", null, "API")
  ])
], -1);
const _hoisted_126 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The following properties are modified when used within the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "actions"),
  /* @__PURE__ */ createTextVNode(" slot of the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-snackbar"),
  /* @__PURE__ */ createTextVNode(" component:")
], -1);
const _hoisted_127 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Property"),
    /* @__PURE__ */ createBaseVNode("th", null, "Value")
  ])
], -1);
const _hoisted_128 = /* @__PURE__ */ createBaseVNode("tbody", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "slim")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "true")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "ripple")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "false")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "variant")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "text")
    ])
  ])
], -1);
const _hoisted_129 = { id: "toolbars-and-appbars" };
const _hoisted_130 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-toolbar", -1);
const _hoisted_131 = /* @__PURE__ */ createBaseVNode("strong", null, "text", -1);
const _hoisted_132 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn", -1);
const _hoisted_133 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Documentation"),
    /* @__PURE__ */ createBaseVNode("th", null, "API")
  ])
], -1);
const _hoisted_134 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-toolbar", -1);
const _hoisted_135 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-js" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/plugins/vuetify.js",
    class: "language-js"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "export"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "default"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "createVuetify"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "defaults"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "VToolbar"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "VBtn"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "variant"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'flat'"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_136 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The following properties are modified when used within a "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-toolbar"),
  /* @__PURE__ */ createTextVNode(" or "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-toolbar-items"),
  /* @__PURE__ */ createTextVNode(" component:")
], -1);
const _hoisted_137 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Property"),
    /* @__PURE__ */ createBaseVNode("th", null, "Value")
  ])
], -1);
const _hoisted_138 = /* @__PURE__ */ createBaseVNode("tbody", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "height")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("provided by "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-toolbar-items")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "variant")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "text")
    ])
  ])
], -1);
const _hoisted_139 = { id: "accessibility" };
const _hoisted_140 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn"),
  /* @__PURE__ */ createTextVNode(" component is an extension of the native "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "button"),
  /* @__PURE__ */ createTextVNode(" element and supports all of the same accessibility features.")
], -1);
const _hoisted_141 = { id: "aria-attributes" };
const _hoisted_142 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn", -1);
const _hoisted_143 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, 'type="button"', -1);
const _hoisted_144 = { id: "keyboard-navigation" };
const _hoisted_145 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn", -1);
const _hoisted_146 = { id: "accessible-labels" };
const _hoisted_147 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn", -1);
const _hoisted_148 = /* @__PURE__ */ createBaseVNode("strong", null, "icon", -1);
const _hoisted_149 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "aria-label", -1);
const _hoisted_150 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-html" }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-btn")
      ]),
      /* @__PURE__ */ createTextVNode("\n  "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "aria-label"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("Refresh"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createTextVNode("\n  "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "icon"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("mdi-refresh"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createTextVNode("\n"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("v-btn")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_151 = { id: "touch-target-size" };
const _hoisted_152 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Make sure your buttons have an adequate touch target size, especially on touch devices. A larger touch target can improve the usability of your buttons for users with motor impairments or those using small screens. You can use "),
  /* @__PURE__ */ createBaseVNode("strong", null, "large"),
  /* @__PURE__ */ createTextVNode(" or "),
  /* @__PURE__ */ createBaseVNode("strong", null, "x-large"),
  /* @__PURE__ */ createTextVNode(" values for the size prop to increase the button size:")
], -1);
const _hoisted_153 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-html" }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-btn")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "size"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("large"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n  Large Button\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("v-btn")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-btn")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "size"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("x-large"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n  Extra Large Button\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("v-btn")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const frontmatter = { "meta": { "nav": "Buttons", "title": "Button component", "description": "The button component communicates actions that a user can take and are typically placed in dialogs, forms, cards and toolbars.", "keywords": "buttons, vuetify button component, vue button component" }, "related": ["/components/button-groups/", "/components/icons/", "/components/cards/"], "features": { "figma": true, "github": "/components/VBtn/", "label": "C: VBtn", "report": true, "spec": "https://m2.material.io/components/buttons" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "buttons",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Buttons", "title": "Button component", "description": "The button component communicates actions that a user can take and are typically placed in dialogs, forms, cards and toolbars.", "keywords": "buttons, vuetify button component, vue button component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Buttons", "title": "Button component", "description": "The button component communicates actions that a user can take and are typically placed in dialogs, forms, cards and toolbars.", "keywords": "buttons, vuetify button component, vue button component" }, "related": ["/components/button-groups/", "/components/icons/", "/components/cards/"], "features": { "figma": true, "github": "/components/VBtn/", "label": "C: VBtn", "report": true, "spec": "https://m2.material.io/components/buttons" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_app_figure = resolveComponent("app-figure");
      const _component_page_features = resolveComponent("page-features");
      const _component_vo_promotions_card_vuetify = resolveComponent("vo-promotions-card-vuetify");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_app_markup = resolveComponent("app-markup");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_alert = resolveComponent("alert");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_kbd = resolveComponent("v-kbd");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#buttons",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Buttons")
                ]),
                _: 1
              }),
              _hoisted_2,
              createBaseVNode("p", null, [
                createBaseVNode("div", null, [
                  createVNode(_component_app_figure, {
                    alt: "Button Entry",
                    src: "https://cdn.vuetifyjs.com/docs/images/components/v-btn/v-btn-entry.png"
                  })
                ])
              ]),
              createVNode(_component_page_features),
              createVNode(_component_vo_promotions_card_vuetify),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_usage, { name: "v-btn" })
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_6,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-btn/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-btn")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_8, [
                createVNode(_component_app_heading, {
                  href: "#anatomy",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Anatomy")
                  ]),
                  _: 1
                }),
                _hoisted_9,
                _hoisted_10,
                createBaseVNode("p", null, [
                  createBaseVNode("div", null, [
                    createVNode(_component_app_figure, {
                      alt: "Button Anatomy",
                      src: "https://cdn.vuetifyjs.com/docs/images/components/v-btn/v-btn-anatomy.png"
                    })
                  ])
                ]),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_11,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        _hoisted_12,
                        createBaseVNode("td", null, [
                          createTextVNode("In addition to text, the Button container typically holds a "),
                          createVNode(_component_app_link, { href: "/components/icons/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-icon")
                            ]),
                            _: 1
                          }),
                          createTextVNode(" component")
                        ])
                      ]),
                      _hoisted_13,
                      _hoisted_14
                    ])
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_15, [
                createVNode(_component_app_heading, {
                  href: "#guide",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Guide")
                  ]),
                  _: 1
                }),
                _hoisted_16,
                _hoisted_17,
                createVNode(_component_app_markup, {
                  resource: "",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_18
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_19, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  _hoisted_20,
                  createBaseVNode("section", _hoisted_21, [
                    createVNode(_component_app_heading, {
                      href: "#density",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Density")
                      ]),
                      _: 1
                    }),
                    _hoisted_22,
                    createVNode(_component_examples_example, { file: "v-btn/prop-density" })
                  ]),
                  createBaseVNode("section", _hoisted_23, [
                    createVNode(_component_app_heading, {
                      href: "#size",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Size")
                      ]),
                      _: 1
                    }),
                    _hoisted_24,
                    createVNode(_component_examples_example, { file: "v-btn/prop-size" })
                  ]),
                  createBaseVNode("section", _hoisted_25, [
                    createVNode(_component_app_heading, {
                      href: "#block",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Block")
                      ]),
                      _: 1
                    }),
                    _hoisted_26,
                    createVNode(_component_examples_example, { file: "v-btn/prop-block" }),
                    createVNode(_component_alert, { type: "info" }, {
                      default: withCtx(() => [
                        _hoisted_27
                      ]),
                      _: 1
                    })
                  ]),
                  createBaseVNode("section", _hoisted_28, [
                    createVNode(_component_app_heading, {
                      href: "#rounded",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Rounded")
                      ]),
                      _: 1
                    }),
                    _hoisted_29,
                    createVNode(_component_examples_example, { file: "v-btn/prop-rounded" })
                  ]),
                  createBaseVNode("section", _hoisted_30, [
                    createVNode(_component_app_heading, {
                      href: "#elevation",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Elevation")
                      ]),
                      _: 1
                    }),
                    _hoisted_31,
                    createVNode(_component_examples_example, { file: "v-btn/prop-elevation" })
                  ]),
                  createBaseVNode("section", _hoisted_32, [
                    createVNode(_component_app_heading, {
                      href: "#ripple",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Ripple")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("The "),
                      _hoisted_33,
                      createTextVNode(" property determines whether the "),
                      createVNode(_component_app_link, { href: "/directives/ripple/" }, {
                        default: withCtx(() => [
                          createTextVNode("v-ripple")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" directive is used.")
                    ]),
                    createVNode(_component_examples_example, { file: "v-btn/prop-ripple" })
                  ]),
                  createBaseVNode("section", _hoisted_34, [
                    createVNode(_component_app_heading, {
                      href: "#variants",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Variants")
                      ]),
                      _: 1
                    }),
                    _hoisted_35,
                    createVNode(_component_app_table, null, {
                      default: withCtx(() => [
                        _hoisted_36,
                        createBaseVNode("tbody", null, [
                          createBaseVNode("tr", null, [
                            _hoisted_37,
                            createBaseVNode("td", null, [
                              createVNode(_component_v_btn, {
                                color: "primary",
                                variant: "elevated"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("Button")
                                ]),
                                _: 1
                              })
                            ]),
                            _hoisted_38
                          ]),
                          createBaseVNode("tr", null, [
                            _hoisted_39,
                            createBaseVNode("td", null, [
                              createVNode(_component_v_btn, {
                                color: "primary",
                                variant: "flat"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("Button")
                                ]),
                                _: 1
                              })
                            ]),
                            _hoisted_40
                          ]),
                          createBaseVNode("tr", null, [
                            _hoisted_41,
                            createBaseVNode("td", null, [
                              createVNode(_component_v_btn, {
                                color: "primary",
                                variant: "tonal"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("Button")
                                ]),
                                _: 1
                              })
                            ]),
                            _hoisted_42
                          ]),
                          createBaseVNode("tr", null, [
                            _hoisted_43,
                            createBaseVNode("td", null, [
                              createVNode(_component_v_btn, {
                                color: "primary",
                                variant: "outlined"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("Button")
                                ]),
                                _: 1
                              })
                            ]),
                            _hoisted_44
                          ]),
                          createBaseVNode("tr", null, [
                            _hoisted_45,
                            createBaseVNode("td", null, [
                              createVNode(_component_v_btn, {
                                color: "primary",
                                variant: "text"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("Button")
                                ]),
                                _: 1
                              })
                            ]),
                            _hoisted_46
                          ]),
                          createBaseVNode("tr", null, [
                            _hoisted_47,
                            createBaseVNode("td", null, [
                              createVNode(_component_v_btn, {
                                color: "primary",
                                variant: "plain"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("Button")
                                ]),
                                _: 1
                              })
                            ]),
                            _hoisted_48
                          ])
                        ])
                      ]),
                      _: 1
                    })
                  ]),
                  createBaseVNode("section", _hoisted_49, [
                    createVNode(_component_app_heading, {
                      href: "#icon",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Icon")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("Icons can be used for the primary content of a button. They are commonly used in the "),
                      createVNode(_component_app_link, { href: "/components/toolbars/" }, {
                        default: withCtx(() => [
                          createTextVNode("v-toolbar")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" and "),
                      createVNode(_component_app_link, { href: "/components/app-bars/" }, {
                        default: withCtx(() => [
                          createTextVNode("v-app-bar")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" components.")
                    ]),
                    createVNode(_component_examples_example, { file: "v-btn/prop-icon" })
                  ]),
                  createBaseVNode("section", _hoisted_50, [
                    createVNode(_component_app_heading, {
                      href: "#loaders",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Loaders")
                      ]),
                      _: 1
                    }),
                    _hoisted_51,
                    createVNode(_component_examples_example, { file: "v-btn/prop-loaders" })
                  ]),
                  createBaseVNode("section", _hoisted_52, [
                    createVNode(_component_app_heading, {
                      href: "#inside-of-bars",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Inside of bars")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("A common use-case is to use the "),
                      _hoisted_53,
                      createTextVNode(" with the "),
                      _hoisted_54,
                      createTextVNode(" property within a "),
                      createVNode(_component_app_link, { href: "/components/toolbars/" }, {
                        default: withCtx(() => [
                          createTextVNode("v-toolbar")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" or "),
                      createVNode(_component_app_link, { href: "/components/app-bars/" }, {
                        default: withCtx(() => [
                          createTextVNode("v-app-bar")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" component.")
                    ]),
                    createVNode(_component_examples_example, { file: "v-btn/misc-toolbar" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_55, [
                  createVNode(_component_app_heading, {
                    href: "#slots",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Slots")
                    ]),
                    _: 1
                  }),
                  _hoisted_56,
                  createBaseVNode("p", null, [
                    createBaseVNode("div", null, [
                      createVNode(_component_app_figure, {
                        alt: "Button Anatomy",
                        src: "https://cdn.vuetifyjs.com/docs/images/components/v-btn/v-btn-slots.png"
                      })
                    ])
                  ]),
                  createVNode(_component_app_table, null, {
                    default: withCtx(() => [
                      _hoisted_57,
                      _hoisted_58
                    ]),
                    _: 1
                  }),
                  _hoisted_59,
                  createBaseVNode("section", _hoisted_60, [
                    createVNode(_component_app_heading, {
                      href: "#icon-color",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Icon color")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("When you use the "),
                      _hoisted_61,
                      createTextVNode(" and "),
                      _hoisted_62,
                      createTextVNode(" props in conjunction with the corresponding slot, "),
                      _hoisted_63,
                      createTextVNode(" or "),
                      _hoisted_64,
                      createTextVNode(", you are able to place a "),
                      createVNode(_component_app_link, { href: "/components/icons/" }, {
                        default: withCtx(() => [
                          createTextVNode("v-icon")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" that automatically injects the designated icon.")
                    ]),
                    createVNode(_component_examples_example, { file: "v-btn/slot-prepend-append" })
                  ]),
                  createBaseVNode("section", _hoisted_65, [
                    createVNode(_component_app_heading, {
                      href: "#custom-loader",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Custom loader")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("The "),
                      _hoisted_66,
                      createTextVNode(" slot allows you to customize the loading indicator. In this example we use a "),
                      createVNode(_component_app_link, { href: "/components/progress-linear/" }, {
                        default: withCtx(() => [
                          createTextVNode("v-progress-linear")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" component to create a loading bar that spans the full width of the button.")
                    ]),
                    createVNode(_component_examples_example, { file: "v-btn/slot-loader" }),
                    createVNode(_component_vo_promotions_card_vuetify)
                  ])
                ])
              ]),
              createBaseVNode("section", _hoisted_67, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                _hoisted_68,
                createBaseVNode("section", _hoisted_69, [
                  createVNode(_component_app_heading, {
                    href: "#discord-event",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Discord event")
                    ]),
                    _: 1
                  }),
                  _hoisted_70,
                  createVNode(_component_examples_example, {
                    file: "v-btn/misc-discord-event",
                    "hide-invert": ""
                  })
                ]),
                createBaseVNode("section", _hoisted_71, [
                  createVNode(_component_app_heading, {
                    href: "#survey-group",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Survey group")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("p", null, [
                    createTextVNode("In addition to "),
                    createVNode(_component_app_link, { href: "/components/button-groups/" }, {
                      default: withCtx(() => [
                        createTextVNode("Button groups")
                      ]),
                      _: 1
                    }),
                    createTextVNode(", the "),
                    _hoisted_72,
                    createTextVNode(" component cant hook into a "),
                    createVNode(_component_app_link, { href: "/components/item-groups/" }, {
                      default: withCtx(() => [
                        createTextVNode("v-item-group")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" using a special symbol. In the next example we create a group of buttons that are used to select a survey answer and add custom "),
                    _hoisted_73,
                    createTextVNode(" state styling.")
                  ]),
                  createVNode(_component_examples_example, {
                    file: "v-btn/misc-group-survey",
                    "hide-invert": ""
                  })
                ]),
                createBaseVNode("section", _hoisted_74, [
                  createVNode(_component_app_heading, {
                    href: "#tax-form-confirmation",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Tax form confirmation")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("p", null, [
                    createTextVNode("This example utilizes the "),
                    createVNode(_component_app_link, { href: "/components/text-fields/" }, {
                      default: withCtx(() => [
                        createTextVNode("v-text-field")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" component to collect data from the user and the "),
                    _hoisted_75,
                    createTextVNode(" prop of "),
                    _hoisted_76,
                    createTextVNode(" when submitting the form.")
                  ]),
                  createVNode(_component_examples_example, { file: "v-btn/misc-tax-form" })
                ]),
                createBaseVNode("section", _hoisted_77, [
                  createVNode(_component_app_heading, {
                    href: "#dialog-action",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Dialog action")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("p", null, [
                    createTextVNode("Buttons are often used to trigger actions within a "),
                    createVNode(_component_app_link, { href: "/components/dialogs/" }, {
                      default: withCtx(() => [
                        createTextVNode("v-dialog")
                      ]),
                      _: 1
                    }),
                    createTextVNode(". In this example we use the "),
                    _hoisted_78,
                    createTextVNode(" variant and the "),
                    _hoisted_79,
                    createTextVNode(" prop to create a button that is visually distinct from the other buttons.")
                  ]),
                  createVNode(_component_examples_example, { file: "v-btn/misc-dialog-action" })
                ]),
                createBaseVNode("section", _hoisted_80, [
                  createVNode(_component_app_heading, {
                    href: "#cookie-settings",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Cookie settings")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("p", null, [
                    createTextVNode("In this example we use a "),
                    createVNode(_component_app_link, { href: "/components/banners/" }, {
                      default: withCtx(() => [
                        createTextVNode("v-banner")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" component to display a custom cookie consent banner. Clicking the “Manage Cookies” button will prompt a "),
                    createVNode(_component_app_link, { href: "/components/dialogs/" }, {
                      default: withCtx(() => [
                        createTextVNode("v-dialog")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" component.")
                  ]),
                  createVNode(_component_examples_example, { file: "v-btn/misc-cookie-settings" })
                ]),
                createBaseVNode("section", _hoisted_81, [
                  createVNode(_component_app_heading, {
                    href: "#readonly-buttons",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Readonly buttons")
                    ]),
                    _: 1
                  }),
                  _hoisted_82,
                  createVNode(_component_examples_example, { file: "v-btn/misc-readonly" })
                ])
              ]),
              createBaseVNode("section", _hoisted_83, [
                createVNode(_component_app_heading, {
                  href: "#global-configuration",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Global Configuration")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("Modify the default values and set a default style for all "),
                  _hoisted_84,
                  createTextVNode(" components using the "),
                  createVNode(_component_app_link, { href: "/features/global-configuration/" }, {
                    default: withCtx(() => [
                      createTextVNode("Global configuration")
                    ]),
                    _: 1
                  }),
                  createTextVNode(". This helps keep your application consistent and allows you to change it in the future with minimal effort.")
                ]),
                createVNode(_component_app_markup, {
                  resource: "src/plugins/vuetify.js",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_85
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_86, [
                createVNode(_component_app_heading, {
                  href: "#aliasing",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Aliasing")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("Utilize the "),
                  createVNode(_component_app_link, { href: "/features/aliasing/" }, {
                    default: withCtx(() => [
                      createTextVNode("component aliasing")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" feature to generate virtual components derived from the v-btn component. This proves valuable when dealing with numerous button variations within design specifications or when developing a custom library based on Vuetify.")
                ]),
                createVNode(_component_app_markup, {
                  resource: "src/plugins/vuetify.js",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_87
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_88, [
                createVNode(_component_app_heading, {
                  href: "#sass-variables",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("SASS Variables")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("Make fine tuned changes by modifying the "),
                  _hoisted_89,
                  createTextVNode(),
                  createVNode(_component_app_link, { href: "/features/sass-variables" }, {
                    default: withCtx(() => [
                      createTextVNode("SASS variables")
                    ]),
                    _: 1
                  }),
                  createTextVNode(". This is useful when you want to change the default button height or padding.")
                ]),
                createVNode(_component_app_markup, {
                  resource: "src/settings.scss",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_90
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("Some of these values can be modified using the "),
                  createVNode(_component_app_link, { href: "/features/global-configuration/" }, {
                    default: withCtx(() => [
                      createTextVNode("Global configuration")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" as well and will take precedence over the SASS variables. For example, the "),
                  _hoisted_91,
                  createTextVNode(" prop can be used to change the default button height without modifying the SASS variables.")
                ])
              ]),
              createBaseVNode("section", _hoisted_92, [
                createVNode(_component_app_heading, {
                  href: "#defaults-side-effects",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Defaults Side Effects")
                  ]),
                  _: 1
                }),
                _hoisted_93,
                _hoisted_94,
                createBaseVNode("section", _hoisted_95, [
                  createVNode(_component_app_heading, {
                    href: "#banners",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Banners")
                    ]),
                    _: 1
                  }),
                  _hoisted_96,
                  createVNode(_component_app_table, null, {
                    default: withCtx(() => [
                      _hoisted_97,
                      createBaseVNode("tbody", null, [
                        createBaseVNode("tr", null, [
                          createBaseVNode("td", null, [
                            createVNode(_component_app_link, { href: "/components/banners/" }, {
                              default: withCtx(() => [
                                createTextVNode("Banners")
                              ]),
                              _: 1
                            })
                          ]),
                          createBaseVNode("td", null, [
                            createVNode(_component_app_link, { href: "/api/v-banner-actions/" }, {
                              default: withCtx(() => [
                                createTextVNode("v-banner-actions")
                              ]),
                              _: 1
                            })
                          ])
                        ])
                      ])
                    ]),
                    _: 1
                  }),
                  createVNode(_component_examples_example, { file: "v-btn/defaults-banner-actions" }),
                  _hoisted_98,
                  createVNode(_component_app_table, null, {
                    default: withCtx(() => [
                      _hoisted_99,
                      _hoisted_100
                    ]),
                    _: 1
                  })
                ]),
                createBaseVNode("section", _hoisted_101, [
                  createVNode(_component_app_heading, {
                    href: "#bottom-navigation",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Bottom navigation")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("p", null, [
                    createTextVNode("The "),
                    _hoisted_102,
                    createTextVNode(" component "),
                    _hoisted_103,
                    createTextVNode(" out all previously provided defaults and applies its own. This is to avoid changes made to "),
                    _hoisted_104,
                    createTextVNode(" in the "),
                    createVNode(_component_app_link, { href: "/features/global-configuration/" }, {
                      default: withCtx(() => [
                        createTextVNode("Global configuration")
                      ]),
                      _: 1
                    }),
                    createTextVNode(". Buttons automatically register with "),
                    _hoisted_105,
                    createTextVNode("’s’ group and will update the "),
                    _hoisted_106,
                    createTextVNode(" when clicked.")
                  ]),
                  createVNode(_component_app_table, null, {
                    default: withCtx(() => [
                      _hoisted_107,
                      createBaseVNode("tbody", null, [
                        createBaseVNode("tr", null, [
                          createBaseVNode("td", null, [
                            createVNode(_component_app_link, { href: "/components/bottom-navigation/" }, {
                              default: withCtx(() => [
                                createTextVNode("Bottom navigation")
                              ]),
                              _: 1
                            })
                          ]),
                          createBaseVNode("td", null, [
                            createVNode(_component_app_link, { href: "/api/v-bottom-navigation/" }, {
                              default: withCtx(() => [
                                createTextVNode("v-bottom-navigation")
                              ]),
                              _: 1
                            })
                          ])
                        ])
                      ])
                    ]),
                    _: 1
                  }),
                  createVNode(_component_examples_example, { file: "v-btn/defaults-bottom-navigation" }),
                  _hoisted_108,
                  createVNode(_component_app_table, null, {
                    default: withCtx(() => [
                      _hoisted_109,
                      _hoisted_110
                    ]),
                    _: 1
                  })
                ]),
                createBaseVNode("section", _hoisted_111, [
                  createVNode(_component_app_heading, {
                    href: "#button-groups",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Button groups")
                    ]),
                    _: 1
                  }),
                  _hoisted_112,
                  createVNode(_component_app_table, null, {
                    default: withCtx(() => [
                      _hoisted_113,
                      createBaseVNode("tbody", null, [
                        createBaseVNode("tr", null, [
                          createBaseVNode("td", null, [
                            createVNode(_component_app_link, { href: "/components/button-groups/" }, {
                              default: withCtx(() => [
                                createTextVNode("Button groups")
                              ]),
                              _: 1
                            })
                          ]),
                          createBaseVNode("td", null, [
                            createVNode(_component_app_link, { href: "/api/v-btn-group/" }, {
                              default: withCtx(() => [
                                createTextVNode("v-btn-group")
                              ]),
                              _: 1
                            })
                          ])
                        ])
                      ])
                    ]),
                    _: 1
                  }),
                  createVNode(_component_examples_example, { file: "v-btn/defaults-btn-group" }),
                  _hoisted_114,
                  createVNode(_component_app_table, null, {
                    default: withCtx(() => [
                      _hoisted_115,
                      _hoisted_116
                    ]),
                    _: 1
                  })
                ]),
                createBaseVNode("section", _hoisted_117, [
                  createVNode(_component_app_heading, {
                    href: "#cards",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Cards")
                    ]),
                    _: 1
                  }),
                  _hoisted_118,
                  createVNode(_component_app_table, null, {
                    default: withCtx(() => [
                      _hoisted_119,
                      createBaseVNode("tbody", null, [
                        createBaseVNode("tr", null, [
                          createBaseVNode("td", null, [
                            createVNode(_component_app_link, { href: "/components/cards/" }, {
                              default: withCtx(() => [
                                createTextVNode("Cards")
                              ]),
                              _: 1
                            })
                          ]),
                          createBaseVNode("td", null, [
                            createVNode(_component_app_link, { href: "/api/v-card-actions/" }, {
                              default: withCtx(() => [
                                createTextVNode("v-card-actions")
                              ]),
                              _: 1
                            })
                          ])
                        ])
                      ])
                    ]),
                    _: 1
                  }),
                  createVNode(_component_examples_example, { file: "v-btn/defaults-card-actions" }),
                  _hoisted_120,
                  createVNode(_component_app_table, null, {
                    default: withCtx(() => [
                      _hoisted_121,
                      _hoisted_122
                    ]),
                    _: 1
                  })
                ]),
                createBaseVNode("section", _hoisted_123, [
                  createVNode(_component_app_heading, {
                    href: "#snackbars",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Snackbars")
                    ]),
                    _: 1
                  }),
                  _hoisted_124,
                  createVNode(_component_app_table, null, {
                    default: withCtx(() => [
                      _hoisted_125,
                      createBaseVNode("tbody", null, [
                        createBaseVNode("tr", null, [
                          createBaseVNode("td", null, [
                            createVNode(_component_app_link, { href: "/components/snackbars/" }, {
                              default: withCtx(() => [
                                createTextVNode("Snackbars")
                              ]),
                              _: 1
                            })
                          ]),
                          createBaseVNode("td", null, [
                            createVNode(_component_app_link, { href: "/api/v-snackbar/" }, {
                              default: withCtx(() => [
                                createTextVNode("v-snackbar")
                              ]),
                              _: 1
                            })
                          ])
                        ])
                      ])
                    ]),
                    _: 1
                  }),
                  createVNode(_component_examples_example, { file: "v-btn/defaults-snackbar" }),
                  _hoisted_126,
                  createVNode(_component_app_table, null, {
                    default: withCtx(() => [
                      _hoisted_127,
                      _hoisted_128
                    ]),
                    _: 1
                  })
                ]),
                createBaseVNode("section", _hoisted_129, [
                  createVNode(_component_app_heading, {
                    href: "#toolbars-and-appbars",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Toolbars and AppBars")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("p", null, [
                    createTextVNode("The "),
                    _hoisted_130,
                    createTextVNode(" component applies the "),
                    _hoisted_131,
                    createTextVNode(" variant to all "),
                    _hoisted_132,
                    createTextVNode(" components. In addition, the "),
                    createVNode(_component_app_link, { href: "/api/v-toolbar-items/" }, {
                      default: withCtx(() => [
                        createTextVNode("v-toolbar-items")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" component is used to create a grouping of buttons that fill the height of the toolbar.")
                  ]),
                  createVNode(_component_app_table, null, {
                    default: withCtx(() => [
                      _hoisted_133,
                      createBaseVNode("tbody", null, [
                        createBaseVNode("tr", null, [
                          createBaseVNode("td", null, [
                            createVNode(_component_app_link, { href: "/components/toolbars/" }, {
                              default: withCtx(() => [
                                createTextVNode("Toolbars")
                              ]),
                              _: 1
                            })
                          ]),
                          createBaseVNode("td", null, [
                            createVNode(_component_app_link, { href: "/api/v-toolbar/" }, {
                              default: withCtx(() => [
                                createTextVNode("v-toolbar")
                              ]),
                              _: 1
                            })
                          ])
                        ])
                      ])
                    ]),
                    _: 1
                  }),
                  createVNode(_component_examples_example, { file: "v-btn/defaults-toolbar" }),
                  createVNode(_component_alert, { type: "info" }, {
                    default: withCtx(() => [
                      createBaseVNode("p", null, [
                        createTextVNode("The "),
                        createVNode(_component_app_link, { href: "/components/app-bars/" }, {
                          default: withCtx(() => [
                            createTextVNode("v-app-bar")
                          ]),
                          _: 1
                        }),
                        createTextVNode(" component uses "),
                        createVNode(_component_app_link, { href: "/components/toolbars/" }, {
                          default: withCtx(() => [
                            createTextVNode("v-toolbar")
                          ]),
                          _: 1
                        }),
                        createTextVNode(" internally. When applying global defaults, you must target the "),
                        _hoisted_134,
                        createTextVNode(" component.")
                      ])
                    ]),
                    _: 1
                  }),
                  createVNode(_component_app_markup, {
                    resource: "src/plugins/vuetify.js",
                    class: "mb-4"
                  }, {
                    default: withCtx(() => [
                      _hoisted_135
                    ]),
                    _: 1
                  }),
                  _hoisted_136,
                  createVNode(_component_app_table, null, {
                    default: withCtx(() => [
                      _hoisted_137,
                      _hoisted_138
                    ]),
                    _: 1
                  }),
                  createVNode(_component_vo_promotions_card_vuetify)
                ])
              ]),
              createBaseVNode("section", _hoisted_139, [
                createVNode(_component_app_heading, {
                  href: "#accessibility",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Accessibility")
                  ]),
                  _: 1
                }),
                _hoisted_140,
                createBaseVNode("section", _hoisted_141, [
                  createVNode(_component_app_heading, {
                    href: "#aria-attributes",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("ARIA Attributes")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("p", null, [
                    createTextVNode("By default, the "),
                    _hoisted_142,
                    createTextVNode(" component includes relevant "),
                    createVNode(_component_app_link, { href: "https://www.w3.org/WAI/standards-guidelines/aria/" }, {
                      default: withCtx(() => [
                        createTextVNode("WAI-ARIA")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" attributes to enhance accessibility. The component is automatically assigned the "),
                    _hoisted_143,
                    createTextVNode(" attribute, which indicates its purpose as a button to assistive technologies.")
                  ])
                ]),
                createBaseVNode("section", _hoisted_144, [
                  createVNode(_component_app_heading, {
                    href: "#keyboard-navigation",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Keyboard Navigation")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("p", null, [
                    createTextVNode("The "),
                    _hoisted_145,
                    createTextVNode(" component is natively focusable and responds to keyboard events, such as pressing the "),
                    createVNode(_component_v_kbd, null, {
                      default: withCtx(() => [
                        createTextVNode("Enter")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" or "),
                    createVNode(_component_v_kbd, null, {
                      default: withCtx(() => [
                        createTextVNode("Space")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" key to trigger the button’s action. This ensures that users can navigate and interact with your application using just the keyboard.")
                  ])
                ]),
                createBaseVNode("section", _hoisted_146, [
                  createVNode(_component_app_heading, {
                    href: "#accessible-labels",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Accessible Labels")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("p", null, [
                    createTextVNode("When using a "),
                    createVNode(_component_app_link, { href: "/components/icons/" }, {
                      default: withCtx(() => [
                        createTextVNode("v-icon")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" within the "),
                    _hoisted_147,
                    createTextVNode(" component (e.g., with the "),
                    _hoisted_148,
                    createTextVNode(" prop), it is essential to provide a text alternative for screen reader users. You can add an "),
                    _hoisted_149,
                    createTextVNode(" attribute with a descriptive label to ensure that the button’s purpose is clear to all users.")
                  ]),
                  createVNode(_component_app_markup, {
                    resource: "",
                    class: "mb-4"
                  }, {
                    default: withCtx(() => [
                      _hoisted_150
                    ]),
                    _: 1
                  })
                ]),
                createBaseVNode("section", _hoisted_151, [
                  createVNode(_component_app_heading, {
                    href: "#touch-target-size",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Touch Target Size")
                    ]),
                    _: 1
                  }),
                  _hoisted_152,
                  createVNode(_component_app_markup, {
                    resource: "",
                    class: "mb-4"
                  }, {
                    default: withCtx(() => [
                      _hoisted_153
                    ]),
                    _: 1
                  })
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
