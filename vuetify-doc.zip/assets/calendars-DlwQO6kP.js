import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "calendars" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-calendar"),
  /* @__PURE__ */ createTextVNode(" component is used to display information in a daily, weekly, monthly. The daily view has slots for all day or timed elements, and the weekly and monthly view has a slot for each day.")
], -1);
const _hoisted_3 = { id: "installation" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, "Labs components require a manual import and installation of the component.", -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-js" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/plugins/vuetify.js",
    class: "language-js"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" VCalendar "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify/labs/VCalendar'"),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "export"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "default"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "createVuetify"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "components"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n    VCalendar"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_6 = { id: "usage" };
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("A calendar has a type and a value which determines what type of calendar is shown over what span of time. This shows the bare minimum configuration, an array of events with "),
  /* @__PURE__ */ createBaseVNode("strong", null, "title"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "start"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "end"),
  /* @__PURE__ */ createTextVNode(" properties. "),
  /* @__PURE__ */ createBaseVNode("strong", null, "end"),
  /* @__PURE__ */ createTextVNode(" is optional, it defaults to the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "start"),
  /* @__PURE__ */ createTextVNode(". If the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "start"),
  /* @__PURE__ */ createTextVNode(" has a time it’s considered a timed event and will be shown accordingly in the day views. An event can span multiple days and will be rendered accordingly.")
], -1);
const _hoisted_8 = { id: "api" };
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_11 = { id: "guide" };
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-calendar"),
  /* @__PURE__ */ createTextVNode(" component in Vuetify offers a versatile solution for building various calendar interfaces. It’s designed to be highly customizable, catering to a wide range of applications from simple date pickers to complex event calendars.")
], -1);
const _hoisted_13 = { id: "props" };
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-calendar"),
  /* @__PURE__ */ createTextVNode(" component is equipped with a range of props that allow you to tailor its functionality and appearance to your specific requirements. This section will provide an overview of the available properties, offering insights into their usage and impact on the calendar’s behavior and presentation.")
], -1);
const _hoisted_15 = { id: "type-month" };
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("This is a calendar with the type of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "month")
], -1);
const _hoisted_17 = { id: "type-week" };
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("This is a calendar with the type of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "week")
], -1);
const _hoisted_19 = { id: "type-day" };
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("This is a calendar with the type of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "day")
], -1);
const frontmatter = { "emphasized": true, "meta": { "nav": "Calendars", "title": "Calendar component", "description": "The calendar component is a clean and simple adaptation to the popular Google Calendar application.", "keywords": "calendars, vuetify calendar component, vue calendar component" }, "related": ["/components/date-pickers/", "/features/dates/", "/components/cards/"], "features": { "github": "/labs/VCalendar/", "label": "C: VCalendar", "report": true } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "calendars",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Calendars", "title": "Calendar component", "description": "The calendar component is a clean and simple adaptation to the popular Google Calendar application.", "keywords": "calendars, vuetify calendar component, vue calendar component" } };
    useHead(head);
    __expose({ frontmatter: { "emphasized": true, "meta": { "nav": "Calendars", "title": "Calendar component", "description": "The calendar component is a clean and simple adaptation to the popular Google Calendar application.", "keywords": "calendars, vuetify calendar component, vue calendar component" }, "related": ["/components/date-pickers/", "/features/dates/", "/components/cards/"], "features": { "github": "/labs/VCalendar/", "label": "C: VCalendar", "report": true } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_app_link = resolveComponent("app-link");
      const _component_alert = resolveComponent("alert");
      const _component_app_markup = resolveComponent("app-markup");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#calendars",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Calendars")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_alert, { type: "warning" }, {
                default: withCtx(() => [
                  createBaseVNode("p", null, [
                    createTextVNode("This feature requires "),
                    createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v3.4.9" }, {
                      default: withCtx(() => [
                        createTextVNode("v3.4.9")
                      ]),
                      _: 1
                    })
                  ])
                ]),
                _: 1
              }),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#installation",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Installation")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_app_markup, {
                  resource: "src/plugins/vuetify.js",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_5
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_6, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_7,
                createVNode(_component_examples_example, { file: "v-calendar/usage" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_8, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_9,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-calendar/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-calendar")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_10
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_11, [
                createVNode(_component_app_heading, {
                  href: "#guide",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Guide")
                  ]),
                  _: 1
                }),
                _hoisted_12,
                createBaseVNode("section", _hoisted_13, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  _hoisted_14,
                  createBaseVNode("section", _hoisted_15, [
                    createVNode(_component_app_heading, {
                      href: "#type-month",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Type month")
                      ]),
                      _: 1
                    }),
                    _hoisted_16,
                    createVNode(_component_examples_example, { file: "v-calendar/prop-type-month" })
                  ]),
                  createBaseVNode("section", _hoisted_17, [
                    createVNode(_component_app_heading, {
                      href: "#type-week",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Type week")
                      ]),
                      _: 1
                    }),
                    _hoisted_18,
                    createVNode(_component_examples_example, { file: "v-calendar/prop-type-week" })
                  ]),
                  createBaseVNode("section", _hoisted_19, [
                    createVNode(_component_app_heading, {
                      href: "#type-day",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Type day")
                      ]),
                      _: 1
                    }),
                    _hoisted_20,
                    createVNode(_component_examples_example, { file: "v-calendar/prop-type-day" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
