import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "cards" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-card", -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-card"),
  /* @__PURE__ */ createTextVNode(" component is a stylish way to wrap different types of content; such as tables, images, or user actions.")
], -1);
const _hoisted_5 = { id: "api" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createTextVNode("Sub-component used to wrap the Card’s "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-card-title"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-card-subtitle"),
  /* @__PURE__ */ createTextVNode(" components.")
], -1);
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createTextVNode("Sub-component used to display the Card’s title. Wraps the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "#title"),
  /* @__PURE__ */ createTextVNode(" slot")
], -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createTextVNode("Sub-component used to display the Card’s subtitle. Wraps the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "#subtitle"),
  /* @__PURE__ */ createTextVNode(" slot.")
], -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createTextVNode("Sub-component used to display the Card’s text. Wraps the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "#text"),
  /* @__PURE__ */ createTextVNode(" slot.")
], -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "#actions", -1);
const _hoisted_13 = { id: "anatomy" };
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The recommended placement of elements inside of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-card"),
  /* @__PURE__ */ createTextVNode(" is:")
], -1);
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Place "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-card-title"),
    /* @__PURE__ */ createTextVNode(", "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-card-subtitle"),
    /* @__PURE__ */ createTextVNode(" or other title text on top")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Place "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-card-text"),
    /* @__PURE__ */ createTextVNode(" and other forms of media below the card header")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Place "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-card-actions"),
    /* @__PURE__ */ createTextVNode(" after card content")
  ])
], -1);
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Element / Area"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("tr", null, [
  /* @__PURE__ */ createBaseVNode("td", null, "1. Container"),
  /* @__PURE__ */ createBaseVNode("td", null, [
    /* @__PURE__ */ createTextVNode("The Card container holds all "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-card"),
    /* @__PURE__ */ createTextVNode(" components. Composed of 3 major parts: "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-card-item"),
    /* @__PURE__ */ createTextVNode(", "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-card-text"),
    /* @__PURE__ */ createTextVNode(", and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-card-actions")
  ])
], -1);
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("tr", null, [
  /* @__PURE__ */ createBaseVNode("td", null, "2. Title (optional)"),
  /* @__PURE__ */ createBaseVNode("td", null, [
    /* @__PURE__ */ createTextVNode("A heading with increased "),
    /* @__PURE__ */ createBaseVNode("strong", null, "font-size")
  ])
], -1);
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("tr", null, [
  /* @__PURE__ */ createBaseVNode("td", null, "3. Subtitle (optional)"),
  /* @__PURE__ */ createBaseVNode("td", null, "A subheading with a lower emphasis text color")
], -1);
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("tr", null, [
  /* @__PURE__ */ createBaseVNode("td", null, "4. Text (optional)"),
  /* @__PURE__ */ createBaseVNode("td", null, "A content area with a lower emphasis text color")
], -1);
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("td", null, "5. Actions (optional)", -1);
const _hoisted_22 = { id: "guide" };
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-card"),
  /* @__PURE__ */ createTextVNode(" component is a versatile and enhanced sheet of paper that provides a simple interface for headings, text, images, and actions. It is a content container that is the most common way to present information.")
], -1);
const _hoisted_24 = { id: "basics" };
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("There are three ways you can populate a "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-card"),
  /* @__PURE__ */ createTextVNode(" with content. The first one is by using props, the second one is by slots, and the third one is by manually using the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-card-*"),
  /* @__PURE__ */ createTextVNode(" components.")
], -1);
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("p", null, "Props give you an easy interface to display text-only content. They can also be used to easily render images and icons. Use slots if you need to render more complex content. If you need full control over the content, use markup.", -1);
const _hoisted_27 = { id: "combined" };
const _hoisted_28 = /* @__PURE__ */ createBaseVNode("p", null, "In some cases it is possible to combine the different options, like the example below where props, slots and markup have all been used.", -1);
const _hoisted_29 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("In general slots take precedence over props. So if you provide both "),
  /* @__PURE__ */ createBaseVNode("strong", null, "text"),
  /* @__PURE__ */ createTextVNode(" prop and use "),
  /* @__PURE__ */ createBaseVNode("strong", null, "text"),
  /* @__PURE__ */ createTextVNode(" slot, then only the slot content will be rendered.")
], -1);
const _hoisted_30 = { id: "props" };
const _hoisted_31 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-card"),
  /* @__PURE__ */ createTextVNode(" component has a variety of props that allow you to customize its appearance and behavior.")
], -1);
const _hoisted_32 = { id: "variants" };
const _hoisted_33 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "variant"),
  /* @__PURE__ */ createTextVNode(" prop gives you easy access to several different card styles. Available variants are: "),
  /* @__PURE__ */ createBaseVNode("strong", null, "elevated"),
  /* @__PURE__ */ createTextVNode("(default), "),
  /* @__PURE__ */ createBaseVNode("strong", null, "flat"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "tonal"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "outlined"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "text"),
  /* @__PURE__ */ createTextVNode(", and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "plain"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_34 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Value"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_35 = /* @__PURE__ */ createBaseVNode("tbody", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "elevated")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "Elevates the card with a shadow")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "flat")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "Removes card shadow and border")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "tonal")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "Background color is a lowered opacity of the color")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "outlined")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "Applies a thin border and card has zero elevation")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "text")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "Removes the background and removes shadow")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "plain")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "Removes the background and lowers the opacity until hovered")
  ])
], -1);
const _hoisted_36 = { id: "color" };
const _hoisted_37 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Cards can be colored by using any of the builtin colors and contextual names using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "color"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_38 = { id: "elevation" };
const _hoisted_39 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "elevation"),
  /* @__PURE__ */ createTextVNode(" property provides up to 24 levels of shadow depth. By default, cards rest at 2dp.")
], -1);
const _hoisted_40 = { id: "hover" };
const _hoisted_41 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("When using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "hover"),
  /* @__PURE__ */ createTextVNode(" prop, the cards will increase its elevation when the mouse is hovered over them.")
], -1);
const _hoisted_42 = { id: "href" };
const _hoisted_43 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The card becomes an anchor with the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "href"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_44 = { id: "link" };
const _hoisted_45 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Add the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "link"),
  /* @__PURE__ */ createTextVNode(" prop for the same style without adding an anchor.")
], -1);
const _hoisted_46 = { id: "disabled" };
const _hoisted_47 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "disabled"),
  /* @__PURE__ */ createTextVNode(" prop can be added in order to prevent a user from interacting with the card.")
], -1);
const _hoisted_48 = { id: "image" };
const _hoisted_49 = /* @__PURE__ */ createBaseVNode("p", null, "Apply a specific background image to the Card.", -1);
const _hoisted_50 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "TIP:")
], -1);
const _hoisted_51 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-card"),
  /* @__PURE__ */ createTextVNode(" does not allow its content to overflow outside the card by default. It also establishes a z-index stacking context, which prevents its content from displaying on top of elements outside the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-card"),
  /* @__PURE__ */ createTextVNode(", even when it sets a higher z-index value. To override this default behavior, apply the following usage: "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, '<v-card style="overflow: initial; z-index: initial">'),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_52 = { id: "slots" };
const _hoisted_53 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-card"),
  /* @__PURE__ */ createTextVNode(" component provides slots that enable you to customize content created by its props or to add additional content.")
], -1);
const _hoisted_54 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Slots give you greater control to customize the content of the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-card"),
  /* @__PURE__ */ createTextVNode(" component while still taking advantage of the easy-to-use props.")
], -1);
const _hoisted_55 = { id: "avatar-and-icon" };
const _hoisted_56 = /* @__PURE__ */ createBaseVNode("strong", null, "prepend-avatar", -1);
const _hoisted_57 = /* @__PURE__ */ createBaseVNode("strong", null, "append-avatar", -1);
const _hoisted_58 = /* @__PURE__ */ createBaseVNode("strong", null, "prepend-icon", -1);
const _hoisted_59 = /* @__PURE__ */ createBaseVNode("strong", null, "append-icon", -1);
const _hoisted_60 = /* @__PURE__ */ createBaseVNode("strong", null, "prepend", -1);
const _hoisted_61 = /* @__PURE__ */ createBaseVNode("strong", null, "append", -1);
const _hoisted_62 = { id: "examples" };
const _hoisted_63 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The following are a collection of examples that demonstrate more advanced and real world use of the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-card"),
  /* @__PURE__ */ createTextVNode(" component.")
], -1);
const _hoisted_64 = { id: "card-reveal" };
const _hoisted_65 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "@click", -1);
const _hoisted_66 = { id: "content-wrapping" };
const _hoisted_67 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-card"),
  /* @__PURE__ */ createTextVNode(" component is useful for wrapping content.")
], -1);
const _hoisted_68 = { id: "custom-actions" };
const _hoisted_69 = /* @__PURE__ */ createBaseVNode("p", null, "With a simple conditional, you can easily add supplementary text that is hidden until opened.", -1);
const _hoisted_70 = { id: "grids" };
const _hoisted_71 = { id: "horizontal-cards" };
const _hoisted_72 = { id: "information-card" };
const _hoisted_73 = /* @__PURE__ */ createBaseVNode("p", null, "Cards are entry points to more detailed information. To keep things concise, ensure to limit the number of actions the user can take.", -1);
const _hoisted_74 = { id: "media-with-text" };
const _hoisted_75 = /* @__PURE__ */ createBaseVNode("p", null, "Using the layout system, we can add custom text anywhere within the background.", -1);
const _hoisted_76 = { id: "twitter-card" };
const _hoisted_77 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-card"),
  /* @__PURE__ */ createTextVNode(" component has multiple children components that help you build complex examples without having to worry about spacing. This example is comprised of the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-card-title"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-card-text"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-card-actions"),
  /* @__PURE__ */ createTextVNode(" components.")
], -1);
const _hoisted_78 = { id: "weather-card" };
const _hoisted_79 = { id: "loading" };
const _hoisted_80 = { id: "earnings-goal" };
const _hoisted_81 = /* @__PURE__ */ createBaseVNode("p", null, "This example utilizes slots to customize the appearance of the different content areas.", -1);
const _hoisted_82 = { id: "funding-card" };
const _hoisted_83 = /* @__PURE__ */ createBaseVNode("p", null, "Utilize a combination of Card properties and utility classes to create a unique funding card.", -1);
const frontmatter = { "meta": { "nav": "Cards", "title": "Card component", "description": "The v-card component is a versatile and enhanced sheet of paper that provides a simple interface for headings, text, images, and actions.", "keywords": "cards, vuetify card component, vue card component, v-card" }, "related": ["/components/buttons", "/components/images", "/styles/text-and-typography"], "features": { "figma": true, "label": "C: VCard", "github": "/components/VCard/", "report": true, "spec": "https://m2.material.io/components/cards" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "cards",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Cards", "title": "Card component", "description": "The v-card component is a versatile and enhanced sheet of paper that provides a simple interface for headings, text, images, and actions.", "keywords": "cards, vuetify card component, vue card component, v-card" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Cards", "title": "Card component", "description": "The v-card component is a versatile and enhanced sheet of paper that provides a simple interface for headings, text, images, and actions.", "keywords": "cards, vuetify card component, vue card component, v-card" }, "related": ["/components/buttons", "/components/images", "/styles/text-and-typography"], "features": { "figma": true, "label": "C: VCard", "github": "/components/VCard/", "report": true, "spec": "https://m2.material.io/components/cards" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_figure = resolveComponent("app-figure");
      const _component_page_features = resolveComponent("page-features");
      const _component_vo_promotions_card_vuetify = resolveComponent("vo-promotions-card-vuetify");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_alert = resolveComponent("alert");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#cards",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Cards")
                ]),
                _: 1
              }),
              createBaseVNode("p", null, [
                createTextVNode("The "),
                _hoisted_2,
                createTextVNode(" component is a versatile and enhanced version of "),
                createVNode(_component_app_link, { href: "/components/sheets/" }, {
                  default: withCtx(() => [
                    createTextVNode("v-sheet")
                  ]),
                  _: 1
                }),
                createTextVNode(" that provides a simple interface for headings, text, images, icons, and more.")
              ]),
              createBaseVNode("p", null, [
                createBaseVNode("div", null, [
                  createVNode(_component_app_figure, {
                    alt: "Card Entry",
                    src: "https://cdn.vuetifyjs.com/docs/images/components-temp/v-card/v-card-entry.png"
                  })
                ])
              ]),
              createVNode(_component_page_features),
              createVNode(_component_vo_promotions_card_vuetify),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_usage, { name: "v-card" })
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_6,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-card/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-card")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-card-item/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-card-item")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_8
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-card-title/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-card-title")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_9
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-card-subtitle/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-card-subtitle")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_10
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-card-text/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-card-text")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_11
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-card-actions/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-card-actions")
                            ]),
                            _: 1
                          })
                        ]),
                        createBaseVNode("td", null, [
                          createTextVNode("Sub-component that modifies the default styling of "),
                          createVNode(_component_app_link, { href: "/components/buttons/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-btn")
                            ]),
                            _: 1
                          }),
                          createTextVNode(". Wraps the "),
                          _hoisted_12,
                          createTextVNode(" slot")
                        ])
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_13, [
                createVNode(_component_app_heading, {
                  href: "#anatomy",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Anatomy")
                  ]),
                  _: 1
                }),
                _hoisted_14,
                _hoisted_15,
                createBaseVNode("p", null, [
                  createBaseVNode("div", null, [
                    createVNode(_component_app_figure, {
                      alt: "Card Anatomy",
                      src: "https://cdn.vuetifyjs.com/docs/images/components-temp/v-card/v-card-anatomy.png"
                    })
                  ])
                ]),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_16,
                    createBaseVNode("tbody", null, [
                      _hoisted_17,
                      _hoisted_18,
                      _hoisted_19,
                      _hoisted_20,
                      createBaseVNode("tr", null, [
                        _hoisted_21,
                        createBaseVNode("td", null, [
                          createTextVNode("A content area that typically contains one or more "),
                          createVNode(_component_app_link, { href: "/components/buttons" }, {
                            default: withCtx(() => [
                              createTextVNode("v-btn")
                            ]),
                            _: 1
                          }),
                          createTextVNode(" components")
                        ])
                      ])
                    ])
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_22, [
                createVNode(_component_app_heading, {
                  href: "#guide",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Guide")
                  ]),
                  _: 1
                }),
                _hoisted_23,
                createBaseVNode("section", _hoisted_24, [
                  createVNode(_component_app_heading, {
                    href: "#basics",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Basics")
                    ]),
                    _: 1
                  }),
                  _hoisted_25,
                  createVNode(_component_examples_example, { file: "v-card/basics-content" }),
                  _hoisted_26
                ]),
                createBaseVNode("section", _hoisted_27, [
                  createVNode(_component_app_heading, {
                    href: "#combined",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Combined")
                    ]),
                    _: 1
                  }),
                  _hoisted_28,
                  createVNode(_component_examples_example, { file: "v-card/basics-combine" }),
                  createVNode(_component_alert, { type: "info" }, {
                    default: withCtx(() => [
                      _hoisted_29
                    ]),
                    _: 1
                  })
                ]),
                createBaseVNode("section", _hoisted_30, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  _hoisted_31,
                  createBaseVNode("section", _hoisted_32, [
                    createVNode(_component_app_heading, {
                      href: "#variants",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Variants")
                      ]),
                      _: 1
                    }),
                    _hoisted_33,
                    createVNode(_component_app_table, null, {
                      default: withCtx(() => [
                        _hoisted_34,
                        _hoisted_35
                      ]),
                      _: 1
                    }),
                    createVNode(_component_examples_example, { file: "v-card/prop-variant" }),
                    createVNode(_component_vo_promotions_card_vuetify)
                  ]),
                  createBaseVNode("section", _hoisted_36, [
                    createVNode(_component_app_heading, {
                      href: "#color",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Color")
                      ]),
                      _: 1
                    }),
                    _hoisted_37,
                    createVNode(_component_examples_example, { file: "v-card/prop-color" })
                  ]),
                  createBaseVNode("section", _hoisted_38, [
                    createVNode(_component_app_heading, {
                      href: "#elevation",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Elevation")
                      ]),
                      _: 1
                    }),
                    _hoisted_39,
                    createVNode(_component_examples_example, { file: "v-card/prop-elevation" })
                  ]),
                  createBaseVNode("section", _hoisted_40, [
                    createVNode(_component_app_heading, {
                      href: "#hover",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Hover")
                      ]),
                      _: 1
                    }),
                    _hoisted_41,
                    createVNode(_component_examples_example, { file: "v-card/prop-hover" })
                  ]),
                  createBaseVNode("section", _hoisted_42, [
                    createVNode(_component_app_heading, {
                      href: "#href",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Href")
                      ]),
                      _: 1
                    }),
                    _hoisted_43,
                    createVNode(_component_examples_example, { file: "v-card/prop-href" })
                  ]),
                  createBaseVNode("section", _hoisted_44, [
                    createVNode(_component_app_heading, {
                      href: "#link",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Link")
                      ]),
                      _: 1
                    }),
                    _hoisted_45,
                    createVNode(_component_examples_example, { file: "v-card/prop-link" })
                  ]),
                  createBaseVNode("section", _hoisted_46, [
                    createVNode(_component_app_heading, {
                      href: "#disabled",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Disabled")
                      ]),
                      _: 1
                    }),
                    _hoisted_47,
                    createVNode(_component_examples_example, { file: "v-card/prop-disabled" })
                  ]),
                  createBaseVNode("section", _hoisted_48, [
                    createVNode(_component_app_heading, {
                      href: "#image",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Image")
                      ]),
                      _: 1
                    }),
                    _hoisted_49,
                    createVNode(_component_examples_example, { file: "v-card/prop-image" }),
                    createVNode(_component_alert, { type: "tip" }, {
                      default: withCtx(() => [
                        _hoisted_50,
                        _hoisted_51
                      ]),
                      _: 1
                    })
                  ])
                ]),
                createBaseVNode("section", _hoisted_52, [
                  createVNode(_component_app_heading, {
                    href: "#slots",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Slots")
                    ]),
                    _: 1
                  }),
                  _hoisted_53,
                  _hoisted_54,
                  createBaseVNode("section", _hoisted_55, [
                    createVNode(_component_app_heading, {
                      href: "#avatar-and-icon",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Avatar and icon")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("You can use the "),
                      _hoisted_56,
                      createTextVNode(", "),
                      _hoisted_57,
                      createTextVNode(", "),
                      _hoisted_58,
                      createTextVNode(" and "),
                      _hoisted_59,
                      createTextVNode(" props or the "),
                      _hoisted_60,
                      createTextVNode(" and "),
                      _hoisted_61,
                      createTextVNode(" slots to place a "),
                      createVNode(_component_app_link, { href: "/components/icons/" }, {
                        default: withCtx(() => [
                          createTextVNode("v-icon")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" that automatically injects the designated icon.")
                    ]),
                    createVNode(_component_examples_example, { file: "v-card/slot-prepend-append" })
                  ])
                ])
              ]),
              createBaseVNode("section", _hoisted_62, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                _hoisted_63,
                createBaseVNode("section", _hoisted_64, [
                  createVNode(_component_app_heading, {
                    href: "#card-reveal",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Card Reveal")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("p", null, [
                    createTextVNode("Using "),
                    createVNode(_component_app_link, { href: "/api/v-expand-transition/" }, {
                      default: withCtx(() => [
                        createTextVNode("v-expand-transition")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" and a "),
                    _hoisted_65,
                    createTextVNode(" event you can have a card that reveals more information once the button is clicked, activating the hidden card to be revealed.")
                  ]),
                  createVNode(_component_examples_example, { file: "v-card/misc-card-reveal" })
                ]),
                createBaseVNode("section", _hoisted_66, [
                  createVNode(_component_app_heading, {
                    href: "#content-wrapping",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Content wrapping")
                    ]),
                    _: 1
                  }),
                  _hoisted_67,
                  createVNode(_component_examples_example, { file: "v-card/misc-content-wrapping" })
                ]),
                createBaseVNode("section", _hoisted_68, [
                  createVNode(_component_app_heading, {
                    href: "#custom-actions",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Custom actions")
                    ]),
                    _: 1
                  }),
                  _hoisted_69,
                  createVNode(_component_examples_example, { file: "v-card/misc-custom-actions" }),
                  createVNode(_component_vo_promotions_card_vuetify)
                ]),
                createBaseVNode("section", _hoisted_70, [
                  createVNode(_component_app_heading, {
                    href: "#grids",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Grids")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("p", null, [
                    createTextVNode("Using "),
                    createVNode(_component_app_link, { href: "/components/grids/" }, {
                      default: withCtx(() => [
                        createTextVNode("grids")
                      ]),
                      _: 1
                    }),
                    createTextVNode(", you can create beautiful layouts.")
                  ]),
                  createVNode(_component_examples_example, { file: "v-card/misc-grids" })
                ]),
                createBaseVNode("section", _hoisted_71, [
                  createVNode(_component_app_heading, {
                    href: "#horizontal-cards",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Horizontal cards")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("p", null, [
                    createTextVNode("You can also play with the card layout using "),
                    createVNode(_component_app_link, { href: "/styles/flex/" }, {
                      default: withCtx(() => [
                        createTextVNode("layout flex")
                      ]),
                      _: 1
                    }),
                    createTextVNode(".")
                  ]),
                  createVNode(_component_examples_example, { file: "v-card/misc-horizontal-cards" })
                ]),
                createBaseVNode("section", _hoisted_72, [
                  createVNode(_component_app_heading, {
                    href: "#information-card",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Information card")
                    ]),
                    _: 1
                  }),
                  _hoisted_73,
                  createVNode(_component_examples_example, { file: "v-card/misc-information-card" })
                ]),
                createBaseVNode("section", _hoisted_74, [
                  createVNode(_component_app_heading, {
                    href: "#media-with-text",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Media with text")
                    ]),
                    _: 1
                  }),
                  _hoisted_75,
                  createVNode(_component_examples_example, { file: "v-card/misc-media-with-text" })
                ]),
                createBaseVNode("section", _hoisted_76, [
                  createVNode(_component_app_heading, {
                    href: "#twitter-card",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Twitter card")
                    ]),
                    _: 1
                  }),
                  _hoisted_77,
                  createVNode(_component_examples_example, { file: "v-card/misc-twitter-card" })
                ]),
                createBaseVNode("section", _hoisted_78, [
                  createVNode(_component_app_heading, {
                    href: "#weather-card",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Weather card")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("p", null, [
                    createTextVNode("Using "),
                    createVNode(_component_app_link, { href: "/components/lists" }, {
                      default: withCtx(() => [
                        createTextVNode("v-list-items")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" and a "),
                    createVNode(_component_app_link, { href: "/components/sliders" }, {
                      default: withCtx(() => [
                        createTextVNode("v-slider")
                      ]),
                      _: 1
                    }),
                    createTextVNode(", we are able to create a unique weather card. The list components ensure that we have consistent spacing and functionality while the slider component allows us to provide a useful interface of selection to the user.")
                  ]),
                  createVNode(_component_examples_example, { file: "v-card/misc-weather-card" })
                ]),
                createBaseVNode("section", _hoisted_79, [
                  createVNode(_component_app_heading, {
                    href: "#loading",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Loading")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("p", null, [
                    createTextVNode("Use an indeterminate "),
                    createVNode(_component_app_link, { href: "/components/progress-linear" }, {
                      default: withCtx(() => [
                        createTextVNode("v-progress-linear")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" to indicate a loading state.")
                  ]),
                  createVNode(_component_examples_example, { file: "v-card/prop-loading" })
                ]),
                createBaseVNode("section", _hoisted_80, [
                  createVNode(_component_app_heading, {
                    href: "#earnings-goal",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Earnings goal")
                    ]),
                    _: 1
                  }),
                  _hoisted_81,
                  createVNode(_component_examples_example, { file: "v-card/misc-earnings-goal" })
                ]),
                createBaseVNode("section", _hoisted_82, [
                  createVNode(_component_app_heading, {
                    href: "#funding-card",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Funding card")
                    ]),
                    _: 1
                  }),
                  _hoisted_83,
                  createVNode(_component_examples_example, { file: "v-card/misc-shopify-funding" })
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
