import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "carousels" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-carousel"),
  /* @__PURE__ */ createTextVNode(" component is used to display large numbers of visual content on a rotating timer.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-carousel"),
  /* @__PURE__ */ createTextVNode(" component expands upon "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-window"),
  /* @__PURE__ */ createTextVNode(" by providing additional features targeted at displaying images.")
], -1);
const _hoisted_5 = { id: "api" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "Primary component", -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createTextVNode("Sub-component used for displaying the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-carousel"),
  /* @__PURE__ */ createTextVNode(" state")
], -1);
const _hoisted_9 = { id: "examples" };
const _hoisted_10 = { id: "props" };
const _hoisted_11 = { id: "custom-delimiters" };
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("p", null, "Use any available icon as your carousel’s slide delimiter.", -1);
const _hoisted_13 = { id: "cycle" };
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("With the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "cycle"),
  /* @__PURE__ */ createTextVNode(" prop you can have your slides automatically transition to the next available every 6s (default).")
], -1);
const _hoisted_15 = { id: "hide-controls" };
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can hide the carousel navigation controls with "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ':show-arrows="false"'),
  /* @__PURE__ */ createTextVNode(". Or you can make them only appear on hover with "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, 'show-arrows="hover"'),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_17 = { id: "customized-arrows" };
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Arrows can be customized by using "),
  /* @__PURE__ */ createBaseVNode("strong", null, "prev"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "next"),
  /* @__PURE__ */ createTextVNode(" slots.")
], -1);
const _hoisted_19 = { id: "hide-delimiters" };
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can hide the bottom controls with "),
  /* @__PURE__ */ createBaseVNode("strong", null, "hide-delimiters"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_21 = { id: "progress" };
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can show a linear progress bar with the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "progress"),
  /* @__PURE__ */ createTextVNode(" prop. It will indicate how far into the cycle the carousel currently is.")
], -1);
const _hoisted_23 = { id: "model" };
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can control carousel with "),
  /* @__PURE__ */ createBaseVNode("strong", null, "v-model"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const frontmatter = { "meta": { "nav": "Carousels", "title": "Carousel component", "description": "The carousel component is used to cycle through visual content such as images or slides of text.", "keywords": "carousels, vuetify carousel component, vue carousel component" }, "related": ["/components/parallax/", "/components/images/", "/components/windows/"], "features": { "github": "/components/VCarousel/", "label": "C: VCarousel", "report": true } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "carousels",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Carousels", "title": "Carousel component", "description": "The carousel component is used to cycle through visual content such as images or slides of text.", "keywords": "carousels, vuetify carousel component, vue carousel component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Carousels", "title": "Carousel component", "description": "The carousel component is used to cycle through visual content such as images or slides of text.", "keywords": "carousels, vuetify carousel component, vue carousel component" }, "related": ["/components/parallax/", "/components/images/", "/components/windows/"], "features": { "github": "/components/VCarousel/", "label": "C: VCarousel", "report": true } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#carousels",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Carousels")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_usage, { name: "v-carousel" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_6,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-carousel/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-carousel")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-carousel-item/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-carousel-item")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_8
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_9, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_10, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_11, [
                    createVNode(_component_app_heading, {
                      href: "#custom-delimiters",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Custom delimiters")
                      ]),
                      _: 1
                    }),
                    _hoisted_12,
                    createVNode(_component_examples_example, { file: "v-carousel/prop-custom-icons" })
                  ]),
                  createBaseVNode("section", _hoisted_13, [
                    createVNode(_component_app_heading, {
                      href: "#cycle",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Cycle")
                      ]),
                      _: 1
                    }),
                    _hoisted_14,
                    createVNode(_component_examples_example, { file: "v-carousel/prop-cycle" })
                  ]),
                  createBaseVNode("section", _hoisted_15, [
                    createVNode(_component_app_heading, {
                      href: "#hide-controls",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Hide controls")
                      ]),
                      _: 1
                    }),
                    _hoisted_16,
                    createVNode(_component_examples_example, { file: "v-carousel/prop-hide-controls" })
                  ]),
                  createBaseVNode("section", _hoisted_17, [
                    createVNode(_component_app_heading, {
                      href: "#customized-arrows",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Customized arrows")
                      ]),
                      _: 1
                    }),
                    _hoisted_18,
                    createVNode(_component_examples_example, { file: "v-carousel/slots-next-prev" })
                  ]),
                  createBaseVNode("section", _hoisted_19, [
                    createVNode(_component_app_heading, {
                      href: "#hide-delimiters",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Hide delimiters")
                      ]),
                      _: 1
                    }),
                    _hoisted_20,
                    createVNode(_component_examples_example, { file: "v-carousel/prop-hide-delimiters" })
                  ]),
                  createBaseVNode("section", _hoisted_21, [
                    createVNode(_component_app_heading, {
                      href: "#progress",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Progress")
                      ]),
                      _: 1
                    }),
                    _hoisted_22,
                    createVNode(_component_examples_example, { file: "v-carousel/prop-progress" })
                  ]),
                  createBaseVNode("section", _hoisted_23, [
                    createVNode(_component_app_heading, {
                      href: "#model",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Model")
                      ]),
                      _: 1
                    }),
                    _hoisted_24,
                    createVNode(_component_examples_example, { file: "v-carousel/prop-model" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
