import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "checkboxes" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-checkbox"),
  /* @__PURE__ */ createTextVNode(" component provides users the ability to choose between two distinct values. These are very similar to a switch and can be used in complex forms and checklists.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("A "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-checkbox"),
  /* @__PURE__ */ createTextVNode(" in its simplest form provides a toggle between 2 values.")
], -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "TIP:")
], -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("A simpler version, "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-simple-checkbox"),
  /* @__PURE__ */ createTextVNode(" is used primarily as a lightweight alternative in data-table components to select rows or display inline boolean data.")
], -1);
const _hoisted_7 = { id: "api" };
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("td", null, "Primary component", -1);
const _hoisted_10 = { id: "examples" };
const _hoisted_11 = { id: "props" };
const _hoisted_12 = { id: "colors" };
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Checkboxes can be colored by using any of the builtin colors and contextual names using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "color"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_14 = { id: "model-as-array" };
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Multiple "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-checkbox"),
  /* @__PURE__ */ createTextVNode("’s can share the same "),
  /* @__PURE__ */ createBaseVNode("strong", null, "v-model"),
  /* @__PURE__ */ createTextVNode(" by using an array.")
], -1);
const _hoisted_16 = { id: "model-as-boolean" };
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("A single "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-checkbox"),
  /* @__PURE__ */ createTextVNode(" will have a boolean value as its "),
  /* @__PURE__ */ createBaseVNode("strong", null, "value"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_18 = { id: "states" };
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-checkbox"),
  /* @__PURE__ */ createTextVNode(" can have different states such as "),
  /* @__PURE__ */ createBaseVNode("strong", null, "default"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "disabled"),
  /* @__PURE__ */ createTextVNode(", and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "indeterminate"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_20 = { id: "slots" };
const _hoisted_21 = { id: "label-slot" };
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Checkbox labels can be defined in "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "label"),
  /* @__PURE__ */ createTextVNode(" slot - that will allow to use HTML content.")
], -1);
const _hoisted_23 = { id: "misc" };
const _hoisted_24 = { id: "inline-text-field" };
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("If you need to place checkboxes in line with other components, you can use the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-checkbox-btn"),
  /* @__PURE__ */ createTextVNode(" component.")
], -1);
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("p", null, "This component renders just checkbox, without the trapping of a form input such as validation, a label, and messages.", -1);
const frontmatter = { "meta": { "nav": "Checkboxes", "title": "Checkbox component", "description": "The checkbox component permits users to select between two values.", "keywords": "checkbox, checkbox component, vuetify checkbox component, vue checkbox component" }, "related": ["/components/switches", "/components/forms", "/components/text-fields"], "features": { "label": "C: VCheckbox", "report": true, "github": "/components/VCheckbox/", "spec": "https://m2.material.io/components/checkboxes" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "checkboxes",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Checkboxes", "title": "Checkbox component", "description": "The checkbox component permits users to select between two values.", "keywords": "checkbox, checkbox component, vuetify checkbox component, vue checkbox component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Checkboxes", "title": "Checkbox component", "description": "The checkbox component permits users to select between two values.", "keywords": "checkbox, checkbox component, vuetify checkbox component, vue checkbox component" }, "related": ["/components/switches", "/components/forms", "/components/text-fields"], "features": { "label": "C: VCheckbox", "report": true, "github": "/components/VCheckbox/", "spec": "https://m2.material.io/components/checkboxes" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_alert = resolveComponent("alert");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#checkboxes",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Checkboxes")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_usage, { name: "v-checkbox" }),
                createVNode(_component_promoted_entry),
                createVNode(_component_alert, { type: "tip" }, {
                  default: withCtx(() => [
                    _hoisted_5,
                    _hoisted_6
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_7, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_8,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-checkbox/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-checkbox")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_9
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_10, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_11, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_12, [
                    createVNode(_component_app_heading, {
                      href: "#colors",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Colors")
                      ]),
                      _: 1
                    }),
                    _hoisted_13,
                    createVNode(_component_examples_example, { file: "v-checkbox/prop-colors" })
                  ]),
                  createBaseVNode("section", _hoisted_14, [
                    createVNode(_component_app_heading, {
                      href: "#model-as-array",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Model as array")
                      ]),
                      _: 1
                    }),
                    _hoisted_15,
                    createVNode(_component_examples_example, { file: "v-checkbox/prop-model-as-array" })
                  ]),
                  createBaseVNode("section", _hoisted_16, [
                    createVNode(_component_app_heading, {
                      href: "#model-as-boolean",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Model as boolean")
                      ]),
                      _: 1
                    }),
                    _hoisted_17,
                    createVNode(_component_examples_example, { file: "v-checkbox/prop-model-as-boolean" })
                  ]),
                  createBaseVNode("section", _hoisted_18, [
                    createVNode(_component_app_heading, {
                      href: "#states",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("States")
                      ]),
                      _: 1
                    }),
                    _hoisted_19,
                    createVNode(_component_examples_example, { file: "v-checkbox/prop-states" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_20, [
                  createVNode(_component_app_heading, {
                    href: "#slots",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Slots")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_21, [
                    createVNode(_component_app_heading, {
                      href: "#label-slot",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Label slot")
                      ]),
                      _: 1
                    }),
                    _hoisted_22,
                    createVNode(_component_examples_example, { file: "v-checkbox/slot-label" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_23, [
                  createVNode(_component_app_heading, {
                    href: "#misc",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Misc")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_24, [
                    createVNode(_component_app_heading, {
                      href: "#inline-text-field",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Inline text-field")
                      ]),
                      _: 1
                    }),
                    _hoisted_25,
                    _hoisted_26,
                    createVNode(_component_examples_example, { file: "v-checkbox/misc-inline-textfield" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
