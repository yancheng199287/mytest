import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "chip-groups" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-chip-group"),
  /* @__PURE__ */ createTextVNode(" supercharges the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-chip"),
  /* @__PURE__ */ createTextVNode(" component by providing groupable functionality. It is used for creating groups of selections using chips.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Chip groups make it easy for users to select filtering options for more complex implementations. By default "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-chip-group"),
  /* @__PURE__ */ createTextVNode(" will overflow to the right but can be changed to a "),
  /* @__PURE__ */ createBaseVNode("strong", null, "column"),
  /* @__PURE__ */ createTextVNode(" only mode.")
], -1);
const _hoisted_5 = { id: "api" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "Primary component", -1);
const _hoisted_8 = { id: "examples" };
const _hoisted_9 = { id: "props" };
const _hoisted_10 = { id: "column" };
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Chip groups with "),
  /* @__PURE__ */ createBaseVNode("strong", null, "column"),
  /* @__PURE__ */ createTextVNode(" prop can wrap their chips.")
], -1);
const _hoisted_12 = { id: "filter-results" };
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Easily create chip groups that provide additional feedback with the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "filter"),
  /* @__PURE__ */ createTextVNode(" prop. This creates an alternative visual style that communicates to the user that the chip is selected.")
], -1);
const _hoisted_14 = { id: "mandatory" };
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Chip groups with "),
  /* @__PURE__ */ createBaseVNode("strong", null, "mandatory"),
  /* @__PURE__ */ createTextVNode(" prop must always have a value selected.")
], -1);
const _hoisted_16 = { id: "multiple" };
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Chip groups with "),
  /* @__PURE__ */ createBaseVNode("strong", null, "multiple"),
  /* @__PURE__ */ createTextVNode(" prop can have many values selected.")
], -1);
const _hoisted_18 = { id: "misc" };
const _hoisted_19 = { id: "product-card" };
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-chip"),
  /* @__PURE__ */ createTextVNode(" component can have an explicit value used for its model. This gets passed to the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-chip-group"),
  /* @__PURE__ */ createTextVNode(" component and is useful for when you don’t want to use the chips index as their values.")
], -1);
const _hoisted_21 = { id: "toothbrush-card" };
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("p", null, "Chip groups allow the creation of custom interfaces that perform the same actions as an item group or radio controls, but are stylistically different.", -1);
const _hoisted_23 = { id: "reddit-style-categories" };
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("p", null, "Use a combination of utility classes and emojis to create a Reddit-style category selection.", -1);
const frontmatter = { "meta": { "nav": "Chip groups", "title": "Chip group component", "description": "The chip group component combines numerous selectable chips into single or multiple lines.", "keywords": "chip groups, vuetify chip group component, vue chip group component" }, "related": ["/components/chips/", "/components/slide-groups/", "/components/item-groups/"], "features": { "github": "/components/VChipGroup/", "label": "C: VChipGroup", "report": true, "spec": "https://m2.material.io/components/chips#choice-chips" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "chip-groups",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Chip groups", "title": "Chip group component", "description": "The chip group component combines numerous selectable chips into single or multiple lines.", "keywords": "chip groups, vuetify chip group component, vue chip group component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Chip groups", "title": "Chip group component", "description": "The chip group component combines numerous selectable chips into single or multiple lines.", "keywords": "chip groups, vuetify chip group component, vue chip group component" }, "related": ["/components/chips/", "/components/slide-groups/", "/components/item-groups/"], "features": { "github": "/components/VChipGroup/", "label": "C: VChipGroup", "report": true, "spec": "https://m2.material.io/components/chips#choice-chips" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#chip-groups",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Chip groups")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_usage, { name: "v-chip-group" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_6,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-chip-group/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-chip-group")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_8, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_9, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_10, [
                    createVNode(_component_app_heading, {
                      href: "#column",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Column")
                      ]),
                      _: 1
                    }),
                    _hoisted_11,
                    createVNode(_component_examples_example, { file: "v-chip-group/prop-column" })
                  ]),
                  createBaseVNode("section", _hoisted_12, [
                    createVNode(_component_app_heading, {
                      href: "#filter-results",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Filter results")
                      ]),
                      _: 1
                    }),
                    _hoisted_13,
                    createVNode(_component_examples_example, { file: "v-chip-group/prop-filter" })
                  ]),
                  createBaseVNode("section", _hoisted_14, [
                    createVNode(_component_app_heading, {
                      href: "#mandatory",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Mandatory")
                      ]),
                      _: 1
                    }),
                    _hoisted_15,
                    createVNode(_component_examples_example, { file: "v-chip-group/prop-mandatory" })
                  ]),
                  createBaseVNode("section", _hoisted_16, [
                    createVNode(_component_app_heading, {
                      href: "#multiple",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Multiple")
                      ]),
                      _: 1
                    }),
                    _hoisted_17,
                    createVNode(_component_examples_example, { file: "v-chip-group/prop-multiple" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_18, [
                  createVNode(_component_app_heading, {
                    href: "#misc",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Misc")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_19, [
                    createVNode(_component_app_heading, {
                      href: "#product-card",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Product card")
                      ]),
                      _: 1
                    }),
                    _hoisted_20,
                    createVNode(_component_examples_example, { file: "v-chip-group/misc-product-card" })
                  ]),
                  createBaseVNode("section", _hoisted_21, [
                    createVNode(_component_app_heading, {
                      href: "#toothbrush-card",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Toothbrush card")
                      ]),
                      _: 1
                    }),
                    _hoisted_22,
                    createVNode(_component_examples_example, { file: "v-chip-group/misc-toothbrush-card" })
                  ]),
                  createBaseVNode("section", _hoisted_23, [
                    createVNode(_component_app_heading, {
                      href: "#reddit-style-categories",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Reddit style categories")
                      ]),
                      _: 1
                    }),
                    _hoisted_24,
                    createVNode(_component_examples_example, { file: "v-chip-group/misc-reddit-categories" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
