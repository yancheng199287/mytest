import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "chips" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-chip", -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "close", -1);
const _hoisted_4 = { id: "usage" };
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Chips come in the following variations: closeable, filter, outlined, pill. The default slot of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-chip"),
  /* @__PURE__ */ createTextVNode(" will also accept avatars and icons alongside text.")
], -1);
const _hoisted_6 = { id: "api" };
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("td", null, "Primary component", -1);
const _hoisted_9 = { id: "guide" };
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-chip", -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "close", -1);
const _hoisted_12 = { id: "props" };
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-chip", -1);
const _hoisted_14 = { id: "closable" };
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Closable chips can be controlled with a v-model. You can also listen to the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "click:close"),
  /* @__PURE__ */ createTextVNode(" event if you want to know when a chip has been closed.")
], -1);
const _hoisted_16 = { id: "color-and-variants" };
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("p", null, "Any color from the Material Design palette can be used to change a chips color.", -1);
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "variant"),
  /* @__PURE__ */ createTextVNode(" prop gives you easy access to several different button styles. Available variants are: "),
  /* @__PURE__ */ createBaseVNode("strong", null, "elevated"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "flat"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "tonal"),
  /* @__PURE__ */ createTextVNode(" (default), "),
  /* @__PURE__ */ createBaseVNode("strong", null, "outlined"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "text"),
  /* @__PURE__ */ createTextVNode(", and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "plain"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Value"),
    /* @__PURE__ */ createBaseVNode("th", null, "Example"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "elevated")
], -1);
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("td", null, "Elevates the chip with a shadow", -1);
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "flat")
], -1);
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("td", null, "Removes chip shadow", -1);
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "tonal")
], -1);
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("td", null, "Background color is a lowered opacity of the current text color", -1);
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "outlined")
], -1);
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("td", null, "Applies a thin border with the current text color", -1);
const _hoisted_28 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "text")
], -1);
const _hoisted_29 = /* @__PURE__ */ createBaseVNode("td", null, "Removes the background and removes shadow", -1);
const _hoisted_30 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "plain")
], -1);
const _hoisted_31 = /* @__PURE__ */ createBaseVNode("td", null, "Removes the background and lowers the opacity until hovered", -1);
const _hoisted_32 = { id: "size-and-density" };
const _hoisted_33 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Chips can have various sizes from "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "x-small"),
  /* @__PURE__ */ createTextVNode(" to "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "x-large"),
  /* @__PURE__ */ createTextVNode(". "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "density"),
  /* @__PURE__ */ createTextVNode(" is used to adjust the vertical spacing without affecting width or font size.")
], -1);
const _hoisted_34 = { id: "draggable" };
const _hoisted_35 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "draggable"),
  /* @__PURE__ */ createTextVNode(),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-chip"),
  /* @__PURE__ */ createTextVNode(" component can be dragged by mouse.")
], -1);
const _hoisted_36 = { id: "label" };
const _hoisted_37 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Label chips use the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-card"),
  /* @__PURE__ */ createTextVNode(" border-radius.")
], -1);
const _hoisted_38 = { id: "no-ripple" };
const _hoisted_39 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-chip"),
  /* @__PURE__ */ createTextVNode(" can be rendered without ripple if "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "ripple"),
  /* @__PURE__ */ createTextVNode(" prop is set to "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "false"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_40 = { id: "outlined" };
const _hoisted_41 = /* @__PURE__ */ createBaseVNode("p", null, "Outlined chips inherit their border color from the current text color.", -1);
const _hoisted_42 = { id: "slots" };
const _hoisted_43 = { id: "icon" };
const _hoisted_44 = /* @__PURE__ */ createBaseVNode("p", null, "Chips can use text or any icon available in the Material Icons font library.", -1);
const _hoisted_45 = { id: "examples" };
const _hoisted_46 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The following are a collection of examples that demonstrate more advanced and real world use of the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-chip"),
  /* @__PURE__ */ createTextVNode(" component.")
], -1);
const _hoisted_47 = { id: "action-chips" };
const _hoisted_48 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Chips can be used as actionable items. Provided with a "),
  /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "click"),
  /* @__PURE__ */ createTextVNode(" event, the chip becomes interactive and can invoke methods.")
], -1);
const _hoisted_49 = { id: "custom-list" };
const _hoisted_50 = { id: "expandable" };
const _hoisted_51 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Chips can be combined with "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-menu"),
  /* @__PURE__ */ createTextVNode(" to enable a specific set of actions for a chip.")
], -1);
const _hoisted_52 = { id: "filtering" };
const _hoisted_53 = /* @__PURE__ */ createBaseVNode("p", null, "Chips are great for providing supplementary actions to a particular task. In this instance, we are searching a list of items and collecting a subset of information to display available keywords.", -1);
const _hoisted_54 = { id: "in-selects" };
const _hoisted_55 = /* @__PURE__ */ createBaseVNode("p", null, "Selects can use chips to display the selected data. Try adding your own tags below.", -1);
const frontmatter = { "meta": { "nav": "Chips", "title": "Chip component", "description": "The chip component allows a user to enter information, make selections, filter content or trigger actions.", "keywords": "chips, vuetify chip component, vue chip component" }, "related": ["/components/avatars", "/components/icons", "/components/selects"], "features": { "figma": true, "github": "/components/VChip/", "label": "C: VChip", "report": true, "spec": "https://m2.material.io/components/chips" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "chips",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Chips", "title": "Chip component", "description": "The chip component allows a user to enter information, make selections, filter content or trigger actions.", "keywords": "chips, vuetify chip component, vue chip component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Chips", "title": "Chip component", "description": "The chip component allows a user to enter information, make selections, filter content or trigger actions.", "keywords": "chips, vuetify chip component, vue chip component" }, "related": ["/components/avatars", "/components/icons", "/components/selects"], "features": { "figma": true, "github": "/components/VChip/", "label": "C: VChip", "report": true, "spec": "https://m2.material.io/components/chips" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_figure = resolveComponent("app-figure");
      const _component_page_features = resolveComponent("page-features");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_v_chip = resolveComponent("v-chip");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#chips",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Chips")
                ]),
                _: 1
              }),
              createBaseVNode("p", null, [
                createTextVNode("The "),
                _hoisted_2,
                createTextVNode(" component is used to convey small pieces of information. Using the "),
                _hoisted_3,
                createTextVNode(" property, the chip becomes interactive, allowing user interaction. This component is used by the "),
                createVNode(_component_app_link, { href: "/components/chip-groups" }, {
                  default: withCtx(() => [
                    createTextVNode("v-chip-group")
                  ]),
                  _: 1
                }),
                createTextVNode(" for advanced selection options.")
              ]),
              createBaseVNode("p", null, [
                createBaseVNode("div", null, [
                  createVNode(_component_app_figure, {
                    alt: "Chips Entry",
                    src: "https://cdn.vuetifyjs.com/docs/images/components/v-chip/v-chip-entry.png"
                  })
                ])
              ]),
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_4, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_5,
                createVNode(_component_examples_usage, { name: "v-chip" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_6, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_7,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-chip/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-chip")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_8
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_9, [
                createVNode(_component_app_heading, {
                  href: "#guide",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Guide")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("The "),
                  _hoisted_10,
                  createTextVNode(" component is used to convey small pieces of information. Using the "),
                  _hoisted_11,
                  createTextVNode(" property, the chip becomes interactive, allowing user interaction. This component is used by the "),
                  createVNode(_component_app_link, { href: "/components/chip-groups" }, {
                    default: withCtx(() => [
                      createTextVNode("v-chip-group")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" for advanced selection options.")
                ]),
                createBaseVNode("section", _hoisted_12, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("p", null, [
                    createTextVNode("Similar to other components such as "),
                    createVNode(_component_app_link, { href: "/components/buttons/" }, {
                      default: withCtx(() => [
                        createTextVNode("v-btn")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" and "),
                    createVNode(_component_app_link, { href: "/components/lists/" }, {
                      default: withCtx(() => [
                        createTextVNode("v-list")
                      ]),
                      _: 1
                    }),
                    createTextVNode(", the "),
                    _hoisted_13,
                    createTextVNode(" component has a large selection of props for customizing the appearance.")
                  ]),
                  createBaseVNode("section", _hoisted_14, [
                    createVNode(_component_app_heading, {
                      href: "#closable",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Closable")
                      ]),
                      _: 1
                    }),
                    _hoisted_15,
                    createVNode(_component_examples_example, { file: "v-chip/prop-closable" })
                  ]),
                  createBaseVNode("section", _hoisted_16, [
                    createVNode(_component_app_heading, {
                      href: "#color-and-variants",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Color and variants")
                      ]),
                      _: 1
                    }),
                    _hoisted_17,
                    createVNode(_component_examples_example, { file: "v-chip/prop-colored" }),
                    _hoisted_18,
                    createVNode(_component_app_table, null, {
                      default: withCtx(() => [
                        _hoisted_19,
                        createBaseVNode("tbody", null, [
                          createBaseVNode("tr", null, [
                            _hoisted_20,
                            createBaseVNode("td", null, [
                              createVNode(_component_v_chip, {
                                color: "primary",
                                variant: "elevated"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("Chip")
                                ]),
                                _: 1
                              })
                            ]),
                            _hoisted_21
                          ]),
                          createBaseVNode("tr", null, [
                            _hoisted_22,
                            createBaseVNode("td", null, [
                              createVNode(_component_v_chip, {
                                color: "primary",
                                variant: "flat"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("Chip")
                                ]),
                                _: 1
                              })
                            ]),
                            _hoisted_23
                          ]),
                          createBaseVNode("tr", null, [
                            _hoisted_24,
                            createBaseVNode("td", null, [
                              createVNode(_component_v_chip, {
                                color: "primary",
                                variant: "tonal"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("Chip")
                                ]),
                                _: 1
                              })
                            ]),
                            _hoisted_25
                          ]),
                          createBaseVNode("tr", null, [
                            _hoisted_26,
                            createBaseVNode("td", null, [
                              createVNode(_component_v_chip, {
                                color: "primary",
                                variant: "outlined"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("Chip")
                                ]),
                                _: 1
                              })
                            ]),
                            _hoisted_27
                          ]),
                          createBaseVNode("tr", null, [
                            _hoisted_28,
                            createBaseVNode("td", null, [
                              createVNode(_component_v_chip, {
                                color: "primary",
                                variant: "text"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("Chip")
                                ]),
                                _: 1
                              })
                            ]),
                            _hoisted_29
                          ]),
                          createBaseVNode("tr", null, [
                            _hoisted_30,
                            createBaseVNode("td", null, [
                              createVNode(_component_v_chip, {
                                color: "primary",
                                variant: "plain"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("Chip")
                                ]),
                                _: 1
                              })
                            ]),
                            _hoisted_31
                          ])
                        ])
                      ]),
                      _: 1
                    })
                  ]),
                  createBaseVNode("section", _hoisted_32, [
                    createVNode(_component_app_heading, {
                      href: "#size-and-density",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Size and density")
                      ]),
                      _: 1
                    }),
                    _hoisted_33,
                    createVNode(_component_examples_example, { file: "v-chip/prop-sizes" })
                  ]),
                  createBaseVNode("section", _hoisted_34, [
                    createVNode(_component_app_heading, {
                      href: "#draggable",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Draggable")
                      ]),
                      _: 1
                    }),
                    _hoisted_35,
                    createVNode(_component_examples_example, { file: "v-chip/prop-draggable" })
                  ]),
                  createBaseVNode("section", _hoisted_36, [
                    createVNode(_component_app_heading, {
                      href: "#label",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Label")
                      ]),
                      _: 1
                    }),
                    _hoisted_37,
                    createVNode(_component_examples_example, { file: "v-chip/prop-label" })
                  ]),
                  createBaseVNode("section", _hoisted_38, [
                    createVNode(_component_app_heading, {
                      href: "#no-ripple",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("No ripple")
                      ]),
                      _: 1
                    }),
                    _hoisted_39,
                    createVNode(_component_examples_example, { file: "v-chip/prop-no-ripple" })
                  ]),
                  createBaseVNode("section", _hoisted_40, [
                    createVNode(_component_app_heading, {
                      href: "#outlined",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Outlined")
                      ]),
                      _: 1
                    }),
                    _hoisted_41,
                    createVNode(_component_examples_example, { file: "v-chip/prop-outlined" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_42, [
                  createVNode(_component_app_heading, {
                    href: "#slots",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Slots")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_43, [
                    createVNode(_component_app_heading, {
                      href: "#icon",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Icon")
                      ]),
                      _: 1
                    }),
                    _hoisted_44,
                    createVNode(_component_examples_example, { file: "v-chip/slot-icon" })
                  ])
                ])
              ]),
              createBaseVNode("section", _hoisted_45, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                _hoisted_46,
                createBaseVNode("section", _hoisted_47, [
                  createVNode(_component_app_heading, {
                    href: "#action-chips",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Action chips")
                    ]),
                    _: 1
                  }),
                  _hoisted_48,
                  createVNode(_component_examples_example, { file: "v-chip/event-action-chips" }),
                  createBaseVNode("section", _hoisted_49, [
                    createVNode(_component_app_heading, {
                      href: "#custom-list",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Custom list")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("In this example we opt to use a customized list instead of "),
                      createVNode(_component_app_link, { href: "/components/autocompletes" }, {
                        default: withCtx(() => [
                          createTextVNode("v-autocomplete")
                        ]),
                        _: 1
                      }),
                      createTextVNode(". This allows us to always display the options available while still providing the same functionality of search and selection.")
                    ]),
                    createVNode(_component_examples_example, { file: "v-chip/misc-custom-list" })
                  ]),
                  createBaseVNode("section", _hoisted_50, [
                    createVNode(_component_app_heading, {
                      href: "#expandable",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Expandable")
                      ]),
                      _: 1
                    }),
                    _hoisted_51,
                    createVNode(_component_examples_example, { file: "v-chip/misc-expandable" })
                  ]),
                  createBaseVNode("section", _hoisted_52, [
                    createVNode(_component_app_heading, {
                      href: "#filtering",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Filtering")
                      ]),
                      _: 1
                    }),
                    _hoisted_53,
                    createVNode(_component_examples_example, { file: "v-chip/misc-filtering" })
                  ]),
                  createBaseVNode("section", _hoisted_54, [
                    createVNode(_component_app_heading, {
                      href: "#in-selects",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("In selects")
                      ]),
                      _: 1
                    }),
                    _hoisted_55,
                    createVNode(_component_examples_example, { file: "v-chip/misc-in-selects" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
