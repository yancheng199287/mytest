import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "click-outside" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-click-outside"),
  /* @__PURE__ */ createTextVNode(" directive calls a function when something outside of the target element is clicked on. This is used internally by components like "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-menu"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-dialog"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-click-outside"),
  /* @__PURE__ */ createTextVNode(" directive allows you to provide a handler to be invoked when the user clicks outside of the target element.")
], -1);
const _hoisted_5 = { id: "api" };
const _hoisted_6 = { id: "examples" };
const _hoisted_7 = { id: "options" };
const _hoisted_8 = { id: "close-conditional" };
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Optionally provide a "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "closeConditional"),
  /* @__PURE__ */ createTextVNode(" handler that returns "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "true"),
  /* @__PURE__ */ createTextVNode(" or "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "false"),
  /* @__PURE__ */ createTextVNode(". This function determines whether the outside click function is invoked or not.")
], -1);
const _hoisted_10 = { id: "include" };
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Optionally provide an "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "include"),
  /* @__PURE__ */ createTextVNode(" function in the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "options"),
  /* @__PURE__ */ createTextVNode(" object that returns an array of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "HTMLElement"),
  /* @__PURE__ */ createTextVNode("s. This function determines which additional elements that the click must be outside of, for the handler to be called.")
], -1);
const frontmatter = { "meta": { "nav": "Click outside", "title": "Click outside directive", "description": "The v-click-outside directive calls a function when something outside of the target element is clicked on.,", "keywords": "click outside, click directive, vue click directive, vuetify click directives" }, "related": ["/components/dialogs/", "/components/navigation-drawers/", "/directives/intersect/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "click-outside",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Click outside", "title": "Click outside directive", "description": "The v-click-outside directive calls a function when something outside of the target element is clicked on.,", "keywords": "click outside, click directive, vue click directive, vuetify click directives" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Click outside", "title": "Click outside directive", "description": "The v-click-outside directive calls a function when something outside of the target element is clicked on.,", "keywords": "click outside, click directive, vue click directive, vuetify click directives" }, "related": ["/components/dialogs/", "/components/navigation-drawers/", "/directives/intersect/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#click-outside",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Click outside")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_promoted_entry),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_example, { file: "v-click-outside/usage" })
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline)
              ]),
              createBaseVNode("section", _hoisted_6, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_7, [
                  createVNode(_component_app_heading, {
                    href: "#options",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Options")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_8, [
                    createVNode(_component_app_heading, {
                      href: "#close-conditional",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Close conditional")
                      ]),
                      _: 1
                    }),
                    _hoisted_9,
                    createVNode(_component_examples_example, { file: "v-click-outside/option-close-on-outside-click" })
                  ]),
                  createBaseVNode("section", _hoisted_10, [
                    createVNode(_component_app_heading, {
                      href: "#include",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Include")
                      ]),
                      _: 1
                    }),
                    _hoisted_11,
                    createVNode(_component_examples_example, { file: "v-click-outside/option-include" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
