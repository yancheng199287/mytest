import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "code-of-conduct" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("em", null, "Code of Conduct", -1);
const _hoisted_3 = { id: "our-pledge" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, "In the interest of fostering an open and welcoming environment, we as contributors and maintainers pledge to making participation in our project and our community a harassment-free experience for everyone, regardless of age, body size, disability, ethnicity, gender identity and expression, level of experience, nationality, personal appearance, race, religion, or sexual identity and orientation.", -1);
const _hoisted_5 = { id: "our-standards" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("p", null, "Examples of behavior that contributes to creating a positive environment include:", -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, "Using welcoming and inclusive language"),
  /* @__PURE__ */ createBaseVNode("li", null, "Being respectful of differing viewpoints and experiences"),
  /* @__PURE__ */ createBaseVNode("li", null, "Gracefully accepting constructive criticism"),
  /* @__PURE__ */ createBaseVNode("li", null, "Focusing on what is best for the community"),
  /* @__PURE__ */ createBaseVNode("li", null, "Showing empathy towards other community members")
], -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("p", null, "Examples of unacceptable behavior by participants include:", -1);
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, "The use of sexualized language or imagery and unwelcome sexual attention or advances"),
  /* @__PURE__ */ createBaseVNode("li", null, "Trolling, insulting/derogatory comments, and personal or political attacks"),
  /* @__PURE__ */ createBaseVNode("li", null, "Public or private harassment"),
  /* @__PURE__ */ createBaseVNode("li", null, "Publishing others’ private information, such as a physical or electronic address, without explicit permission"),
  /* @__PURE__ */ createBaseVNode("li", null, "Other conduct which could reasonably be considered inappropriate in a professional setting")
], -1);
const _hoisted_10 = { id: "our-responsibilities" };
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("p", null, "Project maintainers are responsible for clarifying the standards of acceptable behavior and are expected to take appropriate and fair corrective action in response to any instances of unacceptable behavior.", -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("p", null, "Project maintainers have the right and responsibility to remove, edit, or reject comments, commits, code, wiki edits, issues, and other contributions that are not aligned to this Code of Conduct, or to ban temporarily or permanently any contributor for other behaviors that they deem inappropriate, threatening, offensive, or harmful.", -1);
const _hoisted_13 = { id: "scope" };
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("p", null, "This Code of Conduct applies both within project spaces and in public spaces when an individual is representing the project or its community. Examples of representing a project or community include using an official project e-mail address, posting via an official social media account, or acting as an appointed representative at an online or offline event. Representation of a project may be further defined and clarified by project maintainers.", -1);
const _hoisted_15 = { id: "enforcement" };
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("p", null, "Project maintainers who do not follow or enforce the Code of Conduct in good faith may face temporary or permanent repercussions as determined by other members of the project’s leadership.", -1);
const _hoisted_17 = { id: "attribution" };
const frontmatter = { "meta": { "title": "Code of conduct", "description": "Vuetify provides a safe, inclusive, and judgement free community for developers from all walks of life!", "keywords": "vuetify code of conduct, vuetify coc, community conduct" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "code-of-conduct",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "Code of conduct", "description": "Vuetify provides a safe, inclusive, and judgement free community for developers from all walks of life!", "keywords": "vuetify code of conduct, vuetify coc, community conduct" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "title": "Code of conduct", "description": "Vuetify provides a safe, inclusive, and judgement free community for developers from all walks of life!", "keywords": "vuetify code of conduct, vuetify coc, community conduct" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_app_link = resolveComponent("app-link");
      const _component_page_features = resolveComponent("page-features");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#code-of-conduct",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Code of conduct")
                ]),
                _: 1
              }),
              createBaseVNode("p", null, [
                createTextVNode("For questions or concerns regarding our "),
                _hoisted_2,
                createTextVNode(", please reach out to us at "),
                createVNode(_component_app_link, { href: "mailto:support@vuetifyjs.com" }, {
                  default: withCtx(() => [
                    createTextVNode("support@vuetifyjs.com")
                  ]),
                  _: 1
                }),
                createTextVNode(".")
              ]),
              createVNode(_component_page_features),
              createVNode(_component_promoted_entry),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#our-pledge",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Our Pledge")
                  ]),
                  _: 1
                }),
                _hoisted_4
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#our-standards",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Our Standards")
                  ]),
                  _: 1
                }),
                _hoisted_6,
                _hoisted_7,
                _hoisted_8,
                _hoisted_9
              ]),
              createBaseVNode("section", _hoisted_10, [
                createVNode(_component_app_heading, {
                  href: "#our-responsibilities",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Our Responsibilities")
                  ]),
                  _: 1
                }),
                _hoisted_11,
                _hoisted_12
              ]),
              createBaseVNode("section", _hoisted_13, [
                createVNode(_component_app_heading, {
                  href: "#scope",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Scope")
                  ]),
                  _: 1
                }),
                _hoisted_14
              ]),
              createBaseVNode("section", _hoisted_15, [
                createVNode(_component_app_heading, {
                  href: "#enforcement",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Enforcement")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("Instances of abusive, harassing, or otherwise unacceptable behavior may be reported by contacting the project team at "),
                  createVNode(_component_app_link, { href: "mailto:hello@vuetifyjs.com" }, {
                    default: withCtx(() => [
                      createTextVNode("hello@vuetifyjs.com")
                    ]),
                    _: 1
                  }),
                  createTextVNode(". The project team will review and investigate all complaints, and will respond in a way that it deems appropriate to the circumstances. The project team is obligated to maintain confidentiality with regard to the reporter of an incident. Further details of specific enforcement policies may be posted separately.")
                ]),
                _hoisted_16
              ]),
              createBaseVNode("section", _hoisted_17, [
                createVNode(_component_app_heading, {
                  href: "#attribution",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Attribution")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("This Code of Conduct is adapted from the "),
                  createVNode(_component_app_link, { href: "https://contributor-covenant.org" }, {
                    default: withCtx(() => [
                      createTextVNode("Contributor Covenant")
                    ]),
                    _: 1
                  }),
                  createTextVNode(", version 1.4, available at "),
                  createVNode(_component_app_link, { href: "https://contributor-covenant.org/version/1/4/" }, {
                    default: withCtx(() => [
                      createTextVNode("https://contributor-covenant.org/version/1/4")
                    ]),
                    _: 1
                  })
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
