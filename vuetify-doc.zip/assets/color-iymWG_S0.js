import { y as _export_sfc, o as openBlock, l as createElementBlock, e as createBaseVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _sfc_main$1 = {};
const _hoisted_1$1 = { class: "bg-purple-darken-2 text-center" };
const _hoisted_2$1 = /* @__PURE__ */ createBaseVNode("span", null, "Lorem ipsum", -1);
const _hoisted_3 = [
  _hoisted_2$1
];
function _sfc_render$1(_ctx, _cache) {
  return openBlock(), createElementBlock("div", _hoisted_1$1, _hoisted_3);
}
const __0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["render", _sfc_render$1]]);
const __0_raw = '<template>\n  <div class="bg-purple-darken-2 text-center">\n    <span>Lorem ipsum</span>\n  </div>\n</template>\n';
const _sfc_main = {};
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("strong", { class: "text-red-lighten-1" }, "inciderint", -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("span", { class: "text-indigo-darken-2" }, "Amet causae probatus nec ex", -1);
function _sfc_render(_ctx, _cache) {
  return openBlock(), createElementBlock("div", null, [
    createTextVNode(" Lorem ipsum dolor sit amet, "),
    _hoisted_1,
    createTextVNode(" definitionem est ea, explicari prodesset eam id. Mazim doctus vix an. "),
    _hoisted_2,
    createTextVNode(". ")
  ]);
}
const __1 = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
const __1_raw = '<template>\n  <div>\n    Lorem ipsum dolor sit amet, <strong class="text-red-lighten-1">inciderint</strong> definitionem est ea, explicari prodesset eam id. Mazim doctus vix an. <span class="text-indigo-darken-2">Amet causae probatus nec ex</span>.\n  </div>\n</template>\n';
const color = {
  "classes": {
    component: __0,
    source: __0_raw
  },
  "text-classes": {
    component: __1,
    source: __1_raw
  }
};
export {
  color as default
};
