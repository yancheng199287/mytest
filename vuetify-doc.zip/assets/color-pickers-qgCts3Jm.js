import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "color-pickers" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-color-picker"),
  /* @__PURE__ */ createTextVNode(" allows you to select a color using a variety of input methods.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = { id: "api" };
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("td", null, "Primary component", -1);
const _hoisted_7 = { id: "examples" };
const _hoisted_8 = { id: "props" };
const _hoisted_9 = { id: "customizing-the-look-of-the-picker" };
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("p", null, "There are a number of props available to help you customize the component by hiding or showing the various parts of the picker. You can independently hide the canvas, the sliders, and the inputs. You can also show a collection of swatches.", -1);
const _hoisted_11 = { id: "elevation" };
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Adjust the elevation of the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-color-picker"),
  /* @__PURE__ */ createTextVNode(" component using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "elevation"),
  /* @__PURE__ */ createTextVNode(" or "),
  /* @__PURE__ */ createBaseVNode("strong", null, "flat"),
  /* @__PURE__ */ createTextVNode(" prop. The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "flat"),
  /* @__PURE__ */ createTextVNode(" is equivalent to setting "),
  /* @__PURE__ */ createBaseVNode("strong", null, "elevation"),
  /* @__PURE__ */ createTextVNode(" to 0.")
], -1);
const _hoisted_13 = { id: "mode" };
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can specify which input modes are available to your users with the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "modes"),
  /* @__PURE__ */ createTextVNode(" prop. If you only set a single mode, then the mode toggle will automatically be hidden. You can also control the current mode with the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "mode"),
  /* @__PURE__ */ createTextVNode(" v-model.")
], -1);
const _hoisted_15 = { id: "model" };
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-color-picker"),
  /* @__PURE__ */ createTextVNode(" uses the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-model"),
  /* @__PURE__ */ createTextVNode(" prop to control the color displayed. It supports hex strings such as "),
  /* @__PURE__ */ createBaseVNode("strong", null, "#FF00FF"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "#FF00FF00"),
  /* @__PURE__ */ createTextVNode(", and objects representing "),
  /* @__PURE__ */ createBaseVNode("strong", null, "RGBA"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "HSLA"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "HSVA"),
  /* @__PURE__ */ createTextVNode(" values. The component will try to emit the color in the same format that was provided. If the value is null, then the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-color-picker"),
  /* @__PURE__ */ createTextVNode(" will default to emitting hex colors.")
], -1);
const _hoisted_17 = { id: "swatches" };
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Using the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "show-swatches"),
  /* @__PURE__ */ createTextVNode(" prop you can display an array of color swatches that users can pick from. It is also possible to customize what colors are shown using the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "swatches"),
  /* @__PURE__ */ createTextVNode(" prop. This prop accepts a two-dimensional array, where the first dimension defines a column, and second dimension defines the swatches from top to bottom by providing rgba hex strings. You can also set the max height of the swatches section with the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "swatches-max-height"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const frontmatter = { "meta": { "nav": "Color pickers", "title": "Color picker component", "description": "The color picker component allows users to select a from pre-defined or custom colors using a variety of different inputs and formats.", "keywords": "color pickers, vuetify color picker component, vue color picker component" }, "related": ["/components/menus/", "/styles/colors/", "/features/theme/"], "features": { "github": "/components/VColorPicker/", "label": "C: VColorPicker", "report": true } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "color-pickers",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Color pickers", "title": "Color picker component", "description": "The color picker component allows users to select a from pre-defined or custom colors using a variety of different inputs and formats.", "keywords": "color pickers, vuetify color picker component, vue color picker component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Color pickers", "title": "Color picker component", "description": "The color picker component allows users to select a from pre-defined or custom colors using a variety of different inputs and formats.", "keywords": "color pickers, vuetify color picker component, vue color picker component" }, "related": ["/components/menus/", "/styles/colors/", "/features/theme/"], "features": { "github": "/components/VColorPicker/", "label": "C: VColorPicker", "report": true } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#color-pickers",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Color pickers")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                createVNode(_component_examples_usage, { name: "v-color-picker" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_4, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_5,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-color-picker/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-color-picker")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_6
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_7, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_8, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_9, [
                    createVNode(_component_app_heading, {
                      href: "#customizing-the-look-of-the-picker",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Customizing the look of the picker")
                      ]),
                      _: 1
                    }),
                    _hoisted_10,
                    createVNode(_component_examples_example, { file: "v-color-picker/prop-canvas" })
                  ]),
                  createBaseVNode("section", _hoisted_11, [
                    createVNode(_component_app_heading, {
                      href: "#elevation",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Elevation")
                      ]),
                      _: 1
                    }),
                    _hoisted_12,
                    createVNode(_component_examples_example, { file: "v-color-picker/prop-elevation" })
                  ]),
                  createBaseVNode("section", _hoisted_13, [
                    createVNode(_component_app_heading, {
                      href: "#mode",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Mode")
                      ]),
                      _: 1
                    }),
                    _hoisted_14,
                    createVNode(_component_examples_example, { file: "v-color-picker/prop-mode" })
                  ]),
                  createBaseVNode("section", _hoisted_15, [
                    createVNode(_component_app_heading, {
                      href: "#model",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Model")
                      ]),
                      _: 1
                    }),
                    _hoisted_16,
                    createVNode(_component_examples_example, { file: "v-color-picker/prop-model" })
                  ]),
                  createBaseVNode("section", _hoisted_17, [
                    createVNode(_component_app_heading, {
                      href: "#swatches",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Swatches")
                      ]),
                      _: 1
                    }),
                    _hoisted_18,
                    createVNode(_component_examples_example, { file: "v-color-picker/prop-swatches" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
