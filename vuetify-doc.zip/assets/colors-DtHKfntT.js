import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "colors" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("strong", null, "sass", -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("strong", null, "javascript", -1);
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("strong", null, "color", -1);
const _hoisted_5 = { id: "classes" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("strong", null, "background", -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("strong", null, "text", -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, '<div class="bg-red">', -1);
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, '<span class="text-red">', -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Text colors also support "),
  /* @__PURE__ */ createBaseVNode("strong", null, "darken"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "lighten"),
  /* @__PURE__ */ createTextVNode(" variants using "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "text-{color}-{lighten|darken}-{n}")
], -1);
const _hoisted_11 = { id: "javascript-color-pack" };
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("p", null, "Vuetify has an optional javascript color pack that you can import and use within your application. This can also be used to help define your application’s theme.", -1);
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-js" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/plugins/vuetify.js",
    class: "language-js"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" createVuetify "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify'"),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(" colors "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify/util/colors'"),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "export"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "default"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "createVuetify"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "theme"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "themes"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "light"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n        "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "dark"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n        "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "colors"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n          "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "primary"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(" colors"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "."),
    /* @__PURE__ */ createTextVNode("red"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "."),
    /* @__PURE__ */ createTextVNode("darken1"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// #E53935"),
    /* @__PURE__ */ createTextVNode("\n          "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "secondary"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(" colors"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "."),
    /* @__PURE__ */ createTextVNode("red"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "."),
    /* @__PURE__ */ createTextVNode("lighten4"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// #FFCDD2"),
    /* @__PURE__ */ createTextVNode("\n          "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "..."),
    /* @__PURE__ */ createTextVNode("\n        "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_14 = { id: "sass-color-pack" };
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("strong", null, "theme", -1);
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code text-no-wrap" }, "$color-pack: false", -1);
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-scss" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "main.scss",
    class: "language-scss"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "@use"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify'"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token module-modifier keyword" }, "with"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token variable" }, "$color-pack")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ";"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_18 = { id: "material-colors" };
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("p", null, "Below is a list of the Material design color palette grouped by primary color", -1);
const frontmatter = { "meta": { "title": "Material color palette", "description": "Learn about the colors of Material Design. Consume the javascript color pack directly in your application.", "keywords": "colors, material design colors, vuetify color pack, material color classes" }, "related": ["/features/theme/", "/resources/themes/", "/getting-started/wireframes/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "colors",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "Material color palette", "description": "Learn about the colors of Material Design. Consume the javascript color pack directly in your application.", "keywords": "colors, material design colors, vuetify color pack, material color classes" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "title": "Material color palette", "description": "Learn about the colors of Material Design. Consume the javascript color pack directly in your application.", "keywords": "colors, material design colors, vuetify color pack, material color classes" }, "related": ["/features/theme/", "/resources/themes/", "/getting-started/wireframes/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_app_link = resolveComponent("app-link");
      const _component_page_features = resolveComponent("page-features");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_app_markup = resolveComponent("app-markup");
      const _component_features_color_palette = resolveComponent("features-color-palette");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#colors",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Colors")
                ]),
                _: 1
              }),
              createBaseVNode("p", null, [
                createTextVNode("Out of the box you get access to all colors in the "),
                createVNode(_component_app_link, { href: "https://material.io/design/color/the-color-system.html" }, {
                  default: withCtx(() => [
                    createTextVNode("Material Design specification")
                  ]),
                  _: 1
                }),
                createTextVNode(" through "),
                _hoisted_2,
                createTextVNode(" and "),
                _hoisted_3,
                createTextVNode(". These values can be used within your style sheets, your component files and on actual components via the "),
                _hoisted_4,
                createTextVNode(" prop.")
              ]),
              createVNode(_component_page_features),
              createVNode(_component_promoted_entry),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#classes",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Classes")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("Each color from the specification gets converted to a "),
                  _hoisted_6,
                  createTextVNode(" and "),
                  _hoisted_7,
                  createTextVNode(" variant for styling within your application through a class, e.g. "),
                  _hoisted_8,
                  createTextVNode(" or "),
                  _hoisted_9,
                  createTextVNode(". These class colors are defined "),
                  createVNode(_component_app_link, { href: "https://github.com/vuetifyjs/vuetify/blob/master/packages/vuetify/src/styles/settings/_colors.scss" }, {
                    default: withCtx(() => [
                      createTextVNode("here")
                    ]),
                    _: 1
                  }),
                  createTextVNode(".")
                ]),
                createVNode(_component_examples_example, { file: "color/classes" }),
                _hoisted_10,
                createVNode(_component_examples_example, { file: "color/text-classes" })
              ]),
              createBaseVNode("section", _hoisted_11, [
                createVNode(_component_app_heading, {
                  href: "#javascript-color-pack",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Javascript color pack")
                  ]),
                  _: 1
                }),
                _hoisted_12,
                createVNode(_component_app_markup, {
                  resource: "src/plugins/vuetify.js",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_13
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_14, [
                createVNode(_component_app_heading, {
                  href: "#sass-color-pack",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Sass color pack")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("While convenient, the color pack increases the CSS export size by ~30kb. Some projects may only require the classes that are created at runtime from the Vuetify "),
                  _hoisted_15,
                  createTextVNode(" system. To disable the color pack feature, follow "),
                  createVNode(_component_app_link, { href: "/features/sass-variables" }, {
                    default: withCtx(() => [
                      createTextVNode("sass variables")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" and set "),
                  _hoisted_16,
                  createTextVNode(".")
                ]),
                createVNode(_component_app_markup, {
                  resource: "main.scss",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_17
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_18, [
                createVNode(_component_app_heading, {
                  href: "#material-colors",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Material colors")
                  ]),
                  _: 1
                }),
                _hoisted_19,
                createVNode(_component_features_color_palette)
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
