import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "combobox" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-combobox", -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("strong", null, "items", -1);
const _hoisted_4 = { id: "usage" };
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("p", null, "With Combobox, you can allow a user to create new values that may not be present in a provided items list.", -1);
const _hoisted_6 = { id: "api" };
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("td", null, "Primary component", -1);
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("td", null, "A select component that allows for advanced filtering", -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createTextVNode("A replacement for the HTML "),
  /* @__PURE__ */ createBaseVNode("select")
], -1);
const _hoisted_11 = { id: "caveats" };
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("strong", null, "always", -1);
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("This also means that a typed string will not select an item the same way clicking on it would, you may want to set "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, 'auto-select-first="exact"'),
  /* @__PURE__ */ createTextVNode(" when using object items.")
], -1);
const _hoisted_14 = { id: "examples" };
const _hoisted_15 = { id: "props" };
const _hoisted_16 = { id: "density" };
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can use "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "density"),
  /* @__PURE__ */ createTextVNode(" prop to adjust vertical spacing within the component.")
], -1);
const _hoisted_18 = { id: "multiple-combobox" };
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Previously known as "),
  /* @__PURE__ */ createBaseVNode("strong", null, "tags"),
  /* @__PURE__ */ createTextVNode(" - user is allowed to enter more than one value.")
], -1);
const _hoisted_20 = { id: "slots" };
const _hoisted_21 = { id: "no-data-with-chips" };
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("In this example we utilize a custom "),
  /* @__PURE__ */ createBaseVNode("strong", null, "no-data"),
  /* @__PURE__ */ createTextVNode(" slot to provide context to the user when searching / creating items.")
], -1);
const frontmatter = { "meta": { "nav": "Combobox", "title": "Combobox component", "description": "The combobox component provides type-ahead autocomplete functionality and allows users to provide a custom values beyond the provided list of options.", "keywords": "combobox, vuetify combobox component, vue combobox component" }, "related": ["/components/autocompletes/", "/components/forms/", "/components/selects/"], "features": { "figma": true, "label": "C: VCombobox", "report": true, "github": "/components/VCombobox/", "spec": "https://m2.material.io/components/text-fields" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "combobox",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Combobox", "title": "Combobox component", "description": "The combobox component provides type-ahead autocomplete functionality and allows users to provide a custom values beyond the provided list of options.", "keywords": "combobox, vuetify combobox component, vue combobox component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Combobox", "title": "Combobox component", "description": "The combobox component provides type-ahead autocomplete functionality and allows users to provide a custom values beyond the provided list of options.", "keywords": "combobox, vuetify combobox component, vue combobox component" }, "related": ["/components/autocompletes/", "/components/forms/", "/components/selects/"], "features": { "figma": true, "label": "C: VCombobox", "report": true, "github": "/components/VCombobox/", "spec": "https://m2.material.io/components/text-fields" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_app_link = resolveComponent("app-link");
      const _component_page_features = resolveComponent("page-features");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_alert = resolveComponent("alert");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#combobox",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Combobox")
                ]),
                _: 1
              }),
              createBaseVNode("p", null, [
                createTextVNode("The "),
                _hoisted_2,
                createTextVNode(" component is a "),
                createVNode(_component_app_link, { href: "/components/text-fields" }, {
                  default: withCtx(() => [
                    createTextVNode("v-text-field")
                  ]),
                  _: 1
                }),
                createTextVNode(" that allows the user to select values from a provided "),
                _hoisted_3,
                createTextVNode(" array, or to enter their own value. Created items will be returned as strings.")
              ]),
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_4, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_5,
                createVNode(_component_examples_usage, { name: "v-combobox" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_6, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_7,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-combobox/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-combobox")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_8
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-autocomplete/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-autocomplete")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_9
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-select/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-select")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_10
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_11, [
                createVNode(_component_app_heading, {
                  href: "#caveats",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Caveats")
                  ]),
                  _: 1
                }),
                createVNode(_component_alert, { type: "error" }, {
                  default: withCtx(() => [
                    createBaseVNode("p", null, [
                      createTextVNode("As the Combobox allows user input, it "),
                      _hoisted_12,
                      createTextVNode(" returns the full value provided to it (for example a list of Objects will always return an Object when selected). This is because there’s no way to tell if a value is supposed to be user input or an object lookup "),
                      createVNode(_component_app_link, { href: "https://github.com/vuetifyjs/vuetify/issues/5479" }, {
                        default: withCtx(() => [
                          createTextVNode("GitHub Issue")
                        ]),
                        _: 1
                      })
                    ]),
                    _hoisted_13
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_14, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_15, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_16, [
                    createVNode(_component_app_heading, {
                      href: "#density",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Density")
                      ]),
                      _: 1
                    }),
                    _hoisted_17,
                    createVNode(_component_examples_example, { file: "v-combobox/prop-density" })
                  ]),
                  createBaseVNode("section", _hoisted_18, [
                    createVNode(_component_app_heading, {
                      href: "#multiple-combobox",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Multiple combobox")
                      ]),
                      _: 1
                    }),
                    _hoisted_19,
                    createVNode(_component_examples_example, { file: "v-combobox/prop-multiple" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_20, [
                  createVNode(_component_app_heading, {
                    href: "#slots",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Slots")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_21, [
                    createVNode(_component_app_heading, {
                      href: "#no-data-with-chips",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("No data with chips")
                      ]),
                      _: 1
                    }),
                    _hoisted_22,
                    createVNode(_component_examples_example, { file: "v-combobox/slot-no-data" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
