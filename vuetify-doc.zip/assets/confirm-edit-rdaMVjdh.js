import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "confirm-edit" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-confirm-edit"),
  /* @__PURE__ */ createTextVNode(" component is used to allow the user to verify their changes before they are committed.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = { id: "api" };
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_7 = { id: "guide" };
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-confirm-edit"),
  /* @__PURE__ */ createTextVNode(" component is an intuitive way to capture a model’s changes before they are committed. This is useful when you want to prevent accidental changes or to allow the user to cancel their changes.")
], -1);
const _hoisted_9 = { id: "pickers" };
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("It’s easy to integrate pickers into the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-confirm-edit"),
  /* @__PURE__ */ createTextVNode(" component. This allows you to provide a more user-friendly experience when selecting dates, times, or colors.")
], -1);
const frontmatter = { "emphasized": true, "meta": { "nav": "Confirm Edit", "title": "Confirm Edit", "description": "The confirm edit component is used to allow the user to verify their changes before they are committed. This is useful when you want to prevent accidental changes or to allow the user to cancel their changes.", "keywords": "v-confirm-edit, confirm edit, vuetify confirm edit, vuetify confirm edit component, vuetify confirm edit examples" }, "related": ["/components/avatars/", "/components/icons/", "/components/toolbars/"], "features": { "github": "/components/VConfirmEdit/", "label": "C: VConfirmEdit", "report": true } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "confirm-edit",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Confirm Edit", "title": "Confirm Edit", "description": "The confirm edit component is used to allow the user to verify their changes before they are committed. This is useful when you want to prevent accidental changes or to allow the user to cancel their changes.", "keywords": "v-confirm-edit, confirm edit, vuetify confirm edit, vuetify confirm edit component, vuetify confirm edit examples" } };
    useHead(head);
    __expose({ frontmatter: { "emphasized": true, "meta": { "nav": "Confirm Edit", "title": "Confirm Edit", "description": "The confirm edit component is used to allow the user to verify their changes before they are committed. This is useful when you want to prevent accidental changes or to allow the user to cancel their changes.", "keywords": "v-confirm-edit, confirm edit, vuetify confirm edit, vuetify confirm edit component, vuetify confirm edit examples" }, "related": ["/components/avatars/", "/components/icons/", "/components/toolbars/"], "features": { "github": "/components/VConfirmEdit/", "label": "C: VConfirmEdit", "report": true } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_app_link = resolveComponent("app-link");
      const _component_alert = resolveComponent("alert");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#confirm-edit",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Confirm edit")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_alert, { type: "success" }, {
                default: withCtx(() => [
                  createBaseVNode("p", null, [
                    createTextVNode("This feature was introduced in "),
                    createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v3.6.0" }, {
                      default: withCtx(() => [
                        createTextVNode("v3.6.0")
                      ]),
                      _: 1
                    })
                  ])
                ]),
                _: 1
              }),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                createVNode(_component_examples_usage, { name: "v-confirm-edit" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_4, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_5,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-confirm-edit/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-confirm-edit")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_6
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_7, [
                createVNode(_component_app_heading, {
                  href: "#guide",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Guide")
                  ]),
                  _: 1
                }),
                _hoisted_8,
                createBaseVNode("section", _hoisted_9, [
                  createVNode(_component_app_heading, {
                    href: "#pickers",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Pickers")
                    ]),
                    _: 1
                  }),
                  _hoisted_10,
                  createVNode(_component_examples_example, { file: "v-confirm-edit/misc-date-picker" })
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
