import { r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, b as createVNode, l as createElementBlock, v as renderList, F as Fragment } from "./index-DGybHjCP.js";
const _sfc_main = {
  __name: "constrained",
  setup(__props) {
    const links = [
      "Dashboard",
      "Messages",
      "Profile",
      "Updates"
    ];
    return (_ctx, _cache) => {
      const _component_v_avatar = resolveComponent("v-avatar");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_spacer = resolveComponent("v-spacer");
      const _component_v_text_field = resolveComponent("v-text-field");
      const _component_v_responsive = resolveComponent("v-responsive");
      const _component_v_container = resolveComponent("v-container");
      const _component_v_app_bar = resolveComponent("v-app-bar");
      const _component_v_list_item = resolveComponent("v-list-item");
      const _component_v_divider = resolveComponent("v-divider");
      const _component_v_list = resolveComponent("v-list");
      const _component_v_sheet = resolveComponent("v-sheet");
      const _component_v_col = resolveComponent("v-col");
      const _component_v_row = resolveComponent("v-row");
      const _component_v_main = resolveComponent("v-main");
      const _component_v_app = resolveComponent("v-app");
      return openBlock(), createBlock(_component_v_app, { id: "inspire" }, {
        default: withCtx(() => [
          createVNode(_component_v_app_bar, { flat: "" }, {
            default: withCtx(() => [
              createVNode(_component_v_container, { class: "mx-auto d-flex align-center justify-center" }, {
                default: withCtx(() => [
                  createVNode(_component_v_avatar, {
                    class: "me-4",
                    color: "grey-darken-1",
                    size: "32"
                  }),
                  (openBlock(), createElementBlock(Fragment, null, renderList(links, (link) => {
                    return createVNode(_component_v_btn, {
                      key: link,
                      text: link,
                      variant: "text"
                    }, null, 8, ["text"]);
                  }), 64)),
                  createVNode(_component_v_spacer),
                  createVNode(_component_v_responsive, { "max-width": "160" }, {
                    default: withCtx(() => [
                      createVNode(_component_v_text_field, {
                        density: "compact",
                        label: "Search",
                        rounded: "lg",
                        variant: "solo-filled",
                        flat: "",
                        "hide-details": "",
                        "single-line": ""
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_main, { class: "bg-grey-lighten-3" }, {
            default: withCtx(() => [
              createVNode(_component_v_container, null, {
                default: withCtx(() => [
                  createVNode(_component_v_row, null, {
                    default: withCtx(() => [
                      createVNode(_component_v_col, { cols: "2" }, {
                        default: withCtx(() => [
                          createVNode(_component_v_sheet, { rounded: "lg" }, {
                            default: withCtx(() => [
                              createVNode(_component_v_list, { rounded: "lg" }, {
                                default: withCtx(() => [
                                  (openBlock(), createElementBlock(Fragment, null, renderList(5, (n) => {
                                    return createVNode(_component_v_list_item, {
                                      key: n,
                                      title: `List Item ${n}`,
                                      link: ""
                                    }, null, 8, ["title"]);
                                  }), 64)),
                                  createVNode(_component_v_divider, { class: "my-2" }),
                                  createVNode(_component_v_list_item, {
                                    color: "grey-lighten-4",
                                    title: "Refresh",
                                    link: ""
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_v_col, null, {
                        default: withCtx(() => [
                          createVNode(_component_v_sheet, {
                            "min-height": "70vh",
                            rounded: "lg"
                          })
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __1 = _sfc_main;
export {
  __1 as _
};
