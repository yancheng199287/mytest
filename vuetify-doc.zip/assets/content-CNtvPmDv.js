import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "content" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "Vuetify has custom styling for multiple standard elements.", -1);
const _hoisted_3 = { id: "block-quote" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("blockquote", { class: "blockquote" }, [
  /* @__PURE__ */ createBaseVNode("p", null, "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Harum maiores modi quidem veniam, expedita quis laboriosam, ullam facere adipisci, iusto, voluptate sapiente corrupti asperiores rem nemo numquam fuga ab at.")
], -1);
const _hoisted_5 = { id: "paragraphs" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("p", null, "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Harum maiores modi quidem veniam, expedita quis laboriosam, ullam facere adipisci, iusto, voluptate sapiente corrupti asperiores rem nemo numquam fuga ab at.", -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("p", null, "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Harum maiores modi quidem veniam, expedita quis laboriosam, ullam facere adipisci, iusto, voluptate sapiente corrupti asperiores rem nemo numquam fuga ab at.", -1);
const _hoisted_8 = { id: "code" };
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Example of an inline "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<code>"),
  /* @__PURE__ */ createTextVNode(" element.")
], -1);
const _hoisted_10 = { id: "variables" };
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("var", null, "v"),
  /* @__PURE__ */ createTextVNode(" = "),
  /* @__PURE__ */ createBaseVNode("var", null, "u"),
  /* @__PURE__ */ createTextVNode(" * "),
  /* @__PURE__ */ createBaseVNode("var", null, "e")
], -1);
const _hoisted_12 = { id: "user-input" };
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("To install Vuetify, type "),
  /* @__PURE__ */ createBaseVNode("kbd", null, "npm install vuetify"),
  /* @__PURE__ */ createTextVNode(" into your console. Once complete, type "),
  /* @__PURE__ */ createBaseVNode("kbd", null, [
    /* @__PURE__ */ createTextVNode("cd "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<project name>")
  ]),
  /* @__PURE__ */ createTextVNode(" and run "),
  /* @__PURE__ */ createBaseVNode("kbd", null, "npm install")
], -1);
const frontmatter = { "meta": { "title": "Content", "description": "Vuetify provides custom styling for various HTML elements.", "keywords": "content, html, markup" }, "related": ["/styles/text-and-typography/", "/styles/display/", "/styles/spacing/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "content",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "Content", "description": "Vuetify provides custom styling for various HTML elements.", "keywords": "content, html, markup" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "title": "Content", "description": "Vuetify provides custom styling for various HTML elements.", "keywords": "content, html, markup" }, "related": ["/styles/text-and-typography/", "/styles/display/", "/styles/spacing/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#content",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Content")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_promoted_entry),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#block-quote",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Block quote")
                  ]),
                  _: 1
                }),
                _hoisted_4
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#paragraphs",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Paragraphs")
                  ]),
                  _: 1
                }),
                _hoisted_6,
                _hoisted_7
              ]),
              createBaseVNode("section", _hoisted_8, [
                createVNode(_component_app_heading, {
                  href: "#code",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Code")
                  ]),
                  _: 1
                }),
                _hoisted_9
              ]),
              createBaseVNode("section", _hoisted_10, [
                createVNode(_component_app_heading, {
                  href: "#variables",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Variables")
                  ]),
                  _: 1
                }),
                _hoisted_11
              ]),
              createBaseVNode("section", _hoisted_12, [
                createVNode(_component_app_heading, {
                  href: "#user-input",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("User input")
                  ]),
                  _: 1
                }),
                _hoisted_13
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
