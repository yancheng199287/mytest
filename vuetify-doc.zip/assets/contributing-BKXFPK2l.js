import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "contributing" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "Vuetify is made possible by an amazing community that submits issues, creates pull requests, and provides invaluable feedback.", -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("p", null, "It is our job to enable you to create amazing applications. A lot of the time, you come across something that can be made better. Maybe you find a bug, or you have an idea for additional functionality. That’s great! It’s as easy as cloning the Vuetify repository to get started working in a development environment.", -1);
const _hoisted_4 = { id: "reporting-issues" };
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("p", null, "The issue list of this repo is exclusively for bug reports and feature requests. Non-conforming issues will be closed immediately. Before reporting an issue:", -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("blockquote", null, [
  /* @__PURE__ */ createBaseVNode("p", null, "If a similar issue already exists, you do not need to open another issue for this, if you want to help with it in any way, you can help by giving appropriate information in the already existing issue.")
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createTextVNode("Make sure that the reproduction is "),
  /* @__PURE__ */ createBaseVNode("strong", null, "MINIMAL"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "CONCISE")
], -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("p", null, "When writing an issue please provide as much detail as possible. Note that “reproduction steps” should be a series of actions another developer should take after clicking your reproduction link, not a recollection of how you discovered the bug.", -1);
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "TIP:")
], -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("When you create a reproduction, exclude all "),
  /* @__PURE__ */ createBaseVNode("strong", null, "elements, properties, and data variables"),
  /* @__PURE__ */ createTextVNode(" that are not needed for the reproduction. This helps drastically reduce the time it takes to triage the issue and ultimately resolve it.")
], -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("p", null, "In the next section you will learn step-by-step how to set up your local environment and how to configure Vuetify for development.", -1);
const _hoisted_12 = { id: "local-development" };
const _hoisted_13 = { id: "setting-up-your-environment" };
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("p", null, "Required software:", -1);
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("p", null, "Once you have everything installed, clone the repository:", -1);
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-bash" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-bash" }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "# Using HTTPS"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "git"),
    /* @__PURE__ */ createTextVNode(" clone https://github.com/vuetifyjs/vuetify.git\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "# Using SSH"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "git"),
    /* @__PURE__ */ createTextVNode(" clone git@github.com:vuetifyjs/vuetify.git\n")
  ])
], -1);
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("p", null, "Then install dependencies and perform an initial build to link all the packages together:", -1);
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-bash" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-bash" }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "# Navigate to the vuetify folder"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin class-name" }, "cd"),
    /* @__PURE__ */ createTextVNode(" vuetify\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "# Install all project dependencies"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "yarn"),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "# Build the packages"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "yarn"),
    /* @__PURE__ */ createTextVNode(" build vuetify\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "yarn"),
    /* @__PURE__ */ createTextVNode(" build api\n")
  ])
], -1);
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("p", null, "The build process compiles all the Vuetify packages for development and may take a while (grab some ☕). Once the packages are built, you can start developing.", -1);
const _hoisted_20 = { id: "vuetify" };
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The Vuetify library is located in "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "packages/vuetify"),
  /* @__PURE__ */ createTextVNode(". In "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "packages/vuetify/dev"),
  /* @__PURE__ */ createTextVNode(" you will find a "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "Playground.vue"),
  /* @__PURE__ */ createTextVNode(" file; running "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "yarn dev"),
  /* @__PURE__ */ createTextVNode(" from the project root will start a dev server on "),
  /* @__PURE__ */ createBaseVNode("strong", null, "localhost:8090"),
  /* @__PURE__ */ createTextVNode(" with this file loaded. Test your changes in the Playground.vue file you copied, then paste its contents into your pull request when you’re ready.")
], -1);
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "yarn link", -1);
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Navigate to "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "packages/vuetify")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Run "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "yarn link")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, "Navigate to your project’s directory"),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Run "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "yarn link vuetify")
  ])
], -1);
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("If your project is using vuetify-loader you will have to run "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "yarn build:lib"),
  /* @__PURE__ */ createTextVNode(" in the vuetify package to see changes, otherwise you can use "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "yarn watch"),
  /* @__PURE__ */ createTextVNode(" for incremental builds.")
], -1);
const _hoisted_25 = { id: "playground-vue" };
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "Playground"),
  /* @__PURE__ */ createTextVNode(" file is a cleanroom used for Vuetify development and is the recommended way to iterate on changes within the framework.")
], -1);
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-html" }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-app")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-container")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "<!--  -->"),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("v-container")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("v-app")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("script")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "setup"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token script" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token language-javascript" }, [
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "//"),
        /* @__PURE__ */ createTextVNode("\n")
      ])
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("script")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_28 = { id: "documentation" };
const _hoisted_29 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "packages/docs", -1);
const _hoisted_30 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "packages/api-generator", -1);
const _hoisted_31 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "yarn dev docs", -1);
const _hoisted_32 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("If you want to see changes from Vuetify in the documentation you need to run "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "yarn build:lib"),
  /* @__PURE__ */ createTextVNode(" in the vuetify package before starting the documentation server.")
], -1);
const _hoisted_33 = { id: "api-generator" };
const _hoisted_34 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("All api descriptions are managed via the api-generator package. This package must be built prior to running or building the docs. Descriptions can be updated via the JSON files located in the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "src/locale/en"),
  /* @__PURE__ */ createTextVNode(" folder. Some general guidelines to follow when handling api descriptions are:")
], -1);
const _hoisted_35 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "en", -1);
const _hoisted_36 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createTextVNode("Prop names should be formatted using bold markdown eg: "),
  /* @__PURE__ */ createBaseVNode("strong", null, "prop-name"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_37 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createTextVNode("Slot and other code related text should be formatted using code markdown eg: "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "some-slot"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_38 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createTextVNode("Description keys should be in camelCase, except for "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "slot"),
  /* @__PURE__ */ createTextVNode(" keys which should be kebab-case.")
], -1);
const _hoisted_39 = /* @__PURE__ */ createBaseVNode("li", null, "Put keys in alphabetical order.", -1);
const _hoisted_40 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createTextVNode("Descriptions utilize a hierarchy of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "generic.json"),
  /* @__PURE__ */ createTextVNode(" < "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "Source.json"),
  /* @__PURE__ */ createTextVNode(" < "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "Component.json"),
  /* @__PURE__ */ createTextVNode(" to reduce duplication. Source can be viewed using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "Developer Mode"),
  /* @__PURE__ */ createTextVNode(" in docs settings.")
], -1);
const _hoisted_41 = { id: "submitting-changes-pull-requests" };
const _hoisted_42 = /* @__PURE__ */ createBaseVNode("p", null, "Then add your fork as a remote in git:", -1);
const _hoisted_43 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-bash" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-bash" }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "# Using HTTPS"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "git"),
    /* @__PURE__ */ createTextVNode(" remote "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "add"),
    /* @__PURE__ */ createTextVNode(" fork https://github.com/YOUR_USERNAME/vuetify.git\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "# Using SSH"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "git"),
    /* @__PURE__ */ createTextVNode(" remote "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "add"),
    /* @__PURE__ */ createTextVNode(" fork git@github.com:YOUR_USERNAME/vuetify.git\n")
  ])
], -1);
const _hoisted_44 = { id: "choosing-a-base-branch" };
const _hoisted_45 = /* @__PURE__ */ createBaseVNode("p", null, "Before starting development you should know which branch to base your changes on. If in doubt use master as changes to master can usually be merged into a different branch without rebasing.", -1);
const _hoisted_46 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Version"),
    /* @__PURE__ */ createBaseVNode("th", null, "Type of change"),
    /* @__PURE__ */ createBaseVNode("th", null, "Branch")
  ])
], -1);
const _hoisted_47 = /* @__PURE__ */ createBaseVNode("tbody", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "Vuetify 3"),
    /* @__PURE__ */ createBaseVNode("td", null, "Documentation"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "master")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "Vuetify 3"),
    /* @__PURE__ */ createBaseVNode("td", null, "Bug fixes"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "master")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "Vuetify 3"),
    /* @__PURE__ */ createBaseVNode("td", null, "New features"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "dev")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "Vuetify 3"),
    /* @__PURE__ */ createBaseVNode("td", null, "Features with breaking changes"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "next")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "Vuetify 2"),
    /* @__PURE__ */ createBaseVNode("td", null, "Documentation"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v2-stable")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "Vuetify 2"),
    /* @__PURE__ */ createBaseVNode("td", null, "Bug fixes"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v2-stable")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "Vuetify 2"),
    /* @__PURE__ */ createBaseVNode("td", null, "New features"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v2-dev")
    ])
  ])
], -1);
const _hoisted_48 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-bash" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-bash" }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "# Switch to the desired branch"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "# v3"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "git"),
    /* @__PURE__ */ createTextVNode(" switch master\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "# v2"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "git"),
    /* @__PURE__ */ createTextVNode(" switch v2-stable\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "# Pull down any upstream changes"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "git"),
    /* @__PURE__ */ createTextVNode(" pull\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "# Create a new branch to work on"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "git"),
    /* @__PURE__ */ createTextVNode(" switch "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token parameter variable" }, "--create"),
    /* @__PURE__ */ createTextVNode(" fix/1234-some-issue\n")
  ])
], -1);
const _hoisted_49 = /* @__PURE__ */ createBaseVNode("p", null, "Never commit directly to the base branches, always create a feature branch to work on", -1);
const _hoisted_50 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "git push -u fork", -1);
const _hoisted_51 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Pull requests that include unrelated commits or your local merges will be "),
  /* @__PURE__ */ createBaseVNode("strong", null, "CLOSED"),
  /* @__PURE__ */ createTextVNode(" without notice")
], -1);
const _hoisted_52 = { id: "working-with-github" };
const _hoisted_53 = /* @__PURE__ */ createBaseVNode("p", null, "Some of the more notable links within these services include:", -1);
const _hoisted_54 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "GitHub")
], -1);
const _hoisted_55 = /* @__PURE__ */ createBaseVNode("p", null, "The following sections are designed to familiarize you with our standard operating procedures for Vuetify development.", -1);
const _hoisted_56 = { id: "issue-triage" };
const _hoisted_57 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "triage", -1);
const _hoisted_58 = { id: "for-docs-language" };
const _hoisted_59 = /* @__PURE__ */ createBaseVNode("strong", null, "do not", -1);
const _hoisted_60 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "en", -1);
const _hoisted_61 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "en", -1);
const _hoisted_62 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createTextVNode("Using in-context translation service directly through the documentation site. To get started simply select "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "Help Translate"),
  /* @__PURE__ */ createTextVNode(" in the language drop down in the docs.")
], -1);
const _hoisted_63 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Note"),
  /* @__PURE__ */ createTextVNode(": Languages will not be added to the language drop down on the docs site until they have at least 50% of their translations completed.")
], -1);
const _hoisted_64 = { id: "requesting-new-features" };
const _hoisted_65 = /* @__PURE__ */ createBaseVNode("p", null, "Pending", -1);
const _hoisted_66 = { id: "commit-guidelines" };
const _hoisted_67 = /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "angular", -1);
const _hoisted_68 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("With scope: "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<type>(scope): <subject>")
], -1);
const _hoisted_69 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-bash" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-bash" }, [
    /* @__PURE__ */ createTextVNode("fix"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createTextVNode("VSelect"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode(": don't close when a detachable child is clicked\n\nfixes "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "#12354"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_70 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Without scope: "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<type>: <subject>")
], -1);
const _hoisted_71 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-bash" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-bash" }, [
    /* @__PURE__ */ createTextVNode("docs: restructure nav components\n\nMoved duplicated functionality "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "in"),
    /* @__PURE__ */ createTextVNode(" drawer to reduce\nscope of responsibility\n")
  ])
], -1);
const _hoisted_72 = { id: "general-rules" };
const _hoisted_73 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("p", null, "Commit messages must have a subject line and may have body copy. These must be separated by a blank line.")
], -1);
const _hoisted_74 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("p", null, "The subject line must not exceed 60 characters")
], -1);
const _hoisted_75 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("p", null, "The subject line must be written in imperative mood (fix, not fixed / fixes etc.)")
], -1);
const _hoisted_76 = /* @__PURE__ */ createBaseVNode("p", null, "The body copy must include a reference all issues resolved:", -1);
const _hoisted_77 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-bash" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-bash" }, [
    /* @__PURE__ */ createTextVNode("docs"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createTextVNode("sass-variables"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode(": fix broken "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "link"),
    /* @__PURE__ */ createTextVNode(" to api\n\nresolves "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "#3219"),
    /* @__PURE__ */ createTextVNode("\nresolves "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "#3254"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_78 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("p", null, "The body copy must be wrapped at 72 characters")
], -1);
const _hoisted_79 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("p", null, "The body copy must only contain explanations as to what and why, never how. The latter belongs in documentation and implementation.")
], -1);
const _hoisted_80 = { id: "commit-types" };
const _hoisted_81 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The following is a list of "),
  /* @__PURE__ */ createBaseVNode("strong", null, "commit types"),
  /* @__PURE__ */ createTextVNode(" used in the "),
  /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "angular"),
  /* @__PURE__ */ createTextVNode(" preset:")
], -1);
const _hoisted_82 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "feat:"),
    /* @__PURE__ */ createTextVNode(" Commits that result in new features or functionalities. Backwards compatible features will release with the next "),
    /* @__PURE__ */ createBaseVNode("strong", null, "MINOR"),
    /* @__PURE__ */ createTextVNode(" whereas breaking changes will be in the next "),
    /* @__PURE__ */ createBaseVNode("strong", null, "MAJOR"),
    /* @__PURE__ */ createTextVNode(". The body of a commit with breaking changes must begin with "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "BREAKING CHANGE"),
    /* @__PURE__ */ createTextVNode(", followed by a description of how the API has changed.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "fix:"),
    /* @__PURE__ */ createTextVNode(" Commits that provide fixes for bugs within vuetify’s codebase.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "docs:"),
    /* @__PURE__ */ createTextVNode(" Commits that provide updates to the docs.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "style:"),
    /* @__PURE__ */ createTextVNode(" Commits that do not affect how the code runs, these are simply changes to formatting.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "refactor:"),
    /* @__PURE__ */ createTextVNode(" Commits that neither fixes a bug nor adds a feature.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "perf:"),
    /* @__PURE__ */ createTextVNode(" Commits that improve performance.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "test:"),
    /* @__PURE__ */ createTextVNode(" Commits that add missing or correct existing tests.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "chore:"),
    /* @__PURE__ */ createTextVNode(" Other commits that don’t modify src or test files.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "revert:"),
    /* @__PURE__ */ createTextVNode(" Commits that revert previous commits.")
  ])
], -1);
const frontmatter = { "meta": { "title": "Contributing", "description": "Contributing to open source helps developers access amazing tools for free. Learn how you can help develop the Vuetify framework.", "keywords": "contribute, contributing, feature request" }, "related": ["/getting-started/unit-testing/", "/about/code-of-conduct/", "/introduction/roadmap/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "contributing",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "Contributing", "description": "Contributing to open source helps developers access amazing tools for free. Learn how you can help develop the Vuetify framework.", "keywords": "contribute, contributing, feature request" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "title": "Contributing", "description": "Contributing to open source helps developers access amazing tools for free. Learn how you can help develop the Vuetify framework.", "keywords": "contribute, contributing, feature request" }, "related": ["/getting-started/unit-testing/", "/about/code-of-conduct/", "/introduction/roadmap/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_vo_promotions_card_vuetify = resolveComponent("vo-promotions-card-vuetify");
      const _component_promoted_promoted = resolveComponent("promoted-promoted");
      const _component_app_link = resolveComponent("app-link");
      const _component_alert = resolveComponent("alert");
      const _component_app_markup = resolveComponent("app-markup");
      const _component_app_table = resolveComponent("app-table");
      const _component_app_divider = resolveComponent("app-divider");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#contributing",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Contributing")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_vo_promotions_card_vuetify),
              _hoisted_3,
              createVNode(_component_promoted_promoted, { slug: "vuetify-discord" }),
              createBaseVNode("section", _hoisted_4, [
                createVNode(_component_app_heading, {
                  href: "#reporting-issues",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Reporting Issues")
                  ]),
                  _: 1
                }),
                _hoisted_5,
                createBaseVNode("ul", null, [
                  createBaseVNode("li", null, [
                    createTextVNode("Search for similar "),
                    createVNode(_component_app_link, { href: "https://github.com/vuetifyjs/vuetify/issues" }, {
                      default: withCtx(() => [
                        createTextVNode("issues")
                      ]),
                      _: 1
                    }),
                    createTextVNode(", it may have been answered already. "),
                    _hoisted_6
                  ]),
                  createBaseVNode("li", null, [
                    createTextVNode("Try to reproduce with the "),
                    createVNode(_component_app_link, { href: "https://github.com/vuetifyjs/vuetify/releases/latest" }, {
                      default: withCtx(() => [
                        createTextVNode("latest")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" version in "),
                    createVNode(_component_app_link, { href: "https://play.vuetifyjs.com/" }, {
                      default: withCtx(() => [
                        createTextVNode("Vuetify Play")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" or a repository that can be cloned to produce the expected behavior.")
                  ]),
                  _hoisted_7
                ]),
                createBaseVNode("p", null, [
                  createTextVNode("These steps ensure that we have all the information necessary to quickly triage and resolve your issue. Once your reproduction is complete, submit a new issue using the "),
                  createVNode(_component_app_link, { href: "https://issues.vuetifyjs.com/" }, {
                    default: withCtx(() => [
                      createTextVNode("Vuetify Issue Creator")
                    ]),
                    _: 1
                  }),
                  createTextVNode(". Using this issue creator is required, otherwise the issue will be closed automatically.")
                ]),
                _hoisted_8,
                createBaseVNode("p", null, [
                  createTextVNode("Issues that are convoluted and lacking a proper reproduction may be closed by a member of the "),
                  createVNode(_component_app_link, { href: "/about/meet-the-team/" }, {
                    default: withCtx(() => [
                      createTextVNode("Core Team")
                    ]),
                    _: 1
                  }),
                  createTextVNode(". For additional questions regarding reporting issues and creating reproductions, join the official Vuetify Discord "),
                  createVNode(_component_app_link, { href: "https://community.vuetifyjs.com/" }, {
                    default: withCtx(() => [
                      createTextVNode("community")
                    ]),
                    _: 1
                  }),
                  createTextVNode(".")
                ]),
                createVNode(_component_alert, { type: "tip" }, {
                  default: withCtx(() => [
                    _hoisted_9,
                    _hoisted_10
                  ]),
                  _: 1
                }),
                _hoisted_11
              ]),
              createBaseVNode("section", _hoisted_12, [
                createVNode(_component_app_heading, {
                  href: "#local-development",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Local development")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("The Vuetify repository is a "),
                  createVNode(_component_app_link, { href: "https://github.com/lerna/lerna" }, {
                    default: withCtx(() => [
                      createTextVNode("lerna")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" monorepo that connects the vuetify library, docs, api generator, and reduces the friction of working with multiple projects at once. The following guide is designed to get you up and running in no time.")
                ]),
                createBaseVNode("section", _hoisted_13, [
                  createVNode(_component_app_heading, {
                    href: "#setting-up-your-environment",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Setting up your environment")
                    ]),
                    _: 1
                  }),
                  _hoisted_14,
                  createBaseVNode("ul", null, [
                    createBaseVNode("li", null, [
                      createVNode(_component_app_link, { href: "https://git-scm.com/" }, {
                        default: withCtx(() => [
                          createTextVNode("Git")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" >v2.20")
                    ]),
                    createBaseVNode("li", null, [
                      createVNode(_component_app_link, { href: "https://nodejs.org/" }, {
                        default: withCtx(() => [
                          createTextVNode("Node.js")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" LTS")
                    ]),
                    createBaseVNode("li", null, [
                      createVNode(_component_app_link, { href: "https://classic.yarnpkg.com/" }, {
                        default: withCtx(() => [
                          createTextVNode("Yarn")
                        ]),
                        _: 1
                      })
                    ])
                  ]),
                  createBaseVNode("p", null, [
                    createTextVNode("Some of our dependencies use "),
                    createVNode(_component_app_link, { href: "https://github.com/nodejs/node-gyp#installation" }, {
                      default: withCtx(() => [
                        createTextVNode("node-gyp")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" to build themselves. You don’t need to install node-gyp itself but may require additional tools, especially on windows. See the node-gyp documentation for more details.")
                  ]),
                  _hoisted_15,
                  createVNode(_component_app_markup, {
                    resource: "",
                    class: "mb-4"
                  }, {
                    default: withCtx(() => [
                      _hoisted_16
                    ]),
                    _: 1
                  }),
                  createVNode(_component_alert, { type: "info" }, {
                    default: withCtx(() => [
                      createBaseVNode("p", null, [
                        createVNode(_component_app_link, { href: "https://docs.github.com/en/free-pro-team@latest/github/using-git/which-remote-url-should-i-use" }, {
                          default: withCtx(() => [
                            createTextVNode("Which remote URL should I use?")
                          ]),
                          _: 1
                        })
                      ])
                    ]),
                    _: 1
                  }),
                  _hoisted_17,
                  createVNode(_component_app_markup, {
                    resource: "",
                    class: "mb-4"
                  }, {
                    default: withCtx(() => [
                      _hoisted_18
                    ]),
                    _: 1
                  }),
                  _hoisted_19
                ]),
                createBaseVNode("section", _hoisted_20, [
                  createVNode(_component_app_heading, {
                    href: "#vuetify",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Vuetify")
                    ]),
                    _: 1
                  }),
                  _hoisted_21,
                  createBaseVNode("p", null, [
                    createTextVNode("You can also test Vuetify in your own project using "),
                    createVNode(_component_app_link, { href: "https://classic.yarnpkg.com/en/docs/cli/link/" }, {
                      default: withCtx(() => [
                        _hoisted_22
                      ]),
                      _: 1
                    }),
                    createTextVNode(":")
                  ]),
                  _hoisted_23,
                  _hoisted_24,
                  createBaseVNode("section", _hoisted_25, [
                    createVNode(_component_app_heading, {
                      href: "#playground-vue",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Playground.vue")
                      ]),
                      _: 1
                    }),
                    _hoisted_26,
                    createVNode(_component_app_markup, {
                      resource: "",
                      class: "mb-4"
                    }, {
                      default: withCtx(() => [
                        _hoisted_27
                      ]),
                      _: 1
                    })
                  ])
                ]),
                createBaseVNode("section", _hoisted_28, [
                  createVNode(_component_app_heading, {
                    href: "#documentation",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Documentation")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("p", null, [
                    createTextVNode("The documentation is located in "),
                    _hoisted_29,
                    createTextVNode(" but also uses some files from "),
                    _hoisted_30,
                    createTextVNode(". A dev server for the documentation can be started by running "),
                    _hoisted_31,
                    createTextVNode(" from the project root and will be available on "),
                    createVNode(_component_app_link, { href: "http://localhost:8095/" }, {
                      default: withCtx(() => [
                        createTextVNode("localhost:8095")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" by default.")
                  ]),
                  _hoisted_32
                ]),
                createBaseVNode("section", _hoisted_33, [
                  createVNode(_component_app_heading, {
                    href: "#api-generator",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("API Generator")
                    ]),
                    _: 1
                  }),
                  _hoisted_34,
                  createBaseVNode("ul", null, [
                    createBaseVNode("li", null, [
                      _hoisted_35,
                      createTextVNode(" language only. Translations are handled via "),
                      createVNode(_component_app_link, { href: "https://crowdin.com/project/vuetify" }, {
                        default: withCtx(() => [
                          createTextVNode("Crowdin")
                        ]),
                        _: 1
                      }),
                      createTextVNode(".")
                    ]),
                    _hoisted_36,
                    _hoisted_37,
                    _hoisted_38,
                    _hoisted_39,
                    _hoisted_40
                  ])
                ]),
                createBaseVNode("section", _hoisted_41, [
                  createVNode(_component_app_heading, {
                    href: "#submitting-changes-pull-requests",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Submitting Changes / Pull Requests")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("p", null, [
                    createTextVNode("First you should create a fork of the vuetify repository to push your changes to. Information on forking repositories can be found in the "),
                    createVNode(_component_app_link, { href: "https://help.github.com/en/github/getting-started-with-github/fork-a-repo" }, {
                      default: withCtx(() => [
                        createTextVNode("GitHub documentation")
                      ]),
                      _: 1
                    }),
                    createTextVNode(".")
                  ]),
                  _hoisted_42,
                  createVNode(_component_app_markup, {
                    resource: "",
                    class: "mb-4"
                  }, {
                    default: withCtx(() => [
                      _hoisted_43
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_44, [
                    createVNode(_component_app_heading, {
                      href: "#choosing-a-base-branch",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Choosing a base branch")
                      ]),
                      _: 1
                    }),
                    _hoisted_45,
                    createVNode(_component_app_table, null, {
                      default: withCtx(() => [
                        _hoisted_46,
                        _hoisted_47
                      ]),
                      _: 1
                    }),
                    createVNode(_component_app_markup, {
                      resource: "",
                      class: "mb-4"
                    }, {
                      default: withCtx(() => [
                        _hoisted_48
                      ]),
                      _: 1
                    }),
                    createVNode(_component_alert, { type: "warning" }, {
                      default: withCtx(() => [
                        _hoisted_49
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("Commit your changes following "),
                      createVNode(_component_app_link, { href: "#commit-guidelines" }, {
                        default: withCtx(() => [
                          createTextVNode("our guidelines")
                        ]),
                        _: 1
                      }),
                      createTextVNode(", then push the branch to your fork with "),
                      _hoisted_50,
                      createTextVNode(" and open a pull request on the Vuetify repository following the provided template.")
                    ]),
                    createVNode(_component_alert, { type: "error" }, {
                      default: withCtx(() => [
                        _hoisted_51
                      ]),
                      _: 1
                    })
                  ])
                ])
              ]),
              createBaseVNode("section", _hoisted_52, [
                createVNode(_component_app_heading, {
                  href: "#working-with-github",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Working with GitHub")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("Vuetify’s repository lives on "),
                  createVNode(_component_app_link, { href: "https://github.com/vuetifyjs/vuetify" }, {
                    default: withCtx(() => [
                      createTextVNode("GitHub")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" and is the primary location for all development related information.")
                ]),
                _hoisted_53,
                _hoisted_54,
                createBaseVNode("ul", null, [
                  createBaseVNode("li", null, [
                    createVNode(_component_app_link, { href: "https://github.com/vuetifyjs/vuetify/issues" }, {
                      default: withCtx(() => [
                        createTextVNode("Issues")
                      ]),
                      _: 1
                    })
                  ]),
                  createBaseVNode("li", null, [
                    createVNode(_component_app_link, { href: "https://github.com/vuetifyjs/vuetify/discussions" }, {
                      default: withCtx(() => [
                        createTextVNode("Discussions")
                      ]),
                      _: 1
                    })
                  ])
                ]),
                createVNode(_component_app_divider),
                _hoisted_55,
                createVNode(_component_promoted_promoted, { slug: "vue-jobs" }),
                createBaseVNode("section", _hoisted_56, [
                  createVNode(_component_app_heading, {
                    href: "#issue-triage",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Issue triage")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("p", null, [
                    createTextVNode("With the size and popularity of Vuetify has come a constant influx of new issues, questions, and feature requests. To organize these requests the "),
                    createVNode(_component_app_link, { href: "/about/meet-the-team/" }, {
                      default: withCtx(() => [
                        createTextVNode("Core Team")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" developed tools to aid not only the triaging of issues, but creating them as well.")
                  ]),
                  createBaseVNode("p", null, [
                    createTextVNode("The "),
                    createVNode(_component_app_link, { href: "https://github.com/vuetifyjs/vuetify/issues" }, {
                      default: withCtx(() => [
                        createTextVNode("Issues")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" board makes heavy use of GitHub’s label system with some light automation, such as adding the "),
                    _hoisted_57,
                    createTextVNode(" label to new issues.")
                  ]),
                  createBaseVNode("section", _hoisted_58, [
                    createVNode(_component_app_heading, {
                      href: "#for-docs-language",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("For Docs - Language")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("We "),
                      _hoisted_59,
                      createTextVNode(" accept PRs for any documentation changes pertaining to languages other than "),
                      _hoisted_60,
                      createTextVNode(". All changes for languages other than "),
                      _hoisted_61,
                      createTextVNode(" are to be submitted through our "),
                      createVNode(_component_app_link, { href: "https://crowdin.com/project/vuetify" }, {
                        default: withCtx(() => [
                          createTextVNode("Crowdin project")
                        ]),
                        _: 1
                      }),
                      createTextVNode(". You can help translate in one of 2 ways:")
                    ]),
                    createBaseVNode("ul", null, [
                      _hoisted_62,
                      createBaseVNode("li", null, [
                        createTextVNode("Directly through the "),
                        createVNode(_component_app_link, { href: "https://crowdin.com/project/vuetify" }, {
                          default: withCtx(() => [
                            createTextVNode("Crowdin project")
                          ]),
                          _: 1
                        }),
                        createTextVNode(".")
                      ])
                    ]),
                    _hoisted_63
                  ])
                ]),
                createBaseVNode("section", _hoisted_64, [
                  createVNode(_component_app_heading, {
                    href: "#requesting-new-features",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Requesting new features")
                    ]),
                    _: 1
                  }),
                  _hoisted_65
                ]),
                createBaseVNode("section", _hoisted_66, [
                  createVNode(_component_app_heading, {
                    href: "#commit-guidelines",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Commit guidelines")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("p", null, [
                    createTextVNode("All commit messages are required to follow the "),
                    createVNode(_component_app_link, { href: "https://github.com/conventional-changelog/conventional-changelog" }, {
                      default: withCtx(() => [
                        createTextVNode("conventional-changelog")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" standard using the "),
                    _hoisted_67,
                    createTextVNode(" preset. This standard format consists of 2 types of commits:")
                  ]),
                  createBaseVNode("ul", null, [
                    createBaseVNode("li", null, [
                      _hoisted_68,
                      createVNode(_component_app_markup, {
                        resource: "",
                        class: "mb-4"
                      }, {
                        default: withCtx(() => [
                          _hoisted_69
                        ]),
                        _: 1
                      })
                    ]),
                    createBaseVNode("li", null, [
                      _hoisted_70,
                      createVNode(_component_app_markup, {
                        resource: "",
                        class: "mb-4"
                      }, {
                        default: withCtx(() => [
                          _hoisted_71
                        ]),
                        _: 1
                      })
                    ])
                  ]),
                  createBaseVNode("section", _hoisted_72, [
                    createVNode(_component_app_heading, {
                      href: "#general-rules",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("General Rules")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("ul", null, [
                      _hoisted_73,
                      _hoisted_74,
                      _hoisted_75,
                      createBaseVNode("li", null, [
                        _hoisted_76,
                        createVNode(_component_app_markup, {
                          resource: "",
                          class: "mb-4"
                        }, {
                          default: withCtx(() => [
                            _hoisted_77
                          ]),
                          _: 1
                        })
                      ]),
                      _hoisted_78,
                      _hoisted_79
                    ])
                  ]),
                  createBaseVNode("section", _hoisted_80, [
                    createVNode(_component_app_heading, {
                      href: "#commit-types",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Commit types")
                      ]),
                      _: 1
                    }),
                    _hoisted_81,
                    _hoisted_82,
                    createVNode(_component_promoted_promoted, { slug: "vuetify-reddit" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
