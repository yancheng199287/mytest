import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "css-reset" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "Opinionated base styles for Vuetify projects.", -1);
const _hoisted_3 = { id: "bootstrapping" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "font-family: monospace", -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<code>", -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "outlines", -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "button", -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "input", -1);
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "$reset: false", -1);
const _hoisted_10 = { id: "reset-features" };
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Below is a list of additional "),
  /* @__PURE__ */ createBaseVNode("em", null, "features"),
  /* @__PURE__ */ createTextVNode(" that ress provides over the default "),
  /* @__PURE__ */ createBaseVNode("strong", null, "normalize.css"),
  /* @__PURE__ */ createTextVNode(" functionality")
], -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Apply "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "box-sizing: border-box"),
    /* @__PURE__ */ createTextVNode(" in all elements.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Reset "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "padding"),
    /* @__PURE__ */ createTextVNode(" and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin"),
    /* @__PURE__ */ createTextVNode(" in all elements.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Specify "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "background-repeat: no-repeat"),
    /* @__PURE__ */ createTextVNode(" in all elements and pseudo elements.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Inherit "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "text-decoration"),
    /* @__PURE__ */ createTextVNode(" and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "vertical-align"),
    /* @__PURE__ */ createTextVNode(" to "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "::before"),
    /* @__PURE__ */ createTextVNode(" and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "::after"),
    /* @__PURE__ */ createTextVNode(".")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Remove the "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "outline"),
    /* @__PURE__ */ createTextVNode(" when hovering in all browsers.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Specify "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "font-family: monospace"),
    /* @__PURE__ */ createTextVNode(" in code elements.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Reset "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "border-radius"),
    /* @__PURE__ */ createTextVNode(" in input elements.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, "Specify font inheritance of form elements."),
  /* @__PURE__ */ createBaseVNode("li", null, "Remove the default button styling in all browsers."),
  /* @__PURE__ */ createBaseVNode("li", null, "Specify textarea resizability to vertical."),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Apply "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "cursor: pointer"),
    /* @__PURE__ */ createTextVNode(" to button elements.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Apply "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "tab-size: 4"),
    /* @__PURE__ */ createTextVNode(" in "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "html"),
    /* @__PURE__ */ createTextVNode(".")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Style "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "select"),
    /* @__PURE__ */ createTextVNode(" like a standard input.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Style "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "cursor"),
    /* @__PURE__ */ createTextVNode(" by aria attributes.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, "Hide content from screens but not screen readers.")
], -1);
const frontmatter = { "meta": { "title": "CSS Reset", "description": "Vuetify uses ress.min, a complete browser reset based off or normalize.css.", "keywords": "ress.min, css reset, vuetify css reset" }, "related": ["/styles/colors/", "/styles/text-and-typography/", "/features/sass-variables/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "css-reset",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "CSS Reset", "description": "Vuetify uses ress.min, a complete browser reset based off or normalize.css.", "keywords": "ress.min, css reset, vuetify css reset" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "title": "CSS Reset", "description": "Vuetify uses ress.min, a complete browser reset based off or normalize.css.", "keywords": "ress.min, css reset, vuetify css reset" }, "related": ["/styles/colors/", "/styles/text-and-typography/", "/features/sass-variables/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_alert = resolveComponent("alert");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#css-reset",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("CSS Reset")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_promoted_entry),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#bootstrapping",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Bootstrapping")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("ress is a modern CSS reset that applies a solid base for stylesheets. It is built on top of "),
                  createVNode(_component_app_link, { href: "https://github.com/necolas/normalize.css" }, {
                    default: withCtx(() => [
                      createTextVNode("normalize.css")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" and adds new features such as specifying "),
                  _hoisted_4,
                  createTextVNode(" for "),
                  _hoisted_5,
                  createTextVNode(" elements, removing all "),
                  _hoisted_6,
                  createTextVNode(" from elements when hovering, and much much more. Additional information can be found on the "),
                  createVNode(_component_app_link, { href: "https://github.com/filipelinhares/ress" }, {
                    default: withCtx(() => [
                      createTextVNode("ress GitHub repository")
                    ]),
                    _: 1
                  }),
                  createTextVNode(".")
                ]),
                createVNode(_component_alert, { type: "warning" }, {
                  default: withCtx(() => [
                    createBaseVNode("p", null, [
                      createTextVNode("The Vuetify style reset is applied globally and affects default elements such as "),
                      _hoisted_7,
                      createTextVNode(" and "),
                      _hoisted_8,
                      createTextVNode(". This also includes anything located outside of the "),
                      createVNode(_component_app_link, { href: "/components/application" }, {
                        default: withCtx(() => [
                          createTextVNode("v-app")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" component.")
                    ])
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("It can be disabled with "),
                  createVNode(_component_app_link, { href: "/styles/sass-variables/#sass-variables" }, {
                    default: withCtx(() => [
                      createTextVNode("sass variables")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" by setting "),
                  _hoisted_9,
                  createTextVNode(", but you may have to manually reset some styles for components to display correctly.")
                ])
              ]),
              createBaseVNode("section", _hoisted_10, [
                createVNode(_component_app_heading, {
                  href: "#reset-features",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Reset Features")
                  ]),
                  _: 1
                }),
                _hoisted_11,
                _hoisted_12,
                createBaseVNode("p", null, [
                  createTextVNode("For a complete list of all applied styles, see the "),
                  createVNode(_component_app_link, { href: "https://github.com/vuetifyjs/vuetify/blob/master/packages/vuetify/src/styles/generic/_reset.scss" }, {
                    default: withCtx(() => [
                      createTextVNode("ress css stylesheet")
                    ]),
                    _: 1
                  }),
                  createTextVNode(".")
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
