import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "cursor" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "Utilities for controlling the cursor styling when hovering over elements.", -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Class"),
    /* @__PURE__ */ createBaseVNode("th", null, "Properties")
  ])
], -1);
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("tbody", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "cursor-auto")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "cursor: auto;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "cursor-default")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "cursor: default;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "cursor-grab")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "cursor: grab;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "cursor-grabbing")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "cursor: grabbing;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "cursor-help")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "cursor: help;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "cursor-move")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "cursor: move;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "cursor-none")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "cursor: none;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "cursor-not-allowed")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "cursor: not-allowed;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "cursor-pointer")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "cursor: pointer;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "cursor-progress")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "cursor: progress;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "cursor-text")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "cursor: text;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "cursor-wait")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "cursor: wait;")
  ])
], -1);
const _hoisted_5 = { id: "usage" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("p", null, "Apply custom cursor styling to a component or element.", -1);
const _hoisted_7 = { id: "sass-variables" };
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("p", null, "You can also use the following SASS variables to customize the border color and width:", -1);
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-scss" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/styles/settings.scss",
    class: "language-scss"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "@use"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify/settings'"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token module-modifier keyword" }, "with"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token variable" }, "$utilities")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"cursor"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, "property"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(" cursor"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, "class"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(" cursor"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, "values"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(" auto default pointer wait text move help not-allowed progress grab grabbing none\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ";"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Disable the generation of "),
  /* @__PURE__ */ createBaseVNode("strong", null, "cursor"),
  /* @__PURE__ */ createTextVNode(" utility classes by overwriting the utilities value:")
], -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-scss" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/styles/settings.scss",
    class: "language-scss"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "@use"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify/settings'"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token module-modifier keyword" }, "with"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token variable" }, "$utilities")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"cursor"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ";"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const frontmatter = { "emphasized": true, "meta": { "title": "Cursor", "description": "Assign a custom cursor to any element.", "keywords": "cursor, utility, helper, class" }, "related": ["/styles/content/", "/styles/spacing/", "/styles/text-and-typography/"], "features": { "report": true } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "cursor",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "Cursor", "description": "Assign a custom cursor to any element.", "keywords": "cursor, utility, helper, class" } };
    useHead(head);
    __expose({ frontmatter: { "emphasized": true, "meta": { "title": "Cursor", "description": "Assign a custom cursor to any element.", "keywords": "cursor, utility, helper, class" }, "related": ["/styles/content/", "/styles/spacing/", "/styles/text-and-typography/"], "features": { "report": true } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_app_table = resolveComponent("app-table");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_app_markup = resolveComponent("app-markup");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#cursor",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Cursor")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_app_table, {
                style: { "max-height": "420px" },
                "fixed-header": ""
              }, {
                default: withCtx(() => [
                  _hoisted_3,
                  _hoisted_4
                ]),
                _: 1
              }),
              createVNode(_component_promoted_entry),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_6,
                createVNode(_component_examples_example, { file: "cursor/usage" })
              ]),
              createBaseVNode("section", _hoisted_7, [
                createVNode(_component_app_heading, {
                  href: "#sass-variables",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("SASS variables")
                  ]),
                  _: 1
                }),
                _hoisted_8,
                createVNode(_component_app_markup, {
                  resource: "src/styles/settings.scss",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_9
                  ]),
                  _: 1
                }),
                _hoisted_10,
                createVNode(_component_app_markup, {
                  resource: "src/styles/settings.scss",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_11
                  ]),
                  _: 1
                })
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
