import { r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, b as createVNode, l as createElementBlock, F as Fragment, v as renderList, U as normalizeClass } from "./index-DGybHjCP.js";
const _sfc_main = {
  __name: "usage",
  setup(__props) {
    const cursors = [
      "auto",
      "default",
      "grab",
      "grabbing",
      "help",
      "move",
      "none",
      "not-allowed",
      "pointer",
      "progress",
      "text",
      "wait"
    ];
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_col = resolveComponent("v-col");
      const _component_v_row = resolveComponent("v-row");
      const _component_v_container = resolveComponent("v-container");
      return openBlock(), createBlock(_component_v_container, null, {
        default: withCtx(() => [
          createVNode(_component_v_row, { justify: "space-between" }, {
            default: withCtx(() => [
              (openBlock(), createElementBlock(Fragment, null, renderList(cursors, (cursor2) => {
                return createVNode(_component_v_col, {
                  key: cursor2,
                  cols: "3"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_v_btn, {
                      class: normalizeClass(`cursor-${cursor2}`),
                      text: cursor2,
                      block: ""
                    }, null, 8, ["class", "text"])
                  ]),
                  _: 2
                }, 1024);
              }), 64))
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __0 = _sfc_main;
const __0_raw = `<template>
  <v-container>
    <v-row justify="space-between">
      <v-col v-for="cursor in cursors" :key="cursor" cols="3">
        <v-btn
          :class="\`cursor-\${cursor}\`"
          :text="cursor"
          block
        ></v-btn>
      </v-col>
    </v-row>
  </v-container>
</template>

<script setup>
  const cursors = [
    'auto',
    'default',
    'grab',
    'grabbing',
    'help',
    'move',
    'none',
    'not-allowed',
    'pointer',
    'progress',
    'text',
    'wait',
  ]
<\/script>

<script>
  export default {
    data: () => ({
      cursors: [
        'auto',
        'default',
        'grab',
        'grabbing',
        'help',
        'move',
        'none',
        'not-allowed',
        'pointer',
        'progress',
        'text',
        'wait',
      ],
    }),
  }
<\/script>
`;
const cursor = {
  "usage": {
    component: __0,
    source: __0_raw
  }
};
export {
  cursor as default
};
