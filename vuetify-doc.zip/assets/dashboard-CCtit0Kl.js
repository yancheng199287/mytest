import { I as useDate, a5 as P, j as computed, r as resolveComponent, f as unref, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, t as toDisplayString, q as createCommentVNode, h as createTextVNode, d as defineComponent, a3 as R, b as createVNode, u as useHead } from "./index-DGybHjCP.js";
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("div", null, [
  /* @__PURE__ */ createTextVNode(" Vuetify One "),
  /* @__PURE__ */ createBaseVNode("span", { class: "font-weight-light" }, "Subscriber")
], -1);
const _hoisted_2 = { class: "text-caption font-weight-regular text-grey-lighten-2" };
const _sfc_main$2 = {
  __name: "OneSubCard",
  setup(__props) {
    const adapter = useDate();
    const one = P();
    const memberSince = computed(() => {
      if (!one.subscription)
        return "";
      const createdAt = one.subscription.createdAt;
      if (!adapter.isValid(createdAt))
        return "";
      return adapter.format(adapter.date(createdAt), "monthAndYear");
    });
    return (_ctx, _cache) => {
      const _component_v_card = resolveComponent("v-card");
      return unref(one).isSubscriber ? (openBlock(), createBlock(_component_v_card, {
        key: 0,
        class: "pa-4 text-white font-weight-bold d-flex align-start flex-column mt-2",
        image: "https://cdn.vuetifyjs.com/docs/images/one/banners/one-sub-banner.png",
        width: "250",
        flat: ""
      }, {
        default: withCtx(() => [
          _hoisted_1,
          createBaseVNode("div", _hoisted_2, " Since " + toDisplayString(unref(memberSince)), 1)
        ]),
        _: 1
      })) : createCommentVNode("", true);
    };
  }
};
const UserOneSubCard = _sfc_main$2;
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "DashboardEmptyState",
  setup(__props) {
    const auth = R();
    const text = computed(() => {
      return auth.user ? "This page will soon be home to the Vuetify One Dashboard." : "In order to proceed, please login using GitHub or Discord.";
    });
    return (_ctx, _cache) => {
      const _component_VoAuthCard = resolveComponent("VoAuthCard");
      const _component_v_empty_state = resolveComponent("v-empty-state");
      return openBlock(), createBlock(_component_v_empty_state, {
        text: unref(text),
        headline: "My Dashboard",
        height: "calc(100vh - var(--v-layout-top))"
      }, {
        default: withCtx(() => [
          createVNode(UserOneSubCard),
          !unref(auth).user ? (openBlock(), createBlock(_component_VoAuthCard, { key: 0 })) : createCommentVNode("", true)
        ]),
        _: 1
      }, 8, ["text"]);
    };
  }
});
const frontmatter = { "layout": "user", "meta": { "nav": "Dashboard", "title": "User Dashboard", "description": "User Dashboard", "keywords": "user dashboard" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "dashboard",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Dashboard", "title": "User Dashboard", "description": "User Dashboard", "keywords": "user dashboard" } };
    useHead(head);
    __expose({ frontmatter: { "layout": "user", "meta": { "nav": "Dashboard", "title": "User Dashboard", "description": "User Dashboard", "keywords": "user dashboard" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createVNode(_sfc_main$1)
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
