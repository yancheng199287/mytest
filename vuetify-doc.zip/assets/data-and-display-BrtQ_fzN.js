import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "data-and-display" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "Data table filtering is key feature that allows users to quickly find the data they are looking for.", -1);
const _hoisted_3 = { id: "filtering-examples" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("These examples demonstrate various ways that you can utilize the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "search"),
  /* @__PURE__ */ createTextVNode(" prop to filter results.")
], -1);
const _hoisted_5 = { id: "search" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The data table exposes a "),
  /* @__PURE__ */ createBaseVNode("strong", null, "search"),
  /* @__PURE__ */ createTextVNode(" prop that allows you to filter your data.")
], -1);
const _hoisted_7 = { id: "filterable" };
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can easily disable specific columns from being included when searching through table rows by setting the property "),
  /* @__PURE__ */ createBaseVNode("strong", null, "filterable"),
  /* @__PURE__ */ createTextVNode(" to false on the header item(s). In the example below the dessert name column is no longer searchable.")
], -1);
const _hoisted_9 = { id: "custom-filter" };
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can override the default filtering used with the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "search"),
  /* @__PURE__ */ createTextVNode(" prop by supplying a function to the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "custom-filter"),
  /* @__PURE__ */ createTextVNode(" prop. You can see the signature of the function below.")
], -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-ts" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-ts" }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createTextVNode("value"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "string"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode(" query"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "string"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode(" item"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "?"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "any"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "=>"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "boolean"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "|"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "number"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "|"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "["),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "number"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "number"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "]"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "|"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "["),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "number"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "number"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "]"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "["),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "]"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("p", null, "In the example below, the custom filter will only match inputs that are in completely in upper case.", -1);
const _hoisted_13 = { id: "pagination-examples" };
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("p", null, "Pagination is used to split up large amounts of data into smaller chunks.", -1);
const _hoisted_15 = { id: "external-pagination" };
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Pagination can be controlled externally by using the individual props, or by using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "options"),
  /* @__PURE__ */ createTextVNode(" prop. Remember that you must apply the "),
  /* @__PURE__ */ createBaseVNode("strong", null, ".sync"),
  /* @__PURE__ */ createTextVNode(" modifier.")
], -1);
const _hoisted_17 = { id: "selection-examples" };
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("p", null, "Selection allows you to select/deselect rows and retrieve information about which rows have been selected.", -1);
const _hoisted_19 = { id: "item-value" };
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("For the selection feature to work, the data table must be able to differentiate each row in the data set. This is done using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "item-value"),
  /* @__PURE__ */ createTextVNode(" prop. It designates a property on the item that should contain a unique value. By default the property it looks for is "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "id"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("p", null, "You can also supply a function, if for example the unique value needs to be a composite of several properties. The function receives each item as its first argument.", -1);
const _hoisted_22 = { id: "selected-values" };
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The current selection of the data-table can be accessed through the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "v-model"),
  /* @__PURE__ */ createTextVNode(" prop. The array will consist of the unique values found in the property you set using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "item-value"),
  /* @__PURE__ */ createTextVNode(" prop (or the value returned by the function you passed). You can use "),
  /* @__PURE__ */ createBaseVNode("strong", null, "return-object"),
  /* @__PURE__ */ createTextVNode(" prop if you want the array to consist of the actual objects instead.")
], -1);
const _hoisted_24 = { id: "selectable-rows" };
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Use the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "item-selectable"),
  /* @__PURE__ */ createTextVNode(" prop to designate a property on your items that controls if the item should be selectable or not.")
], -1);
const _hoisted_26 = { id: "select-strategies" };
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("p", null, "Data-tables support three different select strategies.", -1);
const _hoisted_28 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Strategy"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_29 = /* @__PURE__ */ createBaseVNode("tbody", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "'single'")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "Only a single row can be selected. The select all checkbox in the header is not shown")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "'page'")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "Multiple rows can be selected. Clicking on the select all checkbox in the header selects all (selectable) rows on the current page")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "'all'")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "Multiple rows can be selected. Clicking on the select all checkbox in the header selects all (selectable) rows in the entire data set")
  ])
], -1);
const _hoisted_30 = { id: "sorting-examples" };
const _hoisted_31 = /* @__PURE__ */ createBaseVNode("p", null, "Data tables can sort rows by a column value.", -1);
const _hoisted_32 = { id: "basic-sorting" };
const _hoisted_33 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The sorting of your table can be controlled by the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "sort-by"),
  /* @__PURE__ */ createTextVNode(" prop. This prop takes an array of objects, where each object has a "),
  /* @__PURE__ */ createBaseVNode("strong", null, "key"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "order"),
  /* @__PURE__ */ createTextVNode(" property, describing how the table is to be sorted.")
], -1);
const _hoisted_34 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "key"),
  /* @__PURE__ */ createTextVNode(" corresponds to a column defined in the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "headers"),
  /* @__PURE__ */ createTextVNode(" array, and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "order"),
  /* @__PURE__ */ createTextVNode(" is either the string "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "'asc'"),
  /* @__PURE__ */ createTextVNode(" or "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "'desc'"),
  /* @__PURE__ */ createTextVNode(" indicating the order in which the items are sorted.")
], -1);
const _hoisted_35 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Unless you are using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "multi-sort"),
  /* @__PURE__ */ createTextVNode(" prop seen below, this array will almost always just have a single object in it.")
], -1);
const _hoisted_36 = { id: "multi-sort" };
const _hoisted_37 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "multi-sort"),
  /* @__PURE__ */ createTextVNode(" prop will enable you to sort on multiple columns at the same time.")
], -1);
const _hoisted_38 = { id: "sort-by-raw" };
const _hoisted_39 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Using a "),
  /* @__PURE__ */ createBaseVNode("em", null, "sortRaw"),
  /* @__PURE__ */ createTextVNode(" key in your headers object gives you access to all values on the item. This is useful if you want to sort by a value that is not displayed in the table or a combination of multiple values.")
], -1);
const frontmatter = { "meta": { "nav": "Data and Display", "title": "Data table - Data and Display", "description": "The data table component is used for displaying tabular data in a way that is easy for users to scan. It includes sorting, searching, pagination and selection.", "keywords": "data tables, vuetify data table component, vue data table component" }, "related": ["/components/data-tables/basics/", "/components/paginations/", "/components/tables/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "data-and-display",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Data and Display", "title": "Data table - Data and Display", "description": "The data table component is used for displaying tabular data in a way that is easy for users to scan. It includes sorting, searching, pagination and selection.", "keywords": "data tables, vuetify data table component, vue data table component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Data and Display", "title": "Data table - Data and Display", "description": "The data table component is used for displaying tabular data in a way that is easy for users to scan. It includes sorting, searching, pagination and selection.", "keywords": "data tables, vuetify data table component, vue data table component" }, "related": ["/components/data-tables/basics/", "/components/paginations/", "/components/tables/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_app_markup = resolveComponent("app-markup");
      const _component_app_table = resolveComponent("app-table");
      const _component_app_link = resolveComponent("app-link");
      const _component_alert = resolveComponent("alert");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#data-and-display",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Data and Display")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_promoted_entry),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#filtering-examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Filtering examples")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createBaseVNode("section", _hoisted_5, [
                  createVNode(_component_app_heading, {
                    href: "#search",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Search")
                    ]),
                    _: 1
                  }),
                  _hoisted_6,
                  createVNode(_component_examples_example, { file: "v-data-table/prop-search" })
                ]),
                createBaseVNode("section", _hoisted_7, [
                  createVNode(_component_app_heading, {
                    href: "#filterable",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Filterable")
                    ]),
                    _: 1
                  }),
                  _hoisted_8,
                  createVNode(_component_examples_example, { file: "v-data-table/prop-filterable" })
                ]),
                createBaseVNode("section", _hoisted_9, [
                  createVNode(_component_app_heading, {
                    href: "#custom-filter",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Custom filter")
                    ]),
                    _: 1
                  }),
                  _hoisted_10,
                  createVNode(_component_app_markup, {
                    resource: "",
                    class: "mb-4"
                  }, {
                    default: withCtx(() => [
                      _hoisted_11
                    ]),
                    _: 1
                  }),
                  _hoisted_12,
                  createVNode(_component_examples_example, { file: "v-data-table/prop-custom-filter" })
                ])
              ]),
              createBaseVNode("section", _hoisted_13, [
                createVNode(_component_app_heading, {
                  href: "#pagination-examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Pagination examples")
                  ]),
                  _: 1
                }),
                _hoisted_14,
                createBaseVNode("section", _hoisted_15, [
                  createVNode(_component_app_heading, {
                    href: "#external-pagination",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("External pagination")
                    ]),
                    _: 1
                  }),
                  _hoisted_16,
                  createVNode(_component_examples_example, { file: "v-data-table/misc-external-paginate" })
                ])
              ]),
              createBaseVNode("section", _hoisted_17, [
                createVNode(_component_app_heading, {
                  href: "#selection-examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Selection examples")
                  ]),
                  _: 1
                }),
                _hoisted_18,
                createBaseVNode("section", _hoisted_19, [
                  createVNode(_component_app_heading, {
                    href: "#item-value",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Item value")
                    ]),
                    _: 1
                  }),
                  _hoisted_20,
                  _hoisted_21,
                  createVNode(_component_examples_example, { file: "v-data-table/prop-item-value" })
                ]),
                createBaseVNode("section", _hoisted_22, [
                  createVNode(_component_app_heading, {
                    href: "#selected-values",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Selected values")
                    ]),
                    _: 1
                  }),
                  _hoisted_23,
                  createVNode(_component_examples_example, { file: "v-data-table/prop-return-object" }),
                  createVNode(_component_promoted_entry)
                ]),
                createBaseVNode("section", _hoisted_24, [
                  createVNode(_component_app_heading, {
                    href: "#selectable-rows",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Selectable rows")
                    ]),
                    _: 1
                  }),
                  _hoisted_25,
                  createVNode(_component_examples_example, { file: "v-data-table/prop-item-selectable" })
                ]),
                createBaseVNode("section", _hoisted_26, [
                  createVNode(_component_app_heading, {
                    href: "#select-strategies",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Select strategies")
                    ]),
                    _: 1
                  }),
                  _hoisted_27,
                  createVNode(_component_app_table, null, {
                    default: withCtx(() => [
                      _hoisted_28,
                      _hoisted_29
                    ]),
                    _: 1
                  }),
                  createVNode(_component_examples_example, { file: "v-data-table/prop-select-strategy" })
                ])
              ]),
              createBaseVNode("section", _hoisted_30, [
                createVNode(_component_app_heading, {
                  href: "#sorting-examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Sorting examples")
                  ]),
                  _: 1
                }),
                _hoisted_31,
                createVNode(_component_promoted_entry),
                createBaseVNode("section", _hoisted_32, [
                  createVNode(_component_app_heading, {
                    href: "#basic-sorting",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Basic sorting")
                    ]),
                    _: 1
                  }),
                  _hoisted_33,
                  _hoisted_34,
                  _hoisted_35,
                  createVNode(_component_examples_example, { file: "v-data-table/prop-sort-by" })
                ]),
                createBaseVNode("section", _hoisted_36, [
                  createVNode(_component_app_heading, {
                    href: "#multi-sort",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Multi sort")
                    ]),
                    _: 1
                  }),
                  _hoisted_37,
                  createVNode(_component_examples_example, { file: "v-data-table/prop-multi-sort" })
                ]),
                createBaseVNode("section", _hoisted_38, [
                  createVNode(_component_app_heading, {
                    href: "#sort-by-raw",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Sort by raw")
                    ]),
                    _: 1
                  }),
                  createVNode(_component_alert, { type: "success" }, {
                    default: withCtx(() => [
                      createBaseVNode("p", null, [
                        createTextVNode("This feature was introduced in "),
                        createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v3.5.0" }, {
                          default: withCtx(() => [
                            createTextVNode("v3.5.0 (Polaris)")
                          ]),
                          _: 1
                        })
                      ])
                    ]),
                    _: 1
                  }),
                  _hoisted_39,
                  createVNode(_component_examples_example, { file: "v-data-table/prop-headers-sort-raw" })
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
