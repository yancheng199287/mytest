import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "date-inputs" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-date-input"),
  /* @__PURE__ */ createTextVNode(" component combines a text field with a date picker. It is meant to be a direct replacement for a standard date input.")
], -1);
const _hoisted_3 = { id: "installation" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, "Labs components require a manual import and installation of the component.", -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-js" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/plugins/vuetify.js",
    class: "language-js"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" VDateInput "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify/labs/VDateInput'"),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "export"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "default"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "createVuetify"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "components"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n    VDateInput"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_6 = { id: "usage" };
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-date-input", -1);
const _hoisted_8 = { id: "api" };
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("td", null, "Primary component", -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("td", null, "Date picker component", -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("td", null, "Text field component", -1);
const _hoisted_13 = { id: "guide" };
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-date-input"),
  /* @__PURE__ */ createTextVNode(" component is a replacement for the standard date input. It provides a clean interface for selecting dates and shows detailed selection information.")
], -1);
const _hoisted_15 = { id: "props" };
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-date-input", -1);
const _hoisted_17 = { id: "model" };
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("p", null, "The default model value is a Date object, but is displayed as formatted text in the input…", -1);
const _hoisted_19 = { id: "multiple" };
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "multiple"),
  /* @__PURE__ */ createTextVNode(" prop, the default model value is an empty array.")
], -1);
const _hoisted_21 = { id: "range" };
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Using the multiple prop with a value of "),
  /* @__PURE__ */ createBaseVNode("strong", null, "range"),
  /* @__PURE__ */ createTextVNode(", select 2 dates to select them and all the dates between them.")
], -1);
const _hoisted_23 = { id: "calendar-icon" };
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can move the calendar icon within the input or entirely by utilizing the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "prepend-icon"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "prepend-inner-icon"),
  /* @__PURE__ */ createTextVNode(" properties.")
], -1);
const _hoisted_25 = { id: "examples" };
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The following are a collection of examples that demonstrate more advanced and real world use of the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-date-input"),
  /* @__PURE__ */ createTextVNode(" component.")
], -1);
const _hoisted_27 = { id: "passenger" };
const _hoisted_28 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("In this example, the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-date-input"),
  /* @__PURE__ */ createTextVNode(" component is used to select a date of birth.")
], -1);
const frontmatter = { "emphasized": true, "meta": { "nav": "Date inputs", "title": "Date input component", "description": "The date input is a specialized input that provides a clean interface for selecting dates, showing detailed selection information.", "keywords": "date input, date picker, date field" }, "related": ["/components/date-pickers/", "/components/text-fields/", "/components/menus/"], "features": { "label": "C: VDateInput", "report": true, "github": "/labs/VDateInput/" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "date-inputs",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Date inputs", "title": "Date input component", "description": "The date input is a specialized input that provides a clean interface for selecting dates, showing detailed selection information.", "keywords": "date input, date picker, date field" } };
    useHead(head);
    __expose({ frontmatter: { "emphasized": true, "meta": { "nav": "Date inputs", "title": "Date input component", "description": "The date input is a specialized input that provides a clean interface for selecting dates, showing detailed selection information.", "keywords": "date input, date picker, date field" }, "related": ["/components/date-pickers/", "/components/text-fields/", "/components/menus/"], "features": { "label": "C: VDateInput", "report": true, "github": "/labs/VDateInput/" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_app_link = resolveComponent("app-link");
      const _component_alert = resolveComponent("alert");
      const _component_app_markup = resolveComponent("app-markup");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#date-inputs",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Date inputs")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_alert, { type: "warning" }, {
                default: withCtx(() => [
                  createBaseVNode("p", null, [
                    createTextVNode("This feature requires "),
                    createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v3.6.0" }, {
                      default: withCtx(() => [
                        createTextVNode("v3.6.0")
                      ]),
                      _: 1
                    })
                  ])
                ]),
                _: 1
              }),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#installation",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Installation")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_app_markup, {
                  resource: "src/plugins/vuetify.js",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_5
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_6, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("At its core, the "),
                  _hoisted_7,
                  createTextVNode(" component is a basic container that extends "),
                  createVNode(_component_app_link, { href: "/components/text-fields" }, {
                    default: withCtx(() => [
                      createTextVNode("v-text-field")
                    ]),
                    _: 1
                  }),
                  createTextVNode(".")
                ]),
                createVNode(_component_examples_usage, { name: "v-date-input" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_8, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_9,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-date-input/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-date-input")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_10
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-date-picker/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-date-picker")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_11
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-text-field/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-text-field")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_12
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_13, [
                createVNode(_component_app_heading, {
                  href: "#guide",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Guide")
                  ]),
                  _: 1
                }),
                _hoisted_14,
                createBaseVNode("section", _hoisted_15, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("p", null, [
                    createTextVNode("The "),
                    _hoisted_16,
                    createTextVNode(" component extends the "),
                    createVNode(_component_app_link, { href: "/components/text-fields/" }, {
                      default: withCtx(() => [
                        createTextVNode("v-text-field")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" and "),
                    createVNode(_component_app_link, { href: "/components/date-pickers/" }, {
                      default: withCtx(() => [
                        createTextVNode("v-date-picker")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" component; and supports all of their props.")
                  ]),
                  createBaseVNode("section", _hoisted_17, [
                    createVNode(_component_app_heading, {
                      href: "#model",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Model")
                      ]),
                      _: 1
                    }),
                    _hoisted_18,
                    createVNode(_component_examples_example, { file: "v-date-input/prop-model" })
                  ]),
                  createBaseVNode("section", _hoisted_19, [
                    createVNode(_component_app_heading, {
                      href: "#multiple",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Multiple")
                      ]),
                      _: 1
                    }),
                    _hoisted_20,
                    createVNode(_component_examples_example, { file: "v-date-input/prop-multiple" })
                  ]),
                  createBaseVNode("section", _hoisted_21, [
                    createVNode(_component_app_heading, {
                      href: "#range",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Range")
                      ]),
                      _: 1
                    }),
                    _hoisted_22,
                    createVNode(_component_examples_example, { file: "v-date-input/prop-multiple-range" })
                  ]),
                  createBaseVNode("section", _hoisted_23, [
                    createVNode(_component_app_heading, {
                      href: "#calendar-icon",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Calendar icon")
                      ]),
                      _: 1
                    }),
                    _hoisted_24,
                    createVNode(_component_examples_example, { file: "v-date-input/prop-prepend-icon" })
                  ])
                ])
              ]),
              createBaseVNode("section", _hoisted_25, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                _hoisted_26,
                createBaseVNode("section", _hoisted_27, [
                  createVNode(_component_app_heading, {
                    href: "#passenger",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Passenger")
                    ]),
                    _: 1
                  }),
                  _hoisted_28,
                  createVNode(_component_examples_example, { file: "v-date-input/misc-passenger" })
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
