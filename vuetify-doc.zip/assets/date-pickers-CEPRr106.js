import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "date-pickers" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-date-picker"),
  /* @__PURE__ */ createTextVNode(" is a fully featured date selection component that lets users select a date.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Date pickers come in two orientation variations, portrait "),
  /* @__PURE__ */ createBaseVNode("strong", null, "(default)"),
  /* @__PURE__ */ createTextVNode(" and landscape. By default they are emitting "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "input"),
  /* @__PURE__ */ createTextVNode(" event when the day (for date picker) or month (for month picker), but with "),
  /* @__PURE__ */ createBaseVNode("strong", null, "reactive"),
  /* @__PURE__ */ createTextVNode(" prop they can update the model even after clicking year/month.")
], -1);
const _hoisted_5 = { id: "api" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_8 = { id: "guide" };
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-date-picker", -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-js" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-js" }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(" DayJsAdapter "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'@date-io/dayjs'"),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "createVuetify"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "date"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "adapter"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(" DayJsAdapter"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_11 = { id: "props" };
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-date-picker"),
  /* @__PURE__ */ createTextVNode(" component supports multiple props for configuring dates that can be selected, date formats, translations and more.")
], -1);
const _hoisted_13 = { id: "elevation" };
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-date-picker", -1);
const _hoisted_15 = { id: "width" };
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("p", null, "You can specify the picker’s width or make it full width.", -1);
const _hoisted_17 = { id: "show-sibling-months" };
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("By default days from previous and next months are not visible. They can be displayed using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "show-adjacent-months"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_19 = { id: "colors" };
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Date picker colors can be set using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "color"),
  /* @__PURE__ */ createTextVNode(" props.")
], -1);
const _hoisted_21 = { id: "allowed-dates" };
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("p", null, "Specify allowed dates using objects or functions. When using objects, accepts a date string in the format of YYYY-MM-DD. When using functions, accepts a date object as a parameter and should return a boolean.", -1);
const _hoisted_23 = { id: "internationalization" };
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("p", null, "For those not using the default date adapter, you need to create a mapping between the i18n locale string and your chosen date library’s locale. This can be done in the Vuetify options as shown below:", -1);
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-js" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-js" }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(" DateFnsAdapter "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'@date-io/date-fns'"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(" enUS "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'date-fns/locale/en-US'"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(" svSE "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'date-fns/locale/sv'"),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "createVuetify"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "date"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "adapter"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(" DateFnsAdapter"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "locale"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "en"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(" enUS"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "sv"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(" svSE"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_26 = { id: "parsing-dates" };
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-js" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-js" }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" useDate "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify'"),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "const"),
    /* @__PURE__ */ createTextVNode(" adapter "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "="),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "useDate"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "const"),
    /* @__PURE__ */ createTextVNode(" date "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "="),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'2023-11-30'"),
    /* @__PURE__ */ createTextVNode("\n\nconsole"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "."),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "log"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "new"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token class-name" }, "Date"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createTextVNode("date"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// Wed Nov 29 2023 18:00:00 GMT-0600"),
    /* @__PURE__ */ createTextVNode("\nconsole"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "."),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "log"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createTextVNode("adapter"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "."),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "parseISO"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createTextVNode("date"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// Thu Nov 30 2023 00:00:00 GMT-0600"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_28 = /* @__PURE__ */ createBaseVNode("p", null, "Using this function ensures that the date is parsed correctly regardless of the user’s timezone.", -1);
const frontmatter = { "meta": { "title": "Date pickers", "description": "The date picker component is a stand-alone interface that allows the selection of a date, month and year.", "keywords": "date pickers, vuetify date picker component, vue date picker component" }, "related": ["/components/buttons/", "/features/dates/", "/components/text-fields/"], "features": { "github": "/components/VDatePicker/", "label": "C: VDatePicker", "report": true, "spec": "https://m2.material.io/components/date-pickers" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "date-pickers",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "Date pickers", "description": "The date picker component is a stand-alone interface that allows the selection of a date, month and year.", "keywords": "date pickers, vuetify date picker component, vue date picker component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "title": "Date pickers", "description": "The date picker component is a stand-alone interface that allows the selection of a date, month and year.", "keywords": "date pickers, vuetify date picker component, vue date picker component" }, "related": ["/components/buttons/", "/features/dates/", "/components/text-fields/"], "features": { "github": "/components/VDatePicker/", "label": "C: VDatePicker", "report": true, "spec": "https://m2.material.io/components/date-pickers" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_app_figure = resolveComponent("app-figure");
      const _component_page_features = resolveComponent("page-features");
      const _component_app_link = resolveComponent("app-link");
      const _component_alert = resolveComponent("alert");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_app_markup = resolveComponent("app-markup");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#date-pickers",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Date pickers")
                ]),
                _: 1
              }),
              _hoisted_2,
              createBaseVNode("p", null, [
                createBaseVNode("div", null, [
                  createVNode(_component_app_figure, {
                    alt: "Date picker Entry",
                    src: "https://cdn.vuetifyjs.com/docs/images/components/v-date-picker/v-date-picker-entry.png"
                  })
                ])
              ]),
              createVNode(_component_page_features),
              createVNode(_component_alert, { type: "success" }, {
                default: withCtx(() => [
                  createBaseVNode("p", null, [
                    createTextVNode("This feature was introduced in "),
                    createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v3.4.0" }, {
                      default: withCtx(() => [
                        createTextVNode("v3.4.0 (Blackguard)")
                      ]),
                      _: 1
                    })
                  ])
                ]),
                _: 1
              }),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_usage, { name: "v-date-picker" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_6,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-date-picker/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-date-picker")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_8, [
                createVNode(_component_app_heading, {
                  href: "#guide",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Guide")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("The "),
                  _hoisted_9,
                  createTextVNode(" component is a stand-alone interface that allows the selection of a date, month and year. This component is built using the "),
                  createVNode(_component_app_link, { href: "/features/dates/" }, {
                    default: withCtx(() => [
                      createTextVNode("Date composable")
                    ]),
                    _: 1
                  }),
                  createTextVNode(".")
                ]),
                createBaseVNode("p", null, [
                  createTextVNode("All date components support the "),
                  createVNode(_component_app_link, { href: "https://github.com/dmtrKovalenko/date-io" }, {
                    default: withCtx(() => [
                      createTextVNode("date-io")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" abstraction layer for date management. By default they will use a built-in adapter that uses the native Date object, but it is possible to use any of the date-io adapters. See the "),
                  createVNode(_component_app_link, { href: "/features/dates/" }, {
                    default: withCtx(() => [
                      createTextVNode("dates")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" page for more information.")
                ]),
                createVNode(_component_app_markup, {
                  resource: "",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_10
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_11, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  _hoisted_12,
                  createBaseVNode("section", _hoisted_13, [
                    createVNode(_component_app_heading, {
                      href: "#elevation",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Elevation")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("The "),
                      _hoisted_14,
                      createTextVNode(" component supports elevation up to a maximum value of 24. For more information on elevations, visit the official "),
                      createVNode(_component_app_link, { href: "https://material.io/design/environment/elevation.html" }, {
                        default: withCtx(() => [
                          createTextVNode("Material Design elevations")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" page.")
                    ]),
                    createVNode(_component_examples_example, { file: "v-date-picker/prop-elevation" })
                  ]),
                  createBaseVNode("section", _hoisted_15, [
                    createVNode(_component_app_heading, {
                      href: "#width",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Width")
                      ]),
                      _: 1
                    }),
                    _hoisted_16,
                    createVNode(_component_examples_example, { file: "v-date-picker/prop-width" })
                  ]),
                  createBaseVNode("section", _hoisted_17, [
                    createVNode(_component_app_heading, {
                      href: "#show-sibling-months",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Show sibling months")
                      ]),
                      _: 1
                    }),
                    _hoisted_18,
                    createVNode(_component_examples_example, { file: "v-date-picker/prop-show-adjacent-months" })
                  ]),
                  createBaseVNode("section", _hoisted_19, [
                    createVNode(_component_app_heading, {
                      href: "#colors",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Colors")
                      ]),
                      _: 1
                    }),
                    _hoisted_20,
                    createVNode(_component_examples_example, { file: "v-date-picker/prop-colors" })
                  ]),
                  createBaseVNode("section", _hoisted_21, [
                    createVNode(_component_app_heading, {
                      href: "#allowed-dates",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Allowed dates")
                      ]),
                      _: 1
                    }),
                    _hoisted_22,
                    createVNode(_component_examples_example, { file: "v-date-picker/prop-allowed-dates" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_23, [
                  createVNode(_component_app_heading, {
                    href: "#internationalization",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Internationalization")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("p", null, [
                    createTextVNode("Vuetify components can localize date formats by utilizing the "),
                    createVNode(_component_app_link, { href: "/features/internationalization" }, {
                      default: withCtx(() => [
                        createTextVNode("i18n")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" feature. This determines the appropriate locale for date display. When the default date adapter is in use, localization is managed automatically.")
                  ]),
                  _hoisted_24,
                  createVNode(_component_app_markup, {
                    resource: "",
                    class: "mb-4"
                  }, {
                    default: withCtx(() => [
                      _hoisted_25
                    ]),
                    _: 1
                  })
                ]),
                createBaseVNode("section", _hoisted_26, [
                  createVNode(_component_app_heading, {
                    href: "#parsing-dates",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Parsing dates")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("p", null, [
                    createTextVNode("It’s recommended that you use the "),
                    createVNode(_component_app_link, { href: "/features/dates/" }, {
                      default: withCtx(() => [
                        createTextVNode("Date composable")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" for parsing and formatting when working with string dates. The following example uses the parseISO function to convert a string date to a Date object.")
                  ]),
                  createVNode(_component_app_markup, {
                    resource: "",
                    class: "mb-4"
                  }, {
                    default: withCtx(() => [
                      _hoisted_27
                    ]),
                    _: 1
                  }),
                  _hoisted_28
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
