import { i as useI18n, a as useRoute, j as computed, k as getBranch, o as openBlock, l as createElementBlock, e as createBaseVNode, t as toDisplayString, f as unref, b as createVNode, w as withCtx, h as createTextVNode, _ as _sfc_main$9, m as useAppStore, n as useRouter, g as rpath, p as useRtl, r as resolveComponent, c as createBlock, q as createCommentVNode, s as upperFirst, F as Fragment, v as renderList, x as _sfc_main$a, y as _export_sfc, z as _sfc_main$b, A as useGoTo, B as shallowRef, C as resolveDirective, D as withDirectives, E as isRef, G as defineStore, H as useCosmic, I as useDate, J as ref, K as onBeforeMount, d as defineComponent, L as storeToRefs, M as useTheme, N as F, O as watch, P as onMounted, Q as onScopeDispose, R as useSponsorsStore, S as createSlots, T as gtagClick, U as normalizeClass, V as withModifiers, W as nextTick, X as _sfc_main$c, Y as _sfc_main$d, Z as renderSlot, $ as _sfc_main$e, a0 as _sfc_main$f, a1 as normalizeStyle, a2 as resolveDynamicComponent } from "./index-DGybHjCP.js";
import { _ as _sfc_main$g } from "./Drawer-SbZ4cLFe.js";
const _hoisted_1$4 = { class: "font-weight-bold me-1 text-medium-emphasis" };
const _sfc_main$8 = {
  __name: "Contribute",
  setup(__props) {
    const { t } = useI18n();
    const route = useRoute();
    const href = computed(() => {
      const branch = getBranch();
      const link = route.path.split("/").slice(2).filter((v) => v).join("/");
      return `https://github.com/vuetifyjs/vuetify/tree/${branch}/packages/docs/src/pages/en/${link}.md`;
    });
    return (_ctx, _cache) => {
      const _component_AppLink = _sfc_main$9;
      return openBlock(), createElementBlock("div", null, [
        createBaseVNode("span", _hoisted_1$4, toDisplayString(unref(t)("edit-this-page")), 1),
        createVNode(_component_AppLink, { href: unref(href) }, {
          default: withCtx(() => [
            createTextVNode(toDisplayString(unref(t)("github")), 1)
          ]),
          _: 1
        }, 8, ["href"])
      ]);
    };
  }
};
const _hoisted_1$3 = {
  id: "up-next",
  class: "d-flex mb-5"
};
const _hoisted_2$1 = ["textContent"];
const _hoisted_3$1 = ["textContent"];
const _sfc_main$7 = {
  __name: "UpNext",
  setup(__props) {
    const { pages } = useAppStore();
    const route = useRoute();
    const path = computed(() => route.path.split("/").slice(2, -1));
    const routes = computed(() => useRouter().getRoutes());
    const currentIndex = computed(() => pages.indexOf(path.value.join("/")));
    const prev = computed(() => {
      if (currentIndex.value === -1)
        return false;
      const prevPath = rpath(pages[currentIndex.value - 1]);
      if (prevPath == null)
        return false;
      return routes.value.find((r) => r.path === prevPath);
    });
    const next = computed(() => {
      if (currentIndex.value === -1)
        return false;
      const nextPath = rpath(pages[currentIndex.value + 1]);
      return routes.value.find((r) => r.path === nextPath);
    });
    const { isRtl } = useRtl();
    const arrows = computed(() => ({
      next: !isRtl ? "mdi-chevron-left" : "mdi-chevron-right",
      prev: !isRtl ? "mdi-chevron-right" : "mdi-chevron-left"
    }));
    return (_ctx, _cache) => {
      const _component_v_icon = resolveComponent("v-icon");
      const _component_router_link = resolveComponent("router-link");
      const _component_v_spacer = resolveComponent("v-spacer");
      return openBlock(), createElementBlock("div", _hoisted_1$3, [
        unref(prev) && unref(prev).name !== "home" ? (openBlock(), createBlock(_component_router_link, {
          key: 0,
          to: unref(prev).path,
          class: "text-decoration-none text-body-1 d-inline-flex align-center"
        }, {
          default: withCtx(() => [
            createVNode(_component_v_icon, {
              icon: unref(arrows).prev,
              class: "me-1",
              color: "primary"
            }, null, 8, ["icon"]),
            createBaseVNode("span", {
              class: "text-primary",
              textContent: toDisplayString(unref(prev).meta.nav ?? unref(prev).meta.title)
            }, null, 8, _hoisted_2$1)
          ]),
          _: 1
        }, 8, ["to"])) : createCommentVNode("", true),
        createVNode(_component_v_spacer),
        unref(next) ? (openBlock(), createBlock(_component_router_link, {
          key: 1,
          to: unref(next).path,
          class: "text-decoration-none text-body-1 d-inline-flex align-center"
        }, {
          default: withCtx(() => [
            createBaseVNode("span", {
              class: "text-primary",
              textContent: toDisplayString(unref(next).meta.nav ?? unref(next).meta.title)
            }, null, 8, _hoisted_3$1),
            createVNode(_component_v_icon, {
              icon: unref(arrows).next,
              class: "ms-1",
              color: "primary"
            }, null, 8, ["icon"])
          ]),
          _: 1
        }, 8, ["to"])) : createCommentVNode("", true)
      ]);
    };
  }
};
const _sfc_main$6 = {
  __name: "RelatedPage",
  props: { to: String },
  setup(__props) {
    const appStore = useAppStore();
    const props = __props;
    const routes = useRouter().getRoutes();
    const path = rpath(props.to);
    const item = routes.find((r) => r.path === path);
    const category = path.split("/")[2];
    const icon = computed(() => appStore.categories[category]);
    const subtitle = upperFirst(category.replace("-", " "));
    return (_ctx, _cache) => {
      const _component_v_icon = resolveComponent("v-icon");
      const _component_v_avatar = resolveComponent("v-avatar");
      const _component_v_list_item = resolveComponent("v-list-item");
      return unref(item) ? (openBlock(), createBlock(_component_v_list_item, {
        key: 0,
        subtitle: unref(subtitle),
        title: unref(item).meta.nav ?? unref(item).meta.title,
        to: unref(item).path,
        lines: "two",
        border: "",
        rounded: ""
      }, {
        prepend: withCtx(() => [
          createVNode(_component_v_avatar, null, {
            default: withCtx(() => [
              createVNode(_component_v_icon, {
                color: unref(icon).color,
                icon: unref(icon).icon
              }, null, 8, ["color", "icon"])
            ]),
            _: 1
          })
        ]),
        _: 1
      }, 8, ["subtitle", "title", "to"])) : createCommentVNode("", true);
    };
  }
};
const _sfc_main$5 = {
  __name: "RelatedPages",
  setup(__props) {
    const related = useRoute().meta.related;
    return (_ctx, _cache) => {
      var _a;
      const _component_DocRelatedPage = _sfc_main$6;
      const _component_v_col = resolveComponent("v-col");
      const _component_v_row = resolveComponent("v-row");
      return ((_a = unref(related)) == null ? void 0 : _a.length) > 0 ? (openBlock(), createBlock(_component_v_row, {
        key: 0,
        dense: ""
      }, {
        default: withCtx(() => [
          (openBlock(true), createElementBlock(Fragment, null, renderList(unref(related), (to, i) => {
            return openBlock(), createBlock(_component_v_col, {
              key: i,
              cols: "12",
              sm: "4",
              xs: "6"
            }, {
              default: withCtx(() => [
                createVNode(_component_DocRelatedPage, { to }, null, 8, ["to"])
              ]),
              _: 2
            }, 1024);
          }), 128))
        ]),
        _: 1
      })) : createCommentVNode("", true);
    };
  }
};
const _hoisted_1$2 = { class: "mb-3" };
const _sfc_main$4 = {
  __name: "ReadyForMore",
  setup(__props) {
    const { t } = useI18n();
    return (_ctx, _cache) => {
      const _component_AppHeading = _sfc_main$a;
      const _component_AppLink = _sfc_main$9;
      const _component_i18n_t = resolveComponent("i18n-t");
      return openBlock(), createElementBlock("div", _hoisted_1$2, [
        createVNode(_component_AppHeading, {
          content: unref(t)("ready"),
          class: "mb-2",
          level: "2"
        }, null, 8, ["content"]),
        createVNode(_component_i18n_t, {
          keypath: "ready-text",
          scope: "global",
          tag: "div"
        }, {
          team: withCtx(() => [
            createVNode(_component_AppLink, {
              href: ("rpath" in _ctx ? _ctx.rpath : unref(rpath))("/about/meet-the-team/")
            }, {
              default: withCtx(() => [
                createTextVNode(toDisplayString(unref(t)("team")), 1)
              ]),
              _: 1
            }, 8, ["href"])
          ]),
          _: 1
        })
      ]);
    };
  }
};
const _sfc_main$3 = {};
const _hoisted_1$1 = {
  id: "ready-for-more",
  class: "mt-16"
};
function _sfc_render(_ctx, _cache) {
  const _component_DocReadyForMore = _sfc_main$4;
  const _component_DocRelatedPages = _sfc_main$5;
  const _component_AppDivider = _sfc_main$b;
  const _component_DocUpNext = _sfc_main$7;
  const _component_DocContribute = _sfc_main$8;
  return openBlock(), createElementBlock("section", _hoisted_1$1, [
    createVNode(_component_DocReadyForMore),
    createVNode(_component_DocRelatedPages),
    createVNode(_component_AppDivider),
    createVNode(_component_DocUpNext),
    createVNode(_component_DocContribute)
  ]);
}
const __unplugin_components_5 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["render", _sfc_render]]);
const _sfc_main$2 = {
  __name: "BackToTop",
  setup(__props) {
    const goTo = useGoTo({ layout: true });
    const model = shallowRef(false);
    function onScroll() {
      model.value = window.scrollY > 200;
    }
    return (_ctx, _cache) => {
      const _component_v_fab = resolveComponent("v-fab");
      const _directive_scroll = resolveDirective("scroll");
      return withDirectives((openBlock(), createBlock(_component_v_fab, {
        modelValue: unref(model),
        "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(model) ? model.value = $event : null),
        color: "primary",
        elevation: "8",
        icon: "mdi-chevron-up",
        size: "large",
        app: "",
        onClick: _cache[1] || (_cache[1] = ($event) => unref(goTo)(0))
      }, null, 8, ["modelValue"])), [
        [_directive_scroll, onScroll]
      ]);
    };
  }
};
const useSpotStore = defineStore("spot", () => {
  const { bucket } = useCosmic();
  const adapter = useDate();
  const today = adapter.startOfDay(adapter.date());
  const tomorrow = adapter.endOfDay(today);
  const spots = ref([]);
  const spot = computed(() => {
    var _a;
    return (_a = spots.value[0]) == null ? void 0 : _a.metadata;
  });
  onBeforeMount(async () => {
    if (spots.value.length)
      return;
    const { objects = [] } = await (bucket == null ? void 0 : bucket.objects.find({
      type: "spots",
      "metadata.start_date": {
        $lte: today
      },
      "metadata.end_date": {
        $gte: tomorrow
      }
    }).props("metadata,slug").status("published")) || {};
    spots.value = objects;
  });
  return { spot };
});
const _hoisted_1 = { class: "ms-5" };
const _hoisted_2 = ["href", "onClick", "textContent"];
const _hoisted_3 = ["href"];
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "Toc",
  setup(__props) {
    const { toc: tocDrawer, scrolling } = storeToRefs(useAppStore());
    const route = useRoute();
    const router = useRouter();
    const spot = useSpotStore();
    const theme = useTheme();
    const user = F();
    const routeToc = computed(() => route.meta.toc);
    const activeStack = [];
    const activeItem = ref("");
    const observer = new IntersectionObserver((entries) => {
      var _a, _b;
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          activeStack.push(entry.target.id);
        } else if (activeStack.includes(entry.target.id)) {
          activeStack.splice(activeStack.indexOf(entry.target.id), 1);
        }
      });
      activeItem.value = activeStack.at(-1) || activeItem.value || ((_b = (_a = routeToc.value) == null ? void 0 : _a[0]) == null ? void 0 : _b.to.slice(1)) || "";
    }, { rootMargin: "-10% 0px -75%" });
    async function observeToc() {
      var _a;
      scrolling.value = false;
      activeStack.length = 0;
      activeItem.value = "";
      observer.disconnect();
      await nextTick();
      (_a = routeToc.value) == null ? void 0 : _a.forEach((v) => {
        const el = document.querySelector(v.to);
        el && observer.observe(el);
      });
    }
    watch(routeToc, observeToc);
    onMounted(() => {
      observeToc();
    });
    onScopeDispose(() => {
      observer.disconnect();
    });
    let internalScrolling = false;
    let timeout = -1;
    watch(activeItem, async (val) => {
      var _a, _b, _c;
      if (!val || internalScrolling)
        return;
      scrolling.value = true;
      const query = route.query;
      if (val === ((_b = (_a = routeToc.value) == null ? void 0 : _a[0]) == null ? void 0 : _b.to.slice(1)) && route.hash) {
        router.replace({ path: route.path, query });
      } else {
        const toc = (_c = routeToc.value) == null ? void 0 : _c.find((v) => v.to.slice(1) === val);
        if (toc) {
          await router.replace({ path: route.path, hash: toc.to, query });
        }
      }
      clearTimeout(timeout);
      timeout = window.setTimeout(() => {
        scrolling.value = false;
      }, 200);
    });
    async function onClick(hash) {
      if (route.hash === hash)
        return;
      internalScrolling = true;
      await router.replace({ path: route.path, hash });
      setTimeout(() => {
        internalScrolling = false;
      }, 1e3);
    }
    const sponsorStore = useSponsorsStore();
    const sponsors = computed(() => sponsorStore.sponsors.filter((sponsor) => sponsor.metadata.tier <= 1).sort((a, b) => {
      const aTier = a.metadata.tier;
      const bTier = b.metadata.tier;
      return aTier === bTier ? 0 : aTier > bTier ? 1 : -1;
    }));
    const dark = computed(() => theme.current.value.dark);
    return (_ctx, _cache) => {
      var _a;
      const _component_AppHeadline = _sfc_main$c;
      const _component_router_link = resolveComponent("router-link");
      const _component_sponsor_card = _sfc_main$d;
      const _component_v_col = resolveComponent("v-col");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_img = resolveComponent("v-img");
      const _component_v_row = resolveComponent("v-row");
      const _component_v_container = resolveComponent("v-container");
      const _component_v_navigation_drawer = resolveComponent("v-navigation-drawer");
      return !unref(route).meta.fluid ? (openBlock(), createBlock(_component_v_navigation_drawer, {
        key: 0,
        id: "app-toc",
        modelValue: unref(tocDrawer),
        "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(tocDrawer) ? tocDrawer.value = $event : null),
        color: "background",
        location: "right",
        width: "256",
        floating: "",
        sticky: ""
      }, createSlots({
        append: withCtx(() => [
          createVNode(_component_v_container, null, {
            default: withCtx(() => [
              unref(sponsors).length ? (openBlock(), createBlock(_component_AppHeadline, {
                key: 0,
                to: ("rpath" in _ctx ? _ctx.rpath : unref(rpath))("/introduction/sponsors-and-backers/"),
                class: "mb-1 mt-n1 text-high-emphasis text-decoration-none",
                path: "sponsors",
                size: "subtitle-1",
                tag: "router-link"
              }, null, 8, ["to"])) : createCommentVNode("", true),
              createVNode(_component_v_row, { dense: "" }, {
                default: withCtx(() => [
                  unref(sponsors).length ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
                    (openBlock(true), createElementBlock(Fragment, null, renderList(unref(sponsors), (sponsor) => {
                      return openBlock(), createBlock(_component_v_col, {
                        key: sponsor.slug,
                        class: "d-inline-flex"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_sponsor_card, {
                            color: unref(dark) ? void 0 : "grey-lighten-5",
                            "max-height": sponsor.metadata.tier === -1 ? 52 : 40,
                            sponsor
                          }, null, 8, ["color", "max-height", "sponsor"])
                        ]),
                        _: 2
                      }, 1024);
                    }), 128)),
                    createVNode(_component_v_col, { class: "d-inline-flex" }, {
                      default: withCtx(() => [
                        createVNode(_component_v_btn, {
                          to: ("rpath" in _ctx ? _ctx.rpath : unref(rpath))("/introduction/sponsors-and-backers/"),
                          "append-icon": "$vuetify",
                          class: "text-none",
                          color: "primary",
                          size: "large",
                          text: "Support",
                          variant: "tonal",
                          block: ""
                        }, null, 8, ["to"])
                      ]),
                      _: 1
                    })
                  ], 64)) : (openBlock(), createBlock(_component_v_col, {
                    key: 1,
                    cols: "12"
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_v_btn, {
                        class: "text-none border-opacity-50 border-primary",
                        color: "primary",
                        href: "https://github.com/sponsors/johnleider",
                        "prepend-icon": "mdi-github",
                        rel: "noopener noreferrer",
                        size: "large",
                        target: "_blank",
                        text: "Your Logo Here",
                        variant: "tonal",
                        block: "",
                        border: ""
                      })
                    ]),
                    _: 1
                  })),
                  !unref(user).disableAds && unref(spot).spot ? (openBlock(), createBlock(_component_v_col, {
                    key: 2,
                    cols: "12"
                  }, {
                    default: withCtx(() => [
                      createBaseVNode("a", {
                        href: unref(spot).spot.href,
                        rel: "noopener noreferrer sponsored",
                        target: "_blank",
                        onClick: _cache[0] || (_cache[0] = ($event) => ("gtagClick" in _ctx ? _ctx.gtagClick : unref(gtagClick))("toc", "promotion", unref(spot).spot.sponsor))
                      }, [
                        createVNode(_component_v_img, {
                          src: unref(spot).spot.image.url
                        }, null, 8, ["src"])
                      ], 8, _hoisted_3)
                    ]),
                    _: 1
                  })) : createCommentVNode("", true)
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        default: withCtx(() => [
          createBaseVNode("ul", _hoisted_1, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(unref(routeToc), ({ to, level, text }) => {
              return openBlock(), createBlock(_component_router_link, {
                key: text,
                to,
                custom: ""
              }, {
                default: withCtx(({ href }) => [
                  createBaseVNode("li", {
                    class: normalizeClass([
                      "ps-3 text-medium-emphasis text-body-2 py-1 font-weight-regular",
                      {
                        "text-primary router-link-active": unref(activeItem) === to.slice(1),
                        "ps-6": level === 3,
                        "ps-9": level === 4,
                        "ps-12": level === 5
                      }
                    ])
                  }, [
                    createBaseVNode("a", {
                      href,
                      class: "v-toc-link d-block transition-swing text-decoration-none",
                      onClick: withModifiers(($event) => onClick(to), ["prevent", "stop"]),
                      textContent: toDisplayString(text)
                    }, null, 8, _hoisted_2)
                  ], 2)
                ]),
                _: 2
              }, 1032, ["to"]);
            }), 128))
          ])
        ]),
        _: 2
      }, [
        ((_a = unref(routeToc)) == null ? void 0 : _a.length) ? {
          name: "prepend",
          fn: withCtx(() => [
            createVNode(_component_AppHeadline, {
              class: "mt-4 mb-2 ms-4",
              path: "contents"
            })
          ]),
          key: "0"
        } : void 0
      ]), 1032, ["modelValue"])) : createCommentVNode("", true);
    };
  }
});
const __unplugin_components_3 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-bbfe5923"]]);
const _sfc_main = {
  __name: "default",
  setup(__props) {
    const route = useRoute();
    const isApi = computed(() => {
      var _a;
      return ((_a = route.meta) == null ? void 0 : _a.category) === "api";
    });
    const isDashboard = computed(() => {
      var _a;
      return ((_a = route.meta) == null ? void 0 : _a.category) === "user";
    });
    const style = computed(() => ({ maxWidth: isApi.value || isDashboard.value ? "1368px" : "960px" }));
    const hasBackmatter = computed(() => {
      var _a;
      return !isApi.value && ((_a = route.meta) == null ? void 0 : _a.backmatter) !== false;
    });
    return (_ctx, _cache) => {
      const _component_VoNotificationsBanner = resolveComponent("VoNotificationsBanner");
      const _component_AppSettingsDrawer = _sfc_main$e;
      const _component_AppBarBar = _sfc_main$f;
      const _component_AppDrawerDrawer = _sfc_main$g;
      const _component_AppToc = __unplugin_components_3;
      const _component_AppBackToTop = _sfc_main$2;
      const _component_v_fade_transition = resolveComponent("v-fade-transition");
      const _component_router_view = resolveComponent("router-view");
      const _component_Backmatter = __unplugin_components_5;
      const _component_v_container = resolveComponent("v-container");
      const _component_v_main = resolveComponent("v-main");
      const _component_v_app = resolveComponent("v-app");
      return openBlock(), createBlock(_component_v_app, null, {
        default: withCtx(() => [
          createVNode(_component_VoNotificationsBanner, { order: "-1" }),
          createVNode(_component_AppSettingsDrawer),
          createVNode(_component_AppBarBar),
          createVNode(_component_AppDrawerDrawer),
          createVNode(_component_AppToc),
          createVNode(_component_AppBackToTop),
          createVNode(_component_v_main, null, {
            default: withCtx(() => [
              renderSlot(_ctx.$slots, "default", {}, () => [
                createVNode(_component_v_container, {
                  style: normalizeStyle(unref(style)),
                  class: "pa-4 pa-sm-6 pa-md-8",
                  tag: "section",
                  fluid: ""
                }, {
                  default: withCtx(() => [
                    createVNode(_component_router_view, null, {
                      default: withCtx(({ Component }) => [
                        createVNode(_component_v_fade_transition, { "hide-on-leave": "" }, {
                          default: withCtx(() => [
                            (openBlock(), createElementBlock("div", {
                              key: unref(route).name
                            }, [
                              (openBlock(), createBlock(resolveDynamicComponent(Component)))
                            ]))
                          ]),
                          _: 2
                        }, 1024)
                      ]),
                      _: 1
                    }),
                    unref(hasBackmatter) ? (openBlock(), createBlock(_component_Backmatter, {
                      key: unref(route).name
                    })) : createCommentVNode("", true)
                  ]),
                  _: 1
                }, 8, ["style"])
              ])
            ]),
            _: 3
          })
        ]),
        _: 3
      });
    };
  }
};
export {
  _sfc_main as default
};
