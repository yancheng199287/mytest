import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "dialogs" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-dialog"),
  /* @__PURE__ */ createTextVNode(" component inform users about a specific task and may contain critical information, require decisions, or involve multiple tasks. Use dialogs sparingly because they are interruptive.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("In this basic example we use the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "activator"),
  /* @__PURE__ */ createTextVNode(" slot to render a button that is used to open the dialog. When using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "activator"),
  /* @__PURE__ */ createTextVNode(" slot it is important that you bind the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "props"),
  /* @__PURE__ */ createTextVNode(" object from the slot (using "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-bind"),
  /* @__PURE__ */ createTextVNode(") to the element that will activate the dialog. See the examples below for more ways of activating a dialog.")
], -1);
const _hoisted_5 = { id: "api" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "Primary component", -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("td", null, "Extended component", -1);
const _hoisted_9 = { id: "anatomy" };
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The recommended components to use inside of a "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-dialog"),
  /* @__PURE__ */ createTextVNode(" are:")
], -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Element / Area"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("tbody", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "1. Container"),
    /* @__PURE__ */ createBaseVNode("td", null, "The dialog’s content that animates from the activator")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "2. Activator"),
    /* @__PURE__ */ createBaseVNode("td", null, "The element that activates the dialog")
  ])
], -1);
const _hoisted_13 = { id: "guide" };
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-dialog"),
  /* @__PURE__ */ createTextVNode(" component is used to inform users about a specific task and may contain critical information, require decisions, or involve multiple tasks. They are controlled by a "),
  /* @__PURE__ */ createBaseVNode("strong", null, "v-model"),
  /* @__PURE__ */ createTextVNode(" and/or an activator.")
], -1);
const _hoisted_15 = { id: "props" };
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-dialog", -1);
const _hoisted_17 = { id: "v-model" };
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can also trigger a dialog by simply updating the v-model, without using either "),
  /* @__PURE__ */ createBaseVNode("strong", null, "activator"),
  /* @__PURE__ */ createTextVNode(" slot or prop. In this case, the dialog will not appear to be activated by any specific element, and will simply appear in the middle of the screen.")
], -1);
const _hoisted_19 = { id: "persistent" };
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Persistent dialogs are not dismissed when touching outside or pressing the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "esc"),
  /* @__PURE__ */ createTextVNode(" key.")
], -1);
const _hoisted_21 = { id: "transitions" };
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("p", null, "You can make the dialog appear from the top or the bottom.", -1);
const _hoisted_23 = { id: "nesting" };
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("p", null, "Dialogs can be nested: you can open one dialog from another.", -1);
const _hoisted_25 = { id: "overflowed" };
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("p", null, "Modals that do not fit within the available window space will scroll the container.", -1);
const _hoisted_27 = { id: "slots" };
const _hoisted_28 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-dialog"),
  /* @__PURE__ */ createTextVNode(" component has 2 slots, "),
  /* @__PURE__ */ createBaseVNode("strong", null, "activator"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "default"),
  /* @__PURE__ */ createTextVNode(". The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "activator"),
  /* @__PURE__ */ createTextVNode(" slot is used to designate an element that will activate the dialog. The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "default"),
  /* @__PURE__ */ createTextVNode(" slot provides an "),
  /* @__PURE__ */ createBaseVNode("strong", null, "isActive"),
  /* @__PURE__ */ createTextVNode(" ref which is tied to the current state of the dialog.")
], -1);
const _hoisted_29 = { id: "activator" };
const _hoisted_30 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("In addition using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "activator"),
  /* @__PURE__ */ createTextVNode(" slot, we can instead use the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "activator"),
  /* @__PURE__ */ createTextVNode(" prop to activate a dialog. By placing the dialog component inside the button, and setting the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "activator"),
  /* @__PURE__ */ createTextVNode(" prop value to "),
  /* @__PURE__ */ createBaseVNode("strong", null, "“parent”"),
  /* @__PURE__ */ createTextVNode(" we can designate the parent (button) as the activator.")
], -1);
const _hoisted_31 = { id: "default" };
const _hoisted_32 = { id: "examples" };
const _hoisted_33 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The following are a collection of examples that demonstrate more advanced and real world use of the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-dialog"),
  /* @__PURE__ */ createTextVNode(" component.")
], -1);
const _hoisted_34 = { id: "scrollable" };
const _hoisted_35 = /* @__PURE__ */ createBaseVNode("p", null, "Example of a dialog with scrollable content.", -1);
const _hoisted_36 = { id: "form" };
const _hoisted_37 = /* @__PURE__ */ createBaseVNode("p", null, "A simple example of a form in a dialog.", -1);
const _hoisted_38 = { id: "loader" };
const _hoisted_39 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-dialog"),
  /* @__PURE__ */ createTextVNode(" component makes it easy to create a customized loading experience for your application.")
], -1);
const _hoisted_40 = { id: "fullscreen" };
const _hoisted_41 = /* @__PURE__ */ createBaseVNode("p", null, "Due to limited space, full-screen dialogs may be more appropriate for mobile devices than dialogs used on devices with larger screens.", -1);
const _hoisted_42 = { id: "invite-dialog" };
const _hoisted_43 = /* @__PURE__ */ createBaseVNode("p", null, "This example demonstrates a dialog that is used to invite users to a group.", -1);
const frontmatter = { "meta": { "nav": "Dialogs", "title": "Dialog component", "description": "The dialog component informs a user about a specific task and may contain critical information or require the user to take a specific action.", "keywords": "dialogs, vuetify dialog component, vue dialog component" }, "related": ["/components/buttons", "/components/cards", "/components/menus"], "features": { "github": "/components/VDialog/", "label": "C: VDialog", "report": true, "spec": "https://m2.material.io/components/dialogs" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "dialogs",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Dialogs", "title": "Dialog component", "description": "The dialog component informs a user about a specific task and may contain critical information or require the user to take a specific action.", "keywords": "dialogs, vuetify dialog component, vue dialog component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Dialogs", "title": "Dialog component", "description": "The dialog component informs a user about a specific task and may contain critical information or require the user to take a specific action.", "keywords": "dialogs, vuetify dialog component, vue dialog component" }, "related": ["/components/buttons", "/components/cards", "/components/menus"], "features": { "github": "/components/VDialog/", "label": "C: VDialog", "report": true, "spec": "https://m2.material.io/components/dialogs" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_app_figure = resolveComponent("app-figure");
      const _component_page_features = resolveComponent("page-features");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#dialogs",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Dialogs")
                ]),
                _: 1
              }),
              _hoisted_2,
              createBaseVNode("p", null, [
                createBaseVNode("div", null, [
                  createVNode(_component_app_figure, {
                    alt: "Dialog Entry",
                    src: "https://cdn.vuetifyjs.com/docs/images/components/v-dialog/v-dialog-entry.png"
                  })
                ])
              ]),
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_usage, { name: "v-dialog" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_6,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-dialog/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-dialog")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-overlay/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-overlay")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_8
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_9, [
                createVNode(_component_app_heading, {
                  href: "#anatomy",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Anatomy")
                  ]),
                  _: 1
                }),
                _hoisted_10,
                createBaseVNode("ul", null, [
                  createBaseVNode("li", null, [
                    createVNode(_component_app_link, { href: "/components/cards/" }, {
                      default: withCtx(() => [
                        createTextVNode("v-card")
                      ]),
                      _: 1
                    })
                  ]),
                  createBaseVNode("li", null, [
                    createVNode(_component_app_link, { href: "/components/lists/" }, {
                      default: withCtx(() => [
                        createTextVNode("v-list")
                      ]),
                      _: 1
                    })
                  ]),
                  createBaseVNode("li", null, [
                    createVNode(_component_app_link, { href: "/components/sheets/" }, {
                      default: withCtx(() => [
                        createTextVNode("v-sheet")
                      ]),
                      _: 1
                    })
                  ])
                ]),
                createBaseVNode("p", null, [
                  createBaseVNode("div", null, [
                    createVNode(_component_app_figure, {
                      alt: "Dialog Anatomy",
                      src: "https://cdn.vuetifyjs.com/docs/images/components/v-dialog/v-dialog-anatomy.png"
                    })
                  ])
                ]),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_11,
                    _hoisted_12
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_13, [
                createVNode(_component_app_heading, {
                  href: "#guide",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Guide")
                  ]),
                  _: 1
                }),
                _hoisted_14,
                createBaseVNode("section", _hoisted_15, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("p", null, [
                    createTextVNode("The "),
                    _hoisted_16,
                    createTextVNode(" component extends "),
                    createVNode(_component_app_link, { href: "/components/overlays/" }, {
                      default: withCtx(() => [
                        createTextVNode("v-overlay")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" and has access to all of its props.")
                  ]),
                  createBaseVNode("section", _hoisted_17, [
                    createVNode(_component_app_heading, {
                      href: "#v-model",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("v-model")
                      ]),
                      _: 1
                    }),
                    _hoisted_18,
                    createVNode(_component_examples_example, { file: "v-dialog/prop-model" })
                  ]),
                  createBaseVNode("section", _hoisted_19, [
                    createVNode(_component_app_heading, {
                      href: "#persistent",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Persistent")
                      ]),
                      _: 1
                    }),
                    _hoisted_20,
                    createVNode(_component_examples_example, { file: "v-dialog/prop-persistent" })
                  ]),
                  createBaseVNode("section", _hoisted_21, [
                    createVNode(_component_app_heading, {
                      href: "#transitions",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Transitions")
                      ]),
                      _: 1
                    }),
                    _hoisted_22,
                    createVNode(_component_examples_example, { file: "v-dialog/prop-transitions" })
                  ]),
                  createBaseVNode("section", _hoisted_23, [
                    createVNode(_component_app_heading, {
                      href: "#nesting",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Nesting")
                      ]),
                      _: 1
                    }),
                    _hoisted_24,
                    createVNode(_component_examples_example, { file: "v-dialog/misc-nesting" })
                  ]),
                  createBaseVNode("section", _hoisted_25, [
                    createVNode(_component_app_heading, {
                      href: "#overflowed",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Overflowed")
                      ]),
                      _: 1
                    }),
                    _hoisted_26,
                    createVNode(_component_examples_example, { file: "v-dialog/misc-overflowed" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_27, [
                  createVNode(_component_app_heading, {
                    href: "#slots",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Slots")
                    ]),
                    _: 1
                  }),
                  _hoisted_28,
                  createBaseVNode("section", _hoisted_29, [
                    createVNode(_component_app_heading, {
                      href: "#activator",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Activator")
                      ]),
                      _: 1
                    }),
                    _hoisted_30,
                    createVNode(_component_examples_example, { file: "v-dialog/prop-activator" })
                  ]),
                  createBaseVNode("section", _hoisted_31, [
                    createVNode(_component_app_heading, {
                      href: "#default",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Default")
                      ]),
                      _: 1
                    }),
                    createVNode(_component_examples_example, { file: "v-dialog/slot-default" })
                  ])
                ])
              ]),
              createBaseVNode("section", _hoisted_32, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                _hoisted_33,
                createBaseVNode("section", _hoisted_34, [
                  createVNode(_component_app_heading, {
                    href: "#scrollable",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Scrollable")
                    ]),
                    _: 1
                  }),
                  _hoisted_35,
                  createVNode(_component_examples_example, { file: "v-dialog/prop-scrollable" })
                ]),
                createBaseVNode("section", _hoisted_36, [
                  createVNode(_component_app_heading, {
                    href: "#form",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Form")
                    ]),
                    _: 1
                  }),
                  _hoisted_37,
                  createVNode(_component_examples_example, { file: "v-dialog/misc-form" })
                ]),
                createBaseVNode("section", _hoisted_38, [
                  createVNode(_component_app_heading, {
                    href: "#loader",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Loader")
                    ]),
                    _: 1
                  }),
                  _hoisted_39,
                  createVNode(_component_examples_example, { file: "v-dialog/misc-loader" })
                ]),
                createBaseVNode("section", _hoisted_40, [
                  createVNode(_component_app_heading, {
                    href: "#fullscreen",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Fullscreen")
                    ]),
                    _: 1
                  }),
                  _hoisted_41,
                  createVNode(_component_examples_example, { file: "v-dialog/prop-fullscreen" })
                ]),
                createBaseVNode("section", _hoisted_42, [
                  createVNode(_component_app_heading, {
                    href: "#invite-dialog",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Invite dialog")
                    ]),
                    _: 1
                  }),
                  _hoisted_43,
                  createVNode(_component_examples_example, { file: "v-dialog/misc-invite-dialog" })
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
