import { y as _export_sfc, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, b as createVNode, h as createTextVNode, l as createElementBlock, v as renderList, F as Fragment } from "./index-DGybHjCP.js";
const _sfc_main = {};
function _sfc_render(_ctx, _cache) {
  const _component_v_spacer = resolveComponent("v-spacer");
  const _component_v_icon = resolveComponent("v-icon");
  const _component_v_system_bar = resolveComponent("v-system-bar");
  const _component_v_avatar = resolveComponent("v-avatar");
  const _component_v_divider = resolveComponent("v-divider");
  const _component_v_navigation_drawer = resolveComponent("v-navigation-drawer");
  const _component_v_sheet = resolveComponent("v-sheet");
  const _component_v_list_item = resolveComponent("v-list-item");
  const _component_v_list = resolveComponent("v-list");
  const _component_v_text_field = resolveComponent("v-text-field");
  const _component_v_responsive = resolveComponent("v-responsive");
  const _component_v_app_bar = resolveComponent("v-app-bar");
  const _component_v_main = resolveComponent("v-main");
  const _component_v_footer = resolveComponent("v-footer");
  const _component_v_app = resolveComponent("v-app");
  return openBlock(), createBlock(_component_v_app, { id: "inspire" }, {
    default: withCtx(() => [
      createVNode(_component_v_system_bar, null, {
        default: withCtx(() => [
          createVNode(_component_v_spacer),
          createVNode(_component_v_icon, null, {
            default: withCtx(() => [
              createTextVNode("mdi-square")
            ]),
            _: 1
          }),
          createVNode(_component_v_icon, null, {
            default: withCtx(() => [
              createTextVNode("mdi-circle")
            ]),
            _: 1
          }),
          createVNode(_component_v_icon, null, {
            default: withCtx(() => [
              createTextVNode("mdi-triangle")
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_navigation_drawer, {
        color: "grey-lighten-3",
        rail: ""
      }, {
        default: withCtx(() => [
          createVNode(_component_v_avatar, {
            class: "d-block text-center mx-auto mt-4",
            color: "grey-darken-1",
            size: "36"
          }),
          createVNode(_component_v_divider, { class: "mx-3 my-5" }),
          (openBlock(), createElementBlock(Fragment, null, renderList(6, (n) => {
            return createVNode(_component_v_avatar, {
              key: n,
              class: "d-block text-center mx-auto mb-9",
              color: "grey-lighten-1",
              size: "28"
            });
          }), 64))
        ]),
        _: 1
      }),
      createVNode(_component_v_navigation_drawer, { width: "244" }, {
        default: withCtx(() => [
          createVNode(_component_v_sheet, {
            color: "grey-lighten-5",
            height: "128",
            width: "100%"
          }),
          createVNode(_component_v_list, null, {
            default: withCtx(() => [
              (openBlock(), createElementBlock(Fragment, null, renderList(5, (n) => {
                return createVNode(_component_v_list_item, {
                  key: n,
                  title: `Item ${n}`,
                  link: ""
                }, null, 8, ["title"]);
              }), 64))
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_app_bar, {
        class: "px-3",
        color: "grey-lighten-4",
        height: "72",
        flat: ""
      }, {
        default: withCtx(() => [
          createVNode(_component_v_spacer),
          createVNode(_component_v_responsive, { "max-width": "156" }, {
            default: withCtx(() => [
              createVNode(_component_v_text_field, {
                "bg-color": "grey-lighten-1",
                density: "compact",
                rounded: "pill",
                variant: "solo-filled",
                flat: "",
                "hide-details": ""
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_main),
      createVNode(_component_v_navigation_drawer, { location: "right" }, {
        default: withCtx(() => [
          createVNode(_component_v_list, null, {
            default: withCtx(() => [
              (openBlock(), createElementBlock(Fragment, null, renderList(5, (n) => {
                return createVNode(_component_v_list_item, {
                  key: n,
                  title: `Item ${n}`,
                  link: ""
                }, null, 8, ["title"]);
              }), 64))
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_footer, {
        height: "72",
        app: ""
      }, {
        default: withCtx(() => [
          createVNode(_component_v_text_field, {
            "bg-color": "grey-lighten-1",
            class: "overflow-hidden",
            density: "compact",
            rounded: "pill",
            variant: "solo-filled",
            flat: "",
            "hide-details": ""
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __2 = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __2 as _
};
