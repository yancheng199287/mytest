import { y as _export_sfc, o as openBlock, l as createElementBlock, e as createBaseVNode, r as resolveComponent, c as createBlock, w as withCtx, b as createVNode, h as createTextVNode, F as Fragment, v as renderList, t as toDisplayString } from "./index-DGybHjCP.js";
const _sfc_main$4 = {};
const _hoisted_1$3 = /* @__PURE__ */ createBaseVNode("div", { class: "d-block pa-2 bg-deep-purple" }, " d-block ", -1);
const _hoisted_2$3 = /* @__PURE__ */ createBaseVNode("div", { class: "d-block pa-2 bg-black" }, " d-block ", -1);
const _hoisted_3$3 = [
  _hoisted_1$3,
  _hoisted_2$3
];
function _sfc_render$3(_ctx, _cache) {
  return openBlock(), createElementBlock("div", null, _hoisted_3$3);
}
const __0 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["render", _sfc_render$3]]);
const __0_raw = '<template>\n  <div>\n    <div class="d-block pa-2 bg-deep-purple">\n      d-block\n    </div>\n    <div class="d-block pa-2 bg-black">\n      d-block\n    </div>\n  </div>\n</template>\n';
const _sfc_main$3 = {};
const _hoisted_1$2 = /* @__PURE__ */ createBaseVNode("div", { class: "d-inline pa-2 bg-deep-purple" }, " d-inline ", -1);
const _hoisted_2$2 = /* @__PURE__ */ createBaseVNode("div", { class: "d-inline pa-2 bg-black" }, " d-inline ", -1);
const _hoisted_3$2 = [
  _hoisted_1$2,
  _hoisted_2$2
];
function _sfc_render$2(_ctx, _cache) {
  return openBlock(), createElementBlock("div", null, _hoisted_3$2);
}
const __1 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["render", _sfc_render$2]]);
const __1_raw = '<template>\n  <div>\n    <div class="d-inline pa-2 bg-deep-purple">\n      d-inline\n    </div>\n    <div class="d-inline pa-2 bg-black">\n      d-inline\n    </div>\n  </div>\n</template>\n';
const _sfc_main$2 = {
  __name: "hidden-elements",
  setup(__props) {
    const items = [
      {
        text: "Link One"
      },
      {
        text: "Link Two"
      },
      {
        text: "Link Three"
      }
    ];
    return (_ctx, _cache) => {
      const _component_v_toolbar_title = resolveComponent("v-toolbar-title");
      const _component_v_spacer = resolveComponent("v-spacer");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_toolbar_items = resolveComponent("v-toolbar-items");
      const _component_v_toolbar = resolveComponent("v-toolbar");
      return openBlock(), createBlock(_component_v_toolbar, { light: "" }, {
        default: withCtx(() => [
          createVNode(_component_v_toolbar_title, null, {
            default: withCtx(() => [
              createTextVNode("Title")
            ]),
            _: 1
          }),
          createVNode(_component_v_spacer),
          (openBlock(), createElementBlock(Fragment, null, renderList(items, (item) => {
            return createVNode(_component_v_toolbar_items, {
              key: item.text,
              class: "hidden-sm-and-down"
            }, {
              default: withCtx(() => [
                createVNode(_component_v_btn, { variant: "text" }, {
                  default: withCtx(() => [
                    createTextVNode(toDisplayString(item.text), 1)
                  ]),
                  _: 2
                }, 1024)
              ]),
              _: 2
            }, 1024);
          }), 64))
        ]),
        _: 1
      });
    };
  }
};
const __2 = _sfc_main$2;
const __2_raw = `<template>
  <v-toolbar light>
    <v-toolbar-title>Title</v-toolbar-title>
    <v-spacer></v-spacer>
    <v-toolbar-items
      v-for="item in items"
      :key="item.text"
      class="hidden-sm-and-down"
    >
      <v-btn variant="text">
        {{ item.text }}
      </v-btn>
    </v-toolbar-items>
  </v-toolbar>
</template>

<script setup>
  const items = [
    {
      text: 'Link One',
    },
    {
      text: 'Link Two',
    },
    {
      text: 'Link Three',
    },
  ]
<\/script>

<script>
  export default {
    data () {
      return {
        items: [
          {
            text: 'Link One',
          },
          {
            text: 'Link Two',
          },
          {
            text: 'Link Three',
          },
        ],
      }
    },
  }
<\/script>
`;
const _sfc_main$1 = {};
const _hoisted_1$1 = /* @__PURE__ */ createBaseVNode("div", { class: "d-print-none" }, " Screen Only (Hide on print only) ", -1);
const _hoisted_2$1 = /* @__PURE__ */ createBaseVNode("div", { class: "d-none d-print-block" }, " Print Only (Hide on screen only) ", -1);
const _hoisted_3$1 = /* @__PURE__ */ createBaseVNode("div", { class: "d-none d-lg-block d-print-block" }, " Hide up to large on screen, but always show on print ", -1);
const _hoisted_4 = [
  _hoisted_1$1,
  _hoisted_2$1,
  _hoisted_3$1
];
function _sfc_render$1(_ctx, _cache) {
  return openBlock(), createElementBlock("div", null, _hoisted_4);
}
const __3 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["render", _sfc_render$1]]);
const __3_raw = '<template>\n  <div>\n    <div class="d-print-none">\n      Screen Only (Hide on print only)\n    </div>\n    <div class="d-none d-print-block">\n      Print Only (Hide on screen only)\n    </div>\n    <div class="d-none d-lg-block d-print-block">\n      Hide up to large on screen, but always show on print\n    </div>\n  </div>\n</template>\n';
const _sfc_main = {};
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("div", { class: "d-lg-none" }, " hide on screens wider than lg ", -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("div", { class: "d-none d-lg-block" }, " hide on screens smaller than lg ", -1);
const _hoisted_3 = [
  _hoisted_1,
  _hoisted_2
];
function _sfc_render(_ctx, _cache) {
  return openBlock(), createElementBlock("div", null, _hoisted_3);
}
const __4 = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
const __4_raw = '<template>\n  <div>\n    <div class="d-lg-none">\n      hide on screens wider than lg\n    </div>\n    <div class="d-none d-lg-block">\n      hide on screens smaller than lg\n    </div>\n  </div>\n</template>\n';
const display = {
  "display-block": {
    component: __0,
    source: __0_raw
  },
  "display-inline": {
    component: __1,
    source: __1_raw
  },
  "hidden-elements": {
    component: __2,
    source: __2_raw
  },
  "print": {
    component: __3,
    source: __3_raw
  },
  "visibility": {
    component: __4,
    source: __4_raw
  }
};
export {
  display as default
};
