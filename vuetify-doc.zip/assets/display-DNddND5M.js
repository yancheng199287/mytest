import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "display-helpers" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "The display helpers allow you to control the display of content. This includes being conditionally visible based upon the current viewport, or the actual element display type.", -1);
const _hoisted_3 = { id: "display" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Specify the element’s "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "display"),
  /* @__PURE__ */ createTextVNode(" property. These classes can be applied to all breakpoints from "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "xs"),
  /* @__PURE__ */ createTextVNode(" to "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "xxl"),
  /* @__PURE__ */ createTextVNode(". When using a base class,"),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".d-{value}"),
  /* @__PURE__ */ createTextVNode(", it is inferred to be "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".d-xs-{value}"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".d-{value}"),
    /* @__PURE__ */ createTextVNode(" for "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "xs")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".d-{breakpoint}-{value}"),
    /* @__PURE__ */ createTextVNode(" for "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "sm"),
    /* @__PURE__ */ createTextVNode(", "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "md"),
    /* @__PURE__ */ createTextVNode(", "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "lg"),
    /* @__PURE__ */ createTextVNode(", "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "xl"),
    /* @__PURE__ */ createTextVNode(", and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "xxl")
  ])
], -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "value"),
  /* @__PURE__ */ createTextVNode(" property is one of:")
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "none")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "inline")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "inline-block")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "block")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "table")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "table-cell")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "table-row")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "flex")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "inline-flex")
  ])
], -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("When setting a specific breakpoint for a display helper class, it will apply to all screen widths from the designation and up. For example, "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "d-lg-flex"),
  /* @__PURE__ */ createTextVNode(" will apply to "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "lg"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "xl"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "xxl"),
  /* @__PURE__ */ createTextVNode(" size screens.")
], -1);
const _hoisted_9 = { id: "visibility" };
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Conditionally display an element based upon the current "),
  /* @__PURE__ */ createBaseVNode("strong", null, "viewport"),
  /* @__PURE__ */ createTextVNode(". Breakpoint utility classes always apply from the bottom up. That means if you have "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".d-none"),
  /* @__PURE__ */ createTextVNode(", it will apply to all breakpoints. However, "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".d-md-none"),
  /* @__PURE__ */ createTextVNode(" will apply to only "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "md"),
  /* @__PURE__ */ createTextVNode(" and up.")
], -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Screen size"),
    /* @__PURE__ */ createBaseVNode("th", null, "Class")
  ])
], -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("tbody", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "Hidden on all"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".d-none")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "Hidden only on xs"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".d-none .d-sm-flex")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "Hidden only on sm"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".d-sm-none .d-md-flex")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "Hidden only on md"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".d-md-none .d-lg-flex")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "Hidden only on lg"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".d-lg-none .d-xl-flex")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "Hidden only on xl"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".d-xl-none .d-xxl-flex")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "Hidden only on xxl"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".d-xxl-none")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "Visible on all"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".d-flex")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "Visible only on xs"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".d-flex .d-sm-none")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "Visible only on sm"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".d-none .d-sm-flex .d-md-none")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "Visible only on md"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".d-none .d-md-flex .d-lg-none")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "Visible only on lg"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".d-none .d-lg-flex .d-xl-none")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "Visible only on xl"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".d-none .d-xl-flex .d-xxl-none")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "Visible only on xxl"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".d-none .d-xxl-flex")
    ])
  ])
], -1);
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Alternatively you can hide an element based upon the current "),
  /* @__PURE__ */ createBaseVNode("strong", null, "viewport"),
  /* @__PURE__ */ createTextVNode(" using lateral display helper classes. These classes can be applied using the following format "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "hidden-{breakpoint}-{condition?}")
], -1);
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "condition"),
  /* @__PURE__ */ createTextVNode(" applies the class base on:")
], -1);
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, "nothing - hide the element only on the specified breakpoint"),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "and-down"),
    /* @__PURE__ */ createTextVNode(" - hide the element on the specified breakpoint and down - "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "sm"),
    /* @__PURE__ */ createTextVNode(" through "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "xl"),
    /* @__PURE__ */ createTextVNode(" only")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "and-up"),
    /* @__PURE__ */ createTextVNode(" - hide the element on the specified breakpoint and up - "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "sm"),
    /* @__PURE__ */ createTextVNode(" through "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "xl"),
    /* @__PURE__ */ createTextVNode(" only")
  ])
], -1);
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "hidden-{breakpoint}-and-up"),
  /* @__PURE__ */ createTextVNode(" is equivalent to "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "d-{breakpoint}-none"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Media types"),
  /* @__PURE__ */ createTextVNode(" can also be targeted using the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "only"),
  /* @__PURE__ */ createTextVNode(" condition. Both "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "hidden-screen-only"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "hidden-print-only"),
  /* @__PURE__ */ createTextVNode(" are currently supported.")
], -1);
const _hoisted_18 = { id: "caveats" };
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("It is important to note that using any of the display classes above will result in any display style previously added being overwritten. This is because of the classes using "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "!important"),
  /* @__PURE__ */ createTextVNode(" in their display styling.")
], -1);
const _hoisted_20 = { id: "display-in-print" };
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("p", null, "You can also change the display property when printing.", -1);
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".d-print-none")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".d-print-inline")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".d-print-inline-block")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".d-print-block")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".d-print-table")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".d-print-table-row")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".d-print-table-cell")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".d-print-flex")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".d-print-inline-flex")
  ])
], -1);
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("p", null, "Print utility classes can also be combined with none print display utilities.", -1);
const _hoisted_24 = { id: "accessibility" };
const _hoisted_25 = { id: "screen-readers" };
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Use the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "d-sr"),
  /* @__PURE__ */ createTextVNode(" utility classes to conditionally hide content on all devices "),
  /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "except"),
  /* @__PURE__ */ createTextVNode(" screen readers.")
], -1);
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "d-sr-only"),
    /* @__PURE__ */ createTextVNode(" visually hides elements but will still announce to "),
    /* @__PURE__ */ createBaseVNode("strong", null, "screen readers"),
    /* @__PURE__ */ createTextVNode(".")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "d-sr-only-focusable"),
    /* @__PURE__ */ createTextVNode(" visually hides an element until it is focused. This is useful when implementing "),
    /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "skip links"),
    /* @__PURE__ */ createTextVNode(".")
  ])
], -1);
const frontmatter = { "meta": { "title": "Display", "description": "Display helper classes allow you to control when elements should display based upon viewport.", "keywords": "display helper classes, display classes, vuetify display" }, "related": ["/styles/text-and-typography/", "/directives/resize/", "/features/display-and-platform/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "display",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "Display", "description": "Display helper classes allow you to control when elements should display based upon viewport.", "keywords": "display helper classes, display classes, vuetify display" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "title": "Display", "description": "Display helper classes allow you to control when elements should display based upon viewport.", "keywords": "display helper classes, display classes, vuetify display" }, "related": ["/styles/text-and-typography/", "/directives/resize/", "/features/display-and-platform/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_features_breakpoints_table = resolveComponent("features-breakpoints-table");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_app_table = resolveComponent("app-table");
      const _component_alert = resolveComponent("alert");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#display-helpers",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Display helpers")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_promoted_entry),
              createVNode(_component_features_breakpoints_table),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#display",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Display")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                _hoisted_5,
                _hoisted_6,
                _hoisted_7,
                _hoisted_8,
                createVNode(_component_examples_example, { file: "display/display-inline" }),
                createVNode(_component_examples_example, { file: "display/display-block" })
              ]),
              createBaseVNode("section", _hoisted_9, [
                createVNode(_component_app_heading, {
                  href: "#visibility",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Visibility")
                  ]),
                  _: 1
                }),
                _hoisted_10,
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_11,
                    _hoisted_12
                  ]),
                  _: 1
                }),
                createVNode(_component_examples_example, { file: "display/visibility" }),
                _hoisted_13,
                _hoisted_14,
                _hoisted_15,
                _hoisted_16,
                _hoisted_17,
                createBaseVNode("section", _hoisted_18, [
                  createVNode(_component_app_heading, {
                    href: "#caveats",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Caveats")
                    ]),
                    _: 1
                  }),
                  createVNode(_component_alert, { type: "info" }, {
                    default: withCtx(() => [
                      _hoisted_19
                    ]),
                    _: 1
                  })
                ])
              ]),
              createBaseVNode("section", _hoisted_20, [
                createVNode(_component_app_heading, {
                  href: "#display-in-print",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Display in print")
                  ]),
                  _: 1
                }),
                _hoisted_21,
                _hoisted_22,
                _hoisted_23,
                createVNode(_component_examples_example, { file: "display/print" })
              ]),
              createBaseVNode("section", _hoisted_24, [
                createVNode(_component_app_heading, {
                  href: "#accessibility",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Accessibility")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_25, [
                  createVNode(_component_app_heading, {
                    href: "#screen-readers",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Screen readers")
                    ]),
                    _: 1
                  }),
                  _hoisted_26,
                  _hoisted_27
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
