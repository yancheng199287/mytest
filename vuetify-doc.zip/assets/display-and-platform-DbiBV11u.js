import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "display-26-platform" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "The display composable provides a multitude of information about the current device", -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "useDisplay"),
  /* @__PURE__ */ createTextVNode(" composable provides information on multiple aspects of the current device.")
], -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("p", null, "The following shows how to access the application’s display information:", -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "Composition.vue",
    class: "language-html"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("script")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "setup"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token script" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token language-javascript" }, [
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode(" onMounted "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vue'"),
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode(" useDisplay "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify'"),
        /* @__PURE__ */ createTextVNode("\n\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "const"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode(" mobile "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "="),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "useDisplay"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
        /* @__PURE__ */ createTextVNode("\n\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "onMounted"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "=>"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode("\n    console"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "."),
        /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "log"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
        /* @__PURE__ */ createTextVNode("mobile"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "."),
        /* @__PURE__ */ createTextVNode("value"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// false"),
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
        /* @__PURE__ */ createTextVNode("\n")
      ])
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("script")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("If you are still using the Options API, you can access the display information on the global "),
  /* @__PURE__ */ createBaseVNode("strong", null, "$vuetify"),
  /* @__PURE__ */ createTextVNode(" variable. Note that refs are unwrapped here, so you don’t need "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".value"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "Options.vue",
    class: "language-html"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("script")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token script" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token language-javascript" }, [
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "export"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "default"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode("\n    "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "mounted"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode("\n      console"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "."),
        /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "log"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "this"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "."),
        /* @__PURE__ */ createTextVNode("$vuetify"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "."),
        /* @__PURE__ */ createTextVNode("display"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "."),
        /* @__PURE__ */ createTextVNode("mobile"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
        /* @__PURE__ */ createTextVNode("\n    "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createTextVNode("\n")
      ])
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("script")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_9 = { id: "api" };
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("td", null, "Composable", -1);
const _hoisted_12 = { id: "breakpoints-and-thresholds" };
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Threshold values generate the ranges used for various breakpoints seen throughout vuetify and the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "useDisplay"),
  /* @__PURE__ */ createTextVNode(" composable. The system uses an “and up” mentality starting from "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "xs"),
  /* @__PURE__ */ createTextVNode(" at 0px. The default threshold values are displayed below.")
], -1);
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("These ranges power the various additional "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "AndUp"),
  /* @__PURE__ */ createTextVNode(" / "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "AndDown"),
  /* @__PURE__ */ createTextVNode(" properties accessible in "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "useDisplay")
], -1);
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-ts" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-ts" }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n  smAndDown"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "boolean"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// < 960px"),
    /* @__PURE__ */ createTextVNode("\n  smAndUp"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "boolean"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// > 600px"),
    /* @__PURE__ */ createTextVNode("\n  mdAndDown"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "boolean"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// < 1280px"),
    /* @__PURE__ */ createTextVNode("\n  mdAndUp"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "boolean"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// > 960px"),
    /* @__PURE__ */ createTextVNode("\n  lgAndDown"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "boolean"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// < 1919px"),
    /* @__PURE__ */ createTextVNode("\n  lgAndUp"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "boolean"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// > 1280px"),
    /* @__PURE__ */ createTextVNode("\n  xlAndDown"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "boolean"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// < 2559px"),
    /* @__PURE__ */ createTextVNode("\n  xlAndUp"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "boolean"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// > 1920px"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_16 = { id: "options" };
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "useDisplay"),
  /* @__PURE__ */ createTextVNode(" composable has several configuration options, such as the ability to define custom values for breakpoints.")
], -1);
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("For example, the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "thresholds"),
  /* @__PURE__ */ createTextVNode(" option modifies the values used for viewport calculations. The following snippet overrides "),
  /* @__PURE__ */ createBaseVNode("strong", null, "thresholds"),
  /* @__PURE__ */ createTextVNode(" values "),
  /* @__PURE__ */ createBaseVNode("em", null, "xs"),
  /* @__PURE__ */ createTextVNode(" through "),
  /* @__PURE__ */ createBaseVNode("em", null, "lg"),
  /* @__PURE__ */ createTextVNode(" and sets "),
  /* @__PURE__ */ createBaseVNode("strong", null, "mobileBreakpoint"),
  /* @__PURE__ */ createTextVNode(" to "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "sm"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-js" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/plugins/vuetify.js",
    class: "language-js"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" createVuetify"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify'"),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "export"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "default"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "createVuetify"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "display"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "mobileBreakpoint"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'sm'"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "thresholds"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "xs"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token number" }, "0"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "sm"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token number" }, "340"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "md"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token number" }, "540"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "lg"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token number" }, "800"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "xl"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token number" }, "1280"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "mobileBreakpoint"),
  /* @__PURE__ */ createTextVNode(" option accepts numbers and breakpoint keys.")
], -1);
const _hoisted_21 = { id: "examples" };
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("strong", null, "height", -1);
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "Component.vue",
    class: "language-html"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-card")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, ":height"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("height"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n    ...\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("v-card")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("script")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "setup"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token script" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token language-javascript" }, [
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode(" computed "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vue'"),
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode(" useDisplay "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify'"),
        /* @__PURE__ */ createTextVNode("\n\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "const"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode(" name "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "="),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "useDisplay"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
        /* @__PURE__ */ createTextVNode("\n\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "const"),
        /* @__PURE__ */ createTextVNode(" height "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "="),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "computed"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "=>"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode("\n    "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// name is reactive and"),
        /* @__PURE__ */ createTextVNode("\n    "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// must use .value"),
        /* @__PURE__ */ createTextVNode("\n    "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "switch"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
        /* @__PURE__ */ createTextVNode("name"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "."),
        /* @__PURE__ */ createTextVNode("value"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode("\n      "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "case"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'xs'"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "return"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token number" }, "220"),
        /* @__PURE__ */ createTextVNode("\n      "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "case"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'sm'"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "return"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token number" }, "400"),
        /* @__PURE__ */ createTextVNode("\n      "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "case"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'md'"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "return"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token number" }, "500"),
        /* @__PURE__ */ createTextVNode("\n      "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "case"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'lg'"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "return"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token number" }, "600"),
        /* @__PURE__ */ createTextVNode("\n      "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "case"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'xl'"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "return"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token number" }, "800"),
        /* @__PURE__ */ createTextVNode("\n      "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "case"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'xxl'"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "return"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token number" }, "1200"),
        /* @__PURE__ */ createTextVNode("\n    "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createTextVNode("\n\n    "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "return"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "undefined"),
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
        /* @__PURE__ */ createTextVNode("\n")
      ])
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("script")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_24 = { id: "interface" };
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-ts" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-ts" }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// Breakpoints"),
    /* @__PURE__ */ createTextVNode("\n  xs"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "boolean"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// 0 - 595"),
    /* @__PURE__ */ createTextVNode("\n  sm"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "boolean"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// 600 - 959"),
    /* @__PURE__ */ createTextVNode("\n  md"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "boolean"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// 960 - 1279"),
    /* @__PURE__ */ createTextVNode("\n  lg"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "boolean"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// 1280 - 1919"),
    /* @__PURE__ */ createTextVNode("\n  xl"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "boolean"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// > 1920"),
    /* @__PURE__ */ createTextVNode("\n  xxl"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "boolean"),
    /* @__PURE__ */ createTextVNode("\n  smAndDown"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "boolean"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// < 960"),
    /* @__PURE__ */ createTextVNode("\n  smAndUp"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "boolean"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// > 600"),
    /* @__PURE__ */ createTextVNode("\n  mdAndDown"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "boolean"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// < 1280"),
    /* @__PURE__ */ createTextVNode("\n  mdAndUp"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "boolean"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// > 960"),
    /* @__PURE__ */ createTextVNode("\n  lgAndDown"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "boolean"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// < 1919"),
    /* @__PURE__ */ createTextVNode("\n  lgAndUp"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "boolean"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// > 1280"),
    /* @__PURE__ */ createTextVNode("\n  xlAndDown"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "boolean"),
    /* @__PURE__ */ createTextVNode("\n  xlAndUp"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "boolean"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// < 1920"),
    /* @__PURE__ */ createTextVNode("\n\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// true if screen width < mobileBreakpoint"),
    /* @__PURE__ */ createTextVNode("\n  mobile"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "boolean"),
    /* @__PURE__ */ createTextVNode("\n  mobileBreakpoint"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "number"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "|"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'xs'"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "|"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'sm'"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "|"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'md'"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "|"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'lg'"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "|"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'xl'"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "|"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'xxl'"),
    /* @__PURE__ */ createTextVNode("\n\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// Current breakpoint name (e.g. 'xs' | 'sm' | 'md' | 'lg' | 'xl' | 'xxl')"),
    /* @__PURE__ */ createTextVNode("\n  name"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "string"),
    /* @__PURE__ */ createTextVNode("\n\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// The current value of window.innerHeight and window.innerWidth"),
    /* @__PURE__ */ createTextVNode("\n  height"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "number"),
    /* @__PURE__ */ createTextVNode("\n  width"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "number"),
    /* @__PURE__ */ createTextVNode("\n\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// Device userAgent information"),
    /* @__PURE__ */ createTextVNode("\n  platform"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n    android"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "boolean"),
    /* @__PURE__ */ createTextVNode("\n    ios"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "boolean"),
    /* @__PURE__ */ createTextVNode("\n    cordova"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "boolean"),
    /* @__PURE__ */ createTextVNode("\n    electron"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "boolean"),
    /* @__PURE__ */ createTextVNode("\n    chrome"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "boolean"),
    /* @__PURE__ */ createTextVNode("\n    edge"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "boolean"),
    /* @__PURE__ */ createTextVNode("\n    firefox"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "boolean"),
    /* @__PURE__ */ createTextVNode("\n    opera"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "boolean"),
    /* @__PURE__ */ createTextVNode("\n    win"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "boolean"),
    /* @__PURE__ */ createTextVNode("\n    mac"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "boolean"),
    /* @__PURE__ */ createTextVNode("\n    linux"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "boolean"),
    /* @__PURE__ */ createTextVNode("\n    touch"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "boolean"),
    /* @__PURE__ */ createTextVNode("\n    ssr"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "boolean"),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode("\n\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// The values used to make Breakpoint calculations"),
    /* @__PURE__ */ createTextVNode("\n  thresholds"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n    xs"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "number"),
    /* @__PURE__ */ createTextVNode("\n    sm"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "number"),
    /* @__PURE__ */ createTextVNode("\n    md"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "number"),
    /* @__PURE__ */ createTextVNode("\n    lg"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "number"),
    /* @__PURE__ */ createTextVNode("\n    xl"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "number"),
    /* @__PURE__ */ createTextVNode("\n    xxl"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token builtin" }, "number"),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_26 = { id: "using-setup" };
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("strong", null, "useDisplay", -1);
const _hoisted_28 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "setup", -1);
const _hoisted_29 = /* @__PURE__ */ createBaseVNode("strong", null, "fullscreen", -1);
const _hoisted_30 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-dialog", -1);
const _hoisted_31 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "Component.vue",
    class: "language-html"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-dialog")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, ":fullscreen"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("mobile"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n    ...\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("v-dialog")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("script")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "setup"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token script" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token language-javascript" }, [
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode(" useDisplay "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify'"),
        /* @__PURE__ */ createTextVNode("\n\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "const"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode(" mobile "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "="),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "useDisplay"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
        /* @__PURE__ */ createTextVNode("\n")
      ])
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("script")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_32 = { id: "breakpoint-conditionals" };
const _hoisted_33 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "boolean", -1);
const _hoisted_34 = /* @__PURE__ */ createBaseVNode("strong", null, "breakpoint", -1);
const _hoisted_35 = /* @__PURE__ */ createBaseVNode("strong", null, "xlOnly", -1);
const _hoisted_36 = /* @__PURE__ */ createBaseVNode("strong", null, "xsOnly", -1);
const _hoisted_37 = /* @__PURE__ */ createBaseVNode("strong", null, "mdAndDown", -1);
const _hoisted_38 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "setup", -1);
const _hoisted_39 = /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "xs", -1);
const _hoisted_40 = /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "mdAndUp", -1);
const _hoisted_41 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "Component.vue",
    class: "language-html"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-sheet")
      ]),
      /* @__PURE__ */ createTextVNode("\n    "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, ":min-height"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("mdAndUp ? 300 : '20vh'"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createTextVNode("\n    "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, ":rounded"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("xs"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createTextVNode("\n  "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n    ...\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("v-sheet")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("script")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "setup"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token script" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token language-javascript" }, [
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode(" useDisplay "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify'"),
        /* @__PURE__ */ createTextVNode("\n\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// Destructure only the keys you want to use"),
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "const"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode(" xs"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
        /* @__PURE__ */ createTextVNode(" mdAndUp "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "="),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "useDisplay"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
        /* @__PURE__ */ createTextVNode("\n")
      ])
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("script")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_42 = /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "dynamic", -1);
const _hoisted_43 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "300", -1);
const _hoisted_44 = /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "medium", -1);
const _hoisted_45 = /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "extra small", -1);
const _hoisted_46 = { id: "component-mobile-breakpoints" };
const _hoisted_47 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Some components within Vuetify have a "),
  /* @__PURE__ */ createBaseVNode("strong", null, "mobile-breakpoint"),
  /* @__PURE__ */ createTextVNode(" property which allows you to override the default value. These components reference the global mobileBreakpoint value that is generated at runtime using the provided options in the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "vuetify.js"),
  /* @__PURE__ */ createTextVNode(" file.")
], -1);
const _hoisted_48 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The following components have built in support for the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "mobile-breakpoint"),
  /* @__PURE__ */ createTextVNode(" property:")
], -1);
const _hoisted_49 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component")
  ])
], -1);
const _hoisted_50 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("By default, "),
  /* @__PURE__ */ createBaseVNode("strong", null, "mobileBreakpoint"),
  /* @__PURE__ */ createTextVNode(" is set to "),
  /* @__PURE__ */ createBaseVNode("strong", null, "lg"),
  /* @__PURE__ */ createTextVNode(", which means that if the window is less than "),
  /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "1280"),
  /* @__PURE__ */ createTextVNode(" pixels in width (which is the default value for the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "lg"),
  /* @__PURE__ */ createTextVNode(" threshold), then the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "useDisplay"),
  /* @__PURE__ */ createTextVNode(" composable will update its "),
  /* @__PURE__ */ createBaseVNode("strong", null, "mobile"),
  /* @__PURE__ */ createTextVNode(" value to "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "true"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_51 = /* @__PURE__ */ createBaseVNode("strong", null, "mobile-breakpoint", -1);
const _hoisted_52 = /* @__PURE__ */ createBaseVNode("strong", null, "lg", -1);
const _hoisted_53 = /* @__PURE__ */ createBaseVNode("strong", null, "580", -1);
const _hoisted_54 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "Component.vue",
    class: "language-html"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("div")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-banner")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n      ...\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("v-banner")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-banner")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "mobile-breakpoint"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("580"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n      ...\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("v-banner")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("div")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("script")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "setup"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token script" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token language-javascript" }, [
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode(" onMounted "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vue'"),
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode(" useDisplay "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify'"),
        /* @__PURE__ */ createTextVNode("\n\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "const"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode(" width"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
        /* @__PURE__ */ createTextVNode(" mobile "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "="),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "useDisplay"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
        /* @__PURE__ */ createTextVNode("\n\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "onMounted"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "=>"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode("\n    console"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "."),
        /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "log"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
        /* @__PURE__ */ createTextVNode("width"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "."),
        /* @__PURE__ */ createTextVNode("value"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// 960"),
        /* @__PURE__ */ createTextVNode("\n    console"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "."),
        /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "log"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
        /* @__PURE__ */ createTextVNode("mobile"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "."),
        /* @__PURE__ */ createTextVNode("value"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// true"),
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
        /* @__PURE__ */ createTextVNode("\n")
      ])
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("script")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_55 = /* @__PURE__ */ createBaseVNode("p", null, "If the screen width is 1024 pixels, the second banner would not convert into its mobile state.", -1);
const _hoisted_56 = { id: "usedisplay-overrides" };
const _hoisted_57 = /* @__PURE__ */ createBaseVNode("strong", null, "mobileBreakpoint", -1);
const _hoisted_58 = /* @__PURE__ */ createBaseVNode("strong", null, "580", -1);
const _hoisted_59 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "Component.vue",
    class: "language-html"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("script")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "setup"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token script" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token language-javascript" }, [
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode(" onMounted "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vue'"),
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode(" useDisplay "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify'"),
        /* @__PURE__ */ createTextVNode("\n\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "const"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode(" mobile "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "="),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "useDisplay"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode(" mobileBreakpoint "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
        /* @__PURE__ */ createTextVNode("\n\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// Given a viewport width of 960px"),
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "onMounted"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "=>"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode("\n    console"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "."),
        /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "log"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
        /* @__PURE__ */ createTextVNode("mobile"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "."),
        /* @__PURE__ */ createTextVNode("value"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// false"),
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
        /* @__PURE__ */ createTextVNode("\n")
      ])
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("script")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_60 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("If you supply a value for the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "name"),
  /* @__PURE__ */ createTextVNode(" argument, utilize the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "displayClasses"),
  /* @__PURE__ */ createTextVNode(" property to apply the appropriate classes to your component. In the next example, the following classes would be applied to the root element of the component:")
], -1);
const _hoisted_61 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "Component.vue",
    class: "language-html"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("div")
      ]),
      /* @__PURE__ */ createTextVNode("\n    "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, ":class"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("[\n      'v-component',\n      displayClasses,\n    ]"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createTextVNode("\n  "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "<!-- v-component--mobile -->"),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("div")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("script")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "setup"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token script" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token language-javascript" }, [
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode(" defineName "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vue'"),
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode(" useDisplay "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify'"),
        /* @__PURE__ */ createTextVNode("\n\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "const"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode(" displayClasses "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "="),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "useDisplay"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode(" mobileBreakpoint "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'v-component'"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
        /* @__PURE__ */ createTextVNode("\n")
      ])
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("script")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_62 = /* @__PURE__ */ createBaseVNode("p", null, "If you leave out the name argument, displayClasses will use the default name set by Vue. The following example uses the default name of the local component:", -1);
const _hoisted_63 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "AppDrawer.vue",
    class: "language-html"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-navigation-drawer")
      ]),
      /* @__PURE__ */ createTextVNode("\n    "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, ":class"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("[\n      displayClasses, // 'app-drawer--mobile'\n    ]"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createTextVNode("\n  "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n    ...\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("v-navigation-drawer")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("script")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "setup"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token script" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token language-javascript" }, [
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode(" useDisplay "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify'"),
        /* @__PURE__ */ createTextVNode("\n\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "const"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode(" displayClasses "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "="),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "useDisplay"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode(" mobileBreakpoint "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
        /* @__PURE__ */ createTextVNode("\n")
      ])
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("script")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const frontmatter = { "meta": { "title": "Display & Platform", "description": "Access display viewport information using the Vuetify Breakpoint composable.", "keywords": "breakpoints, grid breakpoints, platform details, screen size, display size" }, "related": ["/directives/resize/", "/styles/display/", "/styles/text-and-typography/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "display-and-platform",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "Display & Platform", "description": "Access display viewport information using the Vuetify Breakpoint composable.", "keywords": "breakpoints, grid breakpoints, platform details, screen size, display size" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "title": "Display & Platform", "description": "Access display viewport information using the Vuetify Breakpoint composable.", "keywords": "breakpoints, grid breakpoints, platform details, screen size, display size" }, "related": ["/directives/resize/", "/styles/display/", "/styles/text-and-typography/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_markup = resolveComponent("app-markup");
      const _component_app_table = resolveComponent("app-table");
      const _component_features_breakpoints_table = resolveComponent("features-breakpoints-table");
      const _component_alert = resolveComponent("alert");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#display-26-platform",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Display & Platform")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_promoted_entry),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createBaseVNode("p", null, [
                  createTextVNode("This enables you to control various aspects of your application based upon the window size, device type, and SSR state. This composable works in conjunction with "),
                  createVNode(_component_app_link, { href: "/components/grids/" }, {
                    default: withCtx(() => [
                      createTextVNode("grids")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" and other responsive utility classes (e.g. "),
                  createVNode(_component_app_link, { href: "/styles/display/" }, {
                    default: withCtx(() => [
                      createTextVNode("display")
                    ]),
                    _: 1
                  }),
                  createTextVNode(").")
                ]),
                _hoisted_5,
                createVNode(_component_app_markup, {
                  resource: "Composition.vue",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_6
                  ]),
                  _: 1
                }),
                _hoisted_7,
                createVNode(_component_app_markup, {
                  resource: "Options.vue",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_8
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_9, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_10,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/use-display/" }, {
                            default: withCtx(() => [
                              createTextVNode("useDisplay")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_11
                      ])
                    ])
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_12, [
                createVNode(_component_app_heading, {
                  href: "#breakpoints-and-thresholds",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Breakpoints and Thresholds")
                  ]),
                  _: 1
                }),
                _hoisted_13,
                createVNode(_component_features_breakpoints_table),
                _hoisted_14,
                createVNode(_component_app_markup, {
                  resource: "",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_15
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_16, [
                createVNode(_component_app_heading, {
                  href: "#options",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Options")
                  ]),
                  _: 1
                }),
                _hoisted_17,
                _hoisted_18,
                createVNode(_component_app_markup, {
                  resource: "src/plugins/vuetify.js",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_19
                  ]),
                  _: 1
                }),
                createVNode(_component_alert, { type: "info" }, {
                  default: withCtx(() => [
                    _hoisted_20
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_21, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("In the following example, we use a switch statement and the current breakpoint name to modify the "),
                  _hoisted_22,
                  createTextVNode(" property of the "),
                  createVNode(_component_app_link, { href: "/components/cards/" }, {
                    default: withCtx(() => [
                      createTextVNode("v-card")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" component:")
                ]),
                createVNode(_component_app_markup, {
                  resource: "Component.vue",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_23
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_24, [
                  createVNode(_component_app_heading, {
                    href: "#interface",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Interface")
                    ]),
                    _: 1
                  }),
                  createVNode(_component_app_markup, {
                    resource: "",
                    class: "mb-4"
                  }, {
                    default: withCtx(() => [
                      _hoisted_25
                    ]),
                    _: 1
                  })
                ])
              ]),
              createBaseVNode("section", _hoisted_26, [
                createVNode(_component_app_heading, {
                  href: "#using-setup",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Using Setup")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("Use the "),
                  _hoisted_27,
                  createTextVNode(" composable alongside Vue 3’s "),
                  _hoisted_28,
                  createTextVNode(" function to harness the power of the "),
                  createVNode(_component_app_link, { href: "https://v3.vuejs.org/guide/composition-api-setup.html" }, {
                    default: withCtx(() => [
                      createTextVNode("Composition API")
                    ]),
                    _: 1
                  }),
                  createTextVNode(". In this example we show how to toggle the "),
                  _hoisted_29,
                  createTextVNode(" property of "),
                  _hoisted_30,
                  createTextVNode(" when the mobile breakpoint is active.")
                ]),
                createVNode(_component_app_markup, {
                  resource: "Component.vue",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_31
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_32, [
                  createVNode(_component_app_heading, {
                    href: "#breakpoint-conditionals",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Breakpoint conditionals")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("p", null, [
                    createTextVNode("Breakpoint and conditional values return a "),
                    _hoisted_33,
                    createTextVNode(" that is derived from the current viewport size. Additionally, the "),
                    _hoisted_34,
                    createTextVNode(" composable follows the "),
                    createVNode(_component_app_link, { href: "/components/grids" }, {
                      default: withCtx(() => [
                        createTextVNode("Vuetify Grid")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" naming conventions and has access to properties such as "),
                    _hoisted_35,
                    createTextVNode(", "),
                    _hoisted_36,
                    createTextVNode(", "),
                    _hoisted_37,
                    createTextVNode(", and many others. In the following example we use the "),
                    _hoisted_38,
                    createTextVNode(" function to pass the "),
                    _hoisted_39,
                    createTextVNode(" and "),
                    _hoisted_40,
                    createTextVNode(" values to our template:")
                  ]),
                  createVNode(_component_app_markup, {
                    resource: "Component.vue",
                    class: "mb-4"
                  }, {
                    default: withCtx(() => [
                      _hoisted_41
                    ]),
                    _: 1
                  }),
                  createBaseVNode("p", null, [
                    createTextVNode("Using the "),
                    _hoisted_42,
                    createTextVNode(" display values, we are able to adjust the minimum height of "),
                    createVNode(_component_app_link, { href: "/components/sheets/" }, {
                      default: withCtx(() => [
                        createTextVNode("v-sheet")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" to "),
                    _hoisted_43,
                    createTextVNode(" when on the "),
                    _hoisted_44,
                    createTextVNode(" breakpoint or greater and only show rounded corners on "),
                    _hoisted_45,
                    createTextVNode(" screens:")
                  ])
                ])
              ]),
              createBaseVNode("section", _hoisted_46, [
                createVNode(_component_app_heading, {
                  href: "#component-mobile-breakpoints",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Component Mobile Breakpoints")
                  ]),
                  _: 1
                }),
                createVNode(_component_alert, { type: "success" }, {
                  default: withCtx(() => [
                    createBaseVNode("p", null, [
                      createTextVNode("This feature was introduced in "),
                      createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v3.4.0" }, {
                        default: withCtx(() => [
                          createTextVNode("v3.4.0 (Blackguard)")
                        ]),
                        _: 1
                      })
                    ])
                  ]),
                  _: 1
                }),
                _hoisted_47,
                _hoisted_48,
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_49,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/components/banners/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-banner")
                            ]),
                            _: 1
                          })
                        ])
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/components/navigation-drawers/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-navigation-drawer")
                            ]),
                            _: 1
                          })
                        ])
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/components/slide-groups/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-slide-group")
                            ]),
                            _: 1
                          })
                        ])
                      ])
                    ])
                  ]),
                  _: 1
                }),
                _hoisted_50,
                createBaseVNode("p", null, [
                  createTextVNode("For example, the "),
                  createVNode(_component_app_link, { href: "/components/banners/" }, {
                    default: withCtx(() => [
                      createTextVNode("v-banner")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" component implements different styling when its mobile versus desktop. In the following example, The first banner uses the global "),
                  _hoisted_51,
                  createTextVNode(" value of "),
                  _hoisted_52,
                  createTextVNode(" while the second overrides this default with "),
                  _hoisted_53,
                  createTextVNode(":")
                ]),
                createVNode(_component_app_markup, {
                  resource: "Component.vue",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_54
                  ]),
                  _: 1
                }),
                _hoisted_55,
                createBaseVNode("section", _hoisted_56, [
                  createVNode(_component_app_heading, {
                    href: "#usedisplay-overrides",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("useDisplay overrides")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("p", null, [
                    createTextVNode("Specify a custom "),
                    _hoisted_57,
                    createTextVNode(" value directly to the "),
                    createVNode(_component_app_link, { href: "/api/use-display/" }, {
                      default: withCtx(() => [
                        createTextVNode("useDisplay")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" composable and override the global value. In the following example we use a custom mobileBreakpoint value of "),
                    _hoisted_58,
                    createTextVNode(":")
                  ]),
                  createVNode(_component_app_markup, {
                    resource: "Component.vue",
                    class: "mb-4"
                  }, {
                    default: withCtx(() => [
                      _hoisted_59
                    ]),
                    _: 1
                  }),
                  _hoisted_60,
                  createVNode(_component_app_markup, {
                    resource: "Component.vue",
                    class: "mb-4"
                  }, {
                    default: withCtx(() => [
                      _hoisted_61
                    ]),
                    _: 1
                  }),
                  _hoisted_62,
                  createVNode(_component_app_markup, {
                    resource: "AppDrawer.vue",
                    class: "mb-4"
                  }, {
                    default: withCtx(() => [
                      _hoisted_63
                    ]),
                    _: 1
                  })
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
