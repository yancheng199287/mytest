import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "dividers" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-divider"),
  /* @__PURE__ */ createTextVNode(" component is used to separate sections of lists or layouts.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, "Dividers in their simplest form display a horizontal line.", -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("strong", null, "border-opacity", -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("strong", null, "$utilities", -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("strong", null, "false", -1);
const _hoisted_8 = { id: "api" };
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("td", null, "The divider component.", -1);
const _hoisted_11 = { id: "examples" };
const _hoisted_12 = { id: "props" };
const _hoisted_13 = { id: "inset" };
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("p", null, "Inset dividers are moved 72px to the right. This will cause them to line up with list items.", -1);
const _hoisted_15 = { id: "vertical" };
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("p", null, "Vertical dividers give you more tools for unique layouts.", -1);
const _hoisted_17 = { id: "thickness" };
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("By using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "thickness"),
  /* @__PURE__ */ createTextVNode(" prop, the thickness of the divider can be adjusted to the desired value.")
], -1);
const _hoisted_19 = { id: "misc" };
const _hoisted_20 = { id: "portrait-view" };
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("p", null, "Create custom cards to fit any use-case.", -1);
const _hoisted_22 = { id: "subheaders" };
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Dividers and subheaders can help break up content and can optionally line up with one another by using the same "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "inset"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_24 = { id: "accessibility" };
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-divider", -1);
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("strong", null, "separator", -1);
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("strong", null, "presentation", -1);
const _hoisted_28 = /* @__PURE__ */ createBaseVNode("strong", null, "separator", -1);
const _hoisted_29 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-divider", -1);
const _hoisted_30 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, 'role="presentation"', -1);
const _hoisted_31 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-divider", -1);
const _hoisted_32 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, 'aria-orientation="horizontal"', -1);
const _hoisted_33 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, 'vertical="true"', -1);
const _hoisted_34 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, 'aria-orientation="vertical"', -1);
const _hoisted_35 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, 'role="presentation"', -1);
const _hoisted_36 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, 'aria-orientation="undefined"', -1);
const frontmatter = { "meta": { "nav": "Dividers", "title": "Divider component", "description": "The divider component is a thin line commonly used to separate groups of content in lists or layouts.", "keywords": "dividers, vuetify divider component, vue divider component" }, "related": ["/components/lists", "/components/navigation-drawers", "/components/toolbars"], "features": { "github": "/components/VDivider/", "label": "C: VDivider", "report": true, "spec": "https://m2.material.io/components/dividers" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "dividers",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Dividers", "title": "Divider component", "description": "The divider component is a thin line commonly used to separate groups of content in lists or layouts.", "keywords": "dividers, vuetify divider component, vue divider component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Dividers", "title": "Divider component", "description": "The divider component is a thin line commonly used to separate groups of content in lists or layouts.", "keywords": "dividers, vuetify divider component, vue divider component" }, "related": ["/components/lists", "/components/navigation-drawers", "/components/toolbars"], "features": { "github": "/components/VDivider/", "label": "C: VDivider", "report": true, "spec": "https://m2.material.io/components/dividers" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_app_link = resolveComponent("app-link");
      const _component_alert = resolveComponent("alert");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#dividers",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Dividers")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_usage, { name: "v-divider" }),
                createVNode(_component_alert, { type: "info" }, {
                  default: withCtx(() => [
                    createBaseVNode("p", null, [
                      createTextVNode("This example uses the "),
                      _hoisted_5,
                      createTextVNode(" utility class and is not available when "),
                      _hoisted_6,
                      createTextVNode(" is set to "),
                      _hoisted_7,
                      createTextVNode(". More information regarding utility classes is located on the "),
                      createVNode(_component_app_link, { href: "features/sass-variables/#basic-usage" }, {
                        default: withCtx(() => [
                          createTextVNode("SASS variables page")
                        ]),
                        _: 1
                      }),
                      createTextVNode(".")
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_8, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_9,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-divider/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-divider")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_10
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_11, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_12, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_13, [
                    createVNode(_component_app_heading, {
                      href: "#inset",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Inset")
                      ]),
                      _: 1
                    }),
                    _hoisted_14,
                    createVNode(_component_examples_example, { file: "v-divider/prop-inset" })
                  ]),
                  createBaseVNode("section", _hoisted_15, [
                    createVNode(_component_app_heading, {
                      href: "#vertical",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Vertical")
                      ]),
                      _: 1
                    }),
                    _hoisted_16,
                    createVNode(_component_examples_example, { file: "v-divider/prop-vertical" })
                  ]),
                  createBaseVNode("section", _hoisted_17, [
                    createVNode(_component_app_heading, {
                      href: "#thickness",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Thickness")
                      ]),
                      _: 1
                    }),
                    _hoisted_18
                  ])
                ]),
                createBaseVNode("section", _hoisted_19, [
                  createVNode(_component_app_heading, {
                    href: "#misc",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Misc")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_20, [
                    createVNode(_component_app_heading, {
                      href: "#portrait-view",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Portrait View")
                      ]),
                      _: 1
                    }),
                    _hoisted_21,
                    createVNode(_component_examples_example, { file: "v-divider/misc-portrait-view" })
                  ]),
                  createBaseVNode("section", _hoisted_22, [
                    createVNode(_component_app_heading, {
                      href: "#subheaders",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Subheaders")
                      ]),
                      _: 1
                    }),
                    _hoisted_23,
                    createVNode(_component_examples_example, { file: "v-divider/misc-subheaders" })
                  ])
                ])
              ]),
              createBaseVNode("section", _hoisted_24, [
                createVNode(_component_app_heading, {
                  href: "#accessibility",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Accessibility")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("By default, "),
                  _hoisted_25,
                  createTextVNode(" components are assigned the "),
                  createVNode(_component_app_link, { href: "https://www.w3.org/WAI/standards-guidelines/aria/" }, {
                    default: withCtx(() => [
                      createTextVNode("WAI-ARIA")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" role of "),
                  createVNode(_component_app_link, { href: "https://www.w3.org/TR/wai-aria/#separator" }, {
                    default: withCtx(() => [
                      _hoisted_26
                    ]),
                    _: 1
                  }),
                  createTextVNode(" which denotes that the divider “separates and distinguishes sections of content or groups of menu items.” However, sometimes a divider is just a way to make an interface look nice. In those cases, the role of "),
                  createVNode(_component_app_link, { href: "https://www.w3.org/TR/wai-aria/#presentation" }, {
                    default: withCtx(() => [
                      _hoisted_27
                    ]),
                    _: 1
                  }),
                  createTextVNode(" should be used which denotes “an element whose implicit native role semantics will not be mapped to the accessibility API.” To override the default "),
                  _hoisted_28,
                  createTextVNode(" role in a "),
                  _hoisted_29,
                  createTextVNode(", simply add a "),
                  _hoisted_30,
                  createTextVNode(" prop to your component. In addition, "),
                  _hoisted_31,
                  createTextVNode(" components have an "),
                  _hoisted_32,
                  createTextVNode(". If "),
                  _hoisted_33,
                  createTextVNode(", then "),
                  _hoisted_34,
                  createTextVNode(" will be set automatically as well. If "),
                  _hoisted_35,
                  createTextVNode(", "),
                  _hoisted_36,
                  createTextVNode(", its default value.")
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
