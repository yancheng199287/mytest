import { y as _export_sfc, r as resolveComponent, o as openBlock, l as createElementBlock, b as createVNode, w as withCtx, a9 as mergeProps, h as createTextVNode, e as createBaseVNode, c as createBlock, F as Fragment, v as renderList, U as normalizeClass, t as toDisplayString } from "./index-DGybHjCP.js";
const _sfc_main$1 = {};
const _hoisted_1 = { class: "text--primary" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("div", { class: "my-6" }, null, -1);
function _sfc_render$1(_ctx, _cache) {
  const _component_v_card = resolveComponent("v-card");
  const _component_v_hover = resolveComponent("v-hover");
  return openBlock(), createElementBlock("div", _hoisted_1, [
    createVNode(_component_v_hover, null, {
      default: withCtx(({ isHovering, props }) => [
        createVNode(_component_v_card, mergeProps(props, {
          elevation: isHovering ? 24 : 6,
          class: "mx-auto pa-6"
        }), {
          default: withCtx(() => [
            createTextVNode(" Prop based elevation ")
          ]),
          _: 2
        }, 1040, ["elevation"])
      ]),
      _: 1
    }),
    _hoisted_2,
    createVNode(_component_v_hover, null, {
      default: withCtx(({ isHovering, props }) => [
        createBaseVNode("div", mergeProps(props, {
          class: [`elevation-${isHovering ? 24 : 6}`, "mx-auto pa-6 transition-swing"]
        }), " Class based elevation ", 16)
      ]),
      _: 1
    })
  ]);
}
const __0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["render", _sfc_render$1]]);
const __0_raw = '<template>\n  <div class="text--primary">\n    <!-- Using the elevation prop -->\n    <v-hover v-slot="{ isHovering, props }">\n      <v-card\n        v-bind="props"\n        :elevation="isHovering ? 24 : 6"\n        class="mx-auto pa-6"\n      >\n        Prop based elevation\n      </v-card>\n    </v-hover>\n\n    <div class="my-6"></div>\n\n    <!-- Using a dynamic class -->\n    <v-hover v-slot="{ isHovering, props }">\n      <div\n        v-bind="props"\n        :class="`elevation-${isHovering ? 24 : 6}`"\n        class="mx-auto pa-6 transition-swing"\n      >\n        Class based elevation\n      </div>\n    </v-hover>\n  </div>\n</template>\n';
const _sfc_main = {};
function _sfc_render(_ctx, _cache) {
  const _component_v_card = resolveComponent("v-card");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, null, {
    default: withCtx(() => [
      createVNode(_component_v_row, { justify: "center" }, {
        default: withCtx(() => [
          (openBlock(), createElementBlock(Fragment, null, renderList(25, (_, n) => {
            return createVNode(_component_v_col, {
              key: n,
              cols: "auto"
            }, {
              default: withCtx(() => [
                createVNode(_component_v_card, {
                  class: normalizeClass(["d-flex justify-center align-center bg-secondary", `elevation-${n}`]),
                  height: "100",
                  width: "100"
                }, {
                  default: withCtx(() => [
                    createBaseVNode("div", null, toDisplayString(n), 1)
                  ]),
                  _: 2
                }, 1032, ["class"])
              ]),
              _: 2
            }, 1024);
          }), 64))
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __1 = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
const __1_raw = '<template>\n  <v-container>\n    <v-row justify="center">\n      <v-col\n        v-for="(_, n) in 25"\n        :key="n"\n        cols="auto"\n      >\n        <v-card\n          :class="[\'d-flex justify-center align-center bg-secondary\', `elevation-${n}`]"\n          height="100"\n          width="100"\n        >\n          <div>{{ n }}</div>\n        </v-card>\n      </v-col>\n    </v-row>\n  </v-container>\n</template>\n';
const elevation = {
  "prop-dynamic": {
    component: __0,
    source: __0_raw
  },
  "usage": {
    component: __1,
    source: __1_raw
  }
};
export {
  elevation as default
};
