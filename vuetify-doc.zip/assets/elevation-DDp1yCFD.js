import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "elevation" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The elevation helpers allow you to control relative depth, or distance, between two surfaces along the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "z-axis"),
  /* @__PURE__ */ createTextVNode(". There is a total of 25 elevation levels. You can set an element’s elevation by using the class "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "elevation-{n}"),
  /* @__PURE__ */ createTextVNode(", where "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "n"),
  /* @__PURE__ */ createTextVNode(" is a integer between 0-24 corresponding to the desired elevation.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "elevation"),
  /* @__PURE__ */ createTextVNode(" helper classes allow you to assign a custom "),
  /* @__PURE__ */ createBaseVNode("strong", null, "z-depth"),
  /* @__PURE__ */ createTextVNode(" to any element.")
], -1);
const _hoisted_5 = { id: "examples" };
const _hoisted_6 = { id: "props" };
const _hoisted_7 = { id: "dynamic-elevation" };
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Numerous components utilize the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "elevatable"),
  /* @__PURE__ */ createTextVNode(" mixin and are given an "),
  /* @__PURE__ */ createBaseVNode("strong", null, "elevation"),
  /* @__PURE__ */ createTextVNode(" prop. For components that are not supported, you can dynamically change the class")
], -1);
const frontmatter = { "meta": { "title": "Elevation", "description": "Elevation helper classes allow you to control relative depth, or distance, between two surfaces along the z-axis.", "keywords": "elevation helper classes, elevation classes, vuetify elevation" }, "related": ["/components/cards/", "/components/sheets/", "/components/bottom-navigation/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "elevation",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "Elevation", "description": "Elevation helper classes allow you to control relative depth, or distance, between two surfaces along the z-axis.", "keywords": "elevation helper classes, elevation classes, vuetify elevation" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "title": "Elevation", "description": "Elevation helper classes allow you to control relative depth, or distance, between two surfaces along the z-axis.", "keywords": "elevation helper classes, elevation classes, vuetify elevation" }, "related": ["/components/cards/", "/components/sheets/", "/components/bottom-navigation/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#elevation",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Elevation")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_promoted_entry),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_example, { file: "elevation/usage" })
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_6, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_7, [
                    createVNode(_component_app_heading, {
                      href: "#dynamic-elevation",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Dynamic elevation")
                      ]),
                      _: 1
                    }),
                    _hoisted_8,
                    createVNode(_component_examples_example, { file: "elevation/prop-dynamic" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
