import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "empty-states" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-empty-state"),
  /* @__PURE__ */ createTextVNode(" component is used to indicate that a list is empty or that no search results were found.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, "A basic empty state is composed of a title and a description. It can also include an icon and a button.", -1);
const _hoisted_5 = { id: "api" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_8 = { id: "guide" };
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-empty-state"),
  /* @__PURE__ */ createTextVNode(" component is used to indicate that a page or list is empty or that no search results were found. It can be used in a variety of contexts, such as a list of items, a search results page, or a page with no content.")
], -1);
const _hoisted_10 = { id: "props" };
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-empty-state"),
  /* @__PURE__ */ createTextVNode(" component has a multitude of props that allow you to customize its appearance and behavior.")
], -1);
const _hoisted_12 = { id: "content" };
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("There are three main properties for configuring text content, "),
  /* @__PURE__ */ createBaseVNode("strong", null, "title"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "subtitle"),
  /* @__PURE__ */ createTextVNode(", and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "text"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_14 = { id: "media" };
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("p", null, "Add an icon or image to the empty state to help convey its purpose.", -1);
const _hoisted_16 = { id: "actions" };
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("p", null, "Add a button to the empty state to help users take action.", -1);
const _hoisted_18 = { id: "slots" };
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-empty-state"),
  /* @__PURE__ */ createTextVNode(" component has numerous slots that make it easy to customize the default behavior.")
], -1);
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Slot"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("tbody", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "1. Default"),
    /* @__PURE__ */ createBaseVNode("td", null, "The default slot")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "2. Media"),
    /* @__PURE__ */ createBaseVNode("td", null, "The media slot is for images or icons")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "3. Title"),
    /* @__PURE__ */ createBaseVNode("td", null, "The main title slot")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "4. Subtitle"),
    /* @__PURE__ */ createBaseVNode("td", null, "The subtitle slot")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "5. Text"),
    /* @__PURE__ */ createBaseVNode("td", null, "The text slot")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "6. Actions"),
    /* @__PURE__ */ createBaseVNode("td", null, "The actions slot")
  ])
], -1);
const _hoisted_22 = { id: "default" };
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The default slot is positioned between "),
  /* @__PURE__ */ createBaseVNode("strong", null, "text"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "actions"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_24 = { id: "title" };
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("p", null, "It’s simple to customize the font-sizing of the title using utility classes.", -1);
const _hoisted_26 = { id: "custom-actions" };
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("By default, only 1 action is displayed through configuration. To add more options, utilize the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "actions"),
  /* @__PURE__ */ createTextVNode(" slot.")
], -1);
const _hoisted_28 = { id: "examples" };
const _hoisted_29 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The following are a collection of examples that demonstrate more advanced and real world use of the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-empty-state"),
  /* @__PURE__ */ createTextVNode(" component.")
], -1);
const _hoisted_30 = { id: "astro-dog" };
const _hoisted_31 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("This example demonstrates how to use the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-empty-state"),
  /* @__PURE__ */ createTextVNode(" component to create a fun and engaging empty state.")
], -1);
const _hoisted_32 = { id: "astro-cat" };
const frontmatter = { "emphasized": true, "meta": { "title": "Empty states", "description": "The empty state component is used to indicate that a list is empty or that no search results were found.", "keywords": "empty state, no results, no data, no items, no content, no records, no information, no search results" }, "related": ["/components/buttons/", "/components/icons/", "/components/avatars/"], "features": { "report": true, "spec": "https://m2.material.io/design/communication/empty-states.html", "label": "C: VEmptyState", "github": "/components/VEmptyState/" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "empty-states",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "Empty states", "description": "The empty state component is used to indicate that a list is empty or that no search results were found.", "keywords": "empty state, no results, no data, no items, no content, no records, no information, no search results" } };
    useHead(head);
    __expose({ frontmatter: { "emphasized": true, "meta": { "title": "Empty states", "description": "The empty state component is used to indicate that a list is empty or that no search results were found.", "keywords": "empty state, no results, no data, no items, no content, no records, no information, no search results" }, "related": ["/components/buttons/", "/components/icons/", "/components/avatars/"], "features": { "report": true, "spec": "https://m2.material.io/design/communication/empty-states.html", "label": "C: VEmptyState", "github": "/components/VEmptyState/" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_app_link = resolveComponent("app-link");
      const _component_alert = resolveComponent("alert");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#empty-states",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Empty states")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_alert, { type: "success" }, {
                default: withCtx(() => [
                  createBaseVNode("p", null, [
                    createTextVNode("This feature was introduced in "),
                    createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v3.6.0" }, {
                      default: withCtx(() => [
                        createTextVNode("v3.6.0")
                      ]),
                      _: 1
                    })
                  ])
                ]),
                _: 1
              }),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_usage, { name: "v-empty-state" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_6,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-empty-state/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-empty-state")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_8, [
                createVNode(_component_app_heading, {
                  href: "#guide",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Guide")
                  ]),
                  _: 1
                }),
                _hoisted_9,
                createBaseVNode("section", _hoisted_10, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  _hoisted_11,
                  createBaseVNode("section", _hoisted_12, [
                    createVNode(_component_app_heading, {
                      href: "#content",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Content")
                      ]),
                      _: 1
                    }),
                    _hoisted_13,
                    createVNode(_component_examples_example, { file: "v-empty-state/prop-content" })
                  ]),
                  createBaseVNode("section", _hoisted_14, [
                    createVNode(_component_app_heading, {
                      href: "#media",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Media")
                      ]),
                      _: 1
                    }),
                    _hoisted_15,
                    createVNode(_component_examples_example, { file: "v-empty-state/prop-media" })
                  ]),
                  createBaseVNode("section", _hoisted_16, [
                    createVNode(_component_app_heading, {
                      href: "#actions",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Actions")
                      ]),
                      _: 1
                    }),
                    _hoisted_17,
                    createVNode(_component_examples_example, { file: "v-empty-state/prop-actions" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_18, [
                  createVNode(_component_app_heading, {
                    href: "#slots",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Slots")
                    ]),
                    _: 1
                  }),
                  _hoisted_19,
                  createVNode(_component_app_table, null, {
                    default: withCtx(() => [
                      _hoisted_20,
                      _hoisted_21
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_22, [
                    createVNode(_component_app_heading, {
                      href: "#default",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Default")
                      ]),
                      _: 1
                    }),
                    _hoisted_23,
                    createVNode(_component_examples_example, { file: "v-empty-state/slot-default" })
                  ]),
                  createBaseVNode("section", _hoisted_24, [
                    createVNode(_component_app_heading, {
                      href: "#title",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Title")
                      ]),
                      _: 1
                    }),
                    _hoisted_25,
                    createVNode(_component_examples_example, { file: "v-empty-state/slot-title" })
                  ]),
                  createBaseVNode("section", _hoisted_26, [
                    createVNode(_component_app_heading, {
                      href: "#custom-actions",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Custom Actions")
                      ]),
                      _: 1
                    }),
                    _hoisted_27,
                    createVNode(_component_examples_example, { file: "v-empty-state/slot-actions" })
                  ])
                ])
              ]),
              createBaseVNode("section", _hoisted_28, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                _hoisted_29,
                createBaseVNode("section", _hoisted_30, [
                  createVNode(_component_app_heading, {
                    href: "#astro-dog",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Astro dog")
                    ]),
                    _: 1
                  }),
                  _hoisted_31,
                  createVNode(_component_examples_example, { file: "v-empty-state/misc-astro-dog" })
                ]),
                createBaseVNode("section", _hoisted_32, [
                  createVNode(_component_app_heading, {
                    href: "#astro-cat",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Astro cat")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("p", null, [
                    createTextVNode("This example utilizes components such as "),
                    createVNode(_component_app_link, { href: "/components/tabs/" }, {
                      default: withCtx(() => [
                        createTextVNode("v-tabs")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" and "),
                    createVNode(_component_app_link, { href: "/components/windows/" }, {
                      default: withCtx(() => [
                        createTextVNode("v-window")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" to create a more complex empty state.")
                  ]),
                  createVNode(_component_examples_example, { file: "v-empty-state/misc-astro-cat" })
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
