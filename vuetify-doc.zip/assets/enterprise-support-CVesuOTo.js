import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "direct-support-from-vuetify" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "Let the experts at Vuetify help you get the most out of your application with a customized support plan from the team behind the framework.", -1);
const _hoisted_3 = { id: "for-enterprise" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, "Vuetify offers a variety of support options to meet any need.", -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_6 = { id: "chat-support" };
const frontmatter = { "fluid": true, "meta": { "nav": "For Enterprise", "title": "Direct support from Vuetify", "description": "Let the experts at Vuetify help you get the most out of your application with a customized support plan from the team behind the framework.", "keywords": "vuetify enterprise, vuetify support, vuetify direct support, vuetify help" }, "related": ["/introduction/long-term-support/", "/about/security-disclosure/", "/about/meet-the-team/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "enterprise-support",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "For Enterprise", "title": "Direct support from Vuetify", "description": "Let the experts at Vuetify help you get the most out of your application with a customized support plan from the team behind the framework.", "keywords": "vuetify enterprise, vuetify support, vuetify direct support, vuetify help" } };
    useHead(head);
    __expose({ frontmatter: { "fluid": true, "meta": { "nav": "For Enterprise", "title": "Direct support from Vuetify", "description": "Let the experts at Vuetify help you get the most out of your application with a customized support plan from the team behind the framework.", "keywords": "vuetify enterprise, vuetify support, vuetify direct support, vuetify help" }, "related": ["/introduction/long-term-support/", "/about/security-disclosure/", "/about/meet-the-team/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_introduction_enterprise_deck = resolveComponent("introduction-enterprise-deck");
      const _component_app_link = resolveComponent("app-link");
      const _component_introduction_discord_deck = resolveComponent("introduction-discord-deck");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#direct-support-from-vuetify",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Direct support from Vuetify")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#for-enterprise",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("For Enterprise")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_introduction_enterprise_deck),
                _hoisted_5
              ]),
              createBaseVNode("section", _hoisted_6, [
                createVNode(_component_app_heading, {
                  href: "#chat-support",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Chat support")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("Get direct access to the Vuetify team through our private "),
                  createVNode(_component_app_link, { href: "https://community.vuetifyjs.com/" }, {
                    default: withCtx(() => [
                      createTextVNode("Discord server")
                    ]),
                    _: 1
                  }),
                  createTextVNode(". Ask questions, get help, and chat with the team.")
                ]),
                createVNode(_component_introduction_discord_deck)
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
