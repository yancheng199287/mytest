import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "expansion-panels" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-expansion-panel"),
  /* @__PURE__ */ createTextVNode(" component is useful for reducing vertical space with large amounts of information. The default functionality of the component is to only display one expansion-panel body at a time; however, with the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "multiple"),
  /* @__PURE__ */ createTextVNode(" property, the expansion-panel can remain open until explicitly closed.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Expansion panels in their simplest form display a list of expandable items. You can either declare the markup explicitly, or use the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "title"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "text"),
  /* @__PURE__ */ createTextVNode(" props.")
], -1);
const _hoisted_5 = { id: "api" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "Primary component", -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createTextVNode("Sub-component that wraps "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-expansion-panel-text"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-expansion-panel-title")
], -1);
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createTextVNode("Sub-component used to display the Expansion Panel’s title. Wraps the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "#title"),
  /* @__PURE__ */ createTextVNode(" slot")
], -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createTextVNode("Sub-component used to display the Expanion Panel’s text. Wraps the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "#text"),
  /* @__PURE__ */ createTextVNode(" slot")
], -1);
const _hoisted_11 = { id: "examples" };
const _hoisted_12 = { id: "props" };
const _hoisted_13 = { id: "variant" };
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("p", null, "There are four different variants of the expansion-panel. Accordion expansion-panels have no margins around the currently active panel. Inset expansion-panels become smaller when activated, while poput expansion-panels become larger.", -1);
const _hoisted_15 = { id: "disabled" };
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Both the expansion-panel and its content can be disabled using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "disabled"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_17 = { id: "model" };
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Expansion panels can be controlled externally by using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "v-model"),
  /* @__PURE__ */ createTextVNode(". You will need to set a "),
  /* @__PURE__ */ createBaseVNode("strong", null, "value"),
  /* @__PURE__ */ createTextVNode(" on each panel, so that you can refer to them outside the component. If the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "multiple"),
  /* @__PURE__ */ createTextVNode(" prop is set, then the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "v-model"),
  /* @__PURE__ */ createTextVNode(" value will be an array.")
], -1);
const _hoisted_19 = { id: "readonly" };
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "readonly"),
  /* @__PURE__ */ createTextVNode(" prop does the same thing as "),
  /* @__PURE__ */ createBaseVNode("strong", null, "disabled"),
  /* @__PURE__ */ createTextVNode(", but it doesn’t touch styles.")
], -1);
const _hoisted_21 = { id: "misc" };
const _hoisted_22 = { id: "advanced" };
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The expansion panel component provides a rich playground to build truly advanced implementations. Here we take advantage of slots in the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-expansion-panel-header"),
  /* @__PURE__ */ createTextVNode(" component to react to the state of being open or closed by fading content in and out.")
], -1);
const _hoisted_24 = { id: "custom-icon" };
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Expand action icon can be customized with "),
  /* @__PURE__ */ createBaseVNode("strong", null, "expand-icon"),
  /* @__PURE__ */ createTextVNode(" prop or the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "actions"),
  /* @__PURE__ */ createTextVNode(" slot.")
], -1);
const frontmatter = { "meta": { "nav": "Expansion panels", "title": "Expansion panel component", "description": "The expansion panel component is a lightweight container that hides information behind expandable and contractable containers.", "keywords": "expansion panels, vuetify expansion panel component, vue expansion panel component" }, "related": ["/components/cards/", "/components/data-tables/basics/", "/components/lists/"], "features": { "github": "/components/VExpansionPanel/", "label": "C: VExpansionPanels", "report": true, "spec": "https://m1.material.io/components/expansion-panels.html" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "expansion-panels",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Expansion panels", "title": "Expansion panel component", "description": "The expansion panel component is a lightweight container that hides information behind expandable and contractable containers.", "keywords": "expansion panels, vuetify expansion panel component, vue expansion panel component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Expansion panels", "title": "Expansion panel component", "description": "The expansion panel component is a lightweight container that hides information behind expandable and contractable containers.", "keywords": "expansion panels, vuetify expansion panel component, vue expansion panel component" }, "related": ["/components/cards/", "/components/data-tables/basics/", "/components/lists/"], "features": { "github": "/components/VExpansionPanel/", "label": "C: VExpansionPanels", "report": true, "spec": "https://m1.material.io/components/expansion-panels.html" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#expansion-panels",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Expansion panels")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_usage, { name: "v-expansion-panels" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_6,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-expansion-panels/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-expansion-panels")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-expansion-panel/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-expansion-panel")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_8
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-expansion-panel-title/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-expansion-panel-title")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_9
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-expansion-panel-text/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-expansion-panel-text")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_10
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_11, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_12, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_13, [
                    createVNode(_component_app_heading, {
                      href: "#variant",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Variant")
                      ]),
                      _: 1
                    }),
                    _hoisted_14,
                    createVNode(_component_examples_example, { file: "v-expansion-panels/prop-variant" })
                  ]),
                  createBaseVNode("section", _hoisted_15, [
                    createVNode(_component_app_heading, {
                      href: "#disabled",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Disabled")
                      ]),
                      _: 1
                    }),
                    _hoisted_16,
                    createVNode(_component_examples_example, { file: "v-expansion-panels/prop-disabled" })
                  ]),
                  createBaseVNode("section", _hoisted_17, [
                    createVNode(_component_app_heading, {
                      href: "#model",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Model")
                      ]),
                      _: 1
                    }),
                    _hoisted_18,
                    createVNode(_component_examples_example, { file: "v-expansion-panels/prop-model" })
                  ]),
                  createBaseVNode("section", _hoisted_19, [
                    createVNode(_component_app_heading, {
                      href: "#readonly",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Readonly")
                      ]),
                      _: 1
                    }),
                    _hoisted_20,
                    createVNode(_component_examples_example, { file: "v-expansion-panels/prop-readonly" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_21, [
                  createVNode(_component_app_heading, {
                    href: "#misc",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Misc")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_22, [
                    createVNode(_component_app_heading, {
                      href: "#advanced",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Advanced")
                      ]),
                      _: 1
                    }),
                    _hoisted_23,
                    createVNode(_component_examples_example, { file: "v-expansion-panels/misc-advanced" })
                  ]),
                  createBaseVNode("section", _hoisted_24, [
                    createVNode(_component_app_heading, {
                      href: "#custom-icon",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Custom icon")
                      ]),
                      _: 1
                    }),
                    _hoisted_25,
                    createVNode(_component_examples_example, { file: "v-expansion-panels/misc-custom-icons" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
