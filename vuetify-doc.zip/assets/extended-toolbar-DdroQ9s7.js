import { y as _export_sfc, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, b as createVNode, h as createTextVNode, l as createElementBlock, v as renderList, F as Fragment } from "./index-DGybHjCP.js";
const _sfc_main = {};
function _sfc_render(_ctx, _cache) {
  const _component_v_app_bar_nav_icon = resolveComponent("v-app-bar-nav-icon");
  const _component_v_app_bar_title = resolveComponent("v-app-bar-title");
  const _component_v_spacer = resolveComponent("v-spacer");
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_app_bar = resolveComponent("v-app-bar");
  const _component_v_card = resolveComponent("v-card");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  const _component_v_main = resolveComponent("v-main");
  const _component_v_app = resolveComponent("v-app");
  return openBlock(), createBlock(_component_v_app, { id: "inspire" }, {
    default: withCtx(() => [
      createVNode(_component_v_app_bar, { extended: "" }, {
        default: withCtx(() => [
          createVNode(_component_v_app_bar_nav_icon),
          createVNode(_component_v_app_bar_title, null, {
            default: withCtx(() => [
              createTextVNode("Application")
            ]),
            _: 1
          }),
          createVNode(_component_v_spacer),
          createVNode(_component_v_btn, { icon: "mdi-dots-vertical" })
        ]),
        _: 1
      }),
      createVNode(_component_v_main, null, {
        default: withCtx(() => [
          createVNode(_component_v_container, null, {
            default: withCtx(() => [
              createVNode(_component_v_row, null, {
                default: withCtx(() => [
                  (openBlock(), createElementBlock(Fragment, null, renderList(24, (n) => {
                    return createVNode(_component_v_col, {
                      key: n,
                      cols: "4"
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_v_card, { height: "200" })
                      ]),
                      _: 2
                    }, 1024);
                  }), 64))
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __3 = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __3 as _
};
