import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "file-inputs" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-file-input"),
  /* @__PURE__ */ createTextVNode(" component is a specialized input that provides a clean interface for selecting files, showing detailed selection information and upload progress. It is meant to be a direct replacement for a standard file input.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-file-input", -1);
const _hoisted_5 = { id: "api" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "Primary component", -1);
const _hoisted_8 = { id: "examples" };
const _hoisted_9 = { id: "props" };
const _hoisted_10 = { id: "accept" };
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-file-input", -1);
const _hoisted_12 = { id: "chips" };
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("strong", null, "chips", -1);
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("strong", null, "multiple", -1);
const _hoisted_15 = { id: "counter" };
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("When using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "show-size"),
  /* @__PURE__ */ createTextVNode(" property along with "),
  /* @__PURE__ */ createBaseVNode("strong", null, "counter"),
  /* @__PURE__ */ createTextVNode(", the total number of files and size will be displayed under the input.")
], -1);
const _hoisted_17 = { id: "density" };
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can reduces the file input height with the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "density"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_19 = { id: "multiple" };
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-file-input"),
  /* @__PURE__ */ createTextVNode(" can contain multiple files at the same time when using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "multiple"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_21 = { id: "prepend-icon" };
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-file-input", -1);
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("strong", null, "prepend-icon", -1);
const _hoisted_24 = { id: "show-size" };
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The displayed size of the selected file(s) can be configured with the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "show-size"),
  /* @__PURE__ */ createTextVNode(" property. Display sizes can be either "),
  /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "1024"),
  /* @__PURE__ */ createTextVNode(" (the default used when providing "),
  /* @__PURE__ */ createBaseVNode("strong", null, "true"),
  /* @__PURE__ */ createTextVNode(") or "),
  /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "1000"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_26 = { id: "validation" };
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Similar to other inputs, you can use the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "rules"),
  /* @__PURE__ */ createTextVNode(" prop to create your own custom validation parameters.")
], -1);
const _hoisted_28 = { id: "slots" };
const _hoisted_29 = { id: "selection" };
const _hoisted_30 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "selection", -1);
const _hoisted_31 = { id: "misc" };
const _hoisted_32 = { id: "complex-selection-slot" };
const _hoisted_33 = /* @__PURE__ */ createBaseVNode("p", null, "The flexibility of the selection slot allows you accommodate complex use-cases. In this example we show the first 2 selections as chips while adding a number indicator for the remaining amount.", -1);
const frontmatter = { "meta": { "nav": "File inputs", "title": "File input component", "description": "The file input component is a specialized input that provides a clean interface for selecting files, showing detailed selection information and upload progress.", "keywords": "file input, file upload, file field" }, "related": ["/components/text-fields/", "/components/forms/", "/components/icons/"], "features": { "label": "C: VFileInput", "report": true, "github": "/components/VFileInput/" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "file-inputs",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "File inputs", "title": "File input component", "description": "The file input component is a specialized input that provides a clean interface for selecting files, showing detailed selection information and upload progress.", "keywords": "file input, file upload, file field" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "File inputs", "title": "File input component", "description": "The file input component is a specialized input that provides a clean interface for selecting files, showing detailed selection information and upload progress.", "keywords": "file input, file upload, file field" }, "related": ["/components/text-fields/", "/components/forms/", "/components/icons/"], "features": { "label": "C: VFileInput", "report": true, "github": "/components/VFileInput/" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_app_link = resolveComponent("app-link");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#file-inputs",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("File inputs")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("At its core, the "),
                  _hoisted_4,
                  createTextVNode(" component is a basic container that extends "),
                  createVNode(_component_app_link, { href: "/components/text-fields" }, {
                    default: withCtx(() => [
                      createTextVNode("v-text-field")
                    ]),
                    _: 1
                  }),
                  createTextVNode(".")
                ]),
                createVNode(_component_examples_usage, { name: "v-file-input" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_6,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-file-input/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-file-input")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_8, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_9, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_10, [
                    createVNode(_component_app_heading, {
                      href: "#accept",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Accept")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      _hoisted_11,
                      createTextVNode(" component can accept only specific media formats/file types if you want. For more information, checkout the documentation on the "),
                      createVNode(_component_app_link, { href: "https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input/file#accept" }, {
                        default: withCtx(() => [
                          createTextVNode("accept attribute")
                        ]),
                        _: 1
                      }),
                      createTextVNode(".")
                    ]),
                    createVNode(_component_examples_example, { file: "v-file-input/prop-accept" })
                  ]),
                  createBaseVNode("section", _hoisted_12, [
                    createVNode(_component_app_heading, {
                      href: "#chips",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Chips")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("A selected file can be displayed as a "),
                      createVNode(_component_app_link, { href: "/components/chips" }, {
                        default: withCtx(() => [
                          createTextVNode("chip")
                        ]),
                        _: 1
                      }),
                      createTextVNode(". When using the "),
                      _hoisted_13,
                      createTextVNode(" and "),
                      _hoisted_14,
                      createTextVNode(" props, each chip will be displayed (as opposed to the file count).")
                    ]),
                    createVNode(_component_examples_example, { file: "v-file-input/prop-chips" })
                  ]),
                  createBaseVNode("section", _hoisted_15, [
                    createVNode(_component_app_heading, {
                      href: "#counter",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Counter")
                      ]),
                      _: 1
                    }),
                    _hoisted_16,
                    createVNode(_component_examples_example, { file: "v-file-input/prop-counter" })
                  ]),
                  createBaseVNode("section", _hoisted_17, [
                    createVNode(_component_app_heading, {
                      href: "#density",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Density")
                      ]),
                      _: 1
                    }),
                    _hoisted_18,
                    createVNode(_component_examples_example, { file: "v-file-input/prop-dense" })
                  ]),
                  createBaseVNode("section", _hoisted_19, [
                    createVNode(_component_app_heading, {
                      href: "#multiple",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Multiple")
                      ]),
                      _: 1
                    }),
                    _hoisted_20,
                    createVNode(_component_examples_example, { file: "v-file-input/prop-multiple" })
                  ]),
                  createBaseVNode("section", _hoisted_21, [
                    createVNode(_component_app_heading, {
                      href: "#prepend-icon",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Prepend icon")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("The "),
                      _hoisted_22,
                      createTextVNode(" has a default "),
                      _hoisted_23,
                      createTextVNode(" that can be set on the component or adjusted globally. More information on changing global components can be found on the "),
                      createVNode(_component_app_link, { href: "/features/icon-fonts" }, {
                        default: withCtx(() => [
                          createTextVNode("customizing icons page")
                        ]),
                        _: 1
                      }),
                      createTextVNode(".")
                    ]),
                    createVNode(_component_examples_example, { file: "v-file-input/prop-prepend-icon" })
                  ]),
                  createBaseVNode("section", _hoisted_24, [
                    createVNode(_component_app_heading, {
                      href: "#show-size",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Show size")
                      ]),
                      _: 1
                    }),
                    _hoisted_25,
                    createVNode(_component_examples_example, { file: "v-file-input/prop-show-size" })
                  ]),
                  createBaseVNode("section", _hoisted_26, [
                    createVNode(_component_app_heading, {
                      href: "#validation",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Validation")
                      ]),
                      _: 1
                    }),
                    _hoisted_27,
                    createVNode(_component_examples_example, { file: "v-file-input/prop-validation" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_28, [
                  createVNode(_component_app_heading, {
                    href: "#slots",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Slots")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_29, [
                    createVNode(_component_app_heading, {
                      href: "#selection",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Selection")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("Using the "),
                      _hoisted_30,
                      createTextVNode(" slot, you can customize the appearance of your input selections. This is typically done with "),
                      createVNode(_component_app_link, { href: "/components/chips" }, {
                        default: withCtx(() => [
                          createTextVNode("chips")
                        ]),
                        _: 1
                      }),
                      createTextVNode(", however any component or markup can be used.")
                    ]),
                    createVNode(_component_examples_example, { file: "v-file-input/slot-selection" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_31, [
                  createVNode(_component_app_heading, {
                    href: "#misc",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Misc")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_32, [
                    createVNode(_component_app_heading, {
                      href: "#complex-selection-slot",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Complex selection slot")
                      ]),
                      _: 1
                    }),
                    _hoisted_33,
                    createVNode(_component_examples_example, { file: "v-file-input/misc-complex-selection" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
