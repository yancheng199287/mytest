import { y as _export_sfc, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, l as createElementBlock, F as Fragment, v as renderList, b as createVNode, h as createTextVNode, e as createBaseVNode, t as toDisplayString } from "./index-DGybHjCP.js";
const _sfc_main$j = {};
function _sfc_render$j(_ctx, _cache) {
  const _component_v_sheet = resolveComponent("v-sheet");
  return openBlock(), createBlock(_component_v_sheet, {
    class: "d-flex align-content-space-around flex-wrap bg-surface-variant",
    "min-height": "200"
  }, {
    default: withCtx(() => [
      (openBlock(), createElementBlock(Fragment, null, renderList(20, (n) => {
        return createVNode(_component_v_sheet, {
          key: n,
          class: "ma-2 pa-2"
        }, {
          default: withCtx(() => [
            createTextVNode(" Flex item ")
          ]),
          _: 2
        }, 1024);
      }), 64))
    ]),
    _: 1
  });
}
const __0 = /* @__PURE__ */ _export_sfc(_sfc_main$j, [["render", _sfc_render$j]]);
const __0_raw = '<template>\n  <v-sheet\n    class="d-flex align-content-space-around flex-wrap bg-surface-variant"\n    min-height="200"\n  >\n    <v-sheet\n      v-for="n in 20"\n      :key="n"\n      class="ma-2 pa-2"\n    >\n      Flex item\n    </v-sheet>\n  </v-sheet>\n</template>\n';
const _sfc_main$i = {};
function _sfc_render$i(_ctx, _cache) {
  const _component_v_sheet = resolveComponent("v-sheet");
  return openBlock(), createBlock(_component_v_sheet, {
    class: "d-flex align-content-space-between flex-wrap bg-surface-variant",
    "min-height": "200"
  }, {
    default: withCtx(() => [
      (openBlock(), createElementBlock(Fragment, null, renderList(20, (n) => {
        return createVNode(_component_v_sheet, {
          key: n,
          class: "ma-2 pa-2"
        }, {
          default: withCtx(() => [
            createTextVNode(" Flex item ")
          ]),
          _: 2
        }, 1024);
      }), 64))
    ]),
    _: 1
  });
}
const __1 = /* @__PURE__ */ _export_sfc(_sfc_main$i, [["render", _sfc_render$i]]);
const __1_raw = '<template>\n  <v-sheet\n    class="d-flex align-content-space-between flex-wrap bg-surface-variant"\n    min-height="200"\n  >\n    <v-sheet\n      v-for="n in 20"\n      :key="n"\n      class="ma-2 pa-2"\n    >\n      Flex item\n    </v-sheet>\n  </v-sheet>\n</template>\n';
const _sfc_main$h = {};
function _sfc_render$h(_ctx, _cache) {
  const _component_v_sheet = resolveComponent("v-sheet");
  return openBlock(), createBlock(_component_v_sheet, {
    class: "d-flex align-content-center flex-wrap bg-surface-variant",
    "min-height": "200"
  }, {
    default: withCtx(() => [
      (openBlock(), createElementBlock(Fragment, null, renderList(20, (n) => {
        return createVNode(_component_v_sheet, {
          key: n,
          class: "ma-2 pa-2"
        }, {
          default: withCtx(() => [
            createTextVNode(" Flex item ")
          ]),
          _: 2
        }, 1024);
      }), 64))
    ]),
    _: 1
  });
}
const __2 = /* @__PURE__ */ _export_sfc(_sfc_main$h, [["render", _sfc_render$h]]);
const __2_raw = '<template>\n  <v-sheet\n    class="d-flex align-content-center flex-wrap bg-surface-variant"\n    min-height="200"\n  >\n    <v-sheet\n      v-for="n in 20"\n      :key="n"\n      class="ma-2 pa-2"\n    >\n      Flex item\n    </v-sheet>\n  </v-sheet>\n</template>\n';
const _sfc_main$g = {};
function _sfc_render$g(_ctx, _cache) {
  const _component_v_sheet = resolveComponent("v-sheet");
  return openBlock(), createBlock(_component_v_sheet, {
    class: "d-flex align-content-end flex-wrap bg-surface-variant",
    "min-height": "200"
  }, {
    default: withCtx(() => [
      (openBlock(), createElementBlock(Fragment, null, renderList(20, (n) => {
        return createVNode(_component_v_sheet, {
          key: n,
          class: "ma-2 pa-2"
        }, {
          default: withCtx(() => [
            createTextVNode(" Flex item ")
          ]),
          _: 2
        }, 1024);
      }), 64))
    ]),
    _: 1
  });
}
const __3 = /* @__PURE__ */ _export_sfc(_sfc_main$g, [["render", _sfc_render$g]]);
const __3_raw = '<template>\n  <v-sheet\n    class="d-flex align-content-end flex-wrap bg-surface-variant"\n    min-height="200"\n  >\n    <v-sheet\n      v-for="n in 20"\n      :key="n"\n      class="ma-2 pa-2"\n    >\n      Flex item\n    </v-sheet>\n  </v-sheet>\n</template>\n';
const _sfc_main$f = {};
function _sfc_render$f(_ctx, _cache) {
  const _component_v_sheet = resolveComponent("v-sheet");
  return openBlock(), createBlock(_component_v_sheet, {
    class: "d-flex align-content-start flex-wrap bg-surface-variant",
    "min-height": "200"
  }, {
    default: withCtx(() => [
      (openBlock(), createElementBlock(Fragment, null, renderList(20, (n) => {
        return createVNode(_component_v_sheet, {
          key: n,
          class: "ma-2 pa-2"
        }, {
          default: withCtx(() => [
            createTextVNode(" Flex item ")
          ]),
          _: 2
        }, 1024);
      }), 64))
    ]),
    _: 1
  });
}
const __4 = /* @__PURE__ */ _export_sfc(_sfc_main$f, [["render", _sfc_render$f]]);
const __4_raw = '<template>\n  <v-sheet\n    class="d-flex align-content-start flex-wrap bg-surface-variant"\n    min-height="200"\n  >\n    <v-sheet\n      v-for="n in 20"\n      :key="n"\n      class="ma-2 pa-2"\n    >\n      Flex item\n    </v-sheet>\n  </v-sheet>\n</template>\n';
const _sfc_main$e = {};
function _sfc_render$e(_ctx, _cache) {
  const _component_v_sheet = resolveComponent("v-sheet");
  return openBlock(), createElementBlock("div", null, [
    createVNode(_component_v_sheet, {
      class: "d-flex mb-6 bg-surface-variant",
      height: "100"
    }, {
      default: withCtx(() => [
        createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
          default: withCtx(() => [
            createTextVNode("Flex item")
          ]),
          _: 1
        }),
        createVNode(_component_v_sheet, { class: "ma-2 pa-2 align-self-start" }, {
          default: withCtx(() => [
            createTextVNode("align-self-start")
          ]),
          _: 1
        }),
        createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
          default: withCtx(() => [
            createTextVNode("Flex item")
          ]),
          _: 1
        })
      ]),
      _: 1
    }),
    createVNode(_component_v_sheet, {
      class: "d-flex mb-6 bg-surface-variant",
      height: "100"
    }, {
      default: withCtx(() => [
        createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
          default: withCtx(() => [
            createTextVNode("Flex item")
          ]),
          _: 1
        }),
        createVNode(_component_v_sheet, { class: "ma-2 pa-2 align-self-end" }, {
          default: withCtx(() => [
            createTextVNode("align-self-end")
          ]),
          _: 1
        }),
        createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
          default: withCtx(() => [
            createTextVNode("Flex item")
          ]),
          _: 1
        })
      ]),
      _: 1
    }),
    createVNode(_component_v_sheet, {
      class: "d-flex mb-6 bg-surface-variant",
      height: "100"
    }, {
      default: withCtx(() => [
        createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
          default: withCtx(() => [
            createTextVNode("Flex item")
          ]),
          _: 1
        }),
        createVNode(_component_v_sheet, { class: "ma-2 pa-2 align-self-center" }, {
          default: withCtx(() => [
            createTextVNode("align-self-center")
          ]),
          _: 1
        }),
        createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
          default: withCtx(() => [
            createTextVNode("Flex item")
          ]),
          _: 1
        })
      ]),
      _: 1
    }),
    createVNode(_component_v_sheet, {
      class: "d-flex mb-6 bg-surface-variant",
      height: "100"
    }, {
      default: withCtx(() => [
        createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
          default: withCtx(() => [
            createTextVNode("Flex item")
          ]),
          _: 1
        }),
        createVNode(_component_v_sheet, { class: "ma-2 pa-2 align-self-baseline" }, {
          default: withCtx(() => [
            createTextVNode("align-self-baseline")
          ]),
          _: 1
        }),
        createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
          default: withCtx(() => [
            createTextVNode("Flex item")
          ]),
          _: 1
        })
      ]),
      _: 1
    }),
    createVNode(_component_v_sheet, {
      class: "d-flex mb-6 bg-surface-variant",
      height: "100"
    }, {
      default: withCtx(() => [
        createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
          default: withCtx(() => [
            createTextVNode("Flex item")
          ]),
          _: 1
        }),
        createVNode(_component_v_sheet, { class: "ma-2 pa-2 align-self-auto" }, {
          default: withCtx(() => [
            createTextVNode("align-self-auto")
          ]),
          _: 1
        }),
        createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
          default: withCtx(() => [
            createTextVNode("Flex item")
          ]),
          _: 1
        })
      ]),
      _: 1
    }),
    createVNode(_component_v_sheet, {
      class: "d-flex mb-6 bg-surface-variant",
      height: "100"
    }, {
      default: withCtx(() => [
        createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
          default: withCtx(() => [
            createTextVNode("Flex item")
          ]),
          _: 1
        }),
        createVNode(_component_v_sheet, { class: "ma-2 pa-2 align-self-stretch" }, {
          default: withCtx(() => [
            createTextVNode("align-self-stretch")
          ]),
          _: 1
        }),
        createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
          default: withCtx(() => [
            createTextVNode("Flex item")
          ]),
          _: 1
        })
      ]),
      _: 1
    })
  ]);
}
const __5 = /* @__PURE__ */ _export_sfc(_sfc_main$e, [["render", _sfc_render$e]]);
const __5_raw = '<template>\n  <div>\n    <v-sheet\n      class="d-flex mb-6 bg-surface-variant"\n      height="100"\n    >\n      <v-sheet class="ma-2 pa-2">Flex item</v-sheet>\n      <v-sheet class="ma-2 pa-2 align-self-start">align-self-start</v-sheet>\n      <v-sheet class="ma-2 pa-2">Flex item</v-sheet>\n    </v-sheet>\n\n    <v-sheet\n      class="d-flex mb-6 bg-surface-variant"\n      height="100"\n    >\n      <v-sheet class="ma-2 pa-2">Flex item</v-sheet>\n      <v-sheet class="ma-2 pa-2 align-self-end">align-self-end</v-sheet>\n      <v-sheet class="ma-2 pa-2">Flex item</v-sheet>\n    </v-sheet>\n\n    <v-sheet\n      class="d-flex mb-6 bg-surface-variant"\n      height="100"\n    >\n      <v-sheet class="ma-2 pa-2">Flex item</v-sheet>\n      <v-sheet class="ma-2 pa-2 align-self-center">align-self-center</v-sheet>\n      <v-sheet class="ma-2 pa-2">Flex item</v-sheet>\n    </v-sheet>\n\n    <v-sheet\n      class="d-flex mb-6 bg-surface-variant"\n      height="100"\n    >\n      <v-sheet class="ma-2 pa-2">Flex item</v-sheet>\n      <v-sheet class="ma-2 pa-2 align-self-baseline">align-self-baseline</v-sheet>\n      <v-sheet class="ma-2 pa-2">Flex item</v-sheet>\n    </v-sheet>\n\n    <v-sheet\n      class="d-flex mb-6 bg-surface-variant"\n      height="100"\n    >\n      <v-sheet class="ma-2 pa-2">Flex item</v-sheet>\n      <v-sheet class="ma-2 pa-2 align-self-auto">align-self-auto</v-sheet>\n      <v-sheet class="ma-2 pa-2">Flex item</v-sheet>\n    </v-sheet>\n\n    <v-sheet\n      class="d-flex mb-6 bg-surface-variant"\n      height="100"\n    >\n      <v-sheet class="ma-2 pa-2">Flex item</v-sheet>\n      <v-sheet class="ma-2 pa-2 align-self-stretch">align-self-stretch</v-sheet>\n      <v-sheet class="ma-2 pa-2">Flex item</v-sheet>\n    </v-sheet>\n  </div>\n</template>\n';
const _sfc_main$d = {};
function _sfc_render$d(_ctx, _cache) {
  const _component_v_sheet = resolveComponent("v-sheet");
  return openBlock(), createElementBlock("div", null, [
    createVNode(_component_v_sheet, {
      class: "d-flex align-start mb-6 bg-surface-variant",
      height: "100"
    }, {
      default: withCtx(() => [
        (openBlock(), createElementBlock(Fragment, null, renderList(3, (n) => {
          return createVNode(_component_v_sheet, {
            key: n,
            class: "ma-2 pa-2"
          }, {
            default: withCtx(() => [
              createTextVNode(" align-start ")
            ]),
            _: 2
          }, 1024);
        }), 64))
      ]),
      _: 1
    }),
    createVNode(_component_v_sheet, {
      class: "d-flex align-end mb-6 bg-surface-variant",
      height: "100"
    }, {
      default: withCtx(() => [
        (openBlock(), createElementBlock(Fragment, null, renderList(3, (n) => {
          return createVNode(_component_v_sheet, {
            key: n,
            class: "ma-2 pa-2"
          }, {
            default: withCtx(() => [
              createTextVNode(" align-end ")
            ]),
            _: 2
          }, 1024);
        }), 64))
      ]),
      _: 1
    }),
    createVNode(_component_v_sheet, {
      class: "d-flex align-center mb-6 bg-surface-variant",
      height: "100"
    }, {
      default: withCtx(() => [
        (openBlock(), createElementBlock(Fragment, null, renderList(3, (n) => {
          return createVNode(_component_v_sheet, {
            key: n,
            class: "ma-2 pa-2"
          }, {
            default: withCtx(() => [
              createTextVNode(" align-center ")
            ]),
            _: 2
          }, 1024);
        }), 64))
      ]),
      _: 1
    }),
    createVNode(_component_v_sheet, {
      class: "d-flex align-baseline mb-6 bg-surface-variant",
      height: "100"
    }, {
      default: withCtx(() => [
        (openBlock(), createElementBlock(Fragment, null, renderList(3, (n) => {
          return createVNode(_component_v_sheet, {
            key: n,
            class: "ma-2 pa-2"
          }, {
            default: withCtx(() => [
              createTextVNode(" align-baseline ")
            ]),
            _: 2
          }, 1024);
        }), 64))
      ]),
      _: 1
    }),
    createVNode(_component_v_sheet, {
      class: "d-flex align-stretch mb-6 bg-surface-variant",
      height: "100"
    }, {
      default: withCtx(() => [
        (openBlock(), createElementBlock(Fragment, null, renderList(3, (n) => {
          return createVNode(_component_v_sheet, {
            key: n,
            class: "ma-2 pa-2"
          }, {
            default: withCtx(() => [
              createTextVNode(" align-stretch ")
            ]),
            _: 2
          }, 1024);
        }), 64))
      ]),
      _: 1
    })
  ]);
}
const __6 = /* @__PURE__ */ _export_sfc(_sfc_main$d, [["render", _sfc_render$d]]);
const __6_raw = '<template>\n  <div>\n    <v-sheet\n      class="d-flex align-start mb-6 bg-surface-variant"\n      height="100"\n    >\n      <v-sheet\n        v-for="n in 3"\n        :key="n"\n        class="ma-2 pa-2"\n      >\n        align-start\n      </v-sheet>\n    </v-sheet>\n\n    <v-sheet\n      class="d-flex align-end mb-6 bg-surface-variant"\n      height="100"\n    >\n      <v-sheet\n        v-for="n in 3"\n        :key="n"\n        class="ma-2 pa-2"\n      >\n        align-end\n      </v-sheet>\n    </v-sheet>\n\n    <v-sheet\n      class="d-flex align-center mb-6 bg-surface-variant"\n      height="100"\n    >\n      <v-sheet\n        v-for="n in 3"\n        :key="n"\n        class="ma-2 pa-2"\n      >\n        align-center\n      </v-sheet>\n    </v-sheet>\n\n    <v-sheet\n      class="d-flex align-baseline mb-6 bg-surface-variant"\n      height="100"\n    >\n      <v-sheet\n        v-for="n in 3"\n        :key="n"\n        class="ma-2 pa-2"\n      >\n        align-baseline\n      </v-sheet>\n    </v-sheet>\n\n    <v-sheet\n      class="d-flex align-stretch mb-6 bg-surface-variant"\n      height="100"\n    >\n      <v-sheet\n        v-for="n in 3"\n        :key="n"\n        class="ma-2 pa-2"\n      >\n        align-stretch\n      </v-sheet>\n    </v-sheet>\n  </div>\n</template>\n';
const _sfc_main$c = {};
const _hoisted_1$2 = { class: "d-flex flex-column mb-6 bg-surface-variant" };
const _hoisted_2$2 = { class: "d-flex flex-column-reverse mb-6 bg-surface-variant" };
function _sfc_render$c(_ctx, _cache) {
  const _component_v_sheet = resolveComponent("v-sheet");
  return openBlock(), createElementBlock("div", null, [
    createBaseVNode("div", _hoisted_1$2, [
      createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
        default: withCtx(() => [
          createTextVNode("Flex item 1")
        ]),
        _: 1
      }),
      createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
        default: withCtx(() => [
          createTextVNode("Flex item 2")
        ]),
        _: 1
      }),
      createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
        default: withCtx(() => [
          createTextVNode("Flex item 3")
        ]),
        _: 1
      })
    ]),
    createBaseVNode("div", _hoisted_2$2, [
      createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
        default: withCtx(() => [
          createTextVNode("Flex item 1")
        ]),
        _: 1
      }),
      createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
        default: withCtx(() => [
          createTextVNode("Flex item 2")
        ]),
        _: 1
      }),
      createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
        default: withCtx(() => [
          createTextVNode("Flex item 3")
        ]),
        _: 1
      })
    ])
  ]);
}
const __7 = /* @__PURE__ */ _export_sfc(_sfc_main$c, [["render", _sfc_render$c]]);
const __7_raw = '<template>\n  <div>\n    <div class="d-flex flex-column mb-6 bg-surface-variant">\n      <v-sheet class="ma-2 pa-2">Flex item 1</v-sheet>\n      <v-sheet class="ma-2 pa-2">Flex item 2</v-sheet>\n      <v-sheet class="ma-2 pa-2">Flex item 3</v-sheet>\n    </div>\n\n    <div class="d-flex flex-column-reverse mb-6 bg-surface-variant">\n      <v-sheet class="ma-2 pa-2">Flex item 1</v-sheet>\n      <v-sheet class="ma-2 pa-2">Flex item 2</v-sheet>\n      <v-sheet class="ma-2 pa-2">Flex item 3</v-sheet>\n    </div>\n  </div>\n</template>\n';
const _sfc_main$b = {};
const _hoisted_1$1 = { class: "d-flex flex-row mb-6 bg-surface-variant" };
const _hoisted_2$1 = { class: "d-flex flex-row-reverse mb-6 bg-surface-variant" };
function _sfc_render$b(_ctx, _cache) {
  const _component_v_sheet = resolveComponent("v-sheet");
  return openBlock(), createElementBlock("div", null, [
    createBaseVNode("div", _hoisted_1$1, [
      createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
        default: withCtx(() => [
          createTextVNode("Flex item 1")
        ]),
        _: 1
      }),
      createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
        default: withCtx(() => [
          createTextVNode("Flex item 2")
        ]),
        _: 1
      }),
      createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
        default: withCtx(() => [
          createTextVNode("Flex item 3")
        ]),
        _: 1
      })
    ]),
    createBaseVNode("div", _hoisted_2$1, [
      createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
        default: withCtx(() => [
          createTextVNode("Flex item 1")
        ]),
        _: 1
      }),
      createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
        default: withCtx(() => [
          createTextVNode("Flex item 2")
        ]),
        _: 1
      }),
      createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
        default: withCtx(() => [
          createTextVNode("Flex item 3")
        ]),
        _: 1
      })
    ])
  ]);
}
const __8 = /* @__PURE__ */ _export_sfc(_sfc_main$b, [["render", _sfc_render$b]]);
const __8_raw = '<template>\n  <div>\n    <div class="d-flex flex-row mb-6 bg-surface-variant">\n      <v-sheet class="ma-2 pa-2">Flex item 1</v-sheet>\n      <v-sheet class="ma-2 pa-2">Flex item 2</v-sheet>\n      <v-sheet class="ma-2 pa-2">Flex item 3</v-sheet>\n    </div>\n\n    <div class="d-flex flex-row-reverse mb-6 bg-surface-variant">\n      <v-sheet class="ma-2 pa-2">Flex item 1</v-sheet>\n      <v-sheet class="ma-2 pa-2">Flex item 2</v-sheet>\n      <v-sheet class="ma-2 pa-2">Flex item 3</v-sheet>\n    </div>\n  </div>\n</template>\n';
const _sfc_main$a = {};
function _sfc_render$a(_ctx, _cache) {
  const _component_v_sheet = resolveComponent("v-sheet");
  return openBlock(), createBlock(_component_v_sheet, { class: "d-flex flex-wrap bg-surface-variant" }, {
    default: withCtx(() => [
      createVNode(_component_v_sheet, { class: "flex-1-0 ma-2 pa-2" }, {
        default: withCtx(() => [
          createTextVNode(" I'm an element in an inline flexbox container! ")
        ]),
        _: 1
      }),
      createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
        default: withCtx(() => [
          createTextVNode(" I'm a single element in an inline flexbox container! ")
        ]),
        _: 1
      }),
      createVNode(_component_v_sheet, { class: "flex-1-1-100 ma-2 pa-2" }, {
        default: withCtx(() => [
          createTextVNode(" I'm a single element in an inline flexbox container! ")
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __9 = /* @__PURE__ */ _export_sfc(_sfc_main$a, [["render", _sfc_render$a]]);
const __9_raw = `<template>
  <v-sheet class="d-flex flex-wrap bg-surface-variant">
    <v-sheet class="flex-1-0 ma-2 pa-2">
      I'm an element in an inline flexbox container!
    </v-sheet>

    <v-sheet class="ma-2 pa-2">
      I'm a single element in an inline flexbox container!
    </v-sheet>

    <v-sheet class="flex-1-1-100 ma-2 pa-2">
      I'm a single element in an inline flexbox container!
    </v-sheet>
  </v-sheet>
</template>
`;
const _sfc_main$9 = {};
const _hoisted_1 = { class: "d-flex justify-start mb-6 bg-surface-variant" };
const _hoisted_2 = { class: "d-flex justify-end mb-6 bg-surface-variant" };
const _hoisted_3 = { class: "d-flex justify-center mb-6 bg-surface-variant" };
const _hoisted_4 = { class: "d-flex justify-space-between mb-6 bg-surface-variant" };
const _hoisted_5 = { class: "d-flex justify-space-around mb-6 bg-surface-variant" };
const _hoisted_6 = { class: "d-flex justify-space-evenly mb-6 bg-surface-variant" };
function _sfc_render$9(_ctx, _cache) {
  const _component_v_sheet = resolveComponent("v-sheet");
  return openBlock(), createElementBlock("div", null, [
    createBaseVNode("div", _hoisted_1, [
      (openBlock(), createElementBlock(Fragment, null, renderList(3, (n) => {
        return createVNode(_component_v_sheet, {
          key: n,
          class: "ma-2 pa-2"
        }, {
          default: withCtx(() => [
            createTextVNode(" justify-start ")
          ]),
          _: 2
        }, 1024);
      }), 64))
    ]),
    createBaseVNode("div", _hoisted_2, [
      (openBlock(), createElementBlock(Fragment, null, renderList(3, (n) => {
        return createVNode(_component_v_sheet, {
          key: n,
          class: "ma-2 pa-2"
        }, {
          default: withCtx(() => [
            createTextVNode(" justify-end ")
          ]),
          _: 2
        }, 1024);
      }), 64))
    ]),
    createBaseVNode("div", _hoisted_3, [
      (openBlock(), createElementBlock(Fragment, null, renderList(3, (n) => {
        return createVNode(_component_v_sheet, {
          key: n,
          class: "ma-2 pa-2"
        }, {
          default: withCtx(() => [
            createTextVNode(" justify-center ")
          ]),
          _: 2
        }, 1024);
      }), 64))
    ]),
    createBaseVNode("div", _hoisted_4, [
      (openBlock(), createElementBlock(Fragment, null, renderList(3, (n) => {
        return createVNode(_component_v_sheet, {
          key: n,
          class: "ma-2 pa-2"
        }, {
          default: withCtx(() => [
            createTextVNode(" justify-space-between ")
          ]),
          _: 2
        }, 1024);
      }), 64))
    ]),
    createBaseVNode("div", _hoisted_5, [
      (openBlock(), createElementBlock(Fragment, null, renderList(3, (n) => {
        return createVNode(_component_v_sheet, {
          key: n,
          class: "ma-2 pa-2"
        }, {
          default: withCtx(() => [
            createTextVNode(" justify-space-around ")
          ]),
          _: 2
        }, 1024);
      }), 64))
    ]),
    createBaseVNode("div", _hoisted_6, [
      (openBlock(), createElementBlock(Fragment, null, renderList(3, (n) => {
        return createVNode(_component_v_sheet, {
          key: n,
          class: "ma-2 pa-2"
        }, {
          default: withCtx(() => [
            createTextVNode(" justify-space-evenly ")
          ]),
          _: 2
        }, 1024);
      }), 64))
    ])
  ]);
}
const __10 = /* @__PURE__ */ _export_sfc(_sfc_main$9, [["render", _sfc_render$9]]);
const __10_raw = '<template>\n  <div>\n    <div class="d-flex justify-start mb-6 bg-surface-variant">\n      <v-sheet\n        v-for="n in 3"\n        :key="n"\n        class="ma-2 pa-2"\n      >\n        justify-start\n      </v-sheet>\n    </div>\n\n    <div class="d-flex justify-end mb-6 bg-surface-variant">\n      <v-sheet\n        v-for="n in 3"\n        :key="n"\n        class="ma-2 pa-2"\n      >\n        justify-end\n      </v-sheet>\n    </div>\n\n    <div class="d-flex justify-center mb-6 bg-surface-variant">\n      <v-sheet\n        v-for="n in 3"\n        :key="n"\n        class="ma-2 pa-2"\n      >\n        justify-center\n      </v-sheet>\n    </div>\n\n    <div class="d-flex justify-space-between mb-6 bg-surface-variant">\n      <v-sheet\n        v-for="n in 3"\n        :key="n"\n        class="ma-2 pa-2"\n      >\n        justify-space-between\n      </v-sheet>\n    </div>\n\n    <div class="d-flex justify-space-around mb-6 bg-surface-variant">\n      <v-sheet\n        v-for="n in 3"\n        :key="n"\n        class="ma-2 pa-2"\n      >\n        justify-space-around\n      </v-sheet>\n    </div>\n\n    <div class="d-flex justify-space-evenly mb-6 bg-surface-variant">\n      <v-sheet\n        v-for="n in 3"\n        :key="n"\n        class="ma-2 pa-2"\n      >\n        justify-space-evenly\n      </v-sheet>\n    </div>\n  </div>\n</template>\n';
const _sfc_main$8 = {};
function _sfc_render$8(_ctx, _cache) {
  const _component_v_sheet = resolveComponent("v-sheet");
  return openBlock(), createBlock(_component_v_sheet, {
    class: "d-flex flex-nowrap py-3 bg-surface-variant",
    width: "125"
  }, {
    default: withCtx(() => [
      (openBlock(), createElementBlock(Fragment, null, renderList(5, (n) => {
        return createVNode(_component_v_sheet, {
          key: n,
          class: "ma-2 pa-2"
        }, {
          default: withCtx(() => [
            createTextVNode(" Flex item ")
          ]),
          _: 2
        }, 1024);
      }), 64))
    ]),
    _: 1
  });
}
const __11 = /* @__PURE__ */ _export_sfc(_sfc_main$8, [["render", _sfc_render$8]]);
const __11_raw = '<template>\n  <v-sheet\n    class="d-flex flex-nowrap py-3 bg-surface-variant"\n    width="125"\n  >\n    <v-sheet\n      v-for="n in 5"\n      :key="n"\n      class="ma-2 pa-2"\n    >\n      Flex item\n    </v-sheet>\n  </v-sheet>\n</template>\n';
const _sfc_main$7 = {};
function _sfc_render$7(_ctx, _cache) {
  const _component_v_sheet = resolveComponent("v-sheet");
  return openBlock(), createBlock(_component_v_sheet, { class: "d-flex flex-wrap-reverse bg-surface-variant" }, {
    default: withCtx(() => [
      createVNode(_component_v_sheet, { class: "order-3 pa-2 ma-2" }, {
        default: withCtx(() => [
          createTextVNode(" First flex item ")
        ]),
        _: 1
      }),
      createVNode(_component_v_sheet, { class: "order-2 pa-2 ma-2" }, {
        default: withCtx(() => [
          createTextVNode(" Second flex item ")
        ]),
        _: 1
      }),
      createVNode(_component_v_sheet, { class: "order-1 pa-2 ma-2" }, {
        default: withCtx(() => [
          createTextVNode(" Third flex item ")
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __12 = /* @__PURE__ */ _export_sfc(_sfc_main$7, [["render", _sfc_render$7]]);
const __12_raw = '<template>\n  <v-sheet class="d-flex flex-wrap-reverse bg-surface-variant">\n    <v-sheet class="order-3 pa-2 ma-2">\n      First flex item\n    </v-sheet>\n\n    <v-sheet class="order-2 pa-2 ma-2">\n      Second flex item\n    </v-sheet>\n\n    <v-sheet class="order-1 pa-2 ma-2">\n      Third flex item\n    </v-sheet>\n  </v-sheet>\n</template>\n';
const _sfc_main$6 = {};
function _sfc_render$6(_ctx, _cache) {
  const _component_v_sheet = resolveComponent("v-sheet");
  return openBlock(), createBlock(_component_v_sheet, { class: "d-flex flex-wrap-reverse bg-surface-variant" }, {
    default: withCtx(() => [
      (openBlock(), createElementBlock(Fragment, null, renderList(20, (n) => {
        return createVNode(_component_v_sheet, {
          key: n,
          class: "ma-2 pa-2"
        }, {
          default: withCtx(() => [
            createTextVNode(" Flex item " + toDisplayString(n), 1)
          ]),
          _: 2
        }, 1024);
      }), 64))
    ]),
    _: 1
  });
}
const __13 = /* @__PURE__ */ _export_sfc(_sfc_main$6, [["render", _sfc_render$6]]);
const __13_raw = '<template>\n  <v-sheet class="d-flex flex-wrap-reverse bg-surface-variant">\n    <v-sheet\n      v-for="n in 20"\n      :key="n"\n      class="ma-2 pa-2"\n    >\n      Flex item {{ n }}\n    </v-sheet>\n  </v-sheet>\n</template>\n';
const _sfc_main$5 = {};
function _sfc_render$5(_ctx, _cache) {
  const _component_v_sheet = resolveComponent("v-sheet");
  return openBlock(), createBlock(_component_v_sheet, { class: "d-flex flex-wrap bg-surface-variant" }, {
    default: withCtx(() => [
      (openBlock(), createElementBlock(Fragment, null, renderList(20, (n) => {
        return createVNode(_component_v_sheet, {
          key: n,
          class: "ma-2 pa-2"
        }, {
          default: withCtx(() => [
            createTextVNode(" Flex item " + toDisplayString(n), 1)
          ]),
          _: 2
        }, 1024);
      }), 64))
    ]),
    _: 1
  });
}
const __14 = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["render", _sfc_render$5]]);
const __14_raw = '<template>\n  <v-sheet class="d-flex flex-wrap bg-surface-variant">\n    <v-sheet\n      v-for="n in 20"\n      :key="n"\n      class="ma-2 pa-2"\n    >\n      Flex item {{ n }}\n    </v-sheet>\n  </v-sheet>\n</template>\n';
const _sfc_main$4 = {};
function _sfc_render$4(_ctx, _cache) {
  const _component_v_sheet = resolveComponent("v-sheet");
  return openBlock(), createBlock(_component_v_sheet, { class: "d-inline-flex bg-surface-variant" }, {
    default: withCtx(() => [
      createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
        default: withCtx(() => [
          createTextVNode(" I'm a single element in an inline flexbox container! ")
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __15 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["render", _sfc_render$4]]);
const __15_raw = `<template>
  <v-sheet class="d-inline-flex bg-surface-variant">
    <v-sheet class="ma-2 pa-2">
      I'm a single element in an inline flexbox container!
    </v-sheet>
  </v-sheet>
</template>
`;
const _sfc_main$3 = {};
function _sfc_render$3(_ctx, _cache) {
  const _component_v_sheet = resolveComponent("v-sheet");
  return openBlock(), createBlock(_component_v_sheet, { class: "d-flex bg-surface-variant" }, {
    default: withCtx(() => [
      createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
        default: withCtx(() => [
          createTextVNode(" I'm a single element in a flexbox container! ")
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __16 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["render", _sfc_render$3]]);
const __16_raw = `<template>
  <v-sheet class="d-flex bg-surface-variant">
    <v-sheet class="ma-2 pa-2">
      I'm a single element in a flexbox container!
    </v-sheet>
  </v-sheet>
</template>
`;
const _sfc_main$2 = {};
function _sfc_render$2(_ctx, _cache) {
  const _component_v_sheet = resolveComponent("v-sheet");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, null, {
    default: withCtx(() => [
      createVNode(_component_v_row, {
        class: "flex-nowrap bg-surface-variant",
        "no-gutters": ""
      }, {
        default: withCtx(() => [
          createVNode(_component_v_col, {
            class: "flex-grow-0 flex-shrink-0",
            cols: "2"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
                default: withCtx(() => [
                  createTextVNode(" I'm 2 column wide ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, {
            class: "flex-grow-1 flex-shrink-0",
            cols: "1",
            style: { "min-width": "100px", "max-width": "100%" }
          }, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
                default: withCtx(() => [
                  createTextVNode(" I'm 1 column wide and I grow to take all the space ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, {
            class: "flex-grow-0 flex-shrink-1",
            cols: "5",
            style: { "min-width": "100px" }
          }, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
                default: withCtx(() => [
                  createTextVNode(" I'm 5 column wide and I shrink if there's not enough space ")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __17 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["render", _sfc_render$2]]);
const __17_raw = `<template>
  <v-container>
    <v-row
      class="flex-nowrap bg-surface-variant"
      no-gutters
    >
      <v-col
        class="flex-grow-0 flex-shrink-0"
        cols="2"
      >
        <v-sheet class="ma-2 pa-2">
          I'm 2 column wide
        </v-sheet>
      </v-col>

      <v-col
        class="flex-grow-1 flex-shrink-0"
        cols="1"
        style="min-width: 100px; max-width: 100%;"
      >
        <v-sheet class="ma-2 pa-2">
          I'm 1 column wide and I grow to take all the space
        </v-sheet>
      </v-col>

      <v-col
        class="flex-grow-0 flex-shrink-1"
        cols="5"
        style="min-width: 100px;"
      >
        <v-sheet class="ma-2 pa-2">
          I'm 5 column wide and I shrink if there's not enough space
        </v-sheet>
      </v-col>
    </v-row>
  </v-container>
</template>
`;
const _sfc_main$1 = {};
function _sfc_render$1(_ctx, _cache) {
  const _component_v_sheet = resolveComponent("v-sheet");
  return openBlock(), createElementBlock("div", null, [
    createVNode(_component_v_sheet, {
      class: "d-flex align-start flex-column mb-6 bg-surface-variant",
      height: "200"
    }, {
      default: withCtx(() => [
        createVNode(_component_v_sheet, { class: "ma-2 pa-2 mb-auto" }, {
          default: withCtx(() => [
            createTextVNode("Flex item")
          ]),
          _: 1
        }),
        createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
          default: withCtx(() => [
            createTextVNode("Flex item")
          ]),
          _: 1
        }),
        createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
          default: withCtx(() => [
            createTextVNode("Flex item")
          ]),
          _: 1
        })
      ]),
      _: 1
    }),
    createVNode(_component_v_sheet, {
      class: "d-flex align-end flex-column bg-surface-variant",
      height: "200"
    }, {
      default: withCtx(() => [
        createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
          default: withCtx(() => [
            createTextVNode("Flex item")
          ]),
          _: 1
        }),
        createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
          default: withCtx(() => [
            createTextVNode("Flex item")
          ]),
          _: 1
        }),
        createVNode(_component_v_sheet, { class: "ma-2 pa-2 mt-auto" }, {
          default: withCtx(() => [
            createTextVNode("Flex item")
          ]),
          _: 1
        })
      ]),
      _: 1
    })
  ]);
}
const __18 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["render", _sfc_render$1]]);
const __18_raw = '<template>\n  <div>\n    <v-sheet\n      class="d-flex align-start flex-column mb-6 bg-surface-variant"\n      height="200"\n    >\n      <v-sheet class="ma-2 pa-2 mb-auto">Flex item</v-sheet>\n      <v-sheet class="ma-2 pa-2">Flex item</v-sheet>\n      <v-sheet class="ma-2 pa-2">Flex item</v-sheet>\n    </v-sheet>\n\n    <v-sheet\n      class="d-flex align-end flex-column bg-surface-variant"\n      height="200"\n    >\n      <v-sheet class="ma-2 pa-2">Flex item</v-sheet>\n      <v-sheet class="ma-2 pa-2">Flex item</v-sheet>\n      <v-sheet class="ma-2 pa-2 mt-auto">Flex item</v-sheet>\n    </v-sheet>\n  </div>\n</template>\n';
const _sfc_main = {};
function _sfc_render(_ctx, _cache) {
  const _component_v_sheet = resolveComponent("v-sheet");
  return openBlock(), createElementBlock("div", null, [
    createVNode(_component_v_sheet, { class: "d-flex mb-6 bg-surface-variant" }, {
      default: withCtx(() => [
        createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
          default: withCtx(() => [
            createTextVNode("Flex item")
          ]),
          _: 1
        }),
        createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
          default: withCtx(() => [
            createTextVNode("Flex item")
          ]),
          _: 1
        }),
        createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
          default: withCtx(() => [
            createTextVNode("Flex item")
          ]),
          _: 1
        })
      ]),
      _: 1
    }),
    createVNode(_component_v_sheet, { class: "d-flex mb-6 bg-surface-variant" }, {
      default: withCtx(() => [
        createVNode(_component_v_sheet, { class: "ma-2 pa-2 me-auto" }, {
          default: withCtx(() => [
            createTextVNode("Flex item")
          ]),
          _: 1
        }),
        createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
          default: withCtx(() => [
            createTextVNode("Flex item")
          ]),
          _: 1
        }),
        createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
          default: withCtx(() => [
            createTextVNode("Flex item")
          ]),
          _: 1
        })
      ]),
      _: 1
    }),
    createVNode(_component_v_sheet, { class: "d-flex mb-6 bg-surface-variant" }, {
      default: withCtx(() => [
        createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
          default: withCtx(() => [
            createTextVNode("Flex item")
          ]),
          _: 1
        }),
        createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
          default: withCtx(() => [
            createTextVNode("Flex item")
          ]),
          _: 1
        }),
        createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
          default: withCtx(() => [
            createTextVNode("Flex item")
          ]),
          _: 1
        })
      ]),
      _: 1
    })
  ]);
}
const __19 = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
const __19_raw = '<template>\n  <div>\n    <v-sheet class="d-flex mb-6 bg-surface-variant">\n      <v-sheet class="ma-2 pa-2">Flex item</v-sheet>\n      <v-sheet class="ma-2 pa-2">Flex item</v-sheet>\n      <v-sheet class="ma-2 pa-2">Flex item</v-sheet>\n    </v-sheet>\n\n    <v-sheet class="d-flex mb-6 bg-surface-variant">\n      <v-sheet class="ma-2 pa-2 me-auto">Flex item</v-sheet>\n      <v-sheet class="ma-2 pa-2">Flex item</v-sheet>\n      <v-sheet class="ma-2 pa-2">Flex item</v-sheet>\n    </v-sheet>\n\n    <v-sheet class="d-flex mb-6 bg-surface-variant">\n      <v-sheet class="ma-2 pa-2">Flex item</v-sheet>\n      <v-sheet class="ma-2 pa-2">Flex item</v-sheet>\n      <v-sheet class="ma-2 pa-2">Flex item</v-sheet>\n    </v-sheet>\n  </div>\n</template>\n';
const flex = {
  "flex-align-content-around": {
    component: __0,
    source: __0_raw
  },
  "flex-align-content-between": {
    component: __1,
    source: __1_raw
  },
  "flex-align-content-center": {
    component: __2,
    source: __2_raw
  },
  "flex-align-content-end": {
    component: __3,
    source: __3_raw
  },
  "flex-align-content-start": {
    component: __4,
    source: __4_raw
  },
  "flex-align-self": {
    component: __5,
    source: __5_raw
  },
  "flex-align": {
    component: __6,
    source: __6_raw
  },
  "flex-column": {
    component: __7,
    source: __7_raw
  },
  "flex-direction": {
    component: __8,
    source: __8_raw
  },
  "flex-flex": {
    component: __9,
    source: __9_raw
  },
  "flex-justify": {
    component: __10,
    source: __10_raw
  },
  "flex-nowrap": {
    component: __11,
    source: __11_raw
  },
  "flex-order": {
    component: __12,
    source: __12_raw
  },
  "flex-wrap-reverse": {
    component: __13,
    source: __13_raw
  },
  "flex-wrap": {
    component: __14,
    source: __14_raw
  },
  "flexbox-inline": {
    component: __15,
    source: __15_raw
  },
  "flexbox": {
    component: __16,
    source: __16_raw
  },
  "grow-shrink": {
    component: __17,
    source: __17_raw
  },
  "margins-align-items": {
    component: __18,
    source: __18_raw
  },
  "margins": {
    component: __19,
    source: __19_raw
  }
};
export {
  flex as default
};
