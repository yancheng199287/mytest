import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "flex" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "Control the layout of flex containers with alignment, justification and more with responsive flexbox utilities.", -1);
const _hoisted_3 = { id: "enabling-flexbox" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Using "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "display"),
  /* @__PURE__ */ createTextVNode(" utilities you can turn any element into a flexbox container transforming "),
  /* @__PURE__ */ createBaseVNode("strong", null, "direct children elements"),
  /* @__PURE__ */ createTextVNode(" into flex items. Using additional flex property utilities, you can customize their interaction even further.")
], -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("p", null, "You can also customize flex utilities to apply based upon various breakpoints.", -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".d-flex")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".d-inline-flex")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".d-sm-flex")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".d-sm-inline-flex")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".d-md-flex")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".d-md-inline-flex")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".d-lg-flex")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".d-lg-inline-flex")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".d-xl-flex")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".d-xl-inline-flex")
  ])
], -1);
const _hoisted_7 = { id: "caveats" };
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("It is important to note that using any of the display classes above will result in any display style previously added being overwritten. This is because of the classes using "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "!important"),
  /* @__PURE__ */ createTextVNode(" in their display styling.")
], -1);
const _hoisted_9 = { id: "flex-shorthand" };
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The flex utility classes can be used to modify the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "flex"),
  /* @__PURE__ */ createTextVNode(" css property. This makes it easy to position flex items within a flex container.")
], -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("There are also responsive variations for "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "flex"),
  /* @__PURE__ */ createTextVNode(":")
], -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-fill")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-sm-fill")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-md-fill")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-lg-fill")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-xl-fill")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-1-1")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-sm-1-1")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-md-1-1")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-lg-1-1")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-xl-1-1")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-1-0")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-sm-1-0")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-md-1-0")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-lg-1-0")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-xl-1-0")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-0-1")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-sm-0-1")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-md-0-1")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-lg-0-1")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-xl-0-1")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-0-0")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-sm-0-0")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-md-0-0")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-lg-0-0")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-xl-0-0")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-1-1-100")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-sm-1-1-100")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-md-1-1-100")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-lg-1-1-100")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-xl-1-1-100")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-1-0-100")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-sm-1-0-100")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-md-1-0-100")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-lg-1-0-100")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-xl-1-0-100")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-0-1-100")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-sm-0-1-100")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-md-0-1-100")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-lg-0-1-100")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-xl-0-1-100")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-0-0-100")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-sm-0-0-100")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-md-0-0-100")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-lg-0-0-100")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-xl-0-0-100")
  ])
], -1);
const _hoisted_13 = { id: "flex-direction" };
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("By default, "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "d-flex"),
  /* @__PURE__ */ createTextVNode(" applies "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "flex-direction: row"),
  /* @__PURE__ */ createTextVNode(" and can generally be omitted. However, there may be situations where you need to explicitly define it.")
], -1);
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "flex-column"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "flex-column-reverse"),
  /* @__PURE__ */ createTextVNode(" utility classes can be used to change the orientation of the flexbox container.")
], -1);
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("There are also responsive variations for "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "flex-direction"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-row")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-row-reverse")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-column")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-column-reverse")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-sm-row")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-sm-row-reverse")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-sm-column")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-sm-column-reverse")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-md-row")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-md-row-reverse")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-md-column")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-md-column-reverse")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-lg-row")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-lg-row-reverse")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-lg-column")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-lg-column-reverse")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-xl-row")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-xl-row-reverse")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-xl-column")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-xl-column-reverse")
  ])
], -1);
const _hoisted_18 = { id: "flex-justify" };
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "justify-content"),
  /* @__PURE__ */ createTextVNode(" flex setting can be changed using the flex justify classes. This by default will modify the flexbox items on the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "x-axis"),
  /* @__PURE__ */ createTextVNode(" but is reversed when using "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "flex-direction: column"),
  /* @__PURE__ */ createTextVNode(", modifying the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "y-axis"),
  /* @__PURE__ */ createTextVNode(". Choose from "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "start"),
  /* @__PURE__ */ createTextVNode(" (browser default), "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "end"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "center"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "space-between"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "space-around"),
  /* @__PURE__ */ createTextVNode(", or "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "space-evenly"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("There are also responsive variations for "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "justify-content"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".justify-start")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".justify-end")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".justify-center")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".justify-space-between")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".justify-space-around")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".justify-space-evenly")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".justify-sm-start")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".justify-sm-end")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".justify-sm-center")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".justify-sm-space-between")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".justify-sm-space-around")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".justify-sm-space-evenly")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".justify-md-start")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".justify-md-end")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".justify-md-center")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".justify-md-space-between")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".justify-md-space-around")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".justify-md-space-evenly")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".justify-lg-start")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".justify-lg-end")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".justify-lg-center")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".justify-lg-space-between")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".justify-lg-space-around")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".justify-lg-space-evenly")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".justify-xl-start")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".justify-xl-end")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".justify-xl-center")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".justify-xl-space-between")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".justify-xl-space-around")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".justify-xl-space-evenly")
  ])
], -1);
const _hoisted_22 = { id: "flex-align" };
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "align-items"),
  /* @__PURE__ */ createTextVNode(" flex setting can be changed using the flex align classes. This by default will modify the flexbox items on the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "y-axis"),
  /* @__PURE__ */ createTextVNode(" but is reversed when using "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "flex-direction: column"),
  /* @__PURE__ */ createTextVNode(", modifying the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "x-axis"),
  /* @__PURE__ */ createTextVNode(". Choose from "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "start"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "end"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "center"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "baseline"),
  /* @__PURE__ */ createTextVNode(", or "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "stretch"),
  /* @__PURE__ */ createTextVNode(" (browser default).")
], -1);
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("There are also responsive variations for "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "align-items"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-start")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-end")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-center")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-baseline")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-stretch")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-sm-start")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-sm-end")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-sm-center")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-sm-baseline")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-sm-stretch")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-md-start")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-md-end")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-md-center")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-md-baseline")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-md-stretch")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-lg-start")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-lg-end")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-lg-center")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-lg-baseline")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-lg-stretch")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-xl-start")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-xl-end")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-xl-center")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-xl-baseline")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-xl-stretch")
  ])
], -1);
const _hoisted_26 = { id: "flex-align-self" };
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "align-self"),
  /* @__PURE__ */ createTextVNode(" flex setting can be changed using the flex align-self classes. This by default will modify individual flexbox items across the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "y-axis"),
  /* @__PURE__ */ createTextVNode(" but is reversed when using "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "flex-direction: column"),
  /* @__PURE__ */ createTextVNode(", modifying the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "x-axis"),
  /* @__PURE__ */ createTextVNode(". Choose from "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "start"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "end"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "center"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "baseline"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "stretch"),
  /* @__PURE__ */ createTextVNode(", or "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "auto"),
  /* @__PURE__ */ createTextVNode(" (browser default, applies align-items property from flex container).")
], -1);
const _hoisted_28 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("There are also responsive variations for "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "align-self-items"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_29 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-self-start")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-self-end")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-self-center")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-self-baseline")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-self-auto")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-self-stretch")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-self-sm-start")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-self-sm-end")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-self-sm-center")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-self-sm-baseline")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-self-sm-auto")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-self-sm-stretch")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-self-md-start")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-self-md-end")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-self-md-center")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-self-md-baseline")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-self-md-auto")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-self-md-stretch")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-self-lg-start")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-self-lg-end")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-self-lg-center")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-self-lg-baseline")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-self-lg-auto")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-self-lg-stretch")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-self-xl-start")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-self-xl-end")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-self-xl-center")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-self-xl-baseline")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-self-xl-auto")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".align-self-xl-stretch")
  ])
], -1);
const _hoisted_30 = { id: "auto-margins" };
const _hoisted_31 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Using the margin helper classes in a flexbox container, you can control the positioning of flex items on the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "x-axis"),
  /* @__PURE__ */ createTextVNode(" or "),
  /* @__PURE__ */ createBaseVNode("strong", null, "y-axis"),
  /* @__PURE__ */ createTextVNode(" when using "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "flex-row"),
  /* @__PURE__ */ createTextVNode(" or "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "flex-column"),
  /* @__PURE__ */ createTextVNode(" respectively.")
], -1);
const _hoisted_32 = { id: "using-align-items" };
const _hoisted_33 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Mixing "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "flex-direction: column"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "align-items"),
  /* @__PURE__ */ createTextVNode(", you can utilize "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".mt-auto"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".mb-auto"),
  /* @__PURE__ */ createTextVNode(" helper classes to adjust flex item positioning.")
], -1);
const _hoisted_34 = { id: "flex-wrap" };
const _hoisted_35 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("By default "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".d-flex"),
  /* @__PURE__ */ createTextVNode(" does not provide any wrapping (behaves similarly to "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "flex-wrap: nowrap"),
  /* @__PURE__ */ createTextVNode("). This can be modified by applying flex-wrap helper classes in the format "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "flex-{condition}"),
  /* @__PURE__ */ createTextVNode(" where condition can be "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "nowrap"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "wrap"),
  /* @__PURE__ */ createTextVNode(", or "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "wrap-reverse"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_36 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-nowrap")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-wrap")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-wrap-reverse")
  ])
], -1);
const _hoisted_37 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("These helper classes can also be applied in the format "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "flex-{breakpoint}-{condition}"),
  /* @__PURE__ */ createTextVNode(" to create more responsive variations based on breakpoints. The following combinations are available:")
], -1);
const _hoisted_38 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-sm-nowrap")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-sm-wrap")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-sm-wrap-reverse")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-md-nowrap")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-md-wrap")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-md-wrap-reverse")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-lg-nowrap")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-lg-wrap")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-lg-wrap-reverse")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-xl-nowrap")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-xl-wrap")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".flex-xl-wrap-reverse")
  ])
], -1);
const _hoisted_39 = { id: "flex-order" };
const _hoisted_40 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can change the visual order of flex items with the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "order"),
  /* @__PURE__ */ createTextVNode(" utilities.")
], -1);
const _hoisted_41 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("There are also responsive variations for "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "order"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_42 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-first")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-0")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-1")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-2")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-3")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-4")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-5")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-6")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-7")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-8")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-9")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-10")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-11")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-12")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-last")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-sm-first")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-sm-0")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-sm-1")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-sm-2")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-sm-3")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-sm-4")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-sm-5")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-sm-6")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-sm-7")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-sm-8")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-sm-9")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-sm-10")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-sm-11")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-sm-12")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-sm-last")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-md-first")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-md-0")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-md-1")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-md-2")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-md-3")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-md-4")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-md-5")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-md-6")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-md-7")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-md-8")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-md-9")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-md-10")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-md-11")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-md-12")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-md-last")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-lg-first")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-lg-0")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-lg-1")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-lg-2")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-lg-3")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-lg-4")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-lg-5")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-lg-6")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-lg-7")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-lg-8")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-lg-9")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-lg-10")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-lg-11")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-lg-12")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-lg-last")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-xl-first")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-xl-0")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-xl-1")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-xl-2")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-xl-3")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-xl-4")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-xl-5")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-xl-6")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-xl-7")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-xl-8")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-xl-9")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-xl-10")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-xl-11")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-xl-12")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".order-xl-last")
  ])
], -1);
const _hoisted_43 = { id: "flex-align-content" };
const _hoisted_44 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "align-content"),
  /* @__PURE__ */ createTextVNode(" flex setting can be changed using the flex align-content classes. This by default will modify the wrapped flexbox content across the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "y-axis"),
  /* @__PURE__ */ createTextVNode(" but is reversed when using "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "flex-direction: column"),
  /* @__PURE__ */ createTextVNode(", modifying the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "x-axis"),
  /* @__PURE__ */ createTextVNode(". Choose from "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "start"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "end"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "center"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "space-between"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "space-around"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "space-evenly"),
  /* @__PURE__ */ createTextVNode(" or "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "stretch"),
  /* @__PURE__ */ createTextVNode(" (browser default).")
], -1);
const _hoisted_45 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("There are also responsive variations for "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "align-content"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_46 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "align-content-start")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "align-content-end")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "align-content-center")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "align-content-space-between")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "align-content-space-around")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "align-content-space-evenly")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "align-content-stretch")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "align-content-sm-start")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "align-content-sm-end")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "align-content-sm-center")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "align-content-sm-space-between")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "align-content-sm-space-around")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "align-content-sm-space-evenly")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "align-content-sm-stretch")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "align-content-md-start")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "align-content-md-end")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "align-content-md-center")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "align-content-md-space-between")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "align-content-md-space-around")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "align-content-md-space-evenly")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "align-content-md-stretch")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "align-content-lg-start")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "align-content-lg-end")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "align-content-lg-center")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "align-content-lg-space-between")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "align-content-lg-space-around")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "align-content-lg-space-evenly")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "align-content-lg-stretch")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "align-content-xl-start")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "align-content-xl-end")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "align-content-xl-center")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "align-content-xl-space-between")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "align-content-xl-space-around")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "align-content-xl-space-evenly")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "align-content-xl-stretch")
  ])
], -1);
const _hoisted_47 = { id: "flex-grow-and-shrink" };
const _hoisted_48 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Vuetify has helper classes for applying grow and shrink manually. These can be applied by adding the helper class in the format "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "flex-{condition}-{value}"),
  /* @__PURE__ */ createTextVNode(", where condition can be either "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "grow"),
  /* @__PURE__ */ createTextVNode(" or "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "shrink"),
  /* @__PURE__ */ createTextVNode(" and value can be either "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "0"),
  /* @__PURE__ */ createTextVNode(" or "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "1"),
  /* @__PURE__ */ createTextVNode(". The condition "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "grow"),
  /* @__PURE__ */ createTextVNode(" will permit an element to grow to fill available space, whereas "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "shrink"),
  /* @__PURE__ */ createTextVNode(" will permit an element to shrink down to only the space needs for its contents. However, this will only happen if the element must shrink to fit their container such as a container resize or being effected by a "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "flex-grow-1"),
  /* @__PURE__ */ createTextVNode(". The value "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "0"),
  /* @__PURE__ */ createTextVNode(" will prevent the condition from occurring whereas "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "1"),
  /* @__PURE__ */ createTextVNode(" will permit the condition. The following classes are available:")
], -1);
const _hoisted_49 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "flex-grow-0")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "flex-grow-1")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "flex-shrink-0")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "flex-shrink-1")
  ])
], -1);
const _hoisted_50 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("These helper classes can also be applied in the format "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "flex-{breakpoint}-{condition}-{state}"),
  /* @__PURE__ */ createTextVNode(" to create more responsive variations based on breakpoints. The following combinations are available:")
], -1);
const _hoisted_51 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "flex-sm-grow-0")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "flex-md-grow-0")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "flex-lg-grow-0")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "flex-xl-grow-0")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "flex-sm-grow-1")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "flex-md-grow-1")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "flex-lg-grow-1")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "flex-xl-grow-1")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "flex-sm-shrink-0")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "flex-md-shrink-0")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "flex-lg-shrink-0")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "flex-xl-shrink-0")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "flex-sm-shrink-1")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "flex-md-shrink-1")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "flex-lg-shrink-1")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "flex-xl-shrink-1")
  ])
], -1);
const frontmatter = { "meta": { "title": "Flex", "description": "Flex helper classes allow you to modify flexbox parents and children.", "keywords": "flex helper classes, flex classes, vuetify flex" }, "related": ["/styles/display/", "/components/grids/", "/styles/css-reset/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "flex",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "Flex", "description": "Flex helper classes allow you to modify flexbox parents and children.", "keywords": "flex helper classes, flex classes, vuetify flex" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "title": "Flex", "description": "Flex helper classes allow you to modify flexbox parents and children.", "keywords": "flex helper classes, flex classes, vuetify flex" }, "related": ["/styles/display/", "/components/grids/", "/styles/css-reset/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_alert = resolveComponent("alert");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#flex",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Flex")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_promoted_entry),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#enabling-flexbox",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Enabling flexbox")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_example, { file: "flex/flexbox" }),
                createVNode(_component_examples_example, { file: "flex/flexbox-inline" }),
                _hoisted_5,
                _hoisted_6,
                createBaseVNode("section", _hoisted_7, [
                  createVNode(_component_app_heading, {
                    href: "#caveats",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Caveats")
                    ]),
                    _: 1
                  }),
                  createVNode(_component_alert, { type: "info" }, {
                    default: withCtx(() => [
                      _hoisted_8
                    ]),
                    _: 1
                  })
                ])
              ]),
              createBaseVNode("section", _hoisted_9, [
                createVNode(_component_app_heading, {
                  href: "#flex-shorthand",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Flex shorthand")
                  ]),
                  _: 1
                }),
                _hoisted_10,
                createVNode(_component_examples_example, { file: "flex/flex-flex" }),
                _hoisted_11,
                _hoisted_12
              ]),
              createBaseVNode("section", _hoisted_13, [
                createVNode(_component_app_heading, {
                  href: "#flex-direction",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Flex direction")
                  ]),
                  _: 1
                }),
                _hoisted_14,
                createVNode(_component_examples_example, { file: "flex/flex-direction" }),
                _hoisted_15,
                createVNode(_component_examples_example, { file: "flex/flex-column" }),
                _hoisted_16,
                _hoisted_17
              ]),
              createBaseVNode("section", _hoisted_18, [
                createVNode(_component_app_heading, {
                  href: "#flex-justify",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Flex justify")
                  ]),
                  _: 1
                }),
                _hoisted_19,
                createVNode(_component_examples_example, { file: "flex/flex-justify" }),
                _hoisted_20,
                _hoisted_21
              ]),
              createBaseVNode("section", _hoisted_22, [
                createVNode(_component_app_heading, {
                  href: "#flex-align",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Flex align")
                  ]),
                  _: 1
                }),
                _hoisted_23,
                createVNode(_component_examples_example, { file: "flex/flex-align" }),
                _hoisted_24,
                _hoisted_25
              ]),
              createBaseVNode("section", _hoisted_26, [
                createVNode(_component_app_heading, {
                  href: "#flex-align-self",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Flex align self")
                  ]),
                  _: 1
                }),
                _hoisted_27,
                createVNode(_component_examples_example, { file: "flex/flex-align-self" }),
                _hoisted_28,
                _hoisted_29
              ]),
              createBaseVNode("section", _hoisted_30, [
                createVNode(_component_app_heading, {
                  href: "#auto-margins",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Auto margins")
                  ]),
                  _: 1
                }),
                _hoisted_31,
                createVNode(_component_examples_example, { file: "flex/margins" }),
                createBaseVNode("section", _hoisted_32, [
                  createVNode(_component_app_heading, {
                    href: "#using-align-items",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Using align-items")
                    ]),
                    _: 1
                  }),
                  _hoisted_33,
                  createVNode(_component_examples_example, { file: "flex/margins-align-items" })
                ])
              ]),
              createBaseVNode("section", _hoisted_34, [
                createVNode(_component_app_heading, {
                  href: "#flex-wrap",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Flex wrap")
                  ]),
                  _: 1
                }),
                _hoisted_35,
                _hoisted_36,
                createVNode(_component_examples_example, { file: "flex/flex-nowrap" }),
                createVNode(_component_examples_example, { file: "flex/flex-wrap" }),
                createVNode(_component_examples_example, { file: "flex/flex-wrap-reverse" }),
                _hoisted_37,
                _hoisted_38
              ]),
              createBaseVNode("section", _hoisted_39, [
                createVNode(_component_app_heading, {
                  href: "#flex-order",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Flex order")
                  ]),
                  _: 1
                }),
                _hoisted_40,
                createVNode(_component_examples_example, { file: "flex/flex-order" }),
                _hoisted_41,
                _hoisted_42
              ]),
              createBaseVNode("section", _hoisted_43, [
                createVNode(_component_app_heading, {
                  href: "#flex-align-content",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Flex align content")
                  ]),
                  _: 1
                }),
                _hoisted_44,
                createVNode(_component_examples_example, { file: "flex/flex-align-content-start" }),
                createVNode(_component_examples_example, { file: "flex/flex-align-content-end" }),
                createVNode(_component_examples_example, { file: "flex/flex-align-content-center" }),
                createVNode(_component_examples_example, { file: "flex/flex-align-content-between" }),
                createVNode(_component_examples_example, { file: "flex/flex-align-content-around" }),
                _hoisted_45,
                _hoisted_46
              ]),
              createBaseVNode("section", _hoisted_47, [
                createVNode(_component_app_heading, {
                  href: "#flex-grow-and-shrink",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Flex grow and shrink")
                  ]),
                  _: 1
                }),
                _hoisted_48,
                _hoisted_49,
                createVNode(_component_examples_example, { file: "flex/grow-shrink" }),
                _hoisted_50,
                _hoisted_51
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
