import { y as _export_sfc, o as openBlock, l as createElementBlock, e as createBaseVNode } from "./index-DGybHjCP.js";
const _sfc_main$1 = {};
const _hoisted_1$1 = /* @__PURE__ */ createBaseVNode("div", { class: "float-left" }, " Float left on all viewport sizes ", -1);
const _hoisted_2$1 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_3$1 = /* @__PURE__ */ createBaseVNode("div", { class: "float-right" }, " Float right on all viewport sizes ", -1);
const _hoisted_4$1 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_5$1 = /* @__PURE__ */ createBaseVNode("div", { class: "float-none" }, " Don't float on all viewport sizes ", -1);
const _hoisted_6$1 = [
  _hoisted_1$1,
  _hoisted_2$1,
  _hoisted_3$1,
  _hoisted_4$1,
  _hoisted_5$1
];
function _sfc_render$1(_ctx, _cache) {
  return openBlock(), createElementBlock("div", null, _hoisted_6$1);
}
const __0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["render", _sfc_render$1]]);
const __0_raw = `<template>
  <div>
    <div class="float-left">
      Float left on all viewport sizes
    </div>
    <br>
    <div class="float-right">
      Float right on all viewport sizes
    </div>
    <br>
    <div class="float-none">
      Don't float on all viewport sizes
    </div>
  </div>
</template>
`;
const _sfc_main = {};
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("div", { class: "float-sm-left" }, " Float left on viewports sized SM (small) or wider ", -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("div", { class: "float-md-left" }, " Float left on viewports sized MD (medium) or wider ", -1);
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("div", { class: "float-lg-left" }, " Float left on viewports sized LG (large) or wider ", -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("div", { class: "float-xl-left" }, " Float left on viewports sized XL (extra-large) or wider ", -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_9 = [
  _hoisted_1,
  _hoisted_2,
  _hoisted_3,
  _hoisted_4,
  _hoisted_5,
  _hoisted_6,
  _hoisted_7,
  _hoisted_8
];
function _sfc_render(_ctx, _cache) {
  return openBlock(), createElementBlock("div", null, _hoisted_9);
}
const __1 = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
const __1_raw = '<template>\n  <div>\n    <div class="float-sm-left">\n      Float left on viewports sized SM (small) or wider\n    </div>\n    <br>\n    <div class="float-md-left">\n      Float left on viewports sized MD (medium) or wider\n    </div>\n    <br>\n    <div class="float-lg-left">\n      Float left on viewports sized LG (large) or wider\n    </div>\n    <br>\n    <div class="float-xl-left">\n      Float left on viewports sized XL (extra-large) or wider\n    </div>\n    <br>\n  </div>\n</template>\n';
const float = {
  "classes": {
    component: __0,
    source: __0_raw
  },
  "responsive": {
    component: __1,
    source: __1_raw
  }
};
export {
  float as default
};
