import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "float" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "Applies a custom float across any breakpoint with responsive float utilities.", -1);
const _hoisted_3 = { id: "overview" };
const _hoisted_4 = { id: "classes" };
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("p", null, "Easily toggle a float with a class:", -1);
const _hoisted_6 = { id: "responsive" };
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("p", null, "Floats can also be applied on a per breakpoint (viewport) basis.", -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("p", null, "Here is a list of all the available support classes:", -1);
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".float-left")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".float-right")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".float-start")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".float-end")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".float-none")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".float-sm-left")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".float-sm-right")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".float-sm-start")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".float-sm-end")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".float-sm-none")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".float-md-left")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".float-md-right")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".float-md-start")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".float-md-end")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".float-md-none")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".float-lg-left")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".float-lg-right")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".float-lg-start")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".float-lg-end")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".float-lg-none")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".float-xl-left")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".float-xl-right")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".float-xl-start")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".float-xl-end")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, ".float-xl-none")
  ])
], -1);
const frontmatter = { "meta": { "title": "Float", "description": "Float helper classes allow you to control the float property of an element based upon the viewport size.", "keywords": "float helper classes, float classes, vuetify float" }, "related": ["/styles/text-and-typography/", "/styles/transitions/", "/styles/content/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "float",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "Float", "description": "Float helper classes allow you to control the float property of an element based upon the viewport size.", "keywords": "float helper classes, float classes, vuetify float" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "title": "Float", "description": "Float helper classes allow you to control the float property of an element based upon the viewport size.", "keywords": "float helper classes, float classes, vuetify float" }, "related": ["/styles/text-and-typography/", "/styles/transitions/", "/styles/content/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_features_breakpoints_table = resolveComponent("features-breakpoints-table");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#float",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Float")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_promoted_entry),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#overview",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Overview")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("Float utility classes apply floating based upon the current viewport size using the "),
                  createVNode(_component_app_link, { href: "https://developer.mozilla.org/en-US/docs/Web/CSS/float" }, {
                    default: withCtx(() => [
                      createTextVNode("CSS float property")
                    ]),
                    _: 1
                  }),
                  createTextVNode(".")
                ]),
                createVNode(_component_features_breakpoints_table)
              ]),
              createBaseVNode("section", _hoisted_4, [
                createVNode(_component_app_heading, {
                  href: "#classes",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Classes")
                  ]),
                  _: 1
                }),
                _hoisted_5,
                createVNode(_component_examples_example, { file: "float/classes" })
              ]),
              createBaseVNode("section", _hoisted_6, [
                createVNode(_component_app_heading, {
                  href: "#responsive",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Responsive")
                  ]),
                  _: 1
                }),
                _hoisted_7,
                createVNode(_component_examples_example, { file: "float/responsive" }),
                _hoisted_8,
                _hoisted_9
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
