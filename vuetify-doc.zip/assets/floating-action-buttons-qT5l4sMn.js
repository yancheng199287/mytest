import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "floating-action-buttons" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-fab"),
  /* @__PURE__ */ createTextVNode(" component can be used as a floating action button. This provides an application with a main point of action.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Floating action buttons can be attached to material to signify a promoted action in your application. The default size will be used in most cases, whereas the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "small"),
  /* @__PURE__ */ createTextVNode(" variant can be used to maintain continuity with similar sized elements.")
], -1);
const _hoisted_5 = { id: "api" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_8 = { id: "examples" };
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The following are a collection of examples that demonstrate more advanced and real world use of the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-fab"),
  /* @__PURE__ */ createTextVNode(" component.")
], -1);
const _hoisted_10 = { id: "display-animation" };
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("When displaying for the first time, a floating action button should animate onto the screen. Here we use the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-fab-transition"),
  /* @__PURE__ */ createTextVNode(" with v-show. You can also use any custom transition provided by Vuetify or your own.")
], -1);
const _hoisted_12 = { id: "lateral-screens" };
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("When changing the default action of your button, it is recommended that you display a transition to signify a change. We do this by binding the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "key"),
  /* @__PURE__ */ createTextVNode(" prop to a piece of data that can properly signal a change in action to the Vue transition system.")
], -1);
const _hoisted_14 = { id: "small-variant" };
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("p", null, "For better visual appeal, we use a small button to match our list avatars.", -1);
const frontmatter = { "emphasized": true, "meta": { "nav": "Floating Action Buttons", "title": "FAB component", "description": "The floating action button (or FAB) component is a promoted action that is elevated above the UI or attached to an element such as a card.", "keywords": "floating action button, fab, vuetify fab component, vue fab component" }, "related": ["/components/buttons/", "/components/icons/", "/styles/transitions/"], "features": { "report": true, "label": "C: VFab", "github": "/components/VFab/", "spec": "https://m2.material.io/components/buttons-floating-action-button" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "floating-action-buttons",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Floating Action Buttons", "title": "FAB component", "description": "The floating action button (or FAB) component is a promoted action that is elevated above the UI or attached to an element such as a card.", "keywords": "floating action button, fab, vuetify fab component, vue fab component" } };
    useHead(head);
    __expose({ frontmatter: { "emphasized": true, "meta": { "nav": "Floating Action Buttons", "title": "FAB component", "description": "The floating action button (or FAB) component is a promoted action that is elevated above the UI or attached to an element such as a card.", "keywords": "floating action button, fab, vuetify fab component, vue fab component" }, "related": ["/components/buttons/", "/components/icons/", "/styles/transitions/"], "features": { "report": true, "label": "C: VFab", "github": "/components/VFab/", "spec": "https://m2.material.io/components/buttons-floating-action-button" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_app_link = resolveComponent("app-link");
      const _component_alert = resolveComponent("alert");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#floating-action-buttons",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Floating Action Buttons")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_alert, { type: "success" }, {
                default: withCtx(() => [
                  createBaseVNode("p", null, [
                    createTextVNode("This feature was introduced in "),
                    createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v3.6.0" }, {
                      default: withCtx(() => [
                        createTextVNode("v3.6.0")
                      ]),
                      _: 1
                    })
                  ])
                ]),
                _: 1
              }),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_usage, { name: "v-fab" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_6,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-fab/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-fab")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_8, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                _hoisted_9,
                createBaseVNode("section", _hoisted_10, [
                  createVNode(_component_app_heading, {
                    href: "#display-animation",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Display animation")
                    ]),
                    _: 1
                  }),
                  _hoisted_11,
                  createVNode(_component_examples_example, { file: "v-fab/misc-display-animation" })
                ]),
                createBaseVNode("section", _hoisted_12, [
                  createVNode(_component_app_heading, {
                    href: "#lateral-screens",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Lateral screens")
                    ]),
                    _: 1
                  }),
                  _hoisted_13,
                  createVNode(_component_examples_example, { file: "v-fab/misc-lateral-screens" })
                ]),
                createBaseVNode("section", _hoisted_14, [
                  createVNode(_component_app_heading, {
                    href: "#small-variant",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Small variant")
                    ]),
                    _: 1
                  }),
                  _hoisted_15,
                  createVNode(_component_examples_example, { file: "v-fab/misc-small" })
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
