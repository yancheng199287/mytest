import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "forms" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "Vuetify offers a simple built-in form validation system based on functions as rules, making it easy for developers to get set up quickly.", -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-form"),
  /* @__PURE__ */ createTextVNode(" component makes it easy to add validation to form inputs. All input components have a "),
  /* @__PURE__ */ createBaseVNode("strong", null, "rules"),
  /* @__PURE__ */ createTextVNode(" prop that can be used to specify conditions in which the input is either "),
  /* @__PURE__ */ createBaseVNode("em", null, "valid"),
  /* @__PURE__ */ createTextVNode(" or "),
  /* @__PURE__ */ createBaseVNode("em", null, "invalid"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "TIP:")
], -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Whenever the value of an input is changed, each rule receives a new value and is re-evaluated. If a rule returns "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "false"),
  /* @__PURE__ */ createTextVNode(" or a "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "string"),
  /* @__PURE__ */ createTextVNode(", validation has failed and the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "string"),
  /* @__PURE__ */ createTextVNode(" value is presented as an error message.")
], -1);
const _hoisted_7 = { id: "api" };
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_10 = { id: "rules" };
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Rules allow you to apply custom validation on all form components. These are validated sequentially, and components display a "),
  /* @__PURE__ */ createBaseVNode("em", null, "maximum"),
  /* @__PURE__ */ createTextVNode(" of 1 error at a time; so make sure you order your rules accordingly.")
], -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("p", null, "The most basic of rules is a simple function that checks if an input has a value or not; i.e. it makes it a required input.", -1);
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("However, you can make rules as complicated as needed, even allowing for asynchronous input validation. In the example below, the input is checked against a fake API service that takes some time to respond. Wait for the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "submit"),
  /* @__PURE__ */ createTextVNode(" event promise to resolve and see the validation in action.")
], -1);
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The submit event is a combination of a native "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "SubmitEvent"),
  /* @__PURE__ */ createTextVNode(" with a promise, so it can be "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "await"),
  /* @__PURE__ */ createTextVNode("ed or used with "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".then()"),
  /* @__PURE__ */ createTextVNode(" to get the result of the validation. "),
  /* @__PURE__ */ createBaseVNode("br"),
  /* @__PURE__ */ createTextVNode(" This also demonstrates the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "validate-on"),
  /* @__PURE__ */ createTextVNode(" prop, which tells the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-form"),
  /* @__PURE__ */ createTextVNode(" component when validation should happen. Here we set it to "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "'submit lazy'"),
  /* @__PURE__ */ createTextVNode(" so that we only call the API service when the button is clicked.")
], -1);
const _hoisted_15 = { id: "validation-state" };
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("By default, all inputs run their validation rules when mounted but do not display errors to the user. "),
  /* @__PURE__ */ createBaseVNode("br"),
  /* @__PURE__ */ createTextVNode(" When rules run is controlled with the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "validate-on"),
  /* @__PURE__ */ createTextVNode(" prop which accepts a string containing "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "input"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "blur"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "submit"),
  /* @__PURE__ */ createTextVNode(", or "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "lazy"),
  /* @__PURE__ */ createTextVNode(". "),
  /* @__PURE__ */ createBaseVNode("br"),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "input"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "blur"),
  /* @__PURE__ */ createTextVNode(", and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "submit"),
  /* @__PURE__ */ createTextVNode(" set when a validation error can first be displayed to the user, while "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "lazy"),
  /* @__PURE__ */ createTextVNode(" disables validation on mount (useful for async rules). "),
  /* @__PURE__ */ createBaseVNode("br"),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "lazy"),
  /* @__PURE__ */ createTextVNode(" can be combined with other options, and implies "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "input"),
  /* @__PURE__ */ createTextVNode(" on its own.")
], -1);
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "validate-on=")
    ]),
    /* @__PURE__ */ createBaseVNode("th", { style: { "text-align": "center" } }, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, '"input"')
    ]),
    /* @__PURE__ */ createBaseVNode("th", { style: { "text-align": "center" } }, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, '"blur"')
    ]),
    /* @__PURE__ */ createBaseVNode("th", { style: { "text-align": "center" } }, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, '"submit"')
    ]),
    /* @__PURE__ */ createBaseVNode("th", { style: { "text-align": "center" } }, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, '"lazy"')
    ])
  ])
], -1);
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("tbody", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "On mount"),
    /* @__PURE__ */ createBaseVNode("td", { style: { "text-align": "center" } }, "✅"),
    /* @__PURE__ */ createBaseVNode("td", { style: { "text-align": "center" } }, "✅"),
    /* @__PURE__ */ createBaseVNode("td", { style: { "text-align": "center" } }, "✅"),
    /* @__PURE__ */ createBaseVNode("td", { style: { "text-align": "center" } }, "❌")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "On input"),
    /* @__PURE__ */ createBaseVNode("td", { style: { "text-align": "center" } }, "✅"),
    /* @__PURE__ */ createBaseVNode("td", { style: { "text-align": "center" } }, "❌"),
    /* @__PURE__ */ createBaseVNode("td", { style: { "text-align": "center" } }, "❌"),
    /* @__PURE__ */ createBaseVNode("td", { style: { "text-align": "center" } }, "*")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "On blur"),
    /* @__PURE__ */ createBaseVNode("td", { style: { "text-align": "center" } }, "✅"),
    /* @__PURE__ */ createBaseVNode("td", { style: { "text-align": "center" } }, "✅"),
    /* @__PURE__ */ createBaseVNode("td", { style: { "text-align": "center" } }, "❌"),
    /* @__PURE__ */ createBaseVNode("td", { style: { "text-align": "center" } }, "*")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "On submit"),
    /* @__PURE__ */ createBaseVNode("td", { style: { "text-align": "center" } }, "✅"),
    /* @__PURE__ */ createBaseVNode("td", { style: { "text-align": "center" } }, "✅"),
    /* @__PURE__ */ createBaseVNode("td", { style: { "text-align": "center" } }, "✅"),
    /* @__PURE__ */ createBaseVNode("td", { style: { "text-align": "center" } }, "*")
  ])
], -1);
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("p", { class: "text-caption" }, "* Uses the behavior of whatever it's combined with.", -1);
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The form’s current validation status is accessed using "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-model"),
  /* @__PURE__ */ createTextVNode(" or the submit event. It can be in one of three states:")
], -1);
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "true"),
    /* @__PURE__ */ createTextVNode(": All inputs with validation rules have been successfully validated.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "false"),
    /* @__PURE__ */ createTextVNode(": At least one input has failed validation either by interaction or manual validation.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "null"),
    /* @__PURE__ */ createTextVNode(": At least one input has failed validation without interaction or has not been validated yet due to "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "lazy"),
    /* @__PURE__ */ createTextVNode(" validation.")
  ])
], -1);
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("This allows you to either check for any validation failure with "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "!valid"),
  /* @__PURE__ */ createTextVNode(", or only errors that are displayed to the user with "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code text-no-wrap" }, "valid === false"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_23 = { id: "examples" };
const _hoisted_24 = { id: "props" };
const _hoisted_25 = { id: "disabled" };
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can easily disable all input components in a "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-form"),
  /* @__PURE__ */ createTextVNode(" by setting the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "disabled"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_27 = { id: "fast-fail" };
const _hoisted_28 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("When the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "fast-fail"),
  /* @__PURE__ */ createTextVNode(" prop is set, validation will short-circuit after the first invalid input is found. This can be useful if some of your rules are computationally heavy and can take a long time. In this example, notice how when the submit button is clicked, the second input does not show validation errors even though it does not satisfy the rules.")
], -1);
const _hoisted_29 = { id: "misc" };
const _hoisted_30 = { id: "exposed-properties" };
const _hoisted_31 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-form"),
  /* @__PURE__ */ createTextVNode(" component has a number of exposed properties that can be accessed by setting a "),
  /* @__PURE__ */ createBaseVNode("strong", null, "ref"),
  /* @__PURE__ */ createTextVNode(" on the component. A ref allows us to access internal methods on a component. You can find all of them on the API page, but some of the more commonly used ones are "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "validate()"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "reset()"),
  /* @__PURE__ */ createTextVNode(", and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "resetValidation()"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_32 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The difference between "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "reset()"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "resetValidation()"),
  /* @__PURE__ */ createTextVNode(" is that the former resets both input values and validation state, while the latter only resets validation state.")
], -1);
const _hoisted_33 = { id: "vee-validate" };
const _hoisted_34 = /* @__PURE__ */ createBaseVNode("strong", null, "vee-validate", -1);
const _hoisted_35 = { id: "vuelidate" };
const _hoisted_36 = /* @__PURE__ */ createBaseVNode("strong", null, "vuelidate", -1);
const frontmatter = { "meta": { "nav": "Forms", "title": "Form component", "description": "The form component provides a wrapper that makes it easy to process and control validation states of input components.", "keywords": "forms, vuetify form component, vue form component, form validation" }, "related": ["/components/selects/", "/components/switches/", "/components/text-fields/"], "features": { "label": "C: VForm", "report": true, "github": "/components/VForm/" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "forms",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Forms", "title": "Form component", "description": "The form component provides a wrapper that makes it easy to process and control validation states of input components.", "keywords": "forms, vuetify form component, vue form component, form validation" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Forms", "title": "Form component", "description": "The form component provides a wrapper that makes it easy to process and control validation states of input components.", "keywords": "forms, vuetify form component, vue form component, form validation" }, "related": ["/components/selects/", "/components/switches/", "/components/text-fields/"], "features": { "label": "C: VForm", "report": true, "github": "/components/VForm/" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_app_link = resolveComponent("app-link");
      const _component_alert = resolveComponent("alert");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#forms",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Forms")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_alert, { type: "tip" }, {
                  default: withCtx(() => [
                    _hoisted_5,
                    createBaseVNode("p", null, [
                      createTextVNode("If you prefer using a 3rd party validation plugin, we provide "),
                      createVNode(_component_app_link, { href: "#vee-validate" }, {
                        default: withCtx(() => [
                          createTextVNode("examples")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" further down the page for integrating both "),
                      createVNode(_component_app_link, { href: "https://github.com/baianat/Vee-validate" }, {
                        default: withCtx(() => [
                          createTextVNode("Vee-validate")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" and "),
                      createVNode(_component_app_link, { href: "https://github.com/vuelidate/vuelidate" }, {
                        default: withCtx(() => [
                          createTextVNode("vuelidate")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" validation libraries.")
                    ])
                  ]),
                  _: 1
                }),
                _hoisted_6,
                createVNode(_component_examples_example, { file: "v-form/usage" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_7, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_8,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-form/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-form")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_9
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_10, [
                createVNode(_component_app_heading, {
                  href: "#rules",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Rules")
                  ]),
                  _: 1
                }),
                _hoisted_11,
                _hoisted_12,
                createVNode(_component_examples_example, { file: "v-form/rules-required" }),
                _hoisted_13,
                createVNode(_component_examples_example, { file: "v-form/rules-async" }),
                _hoisted_14
              ]),
              createBaseVNode("section", _hoisted_15, [
                createVNode(_component_app_heading, {
                  href: "#validation-state",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Validation state")
                  ]),
                  _: 1
                }),
                _hoisted_16,
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_17,
                    _hoisted_18
                  ]),
                  _: 1
                }),
                _hoisted_19,
                _hoisted_20,
                _hoisted_21,
                _hoisted_22
              ]),
              createBaseVNode("section", _hoisted_23, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_24, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_25, [
                    createVNode(_component_app_heading, {
                      href: "#disabled",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Disabled")
                      ]),
                      _: 1
                    }),
                    _hoisted_26,
                    createVNode(_component_examples_example, { file: "v-form/prop-disabled" })
                  ]),
                  createBaseVNode("section", _hoisted_27, [
                    createVNode(_component_app_heading, {
                      href: "#fast-fail",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Fast fail")
                      ]),
                      _: 1
                    }),
                    _hoisted_28,
                    createVNode(_component_examples_example, { file: "v-form/prop-fast-fail" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_29, [
                  createVNode(_component_app_heading, {
                    href: "#misc",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Misc")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_30, [
                    createVNode(_component_app_heading, {
                      href: "#exposed-properties",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Exposed properties")
                      ]),
                      _: 1
                    }),
                    _hoisted_31,
                    _hoisted_32,
                    createVNode(_component_examples_example, { file: "v-form/misc-exposed" })
                  ]),
                  createBaseVNode("section", _hoisted_33, [
                    createVNode(_component_app_heading, {
                      href: "#vee-validate",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Vee-validate")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      _hoisted_34,
                      createTextVNode(" documentation can be found "),
                      createVNode(_component_app_link, { href: "https://vee-validate.logaretm.com/v4/" }, {
                        default: withCtx(() => [
                          createTextVNode("here")
                        ]),
                        _: 1
                      }),
                      createTextVNode(".")
                    ]),
                    createVNode(_component_examples_example, { file: "v-form/misc-vee-validate" })
                  ]),
                  createBaseVNode("section", _hoisted_35, [
                    createVNode(_component_app_heading, {
                      href: "#vuelidate",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Vuelidate")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      _hoisted_36,
                      createTextVNode(" documentation can be found "),
                      createVNode(_component_app_link, { href: "https://vuelidate-next.netlify.app/" }, {
                        default: withCtx(() => [
                          createTextVNode("here")
                        ]),
                        _: 1
                      }),
                      createTextVNode(".")
                    ]),
                    createVNode(_component_examples_example, { file: "v-form/misc-vuelidate" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
