import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "frequently-asked-questions" };
const _hoisted_2 = { id: "questions" };
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("p", null, "The following responses are a collection of common questions asked by the Vuetify community.", -1);
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("li", { id: "what-is-vuetify" }, [
  /* @__PURE__ */ createBaseVNode("p", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "What is Vuetify?")
  ]),
  /* @__PURE__ */ createBaseVNode("p", null, "Vuetify is a Vue.js framework that helps to create beautiful and responsive user interfaces. It includes a wide variety of customizable and reusable components for building modern applications.")
], -1);
const _hoisted_5 = { id: "does-vuetify-provide-support" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Does Vuetify provide support?")
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("li", { id: "what-is-the-difference-between-vuetify-and-vue" }, [
  /* @__PURE__ */ createBaseVNode("p", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "What is the difference between Vuetify and Vue?")
  ]),
  /* @__PURE__ */ createBaseVNode("p", null, "Vuetify is a framework that is built on top of Vue.js. It is a collection of components that can be used to build applications. Vue.js is a JavaScript framework that is used to build user interfaces.")
], -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("li", { id: "what-versions-of-vuejs-are-compatible-with-vuetify" }, [
  /* @__PURE__ */ createBaseVNode("p", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "What versions of Vue.js are compatible with Vuetify?")
  ]),
  /* @__PURE__ */ createBaseVNode("p", null, "Vuetify is compatible with Vue.js 3.0.0 and above.")
], -1);
const _hoisted_9 = { id: "can-i-use-vuetify-with-other-css-frameworks" };
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Can I use Vuetify with other CSS frameworks?")
], -1);
const _hoisted_11 = { id: "can-i-customize-the-styling-of-vuetify-components" };
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Can I customize the styling of Vuetify components?")
], -1);
const _hoisted_13 = { id: "where-can-i-get-help-with-vuetify" };
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Where can I get help with Vuetify?")
], -1);
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("p", null, "If you need help with an issue, please use one of our help channels:", -1);
const _hoisted_16 = { id: "can-i-contribute-to-vuetify" };
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Can I contribute to Vuetify?")
], -1);
const _hoisted_18 = { id: "can-i-use-vuetify-with-server-side-rendering" };
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Can I use Vuetify with server-side rendering?")
], -1);
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Yes, Vuetify supports server-side rendering. Set the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "ssr"),
  /* @__PURE__ */ createTextVNode(" property to "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "true"),
  /* @__PURE__ */ createTextVNode(" in your "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "vuetify"),
  /* @__PURE__ */ createTextVNode(" configuration object.")
], -1);
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-js" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/plugins/vuetify.js",
    class: "language-js"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" createVuetify "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify'"),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "export"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "default"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "createVuetify"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "ssr"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "true"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_22 = { id: "is-there-still-support-for-ie11-in-vuetify-3" };
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Is there still support for IE11 in Vuetify 3?")
], -1);
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("li", { id: "is-there-support-for-nuxt-3" }, [
  /* @__PURE__ */ createBaseVNode("p", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "Is there support for Nuxt 3?")
  ]),
  /* @__PURE__ */ createBaseVNode("p", null, "Yes, Vuetify 3 is compatible with Nuxt 3 but does not currently have a community Nuxt module.")
], -1);
const _hoisted_25 = { id: "what-is-vuetify-labs" };
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "What is Vuetify Labs?")
], -1);
const _hoisted_27 = { id: "does-vuetify-have-nightly-builds" };
const _hoisted_28 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Does Vuetify have Nightly Builds?")
], -1);
const _hoisted_29 = { id: "i-found-a-bug-what-should-i-do" };
const _hoisted_30 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "I found a bug, what should I do?")
], -1);
const _hoisted_31 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, [
    /* @__PURE__ */ createTextVNode("Why did Vuetify 3 change "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "value"),
    /* @__PURE__ */ createTextVNode(" to "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "model-value"),
    /* @__PURE__ */ createTextVNode("?")
  ])
], -1);
const _hoisted_32 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "value", -1);
const _hoisted_33 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-model", -1);
const _hoisted_34 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("p", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, [
      /* @__PURE__ */ createTextVNode("Is Vuetify 3 compatible with "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "@vue/compat"),
      /* @__PURE__ */ createTextVNode("?")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("p", null, "No. If this changes in the future, we will update this FAQ and make a public notification.")
], -1);
const frontmatter = { "meta": { "title": "Frequently asked questions", "description": "Stuck on a problem? Check out the most frequently asked questions by the Vuetify community.", "keywords": "frequently asked questions, faq" }, "related": ["/introduction/why-vuetify/", "/getting-started/contributing/", "/getting-started/installation/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "frequently-asked-questions",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "Frequently asked questions", "description": "Stuck on a problem? Check out the most frequently asked questions by the Vuetify community.", "keywords": "frequently asked questions, faq" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "title": "Frequently asked questions", "description": "Stuck on a problem? Check out the most frequently asked questions by the Vuetify community.", "keywords": "frequently asked questions, faq" }, "related": ["/introduction/why-vuetify/", "/getting-started/contributing/", "/getting-started/installation/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_app_link = resolveComponent("app-link");
      const _component_page_features = resolveComponent("page-features");
      const _component_vo_promotions_card_highlight = resolveComponent("vo-promotions-card-highlight");
      const _component_app_markup = resolveComponent("app-markup");
      const _component_promoted_promoted = resolveComponent("promoted-promoted");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#frequently-asked-questions",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Frequently asked questions")
                ]),
                _: 1
              }),
              createBaseVNode("p", null, [
                createTextVNode("Stuck on a particular problem? Check some of these common gotchas before creating a ticket. If you still cannot find what you are looking for, you can submit an "),
                createVNode(_component_app_link, { href: "https://issues.vuetifyjs.com/" }, {
                  default: withCtx(() => [
                    createTextVNode("issue")
                  ]),
                  _: 1
                }),
                createTextVNode(" on GitHub or ask in our "),
                createVNode(_component_app_link, { href: "https://community.vuetifyjs.com/" }, {
                  default: withCtx(() => [
                    createTextVNode("community")
                  ]),
                  _: 1
                }),
                createTextVNode(".")
              ]),
              createVNode(_component_page_features),
              createVNode(_component_vo_promotions_card_highlight, { slug: "vuetify-discord-subscriber-help" }),
              createBaseVNode("section", _hoisted_2, [
                createVNode(_component_app_heading, {
                  href: "#questions",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Questions")
                  ]),
                  _: 1
                }),
                _hoisted_3,
                createBaseVNode("ul", null, [
                  _hoisted_4,
                  createBaseVNode("li", _hoisted_5, [
                    _hoisted_6,
                    createBaseVNode("p", null, [
                      createTextVNode("Vuetify is a free to use Open Source project released under the "),
                      createVNode(_component_app_link, { href: "http://opensource.org/licenses/MIT" }, {
                        default: withCtx(() => [
                          createTextVNode("MIT")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" license. There are multiple ways to receive support for Vuetify:")
                    ]),
                    createBaseVNode("ul", null, [
                      createBaseVNode("li", null, [
                        createTextVNode("Join our "),
                        createVNode(_component_app_link, { href: "https://community.vuetifyjs.com/" }, {
                          default: withCtx(() => [
                            createTextVNode("Discord Community")
                          ]),
                          _: 1
                        }),
                        createTextVNode(" - (Free/Paid)")
                      ]),
                      createBaseVNode("li", null, [
                        createTextVNode("Ask a question on "),
                        createVNode(_component_app_link, { href: "https://discussions.vuetifyjs.com/" }, {
                          default: withCtx(() => [
                            createTextVNode("GitHub Discussions")
                          ]),
                          _: 1
                        }),
                        createTextVNode(" - (Free)")
                      ]),
                      createBaseVNode("li", null, [
                        createTextVNode("Get "),
                        createVNode(_component_app_link, { href: "/introduction/enterprise-support/" }, {
                          default: withCtx(() => [
                            createTextVNode("Direct Support")
                          ]),
                          _: 1
                        }),
                        createTextVNode(" from Vuetify - (Paid)")
                      ])
                    ])
                  ]),
                  _hoisted_7,
                  _hoisted_8,
                  createBaseVNode("li", _hoisted_9, [
                    _hoisted_10,
                    createBaseVNode("p", null, [
                      createTextVNode("Yes, you can use Vuetify with other CSS frameworks, but it is typically not recommended. If you are integrating Vuetify into an existing application that is using another CSS framework, you may want to disable the default color and utility generation. See the "),
                      createVNode(_component_app_link, { href: "/features/sass-variables/" }, {
                        default: withCtx(() => [
                          createTextVNode("SASS Variables")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" page for more information.")
                    ])
                  ]),
                  createBaseVNode("li", _hoisted_11, [
                    _hoisted_12,
                    createBaseVNode("p", null, [
                      createTextVNode("Yes, you can customize the styling of Vuetify components using the "),
                      createVNode(_component_app_link, { href: "/features/global-configuration/" }, {
                        default: withCtx(() => [
                          createTextVNode("Global configuration")
                        ]),
                        _: 1
                      }),
                      createTextVNode(". Vuetify also provides "),
                      createVNode(_component_app_link, { href: "/features/sass-variables/" }, {
                        default: withCtx(() => [
                          createTextVNode("SASS variables")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" that can be overridden to change the look and feel of the components.")
                    ])
                  ]),
                  createBaseVNode("li", _hoisted_13, [
                    _hoisted_14,
                    _hoisted_15,
                    createBaseVNode("ul", null, [
                      createBaseVNode("li", null, [
                        createVNode(_component_app_link, { href: "/introduction/enterprise-support/" }, {
                          default: withCtx(() => [
                            createTextVNode("Vuetify Enterprise Support")
                          ]),
                          _: 1
                        })
                      ]),
                      createBaseVNode("li", null, [
                        createVNode(_component_app_link, { href: "https://community.vuetifyjs.com/" }, {
                          default: withCtx(() => [
                            createTextVNode("Discord Community")
                          ]),
                          _: 1
                        })
                      ]),
                      createBaseVNode("li", null, [
                        createVNode(_component_app_link, { href: "https://discussions.vuetifyjs.com/" }, {
                          default: withCtx(() => [
                            createTextVNode("GitHub Discussions")
                          ]),
                          _: 1
                        })
                      ])
                    ])
                  ]),
                  createBaseVNode("li", _hoisted_16, [
                    _hoisted_17,
                    createBaseVNode("p", null, [
                      createTextVNode("Yes, we welcome all contributions. Please see our "),
                      createVNode(_component_app_link, { href: "/getting-started/contributing/" }, {
                        default: withCtx(() => [
                          createTextVNode("contributing guide")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" for more information.")
                    ])
                  ]),
                  createBaseVNode("li", _hoisted_18, [
                    _hoisted_19,
                    _hoisted_20,
                    createVNode(_component_app_markup, {
                      resource: "src/plugins/vuetify.js",
                      class: "mb-4"
                    }, {
                      default: withCtx(() => [
                        _hoisted_21
                      ]),
                      _: 1
                    })
                  ]),
                  createBaseVNode("li", _hoisted_22, [
                    _hoisted_23,
                    createBaseVNode("p", null, [
                      createTextVNode("No. If you need to support IE11, use "),
                      createVNode(_component_app_link, { href: "https://v2.vuetifyjs.com/" }, {
                        default: withCtx(() => [
                          createTextVNode("Vuetify 2")
                        ]),
                        _: 1
                      }),
                      createTextVNode(".")
                    ])
                  ]),
                  _hoisted_24,
                  createBaseVNode("li", _hoisted_25, [
                    _hoisted_26,
                    createBaseVNode("p", null, [
                      createTextVNode("Vuetify Labs is a collection of components that are still in development. They are not considered stable and may change at any time. They are not included in the default Vuetify installation and must be imported individually. See the "),
                      createVNode(_component_app_link, { href: "/labs/introduction/" }, {
                        default: withCtx(() => [
                          createTextVNode("Labs")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" page for more information.")
                    ])
                  ]),
                  createBaseVNode("li", _hoisted_27, [
                    _hoisted_28,
                    createBaseVNode("p", null, [
                      createTextVNode("Yes, Vuetify has nightly builds. See the "),
                      createVNode(_component_app_link, { href: "/getting-started/installation/#nightly-builds" }, {
                        default: withCtx(() => [
                          createTextVNode("Nightly Builds")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" page for more information.")
                    ])
                  ]),
                  createBaseVNode("li", _hoisted_29, [
                    _hoisted_30,
                    createBaseVNode("p", null, [
                      createTextVNode("Please create a new "),
                      createVNode(_component_app_link, { href: "https://issues.vuetifyjs.com/" }, {
                        default: withCtx(() => [
                          createTextVNode("issue")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" with our Issue Generator. Please make sure to check for existing issues before creating a new one.")
                    ])
                  ]),
                  createBaseVNode("li", null, [
                    _hoisted_31,
                    createBaseVNode("p", null, [
                      createTextVNode("The "),
                      _hoisted_32,
                      createTextVNode(" prop was changed in Vue 3 to support a new "),
                      _hoisted_33,
                      createTextVNode(" syntax. See the official Vue docs for more information on "),
                      createVNode(_component_app_link, { href: "https://vuejs.org/guide/components/v-model.html" }, {
                        default: withCtx(() => [
                          createTextVNode("Component v-model")
                        ]),
                        _: 1
                      }),
                      createTextVNode(".")
                    ])
                  ]),
                  _hoisted_34
                ]),
                createVNode(_component_promoted_promoted, { type: "theme" })
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
