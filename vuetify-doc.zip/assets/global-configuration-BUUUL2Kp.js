import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "global-configuration" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Vuetify allows you to set default prop values globally or per component when setting up your application. Using this functionality you can for example disable "),
  /* @__PURE__ */ createBaseVNode("strong", null, "ripple"),
  /* @__PURE__ */ createTextVNode(" on all components, or set the default "),
  /* @__PURE__ */ createBaseVNode("strong", null, "elevation"),
  /* @__PURE__ */ createTextVNode(" for all sheets or buttons.")
], -1);
const _hoisted_3 = { id: "setup" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Use the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "defaults"),
  /* @__PURE__ */ createTextVNode(" property of the Vuetify configuration object to set default prop values. Here we have disabled "),
  /* @__PURE__ */ createBaseVNode("strong", null, "ripple"),
  /* @__PURE__ */ createTextVNode(" for all components that support it, and set the default "),
  /* @__PURE__ */ createBaseVNode("strong", null, "elevation"),
  /* @__PURE__ */ createTextVNode(" to "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "4"),
  /* @__PURE__ */ createTextVNode(" for all "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<v-sheet>"),
  /* @__PURE__ */ createTextVNode(" components.")
], -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-js" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/plugins/vuetify.js",
    class: "language-js"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" createApp "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vue'"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" createVuetify "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify'"),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "export"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "default"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "createVuetify"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "defaults"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "global"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "ripple"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "VSheet"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "elevation"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token number" }, "4"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_6 = { id: "contextual-defaults" };
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Defaults can also be configured for components nested within other components, for example if you want to set the default "),
  /* @__PURE__ */ createBaseVNode("strong", null, "variant"),
  /* @__PURE__ */ createTextVNode(" for all "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<v-btn>"),
  /* @__PURE__ */ createTextVNode(" components nested within a "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<v-card>"),
  /* @__PURE__ */ createTextVNode(" component:")
], -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-js" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/plugins/vuetify.js",
    class: "language-js"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "createVuetify"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "defaults"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "VCard"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "VBtn"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "variant"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'outlined'"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("p", null, "This is used internally by some components already:", -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<v-btn>"),
    /* @__PURE__ */ createTextVNode(" has "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, 'variant="text"'),
    /* @__PURE__ */ createTextVNode(" when nested within a "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<v-card-actions>"),
    /* @__PURE__ */ createTextVNode(" or "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<v-toolbar>")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<v-list>"),
    /* @__PURE__ */ createTextVNode(" has "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, 'bg-color="transparent"'),
    /* @__PURE__ */ createTextVNode(" when nested within a "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<v-navigation-drawer>")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Lists, chip groups, expansion panels, tabs, and forms all use this system to propagate certain props to their children, for example "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<v-tabs disabled>"),
    /* @__PURE__ */ createTextVNode(" will set the default value of "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "disabled"),
    /* @__PURE__ */ createTextVNode(" to "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "true"),
    /* @__PURE__ */ createTextVNode(" for all "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<v-tab>"),
    /* @__PURE__ */ createTextVNode(" components inside it.")
  ])
], -1);
const _hoisted_11 = { id: "global-class-and-styles" };
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("strong", null, "text-transform", -1);
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "none", -1);
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("strong", null, "style", -1);
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The following code example modifies the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "text-transform"),
  /* @__PURE__ */ createTextVNode(" CSS property of all "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<v-btn>"),
  /* @__PURE__ */ createTextVNode(" components:")
], -1);
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-js" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/plugins/vuetify.js",
    class: "language-js"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" createVuetify "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify'"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" VBtn "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify/components/VBtn'"),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "export"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "default"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "createVuetify"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "defaults"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "VBtn"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "style"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'text-transform: none;'"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("p", null, "As an alternative, apply utility classes instead to achieve the same effect:", -1);
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-js" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/plugins/vuetify.js",
    class: "language-js"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" createVuetify "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify'"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" VBtn "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify/components/VBtn'"),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "export"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "default"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "createVuetify"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "defaults"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "VBtn"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "class"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'text-none'"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("p", null, "Additionally, it works with any valid Vue value type such as objects and arrays:", -1);
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-js" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/plugins/vuetify.js",
    class: "language-js"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" createVuetify "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify'"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" VBtn "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify/components/VBtn'"),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "export"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "default"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "createVuetify"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "defaults"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "VBtn"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "style"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "["),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "textTransform"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'none'"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "]"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "class"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "style"),
  /* @__PURE__ */ createTextVNode(" cannot be used in the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "global"),
  /* @__PURE__ */ createTextVNode(" object, only in specific components.")
], -1);
const _hoisted_22 = { id: "using-with-virtual-components" };
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-js" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/plugins/vuetify.js",
    class: "language-js"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" createVuetify "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify'"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" VBtn "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify/components/VBtn'"),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "export"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "default"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "createVuetify"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "aliases"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "VBtnPrimary"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(" VBtn"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "defaults"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "VBtnPrimary"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "class"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "["),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'v-btn--primary'"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'text-none'"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "]"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Now, use "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<v-btn-primary>"),
  /* @__PURE__ */ createTextVNode(" in a template and apply a custom class:")
], -1);
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-html" }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-btn-primary")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "class"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("foobar"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("Foobar"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("v-btn-primary")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("p", null, "When compiled, the resulting HTML will contain both the globally defined classes and the custom one:", -1);
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-html" }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "<!-- Example HTML Output -->"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("button")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "class"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("v-btn v-btn--primary text-none foobar"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("Fizzbuzz"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("button")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_28 = /* @__PURE__ */ createBaseVNode("p", null, "This is particularly useful when you have multiple variants of a component that need individual classes to target:", -1);
const _hoisted_29 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/components/HelloWorld.vue",
    class: "language-html"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-app")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-main")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-btn-primary")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("Primary"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("v-btn-primary")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("span")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "class"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("mx-2"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "/>")
    ]),
    /* @__PURE__ */ createTextVNode("\n\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-btn-secondary")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("Secondary"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("v-btn-secondary")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("v-main")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("v-app")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("style")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token style" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token language-css" }, [
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token selector" }, ".v-btn.v-btn--primary"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode("\n    "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, "background"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "linear-gradient"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
        /* @__PURE__ */ createTextVNode("to right"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
        /* @__PURE__ */ createTextVNode(" #ff8a00"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
        /* @__PURE__ */ createTextVNode(" #da1b60"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ";"),
        /* @__PURE__ */ createTextVNode("\n    "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, "color"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
        /* @__PURE__ */ createTextVNode(" white"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ";"),
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token selector" }, ".v-btn.v-btn--secondary"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode("\n    "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, "background"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "linear-gradient"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
        /* @__PURE__ */ createTextVNode("to right"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
        /* @__PURE__ */ createTextVNode(" #da1b60"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
        /* @__PURE__ */ createTextVNode(" #ff8a00"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ";"),
        /* @__PURE__ */ createTextVNode("\n    "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, "color"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
        /* @__PURE__ */ createTextVNode(" white"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ";"),
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createTextVNode("\n")
      ])
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("style")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_30 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<v-chip-primary>", -1);
const _hoisted_31 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-js" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/plugins/vuetify.js",
    class: "language-js"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" createVuetify "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify'"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" VChip "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify/components/VChip'"),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "export"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "default"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "createVuetify"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "aliases"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "VChipPrimary"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(" VChip"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "defaults"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "VChipPrimary"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "class"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'v-chip--primary'"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "VChip"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "class"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'v-chip--custom'"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_32 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("When "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<v-chip-primary>"),
  /* @__PURE__ */ createTextVNode(" is used in a template, it will "),
  /* @__PURE__ */ createBaseVNode("strong", null, "not"),
  /* @__PURE__ */ createTextVNode(" have the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-chip--custom"),
  /* @__PURE__ */ createTextVNode(" class.")
], -1);
const _hoisted_33 = { id: "using-in-custom-components" };
const _hoisted_34 = /* @__PURE__ */ createBaseVNode("p", null, "Hook into the Vuetify defaults engine and configure your custom components the same way that we do. This feature makes it super easy to homogenize functionality across your application and reduce the amount of duplicated code.", -1);
const _hoisted_35 = /* @__PURE__ */ createBaseVNode("p", null, "Let’s start with an example by creating a basic component that accepts a single prop:", -1);
const _hoisted_36 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/components/MyComponent.vue",
    class: "language-html"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("div")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("I am {{ foo }}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("div")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("script")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "setup"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token script" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token language-javascript" }, [
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "defineProps"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "foo"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
        /* @__PURE__ */ createTextVNode(" String "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
        /* @__PURE__ */ createTextVNode("\n")
      ])
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("script")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_37 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Now, let’s add our new component to the Vuetify defaults configuration object and assign a default value to its "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "foo"),
  /* @__PURE__ */ createTextVNode(" prop:")
], -1);
const _hoisted_38 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-js" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/plugins/vuetify.js",
    class: "language-js"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" createVuetify "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify'"),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "export"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "default"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "createVuetify"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "defaults"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "MyComponent1"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "foo"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'bar'"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_39 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Next, import the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "useDefaults"),
  /* @__PURE__ */ createTextVNode(" composable into "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "MyComponent1.vue"),
  /* @__PURE__ */ createTextVNode(". This function has two optional arguments:")
], -1);
const _hoisted_40 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "props"),
    /* @__PURE__ */ createTextVNode(" - The props object used to generate the component’s default values")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "name"),
    /* @__PURE__ */ createTextVNode(" - The name of the component. This is used to reference the defaults key defined in your Vuetify configuration")
  ])
], -1);
const _hoisted_41 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("In your template, assign the return value of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "defineProps"),
  /* @__PURE__ */ createTextVNode(" to a variable and pass it to "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "useDefaults"),
  /* @__PURE__ */ createTextVNode(":")
], -1);
const _hoisted_42 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/components/MyComponent1.vue",
    class: "language-html"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("div")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("I am {{ props.foo }}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("div")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("script")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "setup"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token script" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token language-javascript" }, [
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode(" useDefaults "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify'"),
        /* @__PURE__ */ createTextVNode("\n\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "const"),
        /* @__PURE__ */ createTextVNode(" _props "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "="),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "defineProps"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "foo"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
        /* @__PURE__ */ createTextVNode(" String "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "const"),
        /* @__PURE__ */ createTextVNode(" props "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "="),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "useDefaults"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
        /* @__PURE__ */ createTextVNode("_props"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'MyComponent1'"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
        /* @__PURE__ */ createTextVNode("\n")
      ])
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("script")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_43 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Notice that we have to explicitly use the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "props"),
  /* @__PURE__ */ createTextVNode(" object in the template. This is because Vue automatically unwraps the values in "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "defineProps"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_44 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-diff" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-diff" }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token deleted-sign deleted" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token prefix deleted" }, "-"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token line" }, "<div>I am {{ foo }}</div>\n")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token inserted-sign inserted" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token prefix inserted" }, "+"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token line" }, "<div>I am {{ props.foo }}</div>\n")
    ])
  ])
], -1);
const _hoisted_45 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "name"),
  /* @__PURE__ */ createTextVNode(" argument is optional and is inferred from the component’s name if not provided.")
], -1);
const _hoisted_46 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("When "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<MyComponent1>"),
  /* @__PURE__ */ createTextVNode(" is used in a template, it uses the default value assigned in the Vuetify config:")
], -1);
const _hoisted_47 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-html" }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("MyComponent1")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "/>")
    ]),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "<!-- I am bar -->"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_48 = { id: "nested-defaults" };
const _hoisted_49 = /* @__PURE__ */ createBaseVNode("p", null, "It is possible to assign nested defaults within your component chain. This provides you with countless ways to configure your application and its components.", -1);
const _hoisted_50 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<MyComponent2>", -1);
const _hoisted_51 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<MyComponent1>", -1);
const _hoisted_52 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/components/MyComponent2.vue",
    class: "language-html"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("MyComponent1")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "/>")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("script")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "setup"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token script" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token language-javascript" }, [
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
        /* @__PURE__ */ createTextVNode(" MyComponent1 "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'./MyComponent1.vue'"),
        /* @__PURE__ */ createTextVNode("\n")
      ])
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("script")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_53 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Now, let’s add "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<MyComponent2>"),
  /* @__PURE__ */ createTextVNode(" to the Vuetify defaults configuration object and assign a default value to "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "foo"),
  /* @__PURE__ */ createTextVNode(" prop of all nested "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<MyComponent1>"),
  /* @__PURE__ */ createTextVNode(" components:")
], -1);
const _hoisted_54 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-js" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/plugins/vuetify.js",
    class: "language-js"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" createVuetify "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify'"),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "export"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "default"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "createVuetify"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "defaults"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "MyComponent"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "foo"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'bar'"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "MyComponent2"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "MyComponent"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "foo"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'baz'"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_55 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Head back to the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "MyComponent2.vue"),
  /* @__PURE__ */ createTextVNode(" file and import & invoke the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "useDefaults"),
  /* @__PURE__ */ createTextVNode(" composable:")
], -1);
const _hoisted_56 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/components/MyComponent2.vue",
    class: "language-html"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("div")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("slot")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "/>")
    ]),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("div")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("script")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "setup"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token script" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token language-javascript" }, [
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
        /* @__PURE__ */ createTextVNode(" MyComponent1 "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'./MyComponent1.vue'"),
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode(" useDefaults "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify'"),
        /* @__PURE__ */ createTextVNode("\n\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "useDefaults"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
        /* @__PURE__ */ createTextVNode("\n")
      ])
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("script")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_57 = /* @__PURE__ */ createBaseVNode("p", null, "Finally, add both new components to a template and inspect the output:", -1);
const _hoisted_58 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-html" }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-app")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-main")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("MyComponent1")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "/>")
    ]),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "<!-- I am bar -->"),
    /* @__PURE__ */ createTextVNode("\n\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("MyComponent2")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n        "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("MyComponent1")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "/>")
    ]),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "<!-- I am baz -->"),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("MyComponent2")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("v-main")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("v-app")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("script")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "setup"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token script" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token language-javascript" }, [
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
        /* @__PURE__ */ createTextVNode(" MyComponent1 "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'./MyComponent1.vue'"),
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
        /* @__PURE__ */ createTextVNode(" MyComponent2 "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'./MyComponent2.vue'"),
        /* @__PURE__ */ createTextVNode("\n")
      ])
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("script")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_59 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Now, whenever "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<MyComponent1>"),
  /* @__PURE__ */ createTextVNode(" is used within the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<MyComponent2>"),
  /* @__PURE__ */ createTextVNode(" component, it has a different assigned default value.")
], -1);
const frontmatter = { "meta": { "title": "Global configuration", "description": "Vuetify.config is an object containing global configuration options that modify the bootstrapping of your project.", "keywords": "vuetify config, global config, global vuetify config, configure vuetify options" }, "related": ["/features/accessibility/", "/features/treeshaking/", "/features/blueprints/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "global-configuration",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "Global configuration", "description": "Vuetify.config is an object containing global configuration options that modify the bootstrapping of your project.", "keywords": "vuetify config, global config, global vuetify config, configure vuetify options" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "title": "Global configuration", "description": "Vuetify.config is an object containing global configuration options that modify the bootstrapping of your project.", "keywords": "vuetify config, global config, global vuetify config, configure vuetify options" }, "related": ["/features/accessibility/", "/features/treeshaking/", "/features/blueprints/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_markup = resolveComponent("app-markup");
      const _component_app_link = resolveComponent("app-link");
      const _component_alert = resolveComponent("alert");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#global-configuration",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Global configuration")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_promoted_entry),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#setup",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Setup")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_app_markup, {
                  resource: "src/plugins/vuetify.js",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_5
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_6, [
                createVNode(_component_app_heading, {
                  href: "#contextual-defaults",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Contextual defaults")
                  ]),
                  _: 1
                }),
                _hoisted_7,
                createVNode(_component_app_markup, {
                  resource: "src/plugins/vuetify.js",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_8
                  ]),
                  _: 1
                }),
                _hoisted_9,
                _hoisted_10,
                createBaseVNode("p", null, [
                  createVNode(_component_app_link, { href: "/components/defaults-providers/" }, {
                    default: withCtx(() => [
                      createTextVNode("v-defaults-provider")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" can be used to set defaults for components within a specific scope.")
                ])
              ]),
              createBaseVNode("section", _hoisted_11, [
                createVNode(_component_app_heading, {
                  href: "#global-class-and-styles",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Global class and styles")
                  ]),
                  _: 1
                }),
                createVNode(_component_alert, { type: "success" }, {
                  default: withCtx(() => [
                    createBaseVNode("p", null, [
                      createTextVNode("This feature was introduced in "),
                      createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v3.2.0" }, {
                        default: withCtx(() => [
                          createTextVNode("v3.2.0 (Orion)")
                        ]),
                        _: 1
                      })
                    ])
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("Define global classes and styles for all "),
                  createVNode(_component_app_link, { href: "/components/all/" }, {
                    default: withCtx(() => [
                      createTextVNode("built-in")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" components; including "),
                  createVNode(_component_app_link, { href: "/features/aliasing/#virtual-component-defaults" }, {
                    default: withCtx(() => [
                      createTextVNode("virtual")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" ones. This provides an immense amount of utility when building your application’s design system and it reduces the amount of duplicated code in your templates.")
                ]),
                createBaseVNode("p", null, [
                  createTextVNode("Let’s say that you want to set the "),
                  _hoisted_12,
                  createTextVNode(" of all "),
                  createVNode(_component_app_link, { href: "/components/buttons/" }, {
                    default: withCtx(() => [
                      createTextVNode("v-btn")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" components to "),
                  _hoisted_13,
                  createTextVNode(", but are not interested in using "),
                  createVNode(_component_app_link, { href: "/features/sass-variables/" }, {
                    default: withCtx(() => [
                      createTextVNode("SASS variables")
                    ]),
                    _: 1
                  }),
                  createTextVNode(". By simply adding the "),
                  _hoisted_14,
                  createTextVNode(" property to a component’s default values, you are able to apply custom values to all instances of said component.")
                ]),
                _hoisted_15,
                createVNode(_component_app_markup, {
                  resource: "src/plugins/vuetify.js",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_16
                  ]),
                  _: 1
                }),
                _hoisted_17,
                createVNode(_component_app_markup, {
                  resource: "src/plugins/vuetify.js",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_18
                  ]),
                  _: 1
                }),
                _hoisted_19,
                createVNode(_component_app_markup, {
                  resource: "src/plugins/vuetify.js",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_20
                  ]),
                  _: 1
                }),
                createVNode(_component_alert, { type: "warning" }, {
                  default: withCtx(() => [
                    _hoisted_21
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_22, [
                createVNode(_component_app_heading, {
                  href: "#using-with-virtual-components",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Using with virtual components")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("Whether you are developing a wrapper framework or just a design system for your application, "),
                  createVNode(_component_app_link, { href: "/features/aliasing/#virtual-component-defaults" }, {
                    default: withCtx(() => [
                      createTextVNode("virtual components")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" are a powerful ally. Within the Vuetify defaults system, classes and styles are treated just like regular props but instead of being overwritten at the template level, they are merged.")
                ]),
                createBaseVNode("p", null, [
                  createTextVNode("For example, lets create an alias of the "),
                  createVNode(_component_app_link, { href: "/components/buttons/" }, {
                    default: withCtx(() => [
                      createTextVNode("v-btn")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" component and modify some of its default values:")
                ]),
                createVNode(_component_app_markup, {
                  resource: "src/plugins/vuetify.js",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_23
                  ]),
                  _: 1
                }),
                _hoisted_24,
                createVNode(_component_app_markup, {
                  resource: "",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_25
                  ]),
                  _: 1
                }),
                _hoisted_26,
                createVNode(_component_app_markup, {
                  resource: "",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_27
                  ]),
                  _: 1
                }),
                _hoisted_28,
                createVNode(_component_app_markup, {
                  resource: "src/components/HelloWorld.vue",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_29
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("Keep in mind that virtual components do not inherit global class or styles from their extension. For example, the following Vuetify configuration uses a "),
                  createVNode(_component_app_link, { href: "/components/chips/" }, {
                    default: withCtx(() => [
                      createTextVNode("v-chip")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" as the alias for the virtual "),
                  _hoisted_30,
                  createTextVNode(" component.")
                ]),
                createVNode(_component_app_markup, {
                  resource: "src/plugins/vuetify.js",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_31
                  ]),
                  _: 1
                }),
                _hoisted_32,
                createVNode(_component_alert, { type: "warning" }, {
                  default: withCtx(() => [
                    createBaseVNode("p", null, [
                      createTextVNode("There are some cases where a default class or style could be unintentionally passed down to an inner component. This mostly concerns "),
                      createVNode(_component_app_link, { href: "/components/all/#form-inputs-and-controls" }, {
                        default: withCtx(() => [
                          createTextVNode("form inputs and controls")
                        ]),
                        _: 1
                      }),
                      createTextVNode(".")
                    ])
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_33, [
                createVNode(_component_app_heading, {
                  href: "#using-in-custom-components",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Using in custom components")
                  ]),
                  _: 1
                }),
                createVNode(_component_alert, { type: "success" }, {
                  default: withCtx(() => [
                    createBaseVNode("p", null, [
                      createTextVNode("This feature was introduced in "),
                      createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v3.2.0" }, {
                        default: withCtx(() => [
                          createTextVNode("v3.2.0 (Orion)")
                        ]),
                        _: 1
                      })
                    ])
                  ]),
                  _: 1
                }),
                _hoisted_34,
                _hoisted_35,
                createVNode(_component_app_markup, {
                  resource: "src/components/MyComponent.vue",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_36
                  ]),
                  _: 1
                }),
                _hoisted_37,
                createVNode(_component_app_markup, {
                  resource: "src/plugins/vuetify.js",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_38
                  ]),
                  _: 1
                }),
                _hoisted_39,
                _hoisted_40,
                _hoisted_41,
                createVNode(_component_app_markup, {
                  resource: "src/components/MyComponent1.vue",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_42
                  ]),
                  _: 1
                }),
                _hoisted_43,
                createVNode(_component_app_markup, {
                  resource: "",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_44
                  ]),
                  _: 1
                }),
                createVNode(_component_alert, { type: "info" }, {
                  default: withCtx(() => [
                    _hoisted_45
                  ]),
                  _: 1
                }),
                _hoisted_46,
                createVNode(_component_app_markup, {
                  resource: "",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_47
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_48, [
                  createVNode(_component_app_heading, {
                    href: "#nested-defaults",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Nested defaults")
                    ]),
                    _: 1
                  }),
                  _hoisted_49,
                  createBaseVNode("p", null, [
                    createTextVNode("Let’s expand on the previous "),
                    createVNode(_component_app_link, { href: "#using-in-custom-components" }, {
                      default: withCtx(() => [
                        createTextVNode("example")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" by creating a new component, "),
                    _hoisted_50,
                    createTextVNode(" that uses "),
                    _hoisted_51,
                    createTextVNode(":")
                  ]),
                  createVNode(_component_app_markup, {
                    resource: "src/components/MyComponent2.vue",
                    class: "mb-4"
                  }, {
                    default: withCtx(() => [
                      _hoisted_52
                    ]),
                    _: 1
                  }),
                  _hoisted_53,
                  createVNode(_component_app_markup, {
                    resource: "src/plugins/vuetify.js",
                    class: "mb-4"
                  }, {
                    default: withCtx(() => [
                      _hoisted_54
                    ]),
                    _: 1
                  }),
                  _hoisted_55,
                  createVNode(_component_app_markup, {
                    resource: "src/components/MyComponent2.vue",
                    class: "mb-4"
                  }, {
                    default: withCtx(() => [
                      _hoisted_56
                    ]),
                    _: 1
                  }),
                  _hoisted_57,
                  createVNode(_component_app_markup, {
                    resource: "",
                    class: "mb-4"
                  }, {
                    default: withCtx(() => [
                      _hoisted_58
                    ]),
                    _: 1
                  }),
                  _hoisted_59
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
