import { y as _export_sfc, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, b as createVNode, h as createTextVNode, ac as useDisplay, j as computed, t as toDisplayString, l as createElementBlock, F as Fragment, v as renderList } from "./index-DGybHjCP.js";
const _sfc_main$i = {};
function _sfc_render$h(_ctx, _cache) {
  const _component_v_sheet = resolveComponent("v-sheet");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, { class: "bg-surface-variant" }, {
    default: withCtx(() => [
      createVNode(_component_v_row, { "no-gutters": "" }, {
        default: withCtx(() => [
          createVNode(_component_v_col, { cols: "9" }, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-9 ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "4" }, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-4 ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "6" }, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-6 ")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __0 = /* @__PURE__ */ _export_sfc(_sfc_main$i, [["render", _sfc_render$h]]);
const __0_raw = '<template>\n  <v-container class="bg-surface-variant">\n    <v-row no-gutters>\n      <v-col cols="9">\n        <v-sheet class="pa-2 ma-2">\n          .v-col-9\n        </v-sheet>\n      </v-col>\n      <v-col cols="4">\n        <v-sheet class="pa-2 ma-2">\n          .v-col-4\n        </v-sheet>\n      </v-col>\n      <v-col cols="6">\n        <v-sheet class="pa-2 ma-2">\n          .v-col-6\n        </v-sheet>\n      </v-col>\n    </v-row>\n  </v-container>\n</template>\n';
const _sfc_main$h = {};
function _sfc_render$g(_ctx, _cache) {
  const _component_v_sheet = resolveComponent("v-sheet");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_responsive = resolveComponent("v-responsive");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, { class: "bg-surface-variant" }, {
    default: withCtx(() => [
      createVNode(_component_v_row, { "no-gutters": "" }, {
        default: withCtx(() => [
          createVNode(_component_v_col, null, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-auto ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, null, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-auto ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_responsive, { width: "100%" }),
          createVNode(_component_v_col, null, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-auto ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, null, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-auto ")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __1 = /* @__PURE__ */ _export_sfc(_sfc_main$h, [["render", _sfc_render$g]]);
const __1_raw = '<template>\n  <v-container class="bg-surface-variant">\n    <v-row no-gutters>\n      <v-col>\n        <v-sheet class="pa-2 ma-2">\n          .v-col-auto\n        </v-sheet>\n      </v-col>\n      <v-col>\n        <v-sheet class="pa-2 ma-2">\n          .v-col-auto\n        </v-sheet>\n      </v-col>\n\n      <v-responsive width="100%"></v-responsive>\n\n      <v-col>\n        <v-sheet class="pa-2 ma-2">\n          .v-col-auto\n        </v-sheet>\n      </v-col>\n\n      <v-col>\n        <v-sheet class="pa-2 ma-2">\n          .v-col-auto\n        </v-sheet>\n      </v-col>\n    </v-row>\n  </v-container>\n</template>\n';
const _sfc_main$g = {};
function _sfc_render$f(_ctx, _cache) {
  const _component_v_sheet = resolveComponent("v-sheet");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, { class: "bg-surface-variant" }, {
    default: withCtx(() => [
      createVNode(_component_v_row, {
        class: "mb-6",
        "no-gutters": ""
      }, {
        default: withCtx(() => [
          createVNode(_component_v_col, null, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-auto ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, null, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-auto ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, null, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-auto ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, null, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-auto ")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_row, { "no-gutters": "" }, {
        default: withCtx(() => [
          createVNode(_component_v_col, { cols: "8" }, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-8 ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "4" }, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-4 ")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __2 = /* @__PURE__ */ _export_sfc(_sfc_main$g, [["render", _sfc_render$f]]);
const __2_raw = '<template>\n  <v-container class="bg-surface-variant">\n    <v-row\n      class="mb-6"\n      no-gutters\n    >\n      <v-col>\n        <v-sheet class="pa-2 ma-2">\n          .v-col-auto\n        </v-sheet>\n      </v-col>\n\n      <v-col>\n        <v-sheet class="pa-2 ma-2">\n          .v-col-auto\n        </v-sheet>\n      </v-col>\n\n      <v-col>\n        <v-sheet class="pa-2 ma-2">\n          .v-col-auto\n        </v-sheet>\n      </v-col>\n\n      <v-col>\n        <v-sheet class="pa-2 ma-2">\n          .v-col-auto\n        </v-sheet>\n      </v-col>\n    </v-row>\n\n    <v-row no-gutters>\n      <v-col cols="8">\n        <v-sheet class="pa-2 ma-2">\n          .v-col-8\n        </v-sheet>\n      </v-col>\n\n      <v-col cols="4">\n        <v-sheet class="pa-2 ma-2">\n          .v-col-4\n        </v-sheet>\n      </v-col>\n    </v-row>\n  </v-container>\n</template>\n';
const _sfc_main$f = {};
function _sfc_render$e(_ctx, _cache) {
  const _component_v_sheet = resolveComponent("v-sheet");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, { class: "bg-surface-variant" }, {
    default: withCtx(() => [
      createVNode(_component_v_row, null, {
        default: withCtx(() => [
          createVNode(_component_v_col, { md: "4" }, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-md-4 ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, {
            class: "ms-auto",
            md: "4"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-md-4 .ms-auto ")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_row, null, {
        default: withCtx(() => [
          createVNode(_component_v_col, {
            class: "ms-md-auto",
            md: "4"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-md-4 .ms-md-auto ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, {
            class: "ms-md-auto",
            md: "4"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-md-4 .ms-md-auto ")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_row, null, {
        default: withCtx(() => [
          createVNode(_component_v_col, {
            class: "me-auto",
            cols: "auto"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-auto .me-auto ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-auto ")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __3 = /* @__PURE__ */ _export_sfc(_sfc_main$f, [["render", _sfc_render$e]]);
const __3_raw = '<template>\n  <v-container class="bg-surface-variant">\n    <v-row>\n      <v-col md="4">\n        <v-sheet class="pa-2 ma-2">\n          .v-col-md-4\n        </v-sheet>\n      </v-col>\n      <v-col\n        class="ms-auto"\n        md="4"\n      >\n        <v-sheet class="pa-2 ma-2">\n          .v-col-md-4 .ms-auto\n        </v-sheet>\n      </v-col>\n    </v-row>\n\n    <v-row>\n      <v-col\n        class="ms-md-auto"\n        md="4"\n      >\n        <v-sheet class="pa-2 ma-2">\n          .v-col-md-4 .ms-md-auto\n        </v-sheet>\n      </v-col>\n      <v-col\n        class="ms-md-auto"\n        md="4"\n      >\n        <v-sheet class="pa-2 ma-2">\n          .v-col-md-4 .ms-md-auto\n        </v-sheet>\n      </v-col>\n    </v-row>\n\n    <v-row>\n      <v-col\n        class="me-auto"\n        cols="auto"\n      >\n        <v-sheet class="pa-2 ma-2">\n          .v-col-auto .me-auto\n        </v-sheet>\n      </v-col>\n      <v-col cols="auto">\n        <v-sheet class="pa-2 ma-2">\n          .v-col-auto\n        </v-sheet>\n      </v-col>\n    </v-row>\n  </v-container>\n</template>\n';
const _sfc_main$e = {};
function _sfc_render$d(_ctx, _cache) {
  const _component_v_sheet = resolveComponent("v-sheet");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, null, {
    default: withCtx(() => [
      createVNode(_component_v_row, { class: "bg-green" }, {
        default: withCtx(() => [
          createVNode(_component_v_col, { cols: "8" }, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" Level 1: .v-col-8 ")
                ]),
                _: 1
              }),
              createVNode(_component_v_row, {
                class: "bg-red",
                "no-gutters": ""
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_col, { cols: "8" }, {
                    default: withCtx(() => [
                      createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                        default: withCtx(() => [
                          createTextVNode(" Level 2: .v-col-8 ")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_col, { cols: "4" }, {
                    default: withCtx(() => [
                      createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                        default: withCtx(() => [
                          createTextVNode(" Level 2: .v-col-4 ")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "4" }, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" Level 1: .v-col-4 ")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __4 = /* @__PURE__ */ _export_sfc(_sfc_main$e, [["render", _sfc_render$d]]);
const __4_raw = '<template>\n  <v-container>\n    <v-row class="bg-green">\n      <v-col cols="8">\n        <v-sheet class="pa-2 ma-2">\n          Level 1: .v-col-8\n        </v-sheet>\n\n        <v-row class="bg-red" no-gutters>\n          <v-col\n            cols="8"\n          >\n            <v-sheet class="pa-2 ma-2">\n              Level 2: .v-col-8\n            </v-sheet>\n          </v-col>\n\n          <v-col\n            cols="4"\n          >\n            <v-sheet class="pa-2 ma-2">\n              Level 2: .v-col-4\n            </v-sheet>\n          </v-col>\n        </v-row>\n      </v-col>\n\n      <v-col cols="4">\n        <v-sheet class="pa-2 ma-2">\n          Level 1: .v-col-4\n        </v-sheet>\n      </v-col>\n    </v-row>\n  </v-container>\n</template>\n';
const _sfc_main$d = {};
function _sfc_render$c(_ctx, _cache) {
  const _component_v_sheet = resolveComponent("v-sheet");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, { class: "bg-surface-variant" }, {
    default: withCtx(() => [
      createVNode(_component_v_row, { "no-gutters": "" }, {
        default: withCtx(() => [
          createVNode(_component_v_col, null, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-auto ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "6" }, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-6 ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, null, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-auto ")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_row, { "no-gutters": "" }, {
        default: withCtx(() => [
          createVNode(_component_v_col, null, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-auto ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "2" }, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-2 ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, null, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-auto ")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __5 = /* @__PURE__ */ _export_sfc(_sfc_main$d, [["render", _sfc_render$c]]);
const __5_raw = '<template>\n  <v-container class="bg-surface-variant">\n    <v-row no-gutters>\n      <v-col>\n        <v-sheet class="pa-2 ma-2">\n          .v-col-auto\n        </v-sheet>\n      </v-col>\n\n      <v-col cols="6">\n        <v-sheet class="pa-2 ma-2">\n          .v-col-6\n        </v-sheet>\n      </v-col>\n\n      <v-col>\n        <v-sheet class="pa-2 ma-2">\n          .v-col-auto\n        </v-sheet>\n      </v-col>\n    </v-row>\n\n    <v-row no-gutters>\n      <v-col>\n        <v-sheet class="pa-2 ma-2">\n          .v-col-auto\n        </v-sheet>\n      </v-col>\n\n      <v-col cols="2">\n        <v-sheet class="pa-2 ma-2">\n          .v-col-2\n        </v-sheet>\n      </v-col>\n\n      <v-col>\n        <v-sheet class="pa-2 ma-2">\n          .v-col-auto\n        </v-sheet>\n      </v-col>\n    </v-row>\n  </v-container>\n</template>\n';
const _sfc_main$c = {
  __name: "misc-row-and-column-breakpoints",
  setup(__props) {
    const { lg, sm } = useDisplay();
    const cols = computed(() => {
      return lg.value ? [3, 9] : sm.value ? [9, 3] : [6, 6];
    });
    return (_ctx, _cache) => {
      const _component_v_sheet = resolveComponent("v-sheet");
      const _component_v_col = resolveComponent("v-col");
      const _component_v_row = resolveComponent("v-row");
      const _component_v_container = resolveComponent("v-container");
      return openBlock(), createBlock(_component_v_container, { class: "bg-surface-variant" }, {
        default: withCtx(() => [
          createVNode(_component_v_row, {
            class: "mb-6",
            "no-gutters": ""
          }, {
            default: withCtx(() => [
              createVNode(_component_v_col, {
                cols: cols.value[0]
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                    default: withCtx(() => [
                      createTextVNode(" .v-col-" + toDisplayString(cols.value[0]), 1)
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }, 8, ["cols"]),
              createVNode(_component_v_col, {
                cols: cols.value[1]
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                    default: withCtx(() => [
                      createTextVNode(" .v-col-" + toDisplayString(cols.value[1]), 1)
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }, 8, ["cols"])
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __6 = _sfc_main$c;
const __6_raw = `<template>
  <v-container class="bg-surface-variant">
    <v-row
      class="mb-6"
      no-gutters
    >
      <v-col :cols="cols[0]">
        <v-sheet class="pa-2 ma-2">
          .v-col-{{ cols[0] }}
        </v-sheet>
      </v-col>

      <v-col :cols="cols[1]">
        <v-sheet class="pa-2 ma-2">
          .v-col-{{ cols[1] }}
        </v-sheet>
      </v-col>
    </v-row>
  </v-container>
</template>

<script setup>
  import { computed } from 'vue'
  import { useDisplay } from 'vuetify'

  const { lg, sm } = useDisplay()

  const cols = computed(() => {
    return lg.value ? [3, 9]
      : sm.value ? [9, 3]
        : [6, 6]
  })
<\/script>

<script>
  export default {
    computed: {
      cols () {
        const { lg, sm } = this.$vuetify.display
        return lg ? [3, 9]
          : sm ? [9, 3]
            : [6, 6]
      },
    },
  }
<\/script>
`;
const _sfc_main$b = {};
function _sfc_render$b(_ctx, _cache) {
  const _component_v_sheet = resolveComponent("v-sheet");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_spacer = resolveComponent("v-spacer");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, { class: "bg-surface-variant" }, {
    default: withCtx(() => [
      createVNode(_component_v_row, null, {
        default: withCtx(() => [
          createVNode(_component_v_col, null, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-auto ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_spacer),
          createVNode(_component_v_col, null, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-auto ")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_row, null, {
        default: withCtx(() => [
          createVNode(_component_v_col, null, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-auto ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_spacer),
          createVNode(_component_v_col, null, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-auto ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_spacer),
          createVNode(_component_v_col, null, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-auto ")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __7 = /* @__PURE__ */ _export_sfc(_sfc_main$b, [["render", _sfc_render$b]]);
const __7_raw = '<template>\n  <v-container class="bg-surface-variant">\n    <v-row>\n      <v-col>\n        <v-sheet class="pa-2 ma-2">\n          .v-col-auto\n        </v-sheet>\n      </v-col>\n\n      <v-spacer></v-spacer>\n\n      <v-col>\n        <v-sheet class="pa-2 ma-2">\n          .v-col-auto\n        </v-sheet>\n      </v-col>\n    </v-row>\n\n    <v-row>\n      <v-col>\n        <v-sheet class="pa-2 ma-2">\n          .v-col-auto\n        </v-sheet>\n      </v-col>\n\n      <v-spacer></v-spacer>\n\n      <v-col>\n        <v-sheet class="pa-2 ma-2">\n          .v-col-auto\n        </v-sheet>\n      </v-col>\n\n      <v-spacer></v-spacer>\n\n      <v-col>\n        <v-sheet class="pa-2 ma-2">\n          .v-col-auto\n        </v-sheet>\n      </v-col>\n    </v-row>\n  </v-container>\n</template>\n';
const _sfc_main$a = {};
function _sfc_render$a(_ctx, _cache) {
  const _component_v_card = resolveComponent("v-card");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, { class: "bg-grey-lighten-5" }, {
    default: withCtx(() => [
      createVNode(_component_v_row, null, {
        default: withCtx(() => [
          createVNode(_component_v_col, {
            cols: "12",
            md: "8"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_card, {
                class: "pa-2",
                rounded: "0",
                variant: "outlined"
              }, {
                default: withCtx(() => [
                  createTextVNode(" .col-12 .col-md-8 ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, {
            cols: "6",
            md: "4"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_card, {
                class: "pa-2",
                rounded: "0",
                variant: "outlined"
              }, {
                default: withCtx(() => [
                  createTextVNode(" .col-6 .col-md-4 ")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_row, null, {
        default: withCtx(() => [
          (openBlock(), createElementBlock(Fragment, null, renderList(3, (n) => {
            return createVNode(_component_v_col, {
              key: n,
              cols: "6",
              md: "4"
            }, {
              default: withCtx(() => [
                createVNode(_component_v_card, {
                  class: "pa-2",
                  rounded: "0",
                  variant: "outlined"
                }, {
                  default: withCtx(() => [
                    createTextVNode(" .col-6 .col-md-4 ")
                  ]),
                  _: 1
                })
              ]),
              _: 2
            }, 1024);
          }), 64))
        ]),
        _: 1
      }),
      createVNode(_component_v_row, null, {
        default: withCtx(() => [
          (openBlock(), createElementBlock(Fragment, null, renderList(2, (n) => {
            return createVNode(_component_v_col, {
              key: n,
              cols: "6"
            }, {
              default: withCtx(() => [
                createVNode(_component_v_card, {
                  class: "pa-2",
                  rounded: "0",
                  variant: "outlined"
                }, {
                  default: withCtx(() => [
                    createTextVNode(" .col-6 ")
                  ]),
                  _: 1
                })
              ]),
              _: 2
            }, 1024);
          }), 64))
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __8 = /* @__PURE__ */ _export_sfc(_sfc_main$a, [["render", _sfc_render$a]]);
const __8_raw = '<template>\n  <v-container class="bg-grey-lighten-5">\n    <!-- Stack the columns on mobile by making one full-width and the other half-width -->\n    <v-row>\n      <v-col\n        cols="12"\n        md="8"\n      >\n        <v-card\n          class="pa-2"\n          rounded="0"\n          variant="outlined"\n        >\n          .col-12 .col-md-8\n        </v-card>\n      </v-col>\n      <v-col\n        cols="6"\n        md="4"\n      >\n        <v-card\n          class="pa-2"\n          rounded="0"\n          variant="outlined"\n        >\n          .col-6 .col-md-4\n        </v-card>\n      </v-col>\n    </v-row>\n\n    <!-- Columns start at 50% wide on mobile and bump up to 33.3% wide on desktop -->\n    <v-row>\n      <v-col\n        v-for="n in 3"\n        :key="n"\n        cols="6"\n        md="4"\n      >\n        <v-card\n          class="pa-2"\n          rounded="0"\n          variant="outlined"\n        >\n          .col-6 .col-md-4\n        </v-card>\n      </v-col>\n    </v-row>\n\n    <!-- Columns are always 50% wide, on mobile and desktop -->\n    <v-row>\n      <v-col\n        v-for="n in 2"\n        :key="n"\n        cols="6"\n      >\n        <v-card\n          class="pa-2"\n          rounded="0"\n          variant="outlined"\n        >\n          .col-6\n        </v-card>\n      </v-col>\n    </v-row>\n  </v-container>\n</template>\n';
const _sfc_main$9 = {};
function _sfc_render$9(_ctx, _cache) {
  const _component_v_card = resolveComponent("v-card");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, { class: "bg-grey-lighten-5" }, {
    default: withCtx(() => [
      createVNode(_component_v_row, {
        class: "mb-6",
        justify: "center",
        "no-gutters": ""
      }, {
        default: withCtx(() => [
          createVNode(_component_v_col, { lg: "2" }, {
            default: withCtx(() => [
              createVNode(_component_v_card, {
                class: "pa-2",
                rounded: "0",
                variant: "outlined"
              }, {
                default: withCtx(() => [
                  createTextVNode(" 1 of 3 ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { md: "auto" }, {
            default: withCtx(() => [
              createVNode(_component_v_card, {
                class: "pa-2",
                rounded: "0",
                variant: "outlined"
              }, {
                default: withCtx(() => [
                  createTextVNode(" Variable width content ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { lg: "2" }, {
            default: withCtx(() => [
              createVNode(_component_v_card, {
                class: "pa-2",
                rounded: "0",
                variant: "outlined"
              }, {
                default: withCtx(() => [
                  createTextVNode(" 3 of 3 ")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_row, { "no-gutters": "" }, {
        default: withCtx(() => [
          createVNode(_component_v_col, null, {
            default: withCtx(() => [
              createVNode(_component_v_card, {
                class: "pa-2",
                rounded: "0",
                variant: "outlined"
              }, {
                default: withCtx(() => [
                  createTextVNode(" 1 of 3 ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { md: "auto" }, {
            default: withCtx(() => [
              createVNode(_component_v_card, {
                class: "pa-2",
                rounded: "0",
                variant: "outlined"
              }, {
                default: withCtx(() => [
                  createTextVNode(" Variable width content ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { lg: "2" }, {
            default: withCtx(() => [
              createVNode(_component_v_card, {
                class: "pa-2",
                rounded: "0",
                variant: "outlined"
              }, {
                default: withCtx(() => [
                  createTextVNode(" 3 of 3 ")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __9 = /* @__PURE__ */ _export_sfc(_sfc_main$9, [["render", _sfc_render$9]]);
const __9_raw = '<template>\n  <v-container class="bg-grey-lighten-5">\n    <v-row\n      class="mb-6"\n      justify="center"\n      no-gutters\n    >\n      <v-col lg="2">\n        <v-card\n          class="pa-2"\n          rounded="0"\n          variant="outlined"\n        >\n          1 of 3\n        </v-card>\n      </v-col>\n      <v-col md="auto">\n        <v-card\n          class="pa-2"\n          rounded="0"\n          variant="outlined"\n        >\n          Variable width content\n        </v-card>\n      </v-col>\n      <v-col lg="2">\n        <v-card\n          class="pa-2"\n          rounded="0"\n          variant="outlined"\n        >\n          3 of 3\n        </v-card>\n      </v-col>\n    </v-row>\n    <v-row no-gutters>\n      <v-col>\n        <v-card\n          class="pa-2"\n          rounded="0"\n          variant="outlined"\n        >\n          1 of 3\n        </v-card>\n      </v-col>\n      <v-col md="auto">\n        <v-card\n          class="pa-2"\n          rounded="0"\n          variant="outlined"\n        >\n          Variable width content\n        </v-card>\n      </v-col>\n      <v-col lg="2">\n        <v-card\n          class="pa-2"\n          rounded="0"\n          variant="outlined"\n        >\n          3 of 3\n        </v-card>\n      </v-col>\n    </v-row>\n  </v-container>\n</template>\n';
const _sfc_main$8 = {};
function _sfc_render$8(_ctx, _cache) {
  const _component_v_sheet = resolveComponent("v-sheet");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createElementBlock("div", null, [
    createVNode(_component_v_container, { class: "bg-surface-variant mb-6" }, {
      default: withCtx(() => [
        createVNode(_component_v_row, {
          align: "start",
          style: { "height": "150px" },
          "no-gutters": ""
        }, {
          default: withCtx(() => [
            (openBlock(), createElementBlock(Fragment, null, renderList(3, (n) => {
              return createVNode(_component_v_col, { key: n }, {
                default: withCtx(() => [
                  createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                    default: withCtx(() => [
                      createTextVNode(" .align-start ")
                    ]),
                    _: 1
                  })
                ]),
                _: 2
              }, 1024);
            }), 64))
          ]),
          _: 1
        })
      ]),
      _: 1
    }),
    createVNode(_component_v_container, { class: "bg-surface-variant mb-6" }, {
      default: withCtx(() => [
        createVNode(_component_v_row, {
          align: "center",
          style: { "height": "150px" },
          "no-gutters": ""
        }, {
          default: withCtx(() => [
            (openBlock(), createElementBlock(Fragment, null, renderList(3, (n) => {
              return createVNode(_component_v_col, { key: n }, {
                default: withCtx(() => [
                  createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                    default: withCtx(() => [
                      createTextVNode(" .align-center ")
                    ]),
                    _: 1
                  })
                ]),
                _: 2
              }, 1024);
            }), 64))
          ]),
          _: 1
        })
      ]),
      _: 1
    }),
    createVNode(_component_v_container, { class: "bg-surface-variant mb-6" }, {
      default: withCtx(() => [
        createVNode(_component_v_row, {
          align: "end",
          style: { "height": "150px" },
          "no-gutters": ""
        }, {
          default: withCtx(() => [
            (openBlock(), createElementBlock(Fragment, null, renderList(3, (n) => {
              return createVNode(_component_v_col, { key: n }, {
                default: withCtx(() => [
                  createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                    default: withCtx(() => [
                      createTextVNode(" .align-end ")
                    ]),
                    _: 1
                  })
                ]),
                _: 2
              }, 1024);
            }), 64))
          ]),
          _: 1
        })
      ]),
      _: 1
    }),
    createVNode(_component_v_container, { class: "bg-surface-variant" }, {
      default: withCtx(() => [
        createVNode(_component_v_row, {
          style: { "height": "150px" },
          "no-gutters": ""
        }, {
          default: withCtx(() => [
            createVNode(_component_v_col, { "align-self": "start" }, {
              default: withCtx(() => [
                createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                  default: withCtx(() => [
                    createTextVNode(" .align-self-start ")
                  ]),
                  _: 1
                })
              ]),
              _: 1
            }),
            createVNode(_component_v_col, { "align-self": "center" }, {
              default: withCtx(() => [
                createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                  default: withCtx(() => [
                    createTextVNode(" .align-self-center ")
                  ]),
                  _: 1
                })
              ]),
              _: 1
            }),
            createVNode(_component_v_col, { "align-self": "end" }, {
              default: withCtx(() => [
                createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                  default: withCtx(() => [
                    createTextVNode(" .align-self-end ")
                  ]),
                  _: 1
                })
              ]),
              _: 1
            })
          ]),
          _: 1
        })
      ]),
      _: 1
    })
  ]);
}
const __10 = /* @__PURE__ */ _export_sfc(_sfc_main$8, [["render", _sfc_render$8]]);
const __10_raw = '<template>\n  <div>\n    <v-container\n      class="bg-surface-variant mb-6"\n    >\n      <v-row\n        align="start"\n        style="height: 150px;"\n        no-gutters\n      >\n        <v-col\n          v-for="n in 3"\n          :key="n"\n        >\n          <v-sheet class="pa-2 ma-2">\n            .align-start\n          </v-sheet>\n        </v-col>\n      </v-row>\n    </v-container>\n\n    <v-container\n      class="bg-surface-variant mb-6"\n    >\n      <v-row\n        align="center"\n        style="height: 150px;"\n        no-gutters\n      >\n        <v-col\n          v-for="n in 3"\n          :key="n"\n        >\n          <v-sheet class="pa-2 ma-2">\n            .align-center\n          </v-sheet>\n        </v-col>\n      </v-row>\n    </v-container>\n\n    <v-container\n      class="bg-surface-variant mb-6"\n    >\n      <v-row\n        align="end"\n        style="height: 150px;"\n        no-gutters\n      >\n        <v-col\n          v-for="n in 3"\n          :key="n"\n        >\n          <v-sheet class="pa-2 ma-2">\n            .align-end\n          </v-sheet>\n        </v-col>\n      </v-row>\n    </v-container>\n\n    <v-container class="bg-surface-variant">\n      <v-row\n        style="height: 150px;"\n        no-gutters\n      >\n        <v-col align-self="start">\n          <v-sheet class="pa-2 ma-2">\n            .align-self-start\n          </v-sheet>\n        </v-col>\n\n        <v-col align-self="center">\n          <v-sheet class="pa-2 ma-2">\n            .align-self-center\n          </v-sheet>\n        </v-col>\n\n        <v-col align-self="end">\n          <v-sheet class="pa-2 ma-2">\n            .align-self-end\n          </v-sheet>\n        </v-col>\n      </v-row>\n    </v-container>\n  </div>\n</template>\n';
const _sfc_main$7 = {};
function _sfc_render$7(_ctx, _cache) {
  const _component_v_sheet = resolveComponent("v-sheet");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, { class: "bg-surface-variant" }, {
    default: withCtx(() => [
      createVNode(_component_v_row, { "no-gutters": "" }, {
        default: withCtx(() => [
          createVNode(_component_v_col, null, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-auto ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, null, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-auto ")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_row, { "no-gutters": "" }, {
        default: withCtx(() => [
          createVNode(_component_v_col, null, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-auto ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, null, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-auto ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, null, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-auto ")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_row, { "no-gutters": "" }, {
        default: withCtx(() => [
          createVNode(_component_v_col, { cols: "2" }, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-2 ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, null, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-auto ")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __11 = /* @__PURE__ */ _export_sfc(_sfc_main$7, [["render", _sfc_render$7]]);
const __11_raw = '<template>\n  <v-container class="bg-surface-variant">\n    <v-row no-gutters>\n      <v-col>\n        <v-sheet class="pa-2 ma-2">\n          .v-col-auto\n        </v-sheet>\n      </v-col>\n      <v-col>\n        <v-sheet class="pa-2 ma-2">\n          .v-col-auto\n        </v-sheet>\n      </v-col>\n    </v-row>\n\n    <v-row no-gutters>\n      <v-col>\n        <v-sheet class="pa-2 ma-2">\n          .v-col-auto\n        </v-sheet>\n      </v-col>\n      <v-col>\n        <v-sheet class="pa-2 ma-2">\n          .v-col-auto\n        </v-sheet>\n      </v-col>\n      <v-col>\n        <v-sheet class="pa-2 ma-2">\n          .v-col-auto\n        </v-sheet>\n      </v-col>\n    </v-row>\n\n    <v-row no-gutters>\n      <v-col cols="2">\n        <v-sheet class="pa-2 ma-2">\n          .v-col-2\n        </v-sheet>\n      </v-col>\n      <v-col>\n        <v-sheet class="pa-2 ma-2">\n          .v-col-auto\n        </v-sheet>\n      </v-col>\n    </v-row>\n  </v-container>\n</template>\n';
const _sfc_main$6 = {};
function _sfc_render$6(_ctx, _cache) {
  const _component_v_sheet = resolveComponent("v-sheet");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, { class: "bg-surface-variant" }, {
    default: withCtx(() => [
      createVNode(_component_v_row, { justify: "start" }, {
        default: withCtx(() => [
          (openBlock(), createElementBlock(Fragment, null, renderList(2, (k) => {
            return createVNode(_component_v_col, {
              key: k,
              cols: "4"
            }, {
              default: withCtx(() => [
                createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                  default: withCtx(() => [
                    createTextVNode(" .justify-start ")
                  ]),
                  _: 1
                })
              ]),
              _: 2
            }, 1024);
          }), 64))
        ]),
        _: 1
      }),
      createVNode(_component_v_row, { justify: "center" }, {
        default: withCtx(() => [
          (openBlock(), createElementBlock(Fragment, null, renderList(2, (k) => {
            return createVNode(_component_v_col, {
              key: k,
              cols: "4"
            }, {
              default: withCtx(() => [
                createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                  default: withCtx(() => [
                    createTextVNode(" .justify-center ")
                  ]),
                  _: 1
                })
              ]),
              _: 2
            }, 1024);
          }), 64))
        ]),
        _: 1
      }),
      createVNode(_component_v_row, { justify: "end" }, {
        default: withCtx(() => [
          (openBlock(), createElementBlock(Fragment, null, renderList(2, (k) => {
            return createVNode(_component_v_col, {
              key: k,
              cols: "4"
            }, {
              default: withCtx(() => [
                createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                  default: withCtx(() => [
                    createTextVNode(" .justify-end ")
                  ]),
                  _: 1
                })
              ]),
              _: 2
            }, 1024);
          }), 64))
        ]),
        _: 1
      }),
      createVNode(_component_v_row, { justify: "space-around" }, {
        default: withCtx(() => [
          (openBlock(), createElementBlock(Fragment, null, renderList(2, (k) => {
            return createVNode(_component_v_col, {
              key: k,
              cols: "4"
            }, {
              default: withCtx(() => [
                createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                  default: withCtx(() => [
                    createTextVNode(" .justify-space-around ")
                  ]),
                  _: 1
                })
              ]),
              _: 2
            }, 1024);
          }), 64))
        ]),
        _: 1
      }),
      createVNode(_component_v_row, { justify: "space-between" }, {
        default: withCtx(() => [
          (openBlock(), createElementBlock(Fragment, null, renderList(2, (k) => {
            return createVNode(_component_v_col, {
              key: k,
              cols: "4"
            }, {
              default: withCtx(() => [
                createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                  default: withCtx(() => [
                    createTextVNode(" .justify-space-between ")
                  ]),
                  _: 1
                })
              ]),
              _: 2
            }, 1024);
          }), 64))
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __12 = /* @__PURE__ */ _export_sfc(_sfc_main$6, [["render", _sfc_render$6]]);
const __12_raw = '<template>\n  <v-container class="bg-surface-variant">\n    <v-row justify="start">\n      <v-col\n        v-for="k in 2"\n        :key="k"\n        cols="4"\n      >\n        <v-sheet class="pa-2 ma-2">\n          .justify-start\n        </v-sheet>\n      </v-col>\n    </v-row>\n\n    <v-row justify="center">\n      <v-col\n        v-for="k in 2"\n        :key="k"\n        cols="4"\n      >\n        <v-sheet class="pa-2 ma-2">\n          .justify-center\n        </v-sheet>\n      </v-col>\n    </v-row>\n\n    <v-row justify="end">\n      <v-col\n        v-for="k in 2"\n        :key="k"\n        cols="4"\n      >\n        <v-sheet class="pa-2 ma-2">\n          .justify-end\n        </v-sheet>\n      </v-col>\n    </v-row>\n\n    <v-row justify="space-around">\n      <v-col\n        v-for="k in 2"\n        :key="k"\n        cols="4"\n      >\n        <v-sheet class="pa-2 ma-2">\n          .justify-space-around\n        </v-sheet>\n      </v-col>\n    </v-row>\n\n    <v-row justify="space-between">\n      <v-col\n        v-for="k in 2"\n        :key="k"\n        cols="4"\n      >\n        <v-sheet class="pa-2 ma-2">\n          .justify-space-between\n        </v-sheet>\n      </v-col>\n    </v-row>\n  </v-container>\n</template>\n';
const _sfc_main$5 = {};
function _sfc_render$5(_ctx, _cache) {
  const _component_v_sheet = resolveComponent("v-sheet");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, { class: "bg-surface-variant" }, {
    default: withCtx(() => [
      createVNode(_component_v_row, { "no-gutters": "" }, {
        default: withCtx(() => [
          createVNode(_component_v_col, { cols: "12" }, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-12 ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "6" }, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-6 ")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __13 = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["render", _sfc_render$5]]);
const __13_raw = '<template>\n  <v-container class="bg-surface-variant">\n    <v-row no-gutters>\n      <v-col cols="12">\n        <v-sheet class="pa-2">\n          .v-col-12\n        </v-sheet>\n      </v-col>\n      <v-col cols="6">\n        <v-sheet class="pa-2">\n          .v-col-6\n        </v-sheet>\n      </v-col>\n    </v-row>\n  </v-container>\n</template>\n';
const _sfc_main$4 = {};
function _sfc_render$4(_ctx, _cache) {
  const _component_v_sheet = resolveComponent("v-sheet");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, { class: "bg-surface-variant" }, {
    default: withCtx(() => [
      createVNode(_component_v_row, {
        class: "mb-6",
        "no-gutters": ""
      }, {
        default: withCtx(() => [
          createVNode(_component_v_col, {
            md: "6",
            sm: "5"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-sm-5 .v-col-md-6 ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, {
            md: "6",
            "offset-md": "0",
            "offset-sm": "2",
            sm: "5"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-sm-5 .offset-sm-2 .v-col-md-6 .offset-md-0 ")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_row, { "no-gutters": "" }, {
        default: withCtx(() => [
          createVNode(_component_v_col, {
            lg: "6",
            md: "5",
            sm: "6"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" sm-6 md-5 lg-6 ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, {
            lg: "6",
            md: "5",
            "offset-lg": "0",
            "offset-md": "2",
            sm: "6"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-sm-6 md-5 .offset-md-2 .v-col-lg-6 .offset-lg-0 ")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __14 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["render", _sfc_render$4]]);
const __14_raw = '<template>\n  <v-container class="bg-surface-variant">\n    <v-row\n      class="mb-6"\n      no-gutters\n    >\n      <v-col\n        md="6"\n        sm="5"\n      >\n        <v-sheet class="pa-2 ma-2">\n          .v-col-sm-5 .v-col-md-6\n        </v-sheet>\n      </v-col>\n      <v-col\n        md="6"\n        offset-md="0"\n        offset-sm="2"\n        sm="5"\n      >\n        <v-sheet class="pa-2 ma-2">\n          .v-col-sm-5 .offset-sm-2 .v-col-md-6 .offset-md-0\n        </v-sheet>\n      </v-col>\n    </v-row>\n    <v-row no-gutters>\n      <v-col\n        lg="6"\n        md="5"\n        sm="6"\n      >\n        <v-sheet class="pa-2 ma-2">\n          sm-6 md-5 lg-6\n        </v-sheet>\n      </v-col>\n      <v-col\n        lg="6"\n        md="5"\n        offset-lg="0"\n        offset-md="2"\n        sm="6"\n      >\n        <v-sheet class="pa-2 ma-2">\n          .v-col-sm-6 md-5 .offset-md-2 .v-col-lg-6 .offset-lg-0\n        </v-sheet>\n      </v-col>\n    </v-row>\n  </v-container>\n</template>\n';
const _sfc_main$3 = {};
function _sfc_render$3(_ctx, _cache) {
  const _component_v_sheet = resolveComponent("v-sheet");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, { class: "bg-surface-variant" }, {
    default: withCtx(() => [
      createVNode(_component_v_row, {
        class: "mb-6",
        "no-gutters": ""
      }, {
        default: withCtx(() => [
          createVNode(_component_v_col, { cols: "4" }, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-4 ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, {
            cols: "4",
            offset: "4"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-4 .offset-4 ")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_row, {
        class: "mb-6",
        "no-gutters": ""
      }, {
        default: withCtx(() => [
          createVNode(_component_v_col, {
            cols: "3",
            offset: "3"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-3 .offset-3 ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, {
            cols: "3",
            offset: "3"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-3 .offset-3 ")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_row, { "no-gutters": "" }, {
        default: withCtx(() => [
          createVNode(_component_v_col, {
            cols: "6",
            offset: "3"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" .v-col-6 .offset-3 ")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __15 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["render", _sfc_render$3]]);
const __15_raw = '<template>\n  <v-container class="bg-surface-variant">\n    <v-row\n      class="mb-6"\n      no-gutters\n    >\n      <v-col cols="4">\n        <v-sheet class="pa-2 ma-2">\n          .v-col-4\n        </v-sheet>\n      </v-col>\n      <v-col\n        cols="4"\n        offset="4"\n      >\n        <v-sheet class="pa-2 ma-2">\n          .v-col-4 .offset-4\n        </v-sheet>\n      </v-col>\n    </v-row>\n    <v-row\n      class="mb-6"\n      no-gutters\n    >\n      <v-col\n        cols="3"\n        offset="3"\n      >\n        <v-sheet class="pa-2 ma-2">\n          .v-col-3 .offset-3\n        </v-sheet>\n      </v-col>\n      <v-col\n        cols="3"\n        offset="3"\n      >\n        <v-sheet class="pa-2 ma-2">\n          .v-col-3 .offset-3\n        </v-sheet>\n      </v-col>\n    </v-row>\n    <v-row no-gutters>\n      <v-col\n        cols="6"\n        offset="3"\n      >\n        <v-sheet class="pa-2 ma-2">\n          .v-col-6 .offset-3\n        </v-sheet>\n      </v-col>\n    </v-row>\n  </v-container>\n</template>\n';
const _sfc_main$2 = {};
function _sfc_render$2(_ctx, _cache) {
  const _component_v_sheet = resolveComponent("v-sheet");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, { class: "bg-surface-variant" }, {
    default: withCtx(() => [
      createVNode(_component_v_row, { "no-gutters": "" }, {
        default: withCtx(() => [
          createVNode(_component_v_col, { order: "last" }, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" First, but last ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, null, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" Second, but unordered ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { order: "first" }, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" Third, but first ")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __16 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["render", _sfc_render$2]]);
const __16_raw = '<template>\n  <v-container class="bg-surface-variant">\n    <v-row no-gutters>\n      <v-col order="last">\n        <v-sheet class="pa-2 ma-2">\n          First, but last\n        </v-sheet>\n      </v-col>\n      <v-col>\n        <v-sheet class="pa-2 ma-2">\n          Second, but unordered\n        </v-sheet>\n      </v-col>\n      <v-col order="first">\n        <v-sheet class="pa-2 ma-2">\n          Third, but first\n        </v-sheet>\n      </v-col>\n    </v-row>\n  </v-container>\n</template>\n';
const _sfc_main$1 = {};
function _sfc_render$1(_ctx, _cache) {
  const _component_v_sheet = resolveComponent("v-sheet");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, { class: "bg-surface-variant" }, {
    default: withCtx(() => [
      createVNode(_component_v_row, { "no-gutters": "" }, {
        default: withCtx(() => [
          createVNode(_component_v_col, { order: "6" }, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" First in markup, but middle in row ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { order: "12" }, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" Second in markup, but last in row ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { order: "1" }, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, { class: "pa-2 ma-2" }, {
                default: withCtx(() => [
                  createTextVNode(" Third in markup, but first in row ")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __17 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["render", _sfc_render$1]]);
const __17_raw = '<template>\n  <v-container class="bg-surface-variant">\n    <v-row no-gutters>\n      <v-col order="6">\n        <v-sheet class="pa-2 ma-2">\n          First in markup, but middle in row\n        </v-sheet>\n      </v-col>\n      <v-col order="12">\n        <v-sheet class="pa-2 ma-2">\n          Second in markup, but last in row\n        </v-sheet>\n      </v-col>\n      <v-col order="1">\n        <v-sheet class="pa-2 ma-2">\n          Third in markup, but first in row\n        </v-sheet>\n      </v-col>\n    </v-row>\n  </v-container>\n</template>\n';
const _sfc_main = {};
function _sfc_render(_ctx, _cache) {
  const _component_v_sheet = resolveComponent("v-sheet");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, { class: "bg-surface-variant" }, {
    default: withCtx(() => [
      createVNode(_component_v_row, { "no-gutters": "" }, {
        default: withCtx(() => [
          (openBlock(), createElementBlock(Fragment, null, renderList(3, (n) => {
            return createVNode(_component_v_col, {
              key: n,
              cols: "12",
              sm: "4"
            }, {
              default: withCtx(() => [
                createVNode(_component_v_sheet, { class: "ma-2 pa-2" }, {
                  default: withCtx(() => [
                    createTextVNode(" One of three columns ")
                  ]),
                  _: 1
                })
              ]),
              _: 2
            }, 1024);
          }), 64))
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __18 = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
const __18_raw = '<template>\n  <v-container class="bg-surface-variant">\n    <v-row no-gutters>\n      <v-col\n        v-for="n in 3"\n        :key="n"\n        cols="12"\n        sm="4"\n      >\n        <v-sheet class="ma-2 pa-2">\n          One of three columns\n        </v-sheet>\n      </v-col>\n    </v-row>\n  </v-container>\n</template>\n';
const grid = {
  "misc-column-wrapping": {
    component: __0,
    source: __0_raw
  },
  "misc-equal-width-columns": {
    component: __1,
    source: __1_raw
  },
  "misc-grow-and-shrink": {
    component: __2,
    source: __2_raw
  },
  "misc-margin-helpers": {
    component: __3,
    source: __3_raw
  },
  "misc-nested-grid": {
    component: __4,
    source: __4_raw
  },
  "misc-one-column-width": {
    component: __5,
    source: __5_raw
  },
  "misc-row-and-column-breakpoints": {
    component: __6,
    source: __6_raw
  },
  "misc-spacer": {
    component: __7,
    source: __7_raw
  },
  "misc-unique-layouts": {
    component: __8,
    source: __8_raw
  },
  "misc-variable-content": {
    component: __9,
    source: __9_raw
  },
  "prop-align": {
    component: __10,
    source: __10_raw
  },
  "prop-breakpoint-sizing": {
    component: __11,
    source: __11_raw
  },
  "prop-justify": {
    component: __12,
    source: __12_raw
  },
  "prop-no-gutters": {
    component: __13,
    source: __13_raw
  },
  "prop-offset-breakpoint": {
    component: __14,
    source: __14_raw
  },
  "prop-offset": {
    component: __15,
    source: __15_raw
  },
  "prop-order-first-and-last": {
    component: __16,
    source: __16_raw
  },
  "prop-order": {
    component: __17,
    source: __17_raw
  },
  "usage": {
    component: __18,
    source: __18_raw
  }
};
export {
  grid as default
};
