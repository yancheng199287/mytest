import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "grid-system" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "Vuetify comes with a 12 point grid system built using flexbox.", -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("strong", null, "xs", -1);
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("strong", null, "sm", -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("strong", null, "md", -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("strong", null, "lg", -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("strong", null, "xl", -1);
const _hoisted_8 = { id: "usage" };
const _hoisted_9 = { id: "api" };
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("td", null, "The container component.", -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("td", null, "Sub-component used to create rows.", -1);
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("td", null, "Sub-component used to create columns.", -1);
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("td", null, "A component often used in grid scenarios.", -1);
const _hoisted_15 = { id: "sub-components" };
const _hoisted_16 = { id: "v-container" };
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-container"),
  /* @__PURE__ */ createTextVNode(" provides the ability to center and horizontally pad your site’s contents. You can also use the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "fluid"),
  /* @__PURE__ */ createTextVNode(" prop to fully extend the container across all viewport and device sizes. Maintains previous 1.x functionality in which props are passed through as classes on "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-container"),
  /* @__PURE__ */ createTextVNode(" allowing for the application of helper classes (such as "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "ma-#"),
  /* @__PURE__ */ createTextVNode("/"),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "pa-#"),
  /* @__PURE__ */ createTextVNode("/"),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "fill-height"),
  /* @__PURE__ */ createTextVNode(") to easily be applied.")
], -1);
const _hoisted_18 = { id: "v-col" };
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-col"),
  /* @__PURE__ */ createTextVNode(" is a content holder that must be a direct child of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-row"),
  /* @__PURE__ */ createTextVNode(". This is the 2.x replacement for "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-flex"),
  /* @__PURE__ */ createTextVNode(" in 1.x.")
], -1);
const _hoisted_20 = { id: "v-row" };
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-row"),
  /* @__PURE__ */ createTextVNode(" is a wrapper component for "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-col"),
  /* @__PURE__ */ createTextVNode(". It utilizes flex properties to control the layout and flow of its inner columns. It uses a standard gutter of "),
  /* @__PURE__ */ createBaseVNode("strong", null, "24px"),
  /* @__PURE__ */ createTextVNode(". This can be reduced with the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "dense"),
  /* @__PURE__ */ createTextVNode(" prop or removed completely with "),
  /* @__PURE__ */ createBaseVNode("strong", null, "no-gutters"),
  /* @__PURE__ */ createTextVNode(". This is the 2.x replacement for "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-layout"),
  /* @__PURE__ */ createTextVNode(" in 1.x.")
], -1);
const _hoisted_22 = { id: "v-spacer" };
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-spacer"),
  /* @__PURE__ */ createTextVNode(" is a basic yet versatile spacing component used to distribute remaining width in-between a parents child components. When placing a single "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-spacer"),
  /* @__PURE__ */ createTextVNode(" before or after the child components, the components will push to the right and left of its container. When more than one "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-spacer"),
  /* @__PURE__ */ createTextVNode("’s are used between multiple components, the remaining width is evenly distributed between each spacer.")
], -1);
const _hoisted_24 = { id: "helper-classes" };
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The class "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "fill-height"),
  /* @__PURE__ */ createTextVNode(" applies "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "height: 100%"),
  /* @__PURE__ */ createTextVNode(" to an element. When applied to "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-container"),
  /* @__PURE__ */ createTextVNode(" it will also set "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "align-items: center"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_26 = { id: "caveats" };
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Breakpoints based props on grid components work in an "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "andUp"),
  /* @__PURE__ */ createTextVNode(" fashion. With this in mind the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "xs"),
  /* @__PURE__ */ createTextVNode(" breakpoint is assumed and has been removed from the props context. This applies to "),
  /* @__PURE__ */ createBaseVNode("strong", null, "offset"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "justify"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "align"),
  /* @__PURE__ */ createTextVNode(", and single breakpoint props on "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-col")
], -1);
const _hoisted_28 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Props like "),
    /* @__PURE__ */ createBaseVNode("strong", null, "justify-sm"),
    /* @__PURE__ */ createTextVNode(" and "),
    /* @__PURE__ */ createBaseVNode("strong", null, "justify-md"),
    /* @__PURE__ */ createTextVNode(" exist, but "),
    /* @__PURE__ */ createBaseVNode("strong", null, "justify-xs"),
    /* @__PURE__ */ createTextVNode(" does not, it is simply "),
    /* @__PURE__ */ createBaseVNode("strong", null, "justify")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("The "),
    /* @__PURE__ */ createBaseVNode("strong", null, "xs"),
    /* @__PURE__ */ createTextVNode(" prop does not exist on "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-col"),
    /* @__PURE__ */ createTextVNode(". The equivalent to this is the "),
    /* @__PURE__ */ createBaseVNode("strong", null, "cols"),
    /* @__PURE__ */ createTextVNode(" prop")
  ])
], -1);
const _hoisted_29 = { id: "examples" };
const _hoisted_30 = { id: "props" };
const _hoisted_31 = { id: "align" };
const _hoisted_32 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Change the vertical alignment of flex items and their parents using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "align"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "align-self"),
  /* @__PURE__ */ createTextVNode(" properties.")
], -1);
const _hoisted_33 = { id: "breakpoint-sizing" };
const _hoisted_34 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Columns will automatically take up an equal amount of space within their parent container. This can be modified using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "cols"),
  /* @__PURE__ */ createTextVNode(" prop. You can also utilize the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "sm"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "md"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "lg"),
  /* @__PURE__ */ createTextVNode(", and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "xl"),
  /* @__PURE__ */ createTextVNode(" props to further define how the column will be sized in different viewport sizes.")
], -1);
const _hoisted_35 = { id: "justify" };
const _hoisted_36 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Change the horizontal alignment of flex items using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "justify"),
  /* @__PURE__ */ createTextVNode(" property.")
], -1);
const _hoisted_37 = { id: "no-gutters" };
const _hoisted_38 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can remove the negative margins from "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-row"),
  /* @__PURE__ */ createTextVNode(" and the padding from its direct "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-col"),
  /* @__PURE__ */ createTextVNode(" children using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "no-gutters"),
  /* @__PURE__ */ createTextVNode(" property.")
], -1);
const _hoisted_39 = { id: "offset" };
const _hoisted_40 = /* @__PURE__ */ createBaseVNode("p", null, "Offsets are useful for compensating for elements that may not be visible yet, or to control the position of content. Just as with breakpoints, you can set an offset for any available sizes. This allows you to fine tune your application layout precisely to your needs.", -1);
const _hoisted_41 = { id: "offset-breakpoint" };
const _hoisted_42 = /* @__PURE__ */ createBaseVNode("p", null, "Offset can also be applied on a per breakpoint basis.", -1);
const _hoisted_43 = { id: "order" };
const _hoisted_44 = /* @__PURE__ */ createBaseVNode("p", null, "You can control the ordering of grid items. As with offsets, you can set different orders for different sizes. Design specialized screen layouts that accommodate to any application.", -1);
const _hoisted_45 = { id: "order-first-and-last" };
const _hoisted_46 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can also designate explicitly "),
  /* @__PURE__ */ createBaseVNode("strong", null, "first"),
  /* @__PURE__ */ createTextVNode(" or "),
  /* @__PURE__ */ createBaseVNode("strong", null, "last"),
  /* @__PURE__ */ createTextVNode(" which will assign "),
  /* @__PURE__ */ createBaseVNode("strong", null, "-1"),
  /* @__PURE__ */ createTextVNode(" or "),
  /* @__PURE__ */ createBaseVNode("strong", null, "13"),
  /* @__PURE__ */ createTextVNode(" values respectively to the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "order"),
  /* @__PURE__ */ createTextVNode(" CSS property.")
], -1);
const _hoisted_47 = { id: "misc" };
const _hoisted_48 = { id: "column-wrapping" };
const _hoisted_49 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("When more than 12 columns are placed within a given row (that is not using the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".flex-nowrap"),
  /* @__PURE__ */ createTextVNode(" utility class), each group of extra columns will wrap onto a new line.")
], -1);
const _hoisted_50 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("In the example below, the first and second "),
  /* @__PURE__ */ createBaseVNode("strong", null, "v-col"),
  /* @__PURE__ */ createTextVNode(" components are a total of 13 columns wide, which means the second "),
  /* @__PURE__ */ createBaseVNode("strong", null, "v-col"),
  /* @__PURE__ */ createTextVNode(" gets wrapped to a new line.")
], -1);
const _hoisted_51 = { id: "equal-width-columns" };
const _hoisted_52 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can break equal width columns into multiple lines using "),
  /* @__PURE__ */ createBaseVNode("strong", null, "v-responsive"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_53 = { id: "grow-and-shrink" };
const _hoisted_54 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("By default, flex components will automatically fill the available space in a row or column. They will also shrink relative to the rest of the flex items in the flex container when a specific size is not designated. You can define the column width of the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-col"),
  /* @__PURE__ */ createTextVNode(" by using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "cols"),
  /* @__PURE__ */ createTextVNode(" prop and providing a value from "),
  /* @__PURE__ */ createBaseVNode("strong", null, "1 to 12"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_55 = { id: "margin-helpers" };
const _hoisted_56 = { id: "nested-grid" };
const _hoisted_57 = /* @__PURE__ */ createBaseVNode("p", null, "Grids can be nested, similar to other frameworks, in order to achieve very custom layouts.", -1);
const _hoisted_58 = { id: "one-column-width" };
const _hoisted_59 = /* @__PURE__ */ createBaseVNode("p", null, "When using the auto-layout, you can define the width of only one column and still have its siblings to automatically resize around it.", -1);
const _hoisted_60 = { id: "row-and-column-breakpoints" };
const _hoisted_61 = /* @__PURE__ */ createBaseVNode("p", null, "Dynamically change your layout based upon resolution. Resize your screen and watch the row layout change on sm, md, and lg breakpoints.", -1);
const _hoisted_62 = { id: "spacers" };
const _hoisted_63 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-spacer"),
  /* @__PURE__ */ createTextVNode(" component is useful when you want to fill available space or make space between two components.")
], -1);
const frontmatter = { "meta": { "nav": "Grids", "title": "Grid system", "description": "Vuetify supports the 12 point Material Design grid for laying out and controlling breakpoints for your application.", "keywords": "grids, vuetify grid component, layout component, flex component" }, "related": ["/styles/flex", "/features/display-and-platform/", "/styles/display"], "features": { "github": "/components/VGrid/", "label": "C: VGrid", "report": true, "spec": "https://m2.material.io/design/layout/responsive-layout-grid" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "grids",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Grids", "title": "Grid system", "description": "Vuetify supports the 12 point Material Design grid for laying out and controlling breakpoints for your application.", "keywords": "grids, vuetify grid component, layout component, flex component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Grids", "title": "Grid system", "description": "Vuetify supports the 12 point Material Design grid for laying out and controlling breakpoints for your application.", "keywords": "grids, vuetify grid component, layout component, flex component" }, "related": ["/styles/flex", "/features/display-and-platform/", "/styles/display"], "features": { "github": "/components/VGrid/", "label": "C: VGrid", "report": true, "spec": "https://m2.material.io/design/layout/responsive-layout-grid" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_app_link = resolveComponent("app-link");
      const _component_page_features = resolveComponent("page-features");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_features_breakpoints_table = resolveComponent("features-breakpoints-table");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_alert = resolveComponent("alert");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#grid-system",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Grid system")
                ]),
                _: 1
              }),
              _hoisted_2,
              createBaseVNode("p", null, [
                createTextVNode("The grid is used to create specific layouts within an application’s content. It contains 5 types of media breakpoints that are used for targeting specific screen sizes or orientations: "),
                _hoisted_3,
                createTextVNode(", "),
                _hoisted_4,
                createTextVNode(", "),
                _hoisted_5,
                createTextVNode(", "),
                _hoisted_6,
                createTextVNode(" and "),
                _hoisted_7,
                createTextVNode(". These breakpoints are defined below in the Viewport Breakpoints table and can be modified by customizing the "),
                createVNode(_component_app_link, { href: "/features/display-and-platform" }, {
                  default: withCtx(() => [
                    createTextVNode("Breakpoint service")
                  ]),
                  _: 1
                }),
                createTextVNode(".")
              ]),
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_8, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("The Vuetify grid is heavily inspired by the "),
                  createVNode(_component_app_link, { href: "https://getbootstrap.com/docs/4.0/layout/grid/" }, {
                    default: withCtx(() => [
                      createTextVNode("Bootstrap grid")
                    ]),
                    _: 1
                  }),
                  createTextVNode(". It is implemented by using a series of containers, rows, and columns to layout and align content. If you are new to flexbox, read the "),
                  createVNode(_component_app_link, { href: "https://css-tricks.com/snippets/css/a-guide-to-flexbox/#flexbox-background" }, {
                    default: withCtx(() => [
                      createTextVNode("CSS Tricks flexbox guide")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" for background, terminology, guidelines, and code snippets.")
                ]),
                createVNode(_component_examples_example, { file: "grid/usage" }),
                createVNode(_component_features_breakpoints_table),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_9, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_10,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-container/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-container")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_11
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-row/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-row")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_12
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-col/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-col")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_13
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-spacer/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-spacer")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_14
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_15, [
                createVNode(_component_app_heading, {
                  href: "#sub-components",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Sub-components")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_16, [
                  createVNode(_component_app_heading, {
                    href: "#v-container",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v-container")
                    ]),
                    _: 1
                  }),
                  _hoisted_17
                ]),
                createBaseVNode("section", _hoisted_18, [
                  createVNode(_component_app_heading, {
                    href: "#v-col",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v-col")
                    ]),
                    _: 1
                  }),
                  _hoisted_19
                ]),
                createBaseVNode("section", _hoisted_20, [
                  createVNode(_component_app_heading, {
                    href: "#v-row",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v-row")
                    ]),
                    _: 1
                  }),
                  _hoisted_21
                ]),
                createBaseVNode("section", _hoisted_22, [
                  createVNode(_component_app_heading, {
                    href: "#v-spacer",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v-spacer")
                    ]),
                    _: 1
                  }),
                  _hoisted_23
                ])
              ]),
              createBaseVNode("section", _hoisted_24, [
                createVNode(_component_app_heading, {
                  href: "#helper-classes",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Helper Classes")
                  ]),
                  _: 1
                }),
                _hoisted_25
              ]),
              createBaseVNode("section", _hoisted_26, [
                createVNode(_component_app_heading, {
                  href: "#caveats",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Caveats")
                  ]),
                  _: 1
                }),
                createVNode(_component_alert, { type: "info" }, {
                  default: withCtx(() => [
                    _hoisted_27,
                    _hoisted_28
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_29, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_30, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_31, [
                    createVNode(_component_app_heading, {
                      href: "#align",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Align")
                      ]),
                      _: 1
                    }),
                    _hoisted_32,
                    createVNode(_component_examples_example, { file: "grid/prop-align" })
                  ]),
                  createBaseVNode("section", _hoisted_33, [
                    createVNode(_component_app_heading, {
                      href: "#breakpoint-sizing",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Breakpoint sizing")
                      ]),
                      _: 1
                    }),
                    _hoisted_34,
                    createVNode(_component_examples_example, { file: "grid/prop-breakpoint-sizing" })
                  ]),
                  createBaseVNode("section", _hoisted_35, [
                    createVNode(_component_app_heading, {
                      href: "#justify",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Justify")
                      ]),
                      _: 1
                    }),
                    _hoisted_36,
                    createVNode(_component_examples_example, { file: "grid/prop-justify" })
                  ]),
                  createBaseVNode("section", _hoisted_37, [
                    createVNode(_component_app_heading, {
                      href: "#no-gutters",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("No gutters")
                      ]),
                      _: 1
                    }),
                    _hoisted_38,
                    createVNode(_component_examples_example, { file: "grid/prop-no-gutters" })
                  ]),
                  createBaseVNode("section", _hoisted_39, [
                    createVNode(_component_app_heading, {
                      href: "#offset",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Offset")
                      ]),
                      _: 1
                    }),
                    _hoisted_40,
                    createVNode(_component_examples_example, { file: "grid/prop-offset" })
                  ]),
                  createBaseVNode("section", _hoisted_41, [
                    createVNode(_component_app_heading, {
                      href: "#offset-breakpoint",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Offset breakpoint")
                      ]),
                      _: 1
                    }),
                    _hoisted_42,
                    createVNode(_component_examples_example, { file: "grid/prop-offset-breakpoint" })
                  ]),
                  createBaseVNode("section", _hoisted_43, [
                    createVNode(_component_app_heading, {
                      href: "#order",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Order")
                      ]),
                      _: 1
                    }),
                    _hoisted_44,
                    createVNode(_component_examples_example, { file: "grid/prop-order" })
                  ]),
                  createBaseVNode("section", _hoisted_45, [
                    createVNode(_component_app_heading, {
                      href: "#order-first-and-last",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Order first and last")
                      ]),
                      _: 1
                    }),
                    _hoisted_46,
                    createVNode(_component_examples_example, { file: "grid/prop-order-first-and-last" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_47, [
                  createVNode(_component_app_heading, {
                    href: "#misc",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Misc")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_48, [
                    createVNode(_component_app_heading, {
                      href: "#column-wrapping",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Column wrapping")
                      ]),
                      _: 1
                    }),
                    _hoisted_49,
                    _hoisted_50,
                    createVNode(_component_examples_example, { file: "grid/misc-column-wrapping" })
                  ]),
                  createBaseVNode("section", _hoisted_51, [
                    createVNode(_component_app_heading, {
                      href: "#equal-width-columns",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Equal width columns")
                      ]),
                      _: 1
                    }),
                    _hoisted_52,
                    createVNode(_component_examples_example, { file: "grid/misc-equal-width-columns" })
                  ]),
                  createBaseVNode("section", _hoisted_53, [
                    createVNode(_component_app_heading, {
                      href: "#grow-and-shrink",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Grow and Shrink")
                      ]),
                      _: 1
                    }),
                    _hoisted_54,
                    createVNode(_component_examples_example, { file: "grid/misc-grow-and-shrink" })
                  ]),
                  createBaseVNode("section", _hoisted_55, [
                    createVNode(_component_app_heading, {
                      href: "#margin-helpers",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Margin helpers")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("Using the "),
                      createVNode(_component_app_link, { href: "/styles/flex#auto-margins" }, {
                        default: withCtx(() => [
                          createTextVNode("auto margin helper utilities")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" you can force sibling columns away from each other.")
                    ]),
                    createVNode(_component_examples_example, { file: "grid/misc-margin-helpers" })
                  ]),
                  createBaseVNode("section", _hoisted_56, [
                    createVNode(_component_app_heading, {
                      href: "#nested-grid",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Nested grid")
                      ]),
                      _: 1
                    }),
                    _hoisted_57,
                    createVNode(_component_examples_example, { file: "grid/misc-nested-grid" })
                  ]),
                  createBaseVNode("section", _hoisted_58, [
                    createVNode(_component_app_heading, {
                      href: "#one-column-width",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("One column width")
                      ]),
                      _: 1
                    }),
                    _hoisted_59,
                    createVNode(_component_examples_example, { file: "grid/misc-one-column-width" })
                  ]),
                  createBaseVNode("section", _hoisted_60, [
                    createVNode(_component_app_heading, {
                      href: "#row-and-column-breakpoints",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Row and column breakpoints")
                      ]),
                      _: 1
                    }),
                    _hoisted_61,
                    createVNode(_component_examples_example, { file: "grid/misc-row-and-column-breakpoints" })
                  ]),
                  createBaseVNode("section", _hoisted_62, [
                    createVNode(_component_app_heading, {
                      href: "#spacers",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Spacers")
                      ]),
                      _: 1
                    }),
                    _hoisted_63,
                    createVNode(_component_examples_example, { file: "grid/misc-spacer" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
