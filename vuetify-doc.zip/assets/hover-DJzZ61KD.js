import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "hover" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-hover"),
  /* @__PURE__ */ createTextVNode(" component provides a simple interface for handling hover states for any component.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-hover"),
  /* @__PURE__ */ createTextVNode(" is a renderless component that uses the default slot to provide scoped access to its internal model; as well as mouse event listeners to modify it. To explicitly control the internal state, use the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "model-value"),
  /* @__PURE__ */ createTextVNode(" property.")
], -1);
const _hoisted_5 = { id: "api" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_8 = { id: "examples" };
const _hoisted_9 = { id: "props" };
const _hoisted_10 = { id: "disabled" };
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "disabled"),
  /* @__PURE__ */ createTextVNode(" prop disables the hover functionality.")
], -1);
const _hoisted_12 = { id: "open-and-close-delay" };
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Delay "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-hover"),
  /* @__PURE__ */ createTextVNode(" events by using "),
  /* @__PURE__ */ createBaseVNode("strong", null, "open-delay"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "close-delay"),
  /* @__PURE__ */ createTextVNode(" props in combination or separately.")
], -1);
const _hoisted_14 = { id: "misc" };
const _hoisted_15 = { id: "hover-list" };
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-hover"),
  /* @__PURE__ */ createTextVNode(" can be used in combination with "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-for"),
  /* @__PURE__ */ createTextVNode(" to make a single item stand out when the user interacts with the list.")
], -1);
const _hoisted_17 = { id: "transition" };
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("p", null, "Create highly customized components that respond to user interaction.", -1);
const frontmatter = { "meta": { "nav": "Hover", "title": "Hover component", "description": "The hover component makes it easy respond when the user hover events by wrapping selectable content.", "keywords": "hover, vuetify hover component, vue hover component" }, "related": ["/components/cards/", "/components/images/", "/components/tooltips/"], "features": { "github": "/components/VHover/", "label": "C: VHover", "report": true } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "hover",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Hover", "title": "Hover component", "description": "The hover component makes it easy respond when the user hover events by wrapping selectable content.", "keywords": "hover, vuetify hover component, vue hover component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Hover", "title": "Hover component", "description": "The hover component makes it easy respond when the user hover events by wrapping selectable content.", "keywords": "hover, vuetify hover component, vue hover component" }, "related": ["/components/cards/", "/components/images/", "/components/tooltips/"], "features": { "github": "/components/VHover/", "label": "C: VHover", "report": true } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#hover",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Hover")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_usage, { name: "v-hover" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_6,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-hover/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-hover")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_8, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_9, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_10, [
                    createVNode(_component_app_heading, {
                      href: "#disabled",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Disabled")
                      ]),
                      _: 1
                    }),
                    _hoisted_11,
                    createVNode(_component_examples_example, { file: "v-hover/prop-disabled" })
                  ]),
                  createBaseVNode("section", _hoisted_12, [
                    createVNode(_component_app_heading, {
                      href: "#open-and-close-delay",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Open and close delay")
                      ]),
                      _: 1
                    }),
                    _hoisted_13,
                    createVNode(_component_examples_example, { file: "v-hover/prop-open-and-close-delay" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_14, [
                  createVNode(_component_app_heading, {
                    href: "#misc",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Misc")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_15, [
                    createVNode(_component_app_heading, {
                      href: "#hover-list",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Hover list")
                      ]),
                      _: 1
                    }),
                    _hoisted_16,
                    createVNode(_component_examples_example, { file: "v-hover/misc-hover-list" })
                  ]),
                  createBaseVNode("section", _hoisted_17, [
                    createVNode(_component_app_heading, {
                      href: "#transition",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Transition")
                      ]),
                      _: 1
                    }),
                    _hoisted_18,
                    createVNode(_component_examples_example, { file: "v-hover/misc-transition" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
