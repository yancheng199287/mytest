import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "icons" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-icon", -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "mdi-", -1);
const _hoisted_4 = { id: "usage" };
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("p", null, "Icons come in two themes (light and dark), and five different sizes (x-small, small, medium (default), large, and x-large).", -1);
const _hoisted_6 = { id: "api" };
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_9 = { id: "examples" };
const _hoisted_10 = { id: "props" };
const _hoisted_11 = { id: "color" };
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("p", null, "Using color helpers you can change the color of an icon from the standard dark and light themes.", -1);
const _hoisted_13 = { id: "misc" };
const _hoisted_14 = { id: "buttons" };
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("p", null, "Icons can be used inside of buttons to add emphasis to the action.", -1);
const _hoisted_16 = { id: "font-awesome" };
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "fa-", -1);
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "mdi", -1);
const _hoisted_19 = { id: "material-design" };
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "mdi", -1);
const _hoisted_21 = { id: "mdi-svg" };
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "mdi", -1);
const _hoisted_23 = { id: "accessibility" };
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("p", null, "Icons can convey all sorts of meaningful information, so it’s important that they reach the largest amount of people possible. There are two use cases you’ll want to consider:", -1);
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("p", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "Decorative Icons"),
      /* @__PURE__ */ createTextVNode(" are only being used for visual or branding reinforcement. If they were removed from the page, users would still understand and be able to use your page.")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("p", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "Semantic Icons"),
      /* @__PURE__ */ createTextVNode(" are ones that you’re using to convey meaning, rather than just pure decoration. This includes icons without text next to them used as interactive controls — buttons, form elements, toggles, etc.")
    ])
  ])
], -1);
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, 'aria-hidden="false"', -1);
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("WIP: Our team will change to the component to not render "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, 'aria-hidden="false"'),
  /* @__PURE__ */ createTextVNode(" when you pass a label prop.")
], -1);
const _hoisted_28 = { id: "decorative-font-icons" };
const _hoisted_29 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("If your icons are purely decorative, you’ll need to manually add an attribute to each of your icons so they’re accessible."),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "aria-hidden"),
  /* @__PURE__ */ createTextVNode("(automatically by vuetify)")
], -1);
const _hoisted_30 = { id: "semantic-font-icons" };
const _hoisted_31 = /* @__PURE__ */ createBaseVNode("p", null, "If your icons have semantic meaning, you need to provide a text alternative inside a (or similar) element. Also include appropriate CSS to visually hide the element while keeping it accessible to assistive technologies.", -1);
const _hoisted_32 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-html" }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-icon")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "aria-hidden"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("false"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n  mdi-account\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("v-icon")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_33 = { id: "decorative-svg-icons" };
const _hoisted_34 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("If your icons are purely decorative, you’ll need to manually add an attribute to each of your icons so they’re accessible."),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "aria-hidden"),
  /* @__PURE__ */ createTextVNode("(automatically by vuetify)")
], -1);
const _hoisted_35 = { id: "semantic-svg-icons" };
const _hoisted_36 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, 'role="img"', -1);
const _hoisted_37 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "Component.vue",
    class: "language-html"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-icon")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "aria-label"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("My Account"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "role"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("img"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "aria-hidden"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("false"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n  mdiAccount\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("v-icon")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("script")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "setup"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token script" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token language-javascript" }, [
        /* @__PURE__ */ createTextVNode("\n"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode(" mdiAccount "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"@mdi/js"'),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ";"),
        /* @__PURE__ */ createTextVNode("\n\n"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "const"),
        /* @__PURE__ */ createTextVNode(" icons "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "="),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode(" mdiAccount "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createTextVNode("\n")
      ])
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("script")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const frontmatter = { "meta": { "nav": "Icons", "title": "Icon component", "description": "The icon component is compatible with multiple common icon fonts such as Material Design Icons, Font Awesome and more.", "keywords": "icons, vuetify icon component, vue icon component" }, "related": ["/features/icon-fonts/", "/components/buttons/", "/components/cards/"], "assets": ["https://use.fontawesome.com/releases/v5.0.13/css/all.css", "https://fonts.googleapis.com/icon?family=Material+Icons"], "features": { "figma": true, "github": "/components/VIcon/", "label": "C: VIcon", "report": true, "spec": "https://m2.material.io/design/iconography/system-icons.html" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "icons",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Icons", "title": "Icon component", "description": "The icon component is compatible with multiple common icon fonts such as Material Design Icons, Font Awesome and more.", "keywords": "icons, vuetify icon component, vue icon component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Icons", "title": "Icon component", "description": "The icon component is compatible with multiple common icon fonts such as Material Design Icons, Font Awesome and more.", "keywords": "icons, vuetify icon component, vue icon component" }, "related": ["/features/icon-fonts/", "/components/buttons/", "/components/cards/"], "assets": ["https://use.fontawesome.com/releases/v5.0.13/css/all.css", "https://fonts.googleapis.com/icon?family=Material+Icons"], "features": { "figma": true, "github": "/components/VIcon/", "label": "C: VIcon", "report": true, "spec": "https://m2.material.io/design/iconography/system-icons.html" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_app_link = resolveComponent("app-link");
      const _component_page_features = resolveComponent("page-features");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_alert = resolveComponent("alert");
      const _component_app_markup = resolveComponent("app-markup");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#icons",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Icons")
                ]),
                _: 1
              }),
              createBaseVNode("p", null, [
                createTextVNode("The "),
                _hoisted_2,
                createTextVNode(" component provides a large set of glyphs to provide context to various aspects of your application. For a list of all available icons, visit the official "),
                createVNode(_component_app_link, { href: "https://materialdesignicons.com/" }, {
                  default: withCtx(() => [
                    createTextVNode("Material Design Icons")
                  ]),
                  _: 1
                }),
                createTextVNode(" page. To use any of these icons simply use the "),
                _hoisted_3,
                createTextVNode(" prefix followed by the icon name.")
              ]),
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_4, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_5,
                createVNode(_component_examples_usage, { name: "v-icon" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_6, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_7,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-icon/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-icon")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_8
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_9, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_10, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_11, [
                    createVNode(_component_app_heading, {
                      href: "#color",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Color")
                      ]),
                      _: 1
                    }),
                    _hoisted_12,
                    createVNode(_component_examples_example, { file: "v-icon/prop-color" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_13, [
                  createVNode(_component_app_heading, {
                    href: "#misc",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Misc")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_14, [
                    createVNode(_component_app_heading, {
                      href: "#buttons",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Buttons")
                      ]),
                      _: 1
                    }),
                    _hoisted_15,
                    createVNode(_component_examples_example, { file: "v-icon/misc-buttons" })
                  ]),
                  createBaseVNode("section", _hoisted_16, [
                    createVNode(_component_app_heading, {
                      href: "#font-awesome",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Font Awesome")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createVNode(_component_app_link, { href: "https://fontawesome.com/icons/" }, {
                        default: withCtx(() => [
                          createTextVNode("Font Awesome")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" is also supported. Simply use the "),
                      _hoisted_17,
                      createTextVNode(" prefixed icon name. Please note that you still need to include the Font Awesome icons in your project. For more information on how to install it, please navigate to the "),
                      createVNode(_component_app_link, { href: "/features/icon-fonts#install-font-awesome-5-icons" }, {
                        default: withCtx(() => [
                          createTextVNode("installation page")
                        ]),
                        _: 1
                      })
                    ]),
                    createVNode(_component_alert, { type: "info" }, {
                      default: withCtx(() => [
                        createBaseVNode("p", null, [
                          createTextVNode("Note that this example is using an icon set prefix, because the default icon set in the documentation is "),
                          _hoisted_18,
                          createTextVNode(". You can read more about using multiple icon sets "),
                          createVNode(_component_app_link, { href: "/features/icon-fonts/#multiple-icon-sets" }, {
                            default: withCtx(() => [
                              createTextVNode("here")
                            ]),
                            _: 1
                          })
                        ])
                      ]),
                      _: 1
                    }),
                    createVNode(_component_examples_example, { file: "v-icon/misc-font-awesome" })
                  ]),
                  createBaseVNode("section", _hoisted_19, [
                    createVNode(_component_app_heading, {
                      href: "#material-design",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Material Design")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createVNode(_component_app_link, { href: "https://fonts.google.com/icons" }, {
                        default: withCtx(() => [
                          createTextVNode("Material Design")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" is also supported. For more information on how to install it please "),
                      createVNode(_component_app_link, { href: "/features/icon-fonts#install-material-icons" }, {
                        default: withCtx(() => [
                          createTextVNode("navigate here")
                        ]),
                        _: 1
                      })
                    ]),
                    createVNode(_component_alert, { type: "info" }, {
                      default: withCtx(() => [
                        createBaseVNode("p", null, [
                          createTextVNode("Note that this example is using an icon set prefix, because the default icon set in the documentation is "),
                          _hoisted_20,
                          createTextVNode(". You can read more about using multiple icon sets "),
                          createVNode(_component_app_link, { href: "/features/icon-fonts/#multiple-icon-sets" }, {
                            default: withCtx(() => [
                              createTextVNode("here")
                            ]),
                            _: 1
                          })
                        ])
                      ]),
                      _: 1
                    }),
                    createVNode(_component_examples_example, { file: "v-icon/misc-md" })
                  ]),
                  createBaseVNode("section", _hoisted_21, [
                    createVNode(_component_app_heading, {
                      href: "#mdi-svg",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("MDI SVG")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("You can manually import only the icons you use when using the "),
                      createVNode(_component_app_link, { href: "https://www.npmjs.com/package/@mdi/js" }, {
                        default: withCtx(() => [
                          createTextVNode("@mdi/js")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" package. Read more about using them "),
                      createVNode(_component_app_link, { href: "/features/icon-fonts#material-design-icons-js-svg" }, {
                        default: withCtx(() => [
                          createTextVNode("here")
                        ]),
                        _: 1
                      }),
                      createTextVNode(".")
                    ]),
                    createVNode(_component_alert, { type: "info" }, {
                      default: withCtx(() => [
                        createBaseVNode("p", null, [
                          createTextVNode("Note that this example is using an icon set prefix, because the default icon set in the documentation is "),
                          _hoisted_22,
                          createTextVNode(". You can read more about using multiple icon sets "),
                          createVNode(_component_app_link, { href: "/features/icon-fonts/#multiple-icon-sets" }, {
                            default: withCtx(() => [
                              createTextVNode("here")
                            ]),
                            _: 1
                          })
                        ])
                      ]),
                      _: 1
                    }),
                    createVNode(_component_examples_example, { file: "v-icon/misc-mdi-svg" })
                  ])
                ])
              ]),
              createBaseVNode("section", _hoisted_23, [
                createVNode(_component_app_heading, {
                  href: "#accessibility",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Accessibility")
                  ]),
                  _: 1
                }),
                _hoisted_24,
                _hoisted_25,
                createVNode(_component_alert, { type: "error" }, {
                  default: withCtx(() => [
                    createBaseVNode("p", null, [
                      createTextVNode("WAI-ARIA Authoring Practices 1.1 notes that "),
                      _hoisted_26,
                      createTextVNode(" currently "),
                      createVNode(_component_app_link, { href: "https://www.w3.org/TR/wai-aria-1.1/#aria-hidden" }, {
                        default: withCtx(() => [
                          createTextVNode("behaves inconsistently across browsers")
                        ]),
                        _: 1
                      }),
                      createTextVNode(".")
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_alert, { type: "info" }, {
                  default: withCtx(() => [
                    _hoisted_27
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_28, [
                  createVNode(_component_app_heading, {
                    href: "#decorative-font-icons",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Decorative Font Icons")
                    ]),
                    _: 1
                  }),
                  _hoisted_29
                ]),
                createBaseVNode("section", _hoisted_30, [
                  createVNode(_component_app_heading, {
                    href: "#semantic-font-icons",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Semantic Font Icons")
                    ]),
                    _: 1
                  }),
                  _hoisted_31,
                  createVNode(_component_app_markup, {
                    resource: "",
                    class: "mb-4"
                  }, {
                    default: withCtx(() => [
                      _hoisted_32
                    ]),
                    _: 1
                  })
                ]),
                createBaseVNode("section", _hoisted_33, [
                  createVNode(_component_app_heading, {
                    href: "#decorative-svg-icons",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Decorative SVG Icons")
                    ]),
                    _: 1
                  }),
                  _hoisted_34
                ]),
                createBaseVNode("section", _hoisted_35, [
                  createVNode(_component_app_heading, {
                    href: "#semantic-svg-icons",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Semantic SVG Icons")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("p", null, [
                    createTextVNode("Apply accessibility attributes to the "),
                    createVNode(_component_app_link, { href: "/components/icons/" }, {
                      default: withCtx(() => [
                        createTextVNode("v-icon")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" component, such as "),
                    _hoisted_36,
                    createTextVNode(", to give it a semantic meaning.")
                  ]),
                  createVNode(_component_app_markup, {
                    resource: "Component.vue",
                    class: "mb-4"
                  }, {
                    default: withCtx(() => [
                      _hoisted_37
                    ]),
                    _: 1
                  })
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
