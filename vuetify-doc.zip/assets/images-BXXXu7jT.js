import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "images" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-img", -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-img"),
  /* @__PURE__ */ createTextVNode(" component is used to display a responsive image with lazy-load and placeholder.")
], -1);
const _hoisted_5 = { id: "api" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_8 = { id: "caveats" };
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "lazy-src"),
  /* @__PURE__ */ createTextVNode(" property has no effect unless either "),
  /* @__PURE__ */ createBaseVNode("strong", null, "height"),
  /* @__PURE__ */ createTextVNode(" or "),
  /* @__PURE__ */ createBaseVNode("strong", null, "aspect-ratio"),
  /* @__PURE__ */ createTextVNode(" are provided. This is because the image container needs a non-zero height in order for the temporary image to be shown.")
], -1);
const _hoisted_10 = { id: "examples" };
const _hoisted_11 = { id: "props" };
const _hoisted_12 = { id: "cover" };
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("If the provided aspect ratio doesn’t match that of the actual image, the default behavior is to fill as much space as possible without cropping. To fill the entire available space use the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "cover"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_14 = { id: "height" };
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-img"),
  /* @__PURE__ */ createTextVNode(" will automatically grow to the size of its "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "src"),
  /* @__PURE__ */ createTextVNode(", preserving the correct aspect ratio. You can limit this with the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "height"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "max-height"),
  /* @__PURE__ */ createTextVNode(" props.")
], -1);
const _hoisted_16 = { id: "slots" };
const _hoisted_17 = { id: "placeholder" };
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-img"),
  /* @__PURE__ */ createTextVNode(" has a special "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "placeholder"),
  /* @__PURE__ */ createTextVNode(" slot for placeholder to display while image’s loading. Note: the example below has bad src which won’t load for you to see placeholder.")
], -1);
const _hoisted_19 = { id: "error" };
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-img"),
  /* @__PURE__ */ createTextVNode(" has an "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "error"),
  /* @__PURE__ */ createTextVNode(" slot that can be used to display alternative content if an error occurs while loading your source image. A common use for this slot is to load a fallback image if your original image is not available.")
], -1);
const _hoisted_21 = { id: "misc" };
const _hoisted_22 = { id: "future-image-formats" };
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("By default "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-img"),
  /* @__PURE__ */ createTextVNode(" will render a basic "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<img>"),
  /* @__PURE__ */ createTextVNode(" element. If you want to use "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".webp"),
  /* @__PURE__ */ createTextVNode(" images with a fallback for older browsers, you can pass a list of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<source>"),
  /* @__PURE__ */ createTextVNode(" elements to the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "sources"),
  /* @__PURE__ */ createTextVNode(" slot:")
], -1);
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-html" }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-img")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "src"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("image.jpeg"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "#sources"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("source")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "srcset"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("image.webp"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("v-img")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("p", null, "This will behave similarly to:", -1);
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-html" }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("picture")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("source")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "srcset"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("image.webp"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("img")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "src"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("image.jpeg"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("picture")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "srcset", -1);
const _hoisted_28 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "media", -1);
const _hoisted_29 = { id: "grid" };
const _hoisted_30 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can use "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-img"),
  /* @__PURE__ */ createTextVNode(" to make, for example, a picture gallery.")
], -1);
const _hoisted_31 = { id: "complex-grid-layout" };
const _hoisted_32 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Build a more complex picture gallery layout using "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "flex-box"),
  /* @__PURE__ */ createTextVNode(" classes.")
], -1);
const frontmatter = { "meta": { "nav": "Images", "title": "Image component", "description": "The image component provides a flexible interface for displaying different types of images.", "keywords": "images, vuetify image component, vue image component" }, "related": ["/components/grids", "/components/aspect-ratios", "/components/parallax"], "features": { "github": "/components/VImg/", "label": "C: VImg", "report": true } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "images",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Images", "title": "Image component", "description": "The image component provides a flexible interface for displaying different types of images.", "keywords": "images, vuetify image component, vue image component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Images", "title": "Image component", "description": "The image component provides a flexible interface for displaying different types of images.", "keywords": "images, vuetify image component, vue image component" }, "related": ["/components/grids", "/components/aspect-ratios", "/components/parallax"], "features": { "github": "/components/VImg/", "label": "C: VImg", "report": true } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_app_link = resolveComponent("app-link");
      const _component_page_features = resolveComponent("page-features");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_alert = resolveComponent("alert");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_app_markup = resolveComponent("app-markup");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#images",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Images")
                ]),
                _: 1
              }),
              createBaseVNode("p", null, [
                createTextVNode("The "),
                _hoisted_2,
                createTextVNode(" component is packed with features to support rich media. Combined with the "),
                createVNode(_component_app_link, { href: "https://github.com/vuetifyjs/vuetify-loader" }, {
                  default: withCtx(() => [
                    createTextVNode("vuetify-loader")
                  ]),
                  _: 1
                }),
                createTextVNode(", you can add dynamic progressive images to provide a better user experience.")
              ]),
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_usage, { name: "v-img" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_6,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-img/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-img")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_8, [
                createVNode(_component_app_heading, {
                  href: "#caveats",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Caveats")
                  ]),
                  _: 1
                }),
                createVNode(_component_alert, { type: "warning" }, {
                  default: withCtx(() => [
                    _hoisted_9
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_10, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_11, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_12, [
                    createVNode(_component_app_heading, {
                      href: "#cover",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Cover")
                      ]),
                      _: 1
                    }),
                    _hoisted_13,
                    createVNode(_component_examples_example, { file: "v-img/prop-cover" })
                  ]),
                  createBaseVNode("section", _hoisted_14, [
                    createVNode(_component_app_heading, {
                      href: "#height",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Height")
                      ]),
                      _: 1
                    }),
                    _hoisted_15,
                    createVNode(_component_examples_example, { file: "v-img/prop-max-height" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_16, [
                  createVNode(_component_app_heading, {
                    href: "#slots",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Slots")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_17, [
                    createVNode(_component_app_heading, {
                      href: "#placeholder",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Placeholder")
                      ]),
                      _: 1
                    }),
                    _hoisted_18,
                    createVNode(_component_examples_example, { file: "v-img/slot-placeholder" })
                  ]),
                  createBaseVNode("section", _hoisted_19, [
                    createVNode(_component_app_heading, {
                      href: "#error",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Error")
                      ]),
                      _: 1
                    }),
                    _hoisted_20,
                    createVNode(_component_examples_example, { file: "v-img/slot-error" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_21, [
                  createVNode(_component_app_heading, {
                    href: "#misc",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Misc")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_22, [
                    createVNode(_component_app_heading, {
                      href: "#future-image-formats",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Future image formats")
                      ]),
                      _: 1
                    }),
                    _hoisted_23,
                    createVNode(_component_app_markup, {
                      resource: "",
                      class: "mb-4"
                    }, {
                      default: withCtx(() => [
                        _hoisted_24
                      ]),
                      _: 1
                    }),
                    _hoisted_25,
                    createVNode(_component_app_markup, {
                      resource: "",
                      class: "mb-4"
                    }, {
                      default: withCtx(() => [
                        _hoisted_26
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      _hoisted_27,
                      createTextVNode(" and "),
                      _hoisted_28,
                      createTextVNode(" attributes can also be used for art direction or alternate sizes, see "),
                      createVNode(_component_app_link, { href: "https://developer.mozilla.org/en-US/docs/Web/HTML/Element/picture" }, {
                        default: withCtx(() => [
                          createTextVNode("MDN")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" for more.")
                    ])
                  ]),
                  createBaseVNode("section", _hoisted_29, [
                    createVNode(_component_app_heading, {
                      href: "#grid",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Grid")
                      ]),
                      _: 1
                    }),
                    _hoisted_30,
                    createVNode(_component_examples_example, { file: "v-img/misc-grid" })
                  ]),
                  createBaseVNode("section", _hoisted_31, [
                    createVNode(_component_app_heading, {
                      href: "#complex-grid-layout",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Complex Grid Layout")
                      ]),
                      _: 1
                    }),
                    _hoisted_32,
                    createVNode(_component_examples_example, { file: "v-img/complex-grid" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
