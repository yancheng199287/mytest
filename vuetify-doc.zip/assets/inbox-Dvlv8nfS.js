import { J as ref, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, b as createVNode, h as createTextVNode, l as createElementBlock, v as renderList, F as Fragment, q as createCommentVNode, e as createBaseVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("div", null, "john@google.com", -1);
const _sfc_main = {
  __name: "inbox",
  setup(__props) {
    const cards = ["Today", "Yesterday"];
    const links = [
      ["mdi-inbox-arrow-down", "Inbox"],
      ["mdi-send", "Send"],
      ["mdi-delete", "Trash"],
      ["mdi-alert-octagon", "Spam"]
    ];
    const drawer = ref(null);
    return (_ctx, _cache) => {
      const _component_v_spacer = resolveComponent("v-spacer");
      const _component_v_icon = resolveComponent("v-icon");
      const _component_v_system_bar = resolveComponent("v-system-bar");
      const _component_v_avatar = resolveComponent("v-avatar");
      const _component_v_sheet = resolveComponent("v-sheet");
      const _component_v_divider = resolveComponent("v-divider");
      const _component_v_list_item = resolveComponent("v-list-item");
      const _component_v_list = resolveComponent("v-list");
      const _component_v_navigation_drawer = resolveComponent("v-navigation-drawer");
      const _component_v_list_subheader = resolveComponent("v-list-subheader");
      const _component_v_list_item_title = resolveComponent("v-list-item-title");
      const _component_v_list_item_subtitle = resolveComponent("v-list-item-subtitle");
      const _component_v_card = resolveComponent("v-card");
      const _component_v_col = resolveComponent("v-col");
      const _component_v_row = resolveComponent("v-row");
      const _component_v_container = resolveComponent("v-container");
      const _component_v_main = resolveComponent("v-main");
      const _component_v_app = resolveComponent("v-app");
      return openBlock(), createBlock(_component_v_app, { id: "inspire" }, {
        default: withCtx(() => [
          createVNode(_component_v_system_bar, null, {
            default: withCtx(() => [
              createVNode(_component_v_spacer),
              createVNode(_component_v_icon, null, {
                default: withCtx(() => [
                  createTextVNode("mdi-square")
                ]),
                _: 1
              }),
              createVNode(_component_v_icon, null, {
                default: withCtx(() => [
                  createTextVNode("mdi-circle")
                ]),
                _: 1
              }),
              createVNode(_component_v_icon, null, {
                default: withCtx(() => [
                  createTextVNode("mdi-triangle")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_navigation_drawer, {
            modelValue: drawer.value,
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => drawer.value = $event)
          }, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, {
                class: "pa-4",
                color: "grey-lighten-4"
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_avatar, {
                    class: "mb-4",
                    color: "grey-darken-1",
                    size: "64"
                  }),
                  _hoisted_1
                ]),
                _: 1
              }),
              createVNode(_component_v_divider),
              createVNode(_component_v_list, null, {
                default: withCtx(() => [
                  (openBlock(), createElementBlock(Fragment, null, renderList(links, ([icon, text]) => {
                    return createVNode(_component_v_list_item, {
                      key: icon,
                      "prepend-icon": icon,
                      title: text,
                      link: ""
                    }, null, 8, ["prepend-icon", "title"]);
                  }), 64))
                ]),
                _: 1
              })
            ]),
            _: 1
          }, 8, ["modelValue"]),
          createVNode(_component_v_main, null, {
            default: withCtx(() => [
              createVNode(_component_v_container, {
                class: "py-8 px-6",
                fluid: ""
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_row, null, {
                    default: withCtx(() => [
                      (openBlock(), createElementBlock(Fragment, null, renderList(cards, (card) => {
                        return createVNode(_component_v_col, {
                          key: card,
                          cols: "12"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_v_card, null, {
                              default: withCtx(() => [
                                createVNode(_component_v_list, { lines: "two" }, {
                                  default: withCtx(() => [
                                    createVNode(_component_v_list_subheader, { title: card }, null, 8, ["title"]),
                                    (openBlock(), createElementBlock(Fragment, null, renderList(6, (n) => {
                                      return openBlock(), createElementBlock(Fragment, { key: n }, [
                                        createVNode(_component_v_list_item, null, {
                                          prepend: withCtx(() => [
                                            createVNode(_component_v_avatar, { color: "grey-darken-1" })
                                          ]),
                                          default: withCtx(() => [
                                            createVNode(_component_v_list_item_title, {
                                              title: `Message ${n}`
                                            }, null, 8, ["title"]),
                                            createVNode(_component_v_list_item_subtitle, { title: "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil repellendus distinctio similique" })
                                          ]),
                                          _: 2
                                        }, 1024),
                                        n !== 6 ? (openBlock(), createBlock(_component_v_divider, {
                                          key: `divider-${n}`,
                                          inset: ""
                                        })) : createCommentVNode("", true)
                                      ], 64);
                                    }), 64))
                                  ]),
                                  _: 2
                                }, 1024)
                              ]),
                              _: 2
                            }, 1024)
                          ]),
                          _: 2
                        }, 1024);
                      }), 64))
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __4 = _sfc_main;
export {
  __4 as _
};
