import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "infinite-scrollers" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-infinite-scroll"),
  /* @__PURE__ */ createTextVNode(" component displays a potentially infinite list, by loading more items of the list when scrolling. It supports either vertical or horizontal scrolling.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, "When scrolling towards the bottom, new items will be rendered either automatically, or manually with the click of a button.", -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("A "),
  /* @__PURE__ */ createBaseVNode("strong", null, "load"),
  /* @__PURE__ */ createTextVNode(" event will be emitted when the component needs to load more content. The argument passed is an object with two properties.")
], -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "side"),
    /* @__PURE__ */ createTextVNode(" tells you on which side new content should be added, either at the "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "'start'"),
    /* @__PURE__ */ createTextVNode(" or "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "'end'"),
    /* @__PURE__ */ createTextVNode(". The return value of the function is a string that describes if the new content was loaded successfully or not.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "done"),
    /* @__PURE__ */ createTextVNode(" is a callback function that should be called when the loading of new content is done. It takes a single parameter "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "status"),
    /* @__PURE__ */ createTextVNode(" that describes if the load was successful or not. See the table below for the possible values.")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Status"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("tbody", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "'ok'")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "Content was added succesfully")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "'error'")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("Something went wrong when adding content. This will display the "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "error"),
      /* @__PURE__ */ createTextVNode(" slot")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "'empty'")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("There is no more content to fetch. This will display the "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "empty"),
      /* @__PURE__ */ createTextVNode(" slot")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "'loading'")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("Content is currently loading. This will display a message that the content is loading. This status is only set internally by the component and should not be used with the "),
      /* @__PURE__ */ createBaseVNode("strong", null, "done"),
      /* @__PURE__ */ createTextVNode(" function")
    ])
  ])
], -1);
const _hoisted_9 = { id: "api" };
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_12 = { id: "anatomy" };
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-infinite-scroll"),
  /* @__PURE__ */ createTextVNode(" works with any content in its default slot.")
], -1);
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Element / Area"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("tbody", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "1. Container"),
    /* @__PURE__ */ createBaseVNode("td", null, "The infinite scroller content container")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "2. Loader"),
    /* @__PURE__ */ createBaseVNode("td", null, "The loader content area")
  ])
], -1);
const _hoisted_16 = { id: "guide" };
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-infinite-scroll"),
  /* @__PURE__ */ createTextVNode(" component is a container that allows you to react to a user reaching the end of the content area. It is useful when you need to display an unknown but large number of items, and you don’t want to load them all at once.")
], -1);
const _hoisted_18 = { id: "props" };
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-infinite-scroll"),
  /* @__PURE__ */ createTextVNode(" component has several props that can be used to customize its behavior.")
], -1);
const _hoisted_20 = { id: "mode" };
const _hoisted_21 = { id: "direction" };
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-infinite-scroll"),
  /* @__PURE__ */ createTextVNode(" component can be used with either vertical or horizontal scrolling.")
], -1);
const _hoisted_23 = { id: "side" };
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("By default, the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-infinite-scroll"),
  /* @__PURE__ */ createTextVNode(" component assumes that new content will appear at the end of existing content. But it also supports content being added to the start and appearing both at the beginning and the end.")
], -1);
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("When using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "start"),
  /* @__PURE__ */ createTextVNode(" side for content, the scrollbar will start at the bottom of the content.")
], -1);
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("When using "),
  /* @__PURE__ */ createBaseVNode("strong", null, "both"),
  /* @__PURE__ */ createTextVNode(" sides for content, the scrollbar will start in the middle of the content.")
], -1);
const _hoisted_27 = { id: "color" };
const _hoisted_28 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The default load more button and loading spinner can be colored with the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "color"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_29 = { id: "slots" };
const _hoisted_30 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-infinite-scroll"),
  /* @__PURE__ */ createTextVNode(" component exposes several slots that allow you to further customize its behaviour.")
], -1);
const _hoisted_31 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Element / Area"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_32 = /* @__PURE__ */ createBaseVNode("tbody", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "1. Container"),
    /* @__PURE__ */ createBaseVNode("td", null, "The default slot")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "2. Load-more"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("The slot shown when the mode is set to "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "manual"),
      /* @__PURE__ */ createTextVNode(" and the status is not "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "loading")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "3. Loading"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("The slot is shown when the mode is set to "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "manual"),
      /* @__PURE__ */ createTextVNode(" and status is "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "loading")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "4. Empty"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("The slot shown when the status is "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "empty")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "5. Error"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("The slot is shown when the status is "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "error")
    ])
  ])
], -1);
const _hoisted_33 = { id: "loading" };
const _hoisted_34 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can customize the loading message with the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "loading"),
  /* @__PURE__ */ createTextVNode(" slot.")
], -1);
const _hoisted_35 = { id: "load-more" };
const _hoisted_36 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("When using "),
  /* @__PURE__ */ createBaseVNode("strong", null, "manual"),
  /* @__PURE__ */ createTextVNode(" mode you can customize the action required to load more content with the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "load-more"),
  /* @__PURE__ */ createTextVNode(" slot.")
], -1);
const _hoisted_37 = { id: "empty" };
const _hoisted_38 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can customize the empty message with the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "empty"),
  /* @__PURE__ */ createTextVNode(" slot.")
], -1);
const _hoisted_39 = { id: "error" };
const _hoisted_40 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "error"),
  /* @__PURE__ */ createTextVNode(" slot is shown if the status "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "'error'"),
  /* @__PURE__ */ createTextVNode(" is returned from the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "done"),
  /* @__PURE__ */ createTextVNode(" callback.")
], -1);
const _hoisted_41 = { id: "examples" };
const _hoisted_42 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The following is a collection of examples that demonstrate more advanced and real-world use of the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-infinite-scroll"),
  /* @__PURE__ */ createTextVNode(" component.")
], -1);
const _hoisted_43 = { id: "virtualized-infinite-scroller" };
const _hoisted_44 = /* @__PURE__ */ createBaseVNode("p", null, "If the items in your infinite list are of a uniform size, you can quite easily virtualize the list to only render a small number of items regardless of how far you scroll in either direction.", -1);
const frontmatter = { "meta": { "nav": "Infinite scrollers", "title": "Infinite scroller component", "description": "The Infinite scroll component is a container that loads more items when scrolling. It is useful when you need to display an unknown but large number of items.", "keywords": "infinite scroll, vuetify infinite scroll component, vue infinite scroll component, v-infinite-scroll component" }, "related": ["/components/lists/", "/components/data-tables/basics/", "/components/data-iterators/"], "features": { "github": "/components/VInfiniteScroll/", "label": "C: VInfiniteScroll", "report": true } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "infinite-scroller",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Infinite scrollers", "title": "Infinite scroller component", "description": "The Infinite scroll component is a container that loads more items when scrolling. It is useful when you need to display an unknown but large number of items.", "keywords": "infinite scroll, vuetify infinite scroll component, vue infinite scroll component, v-infinite-scroll component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Infinite scrollers", "title": "Infinite scroller component", "description": "The Infinite scroll component is a container that loads more items when scrolling. It is useful when you need to display an unknown but large number of items.", "keywords": "infinite scroll, vuetify infinite scroll component, vue infinite scroll component, v-infinite-scroll component" }, "related": ["/components/lists/", "/components/data-tables/basics/", "/components/data-iterators/"], "features": { "github": "/components/VInfiniteScroll/", "label": "C: VInfiniteScroll", "report": true } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_app_figure = resolveComponent("app-figure");
      const _component_page_features = resolveComponent("page-features");
      const _component_app_link = resolveComponent("app-link");
      const _component_alert = resolveComponent("alert");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_app_table = resolveComponent("app-table");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#infinite-scrollers",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Infinite scrollers")
                ]),
                _: 1
              }),
              _hoisted_2,
              createBaseVNode("p", null, [
                createBaseVNode("div", null, [
                  createVNode(_component_app_figure, {
                    alt: "Infinite scroll Entry",
                    src: "https://cdn.vuetifyjs.com/docs/images/components/v-infinite-scroll/v-infinite-scroll-entry.png"
                  })
                ])
              ]),
              createVNode(_component_page_features),
              createVNode(_component_alert, { type: "success" }, {
                default: withCtx(() => [
                  createBaseVNode("p", null, [
                    createTextVNode("This feature was introduced in "),
                    createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v3.4.0" }, {
                      default: withCtx(() => [
                        createTextVNode("v3.4.0 (Blackguard)")
                      ]),
                      _: 1
                    })
                  ])
                ]),
                _: 1
              }),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_usage, { name: "v-infinite-scroll" }),
                _hoisted_5,
                _hoisted_6,
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_7,
                    _hoisted_8
                  ]),
                  _: 1
                }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_9, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_10,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-infinite-scroll/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-infinite-scroll")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_11
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_12, [
                createVNode(_component_app_heading, {
                  href: "#anatomy",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Anatomy")
                  ]),
                  _: 1
                }),
                _hoisted_13,
                createBaseVNode("p", null, [
                  createBaseVNode("div", null, [
                    createVNode(_component_app_figure, {
                      alt: "Infinite scroll Anatomy",
                      src: "https://cdn.vuetifyjs.com/docs/images/components/v-infinite-scroll/v-infinite-scroll-anatomy.png"
                    })
                  ])
                ]),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_14,
                    _hoisted_15
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_16, [
                createVNode(_component_app_heading, {
                  href: "#guide",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Guide")
                  ]),
                  _: 1
                }),
                _hoisted_17,
                createBaseVNode("section", _hoisted_18, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  _hoisted_19,
                  createBaseVNode("section", _hoisted_20, [
                    createVNode(_component_app_heading, {
                      href: "#mode",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Mode")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("The default behavior of the component is to try to load more content automatically when the scrollbar gets close to the end. However, a manual mode is also supported, where the user needs to do some interaction to load the content. By default this is a button, but it can be customized with a "),
                      createVNode(_component_app_link, { href: "#load-more" }, {
                        default: withCtx(() => [
                          createTextVNode("slot")
                        ]),
                        _: 1
                      })
                    ]),
                    createVNode(_component_examples_example, { file: "v-infinite-scroll/prop-mode" })
                  ]),
                  createBaseVNode("section", _hoisted_21, [
                    createVNode(_component_app_heading, {
                      href: "#direction",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Direction")
                      ]),
                      _: 1
                    }),
                    _hoisted_22,
                    createVNode(_component_examples_example, { file: "v-infinite-scroll/prop-direction" })
                  ]),
                  createBaseVNode("section", _hoisted_23, [
                    createVNode(_component_app_heading, {
                      href: "#side",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Side")
                      ]),
                      _: 1
                    }),
                    _hoisted_24,
                    _hoisted_25,
                    createVNode(_component_examples_example, { file: "v-infinite-scroll/prop-side-start" }),
                    _hoisted_26,
                    createVNode(_component_examples_example, { file: "v-infinite-scroll/prop-side-both" })
                  ]),
                  createBaseVNode("section", _hoisted_27, [
                    createVNode(_component_app_heading, {
                      href: "#color",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Color")
                      ]),
                      _: 1
                    }),
                    _hoisted_28,
                    createVNode(_component_examples_example, { file: "v-infinite-scroll/prop-color" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_29, [
                  createVNode(_component_app_heading, {
                    href: "#slots",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Slots")
                    ]),
                    _: 1
                  }),
                  _hoisted_30,
                  createBaseVNode("p", null, [
                    createBaseVNode("div", null, [
                      createVNode(_component_app_figure, {
                        alt: "Infinite scroll Slots",
                        src: "https://cdn.vuetifyjs.com/docs/images/components/v-infinite-scroll/v-infinite-scroll-slots.png"
                      })
                    ])
                  ]),
                  createVNode(_component_app_table, null, {
                    default: withCtx(() => [
                      _hoisted_31,
                      _hoisted_32
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_33, [
                    createVNode(_component_app_heading, {
                      href: "#loading",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Loading")
                      ]),
                      _: 1
                    }),
                    _hoisted_34,
                    createVNode(_component_examples_example, { file: "v-infinite-scroll/slot-loading" })
                  ]),
                  createBaseVNode("section", _hoisted_35, [
                    createVNode(_component_app_heading, {
                      href: "#load-more",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Load more")
                      ]),
                      _: 1
                    }),
                    _hoisted_36,
                    createVNode(_component_examples_example, { file: "v-infinite-scroll/slot-load-more" })
                  ]),
                  createBaseVNode("section", _hoisted_37, [
                    createVNode(_component_app_heading, {
                      href: "#empty",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Empty")
                      ]),
                      _: 1
                    }),
                    _hoisted_38,
                    createVNode(_component_examples_example, { file: "v-infinite-scroll/slot-empty" })
                  ]),
                  createBaseVNode("section", _hoisted_39, [
                    createVNode(_component_app_heading, {
                      href: "#error",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Error")
                      ]),
                      _: 1
                    }),
                    _hoisted_40,
                    createVNode(_component_examples_example, { file: "v-infinite-scroll/slot-error" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_41, [
                  createVNode(_component_app_heading, {
                    href: "#examples",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Examples")
                    ]),
                    _: 1
                  }),
                  _hoisted_42,
                  createBaseVNode("section", _hoisted_43, [
                    createVNode(_component_app_heading, {
                      href: "#virtualized-infinite-scroller",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Virtualized infinite scroller")
                      ]),
                      _: 1
                    }),
                    _hoisted_44,
                    createVNode(_component_examples_example, { file: "v-infinite-scroll/misc-virtual" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
