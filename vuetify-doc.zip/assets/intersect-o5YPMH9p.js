import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "intersection-observer" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-intersect", -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = { id: "api" };
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Directive"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("td", null, "The intersection observer directive", -1);
const _hoisted_7 = { id: "examples" };
const _hoisted_8 = { id: "props" };
const _hoisted_9 = { id: "options" };
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-intersect", -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "threshold", -1);
const frontmatter = { "meta": { "nav": "Intersection observer", "title": "Intersection observer directive", "description": "The intersection observer directive utilizes the Intersection observer API. It allows you to determine when elements are visible on the screen.", "keywords": "intersect, vuetify intersect directive, intersection observer directive" }, "related": ["/components/cards/", "/components/images/", "/components/text-fields/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "intersect",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Intersection observer", "title": "Intersection observer directive", "description": "The intersection observer directive utilizes the Intersection observer API. It allows you to determine when elements are visible on the screen.", "keywords": "intersect, vuetify intersect directive, intersection observer directive" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Intersection observer", "title": "Intersection observer directive", "description": "The intersection observer directive utilizes the Intersection observer API. It allows you to determine when elements are visible on the screen.", "keywords": "intersect, vuetify intersect directive, intersection observer directive" }, "related": ["/components/cards/", "/components/images/", "/components/text-fields/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_app_link = resolveComponent("app-link");
      const _component_page_features = resolveComponent("page-features");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#intersection-observer",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Intersection observer")
                ]),
                _: 1
              }),
              createBaseVNode("p", null, [
                createTextVNode("The "),
                _hoisted_2,
                createTextVNode(" directive utilizes the "),
                createVNode(_component_app_link, { href: "https://developer.mozilla.org/en-US/docs/Web/API/Intersection_Observer_API" }, {
                  default: withCtx(() => [
                    createTextVNode("Intersection Observer API")
                  ]),
                  _: 1
                }),
                createTextVNode(". It provides an easy-to-use interface for detecting when elements are visible within the user’s viewport. This is also used for the "),
                createVNode(_component_app_link, { href: "/components/lazy" }, {
                  default: withCtx(() => [
                    createTextVNode("v-lazy")
                  ]),
                  _: 1
                }),
                createTextVNode(" component.")
              ]),
              createVNode(_component_page_features),
              createVNode(_component_promoted_entry),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("Scroll the window and watch the colored dot. Notice as the "),
                  createVNode(_component_app_link, { href: "/components/cards" }, {
                    default: withCtx(() => [
                      createTextVNode("v-card")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" comes into view that it changes from error to success.")
                ]),
                createVNode(_component_examples_example, { file: "v-intersect/usage" })
              ]),
              createBaseVNode("section", _hoisted_4, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_5,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-intersect-directive/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-intersect")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_6
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_7, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_8, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_9, [
                    createVNode(_component_app_heading, {
                      href: "#options",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Options")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("The "),
                      _hoisted_10,
                      createTextVNode(" directive accepts options. Available options can be found in the "),
                      createVNode(_component_app_link, { href: "https://developer.mozilla.org/en-US/docs/Web/API/Intersection_Observer_API" }, {
                        default: withCtx(() => [
                          createTextVNode("Intersection Observer API")
                        ]),
                        _: 1
                      }),
                      createTextVNode(". Below is an example using the "),
                      _hoisted_11,
                      createTextVNode(" option.")
                    ]),
                    createVNode(_component_examples_example, { file: "v-intersect/prop-options" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
