import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "data-table-introduction" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "The data table component is used for displaying tabular data in a way that is easy for users to scan. It includes sorting, searching, pagination and selection.", -1);
const _hoisted_3 = { id: "components" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, "Before diving into the guides and examples, let’s take a moment to understand the core components available for data tables. These are variations optimized for different scenarios.", -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Use-case")
  ])
], -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("td", null, "The base functionality data table, used for paginating, filtering and sorting data.", -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "Adds new events and properties used for displaying data from a server", -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("td", null, "A version of the data table that has built in row virtualization features", -1);
const _hoisted_9 = { id: "api" };
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("td", null, "Specialized Data-table for displaying results from a server", -1);
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("td", null, "Data-table with built in row virtualization", -1);
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("td", null, "Functional Component used to display Data-table footer", -1);
const _hoisted_15 = { id: "guides" };
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("p", null, "Explore data table pages that provide detailed explanations and code samples for various functionalities and use cases.", -1);
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Guide"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("td", null, "Understand the fundamental building blocks of Data Tables.", -1);
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("td", null, "Learn how to manipulate and display data effectively.", -1);
const frontmatter = { "meta": { "nav": "Introduction", "title": "Data table - Introduction", "description": "The data table component is used for displaying tabular data in a way that is easy for users to scan. It includes sorting, searching, pagination and selection.", "keywords": "data tables, vuetify data table component, vue data table component" }, "related": ["/components/paginations/", "/components/selects/", "/components/data-tables/basics/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "introduction",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Introduction", "title": "Data table - Introduction", "description": "The data table component is used for displaying tabular data in a way that is easy for users to scan. It includes sorting, searching, pagination and selection.", "keywords": "data tables, vuetify data table component, vue data table component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Introduction", "title": "Data table - Introduction", "description": "The data table component is used for displaying tabular data in a way that is easy for users to scan. It includes sorting, searching, pagination and selection.", "keywords": "data tables, vuetify data table component, vue data table component" }, "related": ["/components/paginations/", "/components/selects/", "/components/data-tables/basics/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_alert = resolveComponent("alert");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#data-table-introduction",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Data table - Introduction")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_promoted_entry),
              createVNode(_component_alert, { type: "success" }, {
                default: withCtx(() => [
                  createBaseVNode("p", null, [
                    createTextVNode("This feature was introduced in "),
                    createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v3.4.0" }, {
                      default: withCtx(() => [
                        createTextVNode("v3.4.0 (Blackguard)")
                      ]),
                      _: 1
                    })
                  ])
                ]),
                _: 1
              }),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#components",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Components")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_5,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/components/data-tables/basics/" }, {
                            default: withCtx(() => [
                              createTextVNode("Data tables")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_6
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/components/data-tables/server-side-tables/" }, {
                            default: withCtx(() => [
                              createTextVNode("Server tables")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/components/data-tables/virtual-tables/" }, {
                            default: withCtx(() => [
                              createTextVNode("Virtual tables")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_8
                      ])
                    ])
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_9, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_10,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-data-table/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-data-table")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_11
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-data-table-server/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-data-table-server")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_12
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-data-table-virtual/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-data-table-virtual")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_13
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-data-table-footer/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-data-table-footer")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_14
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-checkbox-btn/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-checkbox-btn")
                            ]),
                            _: 1
                          })
                        ]),
                        createBaseVNode("td", null, [
                          createTextVNode("Reusable lightweight "),
                          createVNode(_component_app_link, { href: "/components/checkboxes" }, {
                            default: withCtx(() => [
                              createTextVNode("v-checkbox")
                            ]),
                            _: 1
                          })
                        ])
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_15, [
                createVNode(_component_app_heading, {
                  href: "#guides",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Guides")
                  ]),
                  _: 1
                }),
                _hoisted_16,
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_17,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/components/data-tables/basics/" }, {
                            default: withCtx(() => [
                              createTextVNode("Basics")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_18
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/components/data-tables/data-and-display/" }, {
                            default: withCtx(() => [
                              createTextVNode("Data and Display")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_19
                      ])
                    ])
                  ]),
                  _: 1
                })
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
