import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "vuetify-labs" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "Experiment and use in-development components before they’re released.", -1);
const _hoisted_3 = { id: "what-is-labs" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, "Labs is a new way for developers to use unfinished components in an alpha state.", -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Components available through Labs are considered "),
  /* @__PURE__ */ createBaseVNode("strong", null, "NOT"),
  /* @__PURE__ */ createTextVNode(" production ready and only to be used for testing purposes. Breaking changes will be introduced in patch releases and no support will be provided.")
], -1);
const _hoisted_6 = { id: "usage" };
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Using a Labs component is as simple as importing from "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "vuetify/labs"),
  /* @__PURE__ */ createTextVNode(". The following example shows how to import and bootstrap "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-picker"),
  /* @__PURE__ */ createTextVNode(" in your component:")
], -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-html" }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-picker")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "/>")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("script")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "setup"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token script" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token language-javascript" }, [
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode(" VPicker "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify/labs/VPicker'"),
        /* @__PURE__ */ createTextVNode("\n")
      ])
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("script")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("p", null, "Alternatively you can make the component available globally by importing it in your Vuetify plugin file:", -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-js" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/plugins/vuetify.js",
    class: "language-js"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" createVuetify "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify'"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" VPicker "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify/labs/VPicker'"),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "export"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "default"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "createVuetify"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "components"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n    VPicker"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("When Vuetify instantiates it will register "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "VPicker"),
  /* @__PURE__ */ createTextVNode(" as a usable component within templates.")
], -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("p", null, "If you wish to install all available Vuetify components use the following code snippet:", -1);
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-js" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/plugins/vuetify.js",
    class: "language-js"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" createVuetify "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify'"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "*"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "as"),
    /* @__PURE__ */ createTextVNode(" components "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify/components'"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "*"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "as"),
    /* @__PURE__ */ createTextVNode(" labsComponents "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify/labs/components'"),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "export"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "default"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "createVuetify"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "components"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "..."),
    /* @__PURE__ */ createTextVNode("components"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "..."),
    /* @__PURE__ */ createTextVNode("labsComponents"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_14 = { id: "available-components" };
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("p", null, "The following is a list of available and up-and-coming components for use with Labs:", -1);
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description"),
    /* @__PURE__ */ createBaseVNode("th", null, "Min Version")
  ])
], -1);
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("td", null, "A calendar component", -1);
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("td", null, "A date input component", -1);
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("td", null, "A component for numerical data", -1);
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("td", null, "A queue for snackbars", -1);
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("td", null, "A time-picker component", -1);
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("td", null, "A treeview component", -1);
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Lab component APIs are "),
  /* @__PURE__ */ createBaseVNode("strong", null, "NOT"),
  /* @__PURE__ */ createTextVNode(" finalized and can and will change. You should "),
  /* @__PURE__ */ createBaseVNode("strong", null, "EXPECT"),
  /* @__PURE__ */ createTextVNode(" for things to break during the course of development.")
], -1);
const frontmatter = { "meta": { "nav": "Introduction", "title": "Introduction to Labs", "description": "A collection of in-development components for testing purposes before final release", "keywords": "labs" }, "related": ["/getting-started/installation/", "/getting-started/browser-support/", "/introduction/sponsors-and-backers/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "introduction",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Introduction", "title": "Introduction to Labs", "description": "A collection of in-development components for testing purposes before final release", "keywords": "labs" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Introduction", "title": "Introduction to Labs", "description": "A collection of in-development components for testing purposes before final release", "keywords": "labs" }, "related": ["/getting-started/installation/", "/getting-started/browser-support/", "/introduction/sponsors-and-backers/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_alert = resolveComponent("alert");
      const _component_app_markup = resolveComponent("app-markup");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#vuetify-labs",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Vuetify Labs")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#what-is-labs",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("What is Labs?")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_alert, { type: "error" }, {
                  default: withCtx(() => [
                    _hoisted_5
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_6, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_7,
                createVNode(_component_app_markup, {
                  resource: "",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_8
                  ]),
                  _: 1
                }),
                _hoisted_9,
                createVNode(_component_app_markup, {
                  resource: "src/plugins/vuetify.js",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_10
                  ]),
                  _: 1
                }),
                _hoisted_11,
                _hoisted_12,
                createVNode(_component_app_markup, {
                  resource: "src/plugins/vuetify.js",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_13
                  ]),
                  _: 1
                }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_14, [
                createVNode(_component_app_heading, {
                  href: "#available-components",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Available Components")
                  ]),
                  _: 1
                }),
                _hoisted_15,
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_16,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/components/calendars/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-calendar")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_17,
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v3.4.9" }, {
                            default: withCtx(() => [
                              createTextVNode("v3.4.9")
                            ]),
                            _: 1
                          })
                        ])
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/components/date-inputs/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-date-input")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_18,
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v3.6.0" }, {
                            default: withCtx(() => [
                              createTextVNode("v3.6.0")
                            ]),
                            _: 1
                          })
                        ])
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/components/number-input/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-number-input")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_19,
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v3.5.10" }, {
                            default: withCtx(() => [
                              createTextVNode("v3.5.10")
                            ]),
                            _: 1
                          })
                        ])
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/components/snackbar-queue/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-snackbar-queue")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_20,
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v3.6.0" }, {
                            default: withCtx(() => [
                              createTextVNode("v3.6.0")
                            ]),
                            _: 1
                          })
                        ])
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/components/time-pickers/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-time-picker")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_21,
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v3.5.12" }, {
                            default: withCtx(() => [
                              createTextVNode("v3.5.12")
                            ]),
                            _: 1
                          })
                        ])
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/components/treeview/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-treeview")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_22,
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v3.5.9" }, {
                            default: withCtx(() => [
                              createTextVNode("v3.5.9")
                            ]),
                            _: 1
                          })
                        ])
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_alert, { type: "warning" }, {
                  default: withCtx(() => [
                    _hoisted_23
                  ]),
                  _: 1
                })
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
