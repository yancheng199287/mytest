import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "vue-and-vuetify-jobs" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "Find top Vue.js developers, ready to join your team; or browse available openings and land your next job!", -1);
const frontmatter = { "fluid": true, "meta": { "nav": "Jobs", "title": "Vue & Vuetify jobs", "description": "Vue.js & Vuetify jobs for developers and businesses. Apply to Software Engineer, Full Stack Developer, Senior Software Engineer and more!", "keywords": "Vue.js Jobs, Vue.js careers, Vue.js job search, work in Vue.js, Vuetify jobs for Vue" }, "related": ["/introduction/why-vuetify/", "/introduction/enterprise-support/", "/introduction/enterprise/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "jobs-for-vue",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Jobs", "title": "Vue & Vuetify jobs", "description": "Vue.js & Vuetify jobs for developers and businesses. Apply to Software Engineer, Full Stack Developer, Senior Software Engineer and more!", "keywords": "Vue.js Jobs, Vue.js careers, Vue.js job search, work in Vue.js, Vuetify jobs for Vue" } };
    useHead(head);
    __expose({ frontmatter: { "fluid": true, "meta": { "nav": "Jobs", "title": "Vue & Vuetify jobs", "description": "Vue.js & Vuetify jobs for developers and businesses. Apply to Software Engineer, Full Stack Developer, Senior Software Engineer and more!", "keywords": "Vue.js Jobs, Vue.js careers, Vue.js job search, work in Vue.js, Vuetify jobs for Vue" }, "related": ["/introduction/why-vuetify/", "/introduction/enterprise-support/", "/introduction/enterprise/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_promoted_promoted = resolveComponent("promoted-promoted");
      const _component_doc_vue_jobs = resolveComponent("doc-vue-jobs");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#vue-and-vuetify-jobs",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Vue and Vuetify jobs")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_promoted_promoted, { slug: "enterprise-support" }),
              createVNode(_component_doc_vue_jobs)
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
