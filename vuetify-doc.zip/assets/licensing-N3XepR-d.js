import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "licensing" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "This document provides comprehensive details about the licensing of the Vuetify framework.", -1);
const _hoisted_3 = { id: "overview" };
const _hoisted_4 = { id: "what-is-the-mit-license3f" };
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("p", null, "The MIT License is one of the most widely used licenses in the open-source community, known for its simplicity and permissiveness. This license grants users significant freedom in how they use, modify, and distribute software. Here are its key features and what they mean for Vuetify users:", -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "Freedom to Use"),
    /* @__PURE__ */ createTextVNode(": The MIT License allows you to use Vuetify for any purpose - whether it’s a private hobby project, a high-scale commercial application, or a public service. This level of freedom ensures that Vuetify is accessible to everyone, regardless of their project’s nature or scale.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "Freedom to Modify"),
    /* @__PURE__ */ createTextVNode(": Flexibility is at the core of Vuetify, and the MIT License extends this principle. You have the freedom to tweak, customize, and modify Vuetify to suit your project’s unique requirements. This feature is particularly beneficial for developers looking to tailor their UI/UX without constraints.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "Freedom to Distribute"),
    /* @__PURE__ */ createTextVNode(": The license not only allows you to use and modify Vuetify but also to distribute your version of it. Whether you’re distributing your Vuetify-based project openly or commercially, the MIT License supports your endeavors. This aspect is crucial for fostering a culture of sharing and innovation in the developer community.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "No Warranty"),
    /* @__PURE__ */ createTextVNode(": Please note that Vuetify is provided “as is”, without any warranty of any kind. This is a standard clause in open-source licenses, emphasizing that users should test and evaluate the software in their specific contexts. While there’s no formal warranty, the Vuetify team is committed to delivering a high-quality, robust framework, continuously working to improve its reliability and functionality.")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("p", null, "The MIT License’s simplicity and breadth make it an ideal choice for Vuetify, aligning with our commitment to open-source values and community-driven development.", -1);
const _hoisted_8 = { id: "why-mit-license-for-vuetify3f" };
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("p", null, "Choosing the MIT License for Vuetify was a deliberate decision to align with our core values of openness, simplicity, and community collaboration. Here’s why this license is the perfect fit for Vuetify:", -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "Simplicity and Permissiveness"),
    /* @__PURE__ */ createTextVNode(": The MIT License is renowned for its simplicity and clarity. It doesn’t impose complex restrictions, making it straightforward for developers to use Vuetify in various projects. Whether you’re building a small personal project or a large-scale commercial application, the MIT License keeps things simple and unrestricted.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "Broad Compatibility"),
    /* @__PURE__ */ createTextVNode(": One of Vuetify’s strengths is its compatibility with a wide range of other tools and libraries. The MIT License is known for its broad compatibility with other open-source licenses. This compatibility makes it easier for developers to integrate Vuetify with other software, fostering a more vibrant and versatile ecosystem.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "Encourages Open Source Contribution"),
    /* @__PURE__ */ createTextVNode(": Vuetify thrives on community contributions. The permissive nature of the MIT License encourages developers from around the world to contribute to Vuetify, enhancing its features and functionality. This collaborative spirit has been pivotal in shaping Vuetify into the robust and versatile framework it is today.")
  ])
], -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("p", null, "By adopting the MIT License, Vuetify remains committed to promoting innovation, collaboration, and freedom in software development. We believe this approach not only benefits Vuetify but also the broader open-source community.", -1);
const _hoisted_12 = { id: "using-vuetify-in-your-projects" };
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("p", null, "You are free to use Vuetify in your projects, be it personal, commercial, or for educational purposes. The flexibility of the MIT License allows for a wide range of applications. When redistributing Vuetify or derivative works, the only requirement is to include the original copyright and license notice in any copy of the software/source code.", -1);
const _hoisted_14 = { id: "contributions-to-vuetify" };
const _hoisted_15 = { id: "questions-and-comments" };
const _hoisted_16 = { id: "legal-disclaimer" };
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("p", null, "The information provided on this page is for general informational purposes only and is not intended as legal advice. For specific legal questions regarding the use of Vuetify, please consult with a qualified attorney.", -1);
const frontmatter = { "meta": { "nav": "Licensing", "title": "Licensing", "description": "Explore the MIT License under which Vuetify is available, understand your freedoms for using, modifying, and distributing Vuetify, and learn about community contributions.", "keywords": "MIT License, open source, Vuetify license, free software" }, "related": ["/introduction/why-vuetify/", "/getting-started/contributing/", "/introduction/enterprise-support/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "licensing",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Licensing", "title": "Licensing", "description": "Explore the MIT License under which Vuetify is available, understand your freedoms for using, modifying, and distributing Vuetify, and learn about community contributions.", "keywords": "MIT License, open source, Vuetify license, free software" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Licensing", "title": "Licensing", "description": "Explore the MIT License under which Vuetify is available, understand your freedoms for using, modifying, and distributing Vuetify, and learn about community contributions.", "keywords": "MIT License, open source, Vuetify license, free software" }, "related": ["/introduction/why-vuetify/", "/getting-started/contributing/", "/introduction/enterprise-support/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#licensing",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Licensing")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_promoted_entry),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#overview",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Overview")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("Vuetify is an open-source project that is free to use. It is licensed under the "),
                  createVNode(_component_app_link, { href: "https://github.com/vuetifyjs/vuetify/blob/master/LICENSE.md" }, {
                    default: withCtx(() => [
                      createTextVNode("MIT License")
                    ]),
                    _: 1
                  }),
                  createTextVNode(", one of the most permissive and flexible open source licenses available.")
                ])
              ]),
              createBaseVNode("section", _hoisted_4, [
                createVNode(_component_app_heading, {
                  href: "#what-is-the-mit-license3f",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("What is the MIT License?")
                  ]),
                  _: 1
                }),
                _hoisted_5,
                _hoisted_6,
                _hoisted_7
              ]),
              createBaseVNode("section", _hoisted_8, [
                createVNode(_component_app_heading, {
                  href: "#why-mit-license-for-vuetify3f",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Why MIT License for Vuetify?")
                  ]),
                  _: 1
                }),
                _hoisted_9,
                _hoisted_10,
                _hoisted_11
              ]),
              createBaseVNode("section", _hoisted_12, [
                createVNode(_component_app_heading, {
                  href: "#using-vuetify-in-your-projects",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Using Vuetify in Your Projects")
                  ]),
                  _: 1
                }),
                _hoisted_13,
                createBaseVNode("p", null, [
                  createTextVNode("To get inspired or see what’s possible with Vuetify, check out "),
                  createVNode(_component_app_link, { href: "https://github.com/vuetifyjs/awesome-vuetify" }, {
                    default: withCtx(() => [
                      createTextVNode("Awesome Vuetify")
                    ]),
                    _: 1
                  }),
                  createTextVNode(", a curated list of awesome Vuetify resources, libraries, and tools. Additionally, explore the "),
                  createVNode(_component_app_link, { href: "/resources/made-with-vuetify/" }, {
                    default: withCtx(() => [
                      createTextVNode("Made With Vuetify")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" page to see a showcase of applications and projects built using Vuetify. These resources can provide you with ideas and examples of how Vuetify can enhance your projects.")
                ])
              ]),
              createBaseVNode("section", _hoisted_14, [
                createVNode(_component_app_heading, {
                  href: "#contributions-to-vuetify",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Contributions to Vuetify")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("Contributions to Vuetify are also subject to the MIT License. By contributing to the Vuetify project, you agree that your contributions will be licensed under the MIT License. See our "),
                  createVNode(_component_app_link, { href: "/getting-started/contributing/" }, {
                    default: withCtx(() => [
                      createTextVNode("Contributing")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" page for more details.")
                ])
              ]),
              createBaseVNode("section", _hoisted_15, [
                createVNode(_component_app_heading, {
                  href: "#questions-and-comments",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Questions and Comments")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("If you have any questions or comments about our licensing policy, or if you need clarification on legal aspects of using Vuetify in your projects, please "),
                  createVNode(_component_app_link, { href: "mailto:hello@vuetifyjs.com" }, {
                    default: withCtx(() => [
                      createTextVNode("contact us")
                    ]),
                    _: 1
                  }),
                  createTextVNode(".")
                ])
              ]),
              createBaseVNode("section", _hoisted_16, [
                createVNode(_component_app_heading, {
                  href: "#legal-disclaimer",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Legal Disclaimer")
                  ]),
                  _: 1
                }),
                _hoisted_17
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
