import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "lists" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-list"),
  /* @__PURE__ */ createTextVNode(" component is used to display information. It can contain an avatar, content, actions, subheaders and much more. Lists present content in a way that makes it easy to identify a specific item in a collection. They provide a consistent styling for organizing groups of text and images.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Lists come in three main variations. "),
  /* @__PURE__ */ createBaseVNode("strong", null, "single-line"),
  /* @__PURE__ */ createTextVNode(" (default), "),
  /* @__PURE__ */ createBaseVNode("strong", null, "two-line"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "three-line"),
  /* @__PURE__ */ createTextVNode(". The line declaration specifies the minimum height of the item and can also be controlled from "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-list"),
  /* @__PURE__ */ createTextVNode(" with the same prop.")
], -1);
const _hoisted_5 = { id: "api" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("td", null, "Sub-component used to display or hide groups of items", -1);
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("td", null, "Sub-component used to separate groups of items", -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createTextVNode("Sub-component used to display a single item or modify the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-list"),
  /* @__PURE__ */ createTextVNode(" state")
], -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createTextVNode("Sub-component used to display the title of a list item. Wraps the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "#title"),
  /* @__PURE__ */ createTextVNode(" slot")
], -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createTextVNode("Sub-component used to display the subtitle of a list item. Wraps the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "#subtitle"),
  /* @__PURE__ */ createTextVNode(" slot")
], -1);
const _hoisted_13 = { id: "examples" };
const _hoisted_14 = { id: "props" };
const _hoisted_15 = { id: "items" };
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Lists can either be created by markup using the many sub-components that are available, or by using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "items"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("To customize which properties will be used for the title and value of each item, use the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "item-title"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "item-value"),
  /* @__PURE__ */ createTextVNode(" props.")
], -1);
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("If you need to render subheaders or dividers, add an item with a "),
  /* @__PURE__ */ createBaseVNode("strong", null, "type"),
  /* @__PURE__ */ createTextVNode(" property. Which property to use can be customized using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "item-type"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("To customize individual items, you can use the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "item-props"),
  /* @__PURE__ */ createTextVNode(" prop. It defaults to looking for a "),
  /* @__PURE__ */ createBaseVNode("strong", null, "props"),
  /* @__PURE__ */ createTextVNode(" property on the items. The value should be an object, and if found it will be spread on the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "v-list-item"),
  /* @__PURE__ */ createTextVNode(" component.")
], -1);
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("If "),
  /* @__PURE__ */ createBaseVNode("strong", null, "item-props"),
  /* @__PURE__ */ createTextVNode(" is set to "),
  /* @__PURE__ */ createBaseVNode("strong", null, "true"),
  /* @__PURE__ */ createTextVNode(" then the whole item will be spread.")
], -1);
const _hoisted_21 = { id: "density" };
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-list"),
  /* @__PURE__ */ createTextVNode(" supports the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "density"),
  /* @__PURE__ */ createTextVNode(" property.")
], -1);
const _hoisted_23 = { id: "disabled" };
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You cannot interact with disabled "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-list"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_25 = { id: "variant" };
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-list"),
  /* @__PURE__ */ createTextVNode(" supports the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "variant"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_27 = { id: "nav" };
const _hoisted_28 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Lists can receive an alternative "),
  /* @__PURE__ */ createBaseVNode("strong", null, "nav"),
  /* @__PURE__ */ createTextVNode(" styling that reduces the width "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-list-item"),
  /* @__PURE__ */ createTextVNode(" takes up as well as adding a border radius.")
], -1);
const _hoisted_29 = { id: "rounded" };
const _hoisted_30 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can make "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-list"),
  /* @__PURE__ */ createTextVNode(" items rounded.")
], -1);
const _hoisted_31 = { id: "shaped" };
const _hoisted_32 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Shaped lists have rounded borders on one side of the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-list-item"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_33 = { id: "sub-group" };
const _hoisted_34 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Using the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-list-group"),
  /* @__PURE__ */ createTextVNode(" component you can create sub-groups of items.")
], -1);
const _hoisted_35 = { id: "three-line" };
const _hoisted_36 = { id: "two-lines-and-subheader" };
const _hoisted_37 = /* @__PURE__ */ createBaseVNode("p", null, "Lists can contain subheaders, dividers, and can contain 1 or more lines. The subtitle will overflow with ellipsis if it extends past one line.", -1);
const _hoisted_38 = { id: "misc" };
const _hoisted_39 = { id: "action-and-item-groups" };
const _hoisted_40 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("A "),
  /* @__PURE__ */ createBaseVNode("strong", null, "three-line"),
  /* @__PURE__ */ createTextVNode(" list with actions. Utilizing "),
  /* @__PURE__ */ createBaseVNode("strong", null, "v-list-group"),
  /* @__PURE__ */ createTextVNode(", easily connect actions to your tiles.")
], -1);
const frontmatter = { "meta": { "nav": "Lists", "title": "List component", "description": "The list component is a continuous group of text, images and icons that may contain primary or supplemental actions.", "keywords": "lists, vuetify list component, vue list component" }, "related": ["/components/item-groups/", "/components/avatars/", "/components/sheets/"], "features": { "figma": true, "github": "/components/VList/", "label": "C: VList", "report": true, "spec": "https://m2.material.io/components/lists" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "lists",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Lists", "title": "List component", "description": "The list component is a continuous group of text, images and icons that may contain primary or supplemental actions.", "keywords": "lists, vuetify list component, vue list component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Lists", "title": "List component", "description": "The list component is a continuous group of text, images and icons that may contain primary or supplemental actions.", "keywords": "lists, vuetify list component, vue list component" }, "related": ["/components/item-groups/", "/components/avatars/", "/components/sheets/"], "features": { "figma": true, "github": "/components/VList/", "label": "C: VList", "report": true, "spec": "https://m2.material.io/components/lists" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_promoted_promoted = resolveComponent("promoted-promoted");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#lists",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Lists")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_usage, { name: "v-list" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_6,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-list/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-list")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-list-group/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-list-group")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_8
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-list-subheader/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-list-subheader")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_9
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-list-item/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-list-item")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_10
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-list-item-title/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-list-item-title")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_11
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-list-item-subtitle/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-list-item-subtitle")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_12
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-list-item-action/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-list-item-action")
                            ]),
                            _: 1
                          })
                        ]),
                        createBaseVNode("td", null, [
                          createTextVNode("Sub-component used to display "),
                          createVNode(_component_app_link, { href: "/components/checkboxes/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-checkbox")
                            ]),
                            _: 1
                          }),
                          createTextVNode(" or "),
                          createVNode(_component_app_link, { href: "/components/switches/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-switch")
                            ]),
                            _: 1
                          })
                        ])
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-list-img/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-list-img")
                            ]),
                            _: 1
                          })
                        ]),
                        createBaseVNode("td", null, [
                          createTextVNode("Sub-component that is used to wrap a the "),
                          createVNode(_component_app_link, { href: "/components/images/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-img")
                            ]),
                            _: 1
                          }),
                          createTextVNode(" component")
                        ])
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-list-item-media/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-list-item-media")
                            ]),
                            _: 1
                          })
                        ]),
                        createBaseVNode("td", null, [
                          createTextVNode("Sub-component that is used to wrap a the "),
                          createVNode(_component_app_link, { href: "/components/images/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-img")
                            ]),
                            _: 1
                          }),
                          createTextVNode(" component")
                        ])
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_13, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_14, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_15, [
                    createVNode(_component_app_heading, {
                      href: "#items",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Items")
                      ]),
                      _: 1
                    }),
                    _hoisted_16,
                    createVNode(_component_examples_example, { file: "v-list/prop-items" }),
                    _hoisted_17,
                    createVNode(_component_examples_example, { file: "v-list/prop-items-custom" }),
                    _hoisted_18,
                    createVNode(_component_examples_example, { file: "v-list/prop-items-type" }),
                    _hoisted_19,
                    _hoisted_20,
                    createVNode(_component_examples_example, { file: "v-list/prop-items-prop" })
                  ]),
                  createBaseVNode("section", _hoisted_21, [
                    createVNode(_component_app_heading, {
                      href: "#density",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Density")
                      ]),
                      _: 1
                    }),
                    _hoisted_22,
                    createVNode(_component_examples_example, { file: "v-list/prop-density" }),
                    createVNode(_component_promoted_promoted, { slug: "vuetify-lux-admin-pro" })
                  ]),
                  createBaseVNode("section", _hoisted_23, [
                    createVNode(_component_app_heading, {
                      href: "#disabled",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Disabled")
                      ]),
                      _: 1
                    }),
                    _hoisted_24,
                    createVNode(_component_examples_example, { file: "v-list/prop-disabled" })
                  ]),
                  createBaseVNode("section", _hoisted_25, [
                    createVNode(_component_app_heading, {
                      href: "#variant",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Variant")
                      ]),
                      _: 1
                    }),
                    _hoisted_26,
                    createVNode(_component_examples_example, { file: "v-list/prop-variant" })
                  ]),
                  createBaseVNode("section", _hoisted_27, [
                    createVNode(_component_app_heading, {
                      href: "#nav",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Nav")
                      ]),
                      _: 1
                    }),
                    _hoisted_28,
                    createVNode(_component_examples_example, { file: "v-list/prop-nav" })
                  ]),
                  createBaseVNode("section", _hoisted_29, [
                    createVNode(_component_app_heading, {
                      href: "#rounded",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Rounded")
                      ]),
                      _: 1
                    }),
                    _hoisted_30,
                    createVNode(_component_examples_example, { file: "v-list/prop-rounded" })
                  ]),
                  createBaseVNode("section", _hoisted_31, [
                    createVNode(_component_app_heading, {
                      href: "#shaped",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Shaped")
                      ]),
                      _: 1
                    }),
                    _hoisted_32,
                    createVNode(_component_examples_example, { file: "v-list/prop-shaped" })
                  ]),
                  createBaseVNode("section", _hoisted_33, [
                    createVNode(_component_app_heading, {
                      href: "#sub-group",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Sub group")
                      ]),
                      _: 1
                    }),
                    _hoisted_34,
                    createVNode(_component_examples_example, { file: "v-list/prop-sub-group" })
                  ]),
                  createBaseVNode("section", _hoisted_35, [
                    createVNode(_component_app_heading, {
                      href: "#three-line",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Three line")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("For three line lists, the subtitle will clamp vertically at 2 lines and then ellipsis. This feature uses "),
                      createVNode(_component_app_link, { href: "https://developer.mozilla.org/en-US/docs/Web/CSS/-webkit-line-clamp" }, {
                        default: withCtx(() => [
                          createTextVNode("line-clamp")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" and is not supported in all browsers.")
                    ]),
                    createVNode(_component_examples_example, { file: "v-list/prop-three-line" })
                  ]),
                  createBaseVNode("section", _hoisted_36, [
                    createVNode(_component_app_heading, {
                      href: "#two-lines-and-subheader",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Two lines and subheader")
                      ]),
                      _: 1
                    }),
                    _hoisted_37,
                    createVNode(_component_examples_example, { file: "v-list/prop-two-line-and-subheader" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_38, [
                  createVNode(_component_app_heading, {
                    href: "#misc",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Misc")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_39, [
                    createVNode(_component_app_heading, {
                      href: "#action-and-item-groups",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Action and item groups")
                      ]),
                      _: 1
                    }),
                    _hoisted_40,
                    createVNode(_component_examples_example, { file: "v-list/misc-action-and-item-groups" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
