import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "long-term-support" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "Vuetify provides long-term support to the last major release for 18 months for critical bugs and security vulnerabilities.", -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("We understand that many projects that utilize Vuetify have development cycles that prevent upgrading to the latest version. In order to provide developers and businesses peace of mind when adopting Vuetify, we commit to at minimum of "),
  /* @__PURE__ */ createBaseVNode("strong", null, "18 months"),
  /* @__PURE__ */ createTextVNode(" for critical bugs and security vulnerabilities for the latest "),
  /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "minor"),
  /* @__PURE__ */ createTextVNode(" of the last "),
  /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "major"),
  /* @__PURE__ */ createTextVNode(" release.")
], -1);
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Version"),
    /* @__PURE__ */ createBaseVNode("th", null, "Status"),
    /* @__PURE__ */ createBaseVNode("th", null, "Initial Release Date"),
    /* @__PURE__ */ createBaseVNode("th", null, "LTS Start Date"),
    /* @__PURE__ */ createBaseVNode("th", null, "LTS End Date")
  ])
], -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("td", null, "🚀 Active Development", -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("td", null, "November 1st, 2022", -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "N/A", -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("td", null, "N/A", -1);
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("td", null, "🛠️ Maintenance", -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("td", null, "July 23rd, 2019", -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("td", null, "July 5th, 2023", -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("td", null, "January 23rd, 2025", -1);
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("td", null, "📦 Archived", -1);
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("td", null, "February 5th, 2019", -1);
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("td", null, "July 31st, 2019", -1);
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("td", null, "July 31st, 2020", -1);
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "TIP:")
], -1);
const frontmatter = { "meta": { "title": "Long-term support", "description": "Vuetify provides long-term support to the last major release for 18 months for critical bugs and security vulnerabilities", "keywords": "lts, long-term support" }, "related": ["/introduction/enterprise-support/", "/getting-started/contributing/", "/about/meet-the-team/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "long-term-support",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "Long-term support", "description": "Vuetify provides long-term support to the last major release for 18 months for critical bugs and security vulnerabilities", "keywords": "lts, long-term support" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "title": "Long-term support", "description": "Vuetify provides long-term support to the last major release for 18 months for critical bugs and security vulnerabilities", "keywords": "lts, long-term support" }, "related": ["/introduction/enterprise-support/", "/getting-started/contributing/", "/about/meet-the-team/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_vo_promotions_card_vuetify = resolveComponent("vo-promotions-card-vuetify");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_alert = resolveComponent("alert");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#long-term-support",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Long-term support")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_vo_promotions_card_vuetify),
              _hoisted_3,
              createVNode(_component_app_table, null, {
                default: withCtx(() => [
                  _hoisted_4,
                  createBaseVNode("tbody", null, [
                    createBaseVNode("tr", null, [
                      createBaseVNode("td", null, [
                        createVNode(_component_app_link, { href: "https://vuetifyjs.com/" }, {
                          default: withCtx(() => [
                            createTextVNode("Vuetify 3.x")
                          ]),
                          _: 1
                        })
                      ]),
                      _hoisted_5,
                      _hoisted_6,
                      _hoisted_7,
                      _hoisted_8
                    ]),
                    createBaseVNode("tr", null, [
                      createBaseVNode("td", null, [
                        createVNode(_component_app_link, { href: "https://v2.vuetifyjs.com/" }, {
                          default: withCtx(() => [
                            createTextVNode("Vuetify 2.7")
                          ]),
                          _: 1
                        })
                      ]),
                      _hoisted_9,
                      _hoisted_10,
                      _hoisted_11,
                      _hoisted_12
                    ]),
                    createBaseVNode("tr", null, [
                      createBaseVNode("td", null, [
                        createVNode(_component_app_link, { href: "https://v15.vuetifyjs.com/" }, {
                          default: withCtx(() => [
                            createTextVNode("Vuetify 1.5")
                          ]),
                          _: 1
                        })
                      ]),
                      _hoisted_13,
                      _hoisted_14,
                      _hoisted_15,
                      _hoisted_16
                    ])
                  ])
                ]),
                _: 1
              }),
              createBaseVNode("p", null, [
                createTextVNode("Have questions? Reach out to us in our "),
                createVNode(_component_app_link, { href: "https://community.vuetifyjs.com" }, {
                  default: withCtx(() => [
                    createTextVNode("Discord community")
                  ]),
                  _: 1
                }),
                createTextVNode(".")
              ]),
              createVNode(_component_alert, { type: "tip" }, {
                default: withCtx(() => [
                  _hoisted_17,
                  createBaseVNode("p", null, [
                    createTextVNode("Sign-up for Enterprise support and get a personalized service plan from the team behind Vuetify. "),
                    createVNode(_component_app_link, { href: "/introduction/enterprise-support/" }, {
                      default: withCtx(() => [
                        createTextVNode("Book a consultation")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" for your business today!")
                  ])
                ]),
                _: 1
              })
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
