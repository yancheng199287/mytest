import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "made-with-vuetify" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "Check out these amazing projects built using Vuetify.", -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const frontmatter = { "backmatter": false, "fluid": true, "meta": { "nav": "Made with Vuetify", "title": "Made with Vuetify", "description": "Check out these amazing projects built using Vuetify.", "keywords": "made with vuetify, vuetify projects, vuetify apps, vuetify plugins, vuetify themes" }, "related": ["/getting-started/installation/", "/resources/themes/", "/resources/ui-kits/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "made-with-vuetify",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Made with Vuetify", "title": "Made with Vuetify", "description": "Check out these amazing projects built using Vuetify.", "keywords": "made with vuetify, vuetify projects, vuetify apps, vuetify plugins, vuetify themes" } };
    useHead(head);
    __expose({ frontmatter: { "backmatter": false, "fluid": true, "meta": { "nav": "Made with Vuetify", "title": "Made with Vuetify", "description": "Check out these amazing projects built using Vuetify.", "keywords": "made with vuetify, vuetify projects, vuetify apps, vuetify plugins, vuetify themes" }, "related": ["/getting-started/installation/", "/resources/themes/", "/resources/ui-kits/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_doc_made_with_vuetify_gallery = resolveComponent("doc-made-with-vuetify-gallery");
      const _component_doc_made_with_vue_attribution = resolveComponent("doc-made-with-vue-attribution");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#made-with-vuetify",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Made with Vuetify")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_promoted_entry),
              createVNode(_component_doc_made_with_vuetify_gallery, { pagination: "" }),
              _hoisted_3,
              createVNode(_component_doc_made_with_vue_attribution)
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
