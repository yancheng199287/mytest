import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "meet-the-team" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Vuetify is "),
  /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "not"),
  /* @__PURE__ */ createTextVNode(" a one person show. We have a very active and engaged team that is "),
  /* @__PURE__ */ createBaseVNode("strong", null, "constantly striving"),
  /* @__PURE__ */ createTextVNode(" to bring developers a better experience. Keep in mind the below is not an exhaustive list of all the individuals that help make Vuetify great.")
], -1);
const _hoisted_3 = { id: "company" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("strong", null, "GitHub", -1);
const _hoisted_5 = { id: "core-team" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("p", null, "The core development team are Open Source developers that help guide the direction of Vuetify and its ecosystem.", -1);
const _hoisted_7 = { id: "legends" };
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("p", null, "Legends are inactive members of the core team. They have contributed a significant amount of time and effort to the project and are recognized for their contributions.", -1);
const frontmatter = { "meta": { "title": "Meet the team", "description": "Meet the team responsible for building Vuetify. These are the core individuals who drive the vision of the framework.", "keywords": "vuetify dev team, vuetify core team" }, "related": ["/introduction/enterprise-support/", "/introduction/long-term-support/", "/introduction/roadmap/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "meet-the-team",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "Meet the team", "description": "Meet the team responsible for building Vuetify. These are the core individuals who drive the vision of the framework.", "keywords": "vuetify dev team, vuetify core team" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "title": "Meet the team", "description": "Meet the team responsible for building Vuetify. These are the core individuals who drive the vision of the framework.", "keywords": "vuetify dev team, vuetify core team" }, "related": ["/introduction/enterprise-support/", "/introduction/long-term-support/", "/introduction/roadmap/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_promoted_promoted = resolveComponent("promoted-promoted");
      const _component_about_team_members = resolveComponent("about-team-members");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#meet-the-team",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Meet the team")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_promoted_entry),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#company",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Company")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("While Vuetify (the framework) is "),
                  createVNode(_component_app_link, { href: "https://github.com/vuetifyjs/vuetify/blob/master/LICENSE.md" }, {
                    default: withCtx(() => [
                      createTextVNode("MIT Licensed")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" and "),
                  createVNode(_component_app_link, { href: "https://opensource.com/resources/what-open-source" }, {
                    default: withCtx(() => [
                      createTextVNode("Open Source")
                    ]),
                    _: 1
                  }),
                  createTextVNode(", Vuetify (the company) is owned and operated by John and Heather Leider as a full-time Open Source business. You can support them by sponsoring Vuetify on "),
                  _hoisted_4,
                  createTextVNode(".")
                ]),
                createVNode(_component_promoted_promoted, { slug: "enterprise-support" }),
                createVNode(_component_about_team_members, { team: "company" })
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#core-team",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Core Team")
                  ]),
                  _: 1
                }),
                _hoisted_6,
                createVNode(_component_promoted_promoted, { slug: "vuetify-open-collective" }),
                createVNode(_component_about_team_members, { team: "core" })
              ]),
              createBaseVNode("section", _hoisted_7, [
                createVNode(_component_app_heading, {
                  href: "#legends",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Legends")
                  ]),
                  _: 1
                }),
                _hoisted_8,
                createVNode(_component_about_team_members, { team: "legends" })
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
