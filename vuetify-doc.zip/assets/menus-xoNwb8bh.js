import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "menus" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-menu"),
  /* @__PURE__ */ createTextVNode(" component shows a menu at the position of the element used to activate it.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, "There are three main ways that menus can be defined in markup.", -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The first one is by using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "activator"),
  /* @__PURE__ */ createTextVNode(" slot. Don’t forget to bind the slot "),
  /* @__PURE__ */ createBaseVNode("strong", null, "props"),
  /* @__PURE__ */ createTextVNode(" to the activating element.")
], -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The second one is by using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "activator"),
  /* @__PURE__ */ createTextVNode(" prop with value "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "parent"),
  /* @__PURE__ */ createTextVNode(". This will turn the parent element of the menu into the activator.")
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The third one is to supply a CSS selector string to "),
  /* @__PURE__ */ createBaseVNode("strong", null, "activator"),
  /* @__PURE__ */ createTextVNode(" prop. This allows you to place the menu and its activator in separate parts of the markup.")
], -1);
const _hoisted_8 = { id: "api" };
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createTextVNode("Sub-component often used for the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-menu"),
  /* @__PURE__ */ createTextVNode(" activator")
], -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createTextVNode("Sub-component often used for the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-menu"),
  /* @__PURE__ */ createTextVNode(" content")
], -1);
const _hoisted_13 = { id: "examples" };
const _hoisted_14 = { id: "props" };
const _hoisted_15 = { id: "location" };
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("strong", null, "location", -1);
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("strong", null, "location", -1);
const _hoisted_18 = { id: "open-on-hover" };
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Menus can be accessed using hover instead of clicking with the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "open-on-hover"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_20 = { id: "slots" };
const _hoisted_21 = { id: "activator-and-tooltip" };
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("With the new "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-slot"),
  /* @__PURE__ */ createTextVNode(" syntax, nested activators such as those seen with a "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-menu"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-tooltip"),
  /* @__PURE__ */ createTextVNode(" attached to the same activator button, need a particular setup in order to function correctly.")
], -1);
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("This same syntax is used for other nested activators such as "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-dialog"),
  /* @__PURE__ */ createTextVNode(" with "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-tooltip")
], -1);
const _hoisted_24 = { id: "misc" };
const _hoisted_25 = { id: "transitions" };
const _hoisted_26 = { id: "popover-menu" };
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("p", null, "A menu can be configured to be static when opened, allowing it to function as a popover. This can be useful when there are multiple interactive items within the menu contents.", -1);
const _hoisted_28 = { id: "use-in-components" };
const _hoisted_29 = /* @__PURE__ */ createBaseVNode("p", null, "Menus can be placed within almost any component.", -1);
const frontmatter = { "meta": { "nav": "Menus", "title": "Menu component", "description": "The menu component exposes a dropdown of potential selections or actions that the user can make.", "keywords": "menus, vuetify menu component, vue menu component" }, "related": ["/components/dialogs/", "/components/tooltips/", "/styles/transitions/"], "features": { "github": "/components/VMenu/", "label": "C: VMenu", "report": true, "spec": "https://m2.material.io/components/menus" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "menus",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Menus", "title": "Menu component", "description": "The menu component exposes a dropdown of potential selections or actions that the user can make.", "keywords": "menus, vuetify menu component, vue menu component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Menus", "title": "Menu component", "description": "The menu component exposes a dropdown of potential selections or actions that the user can make.", "keywords": "menus, vuetify menu component, vue menu component" }, "related": ["/components/dialogs/", "/components/tooltips/", "/styles/transitions/"], "features": { "github": "/components/VMenu/", "label": "C: VMenu", "report": true, "spec": "https://m2.material.io/components/menus" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_alert = resolveComponent("alert");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#menus",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Menus")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                _hoisted_5,
                _hoisted_6,
                _hoisted_7,
                createVNode(_component_examples_example, { file: "v-menu/usage" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_8, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_9,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-menu/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-menu")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_10
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-btn/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-btn")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_11
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-list-item/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-list-item")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_12
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_13, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_14, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_15, [
                    createVNode(_component_app_heading, {
                      href: "#location",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Location")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("Menu can be offset relative to the activator by using the "),
                      _hoisted_16,
                      createTextVNode(" prop. Read more about "),
                      _hoisted_17,
                      createTextVNode(),
                      createVNode(_component_app_link, { href: "/components/overlays/#location" }, {
                        default: withCtx(() => [
                          createTextVNode("here")
                        ]),
                        _: 1
                      }),
                      createTextVNode(".")
                    ]),
                    createVNode(_component_examples_example, { file: "v-menu/prop-location" })
                  ]),
                  createBaseVNode("section", _hoisted_18, [
                    createVNode(_component_app_heading, {
                      href: "#open-on-hover",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Open on hover")
                      ]),
                      _: 1
                    }),
                    _hoisted_19,
                    createVNode(_component_examples_example, { file: "v-menu/prop-open-on-hover" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_20, [
                  createVNode(_component_app_heading, {
                    href: "#slots",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Slots")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_21, [
                    createVNode(_component_app_heading, {
                      href: "#activator-and-tooltip",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Activator and tooltip")
                      ]),
                      _: 1
                    }),
                    _hoisted_22,
                    createVNode(_component_alert, { type: "info" }, {
                      default: withCtx(() => [
                        _hoisted_23
                      ]),
                      _: 1
                    }),
                    createVNode(_component_examples_example, { file: "v-menu/slot-activator-and-tooltip" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_24, [
                  createVNode(_component_app_heading, {
                    href: "#misc",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Misc")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_25, [
                    createVNode(_component_app_heading, {
                      href: "#transitions",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Transitions")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("Vuetify comes with "),
                      createVNode(_component_app_link, { href: "/styles/transitions#api" }, {
                        default: withCtx(() => [
                          createTextVNode("several standard transitions")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" that you can use. You can also create your own and pass it as the transition argument. For an example of how the stock transitions are constructed, visit "),
                      createVNode(_component_app_link, { href: "https://github.com/vuetifyjs/vuetify/blob/master/packages/vuetify/src/util/helpers.ts" }, {
                        default: withCtx(() => [
                          createTextVNode("here")
                        ]),
                        _: 1
                      }),
                      createTextVNode(".")
                    ]),
                    createVNode(_component_examples_example, { file: "v-menu/misc-transition" })
                  ]),
                  createBaseVNode("section", _hoisted_26, [
                    createVNode(_component_app_heading, {
                      href: "#popover-menu",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Popover menu")
                      ]),
                      _: 1
                    }),
                    _hoisted_27,
                    createVNode(_component_examples_example, { file: "v-menu/misc-popover" })
                  ]),
                  createBaseVNode("section", _hoisted_28, [
                    createVNode(_component_app_heading, {
                      href: "#use-in-components",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Use In components")
                      ]),
                      _: 1
                    }),
                    _hoisted_29,
                    createVNode(_component_examples_example, { file: "v-menu/misc-use-in-components" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
