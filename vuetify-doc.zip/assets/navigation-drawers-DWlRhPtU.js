import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "navigation-drawers" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-navigation-drawer"),
  /* @__PURE__ */ createTextVNode(" component is what your users will utilize to navigate through the application.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("strong", null, "vue-router", -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "null", -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("strong", null, "v-model", -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("strong", null, "nav", -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "TIP:")
], -1);
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("For the purpose of display, some examples are wrapped in a "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-card"),
  /* @__PURE__ */ createTextVNode(" element. Within your application you will generally place the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-navigation-drawer"),
  /* @__PURE__ */ createTextVNode(" as a direct child of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-app"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/App.vue",
    class: "language-html"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-app")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-navigation-drawer")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "/>")
    ]),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("v-app")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_11 = { id: "api" };
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("td", null, "Component used to create navigation links", -1);
const _hoisted_15 = { id: "caveats" };
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "expand-on-hover"),
  /* @__PURE__ */ createTextVNode(" prop does not alter the content area of "),
  /* @__PURE__ */ createBaseVNode("strong", null, "v-main"),
  /* @__PURE__ */ createTextVNode(". To have content area respond to "),
  /* @__PURE__ */ createBaseVNode("strong", null, "expand-on-hover"),
  /* @__PURE__ */ createTextVNode(", bind "),
  /* @__PURE__ */ createBaseVNode("strong", null, "v-model:rail"),
  /* @__PURE__ */ createTextVNode(" to a data prop.")
], -1);
const _hoisted_17 = { id: "examples" };
const _hoisted_18 = { id: "props" };
const _hoisted_19 = { id: "bottom-drawer" };
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "bottom"),
  /* @__PURE__ */ createTextVNode(" prop, we are able to relocate our drawer on mobile devices to come from the bottom of the screen. This is an alternative style and only activates once the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "mobile-breakpoint"),
  /* @__PURE__ */ createTextVNode(" is met.")
], -1);
const _hoisted_21 = { id: "expand-on-hover" };
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Places the component in "),
  /* @__PURE__ */ createBaseVNode("strong", null, "rail"),
  /* @__PURE__ */ createTextVNode(" mode and expands once hovered. This "),
  /* @__PURE__ */ createBaseVNode("strong", null, "does not"),
  /* @__PURE__ */ createTextVNode(" alter the content area of "),
  /* @__PURE__ */ createBaseVNode("strong", null, "v-main"),
  /* @__PURE__ */ createTextVNode(". The width can be controlled with the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "rail-width"),
  /* @__PURE__ */ createTextVNode(" property.")
], -1);
const _hoisted_23 = { id: "background-images" };
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Apply a custom background to your drawer via the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "image"),
  /* @__PURE__ */ createTextVNode(" prop. If you need to customize it further, you can use the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "image"),
  /* @__PURE__ */ createTextVNode(" slot and render your own "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-img"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_25 = { id: "rail-variant" };
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("When using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "rail"),
  /* @__PURE__ */ createTextVNode(" prop, the drawer will shrink (default 56px) and hide everything inside of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-list"),
  /* @__PURE__ */ createTextVNode(" except the first element.")
], -1);
const _hoisted_27 = { id: "floating" };
const _hoisted_28 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("By default, a navigation drawer has a 1px right border that separates it from content. In this example we want to detach the drawer from the left side and let it float on its own. The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "floating"),
  /* @__PURE__ */ createTextVNode(" property removes the right border (or left if using "),
  /* @__PURE__ */ createBaseVNode("strong", null, "position"),
  /* @__PURE__ */ createTextVNode(" prop).")
], -1);
const _hoisted_29 = { id: "location" };
const _hoisted_30 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Navigation drawers can also be positioned on the opposite side of your application (or an element) using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "location"),
  /* @__PURE__ */ createTextVNode(" prop. This is useful for creating a side-sheet with auxiliary information that may not have any navigation links.")
], -1);
const _hoisted_31 = { id: "temporary" };
const _hoisted_32 = /* @__PURE__ */ createBaseVNode("p", null, "A temporary drawer sits above its application and uses a scrim (overlay) to darken the background. This drawer behavior is mimicked by default when on mobile. Clicking outside of the drawer will cause it to close.", -1);
const _hoisted_33 = { id: "misc" };
const _hoisted_34 = { id: "colored-drawer" };
const _hoisted_35 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Navigation drawers can be customized to fit any application’s design. Here we apply a custom background color and an appended content area using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "append"),
  /* @__PURE__ */ createTextVNode(" slot.")
], -1);
const _hoisted_36 = { id: "multiple-drawers" };
const _hoisted_37 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("In this example we define two navigation-drawers, one using "),
  /* @__PURE__ */ createBaseVNode("strong", null, "rail"),
  /* @__PURE__ */ createTextVNode(" and one without.")
], -1);
const frontmatter = { "meta": { "nav": "Navigation drawers", "title": "Navigation drawer component", "description": "The navigation drawer component contains internal navigation links for an application and can be permanently on-screen or controlled programmatically.", "keywords": "navigation drawer, vuetify navigation drawer component, vue navigation drawer component" }, "related": ["/components/lists/", "/components/icons/", "/getting-started/wireframes/"], "features": { "label": "C: VNavigationDrawer", "report": true, "github": "/components/VNavigationDrawer/", "spec": "https://m2.material.io/components/navigation-drawer" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "navigation-drawers",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Navigation drawers", "title": "Navigation drawer component", "description": "The navigation drawer component contains internal navigation links for an application and can be permanently on-screen or controlled programmatically.", "keywords": "navigation drawer, vuetify navigation drawer component, vue navigation drawer component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Navigation drawers", "title": "Navigation drawer component", "description": "The navigation drawer component contains internal navigation links for an application and can be permanently on-screen or controlled programmatically.", "keywords": "navigation drawer, vuetify navigation drawer component, vue navigation drawer component" }, "related": ["/components/lists/", "/components/icons/", "/getting-started/wireframes/"], "features": { "label": "C: VNavigationDrawer", "report": true, "github": "/components/VNavigationDrawer/", "spec": "https://m2.material.io/components/navigation-drawer" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_app_link = resolveComponent("app-link");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_alert = resolveComponent("alert");
      const _component_app_markup = resolveComponent("app-markup");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#navigation-drawers",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Navigation drawers")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("The navigation drawer is primarily used to house links to the pages in your application and is pre-configured to work with or without "),
                  _hoisted_4,
                  createTextVNode(" right out the box. Using "),
                  _hoisted_5,
                  createTextVNode(" as the starting value for its "),
                  _hoisted_6,
                  createTextVNode(" will initialize the drawer as closed on mobile and as open on desktop. It is common to pair drawers with the "),
                  createVNode(_component_app_link, { href: "/components/lists" }, {
                    default: withCtx(() => [
                      createTextVNode("v-list")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" component using the "),
                  _hoisted_7,
                  createTextVNode(" property.")
                ]),
                createVNode(_component_examples_usage, { name: "v-navigation-drawer" }),
                createVNode(_component_promoted_entry),
                createVNode(_component_alert, { type: "tip" }, {
                  default: withCtx(() => [
                    _hoisted_8,
                    _hoisted_9
                  ]),
                  _: 1
                }),
                createVNode(_component_app_markup, {
                  resource: "src/App.vue",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_10
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_11, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_12,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-navigation-drawer/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-navigation-drawer")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_13
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-list-item/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-list-item")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_14
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_15, [
                createVNode(_component_app_heading, {
                  href: "#caveats",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Caveats")
                  ]),
                  _: 1
                }),
                createVNode(_component_alert, { type: "info" }, {
                  default: withCtx(() => [
                    _hoisted_16
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_17, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_18, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_19, [
                    createVNode(_component_app_heading, {
                      href: "#bottom-drawer",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Bottom drawer")
                      ]),
                      _: 1
                    }),
                    _hoisted_20,
                    createVNode(_component_examples_example, { file: "v-navigation-drawer/prop-bottom-drawer" })
                  ]),
                  createBaseVNode("section", _hoisted_21, [
                    createVNode(_component_app_heading, {
                      href: "#expand-on-hover",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Expand on hover")
                      ]),
                      _: 1
                    }),
                    _hoisted_22,
                    createVNode(_component_examples_example, { file: "v-navigation-drawer/prop-expand-on-hover" })
                  ]),
                  createBaseVNode("section", _hoisted_23, [
                    createVNode(_component_app_heading, {
                      href: "#background-images",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Background images")
                      ]),
                      _: 1
                    }),
                    _hoisted_24,
                    createVNode(_component_examples_example, { file: "v-navigation-drawer/prop-images" })
                  ]),
                  createBaseVNode("section", _hoisted_25, [
                    createVNode(_component_app_heading, {
                      href: "#rail-variant",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Rail variant")
                      ]),
                      _: 1
                    }),
                    _hoisted_26,
                    createVNode(_component_examples_example, { file: "v-navigation-drawer/prop-mini-variant" })
                  ]),
                  createBaseVNode("section", _hoisted_27, [
                    createVNode(_component_app_heading, {
                      href: "#floating",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Floating")
                      ]),
                      _: 1
                    }),
                    _hoisted_28,
                    createVNode(_component_examples_example, { file: "v-navigation-drawer/prop-permanent-and-floating" })
                  ]),
                  createBaseVNode("section", _hoisted_29, [
                    createVNode(_component_app_heading, {
                      href: "#location",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Location")
                      ]),
                      _: 1
                    }),
                    _hoisted_30,
                    createVNode(_component_examples_example, { file: "v-navigation-drawer/prop-right" })
                  ]),
                  createBaseVNode("section", _hoisted_31, [
                    createVNode(_component_app_heading, {
                      href: "#temporary",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Temporary")
                      ]),
                      _: 1
                    }),
                    _hoisted_32,
                    createVNode(_component_examples_example, { file: "v-navigation-drawer/prop-temporary" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_33, [
                  createVNode(_component_app_heading, {
                    href: "#misc",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Misc")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_34, [
                    createVNode(_component_app_heading, {
                      href: "#colored-drawer",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Colored drawer")
                      ]),
                      _: 1
                    }),
                    _hoisted_35,
                    createVNode(_component_examples_example, { file: "v-navigation-drawer/misc-colored" })
                  ]),
                  createBaseVNode("section", _hoisted_36, [
                    createVNode(_component_app_heading, {
                      href: "#multiple-drawers",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Multiple drawers")
                      ]),
                      _: 1
                    }),
                    _hoisted_37,
                    createVNode(_component_examples_example, { file: "v-navigation-drawer/misc-combined" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
