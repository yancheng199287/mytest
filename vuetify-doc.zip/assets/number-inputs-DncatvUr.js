import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "number-inputs" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The VNumberInput extends the standard HTML number-type input, ensuring style consistency across browsers as a replacement for "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, '<input type="number">')
], -1);
const _hoisted_3 = { id: "installation" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, "Labs components require a manual import and installation of the component.", -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-js" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/plugins/vuetify.js",
    class: "language-js"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" VNumberInput "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify/labs/VNumberInput'"),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "export"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "default"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "createVuetify"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "components"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n    VNumberInput"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_6 = { id: "usage" };
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("p", null, "Here we display a list of settings that could be applied within an application.", -1);
const _hoisted_8 = { id: "api" };
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_11 = { id: "guide" };
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-number-input"),
  /* @__PURE__ */ createTextVNode(" component is built upon the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-field"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-input"),
  /* @__PURE__ */ createTextVNode(" components. It is used as a replacement for "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, '<input type="number">'),
  /* @__PURE__ */ createTextVNode(", accepting numeric values from the user.")
], -1);
const _hoisted_13 = { id: "props" };
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-number-input"),
  /* @__PURE__ */ createTextVNode(" component has support for most of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-field"),
  /* @__PURE__ */ createTextVNode("’s props and is follows the same design patterns as other inputs.")
], -1);
const _hoisted_15 = { id: "control-variant" };
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "control-variant"),
  /* @__PURE__ */ createTextVNode(" prop offers an easy way to customize steppers button layout. The following values are valid options: "),
  /* @__PURE__ */ createBaseVNode("strong", null, "default"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "stacked"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "split"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_17 = { id: "reverse" };
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "reverse"),
  /* @__PURE__ */ createTextVNode(" prop automatically changes the stepper buttons’ position to the opposite side for both the default and stacked control variants.")
], -1);
const _hoisted_19 = { id: "hide-input" };
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "hide-input"),
  /* @__PURE__ */ createTextVNode(" prop hides the input field, allowing only the stepper buttons to be visible. These stepper buttons follow a stacked control-variant layout.")
], -1);
const _hoisted_21 = { id: "inset" };
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "inset"),
  /* @__PURE__ */ createTextVNode(" prop adjusts the style of the stepper buttons by reducing the size of the button dividers.")
], -1);
const _hoisted_23 = { id: "min-max" };
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "min"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "max"),
  /* @__PURE__ */ createTextVNode(" props specify the minimum and maximum values accepted by v-number-input, behaving identically to the native min and max attributes for "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, '<input type="number">'),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_25 = { id: "step" };
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "step"),
  /* @__PURE__ */ createTextVNode(" prop behaves the same as the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "step"),
  /* @__PURE__ */ createTextVNode(" attribute in the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, '<input type="number">'),
  /* @__PURE__ */ createTextVNode(", it defines the incremental steps for adjusting the numeric value.")
], -1);
const frontmatter = { "emphasized": true, "meta": { "title": "Number inputs", "description": "The Number input component is used for ...", "keywords": "Number, vuetify number input component, vue number component" }, "related": ["/components/inputs/", "/components/text-fields/", "/components/forms/"], "features": { "label": "C: VNumberInput", "github": "/components/VNumberInput/", "report": true } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "number-inputs",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "Number inputs", "description": "The Number input component is used for ...", "keywords": "Number, vuetify number input component, vue number component" } };
    useHead(head);
    __expose({ frontmatter: { "emphasized": true, "meta": { "title": "Number inputs", "description": "The Number input component is used for ...", "keywords": "Number, vuetify number input component, vue number component" }, "related": ["/components/inputs/", "/components/text-fields/", "/components/forms/"], "features": { "label": "C: VNumberInput", "github": "/components/VNumberInput/", "report": true } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_app_link = resolveComponent("app-link");
      const _component_alert = resolveComponent("alert");
      const _component_app_markup = resolveComponent("app-markup");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#number-inputs",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Number inputs")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_alert, { type: "warning" }, {
                default: withCtx(() => [
                  createBaseVNode("p", null, [
                    createTextVNode("This feature requires "),
                    createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v3.5.10" }, {
                      default: withCtx(() => [
                        createTextVNode("v3.5.10")
                      ]),
                      _: 1
                    })
                  ])
                ]),
                _: 1
              }),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#installation",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Installation")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_app_markup, {
                  resource: "src/plugins/vuetify.js",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_5
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_6, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_7,
                createVNode(_component_examples_usage, { name: "v-number-input" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_8, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_9,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-number-input/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-number-input")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_10
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_11, [
                createVNode(_component_app_heading, {
                  href: "#guide",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Guide")
                  ]),
                  _: 1
                }),
                _hoisted_12,
                createBaseVNode("section", _hoisted_13, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  _hoisted_14,
                  createBaseVNode("section", _hoisted_15, [
                    createVNode(_component_app_heading, {
                      href: "#control-variant",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Control-variant")
                      ]),
                      _: 1
                    }),
                    _hoisted_16,
                    createVNode(_component_examples_example, { file: "v-number-input/prop-control-variant" })
                  ]),
                  createBaseVNode("section", _hoisted_17, [
                    createVNode(_component_app_heading, {
                      href: "#reverse",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Reverse")
                      ]),
                      _: 1
                    }),
                    _hoisted_18,
                    createVNode(_component_examples_example, { file: "v-number-input/prop-reverse" })
                  ]),
                  createBaseVNode("section", _hoisted_19, [
                    createVNode(_component_app_heading, {
                      href: "#hide-input",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Hide-input")
                      ]),
                      _: 1
                    }),
                    _hoisted_20,
                    createVNode(_component_examples_example, { file: "v-number-input/prop-hide-input" })
                  ]),
                  createBaseVNode("section", _hoisted_21, [
                    createVNode(_component_app_heading, {
                      href: "#inset",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Inset")
                      ]),
                      _: 1
                    }),
                    _hoisted_22,
                    createVNode(_component_examples_example, { file: "v-number-input/prop-inset" })
                  ]),
                  createBaseVNode("section", _hoisted_23, [
                    createVNode(_component_app_heading, {
                      href: "#min-max",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Min/Max")
                      ]),
                      _: 1
                    }),
                    _hoisted_24,
                    createVNode(_component_examples_example, { file: "v-number-input/prop-min-max" })
                  ]),
                  createBaseVNode("section", _hoisted_25, [
                    createVNode(_component_app_heading, {
                      href: "#step",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Step")
                      ]),
                      _: 1
                    }),
                    _hoisted_26,
                    createVNode(_component_examples_example, { file: "v-number-input/prop-step" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
