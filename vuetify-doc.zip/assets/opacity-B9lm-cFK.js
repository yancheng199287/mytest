import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "opacity" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "Utilities for controlling the opacity of elements in your application.", -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Class"),
    /* @__PURE__ */ createBaseVNode("th", null, "Properties")
  ])
], -1);
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("tbody", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "opacity-0")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "opacity: 0;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "opacity-10")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "opacity: .1;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "opacity-20")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "opacity: .2;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "opacity-30")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "opacity: .3;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "opacity-40")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "opacity: .4;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "opacity-50")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "opacity: .5;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "opacity-60")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "opacity: .6;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "opacity-70")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "opacity: .7;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "opacity-80")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "opacity: .8;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "opacity-90")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "opacity: .9;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "opacity-100")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "opacity: 1;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "opacity-hover")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "opacity: var(–v-hover-opacity);")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "opacity-focus")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "opacity: var(–v-focus-opacity);")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "opacity-selected")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "opacity: var(–v-selected-opacity);")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "opacity-activated")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "opacity: var(–v-activated-opacity);")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "opacity-pressed")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "opacity: var(–v-pressed-opacity);")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "opacity-dragged")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "opacity: var(–v-dragged-opacity);")
  ])
], -1);
const _hoisted_5 = { id: "usage" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "opacity"),
  /* @__PURE__ */ createTextVNode(" utilities allow you to quickly change the opacity of any element.")
], -1);
const _hoisted_7 = { id: "hover" };
const _hoisted_8 = { id: "sass-variables" };
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("p", null, "You can also use the following SASS variables to customize the opacity color and width:", -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-sass" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/styles/settings.scss",
    class: "language-sass"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token atrule-line" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token atrule" }, "@use"),
      /* @__PURE__ */ createTextVNode(" 'vuetify/settings' with (")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token variable-line" }, [
      /* @__PURE__ */ createTextVNode("  "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token variable" }, "$opacities"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
      /* @__PURE__ */ createTextVNode(" (")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property-line" }, [
      /* @__PURE__ */ createTextVNode("    "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, "hover"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
      /* @__PURE__ */ createTextVNode(" var(--v-hover-opacity),")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property-line" }, [
      /* @__PURE__ */ createTextVNode("    "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, "focus"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
      /* @__PURE__ */ createTextVNode(" var(--v-focus-opacity),")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property-line" }, [
      /* @__PURE__ */ createTextVNode("    "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, "selected"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
      /* @__PURE__ */ createTextVNode(" var(--v-selected-opacity),")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property-line" }, [
      /* @__PURE__ */ createTextVNode("    "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, "activated"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
      /* @__PURE__ */ createTextVNode(" var(--v-activated-opacity),")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property-line" }, [
      /* @__PURE__ */ createTextVNode("    "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, "pressed"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
      /* @__PURE__ */ createTextVNode(" var(--v-pressed-opacity),")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property-line" }, [
      /* @__PURE__ */ createTextVNode("    "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, "dragged"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
      /* @__PURE__ */ createTextVNode(" var(--v-dragged-opacity),")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property-line" }, [
      /* @__PURE__ */ createTextVNode("    "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, "0"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
      /* @__PURE__ */ createTextVNode(" 0,")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property-line" }, [
      /* @__PURE__ */ createTextVNode("    "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, "10"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
      /* @__PURE__ */ createTextVNode(" .1,")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property-line" }, [
      /* @__PURE__ */ createTextVNode("    "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, "20"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
      /* @__PURE__ */ createTextVNode(" .2,")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property-line" }, [
      /* @__PURE__ */ createTextVNode("    "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, "30"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
      /* @__PURE__ */ createTextVNode(" .3,")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property-line" }, [
      /* @__PURE__ */ createTextVNode("    "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, "40"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
      /* @__PURE__ */ createTextVNode(" .4,")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property-line" }, [
      /* @__PURE__ */ createTextVNode("    "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, "50"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
      /* @__PURE__ */ createTextVNode(" .5,")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property-line" }, [
      /* @__PURE__ */ createTextVNode("    "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, "60"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
      /* @__PURE__ */ createTextVNode(" .6,")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property-line" }, [
      /* @__PURE__ */ createTextVNode("    "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, "70"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
      /* @__PURE__ */ createTextVNode(" .7,")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property-line" }, [
      /* @__PURE__ */ createTextVNode("    "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, "80"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
      /* @__PURE__ */ createTextVNode(" .8,")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property-line" }, [
      /* @__PURE__ */ createTextVNode("    "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, "90"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
      /* @__PURE__ */ createTextVNode(" .9,")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property-line" }, [
      /* @__PURE__ */ createTextVNode("    "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, "100"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
      /* @__PURE__ */ createTextVNode(" 1")
    ]),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token selector" }, ")"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token selector" }, ");"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Disable opacity class generation by setting the $opacities variable to "),
  /* @__PURE__ */ createBaseVNode("strong", null, "false"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-sass" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/styles/settings.scss",
    class: "language-sass"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token atrule-line" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token atrule" }, "@use"),
      /* @__PURE__ */ createTextVNode(" 'vuetify/settings' with (")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token variable-line" }, [
      /* @__PURE__ */ createTextVNode("  "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token variable" }, "$opacities"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
      /* @__PURE__ */ createTextVNode(" false")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token selector" }, ");"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const frontmatter = { "emphasized": true, "meta": { "title": "Opacity", "description": "Use opacity utilities to quickly style the opacity of any element.", "keywords": "opacity classes, opacity utilities, vuetify opacity helper classes" }, "related": ["/styles/opacity-radius/", "/styles/display/", "/styles/content/"], "features": { "report": true } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "opacity",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "Opacity", "description": "Use opacity utilities to quickly style the opacity of any element.", "keywords": "opacity classes, opacity utilities, vuetify opacity helper classes" } };
    useHead(head);
    __expose({ frontmatter: { "emphasized": true, "meta": { "title": "Opacity", "description": "Use opacity utilities to quickly style the opacity of any element.", "keywords": "opacity classes, opacity utilities, vuetify opacity helper classes" }, "related": ["/styles/opacity-radius/", "/styles/display/", "/styles/content/"], "features": { "report": true } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_app_link = resolveComponent("app-link");
      const _component_alert = resolveComponent("alert");
      const _component_app_table = resolveComponent("app-table");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_app_markup = resolveComponent("app-markup");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#opacity",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Opacity")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_alert, { type: "success" }, {
                default: withCtx(() => [
                  createBaseVNode("p", null, [
                    createTextVNode("This feature was introduced in "),
                    createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v3.6.0" }, {
                      default: withCtx(() => [
                        createTextVNode("v3.6.0 (Nebula)")
                      ]),
                      _: 1
                    })
                  ])
                ]),
                _: 1
              }),
              createVNode(_component_app_table, {
                style: { "max-height": "420px" },
                "fixed-header": ""
              }, {
                default: withCtx(() => [
                  _hoisted_3,
                  _hoisted_4
                ]),
                _: 1
              }),
              createVNode(_component_promoted_entry),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_6,
                createVNode(_component_examples_example, { file: "opacity/misc-opacity" }),
                createBaseVNode("section", _hoisted_7, [
                  createVNode(_component_app_heading, {
                    href: "#hover",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Hover")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("p", null, [
                    createTextVNode("Using the "),
                    createVNode(_component_app_link, { href: "/components/hover/" }, {
                      default: withCtx(() => [
                        createTextVNode("v-hover")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" component, conditionally apply an opacity class when the element is hovered over.")
                  ]),
                  createVNode(_component_examples_example, { file: "opacity/misc-hover" })
                ])
              ]),
              createBaseVNode("section", _hoisted_8, [
                createVNode(_component_app_heading, {
                  href: "#sass-variables",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("SASS variables")
                  ]),
                  _: 1
                }),
                _hoisted_9,
                createVNode(_component_app_markup, {
                  resource: "src/styles/settings.scss",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_10
                  ]),
                  _: 1
                }),
                _hoisted_11,
                createVNode(_component_app_markup, {
                  resource: "src/styles/settings.scss",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_12
                  ]),
                  _: 1
                })
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
