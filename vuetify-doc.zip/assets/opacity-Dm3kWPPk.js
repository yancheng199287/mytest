import { y as _export_sfc, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, b as createVNode, a9 as mergeProps, e as createBaseVNode } from "./index-DGybHjCP.js";
const _sfc_main$1 = {};
function _sfc_render$1(_ctx, _cache) {
  const _component_v_card = resolveComponent("v-card");
  const _component_v_hover = resolveComponent("v-hover");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, null, {
    default: withCtx(() => [
      createVNode(_component_v_hover, null, {
        default: withCtx(({ props: hoverProps, isHovering }) => [
          createVNode(_component_v_card, mergeProps(hoverProps, {
            class: [
              "mx-auto",
              isHovering ? "opacity-100" : "opacity-50"
            ],
            color: "secondary",
            height: "128",
            width: "256",
            flat: ""
          }), null, 16, ["class"])
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["render", _sfc_render$1]]);
const __0_raw = `<template>
  <v-container>
    <v-hover>
      <template v-slot:default="{ props: hoverProps, isHovering }">
        <v-card
          v-bind="hoverProps"
          :class="[
            'mx-auto',
            isHovering ? 'opacity-100' : 'opacity-50'
          ]"
          color="secondary"
          height="128"
          width="256"
          flat
        ></v-card>
      </template>
    </v-hover>
  </v-container>
</template>
`;
const _sfc_main = {};
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-center" }, [
  /* @__PURE__ */ createBaseVNode("div", {
    class: "bg-primary opacity-100",
    style: { "height": "64px", "width": "64px" }
  }),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "opacity-100")
], -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("div", { class: "text-center" }, [
  /* @__PURE__ */ createBaseVNode("div", {
    class: "bg-primary opacity-80",
    style: { "height": "64px", "width": "64px" }
  }),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "opacity-80")
], -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("div", { class: "text-center" }, [
  /* @__PURE__ */ createBaseVNode("div", {
    class: "bg-primary opacity-60",
    style: { "height": "64px", "width": "64px" }
  }),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "opacity-60")
], -1);
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("div", { class: "text-center" }, [
  /* @__PURE__ */ createBaseVNode("div", {
    class: "bg-primary opacity-40",
    style: { "height": "64px", "width": "64px" }
  }),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "opacity-40")
], -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("div", { class: "text-center" }, [
  /* @__PURE__ */ createBaseVNode("div", {
    class: "bg-primary opacity-20",
    style: { "height": "64px", "width": "64px" }
  }),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "opacity-20")
], -1);
function _sfc_render(_ctx, _cache) {
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, null, {
    default: withCtx(() => [
      createVNode(_component_v_row, { justify: "space-around" }, {
        default: withCtx(() => [
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              _hoisted_1
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              _hoisted_2
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              _hoisted_3
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              _hoisted_4
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              _hoisted_5
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __1 = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
const __1_raw = '<template>\n  <v-container>\n    <v-row justify="space-around">\n      <v-col cols="auto">\n        <div class="text-center">\n          <div class="bg-primary opacity-100" style="height: 64px; width: 64px;"></div>\n          <div class="text-caption">opacity-100</div>\n        </div>\n      </v-col>\n\n      <v-col cols="auto">\n        <div class="text-center">\n          <div class="bg-primary opacity-80" style="height: 64px; width: 64px;"></div>\n          <div class="text-caption">opacity-80</div>\n        </div>\n      </v-col>\n\n      <v-col cols="auto">\n        <div class="text-center">\n          <div class="bg-primary opacity-60" style="height: 64px; width: 64px;"></div>\n          <div class="text-caption">opacity-60</div>\n        </div>\n      </v-col>\n\n      <v-col cols="auto">\n        <div class="text-center">\n          <div class="bg-primary opacity-40" style="height: 64px; width: 64px;"></div>\n          <div class="text-caption">opacity-40</div>\n        </div>\n      </v-col>\n\n      <v-col cols="auto">\n        <div class="text-center">\n          <div class="bg-primary opacity-20" style="height: 64px; width: 64px;"></div>\n          <div class="text-caption">opacity-20</div>\n        </div>\n      </v-col>\n    </v-row>\n  </v-container>\n</template>\n';
const opacity = {
  "misc-hover": {
    component: __0,
    source: __0_raw
  },
  "misc-opacity": {
    component: __1,
    source: __1_raw
  }
};
export {
  opacity as default
};
