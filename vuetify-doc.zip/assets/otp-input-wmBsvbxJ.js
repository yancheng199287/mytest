import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "otp-input" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "The OTP input is used for MFA procedure of authenticating users by a one-time password.", -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, "Here we display a list of settings that could be applied within an application.", -1);
const _hoisted_5 = { id: "api" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_8 = { id: "anatomy" };
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-otp-input", -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Element / Area"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("tbody", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "1. Container"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("The OTP input container holds a number of "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-field"),
      /* @__PURE__ */ createTextVNode(" components")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "2. Field"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("The "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-field"),
      /* @__PURE__ */ createTextVNode(" component is used to create a single input field")
    ])
  ])
], -1);
const _hoisted_12 = { id: "guide" };
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-otp-input"),
  /* @__PURE__ */ createTextVNode(" component is a collection of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-field"),
  /* @__PURE__ */ createTextVNode(" components that combine to create a single input. It is used to validate a one-time password (OTP) that is sent to the user via email or SMS.")
], -1);
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The following code snippet is an example of a basic "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-otp-input"),
  /* @__PURE__ */ createTextVNode(" component.")
], -1);
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-html" }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-otp-input")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("v-otp-input")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_16 = { id: "props" };
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-otp-input"),
  /* @__PURE__ */ createTextVNode(" component has support for most of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-field"),
  /* @__PURE__ */ createTextVNode("’s props and is follows the same design patterns as other inputs.")
], -1);
const _hoisted_18 = { id: "length" };
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "length"),
  /* @__PURE__ */ createTextVNode(" prop determines the number of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-field"),
  /* @__PURE__ */ createTextVNode(" components that are rendered. The default value is "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "6"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_20 = { id: "focus-all" };
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "autofocus"),
  /* @__PURE__ */ createTextVNode(" prop automatically focuses the first element in the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-otp-input"),
  /* @__PURE__ */ createTextVNode(" component.")
], -1);
const _hoisted_22 = { id: "error" };
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "error"),
  /* @__PURE__ */ createTextVNode(" prop puts the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-otp-input"),
  /* @__PURE__ */ createTextVNode(" into an error state. This is useful for displaying validation errors.")
], -1);
const _hoisted_24 = { id: "variants" };
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-otp-input"),
  /* @__PURE__ */ createTextVNode(" component supports the same variants as "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-field"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-text-field"),
  /* @__PURE__ */ createTextVNode(" and other inputs.")
], -1);
const _hoisted_26 = { id: "loader" };
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "loader"),
  /* @__PURE__ */ createTextVNode(" prop displays a loader when the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-otp-input"),
  /* @__PURE__ */ createTextVNode(" component is in a loading state. When complete, emits a "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "finish"),
  /* @__PURE__ */ createTextVNode(" event.")
], -1);
const _hoisted_28 = { id: "examples" };
const _hoisted_29 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The following are a collection of examples that demonstrate more advanced and real world use of the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-otp-input"),
  /* @__PURE__ */ createTextVNode(" component.")
], -1);
const _hoisted_30 = { id: "card-variants" };
const _hoisted_31 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The following example is a detailed example of a "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-otp-input"),
  /* @__PURE__ */ createTextVNode(" component used within a card.")
], -1);
const _hoisted_32 = { id: "mobile-text" };
const _hoisted_33 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The following example is a detailed example of a "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-otp-input"),
  /* @__PURE__ */ createTextVNode(" component used with mobile text.")
], -1);
const _hoisted_34 = { id: "verify-account" };
const _hoisted_35 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The following example is a detailed example of a "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-otp-input"),
  /* @__PURE__ */ createTextVNode(" component used to verify a user’s account.")
], -1);
const _hoisted_36 = { id: "divider" };
const _hoisted_37 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The following example is a detailed example of a "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-otp-input"),
  /* @__PURE__ */ createTextVNode(" component used with a divider.")
], -1);
const frontmatter = { "meta": { "title": "OTP Input", "description": "The OTP input component is used for MFA authentication via input field.", "keywords": "OTP, MFA, vuetify OTP input component, vue OTP component" }, "related": ["/components/inputs/", "/components/text-fields/", "/components/forms/"], "features": { "label": "C: VOtpInput", "github": "/components/VOtpInput/", "report": true } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "otp-input",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "OTP Input", "description": "The OTP input component is used for MFA authentication via input field.", "keywords": "OTP, MFA, vuetify OTP input component, vue OTP component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "title": "OTP Input", "description": "The OTP input component is used for MFA authentication via input field.", "keywords": "OTP, MFA, vuetify OTP input component, vue OTP component" }, "related": ["/components/inputs/", "/components/text-fields/", "/components/forms/"], "features": { "label": "C: VOtpInput", "github": "/components/VOtpInput/", "report": true } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_app_figure = resolveComponent("app-figure");
      const _component_page_features = resolveComponent("page-features");
      const _component_app_link = resolveComponent("app-link");
      const _component_alert = resolveComponent("alert");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_app_markup = resolveComponent("app-markup");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#otp-input",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("OTP Input")
                ]),
                _: 1
              }),
              _hoisted_2,
              createBaseVNode("p", null, [
                createBaseVNode("div", null, [
                  createVNode(_component_app_figure, {
                    alt: "Otp input Entry",
                    src: "https://cdn.vuetifyjs.com/docs/images/components/v-otp-input/v-otp-input-entry.png"
                  })
                ])
              ]),
              createVNode(_component_page_features),
              createVNode(_component_alert, { type: "success" }, {
                default: withCtx(() => [
                  createBaseVNode("p", null, [
                    createTextVNode("This feature was introduced in "),
                    createVNode(_component_app_link, { href: "/introduction/roadmap/#v3-4-blackguard" }, {
                      default: withCtx(() => [
                        createTextVNode("v3.4.0 (Blackguard)")
                      ]),
                      _: 1
                    })
                  ])
                ]),
                _: 1
              }),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_usage, { name: "v-otp-input" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_6,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-otp-input/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-otp-input")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_8, [
                createVNode(_component_app_heading, {
                  href: "#anatomy",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Anatomy")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("The "),
                  _hoisted_9,
                  createTextVNode(" component is a collection of "),
                  createVNode(_component_app_link, { href: "/api/v-field/" }, {
                    default: withCtx(() => [
                      createTextVNode("v-field")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" components that combine to create a single input.")
                ]),
                createBaseVNode("p", null, [
                  createBaseVNode("div", null, [
                    createVNode(_component_app_figure, {
                      alt: "Otp input Anatomy",
                      src: "https://cdn.vuetifyjs.com/docs/images/components/v-otp-input/v-otp-input-anatomy.png",
                      title: "OTP input Anatomy"
                    })
                  ])
                ]),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_10,
                    _hoisted_11
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_12, [
                createVNode(_component_app_heading, {
                  href: "#guide",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Guide")
                  ]),
                  _: 1
                }),
                _hoisted_13,
                _hoisted_14,
                createVNode(_component_app_markup, {
                  resource: "",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_15
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_16, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  _hoisted_17,
                  createBaseVNode("section", _hoisted_18, [
                    createVNode(_component_app_heading, {
                      href: "#length",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Length")
                      ]),
                      _: 1
                    }),
                    _hoisted_19,
                    createVNode(_component_examples_example, { file: "v-otp-input/prop-length" })
                  ]),
                  createBaseVNode("section", _hoisted_20, [
                    createVNode(_component_app_heading, {
                      href: "#focus-all",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Focus-all")
                      ]),
                      _: 1
                    }),
                    _hoisted_21,
                    createVNode(_component_examples_example, { file: "v-otp-input/prop-focus-all" })
                  ]),
                  createBaseVNode("section", _hoisted_22, [
                    createVNode(_component_app_heading, {
                      href: "#error",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Error")
                      ]),
                      _: 1
                    }),
                    _hoisted_23,
                    createVNode(_component_examples_example, { file: "v-otp-input/prop-error" })
                  ]),
                  createBaseVNode("section", _hoisted_24, [
                    createVNode(_component_app_heading, {
                      href: "#variants",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Variants")
                      ]),
                      _: 1
                    }),
                    _hoisted_25,
                    createVNode(_component_examples_example, { file: "v-otp-input/prop-variant" })
                  ]),
                  createBaseVNode("section", _hoisted_26, [
                    createVNode(_component_app_heading, {
                      href: "#loader",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Loader")
                      ]),
                      _: 1
                    }),
                    _hoisted_27,
                    createVNode(_component_examples_example, { file: "v-otp-input/prop-loader" })
                  ])
                ])
              ]),
              createBaseVNode("section", _hoisted_28, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                _hoisted_29,
                createBaseVNode("section", _hoisted_30, [
                  createVNode(_component_app_heading, {
                    href: "#card-variants",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Card variants")
                    ]),
                    _: 1
                  }),
                  _hoisted_31,
                  createVNode(_component_examples_example, { file: "v-otp-input/misc-card" })
                ]),
                createBaseVNode("section", _hoisted_32, [
                  createVNode(_component_app_heading, {
                    href: "#mobile-text",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Mobile text")
                    ]),
                    _: 1
                  }),
                  _hoisted_33,
                  createVNode(_component_examples_example, { file: "v-otp-input/misc-mobile" })
                ]),
                createBaseVNode("section", _hoisted_34, [
                  createVNode(_component_app_heading, {
                    href: "#verify-account",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Verify account")
                    ]),
                    _: 1
                  }),
                  _hoisted_35,
                  createVNode(_component_examples_example, { file: "v-otp-input/misc-verify" })
                ]),
                createBaseVNode("section", _hoisted_36, [
                  createVNode(_component_app_heading, {
                    href: "#divider",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Divider")
                    ]),
                    _: 1
                  }),
                  _hoisted_37,
                  createVNode(_component_examples_example, { file: "v-otp-input/misc-divider" })
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
