import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "overflow" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "Configure how content overflows when it becomes out of container bounds.", -1);
const _hoisted_3 = { id: "how-it-works" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Specify the elements "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "overflow"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "overflow-x"),
  /* @__PURE__ */ createTextVNode(", or "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "overflow-y"),
  /* @__PURE__ */ createTextVNode(" property. These classes can be applied using the following format: "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "{overflow}-{value}"),
  /* @__PURE__ */ createTextVNode(". Where "),
  /* @__PURE__ */ createBaseVNode("strong", null, "overflow"),
  /* @__PURE__ */ createTextVNode(" refers to the type: "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "overflow"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "overflow-x"),
  /* @__PURE__ */ createTextVNode(" or "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "overflow-y"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "value"),
  /* @__PURE__ */ createTextVNode(" can be one of: "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "auto"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "hidden"),
  /* @__PURE__ */ createTextVNode(", or "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "visible")
], -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("p", null, "here is a list of properties:", -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "overflow-auto")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "overflow-hidden")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "overflow-visible")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "overflow-x-auto")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "overflow-x-hidden")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "overflow-x-visible")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "overflow-y-auto")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "overflow-y-hidden")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "overflow-y-visible")
  ])
], -1);
const _hoisted_7 = { id: "examples" };
const _hoisted_8 = { id: "overflow-property" };
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "overflow-auto"),
  /* @__PURE__ */ createTextVNode(" is used to add scrollbars to an element when its content overflows the bounds. while "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "overflow-hidden"),
  /* @__PURE__ */ createTextVNode(" is used to clip any content that overflows the bounds. "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "overflow-visible"),
  /* @__PURE__ */ createTextVNode(" will prevent content from being clipped even when it overflows the bounds.")
], -1);
const _hoisted_10 = { id: "overflow-x-property" };
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "overflow-x"),
  /* @__PURE__ */ createTextVNode(" can be used to specify horizontal overflows to an element if needed.")
], -1);
const frontmatter = { "meta": { "title": "Overflow", "description": "Overflow helper classes allow you to configure how content overflows when it beocomes too large.", "keywords": "overflow helper classes, overflow classes, vuetify overflow" }, "related": ["/styles/elevation/", "/styles/content/", "/components/grids/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "overflow",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "Overflow", "description": "Overflow helper classes allow you to configure how content overflows when it beocomes too large.", "keywords": "overflow helper classes, overflow classes, vuetify overflow" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "title": "Overflow", "description": "Overflow helper classes allow you to configure how content overflows when it beocomes too large.", "keywords": "overflow helper classes, overflow classes, vuetify overflow" }, "related": ["/styles/elevation/", "/styles/content/", "/components/grids/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#overflow",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Overflow")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_promoted_entry),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#how-it-works",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("How it works")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                _hoisted_5,
                _hoisted_6
              ]),
              createBaseVNode("section", _hoisted_7, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_8, [
                  createVNode(_component_app_heading, {
                    href: "#overflow-property",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Overflow property")
                    ]),
                    _: 1
                  }),
                  _hoisted_9,
                  createVNode(_component_examples_example, { file: "overflow/overflow" })
                ]),
                createBaseVNode("section", _hoisted_10, [
                  createVNode(_component_app_heading, {
                    href: "#overflow-x-property",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Overflow X property")
                    ]),
                    _: 1
                  }),
                  _hoisted_11,
                  createVNode(_component_examples_example, { file: "overflow/overflow-x" })
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
