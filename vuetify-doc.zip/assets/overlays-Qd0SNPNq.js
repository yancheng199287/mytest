import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "overlays" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-overlay"),
  /* @__PURE__ */ createTextVNode(" is the base for components that float over the rest of the page, such as "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-menu"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-dialog"),
  /* @__PURE__ */ createTextVNode(". It can also be used on its own and comes with everything you need to create a custom popover component.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("In its simplest form, the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-overlay"),
  /* @__PURE__ */ createTextVNode(" component will add a dimmed layer over your application.")
], -1);
const _hoisted_5 = { id: "api" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_8 = { id: "activator" };
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("p", null, "Overlays can be opened with v-model, or by clicking or hovering on an activator element. An activator is mandatory for the connected locationLocation strategy. The activator element (if present) will also be used by some transitions to slide or scale from the activator’s location instead of the middle of the screen.", -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("p", null, "Related props:", -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "activator")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "activatorProps")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "openOnClick")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "openOnHover")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "openOnFocus")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "closeDelay")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "openDelay")
  ])
], -1);
const _hoisted_12 = { id: "activator-prop" };
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The simplest way of providing an activator. Can be a CSS selector to pass to "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "document.querySelector()"),
  /* @__PURE__ */ createTextVNode(", a component instance, or a HTMLElement. The string "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, '"parent"'),
  /* @__PURE__ */ createTextVNode(" is also accepted to automatically bind to the parent element.")
], -1);
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-html" }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-overlay")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "activator"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("#id"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "/>")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-overlay")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "activator"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode(".class"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "/>")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-overlay")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, ":activator"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("elementRef"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "/>")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-btn")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-overlay")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "activator"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("parent"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "/>")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("v-btn")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_15 = { id: "activator-slot" };
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("For more manual control, the slot can be used instead. "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "props"),
  /* @__PURE__ */ createTextVNode(" is an object containing all the relevant ARIA attributes and event handlers, and must be applied to the target element with "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-bind"),
  /* @__PURE__ */ createTextVNode(" for the component to work correctly.")
], -1);
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-html" }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-overlay")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "#activator"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("{ isActive, props }"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-btn")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "v-bind"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("props"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("Overlay is {{ isActive ? 'open' : 'closed' }}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("v-btn")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("v-overlay")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_18 = { id: "location-strategies" };
const _hoisted_19 = { id: "static-default" };
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, 'location-strategy="static"')
], -1);
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("p", null, "Overlay content is absolutely positioned to the center of its container by default.", -1);
const _hoisted_22 = { id: "connected" };
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, 'location-strategy="connected"')
], -1);
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "location"),
  /* @__PURE__ */ createTextVNode(" selects a point on the activator, and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "origin"),
  /* @__PURE__ */ createTextVNode(" a point on the overlay content. The content element will be positioned so the two points overlap.")
], -1);
const _hoisted_25 = { id: "scroll-strategies" };
const _hoisted_26 = { id: "block-default" };
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, 'scroll-strategy="block"')
], -1);
const _hoisted_28 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "contained", -1);
const _hoisted_29 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "offsetParent", -1);
const _hoisted_30 = { id: "close" };
const _hoisted_31 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, 'scroll-strategy="close"')
], -1);
const _hoisted_32 = /* @__PURE__ */ createBaseVNode("p", null, "Scrolling when the overlay is active will de-activate it.", -1);
const _hoisted_33 = { id: "reposition" };
const _hoisted_34 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, 'scroll-strategy="reposition"')
], -1);
const _hoisted_35 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("When using the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "connected"),
  /* @__PURE__ */ createTextVNode(" location strategy, this scroll strategy will reposition the overlay element to always respect the activator location.")
], -1);
const _hoisted_36 = { id: "none" };
const _hoisted_37 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, 'scroll-strategy="none"')
], -1);
const _hoisted_38 = /* @__PURE__ */ createBaseVNode("p", null, "No scroll strategy is used.", -1);
const _hoisted_39 = { id: "examples" };
const _hoisted_40 = { id: "props" };
const _hoisted_41 = { id: "contained" };
const _hoisted_42 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("A "),
  /* @__PURE__ */ createBaseVNode("strong", null, "contained"),
  /* @__PURE__ */ createTextVNode(" overlay is positioned absolutely and contained inside its parent element.")
], -1);
const _hoisted_43 = /* @__PURE__ */ createBaseVNode("p", null, "Note: The parent element must have position: relative.", -1);
const _hoisted_44 = { id: "misc" };
const _hoisted_45 = { id: "advanced" };
const _hoisted_46 = { id: "loader" };
const _hoisted_47 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Using the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-overlay"),
  /* @__PURE__ */ createTextVNode(" as a background, add a progress component to easily create a custom loader.")
], -1);
const frontmatter = { "meta": { "nav": "Overlays", "title": "Overlay component", "description": "The overlay component makes it easy to create a scrim over components or your entire application.", "keywords": "overlays, vuetify overlay component, vue overlay component" }, "related": ["/components/dialogs/", "/components/menus/", "/components/tooltips/"], "features": { "github": "/components/VOverlay/", "label": "C: VOverlay", "report": true } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "overlays",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Overlays", "title": "Overlay component", "description": "The overlay component makes it easy to create a scrim over components or your entire application.", "keywords": "overlays, vuetify overlay component, vue overlay component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Overlays", "title": "Overlay component", "description": "The overlay component makes it easy to create a scrim over components or your entire application.", "keywords": "overlays, vuetify overlay component, vue overlay component" }, "related": ["/components/dialogs/", "/components/menus/", "/components/tooltips/"], "features": { "github": "/components/VOverlay/", "label": "C: VOverlay", "report": true } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_app_markup = resolveComponent("app-markup");
      const _component_alert = resolveComponent("alert");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#overlays",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Overlays")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_example, { file: "v-overlay/usage" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_6,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-overlay/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-overlay")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_8, [
                createVNode(_component_app_heading, {
                  href: "#activator",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Activator")
                  ]),
                  _: 1
                }),
                _hoisted_9,
                _hoisted_10,
                _hoisted_11,
                createBaseVNode("section", _hoisted_12, [
                  createVNode(_component_app_heading, {
                    href: "#activator-prop",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Activator prop")
                    ]),
                    _: 1
                  }),
                  _hoisted_13,
                  createVNode(_component_app_markup, {
                    resource: "",
                    class: "mb-4"
                  }, {
                    default: withCtx(() => [
                      _hoisted_14
                    ]),
                    _: 1
                  })
                ]),
                createBaseVNode("section", _hoisted_15, [
                  createVNode(_component_app_heading, {
                    href: "#activator-slot",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Activator slot")
                    ]),
                    _: 1
                  }),
                  _hoisted_16,
                  createVNode(_component_app_markup, {
                    resource: "",
                    class: "mb-4"
                  }, {
                    default: withCtx(() => [
                      _hoisted_17
                    ]),
                    _: 1
                  })
                ])
              ]),
              createBaseVNode("section", _hoisted_18, [
                createVNode(_component_app_heading, {
                  href: "#location-strategies",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Location Strategies")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_19, [
                  createVNode(_component_app_heading, {
                    href: "#static-default",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Static (default)")
                    ]),
                    _: 1
                  }),
                  _hoisted_20,
                  _hoisted_21
                ]),
                createBaseVNode("section", _hoisted_22, [
                  createVNode(_component_app_heading, {
                    href: "#connected",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Connected")
                    ]),
                    _: 1
                  }),
                  _hoisted_23,
                  createBaseVNode("p", null, [
                    createTextVNode("The connected strategy is used by "),
                    createVNode(_component_app_link, { href: "/components/menus" }, {
                      default: withCtx(() => [
                        createTextVNode("v-menu")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" and "),
                    createVNode(_component_app_link, { href: "/components/tooltips" }, {
                      default: withCtx(() => [
                        createTextVNode("v-tooltip")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" to attach the overlay content to an activator element.")
                  ]),
                  _hoisted_24,
                  createVNode(_component_examples_example, { file: "v-overlay/connected-playground" })
                ])
              ]),
              createBaseVNode("section", _hoisted_25, [
                createVNode(_component_app_heading, {
                  href: "#scroll-strategies",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Scroll Strategies")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_26, [
                  createVNode(_component_app_heading, {
                    href: "#block-default",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Block (default)")
                    ]),
                    _: 1
                  }),
                  _hoisted_27,
                  createBaseVNode("p", null, [
                    createTextVNode("Scrolling is blocked while the overlay is active, and the scrollbar is hidden. If "),
                    _hoisted_28,
                    createTextVNode(" is also set, scrolling will only be blocked up to the overlay’s "),
                    createVNode(_component_app_link, { href: "https://developer.mozilla.org/en-US/docs/Web/API/HTMLElement/offsetParent" }, {
                      default: withCtx(() => [
                        _hoisted_29
                      ]),
                      _: 1
                    }),
                    createTextVNode(".")
                  ]),
                  createVNode(_component_examples_example, { file: "v-overlay/scroll-block" })
                ]),
                createBaseVNode("section", _hoisted_30, [
                  createVNode(_component_app_heading, {
                    href: "#close",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Close")
                    ]),
                    _: 1
                  }),
                  _hoisted_31,
                  _hoisted_32,
                  createVNode(_component_examples_example, { file: "v-overlay/scroll-close" })
                ]),
                createBaseVNode("section", _hoisted_33, [
                  createVNode(_component_app_heading, {
                    href: "#reposition",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Reposition")
                    ]),
                    _: 1
                  }),
                  _hoisted_34,
                  _hoisted_35,
                  createVNode(_component_examples_example, { file: "v-overlay/scroll-reposition" })
                ]),
                createBaseVNode("section", _hoisted_36, [
                  createVNode(_component_app_heading, {
                    href: "#none",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("None")
                    ]),
                    _: 1
                  }),
                  _hoisted_37,
                  _hoisted_38,
                  createVNode(_component_examples_example, { file: "v-overlay/scroll-none" })
                ])
              ]),
              createBaseVNode("section", _hoisted_39, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_40, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_41, [
                    createVNode(_component_app_heading, {
                      href: "#contained",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Contained")
                      ]),
                      _: 1
                    }),
                    _hoisted_42,
                    createVNode(_component_alert, { type: "info" }, {
                      default: withCtx(() => [
                        _hoisted_43
                      ]),
                      _: 1
                    }),
                    createVNode(_component_examples_example, { file: "v-overlay/prop-contained" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_44, [
                  createVNode(_component_app_heading, {
                    href: "#misc",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Misc")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_45, [
                    createVNode(_component_app_heading, {
                      href: "#advanced",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Advanced")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("Using the "),
                      createVNode(_component_app_link, { href: "/components/hover" }, {
                        default: withCtx(() => [
                          createTextVNode("v-hover")
                        ]),
                        _: 1
                      }),
                      createTextVNode(", we are able to add a nice scrim over the information card with additional actions the user can take.")
                    ]),
                    createVNode(_component_examples_example, { file: "v-overlay/misc-advanced" })
                  ]),
                  createBaseVNode("section", _hoisted_46, [
                    createVNode(_component_app_heading, {
                      href: "#loader",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Loader")
                      ]),
                      _: 1
                    }),
                    _hoisted_47,
                    createVNode(_component_examples_example, { file: "v-overlay/misc-loader" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
