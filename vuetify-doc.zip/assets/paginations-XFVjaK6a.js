import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "pagination" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-pagination"),
  /* @__PURE__ */ createTextVNode(" component is used to separate long sets of data so that it is easier for a user to consume information.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Pagination by default displays the number of pages based on the set "),
  /* @__PURE__ */ createBaseVNode("strong", null, "length"),
  /* @__PURE__ */ createTextVNode(" prop, with "),
  /* @__PURE__ */ createBaseVNode("strong", null, "prev"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "next"),
  /* @__PURE__ */ createTextVNode(" buttons surrounding to help you navigate. Depending on the length provided, the pagination component will automatically scale. To maintain the current page, simply supply a "),
  /* @__PURE__ */ createBaseVNode("strong", null, "v-model"),
  /* @__PURE__ */ createTextVNode(" attribute.")
], -1);
const _hoisted_5 = { id: "api" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_8 = { id: "examples" };
const _hoisted_9 = { id: "props" };
const _hoisted_10 = { id: "rounded" };
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "rounded"),
  /* @__PURE__ */ createTextVNode(" prop allows you to render pagination buttons with alternative styles.")
], -1);
const _hoisted_12 = { id: "disabled" };
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Pagination items can be manually deactivated using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "disabled"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_14 = { id: "icons" };
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Previous and next page icons can be customized with the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "prev-icon"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "next-icon"),
  /* @__PURE__ */ createTextVNode(" props.")
], -1);
const _hoisted_16 = { id: "length" };
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "length"),
  /* @__PURE__ */ createTextVNode(" prop you can set the length of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-pagination"),
  /* @__PURE__ */ createTextVNode(", if the number of page buttons exceeds the parent container, it will truncate the list.")
], -1);
const _hoisted_18 = { id: "total-visible" };
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can also manually set the maximum number of visible page buttons with the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "total-visible"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const frontmatter = { "meta": { "nav": "Pagination", "title": "Pagination component", "description": "The pagination component is used to separate long sets of data so that it is easier for a user to consume information.", "keywords": "pagination, vuetify pagination component, vue pagination component" }, "related": ["/components/data-tables/basics/", "/components/data-tables/pagination/", "/components/tables/"], "features": { "figma": true, "label": "C: VPagination", "report": true, "github": "/components/VPagination/" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "paginations",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Pagination", "title": "Pagination component", "description": "The pagination component is used to separate long sets of data so that it is easier for a user to consume information.", "keywords": "pagination, vuetify pagination component, vue pagination component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Pagination", "title": "Pagination component", "description": "The pagination component is used to separate long sets of data so that it is easier for a user to consume information.", "keywords": "pagination, vuetify pagination component, vue pagination component" }, "related": ["/components/data-tables/basics/", "/components/data-tables/pagination/", "/components/tables/"], "features": { "figma": true, "label": "C: VPagination", "report": true, "github": "/components/VPagination/" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#pagination",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Pagination")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_usage, { name: "v-pagination" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_6,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-pagination/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-pagination")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_8, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_9, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_10, [
                    createVNode(_component_app_heading, {
                      href: "#rounded",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Rounded")
                      ]),
                      _: 1
                    }),
                    _hoisted_11,
                    createVNode(_component_examples_example, { file: "v-pagination/prop-rounded" })
                  ]),
                  createBaseVNode("section", _hoisted_12, [
                    createVNode(_component_app_heading, {
                      href: "#disabled",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Disabled")
                      ]),
                      _: 1
                    }),
                    _hoisted_13,
                    createVNode(_component_examples_example, { file: "v-pagination/prop-disabled" })
                  ]),
                  createBaseVNode("section", _hoisted_14, [
                    createVNode(_component_app_heading, {
                      href: "#icons",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Icons")
                      ]),
                      _: 1
                    }),
                    _hoisted_15,
                    createVNode(_component_examples_example, { file: "v-pagination/prop-icons" })
                  ]),
                  createBaseVNode("section", _hoisted_16, [
                    createVNode(_component_app_heading, {
                      href: "#length",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Length")
                      ]),
                      _: 1
                    }),
                    _hoisted_17,
                    createVNode(_component_examples_example, { file: "v-pagination/prop-length" })
                  ]),
                  createBaseVNode("section", _hoisted_18, [
                    createVNode(_component_app_heading, {
                      href: "#total-visible",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Total visible")
                      ]),
                      _: 1
                    }),
                    _hoisted_19,
                    createVNode(_component_examples_example, { file: "v-pagination/prop-total-visible" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
