import { y as _export_sfc, ao as createStaticVNode, o as openBlock, l as createElementBlock, e as createBaseVNode, F as Fragment, v as renderList, t as toDisplayString } from "./index-DGybHjCP.js";
const _sfc_main$4 = {};
const _hoisted_1$4 = /* @__PURE__ */ createStaticVNode('<div class="text-caption px-4 mb-2">With static child</div><div class="bg-surface-variant pa-4 position-relative rounded-lg mx-2 mb-2"><div class="mb-2">Relative parent</div><div class="bg-surface-light position-static pa-3"><div class="mb-2">Static parent</div><div class="position-static bg-primary rounded-lg pa-3 d-inline-block me-2"> Static child </div><div class="position-static bg-blue rounded-lg pa-3 d-inline-block"> Static sibling </div></div></div><div class="text-caption px-4 mb-2">With absolute child</div><div class="bg-surface-variant pa-4 position-relative rounded-lg mx-2 mb-2"><div class="mb-2">Relative parent</div><div class="bg-surface-light position-static pa-3"><div class="mb-3">Static parent</div><div class="position-absolute top-0 right-0 bg-primary rounded-lg pa-3 d-inline-block"> Absolute child </div><div class="position-static bg-blue rounded-lg pa-3 d-inline-block"> Static sibling </div></div></div>', 4);
function _sfc_render$4(_ctx, _cache) {
  return _hoisted_1$4;
}
const __0 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["render", _sfc_render$4]]);
const __0_raw = '<template>\n  <div class="text-caption px-4 mb-2">With static child</div>\n\n  <div class="bg-surface-variant pa-4 position-relative rounded-lg mx-2 mb-2">\n    <div class="mb-2">Relative parent</div>\n\n    <div class="bg-surface-light position-static pa-3">\n      <div class="mb-2">Static parent</div>\n\n      <div class="position-static bg-primary rounded-lg pa-3 d-inline-block me-2">\n        Static child\n      </div>\n\n      <div class="position-static bg-blue rounded-lg pa-3 d-inline-block">\n        Static sibling\n      </div>\n    </div>\n  </div>\n\n  <div class="text-caption px-4 mb-2">With absolute child</div>\n\n  <div class="bg-surface-variant pa-4 position-relative rounded-lg mx-2 mb-2">\n    <div class="mb-2">Relative parent</div>\n\n    <div class="bg-surface-light position-static pa-3">\n      <div class="mb-3">Static parent</div>\n\n      <div class="position-absolute top-0 right-0 bg-primary rounded-lg pa-3 d-inline-block">\n        Absolute child\n      </div>\n\n      <div class="position-static bg-blue rounded-lg pa-3 d-inline-block">\n        Static sibling\n      </div>\n    </div>\n  </div>\n</template>\n';
const _sfc_main$3 = {};
const _hoisted_1$3 = { class: "bg-surface-variant pa-4 position-relative rounded-lg ma-2" };
const _hoisted_2$3 = { class: "bg-surface-light position-relative py-3 ps-3" };
const _hoisted_3$3 = /* @__PURE__ */ createBaseVNode("div", { class: "position-absolute top-0 left-0 right-0 bg-primary pa-3 w-100" }, " Fixed child ", -1);
const _hoisted_4$1 = {
  class: "overflow-y-auto pe-3",
  style: { "max-height": "250px" }
};
const _hoisted_5$1 = /* @__PURE__ */ createBaseVNode("div", { class: "mt-12" }, "Relative parent", -1);
function _sfc_render$3(_ctx, _cache) {
  return openBlock(), createElementBlock("div", _hoisted_1$3, [
    createBaseVNode("div", _hoisted_2$3, [
      _hoisted_3$3,
      createBaseVNode("div", _hoisted_4$1, [
        _hoisted_5$1,
        (openBlock(), createElementBlock(Fragment, null, renderList(10, (n) => {
          return createBaseVNode("div", {
            key: n,
            class: "bg-info rounded-lg pa-3 mt-2"
          }, " Static child ");
        }), 64))
      ])
    ])
  ]);
}
const __1 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["render", _sfc_render$3]]);
const __1_raw = '<template>\n  <div class="bg-surface-variant pa-4 position-relative rounded-lg ma-2">\n    <div class="bg-surface-light position-relative py-3 ps-3">\n      <!-- position-absolute used for demonstration purposes -->\n      <div class="position-absolute top-0 left-0 right-0 bg-primary pa-3 w-100">\n        Fixed child\n      </div>\n\n      <div class="overflow-y-auto pe-3" style="max-height: 250px">\n        <div class="mt-12">Relative parent</div>\n\n        <div\n          v-for="n in 10"\n          :key="n"\n          class="bg-info rounded-lg pa-3 mt-2"\n        >\n          Static child\n        </div>\n      </div>\n    </div>\n  </div>\n</template>\n';
const _sfc_main$2 = {};
const _hoisted_1$2 = { class: "bg-surface-variant pa-4 position-relative rounded-lg ma-2" };
const _hoisted_2$2 = /* @__PURE__ */ createBaseVNode("div", { class: "bg-surface-light position-relative pa-3 pb-16" }, [
  /* @__PURE__ */ createBaseVNode("div", { class: "mb-2" }, "Relative parent"),
  /* @__PURE__ */ createBaseVNode("div", { class: "position-absolute bottom-0 right-0 bg-primary rounded-lg pa-3" }, " Absolute child ")
], -1);
const _hoisted_3$2 = [
  _hoisted_2$2
];
function _sfc_render$2(_ctx, _cache) {
  return openBlock(), createElementBlock("div", _hoisted_1$2, _hoisted_3$2);
}
const __2 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["render", _sfc_render$2]]);
const __2_raw = '<template>\n  <div class="bg-surface-variant pa-4 position-relative rounded-lg ma-2">\n    <div class="bg-surface-light position-relative pa-3 pb-16">\n      <div class="mb-2">Relative parent</div>\n\n      <div class="position-absolute bottom-0 right-0 bg-primary rounded-lg pa-3">\n        Absolute child\n      </div>\n    </div>\n  </div>\n</template>\n';
const _sfc_main$1 = {};
const _hoisted_1$1 = { class: "bg-surface-variant pa-4 position-relative rounded-lg ma-2" };
const _hoisted_2$1 = /* @__PURE__ */ createBaseVNode("div", { class: "bg-surface-light position-static pa-3 pb-16" }, [
  /* @__PURE__ */ createBaseVNode("div", { class: "mb-2" }, "Static parent"),
  /* @__PURE__ */ createBaseVNode("div", { class: "position-absolute bottom-0 right-0 bg-primary rounded-lg pa-3" }, " Absolute child ")
], -1);
const _hoisted_3$1 = [
  _hoisted_2$1
];
function _sfc_render$1(_ctx, _cache) {
  return openBlock(), createElementBlock("div", _hoisted_1$1, _hoisted_3$1);
}
const __3 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["render", _sfc_render$1]]);
const __3_raw = '<template>\n  <div class="bg-surface-variant pa-4 position-relative rounded-lg ma-2">\n    <div class="bg-surface-light position-static pa-3 pb-16">\n      <div class="mb-2">Static parent</div>\n\n      <div class="position-absolute bottom-0 right-0 bg-primary rounded-lg pa-3">\n        Absolute child\n      </div>\n    </div>\n  </div>\n</template>\n';
const _sfc_main = {};
const _hoisted_1 = { class: "bg-surface-variant pa-4 position-relative rounded-lg ma-2" };
const _hoisted_2 = { class: "bg-surface-light position-relative py-3 ps-3" };
const _hoisted_3 = {
  class: "overflow-y-auto pe-3",
  style: { "max-height": "250px" }
};
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("div", null, "Relative parent", -1);
const _hoisted_5 = { class: "bg-primary position-sticky top-0 pa-3 mt-2" };
function _sfc_render(_ctx, _cache) {
  return openBlock(), createElementBlock("div", _hoisted_1, [
    createBaseVNode("div", _hoisted_2, [
      createBaseVNode("div", _hoisted_3, [
        _hoisted_4,
        (openBlock(), createElementBlock(Fragment, null, renderList(5, (n) => {
          return createBaseVNode("div", { key: n }, [
            createBaseVNode("div", _hoisted_5, " Sticky header " + toDisplayString(n), 1),
            (openBlock(), createElementBlock(Fragment, null, renderList(8, (k) => {
              return createBaseVNode("div", {
                key: k,
                class: "bg-info rounded-lg pa-3 mt-2"
              }, " Static child ");
            }), 64))
          ]);
        }), 64))
      ])
    ])
  ]);
}
const __4 = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
const __4_raw = '<template>\n  <div class="bg-surface-variant pa-4 position-relative rounded-lg ma-2">\n    <div class="bg-surface-light position-relative py-3 ps-3">\n      <div class="overflow-y-auto pe-3" style="max-height: 250px">\n        <div>Relative parent</div>\n\n        <div\n          v-for="n in 5"\n          :key="n"\n        >\n          <div class="bg-primary position-sticky top-0 pa-3 mt-2">\n            Sticky header {{ n }}\n          </div>\n\n          <div\n            v-for="k in 8"\n            :key="k"\n            class="bg-info rounded-lg pa-3 mt-2"\n          >\n            Static child\n          </div>\n\n        </div>\n      </div>\n    </div>\n  </div>\n</template>\n';
const position = {
  "absolute": {
    component: __0,
    source: __0_raw
  },
  "fixed": {
    component: __1,
    source: __1_raw
  },
  "relative": {
    component: __2,
    source: __2_raw
  },
  "static": {
    component: __3,
    source: __3_raw
  },
  "sticky": {
    component: __4,
    source: __4_raw
  }
};
export {
  position as default
};
