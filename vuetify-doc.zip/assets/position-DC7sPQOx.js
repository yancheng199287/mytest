import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "position" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "Utilities for controlling the positioning of elements in your application.", -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Class"),
    /* @__PURE__ */ createBaseVNode("th", null, "Properties")
  ])
], -1);
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("tbody", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "position-static")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "position: static;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "position-relative")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "position: relative;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "position-absolute")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "position: absolute;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "position-fixed")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "position: fixed;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "position-sticky")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "position: sticky;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "top-0")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "top: 0;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "right-0")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "right: 0;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "bottom-0")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "bottom: 0;")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "left-0")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "left: 0;")
  ])
], -1);
const _hoisted_5 = { id: "usage" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "position"),
  /* @__PURE__ */ createTextVNode(" utilities allow you to quickly style the positioning of any element. These classes can be used to apply the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "position"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "top"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "right"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "bottom"),
  /* @__PURE__ */ createTextVNode(", and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "left"),
  /* @__PURE__ */ createTextVNode(" properties to an element.")
], -1);
const _hoisted_7 = { id: "static" };
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The default position value for all elements is "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "static"),
  /* @__PURE__ */ createTextVNode(". This means that the element is positioned according to the normal flow of the document. The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "top"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "right"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "bottom"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "left"),
  /* @__PURE__ */ createTextVNode(" properties have no effect on a statically positioned element.")
], -1);
const _hoisted_9 = { id: "relative" };
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "position-relative"),
  /* @__PURE__ */ createTextVNode(" class allows you to position an element relative to its normal position in the document. This means that the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "top"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "right"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "bottom"),
  /* @__PURE__ */ createTextVNode(", and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "left"),
  /* @__PURE__ */ createTextVNode(" properties can be used to move the element from its normal position.")
], -1);
const _hoisted_11 = { id: "absolute" };
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "position-absolute"),
  /* @__PURE__ */ createTextVNode(" class allows you to position an element relative to its closest positioned ancestor. If no positioned ancestor is found, the element is positioned relative to the document body.")
], -1);
const _hoisted_13 = { id: "fixed" };
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "position-fixed"),
  /* @__PURE__ */ createTextVNode(" class allows you to position an element relative to the viewport. This means that the element will stay in the same position even when the page is scrolled.")
], -1);
const _hoisted_15 = { id: "sticky" };
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "position-sticky"),
  /* @__PURE__ */ createTextVNode(" class allows you to position an element based on the user’s scroll position. The element is treated as "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "relative"),
  /* @__PURE__ */ createTextVNode(" until it crosses a specified threshold, at which point it is treated as "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "fixed"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const frontmatter = { "emphasized": true, "meta": { "title": "Position", "description": "Use position utilities to quickly style the positioning of any element.", "keywords": "position classes, positioning utilities, vuetify position helper classes" }, "related": ["/styles/display/", "/styles/spacing/", "/styles/flex/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "position",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "Position", "description": "Use position utilities to quickly style the positioning of any element.", "keywords": "position classes, positioning utilities, vuetify position helper classes" } };
    useHead(head);
    __expose({ frontmatter: { "emphasized": true, "meta": { "title": "Position", "description": "Use position utilities to quickly style the positioning of any element.", "keywords": "position classes, positioning utilities, vuetify position helper classes" }, "related": ["/styles/display/", "/styles/spacing/", "/styles/flex/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_app_table = resolveComponent("app-table");
      const _component_entry = resolveComponent("entry");
      const _component_example = resolveComponent("example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#position",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Position")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_app_table, null, {
                default: withCtx(() => [
                  _hoisted_3,
                  _hoisted_4
                ]),
                _: 1
              }),
              createVNode(_component_entry),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_6,
                createBaseVNode("section", _hoisted_7, [
                  createVNode(_component_app_heading, {
                    href: "#static",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Static")
                    ]),
                    _: 1
                  }),
                  _hoisted_8,
                  createVNode(_component_example, { file: "position/static" })
                ]),
                createBaseVNode("section", _hoisted_9, [
                  createVNode(_component_app_heading, {
                    href: "#relative",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Relative")
                    ]),
                    _: 1
                  }),
                  _hoisted_10,
                  createVNode(_component_example, { file: "position/relative" })
                ]),
                createBaseVNode("section", _hoisted_11, [
                  createVNode(_component_app_heading, {
                    href: "#absolute",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Absolute")
                    ]),
                    _: 1
                  }),
                  _hoisted_12,
                  createVNode(_component_example, { file: "position/absolute" })
                ]),
                createBaseVNode("section", _hoisted_13, [
                  createVNode(_component_app_heading, {
                    href: "#fixed",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Fixed")
                    ]),
                    _: 1
                  }),
                  _hoisted_14,
                  createVNode(_component_example, { file: "position/fixed" })
                ]),
                createBaseVNode("section", _hoisted_15, [
                  createVNode(_component_app_heading, {
                    href: "#sticky",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Sticky")
                    ]),
                    _: 1
                  }),
                  _hoisted_16,
                  createVNode(_component_example, { file: "position/sticky" })
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
