import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "progress-circular" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-progress-circular"),
  /* @__PURE__ */ createTextVNode(" component is used to convey data circularly to users. It also can be put into an indeterminate state to portray loading.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, "In its simplest form, v-progress-circular displays a circular progress bar. Use the value prop to control the progress.", -1);
const _hoisted_5 = { id: "api" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_8 = { id: "examples" };
const _hoisted_9 = { id: "props" };
const _hoisted_10 = { id: "color" };
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Alternate colors can be applied to "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-progress-circular"),
  /* @__PURE__ */ createTextVNode(" using the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "color"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_12 = { id: "indeterminate" };
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Using the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "indeterminate"),
  /* @__PURE__ */ createTextVNode(" prop, a "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-progress-circular"),
  /* @__PURE__ */ createTextVNode(" continues to animate indefinitely.")
], -1);
const _hoisted_14 = { id: "rotate" };
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "rotate"),
  /* @__PURE__ */ createTextVNode(" prop gives you the ability to customize the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-progress-circular"),
  /* @__PURE__ */ createTextVNode("’s origin.")
], -1);
const _hoisted_16 = { id: "size-and-width" };
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "size"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "width"),
  /* @__PURE__ */ createTextVNode(" props allow you to easily alter the size and width of the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-progress-circular"),
  /* @__PURE__ */ createTextVNode(" component.")
], -1);
const _hoisted_18 = { id: "slots" };
const _hoisted_19 = { id: "default" };
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "default"),
  /* @__PURE__ */ createTextVNode(" slot can be used to replace the text inside the loader.")
], -1);
const frontmatter = { "meta": { "nav": "Progress circular", "title": "Progress circular component", "description": "The progress circular component is useful for displaying a visual indicator of numerical data in a circle.", "keywords": "progress circular, vuetify progress circular component, vue progress circular component, circular progress" }, "related": ["/components/cards/", "/components/progress-linear/", "/components/lists/"], "features": { "github": "/components/VProgressCircular/", "label": "C: VProgressCircular", "report": true, "spec": "https://m2.material.io/components/progress-indicators" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "progress-circular",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Progress circular", "title": "Progress circular component", "description": "The progress circular component is useful for displaying a visual indicator of numerical data in a circle.", "keywords": "progress circular, vuetify progress circular component, vue progress circular component, circular progress" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Progress circular", "title": "Progress circular component", "description": "The progress circular component is useful for displaying a visual indicator of numerical data in a circle.", "keywords": "progress circular, vuetify progress circular component, vue progress circular component, circular progress" }, "related": ["/components/cards/", "/components/progress-linear/", "/components/lists/"], "features": { "github": "/components/VProgressCircular/", "label": "C: VProgressCircular", "report": true, "spec": "https://m2.material.io/components/progress-indicators" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#progress-circular",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Progress circular")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_usage, { name: "v-progress-circular" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_6,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-progress-circular/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-progress-circular")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_8, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_9, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_10, [
                    createVNode(_component_app_heading, {
                      href: "#color",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Color")
                      ]),
                      _: 1
                    }),
                    _hoisted_11,
                    createVNode(_component_examples_example, { file: "v-progress-circular/prop-color" })
                  ]),
                  createBaseVNode("section", _hoisted_12, [
                    createVNode(_component_app_heading, {
                      href: "#indeterminate",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Indeterminate")
                      ]),
                      _: 1
                    }),
                    _hoisted_13,
                    createVNode(_component_examples_example, { file: "v-progress-circular/prop-indeterminate" })
                  ]),
                  createBaseVNode("section", _hoisted_14, [
                    createVNode(_component_app_heading, {
                      href: "#rotate",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Rotate")
                      ]),
                      _: 1
                    }),
                    _hoisted_15,
                    createVNode(_component_examples_example, { file: "v-progress-circular/prop-rotate" })
                  ]),
                  createBaseVNode("section", _hoisted_16, [
                    createVNode(_component_app_heading, {
                      href: "#size-and-width",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Size and Width")
                      ]),
                      _: 1
                    }),
                    _hoisted_17,
                    createVNode(_component_examples_example, { file: "v-progress-circular/prop-size-and-width" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_18, [
                  createVNode(_component_app_heading, {
                    href: "#slots",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Slots")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_19, [
                    createVNode(_component_app_heading, {
                      href: "#default",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Default")
                      ]),
                      _: 1
                    }),
                    _hoisted_20,
                    createVNode(_component_examples_example, { file: "v-progress-circular/prop-slot-default" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
