import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "progress-linear" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-progress-linear"),
  /* @__PURE__ */ createTextVNode(" component is used to convey data visually to users. It supports both indeterminate amounts, such as loading or processing, and finite amounts of progress (including separate buffer values).")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("In its simplest form, "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-progress-linear"),
  /* @__PURE__ */ createTextVNode(" displays a horizontal progress bar. Use the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "value"),
  /* @__PURE__ */ createTextVNode(" prop to control the progress.")
], -1);
const _hoisted_5 = { id: "api" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_8 = { id: "examples" };
const _hoisted_9 = { id: "props" };
const _hoisted_10 = { id: "buffering" };
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The primary value is controlled by "),
  /* @__PURE__ */ createBaseVNode("strong", null, "v-model"),
  /* @__PURE__ */ createTextVNode(", whereas the buffer is controlled by the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "buffer-value"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_12 = { id: "colors" };
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can set the colors of the progress bar using the props "),
  /* @__PURE__ */ createBaseVNode("strong", null, "color"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "bg-color"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_14 = { id: "indeterminate" };
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "indeterminate"),
  /* @__PURE__ */ createTextVNode(" prop, "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-progress-linear"),
  /* @__PURE__ */ createTextVNode(" continuously animates.")
], -1);
const _hoisted_16 = { id: "reversed" };
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Displays reversed progress. The component also has RTL support, such that a progress bar in right-to-left mode with "),
  /* @__PURE__ */ createBaseVNode("strong", null, "reverse"),
  /* @__PURE__ */ createTextVNode(" prop enabled will display left-to-right.")
], -1);
const _hoisted_18 = { id: "rounded" };
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "rounded"),
  /* @__PURE__ */ createTextVNode(" prop is used to apply a border radius to the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-progress-linear"),
  /* @__PURE__ */ createTextVNode(" component.")
], -1);
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Use the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "rounded-bar"),
  /* @__PURE__ */ createTextVNode(" property to add a border-radius to the inner edges of value bar. By default, the value bar’s border-radius is equal to the default "),
  /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "border-radius"),
  /* @__PURE__ */ createTextVNode(" of your application unless a different value is provided by the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "rounded"),
  /* @__PURE__ */ createTextVNode(" prop or SASS variable.")
], -1);
const _hoisted_21 = { id: "stream" };
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "stream"),
  /* @__PURE__ */ createTextVNode(" property works with "),
  /* @__PURE__ */ createBaseVNode("strong", null, "buffer-value"),
  /* @__PURE__ */ createTextVNode(" to convey to the user that there is some action taking place.")
], -1);
const _hoisted_23 = { id: "striped" };
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("This applies a striped background over the value portion of the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-progress-linear"),
  /* @__PURE__ */ createTextVNode(". This prop has no effect when using "),
  /* @__PURE__ */ createBaseVNode("strong", null, "indeterminate"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_25 = { id: "slots" };
const _hoisted_26 = { id: "default" };
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-progress-linear", -1);
const _hoisted_28 = /* @__PURE__ */ createBaseVNode("strong", null, "v-model", -1);
const _hoisted_29 = { id: "misc" };
const _hoisted_30 = { id: "determinate" };
const _hoisted_31 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The progress linear component can have a determinate state modified by "),
  /* @__PURE__ */ createBaseVNode("strong", null, "v-model"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_32 = { id: "file-loader" };
const _hoisted_33 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-progress-linear"),
  /* @__PURE__ */ createTextVNode(" component is good for communicating to the user that they are waiting for a response.")
], -1);
const _hoisted_34 = { id: "toolbar-loader" };
const _hoisted_35 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "absolute"),
  /* @__PURE__ */ createTextVNode(" prop we are able to position the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-progress-linear"),
  /* @__PURE__ */ createTextVNode(" component at the bottom of the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-toolbar"),
  /* @__PURE__ */ createTextVNode(". We also use the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "active"),
  /* @__PURE__ */ createTextVNode(" prop which allows us to control the visibility of the progress.")
], -1);
const _hoisted_36 = { id: "buffer-color-and-opacity" };
const _hoisted_37 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The buffer color and opacity can be controlled using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "buffer-color"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "buffer-opacity"),
  /* @__PURE__ */ createTextVNode(" props. This enables you to make multi colored progress bars.")
], -1);
const frontmatter = { "meta": { "nav": "Progress linear", "title": "Progress linear component", "description": "The progress-linear component is useful for displaying a visual indicator of numerical data in a straight line.", "keywords": "progress linear, vuetify progress linear component, vue progress linear component, linear progress" }, "related": ["/components/cards/", "/components/progress-circular/", "/components/lists/"], "features": { "figma": true, "github": "/components/VProgressLinear/", "label": "C: VProgressLinear", "report": true, "spec": "https://m2.material.io/components/progress-indicators" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "progress-linear",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Progress linear", "title": "Progress linear component", "description": "The progress-linear component is useful for displaying a visual indicator of numerical data in a straight line.", "keywords": "progress linear, vuetify progress linear component, vue progress linear component, linear progress" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Progress linear", "title": "Progress linear component", "description": "The progress-linear component is useful for displaying a visual indicator of numerical data in a straight line.", "keywords": "progress linear, vuetify progress linear component, vue progress linear component, linear progress" }, "related": ["/components/cards/", "/components/progress-circular/", "/components/lists/"], "features": { "figma": true, "github": "/components/VProgressLinear/", "label": "C: VProgressLinear", "report": true, "spec": "https://m2.material.io/components/progress-indicators" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_alert = resolveComponent("alert");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#progress-linear",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Progress linear")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_usage, { name: "v-progress-linear" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_6,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-progress-linear/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-progress-linear")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_8, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_9, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_10, [
                    createVNode(_component_app_heading, {
                      href: "#buffering",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Buffering")
                      ]),
                      _: 1
                    }),
                    _hoisted_11,
                    createVNode(_component_examples_example, { file: "v-progress-linear/prop-buffer-value" })
                  ]),
                  createBaseVNode("section", _hoisted_12, [
                    createVNode(_component_app_heading, {
                      href: "#colors",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Colors")
                      ]),
                      _: 1
                    }),
                    _hoisted_13,
                    createVNode(_component_examples_example, { file: "v-progress-linear/prop-colors" })
                  ]),
                  createBaseVNode("section", _hoisted_14, [
                    createVNode(_component_app_heading, {
                      href: "#indeterminate",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Indeterminate")
                      ]),
                      _: 1
                    }),
                    _hoisted_15,
                    createVNode(_component_examples_example, { file: "v-progress-linear/prop-indeterminate" })
                  ]),
                  createBaseVNode("section", _hoisted_16, [
                    createVNode(_component_app_heading, {
                      href: "#reversed",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Reversed")
                      ]),
                      _: 1
                    }),
                    _hoisted_17,
                    createVNode(_component_examples_example, { file: "v-progress-linear/prop-reverse" })
                  ]),
                  createBaseVNode("section", _hoisted_18, [
                    createVNode(_component_app_heading, {
                      href: "#rounded",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Rounded")
                      ]),
                      _: 1
                    }),
                    _hoisted_19,
                    createVNode(_component_examples_example, { file: "v-progress-linear/prop-rounded" }),
                    createVNode(_component_alert, { type: "info" }, {
                      default: withCtx(() => [
                        _hoisted_20
                      ]),
                      _: 1
                    })
                  ]),
                  createBaseVNode("section", _hoisted_21, [
                    createVNode(_component_app_heading, {
                      href: "#stream",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Stream")
                      ]),
                      _: 1
                    }),
                    _hoisted_22,
                    createVNode(_component_examples_example, { file: "v-progress-linear/prop-stream" })
                  ]),
                  createBaseVNode("section", _hoisted_23, [
                    createVNode(_component_app_heading, {
                      href: "#striped",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Striped")
                      ]),
                      _: 1
                    }),
                    _hoisted_24,
                    createVNode(_component_examples_example, { file: "v-progress-linear/prop-striped" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_25, [
                  createVNode(_component_app_heading, {
                    href: "#slots",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Slots")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_26, [
                    createVNode(_component_app_heading, {
                      href: "#default",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Default")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("The "),
                      _hoisted_27,
                      createTextVNode(" component will be responsive to user input when using "),
                      _hoisted_28,
                      createTextVNode(". You can use the default slot or bind a local model to display inside of the progress. If you are looking for advanced features on a linear type component, check out "),
                      createVNode(_component_app_link, { href: "/components/sliders" }, {
                        default: withCtx(() => [
                          createTextVNode("v-slider")
                        ]),
                        _: 1
                      }),
                      createTextVNode(".")
                    ]),
                    createVNode(_component_examples_example, { file: "v-progress-linear/slot-default" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_29, [
                  createVNode(_component_app_heading, {
                    href: "#misc",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Misc")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_30, [
                    createVNode(_component_app_heading, {
                      href: "#determinate",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Determinate")
                      ]),
                      _: 1
                    }),
                    _hoisted_31,
                    createVNode(_component_examples_example, { file: "v-progress-linear/misc-determinate" })
                  ]),
                  createBaseVNode("section", _hoisted_32, [
                    createVNode(_component_app_heading, {
                      href: "#file-loader",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("File loader")
                      ]),
                      _: 1
                    }),
                    _hoisted_33,
                    createVNode(_component_examples_example, { file: "v-progress-linear/misc-file-loader" })
                  ]),
                  createBaseVNode("section", _hoisted_34, [
                    createVNode(_component_app_heading, {
                      href: "#toolbar-loader",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Toolbar loader")
                      ]),
                      _: 1
                    }),
                    _hoisted_35,
                    createVNode(_component_examples_example, { file: "v-progress-linear/misc-toolbar-loader" })
                  ]),
                  createBaseVNode("section", _hoisted_36, [
                    createVNode(_component_app_heading, {
                      href: "#buffer-color-and-opacity",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Buffer color and opacity")
                      ]),
                      _: 1
                    }),
                    createVNode(_component_alert, { type: "success" }, {
                      default: withCtx(() => [
                        createBaseVNode("p", null, [
                          createTextVNode("This feature was introduced in "),
                          createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v3.6.0" }, {
                            default: withCtx(() => [
                              createTextVNode("v3.6.0 (Nebula)")
                            ]),
                            _: 1
                          })
                        ])
                      ]),
                      _: 1
                    }),
                    _hoisted_37,
                    createVNode(_component_examples_example, { file: "v-progress-linear/misc-buffer-color" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
