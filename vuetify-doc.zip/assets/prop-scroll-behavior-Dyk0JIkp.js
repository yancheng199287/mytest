import { J as ref, j as computed, ag as propsToString, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, b as createVNode, l as createElementBlock, v as renderList, f as unref, E as isRef, F as Fragment, a9 as mergeProps, S as createSlots, h as createTextVNode, e as createBaseVNode, ah as _sfc_main$2 } from "./index-DGybHjCP.js";
import { _ as _sfc_main$1 } from "./UsageExample-M8CmNipa.js";
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("div", { style: { "height": "1000px" } }, null, -1);
const name = "v-app-bar";
const _sfc_main = {
  __name: "prop-scroll-behavior",
  setup(__props) {
    const model = ref("default");
    const options = [];
    const actions = ref(false);
    const scrollThreshold = ref(300);
    const selectedBehaviors = ref([]);
    const behaviors = [
      { value: "hide", title: "Hide" },
      { value: "collapse", title: "Collapse" },
      { value: "elevate", title: "Elevate" },
      { value: "fade-image", title: "Fade image" }
    ];
    const props = computed(() => {
      return {
        "scroll-behavior": selectedBehaviors.value.join(" ") || void 0,
        "scroll-threshold": scrollThreshold.value === 300 ? void 0 : String(scrollThreshold.value),
        image: selectedBehaviors.value.includes("fade-image") ? "https://picsum.photos/1920/1080?random" : void 0
      };
    });
    const slots = computed(() => {
      let str = "";
      if (actions.value) {
        str += `
  <template v-slot:append>
    <v-btn icon="mdi-heart"></v-btn>

    <v-btn icon="mdi-magnify"></v-btn>

    <v-btn icon="mdi-dots-vertical"></v-btn>
  </template>
`;
      }
      return str;
    });
    const code = computed(() => {
      return `<${name}${propsToString(props.value)}>${slots.value}</${name}>`;
    });
    return (_ctx, _cache) => {
      const _component_v_app_bar_nav_icon = resolveComponent("v-app-bar-nav-icon");
      const _component_v_app_bar_title = resolveComponent("v-app-bar-title");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_app_bar = resolveComponent("v-app-bar");
      const _component_v_main = resolveComponent("v-main");
      const _component_v_layout = resolveComponent("v-layout");
      const _component_v_checkbox = resolveComponent("v-checkbox");
      const _component_v_divider = resolveComponent("v-divider");
      const _component_v_slider = resolveComponent("v-slider");
      const _component_ExamplesUsageExample = _sfc_main$1;
      const _component_AppSheet = _sfc_main$2;
      return openBlock(), createBlock(_component_AppSheet, { class: "mb-6" }, {
        default: withCtx(() => [
          createVNode(_component_ExamplesUsageExample, {
            modelValue: unref(model),
            "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => isRef(model) ? model.value = $event : null),
            code: unref(code),
            name,
            options
          }, {
            configuration: withCtx(() => [
              (openBlock(), createElementBlock(Fragment, null, renderList(behaviors, (option) => {
                return createVNode(_component_v_checkbox, {
                  key: option.value,
                  modelValue: unref(selectedBehaviors),
                  "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(selectedBehaviors) ? selectedBehaviors.value = $event : null),
                  label: option.title,
                  value: option.value
                }, null, 8, ["modelValue", "label", "value"]);
              }), 64)),
              createVNode(_component_v_divider),
              createVNode(_component_v_checkbox, {
                modelValue: unref(selectedBehaviors),
                "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(selectedBehaviors) ? selectedBehaviors.value = $event : null),
                label: "Inverted",
                value: "inverted"
              }, null, 8, ["modelValue"]),
              createVNode(_component_v_slider, {
                modelValue: unref(scrollThreshold),
                "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => isRef(scrollThreshold) ? scrollThreshold.value = $event : null),
                label: "Threshold",
                max: "1000",
                min: "0",
                step: "1"
              }, null, 8, ["modelValue"])
            ]),
            default: withCtx(() => [
              createVNode(_component_v_layout, {
                class: "overflow-visible",
                style: { "height": "300px" }
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_main, {
                    id: "scroll-behavior-layout",
                    class: "pt-0",
                    scrollable: ""
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_v_app_bar, mergeProps(unref(props), {
                        color: "secondary",
                        "scroll-target": "#scroll-behavior-layout > .v-main__scroller",
                        style: { "position": "sticky" }
                      }), createSlots({
                        prepend: withCtx(() => [
                          createVNode(_component_v_app_bar_nav_icon)
                        ]),
                        default: withCtx(() => [
                          createVNode(_component_v_app_bar_title, null, {
                            default: withCtx(() => [
                              createTextVNode("Application Bar")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 2
                      }, [
                        unref(actions) ? {
                          name: "append",
                          fn: withCtx(() => [
                            createVNode(_component_v_btn, { icon: "mdi-heart" }),
                            createVNode(_component_v_btn, { icon: "mdi-magnify" }),
                            createVNode(_component_v_btn, { icon: "mdi-dots-vertical" })
                          ]),
                          key: "0"
                        } : void 0
                      ]), 1040),
                      _hoisted_1
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          }, 8, ["modelValue", "code"])
        ]),
        _: 1
      });
    };
  }
};
const __6 = _sfc_main;
export {
  __6 as _
};
