import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "radio-buttons" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-radio"),
  /* @__PURE__ */ createTextVNode(" component is a simple radio button. When combined with the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-radio-group"),
  /* @__PURE__ */ createTextVNode(" component you can provide grouping functionality to allow users to select from a predefined set of options.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Although "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-radio"),
  /* @__PURE__ */ createTextVNode(" can be used on its own, it is best used in conjunction with "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-radio-group"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_5 = { id: "api" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createTextVNode("Sub-component used for modifying the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-radio-group"),
  /* @__PURE__ */ createTextVNode(" state")
], -1);
const _hoisted_9 = { id: "examples" };
const _hoisted_10 = { id: "props" };
const _hoisted_11 = { id: "model-group" };
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "v-model"),
  /* @__PURE__ */ createTextVNode(" (or "),
  /* @__PURE__ */ createBaseVNode("strong", null, "model-value"),
  /* @__PURE__ */ createTextVNode(") you can access and control the selected radio button defined by the set "),
  /* @__PURE__ */ createBaseVNode("strong", null, "value"),
  /* @__PURE__ */ createTextVNode(" on the child "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-radio"),
  /* @__PURE__ */ createTextVNode(" components.")
], -1);
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("If you are using integer values with "),
  /* @__PURE__ */ createBaseVNode("strong", null, "model-value"),
  /* @__PURE__ */ createTextVNode(", you will need to use "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ":value"),
  /* @__PURE__ */ createTextVNode(" to set the value of the child "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-radio"),
  /* @__PURE__ */ createTextVNode(" otherwise it will be evaluated as a string.")
], -1);
const _hoisted_14 = { id: "model-radio" };
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "v-model"),
  /* @__PURE__ */ createTextVNode(" (or "),
  /* @__PURE__ */ createBaseVNode("strong", null, "model-value"),
  /* @__PURE__ */ createTextVNode(") you can access and control the value of a single radio button. The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "true"),
  /* @__PURE__ */ createTextVNode("/"),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "false"),
  /* @__PURE__ */ createTextVNode(" values can be independently defined using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "true-value"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "false-value"),
  /* @__PURE__ */ createTextVNode(" props.")
], -1);
const _hoisted_16 = { id: "colors" };
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Radios can be colored by using any of the builtin colors and contextual names using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "color"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_18 = { id: "direction" };
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("p", null, "Radio-groups can be presented either as a row or a column, using their respective props. The default is as a column.", -1);
const _hoisted_20 = { id: "slots" };
const _hoisted_21 = { id: "label" };
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Radio Group labels can be defined in "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "label"),
  /* @__PURE__ */ createTextVNode(" slot - that will allow to use HTML content.")
], -1);
const frontmatter = { "meta": { "nav": "Radio buttons", "title": "Radio button component", "description": "A radio button allows the user to choose only one of a set of options using a radio group.", "keywords": "radio groups, radio buttons, vuetify radio group component, vuetify radio component, vue radio component, vue radio group component" }, "related": ["/components/button-groups/", "/components/forms/", "/components/checkboxes/"], "features": { "label": "C: VRadio", "report": true, "github": "/components/VRadio/", "spec": "https://m2.material.io/components/radio-buttons" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "radio-buttons",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Radio buttons", "title": "Radio button component", "description": "A radio button allows the user to choose only one of a set of options using a radio group.", "keywords": "radio groups, radio buttons, vuetify radio group component, vuetify radio component, vue radio component, vue radio group component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Radio buttons", "title": "Radio button component", "description": "A radio button allows the user to choose only one of a set of options using a radio group.", "keywords": "radio groups, radio buttons, vuetify radio group component, vuetify radio component, vue radio component, vue radio group component" }, "related": ["/components/button-groups/", "/components/forms/", "/components/checkboxes/"], "features": { "label": "C: VRadio", "report": true, "github": "/components/VRadio/", "spec": "https://m2.material.io/components/radio-buttons" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_alert = resolveComponent("alert");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#radio-buttons",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Radio buttons")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_usage, { name: "v-radio-group" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_6,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-radio-group/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-radio-group")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-radio/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-radio")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_8
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_9, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_10, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_11, [
                    createVNode(_component_app_heading, {
                      href: "#model-group",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Model (group)")
                      ]),
                      _: 1
                    }),
                    _hoisted_12,
                    createVNode(_component_examples_example, { file: "v-radio-group/prop-model-group" }),
                    createVNode(_component_alert, { type: "info" }, {
                      default: withCtx(() => [
                        _hoisted_13
                      ]),
                      _: 1
                    })
                  ]),
                  createBaseVNode("section", _hoisted_14, [
                    createVNode(_component_app_heading, {
                      href: "#model-radio",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Model (radio)")
                      ]),
                      _: 1
                    }),
                    _hoisted_15,
                    createVNode(_component_examples_example, { file: "v-radio-group/prop-model-radio" })
                  ]),
                  createBaseVNode("section", _hoisted_16, [
                    createVNode(_component_app_heading, {
                      href: "#colors",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Colors")
                      ]),
                      _: 1
                    }),
                    _hoisted_17,
                    createVNode(_component_examples_example, { file: "v-radio-group/prop-colors" })
                  ]),
                  createBaseVNode("section", _hoisted_18, [
                    createVNode(_component_app_heading, {
                      href: "#direction",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Direction")
                      ]),
                      _: 1
                    }),
                    _hoisted_19,
                    createVNode(_component_examples_example, { file: "v-radio-group/prop-direction" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_20, [
                  createVNode(_component_app_heading, {
                    href: "#slots",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Slots")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_21, [
                    createVNode(_component_app_heading, {
                      href: "#label",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Label")
                      ]),
                      _: 1
                    }),
                    _hoisted_22,
                    createVNode(_component_examples_example, { file: "v-radio-group/slot-label" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
