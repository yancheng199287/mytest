import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "range-sliders" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-range-slider"),
  /* @__PURE__ */ createTextVNode(" component complements the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-slider"),
  /* @__PURE__ */ createTextVNode(" component nicely when you are in need of representing a range of values.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, "Sliders reflect a range of values along a bar, from which users may select a single value. They are ideal for adjusting settings such as volume, brightness, or applying image filters.", -1);
const _hoisted_5 = { id: "api" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_8 = { id: "examples" };
const _hoisted_9 = { id: "props" };
const _hoisted_10 = { id: "strict" };
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("With the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "strict"),
  /* @__PURE__ */ createTextVNode(" prop applied, the thumbs of the range slider are not allowed to cross over each other.")
], -1);
const _hoisted_12 = { id: "disabled" };
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You cannot interact with "),
  /* @__PURE__ */ createBaseVNode("strong", null, "disabled"),
  /* @__PURE__ */ createTextVNode(" sliders.")
], -1);
const _hoisted_14 = { id: "min-and-max" };
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can set "),
  /* @__PURE__ */ createBaseVNode("strong", null, "min"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "max"),
  /* @__PURE__ */ createTextVNode(" values of sliders.")
], -1);
const _hoisted_16 = { id: "step" };
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-range-slider"),
  /* @__PURE__ */ createTextVNode(" can have steps other than 1. This can be helpful for some applications where you need to adjust values with more or less accuracy.")
], -1);
const _hoisted_18 = { id: "vertical-sliders" };
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can use the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "vertical"),
  /* @__PURE__ */ createTextVNode(" prop to switch sliders to a vertical orientation. If you need to change the height of the slider, use css.")
], -1);
const _hoisted_20 = { id: "slots" };
const _hoisted_21 = { id: "thumb-label" };
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "tick-labels"),
  /* @__PURE__ */ createTextVNode(" prop along with the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "thumb-label"),
  /* @__PURE__ */ createTextVNode(" slot, you can create a very customized solution.")
], -1);
const frontmatter = { "meta": { "nav": "Range sliders", "title": "Range Slider component", "description": "The range slider component is a better visualization of the number input. It is used for gathering a range of numerical user data.", "keywords": "sliders, range, vuetify slider component, vuetify range slider component, vue slider component" }, "related": ["/components/forms/", "/components/selects/", "/components/sliders/"], "features": { "label": "C: VRangeSlider", "report": true, "github": "/components/VRangeSlider/", "spec": "https://m2.material.io/components/sliders" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "range-sliders",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Range sliders", "title": "Range Slider component", "description": "The range slider component is a better visualization of the number input. It is used for gathering a range of numerical user data.", "keywords": "sliders, range, vuetify slider component, vuetify range slider component, vue slider component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Range sliders", "title": "Range Slider component", "description": "The range slider component is a better visualization of the number input. It is used for gathering a range of numerical user data.", "keywords": "sliders, range, vuetify slider component, vuetify range slider component, vue slider component" }, "related": ["/components/forms/", "/components/selects/", "/components/sliders/"], "features": { "label": "C: VRangeSlider", "report": true, "github": "/components/VRangeSlider/", "spec": "https://m2.material.io/components/sliders" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#range-sliders",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Range Sliders")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_usage, { name: "v-range-slider" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_6,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-range-slider/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-range-slider")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_8, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_9, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_10, [
                    createVNode(_component_app_heading, {
                      href: "#strict",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Strict")
                      ]),
                      _: 1
                    }),
                    _hoisted_11,
                    createVNode(_component_examples_example, { file: "v-range-slider/prop-strict" })
                  ]),
                  createBaseVNode("section", _hoisted_12, [
                    createVNode(_component_app_heading, {
                      href: "#disabled",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Disabled")
                      ]),
                      _: 1
                    }),
                    _hoisted_13,
                    createVNode(_component_examples_example, { file: "v-range-slider/prop-disabled" })
                  ]),
                  createBaseVNode("section", _hoisted_14, [
                    createVNode(_component_app_heading, {
                      href: "#min-and-max",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Min and max")
                      ]),
                      _: 1
                    }),
                    _hoisted_15,
                    createVNode(_component_examples_example, { file: "v-range-slider/prop-min-and-max" })
                  ]),
                  createBaseVNode("section", _hoisted_16, [
                    createVNode(_component_app_heading, {
                      href: "#step",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Step")
                      ]),
                      _: 1
                    }),
                    _hoisted_17,
                    createVNode(_component_examples_example, { file: "v-range-slider/prop-step" })
                  ]),
                  createBaseVNode("section", _hoisted_18, [
                    createVNode(_component_app_heading, {
                      href: "#vertical-sliders",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Vertical sliders")
                      ]),
                      _: 1
                    }),
                    _hoisted_19,
                    createVNode(_component_examples_example, { file: "v-range-slider/prop-vertical" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_20, [
                  createVNode(_component_app_heading, {
                    href: "#slots",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Slots")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_21, [
                    createVNode(_component_app_heading, {
                      href: "#thumb-label",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Thumb label")
                      ]),
                      _: 1
                    }),
                    _hoisted_22,
                    createVNode(_component_examples_example, { file: "v-range-slider/slot-thumb-label" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
