import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "ratings" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-rating"),
  /* @__PURE__ */ createTextVNode(" component is a specialized but important piece in building user widgets. Collecting user feedback via ratings is a simple analytic that can provide a lot of feedback to your product or application.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-rating"),
  /* @__PURE__ */ createTextVNode(" component provides a simple interface for gathering user feedback.")
], -1);
const _hoisted_5 = { id: "api" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_8 = { id: "examples" };
const _hoisted_9 = { id: "props" };
const _hoisted_10 = { id: "color" };
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-rating"),
  /* @__PURE__ */ createTextVNode(" component can be colored as you want, you can set both selected and not selected colors.")
], -1);
const _hoisted_12 = { id: "density" };
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Control the space occupied by "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-rating"),
  /* @__PURE__ */ createTextVNode(" items using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "density"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_14 = { id: "clearable" };
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Clicking on a current rating value can reset the rating by using "),
  /* @__PURE__ */ createBaseVNode("strong", null, "clearable"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_16 = { id: "readonly" };
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("For ratings that are not meant to be changed you can use "),
  /* @__PURE__ */ createBaseVNode("strong", null, "readonly"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_18 = { id: "hover-effect" };
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("When using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "hover"),
  /* @__PURE__ */ createTextVNode(" prop, the rating icons will become a solid color and slightly increase its scale when the mouse is hovered over them.")
], -1);
const _hoisted_20 = { id: "labels" };
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-rating"),
  /* @__PURE__ */ createTextVNode(" component can display labels above or below each item.")
], -1);
const _hoisted_22 = { id: "icons" };
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("p", null, "You can use custom icons.", -1);
const _hoisted_24 = { id: "length" };
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Change the number of items by modifying the the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "length"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_26 = { id: "half-increments" };
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "half-increments"),
  /* @__PURE__ */ createTextVNode(" prop increases the granularity of the ratings, allow for "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".5"),
  /* @__PURE__ */ createTextVNode(" values as well.")
], -1);
const _hoisted_28 = { id: "size" };
const _hoisted_29 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Utilize the same sizing classes available in "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-icon"),
  /* @__PURE__ */ createTextVNode(" or provide your own with the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "size"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_30 = { id: "aria-label" };
const _hoisted_31 = /* @__PURE__ */ createBaseVNode("p", null, "Provide a label to assistive technologies for each item.", -1);
const _hoisted_32 = { id: "slots" };
const _hoisted_33 = { id: "item-slot" };
const _hoisted_34 = /* @__PURE__ */ createBaseVNode("p", null, "Slots enable advanced customization possibilities and provide you with more freedom in how you display the rating.", -1);
const _hoisted_35 = { id: "custom-labels-slot" };
const _hoisted_36 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Any arbitrary content could be displayed for labels in "),
  /* @__PURE__ */ createBaseVNode("strong", null, "item-label"),
  /* @__PURE__ */ createTextVNode(" slot.")
], -1);
const _hoisted_37 = { id: "misc" };
const _hoisted_38 = { id: "card-ratings" };
const _hoisted_39 = /* @__PURE__ */ createBaseVNode("p", null, "The rating component pairs well with products allowing you to gather and display customer feedback.", -1);
const frontmatter = { "meta": { "nav": "Ratings", "title": "Rating component", "description": "The star rating component is a specialized widget for collecting user feedback via ratings.", "keywords": "star ratings, vuetify star rating component, vue star rating component, rating component" }, "related": ["/components/cards", "/components/icons", "/components/lists"], "features": { "github": "/components/VRating/", "label": "C: VRating", "report": true } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ratings",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Ratings", "title": "Rating component", "description": "The star rating component is a specialized widget for collecting user feedback via ratings.", "keywords": "star ratings, vuetify star rating component, vue star rating component, rating component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Ratings", "title": "Rating component", "description": "The star rating component is a specialized widget for collecting user feedback via ratings.", "keywords": "star ratings, vuetify star rating component, vue star rating component, rating component" }, "related": ["/components/cards", "/components/icons", "/components/lists"], "features": { "github": "/components/VRating/", "label": "C: VRating", "report": true } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#ratings",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Ratings")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_usage, { name: "v-rating" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_6,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-rating/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-rating")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_8, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_9, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_10, [
                    createVNode(_component_app_heading, {
                      href: "#color",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Color")
                      ]),
                      _: 1
                    }),
                    _hoisted_11,
                    createVNode(_component_examples_example, { file: "v-rating/prop-color" })
                  ]),
                  createBaseVNode("section", _hoisted_12, [
                    createVNode(_component_app_heading, {
                      href: "#density",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Density")
                      ]),
                      _: 1
                    }),
                    _hoisted_13,
                    createVNode(_component_examples_example, { file: "v-rating/prop-density" })
                  ]),
                  createBaseVNode("section", _hoisted_14, [
                    createVNode(_component_app_heading, {
                      href: "#clearable",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Clearable")
                      ]),
                      _: 1
                    }),
                    _hoisted_15,
                    createVNode(_component_examples_example, { file: "v-rating/prop-clearable" })
                  ]),
                  createBaseVNode("section", _hoisted_16, [
                    createVNode(_component_app_heading, {
                      href: "#readonly",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Readonly")
                      ]),
                      _: 1
                    }),
                    _hoisted_17,
                    createVNode(_component_examples_example, { file: "v-rating/prop-readonly" })
                  ]),
                  createBaseVNode("section", _hoisted_18, [
                    createVNode(_component_app_heading, {
                      href: "#hover-effect",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Hover effect")
                      ]),
                      _: 1
                    }),
                    _hoisted_19,
                    createVNode(_component_examples_example, { file: "v-rating/prop-hover" })
                  ]),
                  createBaseVNode("section", _hoisted_20, [
                    createVNode(_component_app_heading, {
                      href: "#labels",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Labels")
                      ]),
                      _: 1
                    }),
                    _hoisted_21,
                    createVNode(_component_examples_example, { file: "v-rating/prop-item-labels" })
                  ]),
                  createBaseVNode("section", _hoisted_22, [
                    createVNode(_component_app_heading, {
                      href: "#icons",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Icons")
                      ]),
                      _: 1
                    }),
                    _hoisted_23,
                    createVNode(_component_examples_example, { file: "v-rating/prop-icons" })
                  ]),
                  createBaseVNode("section", _hoisted_24, [
                    createVNode(_component_app_heading, {
                      href: "#length",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Length")
                      ]),
                      _: 1
                    }),
                    _hoisted_25,
                    createVNode(_component_examples_example, { file: "v-rating/prop-length" })
                  ]),
                  createBaseVNode("section", _hoisted_26, [
                    createVNode(_component_app_heading, {
                      href: "#half-increments",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Half increments")
                      ]),
                      _: 1
                    }),
                    _hoisted_27,
                    createVNode(_component_examples_example, { file: "v-rating/prop-half-increments" })
                  ]),
                  createBaseVNode("section", _hoisted_28, [
                    createVNode(_component_app_heading, {
                      href: "#size",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Size")
                      ]),
                      _: 1
                    }),
                    _hoisted_29,
                    createVNode(_component_examples_example, { file: "v-rating/prop-size" })
                  ]),
                  createBaseVNode("section", _hoisted_30, [
                    createVNode(_component_app_heading, {
                      href: "#aria-label",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Aria Label")
                      ]),
                      _: 1
                    }),
                    _hoisted_31,
                    createVNode(_component_examples_example, { file: "v-rating/prop-icon-label" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_32, [
                  createVNode(_component_app_heading, {
                    href: "#slots",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Slots")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_33, [
                    createVNode(_component_app_heading, {
                      href: "#item-slot",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Item slot")
                      ]),
                      _: 1
                    }),
                    _hoisted_34,
                    createVNode(_component_examples_example, { file: "v-rating/slot-item" })
                  ]),
                  createBaseVNode("section", _hoisted_35, [
                    createVNode(_component_app_heading, {
                      href: "#custom-labels-slot",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Custom labels slot")
                      ]),
                      _: 1
                    }),
                    _hoisted_36,
                    createVNode(_component_examples_example, { file: "v-rating/slot-item-label" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_37, [
                  createVNode(_component_app_heading, {
                    href: "#misc",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Misc")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_38, [
                    createVNode(_component_app_heading, {
                      href: "#card-ratings",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Card ratings")
                      ]),
                      _: 1
                    }),
                    _hoisted_39,
                    createVNode(_component_examples_example, { file: "v-rating/misc-card" }),
                    createVNode(_component_examples_example, { file: "v-rating/misc-card-overview" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
