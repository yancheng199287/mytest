import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "release-notes" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "The Vuetify team performs releases on a weekly basis.", -1);
const frontmatter = { "fluid": true, "meta": { "title": "Release notes", "description": "Stay up to date with the latest release notes. The migration guides will also help you migrate applications though major releases.", "keywords": "migration, releases, upgrading vuetify" }, "related": ["/introduction/long-term-support/", "/getting-started/contributing/", "/introduction/roadmap/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "release-notes",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "Release notes", "description": "Stay up to date with the latest release notes. The migration guides will also help you migrate applications though major releases.", "keywords": "migration, releases, upgrading vuetify" } };
    useHead(head);
    __expose({ frontmatter: { "fluid": true, "meta": { "title": "Release notes", "description": "Stay up to date with the latest release notes. The migration guides will also help you migrate applications though major releases.", "keywords": "migration, releases, upgrading vuetify" }, "related": ["/introduction/long-term-support/", "/getting-started/contributing/", "/introduction/roadmap/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_vo_promotions_card_vuetify = resolveComponent("vo-promotions-card-vuetify");
      const _component_doc_releases = resolveComponent("doc-releases");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#release-notes",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Release notes")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_vo_promotions_card_vuetify),
              createVNode(_component_doc_releases)
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
