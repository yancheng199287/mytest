import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "ripple-directive" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-ripple"),
  /* @__PURE__ */ createTextVNode(" directive is used to show action from a user. It can be applied to any block level element. Numerous components come with the ripple directive built in, such as the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-tabs-item"),
  /* @__PURE__ */ createTextVNode(" and many more.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Basic ripple functionality can be enabled just by using "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-ripple"),
  /* @__PURE__ */ createTextVNode(" directive on a component or an HTML element")
], -1);
const _hoisted_5 = { id: "api" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Directive"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "The ripple directive", -1);
const _hoisted_8 = { id: "examples" };
const _hoisted_9 = { id: "propagation" };
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("If multiple elements have the ripple directive applied, only the inner one will show the effect. This can also be done without having a visible ripple by using "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-ripple.stop"),
  /* @__PURE__ */ createTextVNode(" to prevent ripples in the outer element if the inner element is clicked on. "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-ripple.stop"),
  /* @__PURE__ */ createTextVNode(" will not actually stop propagation of the mousedown/touchstart events unlike other workarounds.")
], -1);
const _hoisted_11 = { id: "options" };
const _hoisted_12 = { id: "center" };
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("When a "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "center"),
  /* @__PURE__ */ createTextVNode(" option is used ripple will always originate from the center of the target.")
], -1);
const _hoisted_14 = { id: "misc" };
const _hoisted_15 = { id: "custom-color" };
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("p", null, "Using a helper class, you can change the color of the ripple.", -1);
const _hoisted_17 = { id: "ripple-in-components" };
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Some components provide the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "ripple"),
  /* @__PURE__ */ createTextVNode(" prop that allows you to control the ripple effect. You can turn it off or customize the behavior by using "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "class"),
  /* @__PURE__ */ createTextVNode(" or "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "center"),
  /* @__PURE__ */ createTextVNode(" options.")
], -1);
const frontmatter = { "meta": { "nav": "Ripple", "title": "Ripple directive", "description": "The ripple directive adds touch and click feedback to any element in the form of a water ripple.", "keywords": "ripples, ink, vuetify ripple directive, vue ripple directive" }, "related": ["/components/buttons/", "/components/expansion-panels/", "/styles/transitions/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ripple",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Ripple", "title": "Ripple directive", "description": "The ripple directive adds touch and click feedback to any element in the form of a water ripple.", "keywords": "ripples, ink, vuetify ripple directive, vue ripple directive" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Ripple", "title": "Ripple directive", "description": "The ripple directive adds touch and click feedback to any element in the form of a water ripple.", "keywords": "ripples, ink, vuetify ripple directive, vue ripple directive" }, "related": ["/components/buttons/", "/components/expansion-panels/", "/styles/transitions/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#ripple-directive",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Ripple directive")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_promoted_entry),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_example, { file: "v-ripple/usage" })
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_6,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-ripple-directive/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-ripple")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_8, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_9, [
                  createVNode(_component_app_heading, {
                    href: "#propagation",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Propagation")
                    ]),
                    _: 1
                  }),
                  _hoisted_10,
                  createVNode(_component_examples_example, { file: "v-ripple/stop" })
                ]),
                createBaseVNode("section", _hoisted_11, [
                  createVNode(_component_app_heading, {
                    href: "#options",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Options")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_12, [
                    createVNode(_component_app_heading, {
                      href: "#center",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Center")
                      ]),
                      _: 1
                    }),
                    _hoisted_13,
                    createVNode(_component_examples_example, { file: "v-ripple/option-center" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_14, [
                  createVNode(_component_app_heading, {
                    href: "#misc",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Misc")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_15, [
                    createVNode(_component_app_heading, {
                      href: "#custom-color",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Custom color")
                      ]),
                      _: 1
                    }),
                    _hoisted_16,
                    createVNode(_component_examples_example, { file: "v-ripple/misc-custom-color" })
                  ]),
                  createBaseVNode("section", _hoisted_17, [
                    createVNode(_component_app_heading, {
                      href: "#ripple-in-components",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Ripple in components")
                      ]),
                      _: 1
                    }),
                    _hoisted_18,
                    createVNode(_component_examples_example, { file: "v-ripple/misc-ripple-in-components" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
