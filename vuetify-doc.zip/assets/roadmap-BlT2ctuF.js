import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "the-vuetify-roadmap" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "Vuetify is always under development. We are constantly working towards improving the existing codebase, adding new features, and expanding the ecosystem with developer tooling that makes building applications even easier.", -1);
const _hoisted_3 = { id: "section-2024-component-roadmap" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, "The following is a list of all planned components for the year 2024.", -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Entering Labs"),
    /* @__PURE__ */ createBaseVNode("th", null, "Production Release")
  ])
], -1);
const _hoisted_6 = { class: "bg-surface-light" };
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, null, -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("td", null, "July 2024", -1);
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("td", null, "*️⃣", -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("td", null, "July 2024", -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("td", null, "*️⃣", -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("td", null, "July 2024", -1);
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("td", null, "*️⃣", -1);
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("td", null, "July 2024", -1);
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("td", null, "*️⃣", -1);
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("td", null, "July 2024", -1);
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createBaseVNode("s", null, "April"),
  /* @__PURE__ */ createTextVNode(" May 2024")
], -1);
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("td", null, "July 2024", -1);
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createBaseVNode("s", null, "April"),
  /* @__PURE__ */ createTextVNode(" May 2024")
], -1);
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("td", null, "July 2024", -1);
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createBaseVNode("s", null, "March"),
  /* @__PURE__ */ createTextVNode(" May 2024")
], -1);
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("td", null, "July 2024", -1);
const _hoisted_23 = { class: "bg-surface-light" };
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("td", null, null, -1);
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("td", null, "Q4", -1);
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("td", null, "*️⃣", -1);
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("td", null, "Q4", -1);
const _hoisted_28 = /* @__PURE__ */ createBaseVNode("tr", null, [
  /* @__PURE__ */ createBaseVNode("td", null, "v-date-time-picker"),
  /* @__PURE__ */ createBaseVNode("td", null, "May 2024"),
  /* @__PURE__ */ createBaseVNode("td", null, "Q4")
], -1);
const _hoisted_29 = /* @__PURE__ */ createBaseVNode("tr", null, [
  /* @__PURE__ */ createBaseVNode("td", null, "v-date-range-picker"),
  /* @__PURE__ */ createBaseVNode("td", null, "June 2024"),
  /* @__PURE__ */ createBaseVNode("td", null, "Q4")
], -1);
const _hoisted_30 = /* @__PURE__ */ createBaseVNode("tr", null, [
  /* @__PURE__ */ createBaseVNode("td", null, "v-video"),
  /* @__PURE__ */ createBaseVNode("td", null, "July 2024"),
  /* @__PURE__ */ createBaseVNode("td", null, "Q4")
], -1);
const _hoisted_31 = /* @__PURE__ */ createBaseVNode("tr", null, [
  /* @__PURE__ */ createBaseVNode("td", null, "v-feature-discovery"),
  /* @__PURE__ */ createBaseVNode("td", null, "August 2024"),
  /* @__PURE__ */ createBaseVNode("td", null, "Q4")
], -1);
const _hoisted_32 = /* @__PURE__ */ createBaseVNode("p", { class: "text-caption" }, "*️⃣ Already in Labs", -1);
const _hoisted_33 = { id: "released" };
const _hoisted_34 = /* @__PURE__ */ createBaseVNode("strong", null, "minor", -1);
const _hoisted_35 = /* @__PURE__ */ createBaseVNode("strong", null, "major", -1);
const _hoisted_36 = { id: "v3-6-nebula" };
const _hoisted_37 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Released:"),
  /* @__PURE__ */ createTextVNode(" April 2024")
], -1);
const _hoisted_38 = /* @__PURE__ */ createBaseVNode("strong", null, "Hero:", -1);
const _hoisted_39 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Target Release:"),
  /* @__PURE__ */ createTextVNode(" Q2 2024")
], -1);
const _hoisted_40 = /* @__PURE__ */ createBaseVNode("strong", null, "Notes:", -1);
const _hoisted_41 = /* @__PURE__ */ createBaseVNode("strong", null, "Overview:", -1);
const _hoisted_42 = /* @__PURE__ */ createBaseVNode("li", null, "Multiple bug fixes and improvements.", -1);
const _hoisted_43 = /* @__PURE__ */ createBaseVNode("strong", null, "Milestone Issues:", -1);
const _hoisted_44 = { id: "v3-5-polaris" };
const _hoisted_45 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Released:"),
  /* @__PURE__ */ createTextVNode(" January 2024")
], -1);
const _hoisted_46 = /* @__PURE__ */ createBaseVNode("strong", null, "Hero:", -1);
const _hoisted_47 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Target Release:"),
  /* @__PURE__ */ createTextVNode(" Q1 2024")
], -1);
const _hoisted_48 = /* @__PURE__ */ createBaseVNode("strong", null, "Notes:", -1);
const _hoisted_49 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Overview:"),
  /* @__PURE__ */ createTextVNode(" A maintenance cycle post v3.4 that will focuses on bug fixes and general improvements.")
], -1);
const _hoisted_50 = /* @__PURE__ */ createBaseVNode("strong", null, "Milestone Issues:", -1);
const _hoisted_51 = { id: "v3-4-blackguard" };
const _hoisted_52 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Released:"),
  /* @__PURE__ */ createTextVNode(" November 2023")
], -1);
const _hoisted_53 = /* @__PURE__ */ createBaseVNode("strong", null, "Hero:", -1);
const _hoisted_54 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Target Release:"),
  /* @__PURE__ */ createTextVNode(" Q3 2023")
], -1);
const _hoisted_55 = /* @__PURE__ */ createBaseVNode("strong", null, "Notes:", -1);
const _hoisted_56 = /* @__PURE__ */ createBaseVNode("strong", null, "Overview:", -1);
const _hoisted_57 = /* @__PURE__ */ createBaseVNode("strong", null, "Milestone Issues:", -1);
const _hoisted_58 = { id: "v2-7-nirvana" };
const _hoisted_59 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Released:"),
  /* @__PURE__ */ createTextVNode(" July 2023")
], -1);
const _hoisted_60 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Target Release:"),
  /* @__PURE__ */ createTextVNode(" Q2 2023")
], -1);
const _hoisted_61 = /* @__PURE__ */ createBaseVNode("strong", null, "Notes:", -1);
const _hoisted_62 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "LTS Support until:"),
  /* @__PURE__ */ createTextVNode(" January 2025")
], -1);
const _hoisted_63 = /* @__PURE__ */ createBaseVNode("strong", null, "Milestone Issues:", -1);
const _hoisted_64 = { id: "v3-3-icarus" };
const _hoisted_65 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Released:"),
  /* @__PURE__ */ createTextVNode(" May 2023")
], -1);
const _hoisted_66 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Target Release:"),
  /* @__PURE__ */ createTextVNode(" Q2 2023")
], -1);
const _hoisted_67 = /* @__PURE__ */ createBaseVNode("strong", null, "Notes:", -1);
const _hoisted_68 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Overview:"),
  /* @__PURE__ */ createTextVNode(" A small intermediary minor that will release alongside Vue v3.3 and include a few small features.")
], -1);
const _hoisted_69 = /* @__PURE__ */ createBaseVNode("strong", null, "Milestone Issues:", -1);
const _hoisted_70 = { id: "v3-2-orion" };
const _hoisted_71 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Released:"),
  /* @__PURE__ */ createTextVNode(" April 2023")
], -1);
const _hoisted_72 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Target Release:"),
  /* @__PURE__ */ createTextVNode(" Q2 2023")
], -1);
const _hoisted_73 = /* @__PURE__ */ createBaseVNode("strong", null, "Notes:", -1);
const _hoisted_74 = /* @__PURE__ */ createBaseVNode("strong", null, "Overview:", -1);
const _hoisted_75 = /* @__PURE__ */ createBaseVNode("strong", null, "Milestone Issues:", -1);
const _hoisted_76 = { id: "v3-1-valkyrie" };
const _hoisted_77 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Released:"),
  /* @__PURE__ */ createTextVNode(" January 2023")
], -1);
const _hoisted_78 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Target Release:"),
  /* @__PURE__ */ createTextVNode(" Q1 2023")
], -1);
const _hoisted_79 = /* @__PURE__ */ createBaseVNode("strong", null, "Notes:", -1);
const _hoisted_80 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Overview:"),
  /* @__PURE__ */ createTextVNode(" First post v3 release that will focus on porting remaining missing v2 components and general bug fixing.")
], -1);
const _hoisted_81 = /* @__PURE__ */ createBaseVNode("strong", null, "Milestone Issues:", -1);
const _hoisted_82 = { id: "labs" };
const _hoisted_83 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Released:"),
  /* @__PURE__ */ createTextVNode(" January 2023")
], -1);
const _hoisted_84 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Target Release:"),
  /* @__PURE__ */ createTextVNode(" Q4 2022")
], -1);
const _hoisted_85 = /* @__PURE__ */ createBaseVNode("strong", null, "Overview:", -1);
const _hoisted_86 = { id: "v3-0-titan" };
const _hoisted_87 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Released:"),
  /* @__PURE__ */ createTextVNode(" October 2022")
], -1);
const _hoisted_88 = /* @__PURE__ */ createBaseVNode("strong", null, "Notes:", -1);
const _hoisted_89 = /* @__PURE__ */ createBaseVNode("strong", null, "Overview:", -1);
const _hoisted_90 = /* @__PURE__ */ createBaseVNode("li", null, "Global properties that allow you to make large overarching changes to your app", -1);
const _hoisted_91 = /* @__PURE__ */ createBaseVNode("li", null, "Greatly improved TypeScript support", -1);
const _hoisted_92 = /* @__PURE__ */ createBaseVNode("li", null, "Better framework coverage with E2E testing using Cypress", -1);
const _hoisted_93 = { id: "v2-6-horizon" };
const _hoisted_94 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Released"),
  /* @__PURE__ */ createTextVNode(": November 2021")
], -1);
const _hoisted_95 = /* @__PURE__ */ createBaseVNode("strong", null, "Notes", -1);
const _hoisted_96 = /* @__PURE__ */ createBaseVNode("strong", null, "Overview", -1);
const _hoisted_97 = { id: "v2-5-avalon" };
const _hoisted_98 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Released:"),
  /* @__PURE__ */ createTextVNode(" May 2021")
], -1);
const _hoisted_99 = /* @__PURE__ */ createBaseVNode("strong", null, "Notes:", -1);
const _hoisted_100 = /* @__PURE__ */ createBaseVNode("strong", null, "Overview:", -1);
const _hoisted_101 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Objectives:"),
  /* @__PURE__ */ createBaseVNode("ul", null, [
    /* @__PURE__ */ createBaseVNode("li", null, [
      /* @__PURE__ */ createTextVNode("Expand functionality of "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-data-table")
    ]),
    /* @__PURE__ */ createBaseVNode("li", null, "Quality of life improvements"),
    /* @__PURE__ */ createBaseVNode("li", null, "General bug fixes")
  ])
], -1);
const _hoisted_102 = { id: "v2-4-endurance" };
const _hoisted_103 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Released:"),
  /* @__PURE__ */ createTextVNode(" December 2020")
], -1);
const _hoisted_104 = /* @__PURE__ */ createBaseVNode("strong", null, "Notes:", -1);
const _hoisted_105 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Overview:"),
  /* @__PURE__ */ createTextVNode(" The v2.4 release provides bug fixes, features and quality of life changes for Vuetify as we prepare for v3 Alpha. This release contains some new features that we are building into Vuetify 3 right now such as new slots for "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-carousel"),
  /* @__PURE__ */ createTextVNode(" and support for globally defined icon components.")
], -1);
const _hoisted_106 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Objectives:"),
  /* @__PURE__ */ createBaseVNode("ul", null, [
    /* @__PURE__ */ createBaseVNode("li", null, [
      /* @__PURE__ */ createTextVNode("Add "),
      /* @__PURE__ */ createBaseVNode("strong", null, "plain"),
      /* @__PURE__ */ createTextVNode(" property for "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn")
    ]),
    /* @__PURE__ */ createBaseVNode("li", null, [
      /* @__PURE__ */ createTextVNode("Add new locales "),
      /* @__PURE__ */ createBaseVNode("ul", null, [
        /* @__PURE__ */ createBaseVNode("li", null, "Azerbaijani"),
        /* @__PURE__ */ createBaseVNode("li", null, "Central Kurdish")
      ])
    ]),
    /* @__PURE__ */ createBaseVNode("li", null, [
      /* @__PURE__ */ createTextVNode("Add typography css classes "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "text-pre"),
      /* @__PURE__ */ createTextVNode(" and "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "text-pre-wrap")
    ]),
    /* @__PURE__ */ createBaseVNode("li", null, [
      /* @__PURE__ */ createTextVNode("Add new slots for "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-carousel")
    ]),
    /* @__PURE__ */ createBaseVNode("li", null, "Support for a globally defined icon components"),
    /* @__PURE__ */ createBaseVNode("li", null, [
      /* @__PURE__ */ createTextVNode("Improved accessibility in the "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-menu"),
      /* @__PURE__ */ createTextVNode(" component")
    ])
  ])
], -1);
const _hoisted_107 = { id: "v2-3-liberator" };
const _hoisted_108 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Released:"),
  /* @__PURE__ */ createTextVNode(" June 2020")
], -1);
const _hoisted_109 = /* @__PURE__ */ createBaseVNode("strong", null, "Notes:", -1);
const _hoisted_110 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Overview:"),
  /* @__PURE__ */ createTextVNode(" The v2.3 release was dropped earlier in the year to focus on v3 development but was revived when COVID-19 showed up. This release is packed full of quality of life changes, new features such as the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-virtual-scroll"),
  /* @__PURE__ */ createTextVNode(" component, responsive typography css classes.")
], -1);
const _hoisted_111 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Objectives:"),
  /* @__PURE__ */ createBaseVNode("ul", null, [
    /* @__PURE__ */ createBaseVNode("li", null, [
      /* @__PURE__ */ createTextVNode("Add new css helper classes for "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "text-decoration"),
      /* @__PURE__ */ createTextVNode(", "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "border-radius"),
      /* @__PURE__ */ createTextVNode(", "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "typography"),
      /* @__PURE__ */ createTextVNode(", and more.")
    ]),
    /* @__PURE__ */ createBaseVNode("li", null, [
      /* @__PURE__ */ createTextVNode("Add new "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-virtual-scroll"),
      /* @__PURE__ */ createTextVNode(" component")
    ]),
    /* @__PURE__ */ createBaseVNode("li", null, [
      /* @__PURE__ */ createTextVNode("Improve "),
      /* @__PURE__ */ createBaseVNode("em", null, "Date Pickers, Data Tables, and Calendars")
    ]),
    /* @__PURE__ */ createBaseVNode("li", null, [
      /* @__PURE__ */ createTextVNode("Harden framework in preparation for "),
      /* @__PURE__ */ createBaseVNode("strong", null, "LTS version")
    ])
  ])
], -1);
const _hoisted_112 = { id: "v2-2-tigris" };
const _hoisted_113 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Released:"),
  /* @__PURE__ */ createTextVNode(" January 2020")
], -1);
const _hoisted_114 = /* @__PURE__ */ createBaseVNode("strong", null, "Notes:", -1);
const _hoisted_115 = /* @__PURE__ */ createBaseVNode("strong", null, "Overview:", -1);
const _hoisted_116 = /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "user customizable", -1);
const _hoisted_117 = /* @__PURE__ */ createBaseVNode("strong", null, "Objectives:", -1);
const _hoisted_118 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createTextVNode("Add "),
  /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "thousands"),
  /* @__PURE__ */ createTextVNode(" of new SASS variables")
], -1);
const _hoisted_119 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createTextVNode("Create a new Vuetify Service for bootstrapping pre-configured framework options; "),
  /* @__PURE__ */ createBaseVNode("strong", null, "Preset")
], -1);
const _hoisted_120 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createTextVNode("Add new features and improve code styling of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-badge")
], -1);
const _hoisted_121 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createTextVNode("Add new features and improve code styling of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-expansion-panels")
], -1);
const _hoisted_122 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createTextVNode("new "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-theme-provider"),
  /* @__PURE__ */ createTextVNode(" component")
], -1);
const _hoisted_123 = { id: "v2-1-vanguard" };
const _hoisted_124 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Released:"),
  /* @__PURE__ */ createTextVNode(" October 2019")
], -1);
const _hoisted_125 = /* @__PURE__ */ createBaseVNode("strong", null, "Notes:", -1);
const _hoisted_126 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Overview:"),
  /* @__PURE__ */ createTextVNode(" A maintenance cycle to work on bugs from the v2.0 release. This includes performance issues, incorrect or missing a11y, RTL, regressions and general fixes. This will allow the team to catch up on the backlog of tasks that have accumulated over the 8 month development cycle of the previous release.")
], -1);
const _hoisted_127 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Objectives:"),
  /* @__PURE__ */ createBaseVNode("ul", null, [
    /* @__PURE__ */ createBaseVNode("li", null, [
      /* @__PURE__ */ createTextVNode("Add new components "),
      /* @__PURE__ */ createBaseVNode("ul", null, [
        /* @__PURE__ */ createBaseVNode("li", null, [
          /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-lazy")
        ]),
        /* @__PURE__ */ createBaseVNode("li", null, [
          /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-skeleton-loader")
        ])
      ])
    ]),
    /* @__PURE__ */ createBaseVNode("li", null, [
      /* @__PURE__ */ createTextVNode("Add new directives "),
      /* @__PURE__ */ createBaseVNode("ul", null, [
        /* @__PURE__ */ createBaseVNode("li", null, [
          /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-intersect")
        ]),
        /* @__PURE__ */ createBaseVNode("li", null, [
          /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-mutate")
        ])
      ])
    ]),
    /* @__PURE__ */ createBaseVNode("li", null, [
      /* @__PURE__ */ createTextVNode("Add lazy loading support for "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-img")
    ])
  ])
], -1);
const _hoisted_128 = { id: "v2-0-arcadia" };
const _hoisted_129 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Released:"),
  /* @__PURE__ */ createTextVNode(" July 2019")
], -1);
const _hoisted_130 = /* @__PURE__ */ createBaseVNode("strong", null, "Notes:", -1);
const _hoisted_131 = /* @__PURE__ */ createBaseVNode("strong", null, "Overview:", -1);
const _hoisted_132 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Objectives:"),
  /* @__PURE__ */ createBaseVNode("ul", null, [
    /* @__PURE__ */ createBaseVNode("li", null, [
      /* @__PURE__ */ createTextVNode("Add new components "),
      /* @__PURE__ */ createBaseVNode("ul", null, [
        /* @__PURE__ */ createBaseVNode("li", null, [
          /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-app-bar")
        ]),
        /* @__PURE__ */ createBaseVNode("li", null, [
          /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-banner")
        ]),
        /* @__PURE__ */ createBaseVNode("li", null, [
          /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-chip-group")
        ]),
        /* @__PURE__ */ createBaseVNode("li", null, [
          /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-color-picker")
        ]),
        /* @__PURE__ */ createBaseVNode("li", null, [
          /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-file-input")
        ]),
        /* @__PURE__ */ createBaseVNode("li", null, [
          /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-list-item-group")
        ]),
        /* @__PURE__ */ createBaseVNode("li", null, [
          /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-overlay")
        ]),
        /* @__PURE__ */ createBaseVNode("li", null, [
          /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-simple-table")
        ]),
        /* @__PURE__ */ createBaseVNode("li", null, [
          /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-slide-group")
        ])
      ])
    ]),
    /* @__PURE__ */ createBaseVNode("li", null, "Complete update to Material Design 2"),
    /* @__PURE__ */ createBaseVNode("li", null, "Convert from Javascript to Typescript"),
    /* @__PURE__ */ createBaseVNode("li", null, "Convert from Stylus to Sass"),
    /* @__PURE__ */ createBaseVNode("li", null, "Convert from avoriaz to vue-test-utils")
  ])
], -1);
const _hoisted_133 = { id: "contributing" };
const _hoisted_134 = { id: "archived" };
const _hoisted_135 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The following releases are old and unsupported "),
  /* @__PURE__ */ createBaseVNode("strong", null, "minor"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "major"),
  /* @__PURE__ */ createTextVNode(" versions:")
], -1);
const _hoisted_136 = { id: "v1-5" };
const _hoisted_137 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Released:"),
  /* @__PURE__ */ createTextVNode(" February 2019")
], -1);
const _hoisted_138 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Support until:"),
  /* @__PURE__ */ createTextVNode(" August 1st, 2020")
], -1);
const _hoisted_139 = /* @__PURE__ */ createBaseVNode("strong", null, "Notes:", -1);
const _hoisted_140 = /* @__PURE__ */ createBaseVNode("strong", null, "Overview:", -1);
const _hoisted_141 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-calendar", -1);
const _hoisted_142 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-sparkline", -1);
const _hoisted_143 = /* @__PURE__ */ createBaseVNode("strong", null, "bar", -1);
const _hoisted_144 = /* @__PURE__ */ createBaseVNode("strong", null, "fill", -1);
const _hoisted_145 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-treeview", -1);
const _hoisted_146 = /* @__PURE__ */ createBaseVNode("strong", null, "July 31st, 2020", -1);
const _hoisted_147 = { id: "v1-4" };
const _hoisted_148 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Released:"),
  /* @__PURE__ */ createTextVNode(" December 2018")
], -1);
const _hoisted_149 = /* @__PURE__ */ createBaseVNode("strong", null, "Notes:", -1);
const _hoisted_150 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Overview:"),
  /* @__PURE__ */ createTextVNode(" Added new components "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-sparkline"),
  /* @__PURE__ */ createTextVNode(" and abstracted "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-toolbar"),
  /* @__PURE__ */ createTextVNode("’s functionality into multiple components for easier maintainability and testing. Rebuilt the entire documentation to make it easier for contributors and maintenance from the team.")
], -1);
const _hoisted_151 = { id: "v1-3" };
const _hoisted_152 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Released:"),
  /* @__PURE__ */ createTextVNode(" December 2018")
], -1);
const _hoisted_153 = /* @__PURE__ */ createBaseVNode("strong", null, "Notes:", -1);
const _hoisted_154 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Overview:"),
  /* @__PURE__ */ createTextVNode(" Added new components, "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-treeview"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-timeline"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-item-group"),
  /* @__PURE__ */ createTextVNode(". Unified the interfaces used in "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-tabs"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-carousel"),
  /* @__PURE__ */ createTextVNode(". Improved the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "vuetify-loader"),
  /* @__PURE__ */ createTextVNode(" to support effortless application tree-shaking of Vuetify components.")
], -1);
const _hoisted_155 = { id: "v1-2" };
const _hoisted_156 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Released:"),
  /* @__PURE__ */ createTextVNode(" October 2018")
], -1);
const _hoisted_157 = /* @__PURE__ */ createBaseVNode("strong", null, "Notes:", -1);
const _hoisted_158 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Overview:"),
  /* @__PURE__ */ createTextVNode(" Added new components, "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-img"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-rating"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-hover"),
  /* @__PURE__ */ createTextVNode(". Improved theme propagation system and expanded the functionality of the colors used with components such as HEX and RGBA. Als added numerous new locales.")
], -1);
const _hoisted_159 = { id: "v1-1" };
const _hoisted_160 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Released:"),
  /* @__PURE__ */ createTextVNode(" July 2018")
], -1);
const _hoisted_161 = /* @__PURE__ */ createBaseVNode("strong", null, "Notes:", -1);
const _hoisted_162 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Overview:"),
  /* @__PURE__ */ createTextVNode(" A complete rebuild of all form functionality including all inputs and selection controls. Abstracted features from components like "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-select"),
  /* @__PURE__ */ createTextVNode(" into new implementations, "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-autocomplete"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-combobox"),
  /* @__PURE__ */ createTextVNode(" for more scoped functionality and easier testing. This release also marked the first official support of "),
  /* @__PURE__ */ createBaseVNode("strong", null, "RTL"),
  /* @__PURE__ */ createTextVNode(" languages.")
], -1);
const _hoisted_163 = { id: "v1-0" };
const _hoisted_164 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Released:"),
  /* @__PURE__ */ createTextVNode(" February 2018")
], -1);
const _hoisted_165 = /* @__PURE__ */ createBaseVNode("strong", null, "Notes:", -1);
const _hoisted_166 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Overview:"),
  /* @__PURE__ */ createTextVNode(" The official v1.0 release party. After 18 months and Kael’s sanity, we rolled into our first "),
  /* @__PURE__ */ createBaseVNode("strong", null, "MAJOR"),
  /* @__PURE__ */ createTextVNode(" release. This included a multitude of brand new components, features and functionality.")
], -1);
const _hoisted_167 = { id: "alpha-release" };
const _hoisted_168 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "Released:"),
    /* @__PURE__ */ createTextVNode(" December 2016")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "Overview:"),
    /* @__PURE__ */ createTextVNode(" Vuetify is officially announced to the public. The framework initially shipped with 40 components and came in at a whopping 46kb.")
  ])
], -1);
const frontmatter = { "meta": { "nav": "Roadmap", "title": "The Vuetify roadmap", "description": "The upcoming planned features and new functionality coming to Vuetify. New components, new directives, and much much more!.", "keywords": "vuetify roadmap, future plans, new vuetify features" }, "related": ["/introduction/long-term-support/", "/introduction/enterprise-support/", "/getting-started/browser-support/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "roadmap",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Roadmap", "title": "The Vuetify roadmap", "description": "The upcoming planned features and new functionality coming to Vuetify. New components, new directives, and much much more!.", "keywords": "vuetify roadmap, future plans, new vuetify features" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Roadmap", "title": "The Vuetify roadmap", "description": "The upcoming planned features and new functionality coming to Vuetify. New components, new directives, and much much more!.", "keywords": "vuetify roadmap, future plans, new vuetify features" }, "related": ["/introduction/long-term-support/", "/introduction/enterprise-support/", "/getting-started/browser-support/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_vo_promotions_card_vuetify = resolveComponent("vo-promotions-card-vuetify");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_app_divider = resolveComponent("app-divider");
      const _component_alert = resolveComponent("alert");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#the-vuetify-roadmap",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("The Vuetify roadmap")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_vo_promotions_card_vuetify),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#section-2024-component-roadmap",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("2024 Component Roadmap")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_5,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", _hoisted_6, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "https://github.com/vuetifyjs/vuetify/milestone/73" }, {
                            default: withCtx(() => [
                              createTextVNode("v3.7 (Odyssey)")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7,
                        _hoisted_8
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/components/treeview/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-treeview")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_9,
                        _hoisted_10
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/components/number-inputs/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-number-input")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_11,
                        _hoisted_12
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/components/time-pickers/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-time-picker")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_13,
                        _hoisted_14
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/components/date-inputs/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-date-input")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_15,
                        _hoisted_16
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "https://github.com/vuetifyjs/vuetify/pull/19667" }, {
                            default: withCtx(() => [
                              createTextVNode("v-file-upload")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_17,
                        _hoisted_18
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "https://github.com/vuetifyjs/vuetify/pull/19709" }, {
                            default: withCtx(() => [
                              createTextVNode("v-time-input")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_19,
                        _hoisted_20
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "https://github.com/vuetifyjs/vuetify/pull/19524" }, {
                            default: withCtx(() => [
                              createTextVNode("v-stepper-vertical")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_21,
                        _hoisted_22
                      ]),
                      createBaseVNode("tr", _hoisted_23, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "https://github.com/vuetifyjs/vuetify/milestone/74" }, {
                            default: withCtx(() => [
                              createTextVNode("v3.8 (Andromeda)")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_24,
                        _hoisted_25
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/components/calendars/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-calendar")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_26,
                        _hoisted_27
                      ]),
                      _hoisted_28,
                      _hoisted_29,
                      _hoisted_30,
                      _hoisted_31
                    ])
                  ]),
                  _: 1
                }),
                _hoisted_32
              ]),
              createBaseVNode("section", _hoisted_33, [
                createVNode(_component_app_heading, {
                  href: "#released",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Released")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("The following are the already released "),
                  _hoisted_34,
                  createTextVNode(" and "),
                  _hoisted_35,
                  createTextVNode(" version updates. Find more information on the "),
                  createVNode(_component_app_link, { href: "https://github.com/vuetifyjs/vuetify/releases/latest" }, {
                    default: withCtx(() => [
                      createTextVNode("latest releases")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" on GitHub.")
                ]),
                createBaseVNode("section", _hoisted_36, [
                  createVNode(_component_app_heading, {
                    href: "#v3-6-nebula",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v3.6 (Nebula)")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("ul", null, [
                    _hoisted_37,
                    createBaseVNode("li", null, [
                      _hoisted_38,
                      createTextVNode(),
                      createVNode(_component_app_link, { href: "https://cdn.vuetifyjs.com/docs/images/release-banners/nebula-36.png" }, {
                        default: withCtx(() => [
                          createTextVNode("Banner")
                        ]),
                        _: 1
                      })
                    ]),
                    _hoisted_39,
                    createBaseVNode("li", null, [
                      _hoisted_40,
                      createTextVNode(),
                      createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v3.6.0" }, {
                        default: withCtx(() => [
                          createTextVNode("v3.6 Release")
                        ]),
                        _: 1
                      })
                    ]),
                    createBaseVNode("li", null, [
                      _hoisted_41,
                      createTextVNode(" Introduced 5 new components to the main framework from Labs: "),
                      createBaseVNode("ul", null, [
                        createBaseVNode("li", null, [
                          createVNode(_component_app_link, { href: "/components/floating-action-buttons/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-fab")
                            ]),
                            _: 1
                          })
                        ]),
                        createBaseVNode("li", null, [
                          createVNode(_component_app_link, { href: "/components/empty-states/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-empty-state")
                            ]),
                            _: 1
                          })
                        ]),
                        createBaseVNode("li", null, [
                          createVNode(_component_app_link, { href: "/components/sparklines/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-sparkline")
                            ]),
                            _: 1
                          })
                        ]),
                        createBaseVNode("li", null, [
                          createVNode(_component_app_link, { href: "/components/speed-dials/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-speed-dial")
                            ]),
                            _: 1
                          })
                        ]),
                        createBaseVNode("li", null, [
                          createVNode(_component_app_link, { href: "/components/confirm-edit/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-confirm-edit")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_42
                      ])
                    ]),
                    createBaseVNode("li", null, [
                      _hoisted_43,
                      createTextVNode(),
                      createVNode(_component_app_link, { href: "https://github.com/vuetifyjs/vuetify/milestone/72" }, {
                        default: withCtx(() => [
                          createTextVNode("Github Issues")
                        ]),
                        _: 1
                      })
                    ])
                  ])
                ]),
                createBaseVNode("section", _hoisted_44, [
                  createVNode(_component_app_heading, {
                    href: "#v3-5-polaris",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v3.5 (Polaris)")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("ul", null, [
                    _hoisted_45,
                    createBaseVNode("li", null, [
                      _hoisted_46,
                      createTextVNode(),
                      createVNode(_component_app_link, { href: "https://cdn.vuetifyjs.com/docs/images/release-banners/polaris-35.png" }, {
                        default: withCtx(() => [
                          createTextVNode("Banner")
                        ]),
                        _: 1
                      })
                    ]),
                    _hoisted_47,
                    createBaseVNode("li", null, [
                      _hoisted_48,
                      createTextVNode(),
                      createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v3.5.0" }, {
                        default: withCtx(() => [
                          createTextVNode("v3.5 Release")
                        ]),
                        _: 1
                      })
                    ]),
                    _hoisted_49,
                    createBaseVNode("li", null, [
                      _hoisted_50,
                      createTextVNode(),
                      createVNode(_component_app_link, { href: "https://github.com/vuetifyjs/vuetify/milestone/70" }, {
                        default: withCtx(() => [
                          createTextVNode("Github Issues")
                        ]),
                        _: 1
                      })
                    ])
                  ])
                ]),
                createBaseVNode("section", _hoisted_51, [
                  createVNode(_component_app_heading, {
                    href: "#v3-4-blackguard",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v3.4 (Blackguard)")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("ul", null, [
                    _hoisted_52,
                    createBaseVNode("li", null, [
                      _hoisted_53,
                      createTextVNode(),
                      createVNode(_component_app_link, { href: "https://cdn.vuetifyjs.com/docs/images/release-banners/blackguard-34.png" }, {
                        default: withCtx(() => [
                          createTextVNode("Banner")
                        ]),
                        _: 1
                      })
                    ]),
                    _hoisted_54,
                    createBaseVNode("li", null, [
                      _hoisted_55,
                      createTextVNode(),
                      createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v3.4.0" }, {
                        default: withCtx(() => [
                          createTextVNode("v3.4 Release")
                        ]),
                        _: 1
                      })
                    ]),
                    createBaseVNode("li", null, [
                      _hoisted_56,
                      createTextVNode(" Introduced 8 updated components to the main framework from Labs: "),
                      createBaseVNode("ul", null, [
                        createBaseVNode("li", null, [
                          createVNode(_component_app_link, { href: "/components/bottom-sheets/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-bottom-sheet")
                            ]),
                            _: 1
                          })
                        ]),
                        createBaseVNode("li", null, [
                          createVNode(_component_app_link, { href: "/components/data-iterators/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-data-iterator")
                            ]),
                            _: 1
                          })
                        ]),
                        createBaseVNode("li", null, [
                          createVNode(_component_app_link, { href: "/components/data-tables/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-data-table")
                            ]),
                            _: 1
                          })
                        ]),
                        createBaseVNode("li", null, [
                          createVNode(_component_app_link, { href: "/components/date-pickers/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-date-picker")
                            ]),
                            _: 1
                          })
                        ]),
                        createBaseVNode("li", null, [
                          createVNode(_component_app_link, { href: "/components/infinite-scroller/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-infinite-scroll")
                            ]),
                            _: 1
                          })
                        ]),
                        createBaseVNode("li", null, [
                          createVNode(_component_app_link, { href: "/components/otp-input/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-opt-input")
                            ]),
                            _: 1
                          })
                        ]),
                        createBaseVNode("li", null, [
                          createVNode(_component_app_link, { href: "/components/skeleton-loaders/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-skeleton-loader")
                            ]),
                            _: 1
                          })
                        ]),
                        createBaseVNode("li", null, [
                          createVNode(_component_app_link, { href: "/components/steppers/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-stepper")
                            ]),
                            _: 1
                          }),
                          createTextVNode(".")
                        ])
                      ])
                    ]),
                    createBaseVNode("li", null, [
                      _hoisted_57,
                      createTextVNode(),
                      createVNode(_component_app_link, { href: "https://github.com/vuetifyjs/vuetify/milestone/61" }, {
                        default: withCtx(() => [
                          createTextVNode("Github Issues")
                        ]),
                        _: 1
                      })
                    ])
                  ])
                ]),
                createBaseVNode("section", _hoisted_58, [
                  createVNode(_component_app_heading, {
                    href: "#v2-7-nirvana",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v2.7 (Nirvana)")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("ul", null, [
                    _hoisted_59,
                    _hoisted_60,
                    createBaseVNode("li", null, [
                      _hoisted_61,
                      createTextVNode(),
                      createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v2.7.0" }, {
                        default: withCtx(() => [
                          createTextVNode("v2.7 Release")
                        ]),
                        _: 1
                      })
                    ]),
                    _hoisted_62,
                    createBaseVNode("li", null, [
                      _hoisted_63,
                      createTextVNode(),
                      createVNode(_component_app_link, { href: "https://github.com/vuetifyjs/vuetify/milestone/59" }, {
                        default: withCtx(() => [
                          createTextVNode("Github Issues")
                        ]),
                        _: 1
                      })
                    ])
                  ]),
                  createVNode(_component_app_divider)
                ]),
                createBaseVNode("section", _hoisted_64, [
                  createVNode(_component_app_heading, {
                    href: "#v3-3-icarus",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v3.3 (Icarus)")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("ul", null, [
                    _hoisted_65,
                    _hoisted_66,
                    createBaseVNode("li", null, [
                      _hoisted_67,
                      createTextVNode(),
                      createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v3.3.0" }, {
                        default: withCtx(() => [
                          createTextVNode("v3.3 Release")
                        ]),
                        _: 1
                      })
                    ]),
                    _hoisted_68,
                    createBaseVNode("li", null, [
                      _hoisted_69,
                      createTextVNode(),
                      createVNode(_component_app_link, { href: "https://github.com/vuetifyjs/vuetify/milestone/67" }, {
                        default: withCtx(() => [
                          createTextVNode("Github Issues")
                        ]),
                        _: 1
                      })
                    ])
                  ]),
                  createVNode(_component_app_divider)
                ]),
                createBaseVNode("section", _hoisted_70, [
                  createVNode(_component_app_heading, {
                    href: "#v3-2-orion",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v3.2 (Orion)")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("ul", null, [
                    _hoisted_71,
                    _hoisted_72,
                    createBaseVNode("li", null, [
                      _hoisted_73,
                      createTextVNode(),
                      createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v3.2.0" }, {
                        default: withCtx(() => [
                          createTextVNode("v3.2 Release")
                        ]),
                        _: 1
                      })
                    ]),
                    createBaseVNode("li", null, [
                      _hoisted_74,
                      createTextVNode(" New and ported components from v2. Exposed defaults system for public use, allowing you to hook into the global default configuration with your components. More information in the "),
                      createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v3.2.0" }, {
                        default: withCtx(() => [
                          createTextVNode("release notes")
                        ]),
                        _: 1
                      })
                    ]),
                    createBaseVNode("li", null, [
                      _hoisted_75,
                      createTextVNode(),
                      createVNode(_component_app_link, { href: "https://github.com/vuetifyjs/vuetify/milestone/53" }, {
                        default: withCtx(() => [
                          createTextVNode("Github Issues")
                        ]),
                        _: 1
                      })
                    ])
                  ]),
                  createVNode(_component_app_divider)
                ]),
                createBaseVNode("section", _hoisted_76, [
                  createVNode(_component_app_heading, {
                    href: "#v3-1-valkyrie",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v3.1 (Valkyrie)")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("ul", null, [
                    _hoisted_77,
                    _hoisted_78,
                    createBaseVNode("li", null, [
                      _hoisted_79,
                      createTextVNode(),
                      createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v3.1.0" }, {
                        default: withCtx(() => [
                          createTextVNode("v3.1 Release")
                        ]),
                        _: 1
                      })
                    ]),
                    _hoisted_80,
                    createBaseVNode("li", null, [
                      _hoisted_81,
                      createTextVNode(),
                      createVNode(_component_app_link, { href: "https://github.com/vuetifyjs/vuetify/milestone/56" }, {
                        default: withCtx(() => [
                          createTextVNode("Github Issues")
                        ]),
                        _: 1
                      })
                    ])
                  ]),
                  createVNode(_component_app_divider)
                ]),
                createBaseVNode("section", _hoisted_82, [
                  createVNode(_component_app_heading, {
                    href: "#labs",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Vuetify Labs")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("ul", null, [
                    _hoisted_83,
                    _hoisted_84,
                    createBaseVNode("li", null, [
                      _hoisted_85,
                      createTextVNode(" Labs is a new package that includes large components from Vuetify 2 in a pre-production state. More information is located on the "),
                      createVNode(_component_app_link, { href: "/labs/introduction/" }, {
                        default: withCtx(() => [
                          createTextVNode("Labs introduction")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" page.")
                    ])
                  ]),
                  createVNode(_component_app_divider)
                ]),
                createBaseVNode("section", _hoisted_86, [
                  createVNode(_component_app_heading, {
                    href: "#v3-0-titan",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v3.0 (Titan)")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("ul", null, [
                    _hoisted_87,
                    createBaseVNode("li", null, [
                      _hoisted_88,
                      createTextVNode(),
                      createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v3.0.0" }, {
                        default: withCtx(() => [
                          createTextVNode("v3.0 Release")
                        ]),
                        _: 1
                      })
                    ]),
                    createBaseVNode("li", null, [
                      _hoisted_89,
                      createBaseVNode("ul", null, [
                        createBaseVNode("li", null, [
                          createTextVNode("Rebuilt for Vue 3 using the new "),
                          createVNode(_component_app_link, { href: "https://vue-composition-api-rfc.netlify.com/" }, {
                            default: withCtx(() => [
                              createTextVNode("composition api")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_90,
                        createBaseVNode("li", null, [
                          createTextVNode("Improved SASS variable customization and extensibility with "),
                          createVNode(_component_app_link, { href: "https://sass-lang.com/documentation/modules" }, {
                            default: withCtx(() => [
                              createTextVNode("Built-In Modules")
                            ]),
                            _: 1
                          })
                        ]),
                        createBaseVNode("li", null, [
                          createTextVNode("New "),
                          createVNode(_component_app_link, { href: "https://github.com/vuetifyjs/vue-cli-plugins" }, {
                            default: withCtx(() => [
                              createTextVNode("Vue CLI presets")
                            ]),
                            _: 1
                          }),
                          createTextVNode(" for generating pre-built starting projects")
                        ]),
                        createBaseVNode("li", null, [
                          createTextVNode("First party "),
                          createVNode(_component_app_link, { href: "https://vitejs.dev/" }, {
                            default: withCtx(() => [
                              createTextVNode("Vite")
                            ]),
                            _: 1
                          }),
                          createTextVNode(" support for lightning fast development")
                        ]),
                        _hoisted_91,
                        _hoisted_92
                      ])
                    ])
                  ]),
                  createVNode(_component_app_divider)
                ]),
                createBaseVNode("section", _hoisted_93, [
                  createVNode(_component_app_heading, {
                    href: "#v2-6-horizon",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v2.6 (Horizon)")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("ul", null, [
                    _hoisted_94,
                    createBaseVNode("li", null, [
                      _hoisted_95,
                      createTextVNode(": "),
                      createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v2.6.0" }, {
                        default: withCtx(() => [
                          createTextVNode("v2.6 Release")
                        ]),
                        _: 1
                      })
                    ]),
                    createBaseVNode("li", null, [
                      _hoisted_96,
                      createTextVNode(": New "),
                      createVNode(_component_app_link, { href: "/components/otp-input/" }, {
                        default: withCtx(() => [
                          createTextVNode("v-otp-input")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" component, calendar event and scrolling improvements, minor features for other components.")
                    ])
                  ]),
                  createVNode(_component_app_divider)
                ]),
                createBaseVNode("section", _hoisted_97, [
                  createVNode(_component_app_heading, {
                    href: "#v2-5-avalon",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v2.5 (Avalon)")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("ul", null, [
                    _hoisted_98,
                    createBaseVNode("li", null, [
                      _hoisted_99,
                      createTextVNode(),
                      createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v2.5.0" }, {
                        default: withCtx(() => [
                          createTextVNode("v2.5 Release")
                        ]),
                        _: 1
                      })
                    ]),
                    createBaseVNode("li", null, [
                      _hoisted_100,
                      createTextVNode(" The v2.5 release adds a multitude of new functionality to "),
                      createVNode(_component_app_link, { href: "/components/data-tables/" }, {
                        default: withCtx(() => [
                          createTextVNode("v-data-table")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" and "),
                      createVNode(_component_app_link, { href: "/components/text-fields/" }, {
                        default: withCtx(() => [
                          createTextVNode("v-text-field")
                        ]),
                        _: 1
                      }),
                      createTextVNode(", as well as bug fixes for the "),
                      createVNode(_component_app_link, { href: "/directives/click-outside/" }, {
                        default: withCtx(() => [
                          createTextVNode("click-outside")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" directive, "),
                      createVNode(_component_app_link, { href: "/components/carousels/" }, {
                        default: withCtx(() => [
                          createTextVNode("v-carousel")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" component, and more.")
                    ]),
                    _hoisted_101
                  ]),
                  createVNode(_component_app_divider)
                ]),
                createBaseVNode("section", _hoisted_102, [
                  createVNode(_component_app_heading, {
                    href: "#v2-4-endurance",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v2.4 (Endurance)")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("ul", null, [
                    _hoisted_103,
                    createBaseVNode("li", null, [
                      _hoisted_104,
                      createTextVNode(),
                      createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v2.4.0" }, {
                        default: withCtx(() => [
                          createTextVNode("v2.4 Release")
                        ]),
                        _: 1
                      })
                    ]),
                    _hoisted_105,
                    _hoisted_106
                  ]),
                  createVNode(_component_app_divider)
                ]),
                createBaseVNode("section", _hoisted_107, [
                  createVNode(_component_app_heading, {
                    href: "#v2-3-liberator",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v2.3 (Liberator)")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("ul", null, [
                    _hoisted_108,
                    createBaseVNode("li", null, [
                      _hoisted_109,
                      createTextVNode(),
                      createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v2.3.0" }, {
                        default: withCtx(() => [
                          createTextVNode("v2.3 Release")
                        ]),
                        _: 1
                      })
                    ]),
                    _hoisted_110,
                    _hoisted_111
                  ]),
                  createVNode(_component_app_divider)
                ]),
                createBaseVNode("section", _hoisted_112, [
                  createVNode(_component_app_heading, {
                    href: "#v2-2-tigris",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v2.2 (Tigris)")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("ul", null, [
                    _hoisted_113,
                    createBaseVNode("li", null, [
                      _hoisted_114,
                      createTextVNode(),
                      createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v2.2.0" }, {
                        default: withCtx(() => [
                          createTextVNode("v2.2 Release")
                        ]),
                        _: 1
                      })
                    ]),
                    createBaseVNode("li", null, [
                      _hoisted_115,
                      createTextVNode(" The introduction of Vuetify Presets. Will include the entire Material Design Studies collection and be "),
                      _hoisted_116,
                      createTextVNode(". Will streamline the process for altering the default styles for the framework. Thousands of SASS variables will be added and a lookup tree for finding those variables will put into the documentation. For more information on Google’s studies, please "),
                      createVNode(_component_app_link, { href: "https://material.io/design/material-studies/about-our-material-studies.html" }, {
                        default: withCtx(() => [
                          createTextVNode("navigate here")
                        ]),
                        _: 1
                      }),
                      createTextVNode(".")
                    ]),
                    createBaseVNode("li", null, [
                      _hoisted_117,
                      createBaseVNode("ul", null, [
                        _hoisted_118,
                        _hoisted_119,
                        createBaseVNode("li", null, [
                          createTextVNode("Create presets for the official "),
                          createVNode(_component_app_link, { href: "https://material.io/design/material-studies/about-our-material-studies.html" }, {
                            default: withCtx(() => [
                              createTextVNode("Material Design Studies")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_120,
                        _hoisted_121,
                        _hoisted_122
                      ])
                    ])
                  ]),
                  createVNode(_component_app_divider)
                ]),
                createBaseVNode("section", _hoisted_123, [
                  createVNode(_component_app_heading, {
                    href: "#v2-1-vanguard",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v2.1 (Vanguard)")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("ul", null, [
                    _hoisted_124,
                    createBaseVNode("li", null, [
                      _hoisted_125,
                      createTextVNode(),
                      createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v2.1.0" }, {
                        default: withCtx(() => [
                          createTextVNode("v2.1 Release")
                        ]),
                        _: 1
                      })
                    ]),
                    _hoisted_126,
                    _hoisted_127
                  ]),
                  createVNode(_component_app_divider)
                ]),
                createBaseVNode("section", _hoisted_128, [
                  createVNode(_component_app_heading, {
                    href: "#v2-0-arcadia",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v2.0 (Arcadia)")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("ul", null, [
                    _hoisted_129,
                    createBaseVNode("li", null, [
                      _hoisted_130,
                      createTextVNode(),
                      createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v2.0.0" }, {
                        default: withCtx(() => [
                          createTextVNode("v2.0 Release")
                        ]),
                        _: 1
                      })
                    ]),
                    createBaseVNode("li", null, [
                      _hoisted_131,
                      createTextVNode(" A complete rebuild of the framework core. Improving the layout and theme systems, platform integration, accessibility, RTL and performance. Update all components to the "),
                      createVNode(_component_app_link, { href: "https://material.io/design/" }, {
                        default: withCtx(() => [
                          createTextVNode("Material Design 2")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" specification. Add additional functionality to multiple existing components and setup v1.5 for "),
                      createVNode(_component_app_link, { href: "/introduction/long-term-support" }, {
                        default: withCtx(() => [
                          createTextVNode("Long-term Support")
                        ]),
                        _: 1
                      }),
                      createTextVNode(".")
                    ]),
                    _hoisted_132
                  ])
                ])
              ]),
              createBaseVNode("section", _hoisted_133, [
                createVNode(_component_app_heading, {
                  href: "#contributing",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Contributing")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("If you’d like to help contribute to Vuetify, head to our "),
                  createVNode(_component_app_link, { href: "/getting-started/contributing/" }, {
                    default: withCtx(() => [
                      createTextVNode("Contribution guide")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" for more information on how to get started.")
                ])
              ]),
              createBaseVNode("section", _hoisted_134, [
                createVNode(_component_app_heading, {
                  href: "#archived",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Archived")
                  ]),
                  _: 1
                }),
                _hoisted_135,
                createBaseVNode("section", _hoisted_136, [
                  createVNode(_component_app_heading, {
                    href: "#v1-5",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v1.5")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("ul", null, [
                    _hoisted_137,
                    _hoisted_138,
                    createBaseVNode("li", null, [
                      _hoisted_139,
                      createTextVNode(),
                      createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v1.5.0" }, {
                        default: withCtx(() => [
                          createTextVNode("v1.5 Release")
                        ]),
                        _: 1
                      })
                    ]),
                    createBaseVNode("li", null, [
                      _hoisted_140,
                      createTextVNode(" Added new component, "),
                      _hoisted_141,
                      createTextVNode(". Improved functionality of "),
                      _hoisted_142,
                      createTextVNode(" with new "),
                      _hoisted_143,
                      createTextVNode(" and "),
                      _hoisted_144,
                      createTextVNode(" properties. Improved "),
                      _hoisted_145,
                      createTextVNode(" and prepared for LTS. Navigate to the "),
                      createVNode(_component_app_link, { href: "/introduction/long-term-support" }, {
                        default: withCtx(() => [
                          createTextVNode("Long-term Support Page")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" for more information on LTS.")
                    ])
                  ]),
                  createVNode(_component_alert, { type: "error" }, {
                    default: withCtx(() => [
                      createBaseVNode("p", null, [
                        createTextVNode("v1.5 reached end of life on "),
                        _hoisted_146,
                        createTextVNode(" and is no longer actively maintained. It is recommended to update to the latest stable version of Vuetify using our "),
                        createVNode(_component_app_link, { href: "/getting-started/upgrade-guide/" }, {
                          default: withCtx(() => [
                            createTextVNode("Upgrade guide")
                          ]),
                          _: 1
                        }),
                        createTextVNode(".")
                      ])
                    ]),
                    _: 1
                  })
                ]),
                createBaseVNode("section", _hoisted_147, [
                  createVNode(_component_app_heading, {
                    href: "#v1-4",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v1.4")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("ul", null, [
                    _hoisted_148,
                    createBaseVNode("li", null, [
                      _hoisted_149,
                      createTextVNode(),
                      createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v1.4.0" }, {
                        default: withCtx(() => [
                          createTextVNode("v1.4 Release")
                        ]),
                        _: 1
                      })
                    ]),
                    _hoisted_150
                  ]),
                  createVNode(_component_app_divider)
                ]),
                createBaseVNode("section", _hoisted_151, [
                  createVNode(_component_app_heading, {
                    href: "#v1-3",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v1.3")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("ul", null, [
                    _hoisted_152,
                    createBaseVNode("li", null, [
                      _hoisted_153,
                      createTextVNode(),
                      createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v1.3.0" }, {
                        default: withCtx(() => [
                          createTextVNode("v1.3 Release")
                        ]),
                        _: 1
                      })
                    ]),
                    _hoisted_154
                  ]),
                  createVNode(_component_app_divider)
                ]),
                createBaseVNode("section", _hoisted_155, [
                  createVNode(_component_app_heading, {
                    href: "#v1-2",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v1.2")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("ul", null, [
                    _hoisted_156,
                    createBaseVNode("li", null, [
                      _hoisted_157,
                      createTextVNode(),
                      createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v1.2.0" }, {
                        default: withCtx(() => [
                          createTextVNode("v1.2 Release")
                        ]),
                        _: 1
                      })
                    ]),
                    _hoisted_158
                  ]),
                  createVNode(_component_app_divider)
                ]),
                createBaseVNode("section", _hoisted_159, [
                  createVNode(_component_app_heading, {
                    href: "#v1-1",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v1.1")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("ul", null, [
                    _hoisted_160,
                    createBaseVNode("li", null, [
                      _hoisted_161,
                      createTextVNode(),
                      createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v1.1.0" }, {
                        default: withCtx(() => [
                          createTextVNode("v1.1 Release")
                        ]),
                        _: 1
                      })
                    ]),
                    _hoisted_162
                  ]),
                  createVNode(_component_app_divider)
                ]),
                createBaseVNode("section", _hoisted_163, [
                  createVNode(_component_app_heading, {
                    href: "#v1-0",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v1.0")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("ul", null, [
                    _hoisted_164,
                    createBaseVNode("li", null, [
                      _hoisted_165,
                      createTextVNode(),
                      createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v1.0.0" }, {
                        default: withCtx(() => [
                          createTextVNode("v1.0 Release")
                        ]),
                        _: 1
                      })
                    ]),
                    _hoisted_166
                  ]),
                  createVNode(_component_app_divider)
                ]),
                createBaseVNode("section", _hoisted_167, [
                  createVNode(_component_app_heading, {
                    href: "#alpha-release",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Alpha release")
                    ]),
                    _: 1
                  }),
                  _hoisted_168
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
