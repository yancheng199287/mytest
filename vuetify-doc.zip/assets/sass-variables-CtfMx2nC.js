import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "sass-variables" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Vuetify uses "),
  /* @__PURE__ */ createBaseVNode("strong", null, "SASS/SCSS"),
  /* @__PURE__ */ createTextVNode(" to craft the style and appearance of all aspects of the framework.")
], -1);
const _hoisted_3 = { id: "installation" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, "Vuetify works out of the box without any additional compilers needing to be installed but does support advanced use-cases such as modifying the underlying variables of the framework. Vite provides built-in support for sass, less and stylus files without the need to install Vite-specific plugins for them; just the corresponding pre-processor itself.", -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-bash" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-bash" }, [
    /* @__PURE__ */ createTextVNode("  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "yarn"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "add"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token parameter variable" }, "-D"),
    /* @__PURE__ */ createTextVNode(" sass\n")
  ])
], -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-bash" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-bash" }, [
    /* @__PURE__ */ createTextVNode("  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "npm"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "install"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token parameter variable" }, "-D"),
    /* @__PURE__ */ createTextVNode(" sass-loader sass\n")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-bash" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-bash" }, [
    /* @__PURE__ */ createTextVNode("  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "pnpm"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "install"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token parameter variable" }, "-D"),
    /* @__PURE__ */ createTextVNode(" sass-loader sass\n")
  ])
], -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-bash" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-bash" }, [
    /* @__PURE__ */ createTextVNode("  bun "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "add"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token parameter variable" }, "-D"),
    /* @__PURE__ */ createTextVNode(" sass-loader sass\n")
  ])
], -1);
const _hoisted_9 = { id: "basic-usage" };
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Create a "),
  /* @__PURE__ */ createBaseVNode("strong", null, "main.scss"),
  /* @__PURE__ */ createTextVNode(" file in your "),
  /* @__PURE__ */ createBaseVNode("strong", null, "src/styles"),
  /* @__PURE__ */ createTextVNode(" directory and update the style import within your "),
  /* @__PURE__ */ createBaseVNode("strong", null, "vuetify.js"),
  /* @__PURE__ */ createTextVNode(" file:")
], -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-scss" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/styles/main.scss",
    class: "language-scss"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "@use"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify'"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token module-modifier keyword" }, "with"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// variables go here"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ";"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-diff" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/plugins/vuetify.js",
    class: "language-diff"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token deleted-sign deleted" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token prefix deleted" }, "-"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token line" }, " import 'vuetify/styles'\n")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token inserted-sign inserted" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token prefix inserted" }, "+"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token line" }, " import '@/styles/main.scss'\n")
    ])
  ])
], -1);
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("p", null, "Within your style file, import the Vuetify styles and specify the variables you want to override, that’s it.", -1);
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "'vuetify/styles'", -1);
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "'vuetify'", -1);
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "'vuetify/settings'", -1);
const _hoisted_17 = { id: "component-specific-variables" };
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("p", null, "Customizing variables used in components is a bit more complex and requires the use of a special build plugin.", -1);
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "styles.configFile", -1);
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-js" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "vite.config.js",
    class: "language-js"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "vuetify"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "styles"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "configFile"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'src/styles/settings.scss'"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-scss" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/styles/settings.scss",
    class: "language-scss"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "@use"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify/settings'"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token module-modifier keyword" }, "with"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token variable" }, "$button-height")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(" 40px"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ";"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "configFile"),
  /* @__PURE__ */ createTextVNode(" will be resolved relative to the project root, and loaded before each of vuetify’s stylesheets. If you were using the basic technique from above, make sure to either:")
], -1);
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Remove it and switch back to "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "import 'vuetify/styles'"),
    /* @__PURE__ */ createTextVNode(", or")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Add "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "@use './settings'"),
    /* @__PURE__ */ createTextVNode(" before "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "@use 'vuetify'"),
    /* @__PURE__ */ createTextVNode(" in "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "main.scss"),
    /* @__PURE__ */ createTextVNode(" and remove the "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "with"),
    /* @__PURE__ */ createTextVNode(" block from "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "@use 'vuetify'"),
    /* @__PURE__ */ createTextVNode(".")
  ])
], -1);
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can keep "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "main.scss"),
  /* @__PURE__ */ createTextVNode(" for other style overrides but don’t do both "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "@use 'vuetify'"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "import 'vuetify/styles'"),
  /* @__PURE__ */ createTextVNode(" or you’ll end up with duplicated styles.")
], -1);
const _hoisted_25 = { id: "variable-api" };
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("p", null, "There are many SASS/SCSS variables that can be customized across the entire Vuetify framework. You can browse all the variables using the tool below:", -1);
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("p", null, "Available SASS variables are located on each component’s API page.", -1);
const _hoisted_28 = { id: "usage-in-templates" };
const _hoisted_29 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "Comp1.vue",
    class: "language-html"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("style")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "lang"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("scss"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token style" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token language-css" }, [
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token atrule" }, [
          /* @__PURE__ */ createBaseVNode("span", { class: "token rule" }, "@use"),
          /* @__PURE__ */ createTextVNode(),
          /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'./settings'"),
          /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ";")
        ]),
        /* @__PURE__ */ createTextVNode("\n\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token selector" }, ".my-button"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode("\n    "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, "height"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
        /* @__PURE__ */ createTextVNode(" settings.$button-height"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ";"),
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createTextVNode("\n")
      ])
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("style")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_30 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Keep in mind that to obtain settings from Vuetify, you must forward its variables from within your local stylesheet. In the following example we modify "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "settings.scss"),
  /* @__PURE__ */ createTextVNode(" to "),
  /* @__PURE__ */ createBaseVNode("strong", null, "forward"),
  /* @__PURE__ */ createTextVNode(" instead of "),
  /* @__PURE__ */ createBaseVNode("strong", null, "use"),
  /* @__PURE__ */ createTextVNode(":")
], -1);
const _hoisted_31 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-diff" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/styles/settings.scss",
    class: "language-diff"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token deleted-sign deleted" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token prefix deleted" }, "-"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token line" }, " @use 'vuetify/settings' with (\n")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token inserted-sign inserted" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token prefix inserted" }, "+"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token line" }, " @forward 'vuetify/settings' with (\n")
    ])
  ])
], -1);
const _hoisted_32 = { id: "disabling-utility-classes" };
const _hoisted_33 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "false", -1);
const _hoisted_34 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-scss" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/styles/settings.scss",
    class: "language-scss"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "@forward"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify/settings'"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token module-modifier keyword" }, "with"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token variable" }, "$utilities")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"align-content"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"align-items"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"align-self"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"border-bottom"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"border-end"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"border-opacity"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"border-start"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"border-style"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"border-top"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"border"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"display"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"flex-direction"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"flex-grow"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"flex-shrink"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"flex-wrap"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"flex"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"float-ltr"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"float-rtl"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"float"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"font-italic"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"font-weight"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"justify-content"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"margin-bottom"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"margin-end"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"margin-left"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"margin-right"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"margin-start"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"margin-top"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"margin-x"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"margin-y"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"margin"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"negative-margin-bottom"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"negative-margin-end"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"negative-margin-left"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"negative-margin-right"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"negative-margin-start"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"negative-margin-top"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"negative-margin-x"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"negative-margin-y"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"negative-margin"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"order"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"overflow-wrap"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"overflow-x"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"overflow-y"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"overflow"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"padding-bottom"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"padding-end"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"padding-left"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"padding-right"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"padding-start"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"padding-top"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"padding-x"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"padding-y"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"padding"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"rounded-bottom-end"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"rounded-bottom-start"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"rounded-bottom"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"rounded-end"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"rounded-start"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"rounded-top-end"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"rounded-top-start"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"rounded-top"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"rounded"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"text-align"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"text-decoration"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"text-mono"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"text-opacity"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"text-overflow"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"text-transform"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"typography"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, '"white-space"'),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ";"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_35 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("To disable all utility classes, set the entire "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "$utilities"),
  /* @__PURE__ */ createTextVNode(" variable to "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "false"),
  /* @__PURE__ */ createTextVNode(":")
], -1);
const _hoisted_36 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-scss" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/styles/settings.scss",
    class: "language-scss"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "@forward"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify/settings'"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token module-modifier keyword" }, "with"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token variable" }, "$utilities")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ";"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_37 = { id: "disabling-color-packs" };
const _hoisted_38 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Color packs are handy for quickly applying a color to a component but mostly unused in production. To disable them, set the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "$color-pack"),
  /* @__PURE__ */ createTextVNode(" variable to "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "false"),
  /* @__PURE__ */ createTextVNode(":")
], -1);
const _hoisted_39 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-scss" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/styles/settings.scss",
    class: "language-scss"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "@forward"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify/settings'"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token module-modifier keyword" }, "with"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token variable" }, "$color-pack")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "false"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ";"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_40 = { id: "enabling-css-cascade-layers" };
const _hoisted_41 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "!important", -1);
const _hoisted_42 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-scss" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/styles/settings.scss",
    class: "language-scss"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "@forward"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify/settings'"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token module-modifier keyword" }, "with"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token variable" }, "$layers")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "true"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ";"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_43 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Import order of stylesheets becomes much more important with layers enabled, "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "import 'vuetify/styles'"),
  /* @__PURE__ */ createTextVNode(" or a file containing "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "@use 'vuetify'"),
  /* @__PURE__ */ createTextVNode(),
  /* @__PURE__ */ createBaseVNode("strong", null, "must"),
  /* @__PURE__ */ createTextVNode(" be loaded "),
  /* @__PURE__ */ createBaseVNode("em", null, "before"),
  /* @__PURE__ */ createTextVNode(" any components or the CSS reset will take precedence over component styles and break everything. If you have separate plugin files make sure to import vuetify’s before "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "App.vue"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_44 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Your own styles will always"),
  /* @__PURE__ */ createBaseVNode("sup", null, "*"),
  /* @__PURE__ */ createTextVNode(" override vuetify’s if you don’t use "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "@layer"),
  /* @__PURE__ */ createTextVNode(" yourself, or you can specify an order for custom layers in a stylesheet loaded before vuetify.")
], -1);
const _hoisted_45 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-css" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/styles/layers.css",
    class: "language-css"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token atrule" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token rule" }, "@layer"),
      /* @__PURE__ */ createTextVNode(" base"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
      /* @__PURE__ */ createTextVNode(" vuetify"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
      /* @__PURE__ */ createTextVNode(" overrides"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ";")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_46 = /* @__PURE__ */ createBaseVNode("p", { class: "text-caption" }, [
  /* @__PURE__ */ createTextVNode("* Layers invert "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "!important"),
  /* @__PURE__ */ createTextVNode(", so anything trying to override an important vuetify style must also be in a layer.")
], -1);
const _hoisted_47 = { id: "caveats" };
const _hoisted_48 = /* @__PURE__ */ createBaseVNode("p", null, "When using sass variables, there are a few considerations to be aware of.", -1);
const _hoisted_49 = { id: "duplicated-css" };
const _hoisted_50 = /* @__PURE__ */ createBaseVNode("p", null, "Placing actual styles or importing a regular stylesheet into the settings file will cause them to be duplicated everywhere the file is imported. Only put variables, mixins, and functions in the settings file, styles should be placed in the main stylesheet or loaded another way.", -1);
const _hoisted_51 = { id: "build-performance" };
const _hoisted_52 = /* @__PURE__ */ createBaseVNode("p", null, "Vuetify loads precompiled CSS by default, enabling variable customization will switch to the base SASS files instead which must be recompiled with your project. This can be a performance hit if you’re using more than a few vuetify components, and also forces you to use the same SASS compiler version as us.", -1);
const _hoisted_53 = { id: "symlinks" };
const _hoisted_54 = /* @__PURE__ */ createBaseVNode("p", null, "PNPM and Yarn 2+ create symlinks to library files instead of copying them to node_modules, sass doesn’t seem to like this and sometimes doesn’t apply the configuration.", -1);
const _hoisted_55 = { id: "sass-loader-with-api3a-27modern27" };
const _hoisted_56 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "api: 'modern'", -1);
const _hoisted_57 = /* @__PURE__ */ createBaseVNode("p", null, "You might have to write a custom importer plugin to load the settings file.", -1);
const frontmatter = { "meta": { "title": "SASS variables", "description": "Customize Vuetify's internal styles by modifying SASS variables.", "keywords": "sass variables, scss variables, modifying Vuetify styles" }, "related": ["/styles/colors/", "/features/theme/", "/features/treeshaking/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "sass-variables",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "SASS variables", "description": "Customize Vuetify's internal styles by modifying SASS variables.", "keywords": "sass variables, scss variables, modifying Vuetify styles" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "title": "SASS variables", "description": "Customize Vuetify's internal styles by modifying SASS variables.", "keywords": "sass variables, scss variables, modifying Vuetify styles" }, "related": ["/styles/colors/", "/features/theme/", "/features/treeshaking/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_alert = resolveComponent("alert");
      const _component_v_tab = resolveComponent("v-tab");
      const _component_app_markup = resolveComponent("app-markup");
      const _component_v_window_item = resolveComponent("v-window-item");
      const _component_doc_tabs = resolveComponent("doc-tabs");
      const _component_features_sass_api = resolveComponent("features-sass-api");
      const _component_app_figure = resolveComponent("app-figure");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#sass-variables",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("SASS variables")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_promoted_entry),
              createVNode(_component_alert, { type: "info" }, {
                default: withCtx(() => [
                  createBaseVNode("p", null, [
                    createTextVNode("It is recommended to familiarize yourself with the "),
                    createVNode(_component_app_link, { href: "/features/treeshaking/" }, {
                      default: withCtx(() => [
                        createTextVNode("Treeshaking")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" guide before continuing.")
                  ])
                ]),
                _: 1
              }),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#installation",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Installation")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createBaseVNode("p", null, [
                  createTextVNode("To begin modifying Vuetify’s internal variables, install the "),
                  createVNode(_component_app_link, { href: "https://sass-lang.com/" }, {
                    default: withCtx(() => [
                      createTextVNode("sass")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" pre-processor:")
                ]),
                createVNode(_component_doc_tabs, null, {
                  tabs: withCtx(() => [
                    createVNode(_component_v_tab, {
                      value: "yarn",
                      variant: "plain",
                      class: "text-none"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("yarn")
                      ]),
                      _: 1
                    }),
                    createVNode(_component_v_tab, {
                      value: "npm",
                      variant: "plain",
                      class: "text-none"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("npm")
                      ]),
                      _: 1
                    }),
                    createVNode(_component_v_tab, {
                      value: "pnpm",
                      variant: "plain",
                      class: "text-none"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("pnpm")
                      ]),
                      _: 1
                    }),
                    createVNode(_component_v_tab, {
                      value: "bun",
                      variant: "plain",
                      class: "text-none"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("bun")
                      ]),
                      _: 1
                    })
                  ]),
                  content: withCtx(() => [
                    createVNode(_component_v_window_item, { value: "yarn" }, {
                      default: withCtx(() => [
                        createVNode(_component_app_markup, {
                          resource: "",
                          class: "mb-4"
                        }, {
                          default: withCtx(() => [
                            _hoisted_5
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }),
                    createVNode(_component_v_window_item, { value: "npm" }, {
                      default: withCtx(() => [
                        createVNode(_component_app_markup, {
                          resource: "",
                          class: "mb-4"
                        }, {
                          default: withCtx(() => [
                            _hoisted_6
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }),
                    createVNode(_component_v_window_item, { value: "pnpm" }, {
                      default: withCtx(() => [
                        createVNode(_component_app_markup, {
                          resource: "",
                          class: "mb-4"
                        }, {
                          default: withCtx(() => [
                            _hoisted_7
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }),
                    createVNode(_component_v_window_item, { value: "bun" }, {
                      default: withCtx(() => [
                        createVNode(_component_app_markup, {
                          resource: "",
                          class: "mb-4"
                        }, {
                          default: withCtx(() => [
                            _hoisted_8
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("For additional details about css-pre-processors, please refer to the official vite page at: "),
                  createVNode(_component_app_link, { href: "https://vitejs.dev/guide/features.html#css-pre-processors" }, {
                    default: withCtx(() => [
                      createTextVNode("https://vitejs.dev/guide/features.html#css-pre-processors")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" or official vue-cli-page at: "),
                  createVNode(_component_app_link, { href: "https://cli.vuejs.org/guide/css.html#pre-processors" }, {
                    default: withCtx(() => [
                      createTextVNode("https://cli.vuejs.org/guide/css.html#pre-processors")
                    ]),
                    _: 1
                  })
                ])
              ]),
              createBaseVNode("section", _hoisted_9, [
                createVNode(_component_app_heading, {
                  href: "#basic-usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Basic usage")
                  ]),
                  _: 1
                }),
                _hoisted_10,
                createVNode(_component_app_markup, {
                  resource: "src/styles/main.scss",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_11
                  ]),
                  _: 1
                }),
                createVNode(_component_app_markup, {
                  resource: "src/plugins/vuetify.js",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_12
                  ]),
                  _: 1
                }),
                _hoisted_13,
                createVNode(_component_alert, { type: "warning" }, {
                  default: withCtx(() => [
                    createBaseVNode("p", null, [
                      _hoisted_14,
                      createTextVNode(" should not be used in sass files as it resolves to precompiled css ("),
                      createVNode(_component_app_link, { href: "https://github.com/vitejs/vite/issues/7809" }, {
                        default: withCtx(() => [
                          createTextVNode("vitejs/vite#7809")
                        ]),
                        _: 1
                      }),
                      createTextVNode("). "),
                      _hoisted_15,
                      createTextVNode(" and "),
                      _hoisted_16,
                      createTextVNode(" are valid and safe to use")
                    ])
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_17, [
                createVNode(_component_app_heading, {
                  href: "#component-specific-variables",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Component specific variables")
                  ]),
                  _: 1
                }),
                _hoisted_18,
                createBaseVNode("p", null, [
                  createTextVNode("Follow the plugin setup guide from "),
                  createVNode(_component_app_link, { href: "/features/treeshaking/" }, {
                    default: withCtx(() => [
                      createTextVNode("treeshaking")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" then add "),
                  _hoisted_19,
                  createTextVNode(" to the plugin options:")
                ]),
                createVNode(_component_app_markup, {
                  resource: "vite.config.js",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_20
                  ]),
                  _: 1
                }),
                createVNode(_component_app_markup, {
                  resource: "src/styles/settings.scss",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_21
                  ]),
                  _: 1
                }),
                _hoisted_22,
                _hoisted_23,
                _hoisted_24
              ]),
              createBaseVNode("section", _hoisted_25, [
                createVNode(_component_app_heading, {
                  href: "#variable-api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Variable API")
                  ]),
                  _: 1
                }),
                _hoisted_26,
                createVNode(_component_features_sass_api),
                _hoisted_27,
                createBaseVNode("p", null, [
                  createBaseVNode("div", null, [
                    createVNode(_component_app_figure, {
                      alt: "image",
                      src: "https://github.com/vuetifyjs/vuetify/assets/9064066/967da002-5a9e-4bce-8285-1fa9b849e36d",
                      title: "VBtn SASS Variables"
                    })
                  ])
                ])
              ]),
              createBaseVNode("section", _hoisted_28, [
                createVNode(_component_app_heading, {
                  href: "#usage-in-templates",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage in templates")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("You can access "),
                  createVNode(_component_app_link, { href: "/api/vuetify/" }, {
                    default: withCtx(() => [
                      createTextVNode("global")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" and per-component variables in Vue templates simply by importing the settings file:")
                ]),
                createVNode(_component_app_markup, {
                  resource: "Comp1.vue",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_29
                  ]),
                  _: 1
                }),
                _hoisted_30,
                createVNode(_component_app_markup, {
                  resource: "src/styles/settings.scss",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_31
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_32, [
                createVNode(_component_app_heading, {
                  href: "#disabling-utility-classes",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Disabling utility classes")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("Utility classes are a powerful feature of Vuetify, but they can also be unnecessary for some projects. Each utility class is generated with a set of options that are defined "),
                  createVNode(_component_app_link, { href: "https://github.com/vuetifyjs/vuetify/blob/master/packages/vuetify/src/styles/settings/_utilities.scss" }, {
                    default: withCtx(() => [
                      createTextVNode("here")
                    ]),
                    _: 1
                  }),
                  createTextVNode(". Disable individual classes by setting their corresponding variable to "),
                  _hoisted_33,
                  createTextVNode(":")
                ]),
                createVNode(_component_app_markup, {
                  resource: "src/styles/settings.scss",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_34
                  ]),
                  _: 1
                }),
                _hoisted_35,
                createVNode(_component_app_markup, {
                  resource: "src/styles/settings.scss",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_36
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_37, [
                createVNode(_component_app_heading, {
                  href: "#disabling-color-packs",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Disabling color packs")
                  ]),
                  _: 1
                }),
                _hoisted_38,
                createVNode(_component_app_markup, {
                  resource: "src/styles/settings.scss",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_39
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_40, [
                createVNode(_component_app_heading, {
                  href: "#enabling-css-cascade-layers",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Enabling CSS cascade layers")
                  ]),
                  _: 1
                }),
                createVNode(_component_alert, { type: "success" }, {
                  default: withCtx(() => [
                    createBaseVNode("p", null, [
                      createTextVNode("This feature was introduced in "),
                      createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v3.6.0" }, {
                        default: withCtx(() => [
                          createTextVNode("v3.6.0 (Nebula)")
                        ]),
                        _: 1
                      })
                    ])
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createVNode(_component_app_link, { href: "https://developer.mozilla.org/en-US/docs/Web/CSS/@layer" }, {
                    default: withCtx(() => [
                      createTextVNode("Cascade layers")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" are a modern CSS feature that makes it easier to write custom styles without having to deal with specificity issues and "),
                  _hoisted_41,
                  createTextVNode(". This will be included by default in Vuetify 4 but can optionally be used now:")
                ]),
                createVNode(_component_app_markup, {
                  resource: "src/styles/settings.scss",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_42
                  ]),
                  _: 1
                }),
                _hoisted_43,
                _hoisted_44,
                createVNode(_component_app_markup, {
                  resource: "src/styles/layers.css",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_45
                  ]),
                  _: 1
                }),
                _hoisted_46
              ]),
              createBaseVNode("section", _hoisted_47, [
                createVNode(_component_app_heading, {
                  href: "#caveats",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Caveats")
                  ]),
                  _: 1
                }),
                _hoisted_48,
                createBaseVNode("section", _hoisted_49, [
                  createVNode(_component_app_heading, {
                    href: "#duplicated-css",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Duplicated CSS")
                    ]),
                    _: 1
                  }),
                  _hoisted_50
                ]),
                createBaseVNode("section", _hoisted_51, [
                  createVNode(_component_app_heading, {
                    href: "#build-performance",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Build performance")
                    ]),
                    _: 1
                  }),
                  _hoisted_52
                ]),
                createBaseVNode("section", _hoisted_53, [
                  createVNode(_component_app_heading, {
                    href: "#symlinks",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Symlinks")
                    ]),
                    _: 1
                  }),
                  _hoisted_54
                ]),
                createBaseVNode("section", _hoisted_55, [
                  createVNode(_component_app_heading, {
                    href: "#sass-loader-with-api3a-27modern27",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("sass-loader with "),
                      _hoisted_56
                    ]),
                    _: 1
                  }),
                  _hoisted_57
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
