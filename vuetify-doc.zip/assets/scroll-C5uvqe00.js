import { A as useGoTo, J as ref, j as computed, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, b as createVNode, ap as withKeys, e as createBaseVNode, f as unref } from "./index-DGybHjCP.js";
const _hoisted_1 = {
  id: "goto-container-example",
  class: "overflow-auto",
  style: { "max-height": "400px" }
};
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("div", {
  id: "heading-1",
  class: "text-h5"
}, "Heading 1", -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("p", null, "Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!", -1);
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("div", { style: { "height": "420px" } }, null, -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("div", {
  id: "heading-2",
  class: "text-h5"
}, "Heading 2", -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("p", null, "Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!", -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("div", { style: { "height": "420px" } }, null, -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("div", {
  id: "heading-3",
  class: "text-h5"
}, "Heading 3", -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("p", null, "Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!", -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("div", { style: { "height": "420px" } }, null, -1);
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("div", {
  id: "heading-4",
  class: "text-h5"
}, "Heading 4", -1);
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("p", null, "Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!", -1);
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("div", { style: { "height": "180px" } }, null, -1);
const _sfc_main = {
  __name: "usage",
  setup(__props) {
    const goTo = useGoTo();
    const duration = ref(300);
    const number = ref(500);
    const offset = ref(0);
    const cards = {
      card1: ref(null),
      card2: ref(null),
      card3: ref(null),
      card4: ref(null)
    };
    const component = ref("card3");
    const components = [
      { title: "Card 1", value: "card1" },
      { title: "Card 2", value: "card2" },
      { title: "Card 3", value: "card3" },
      { title: "Card 4", value: "card4" }
    ];
    const query = ref("#heading-3");
    const queries = [
      "#heading-1",
      "#heading-2",
      "#heading-3",
      "#heading-4"
    ];
    const target = ref("By Number");
    const targets = [
      "By Number",
      "By Query Selector",
      "By Component / Element"
    ];
    const easing = ref("easeInOutCubic");
    const easings = [
      "linear",
      "easeInQuad",
      "easeOutQuad",
      "easeInOutQuad",
      "easeInCubic",
      "easeOutCubic",
      "easeInOutCubic",
      "easeInQuart",
      "easeOutQuart",
      "easeInOutQuart",
      "easeInQuint",
      "easeOutQuint",
      "easeInOutQuint"
    ];
    const options = computed(() => ({
      container: "#goto-container-example",
      duration: duration.value,
      easing: easing.value,
      offset: offset.value
    }));
    function onClick() {
      if (target.value === "By Number") {
        goTo(number.value, options.value);
      } else if (target.value === "By Query Selector") {
        goTo(query.value, options.value);
      } else if (target.value === "By Component / Element") {
        goTo(cards[component.value].$el, options.value);
      }
    }
    function onClickReset() {
      component.value = "card3";
      duration.value = 300;
      easing.value = "easeInOutCubic";
      number.value = 500;
      offset.value = 0;
      query.value = "#heading-3";
      target.value = "By Number";
      goTo(0, { container: "#goto-container-example" });
    }
    return (_ctx, _cache) => {
      const _component_v_select = resolveComponent("v-select");
      const _component_v_col = resolveComponent("v-col");
      const _component_v_text_field = resolveComponent("v-text-field");
      const _component_v_slider = resolveComponent("v-slider");
      const _component_v_divider = resolveComponent("v-divider");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_row = resolveComponent("v-row");
      const _component_v_container = resolveComponent("v-container");
      const _component_v_card = resolveComponent("v-card");
      const _component_v_sheet = resolveComponent("v-sheet");
      return openBlock(), createBlock(_component_v_sheet, {
        rounded: "b",
        border: ""
      }, {
        default: withCtx(() => [
          createVNode(_component_v_container, { fluid: "" }, {
            default: withCtx(() => [
              createVNode(_component_v_row, null, {
                default: withCtx(() => [
                  createVNode(_component_v_col, {
                    cols: "12",
                    md: "6"
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_v_select, {
                        modelValue: target.value,
                        "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => target.value = $event),
                        items: targets,
                        label: "Target",
                        "prepend-inner-icon": "mdi-bullseye",
                        variant: "outlined",
                        "hide-details": ""
                      }, null, 8, ["modelValue"])
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_col, {
                    cols: "12",
                    md: "6"
                  }, {
                    default: withCtx(() => [
                      target.value === "By Number" ? (openBlock(), createBlock(_component_v_text_field, {
                        key: 0,
                        modelValue: number.value,
                        "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => number.value = $event),
                        modelModifiers: { number: true },
                        label: "Number",
                        max: "2000",
                        min: "0",
                        "prepend-inner-icon": "mdi-numeric",
                        step: "1",
                        type: "number",
                        variant: "outlined",
                        "hide-details": "",
                        onKeydown: withKeys(onClick, ["enter"])
                      }, null, 8, ["modelValue"])) : target.value === "By Query Selector" ? (openBlock(), createBlock(_component_v_select, {
                        key: 1,
                        modelValue: query.value,
                        "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => query.value = $event),
                        items: queries,
                        label: "Query Selector",
                        "prepend-inner-icon": "mdi-format-header-1",
                        variant: "outlined",
                        "hide-details": ""
                      }, null, 8, ["modelValue"])) : (openBlock(), createBlock(_component_v_select, {
                        key: 2,
                        modelValue: component.value,
                        "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => component.value = $event),
                        items: components,
                        label: "Component / Element",
                        "prepend-inner-icon": "mdi-card-bulleted",
                        variant: "outlined",
                        "hide-details": ""
                      }, null, 8, ["modelValue"]))
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_col, {
                    cols: "12",
                    md: "6"
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_v_select, {
                        modelValue: easing.value,
                        "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => easing.value = $event),
                        items: easings,
                        label: "Easing",
                        "prepend-inner-icon": "mdi-sine-wave",
                        variant: "outlined",
                        "hide-details": ""
                      }, null, 8, ["modelValue"])
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_col, {
                    cols: "12",
                    md: "6"
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_v_text_field, {
                        modelValue: duration.value,
                        "onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => duration.value = $event),
                        modelModifiers: { number: true },
                        label: "Duration",
                        max: "2000",
                        min: "50",
                        "prepend-inner-icon": "mdi-timer-sand",
                        step: "1",
                        type: "number",
                        variant: "outlined",
                        "hide-details": ""
                      }, null, 8, ["modelValue"])
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_col, { cols: "12" }, {
                    default: withCtx(() => [
                      createVNode(_component_v_slider, {
                        modelValue: offset.value,
                        "onUpdate:modelValue": _cache[6] || (_cache[6] = ($event) => offset.value = $event),
                        "append-icon": "mdi-axis-arrow",
                        label: "Offset",
                        max: "100",
                        min: "-100",
                        step: "1",
                        "hide-details": "",
                        "thumb-label": ""
                      }, null, 8, ["modelValue"])
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_divider, { class: "my-3 mx-n1" }),
                  createVNode(_component_v_col, {
                    class: "mt-n2",
                    cols: "10"
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_v_btn, {
                        color: "surface-variant",
                        text: "Go To",
                        variant: "flat",
                        block: "",
                        onClick
                      })
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_col, {
                    class: "mt-n2",
                    cols: "2"
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_v_btn, {
                        color: "error",
                        text: "Reset",
                        variant: "outlined",
                        block: "",
                        onClick: onClickReset
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_divider),
          createBaseVNode("div", _hoisted_1, [
            createVNode(_component_v_sheet, {
              class: "pa-4",
              color: "surface-light"
            }, {
              default: withCtx(() => [
                _hoisted_2,
                _hoisted_3,
                _hoisted_4,
                createVNode(_component_v_card, {
                  ref: (instance) => cards.card1 = instance,
                  text: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem! Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!",
                  title: "Card 1",
                  flat: ""
                }, null, 512),
                _hoisted_5,
                _hoisted_6,
                _hoisted_7,
                _hoisted_8,
                createVNode(_component_v_card, {
                  ref: (instance) => cards.card2 = instance,
                  text: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem! Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!",
                  title: "Card 2",
                  flat: ""
                }, null, 512),
                _hoisted_9,
                _hoisted_10,
                _hoisted_11,
                _hoisted_12,
                createVNode(_component_v_card, {
                  ref: (instance) => cards.card3 = instance,
                  text: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem! Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!",
                  title: "Card 3",
                  flat: ""
                }, null, 512),
                _hoisted_13,
                _hoisted_14,
                _hoisted_15,
                _hoisted_16,
                createVNode(_component_v_card, {
                  ref: (instance) => cards.card4 = instance,
                  text: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem! Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!",
                  title: "Card 4",
                  flat: ""
                }, null, 512),
                _hoisted_17,
                createVNode(_component_v_btn, {
                  "append-icon": "mdi-arrow-up-bold",
                  text: "Back to Top",
                  variant: "tonal",
                  onClick: _cache[7] || (_cache[7] = ($event) => unref(goTo)(0, { container: "#goto-container-example" }))
                })
              ]),
              _: 1
            })
          ])
        ]),
        _: 1
      });
    };
  }
};
const __0 = _sfc_main;
const __0_raw = `<template>
  <v-sheet rounded="b" border>
    <v-container fluid>
      <v-row>
        <v-col cols="12" md="6">
          <v-select
            v-model="target"
            :items="targets"
            label="Target"
            prepend-inner-icon="mdi-bullseye"
            variant="outlined"
            hide-details
          ></v-select>
        </v-col>

        <v-col cols="12" md="6">
          <v-text-field
            v-if="target === 'By Number'"
            v-model.number="number"
            label="Number"
            max="2000"
            min="0"
            prepend-inner-icon="mdi-numeric"
            step="1"
            type="number"
            variant="outlined"
            hide-details
            @keydown.enter="onClick"
          ></v-text-field>

          <v-select
            v-else-if="target === 'By Query Selector'"
            v-model="query"
            :items="queries"
            label="Query Selector"
            prepend-inner-icon="mdi-format-header-1"
            variant="outlined"
            hide-details
          ></v-select>

          <v-select
            v-else
            v-model="component"
            :items="components"
            label="Component / Element"
            prepend-inner-icon="mdi-card-bulleted"
            variant="outlined"
            hide-details
          ></v-select>
        </v-col>

        <v-col cols="12" md="6">
          <v-select
            v-model="easing"
            :items="easings"
            label="Easing"
            prepend-inner-icon="mdi-sine-wave"
            variant="outlined"
            hide-details
          ></v-select>
        </v-col>

        <v-col cols="12" md="6">
          <v-text-field
            v-model.number="duration"
            label="Duration"
            max="2000"
            min="50"
            prepend-inner-icon="mdi-timer-sand"
            step="1"
            type="number"
            variant="outlined"
            hide-details
          ></v-text-field>
        </v-col>

        <v-col cols="12">
          <v-slider
            v-model="offset"
            append-icon="mdi-axis-arrow"
            label="Offset"
            max="100"
            min="-100"
            step="1"
            hide-details
            thumb-label
          ></v-slider>
        </v-col>

        <v-divider class="my-3 mx-n1"></v-divider>

        <v-col class="mt-n2" cols="10">
          <v-btn
            color="surface-variant"
            text="Go To"
            variant="flat"
            block
            @click="onClick"
          ></v-btn>
        </v-col>

        <v-col class="mt-n2" cols="2">
          <v-btn
            color="error"
            text="Reset"
            variant="outlined"
            block
            @click="onClickReset"
          ></v-btn>
        </v-col>
      </v-row>
    </v-container>

    <v-divider></v-divider>

    <div
      id="goto-container-example"
      class="overflow-auto"
      style="max-height: 400px;"
    >
      <v-sheet
        class="pa-4"
        color="surface-light"
      >
        <div id="heading-1" class="text-h5">Heading 1</div>

        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!</p>

        <br>

        <v-card
          :ref="instance => cards.card1 = instance"
          text="Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem! Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!"
          title="Card 1"
          flat
        ></v-card>

        <div style="height: 420px;"></div>

        <div id="heading-2" class="text-h5">Heading 2</div>

        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!</p>

        <br>

        <v-card
          :ref="instance => cards.card2 = instance"
          text="Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem! Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!"
          title="Card 2"
          flat
        ></v-card>

        <div style="height: 420px;"></div>

        <div id="heading-3" class="text-h5">Heading 3</div>

        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!</p>

        <br>

        <v-card
          :ref="instance => cards.card3 = instance"
          text="Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem! Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!"
          title="Card 3"
          flat
        ></v-card>

        <div style="height: 420px;"></div>

        <div id="heading-4" class="text-h5">Heading 4</div>

        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!</p>

        <br>

        <v-card
          :ref="instance => cards.card4 = instance"
          text="Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem! Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!"
          title="Card 4"
          flat
        ></v-card>

        <div style="height: 180px;"></div>

        <v-btn
          append-icon="mdi-arrow-up-bold"
          text="Back to Top"
          variant="tonal"
          @click="goTo(0, { container: '#goto-container-example' })"
        ></v-btn>
      </v-sheet>
    </div>
  </v-sheet>
</template>

<script setup>
  import { computed, ref } from 'vue'
  import { useGoTo } from 'vuetify'

  const goTo = useGoTo()

  const duration = ref(300)
  const number = ref(500)
  const offset = ref(0)
  const cards = {
    card1: ref(null),
    card2: ref(null),
    card3: ref(null),
    card4: ref(null),
  }
  const component = ref('card3')
  const components = [
    { title: 'Card 1', value: 'card1' },
    { title: 'Card 2', value: 'card2' },
    { title: 'Card 3', value: 'card3' },
    { title: 'Card 4', value: 'card4' },
  ]
  const query = ref('#heading-3')
  const queries = [
    '#heading-1',
    '#heading-2',
    '#heading-3',
    '#heading-4',
  ]
  const target = ref('By Number')
  const targets = [
    'By Number',
    'By Query Selector',
    'By Component / Element',
  ]
  const easing = ref('easeInOutCubic')
  const easings = [
    'linear',
    'easeInQuad',
    'easeOutQuad',
    'easeInOutQuad',
    'easeInCubic',
    'easeOutCubic',
    'easeInOutCubic',
    'easeInQuart',
    'easeOutQuart',
    'easeInOutQuart',
    'easeInQuint',
    'easeOutQuint',
    'easeInOutQuint',
  ]

  const options = computed(() => ({
    container: '#goto-container-example',
    duration: duration.value,
    easing: easing.value,
    offset: offset.value,
  }))

  function onClick () {
    if (target.value === 'By Number') {
      goTo(number.value, options.value)
    } else if (target.value === 'By Query Selector') {
      goTo(query.value, options.value)
    } else if (target.value === 'By Component / Element') {
      goTo(cards[component.value].$el, options.value)
    }
  }

  function onClickReset () {
    component.value = 'card3'
    duration.value = 300
    easing.value = 'easeInOutCubic'
    number.value = 500
    offset.value = 0
    query.value = '#heading-3'
    target.value = 'By Number'

    goTo(0, { container: '#goto-container-example' })
  }
<\/script>

<script>
  import { useGoTo } from 'vuetify'

  export default {
    setup () {
      const goTo = useGoTo()
      return { goTo }
    },
    data () {
      return {
        duration: 300,
        number: 500,
        offset: 0,
        cards: {
          card1: null,
          card2: null,
          card3: null,
          card4: null,
        },
        component: 'card3',
        components: [
          { title: 'Card 1', value: 'card1' },
          { title: 'Card 2', value: 'card2' },
          { title: 'Card 3', value: 'card3' },
          { title: 'Card 4', value: 'card4' },
        ],
        query: '#heading-3',
        queries: [
          '#heading-1',
          '#heading-2',
          '#heading-3',
          '#heading-4',
        ],
        target: 'By Number',
        targets: [
          'By Number',
          'By Query Selector',
          'By Component / Element',
        ],
        easing: 'easeInOutCubic',
        easings: [
          'linear',
          'easeInQuad',
          'easeOutQuad',
          'easeInOutQuad',
          'easeInCubic',
          'easeOutCubic',
          'easeInOutCubic',
          'easeInQuart',
          'easeOutQuart',
          'easeInOutQuart',
          'easeInQuint',
          'easeOutQuint',
          'easeInOutQuint',
        ],
      }
    },
    computed: {
      options () {
        return {
          container: '#goto-container-example',
          duration: this.duration,
          easing: this.easing,
          offset: this.offset,
        }
      },
    },
    methods: {
      onClick () {
        if (this.target === 'By Number') {
          this.goTo(this.number, this.options)
        } else if (this.target === 'By Query Selector') {
          this.goTo(this.query, this.options)
        } else if (this.target === 'By Component / Element') {
          this.goTo(this.cards[this.component].$el, this.options)
        }
      },
      onClickReset () {
        this.component = 'card3'
        this.duration = 300
        this.easing = 'easeInOutCubic'
        this.number = 500
        this.offset = 0
        this.query = '#heading-3'
        this.target = 'By Number'

        this.goTo(0, { container: '#goto-container-example' })
      },
    },
  }
<\/script>
`;
const scroll = {
  "usage": {
    component: __0,
    source: __0_raw
  }
};
export {
  scroll as default
};
