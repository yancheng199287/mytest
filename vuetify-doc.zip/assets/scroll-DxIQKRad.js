import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "scroll-directive" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-scroll"),
  /* @__PURE__ */ createTextVNode(" directive allows you to provide callbacks when the window, specified target or element itself (with "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".self"),
  /* @__PURE__ */ createTextVNode(" modifier) is scrolled.")
], -1);
const _hoisted_3 = { id: "api" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Directive"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("td", null, "The scroll directive", -1);
const _hoisted_6 = { id: "examples" };
const _hoisted_7 = { id: "options" };
const _hoisted_8 = { id: "self" };
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-scroll", -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "window", -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("strong", null, "self", -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-scroll.self", -1);
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-card", -1);
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "onScroll", -1);
const _hoisted_15 = { id: "target" };
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("p", null, "For a more fine tuned approach, you can designate the target to bind the scroll event listener.", -1);
const frontmatter = { "meta": { "nav": "Scroll", "title": "Scroll directive", "description": "The scroll directive gives you the ability to conditionally invoke methods when the screen or an element are scrolled.", "keywords": "scroll, vuetify scroll directive, vue scroll directive, window scroll directive" }, "related": ["/components/app-bars/", "/components/bottom-navigation/", "/directives/touch/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "scroll",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Scroll", "title": "Scroll directive", "description": "The scroll directive gives you the ability to conditionally invoke methods when the screen or an element are scrolled.", "keywords": "scroll, vuetify scroll directive, vue scroll directive, window scroll directive" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Scroll", "title": "Scroll directive", "description": "The scroll directive gives you the ability to conditionally invoke methods when the screen or an element are scrolled.", "keywords": "scroll, vuetify scroll directive, vue scroll directive, window scroll directive" }, "related": ["/components/app-bars/", "/components/bottom-navigation/", "/directives/touch/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#scroll-directive",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Scroll directive")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_promoted_entry),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_4,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-scroll-directive/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-scroll")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_5
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_6, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_7, [
                  createVNode(_component_app_heading, {
                    href: "#options",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Options")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_8, [
                    createVNode(_component_app_heading, {
                      href: "#self",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Self")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      _hoisted_9,
                      createTextVNode(" targets the "),
                      _hoisted_10,
                      createTextVNode(" by default but can also watch the element it’s being bound to. In the following example we use the "),
                      _hoisted_11,
                      createTextVNode(" modifier, "),
                      _hoisted_12,
                      createTextVNode(", to watch the "),
                      createVNode(_component_app_link, { href: "/components/cards" }, {
                        default: withCtx(() => [
                          _hoisted_13
                        ]),
                        _: 1
                      }),
                      createTextVNode(" element specifically. This causes the method "),
                      _hoisted_14,
                      createTextVNode(" to invoke as you scroll the card contents; incrementing the counter.")
                    ]),
                    createVNode(_component_examples_example, { file: "v-scroll/option-self" })
                  ]),
                  createBaseVNode("section", _hoisted_15, [
                    createVNode(_component_app_heading, {
                      href: "#target",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Target")
                      ]),
                      _: 1
                    }),
                    _hoisted_16,
                    createVNode(_component_examples_example, { file: "v-scroll/option-target" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
