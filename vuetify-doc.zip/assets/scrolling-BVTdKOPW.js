import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "programmatic-scrolling" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Handle scrolling within your application by using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "goTo"),
  /* @__PURE__ */ createTextVNode(" function.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "goTo"),
  /* @__PURE__ */ createTextVNode(" method takes two parameters "),
  /* @__PURE__ */ createBaseVNode("strong", null, "target"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "options"),
  /* @__PURE__ */ createTextVNode(". "),
  /* @__PURE__ */ createBaseVNode("strong", null, "target"),
  /* @__PURE__ */ createTextVNode(" can be either a pixel offset from the top of the page, a valid css selector, or an element reference. "),
  /* @__PURE__ */ createBaseVNode("strong", null, "options"),
  /* @__PURE__ */ createTextVNode(" is an object that includes "),
  /* @__PURE__ */ createBaseVNode("strong", null, "duration"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "easing"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "container"),
  /* @__PURE__ */ createTextVNode(", and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "offset"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_5 = { id: "api" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Directive"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "The useGoTo composable", -1);
const frontmatter = { "emphasized": true, "meta": { "title": "Programmatic scrolling", "description": "Handle scrolling within your application by using the goTo function", "keywords": "programmatic scrolling, vuetify goto, goto" }, "related": ["/directives/scroll/", "/features/application-layout/", "/components/slide-groups/"], "features": { "github": "/composables/goto.ts", "label": "E: goto", "report": true } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "scrolling",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "Programmatic scrolling", "description": "Handle scrolling within your application by using the goTo function", "keywords": "programmatic scrolling, vuetify goto, goto" } };
    useHead(head);
    __expose({ frontmatter: { "emphasized": true, "meta": { "title": "Programmatic scrolling", "description": "Handle scrolling within your application by using the goTo function", "keywords": "programmatic scrolling, vuetify goto, goto" }, "related": ["/directives/scroll/", "/features/application-layout/", "/components/slide-groups/"], "features": { "github": "/composables/goto.ts", "label": "E: goto", "report": true } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_alert = resolveComponent("alert");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#programmatic-scrolling",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Programmatic scrolling")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_promoted_entry),
              createVNode(_component_alert, { type: "success" }, {
                default: withCtx(() => [
                  createBaseVNode("p", null, [
                    createTextVNode("This feature was introduced in "),
                    createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v3.5.0" }, {
                      default: withCtx(() => [
                        createTextVNode("v3.5.0 (Polaris)")
                      ]),
                      _: 1
                    })
                  ])
                ]),
                _: 1
              }),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_example, { file: "scroll/usage" })
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_6,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/use-go-to/" }, {
                            default: withCtx(() => [
                              createTextVNode("useGoTo")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
