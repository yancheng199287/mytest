import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "search-engine" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "Add Vuetify as a browser search engine for quick access to the documentation.", -1);
const _hoisted_3 = { id: "setup" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, "The Vuetify documentation supports being a search engine for your browser. This allows you to query directly from the url bar without having to navigate to the site first. To add Vuetify as a search engine, follow the steps below:", -1);
const _hoisted_5 = { id: "for-chrome" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("li", null, "Enter the following information into the “Add search engine” dialog:", -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", { class: "ms-4" }, [
    /* @__PURE__ */ createTextVNode("Search engine: "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "Vuetify")
  ]),
  /* @__PURE__ */ createBaseVNode("li", { class: "ms-4" }, [
    /* @__PURE__ */ createTextVNode("Shortcut: "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "vt"),
    /* @__PURE__ */ createTextVNode(" (or whatever you prefer)")
  ]),
  /* @__PURE__ */ createBaseVNode("li", { class: "ms-4" }, [
    /* @__PURE__ */ createTextVNode("URL with %s in place of query: "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "https://vuetifyjs.com/?search=%s")
  ])
], -1);
const _hoisted_8 = { start: "5" };
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "vt", -1);
const _hoisted_10 = { id: "for-edge" };
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("li", null, "Entry the following information into the “Add search engine” dialog:", -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", { class: "ms-4" }, [
    /* @__PURE__ */ createTextVNode("Search engine: "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "Vuetify")
  ]),
  /* @__PURE__ */ createBaseVNode("li", { class: "ms-4" }, [
    /* @__PURE__ */ createTextVNode("Shortcut: "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "vt"),
    /* @__PURE__ */ createTextVNode(" (or whatever you prefer)")
  ]),
  /* @__PURE__ */ createBaseVNode("li", { class: "ms-4" }, [
    /* @__PURE__ */ createTextVNode("URL with %s in place of query: "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "https://vuetifyjs.com/?search=%s")
  ])
], -1);
const _hoisted_13 = { start: "5" };
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "vt", -1);
const frontmatter = { "meta": { "title": "Search Engine", "description": "Add Vuetify as a search engine to your Chrome browser for quick access to the documentation", "keywords": "search engine, vuetify search engine, vuetify chrome search engine, vuetify chrome extension" }, "related": ["/getting-started/quick-start/", "/getting-started/why-vuetify/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "search-engine",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "Search Engine", "description": "Add Vuetify as a search engine to your Chrome browser for quick access to the documentation", "keywords": "search engine, vuetify search engine, vuetify chrome search engine, vuetify chrome extension" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "title": "Search Engine", "description": "Add Vuetify as a search engine to your Chrome browser for quick access to the documentation", "keywords": "search engine, vuetify search engine, vuetify chrome search engine, vuetify chrome extension" }, "related": ["/getting-started/quick-start/", "/getting-started/why-vuetify/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_figure = resolveComponent("app-figure");
      const _component_v_kbd = resolveComponent("v-kbd");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#search-engine",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Search engine")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_promoted_entry),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#setup",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Setup")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createBaseVNode("section", _hoisted_5, [
                  createVNode(_component_app_heading, {
                    href: "#for-chrome",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("For Chrome")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("ol", null, [
                    createBaseVNode("li", null, [
                      createTextVNode("Open Chrome settings "),
                      createBaseVNode("div", null, [
                        createVNode(_component_app_figure, {
                          alt: "image",
                          src: "https://github.com/vuetifyjs/vuetify/assets/9064066/3b83a0a1-a51d-4c88-bf1b-0200a1f6b532"
                        })
                      ])
                    ]),
                    createBaseVNode("li", null, [
                      createTextVNode("Search for “Manage search engines and site search” "),
                      createBaseVNode("div", null, [
                        createVNode(_component_app_figure, {
                          alt: "search",
                          src: "https://github.com/vuetifyjs/vuetify/assets/9064066/8fd8f1e4-ebed-4c8a-9444-16163c580a60"
                        })
                      ])
                    ]),
                    createBaseVNode("li", null, [
                      createTextVNode("Scroll down to “Site search” and click the "),
                      createVNode(_component_v_kbd, null, {
                        default: withCtx(() => [
                          createTextVNode("Add")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" button to add a new search engine "),
                      createBaseVNode("div", null, [
                        createVNode(_component_app_figure, {
                          alt: "image",
                          src: "https://github.com/vuetifyjs/vuetify/assets/9064066/87d7775f-0f92-4f12-b9dd-01195f80df31"
                        })
                      ])
                    ]),
                    _hoisted_6
                  ]),
                  _hoisted_7,
                  createBaseVNode("ol", _hoisted_8, [
                    createBaseVNode("li", null, [
                      createTextVNode("Hit the "),
                      createVNode(_component_v_kbd, null, {
                        default: withCtx(() => [
                          createTextVNode("Add")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" button to save the search engine")
                    ]),
                    createBaseVNode("li", null, [
                      createTextVNode("Open your browster and type "),
                      _hoisted_9,
                      createTextVNode(" into the url bar followed by a space or tab: "),
                      createBaseVNode("div", null, [
                        createVNode(_component_app_figure, {
                          alt: "image",
                          src: "https://github.com/vuetifyjs/vuetify/assets/9064066/07869a65-bcc4-44c2-a900-3f69eea1be4b"
                        })
                      ])
                    ]),
                    createBaseVNode("li", null, [
                      createTextVNode("Type your search query and hit enter to search the Vuetify documentation "),
                      createBaseVNode("div", null, [
                        createVNode(_component_app_figure, {
                          alt: "image",
                          src: "https://github.com/vuetifyjs/vuetify/assets/9064066/e91092f4-f308-4ed4-9b4a-33ac189aec19"
                        })
                      ])
                    ])
                  ])
                ]),
                createBaseVNode("section", _hoisted_10, [
                  createVNode(_component_app_heading, {
                    href: "#for-edge",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("For Edge")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("ol", null, [
                    createBaseVNode("li", null, [
                      createTextVNode("Open Edge Settings "),
                      createBaseVNode("div", null, [
                        createVNode(_component_app_figure, {
                          alt: "step1",
                          src: "https://github.com/vuetifyjs/vuetify/assets/9064066/696182cf-5eab-4229-a007-5521186f8058"
                        })
                      ])
                    ]),
                    createBaseVNode("li", null, [
                      createTextVNode("Search for “Address bar and search” "),
                      createBaseVNode("div", null, [
                        createVNode(_component_app_figure, {
                          alt: "edge-search",
                          src: "https://github.com/vuetifyjs/vuetify/assets/9064066/9b9487c3-34d6-44b4-81e2-45ba30da2977"
                        })
                      ])
                    ]),
                    createBaseVNode("li", null, [
                      createTextVNode("Click the "),
                      createVNode(_component_v_kbd, null, {
                        default: withCtx(() => [
                          createTextVNode("Add")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" button to add a new search engine "),
                      createBaseVNode("div", null, [
                        createVNode(_component_app_figure, {
                          alt: "step2",
                          src: "https://github.com/vuetifyjs/vuetify/assets/9064066/eb50602a-bb6d-4933-92cd-e4f0edbc8a86"
                        })
                      ])
                    ]),
                    _hoisted_11
                  ]),
                  _hoisted_12,
                  createBaseVNode("p", null, [
                    createBaseVNode("div", null, [
                      createVNode(_component_app_figure, {
                        alt: "add search engine",
                        src: "https://github.com/vuetifyjs/vuetify/assets/9064066/8b31e827-5b16-4ba8-b220-bcbe139986ff"
                      })
                    ])
                  ]),
                  createBaseVNode("ol", _hoisted_13, [
                    createBaseVNode("li", null, [
                      createTextVNode("Hit the "),
                      createVNode(_component_v_kbd, null, {
                        default: withCtx(() => [
                          createTextVNode("Add")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" button to save the search engine")
                    ]),
                    createBaseVNode("li", null, [
                      createTextVNode("Open your browster and type "),
                      _hoisted_14,
                      createTextVNode(" into the url bar followed by a space or tab: "),
                      createBaseVNode("div", null, [
                        createVNode(_component_app_figure, {
                          alt: "search bar",
                          src: "https://github.com/vuetifyjs/vuetify/assets/9064066/59311829-e564-4c80-a0c9-d33e7aacfd21"
                        })
                      ])
                    ]),
                    createBaseVNode("li", null, [
                      createTextVNode("Type your search query and hit enter to search the Vuetify documentation "),
                      createBaseVNode("div", null, [
                        createVNode(_component_app_figure, {
                          alt: "step5",
                          src: "https://github.com/vuetifyjs/vuetify/assets/9064066/8245afd9-bceb-41dd-8310-50e4137d1fca"
                        })
                      ])
                    ])
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
