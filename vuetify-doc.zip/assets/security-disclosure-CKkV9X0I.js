import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "security-disclosure-procedures" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "This document outlines security procedures and general policies for the Vuetify project.", -1);
const _hoisted_3 = { id: "reporting-a-bug" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, "The Vuetify team and community take all security bugs in Vuetify seriously. We appreciate your efforts and responsible disclosure and will make every effort to acknowledge your contributions.", -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("strong", null, '"SECURITY"', -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("p", null, "The Vuetify team will send a response indicating the next steps in handling your report. After the initial reply to your report, the security team will keep you informed of the progress towards a fix and full announcement, and may ask for additional information or guidance.", -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("p", null, "Report security bugs in third-party modules to the person or team maintaining the module.", -1);
const _hoisted_8 = { id: "disclosure-policy" };
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("p", null, "When the security team receives a security bug report, they will assign it to a primary handler. This person will coordinate the fix and release process, involving the following steps:", -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, "Confirm the problem and determine the affected versions."),
  /* @__PURE__ */ createBaseVNode("li", null, "Audit code to find any potential similar problems."),
  /* @__PURE__ */ createBaseVNode("li", null, "Prepare fixes for all releases still under maintenance.These fixes will be released as fast as possible to npm.")
], -1);
const _hoisted_11 = { id: "comments-on-this-policy" };
const frontmatter = { "meta": { "nav": "Security disclosure", "title": "Security disclosure procedures", "description": "This document outlines security procedures and general policies for the Vuetify project.", "keywords": "security, security vulnerability, disclosure policy, security disclosure" }, "related": ["/introduction/enterprise-support/", "/getting-started/contributing/", "/introduction/long-term-support/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "security-disclosure",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Security disclosure", "title": "Security disclosure procedures", "description": "This document outlines security procedures and general policies for the Vuetify project.", "keywords": "security, security vulnerability, disclosure policy, security disclosure" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Security disclosure", "title": "Security disclosure procedures", "description": "This document outlines security procedures and general policies for the Vuetify project.", "keywords": "security, security vulnerability, disclosure policy, security disclosure" }, "related": ["/introduction/enterprise-support/", "/getting-started/contributing/", "/introduction/long-term-support/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_promoted_promoted = resolveComponent("promoted-promoted");
      const _component_app_link = resolveComponent("app-link");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#security-disclosure-procedures",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Security disclosure procedures")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_promoted_promoted, { slug: "enterprise-support" }),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#reporting-a-bug",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Reporting a Bug")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createBaseVNode("p", null, [
                  createTextVNode("To report a security issue, email "),
                  createVNode(_component_app_link, { href: "mailto:security@vuetifyjs.com?subject=SECURITY" }, {
                    default: withCtx(() => [
                      createTextVNode("security@vuetifyjs.com")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" and include the word "),
                  _hoisted_5,
                  createTextVNode(" in the subject line.")
                ]),
                _hoisted_6,
                _hoisted_7
              ]),
              createBaseVNode("section", _hoisted_8, [
                createVNode(_component_app_heading, {
                  href: "#disclosure-policy",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Disclosure Policy")
                  ]),
                  _: 1
                }),
                _hoisted_9,
                _hoisted_10
              ]),
              createBaseVNode("section", _hoisted_11, [
                createVNode(_component_app_heading, {
                  href: "#comments-on-this-policy",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Comments on this Policy")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("If you have suggestions on how this process could be improved please submit a pull request using the "),
                  createVNode(_component_app_link, { href: "https://issues.vuetifyjs.com" }, {
                    default: withCtx(() => [
                      createTextVNode("issue creator")
                    ]),
                    _: 1
                  }),
                  createTextVNode(".")
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
