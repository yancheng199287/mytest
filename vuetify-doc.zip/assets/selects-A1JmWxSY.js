import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "selects" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "Select fields components are used for collecting user provided information from a list of options.", -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = { id: "api" };
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "A select component that allows for advanced filtering", -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("td", null, "A select component that allows for filtering and custom values", -1);
const _hoisted_9 = { id: "caveats" };
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("When using objects for the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "items"),
  /* @__PURE__ */ createTextVNode(" prop, you must associate "),
  /* @__PURE__ */ createBaseVNode("strong", null, "item-title"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "item-value"),
  /* @__PURE__ */ createTextVNode(" with existing properties on your objects. These values are defaulted to "),
  /* @__PURE__ */ createBaseVNode("strong", null, "title"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "value"),
  /* @__PURE__ */ createTextVNode(" and can be changed.")
], -1);
const _hoisted_11 = { id: "guide" };
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-select", -1);
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<select>", -1);
const _hoisted_14 = { id: "props" };
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("p", null, "All form inputs have a massive API that make it super easy to configure everything just the way you want it.", -1);
const _hoisted_16 = { id: "density" };
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can use "),
  /* @__PURE__ */ createBaseVNode("strong", null, "density"),
  /* @__PURE__ */ createTextVNode(" prop to adjust vertical spacing within the component.")
], -1);
const _hoisted_18 = { id: "multiple" };
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "multiple"),
  /* @__PURE__ */ createTextVNode(" prop allows for multiple selections.")
], -1);
const _hoisted_20 = { id: "chips" };
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Display selected items as chips with the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "chips"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_22 = { id: "readonly" };
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can use the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "readonly"),
  /* @__PURE__ */ createTextVNode(" prop on "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-select"),
  /* @__PURE__ */ createTextVNode(" which will prevent a user from changing its value.")
], -1);
const _hoisted_24 = { id: "disabled" };
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Applying the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "disabled"),
  /* @__PURE__ */ createTextVNode(" prop to a "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-select"),
  /* @__PURE__ */ createTextVNode(" will prevent a user from interacting with the component.")
], -1);
const _hoisted_26 = { id: "custom-title-and-value" };
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can specify the specific properties within your items array that correspond to the title and value fields. By default, this is "),
  /* @__PURE__ */ createBaseVNode("strong", null, "title"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "value"),
  /* @__PURE__ */ createTextVNode(". In this example we also use the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "return-object"),
  /* @__PURE__ */ createTextVNode(" prop which will return the entire object of the selected item on selection.")
], -1);
const _hoisted_28 = { id: "custom-item-props" };
const _hoisted_29 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "item-title"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "item-value"),
  /* @__PURE__ */ createTextVNode(" are provided for convenience, and additional props can be passed to list items either through the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "item"),
  /* @__PURE__ */ createTextVNode(" slot (see below) or with the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "itemProps"),
  /* @__PURE__ */ createTextVNode(" prop. Similar to title and value, it has a default value of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, '"props"'),
  /* @__PURE__ */ createTextVNode(", which will pass everything in the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "props"),
  /* @__PURE__ */ createTextVNode(" key of each item object to the list item.")
], -1);
const _hoisted_30 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-js" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-js" }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "const"),
    /* @__PURE__ */ createTextVNode(" items "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "="),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "["),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "title"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'John'"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "props"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "subtitle"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'Engineering'"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "]"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_31 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ':item-props="true"'),
  /* @__PURE__ */ createTextVNode(" will use the entire item object as props. This overrides "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "item-title"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "item-value"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_32 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-js" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-js" }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "const"),
    /* @__PURE__ */ createTextVNode(" items "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "="),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "["),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "title"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'John'"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "subtitle"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'Engineering'"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "]"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_33 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Or a custom transform function can be passed to "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "itemProps"),
  /* @__PURE__ */ createTextVNode(" to generate the props for each item.")
], -1);
const _hoisted_34 = { id: "slots" };
const _hoisted_35 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-select"),
  /* @__PURE__ */ createTextVNode(" component offers slots that make it easy to customize the output of certain parts of the component. This includes the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "prepend"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "append"),
  /* @__PURE__ */ createTextVNode(" slots, the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "selection"),
  /* @__PURE__ */ createTextVNode(" slot, and the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "no-data"),
  /* @__PURE__ */ createTextVNode(" slot.")
], -1);
const _hoisted_36 = { id: "item" };
const _hoisted_37 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "item", -1);
const _hoisted_38 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "props", -1);
const _hoisted_39 = { id: "append-and-prepend-item" };
const _hoisted_40 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-select"),
  /* @__PURE__ */ createTextVNode(" component can be optionally expanded with prepended and appended items. This is perfect for customized "),
  /* @__PURE__ */ createBaseVNode("strong", null, "select-all"),
  /* @__PURE__ */ createTextVNode(" functionality.")
], -1);
const _hoisted_41 = { id: "selection" };
const _hoisted_42 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "selection"),
  /* @__PURE__ */ createTextVNode(" slot can be used to customize the way selected values are shown in the input. This is great when you don’t want the selection to occupy multiple lines.")
], -1);
const frontmatter = { "meta": { "nav": "Selects", "title": "Select component", "description": "The select component provides a list of options that a user can make selections from.", "keywords": "selects, vuetify select component, vue select component" }, "related": ["/components/autocompletes/", "/components/combobox/", "/components/forms/"], "features": { "label": "C: VSelect", "report": true, "github": "/components/VSelect/", "spec": "https://m2.material.io/components/text-fields" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "selects",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Selects", "title": "Select component", "description": "The select component provides a list of options that a user can make selections from.", "keywords": "selects, vuetify select component, vue select component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Selects", "title": "Select component", "description": "The select component provides a list of options that a user can make selections from.", "keywords": "selects, vuetify select component, vue select component" }, "related": ["/components/autocompletes/", "/components/combobox/", "/components/forms/"], "features": { "label": "C: VSelect", "report": true, "github": "/components/VSelect/", "spec": "https://m2.material.io/components/text-fields" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_alert = resolveComponent("alert");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_app_markup = resolveComponent("app-markup");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#selects",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Selects")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                createVNode(_component_examples_usage, { name: "v-select" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_4, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_5,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-select/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-select")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_6
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-autocomplete/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-autocomplete")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-combobox/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-combobox")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_8
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_9, [
                createVNode(_component_app_heading, {
                  href: "#caveats",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Caveats")
                  ]),
                  _: 1
                }),
                createVNode(_component_alert, { type: "error" }, {
                  default: withCtx(() => [
                    _hoisted_10
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_11, [
                createVNode(_component_app_heading, {
                  href: "#guide",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Guide")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("The "),
                  _hoisted_12,
                  createTextVNode(" component is meant to be a direct replacement for a standard "),
                  _hoisted_13,
                  createTextVNode(" element. It is commonly used with "),
                  createVNode(_component_app_link, { href: "/components/forms/" }, {
                    default: withCtx(() => [
                      createTextVNode("v-form")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" and other inputs & controls.")
                ]),
                createBaseVNode("section", _hoisted_14, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  _hoisted_15,
                  createBaseVNode("section", _hoisted_16, [
                    createVNode(_component_app_heading, {
                      href: "#density",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Density")
                      ]),
                      _: 1
                    }),
                    _hoisted_17,
                    createVNode(_component_examples_example, { file: "v-select/prop-dense" })
                  ]),
                  createBaseVNode("section", _hoisted_18, [
                    createVNode(_component_app_heading, {
                      href: "#multiple",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Multiple")
                      ]),
                      _: 1
                    }),
                    _hoisted_19,
                    createVNode(_component_examples_example, { file: "v-select/prop-multiple" })
                  ]),
                  createBaseVNode("section", _hoisted_20, [
                    createVNode(_component_app_heading, {
                      href: "#chips",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Chips")
                      ]),
                      _: 1
                    }),
                    _hoisted_21,
                    createVNode(_component_examples_example, { file: "v-select/prop-chips" })
                  ]),
                  createBaseVNode("section", _hoisted_22, [
                    createVNode(_component_app_heading, {
                      href: "#readonly",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Readonly")
                      ]),
                      _: 1
                    }),
                    _hoisted_23,
                    createVNode(_component_examples_example, { file: "v-select/prop-readonly" })
                  ]),
                  createBaseVNode("section", _hoisted_24, [
                    createVNode(_component_app_heading, {
                      href: "#disabled",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Disabled")
                      ]),
                      _: 1
                    }),
                    _hoisted_25,
                    createVNode(_component_examples_example, { file: "v-select/prop-disabled" })
                  ]),
                  createBaseVNode("section", _hoisted_26, [
                    createVNode(_component_app_heading, {
                      href: "#custom-title-and-value",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Custom title and value")
                      ]),
                      _: 1
                    }),
                    _hoisted_27,
                    createVNode(_component_examples_example, { file: "v-select/prop-custom-title-and-value" })
                  ]),
                  createBaseVNode("section", _hoisted_28, [
                    createVNode(_component_app_heading, {
                      href: "#custom-item-props",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Custom item props")
                      ]),
                      _: 1
                    }),
                    _hoisted_29,
                    createVNode(_component_app_markup, {
                      resource: "",
                      class: "mb-4"
                    }, {
                      default: withCtx(() => [
                        _hoisted_30
                      ]),
                      _: 1
                    }),
                    _hoisted_31,
                    createVNode(_component_app_markup, {
                      resource: "",
                      class: "mb-4"
                    }, {
                      default: withCtx(() => [
                        _hoisted_32
                      ]),
                      _: 1
                    }),
                    _hoisted_33,
                    createVNode(_component_examples_example, { file: "v-select/prop-item-props" }),
                    createBaseVNode("p", null, [
                      createTextVNode("See the "),
                      createVNode(_component_app_link, { href: "/api/v-list-item/" }, {
                        default: withCtx(() => [
                          createTextVNode("VListItem API")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" for a list of available props.")
                    ])
                  ])
                ]),
                createBaseVNode("section", _hoisted_34, [
                  createVNode(_component_app_heading, {
                    href: "#slots",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Slots")
                    ]),
                    _: 1
                  }),
                  _hoisted_35,
                  createBaseVNode("section", _hoisted_36, [
                    createVNode(_component_app_heading, {
                      href: "#item",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Item")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("The item slot is used to change how items are rendered in the list. It provides "),
                      _hoisted_37,
                      createTextVNode(", an "),
                      createVNode(_component_app_link, { href: "/api/v-select/#slots-item" }, {
                        default: withCtx(() => [
                          createTextVNode("InternalItem")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" object containing the transformed item-title and item-value; and "),
                      _hoisted_38,
                      createTextVNode(", an object containing the props and events that would normally be bound to the list item.")
                    ]),
                    createVNode(_component_examples_example, { file: "v-select/slot-item" })
                  ]),
                  createBaseVNode("section", _hoisted_39, [
                    createVNode(_component_app_heading, {
                      href: "#append-and-prepend-item",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Append and prepend item")
                      ]),
                      _: 1
                    }),
                    _hoisted_40,
                    createVNode(_component_examples_example, { file: "v-select/slot-append-and-prepend-item" })
                  ]),
                  createBaseVNode("section", _hoisted_41, [
                    createVNode(_component_app_heading, {
                      href: "#selection",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Selection")
                      ]),
                      _: 1
                    }),
                    _hoisted_42,
                    createVNode(_component_examples_example, { file: "v-select/slot-selection" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
