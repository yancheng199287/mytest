import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "data-table-server-side-tables" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "Server-side Data tables are used for showing data coming from an API.", -1);
const _hoisted_3 = { id: "examples" };
const _hoisted_4 = { id: "server-side-paginate-and-sort" };
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("To use data from an API, listen to the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "@update:options"),
  /* @__PURE__ */ createTextVNode(" event to know when to fetch new data. Use the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "loading"),
  /* @__PURE__ */ createTextVNode(" prop to display a progress bar while fetching the data.")
], -1);
const _hoisted_6 = { id: "server-side-search" };
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("If you need to support search functionality, use the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "search"),
  /* @__PURE__ */ createTextVNode(" prop to let the table know when new search input is available. Since the table does not actually do any filtering on its own, the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "search"),
  /* @__PURE__ */ createTextVNode(" input does not need to be the actual value being searched for. In this example we have multiple values searchable, so we just make sure to set "),
  /* @__PURE__ */ createBaseVNode("strong", null, "search"),
  /* @__PURE__ */ createTextVNode(" to "),
  /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "anything"),
  /* @__PURE__ */ createTextVNode(" when we need to fetch new data.")
], -1);
const _hoisted_8 = { id: "loading" };
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can use the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "loading"),
  /* @__PURE__ */ createTextVNode(" prop to indicate that data in the table is currently loading. If there is no data in the table, a loading message will also be displayed. This message can be customized using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "loading-text"),
  /* @__PURE__ */ createTextVNode(" prop or the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "loading"),
  /* @__PURE__ */ createTextVNode(" slot.")
], -1);
const frontmatter = { "meta": { "nav": "Server side tables", "title": "Data table - Server side tables", "description": "The data table component is used for displaying tabular data in a way that is easy for users to scan. It includes sorting, searching, pagination and selection.", "keywords": "data tables, vuetify data table component, vue data table component" }, "related": ["/components/data-tables/basics/", "/components/data-tables/virtual-tables/", "/components/tables/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "server-side-tables",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Server side tables", "title": "Data table - Server side tables", "description": "The data table component is used for displaying tabular data in a way that is easy for users to scan. It includes sorting, searching, pagination and selection.", "keywords": "data tables, vuetify data table component, vue data table component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Server side tables", "title": "Data table - Server side tables", "description": "The data table component is used for displaying tabular data in a way that is easy for users to scan. It includes sorting, searching, pagination and selection.", "keywords": "data tables, vuetify data table component, vue data table component" }, "related": ["/components/data-tables/basics/", "/components/data-tables/virtual-tables/", "/components/tables/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#data-table-server-side-tables",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Data table - Server side tables")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_promoted_entry),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_4, [
                  createVNode(_component_app_heading, {
                    href: "#server-side-paginate-and-sort",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Server-side paginate and sort")
                    ]),
                    _: 1
                  }),
                  _hoisted_5,
                  createVNode(_component_examples_example, { file: "v-data-table/misc-server-side-paginate-and-sort" })
                ]),
                createBaseVNode("section", _hoisted_6, [
                  createVNode(_component_app_heading, {
                    href: "#server-side-search",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Server-side search")
                    ]),
                    _: 1
                  }),
                  _hoisted_7,
                  createVNode(_component_examples_example, { file: "v-data-table/server-search" })
                ]),
                createBaseVNode("section", _hoisted_8, [
                  createVNode(_component_app_heading, {
                    href: "#loading",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Loading")
                    ]),
                    _: 1
                  }),
                  _hoisted_9,
                  createVNode(_component_examples_example, { file: "v-data-table/prop-loading" })
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
