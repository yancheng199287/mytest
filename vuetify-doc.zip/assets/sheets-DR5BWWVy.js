import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "sheets" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-sheet"),
  /* @__PURE__ */ createTextVNode(" component is a transformable piece of "),
  /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "paper"),
  /* @__PURE__ */ createTextVNode(" that provides a basic foundation for Vuetify features.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, "The sheet component has support for elevation, rounded corners, color, and more. It can be used as a container for other components or as a standalone.", -1);
const _hoisted_5 = { id: "api" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_8 = { id: "anatomy" };
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-sheet"),
  /* @__PURE__ */ createTextVNode(" component contains only a default slot.")
], -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Element / Area"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("tbody", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "1. Container"),
    /* @__PURE__ */ createBaseVNode("td", null, "The main content area")
  ])
], -1);
const _hoisted_12 = { id: "guide" };
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Often when building out a user interface, you will need to create a container for content and other custom components. The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-sheet"),
  /* @__PURE__ */ createTextVNode(" component is a great way to do this. It provides a baseline for elevation, rounded corners, and color.")
], -1);
const _hoisted_14 = { id: "props" };
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Some of the standard props that can be applied to the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-sheet"),
  /* @__PURE__ */ createTextVNode(" component are listed below.")
], -1);
const _hoisted_16 = { id: "elevation" };
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-sheet", -1);
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("strong", null, "0", -1);
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("strong", null, "24", -1);
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "elevation", -1);
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "box-shadow", -1);
const _hoisted_22 = { id: "rounded" };
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("strong", null, "rounded", -1);
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "border-radius", -1);
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "4px", -1);
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-sheet", -1);
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "tr-xl l-pill", -1);
const _hoisted_28 = /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "rounded-tr-xl rounded-l-pill", -1);
const _hoisted_29 = { id: "color" };
const _hoisted_30 = /* @__PURE__ */ createBaseVNode("p", null, "Sheets and components based on them can have different sizes and colors.", -1);
const _hoisted_31 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-sheet", -1);
const _hoisted_32 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "warning", -1);
const _hoisted_33 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "amber darken-3", -1);
const _hoisted_34 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "deep-purple accent", -1);
const _hoisted_35 = /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "rgb", -1);
const _hoisted_36 = /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "rgba", -1);
const _hoisted_37 = /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "hexadecimal", -1);
const _hoisted_38 = { id: "examples" };
const _hoisted_39 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The following are a collection of examples that demonstrate more advanced and real world use of the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-sheet"),
  /* @__PURE__ */ createTextVNode(" component.")
], -1);
const _hoisted_40 = { id: "congratulations" };
const _hoisted_41 = /* @__PURE__ */ createBaseVNode("p", null, "This example uses a sheet component to create a banner congratulating users for signing up for the Vuetify community.", -1);
const _hoisted_42 = { id: "reconcile-notification" };
const _hoisted_43 = /* @__PURE__ */ createBaseVNode("p", null, "The following example uses a sheet component to create a banner that notifies users that the account balance has been reconciled.", -1);
const _hoisted_44 = { id: "privacy-policy" };
const _hoisted_45 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Creating a Privacy Policy notification is a great use case for the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-sheet"),
  /* @__PURE__ */ createTextVNode(" component.")
], -1);
const _hoisted_46 = { id: "referral-program" };
const _hoisted_47 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Even for simple use-cases, the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-sheet"),
  /* @__PURE__ */ createTextVNode(" component is versatile makes it easy to contain content and other components.")
], -1);
const frontmatter = { "meta": { "nav": "Sheets", "title": "Sheet component", "description": "The sheet component is the baseline for many Material Design implementations used in Vuetify.", "keywords": "sheets, vuetify sheet component, vue sheet component, paper, material design paper, material design sheets" }, "related": ["/components/cards", "/components/grids", "/styles/elevation"], "features": { "github": "/components/VSheet/", "label": "C: VSheet", "report": true } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "sheets",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Sheets", "title": "Sheet component", "description": "The sheet component is the baseline for many Material Design implementations used in Vuetify.", "keywords": "sheets, vuetify sheet component, vue sheet component, paper, material design paper, material design sheets" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Sheets", "title": "Sheet component", "description": "The sheet component is the baseline for many Material Design implementations used in Vuetify.", "keywords": "sheets, vuetify sheet component, vue sheet component, paper, material design paper, material design sheets" }, "related": ["/components/cards", "/components/grids", "/styles/elevation"], "features": { "github": "/components/VSheet/", "label": "C: VSheet", "report": true } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_app_figure = resolveComponent("app-figure");
      const _component_page_features = resolveComponent("page-features");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#sheets",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Sheets")
                ]),
                _: 1
              }),
              _hoisted_2,
              createBaseVNode("p", null, [
                createBaseVNode("div", null, [
                  createVNode(_component_app_figure, {
                    alt: "Sheet Entry",
                    src: "https://cdn.vuetifyjs.com/docs/images/components/v-sheet/v-sheet-entry.png"
                  })
                ])
              ]),
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_usage, { name: "v-sheet" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_6,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-sheet/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-sheet")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_8, [
                createVNode(_component_app_heading, {
                  href: "#anatomy",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Anatomy")
                  ]),
                  _: 1
                }),
                _hoisted_9,
                createBaseVNode("p", null, [
                  createBaseVNode("div", null, [
                    createVNode(_component_app_figure, {
                      alt: "Sheet Anatomy",
                      src: "https://cdn.vuetifyjs.com/docs/images/components/v-sheet/v-sheet-anatomy.png"
                    })
                  ])
                ]),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_10,
                    _hoisted_11
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_12, [
                createVNode(_component_app_heading, {
                  href: "#guide",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Guide")
                  ]),
                  _: 1
                }),
                _hoisted_13,
                createBaseVNode("section", _hoisted_14, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  _hoisted_15,
                  createBaseVNode("section", _hoisted_16, [
                    createVNode(_component_app_heading, {
                      href: "#elevation",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Elevation")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("The "),
                      _hoisted_17,
                      createTextVNode(" component accepts a custom elevation between "),
                      _hoisted_18,
                      createTextVNode(" and "),
                      _hoisted_19,
                      createTextVNode(" (0 is default). The "),
                      _hoisted_20,
                      createTextVNode(" property modifies the "),
                      _hoisted_21,
                      createTextVNode(" property. More information is located in the MD "),
                      createVNode(_component_app_link, { href: "https://material.io/design/environment/elevation.html" }, {
                        default: withCtx(() => [
                          createTextVNode("Elevation Design Specification")
                        ]),
                        _: 1
                      }),
                      createTextVNode(".")
                    ]),
                    createVNode(_component_examples_example, { file: "v-sheet/prop-elevation" })
                  ]),
                  createBaseVNode("section", _hoisted_22, [
                    createVNode(_component_app_heading, {
                      href: "#rounded",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Rounded")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("The "),
                      _hoisted_23,
                      createTextVNode(" prop adds a default "),
                      _hoisted_24,
                      createTextVNode(" of "),
                      _hoisted_25,
                      createTextVNode(". By default, the "),
                      _hoisted_26,
                      createTextVNode(" component has no border-radius. Customize the radius’s size and location by providing a custom rounded value; e.g. a rounded value of "),
                      _hoisted_27,
                      createTextVNode(" equates to "),
                      _hoisted_28,
                      createTextVNode(". Additional information is on the "),
                      createVNode(_component_app_link, { href: "/styles/border-radius/" }, {
                        default: withCtx(() => [
                          createTextVNode("Border Radius")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" page.")
                    ]),
                    createVNode(_component_examples_example, { file: "v-sheet/prop-rounded" })
                  ]),
                  createBaseVNode("section", _hoisted_29, [
                    createVNode(_component_app_heading, {
                      href: "#color",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Color")
                      ]),
                      _: 1
                    }),
                    _hoisted_30,
                    createBaseVNode("p", null, [
                      createTextVNode("The "),
                      _hoisted_31,
                      createTextVNode(" component accepts custom "),
                      createVNode(_component_app_link, { href: "/styles/colors/" }, {
                        default: withCtx(() => [
                          createTextVNode("Material Design Color")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" values such as "),
                      _hoisted_32,
                      createTextVNode(", "),
                      _hoisted_33,
                      createTextVNode(", and "),
                      _hoisted_34,
                      createTextVNode(" — as well as "),
                      _hoisted_35,
                      createTextVNode(", "),
                      _hoisted_36,
                      createTextVNode(", and "),
                      _hoisted_37,
                      createTextVNode(" values.")
                    ]),
                    createVNode(_component_examples_example, { file: "v-sheet/prop-color" })
                  ])
                ])
              ]),
              createBaseVNode("section", _hoisted_38, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                _hoisted_39,
                createBaseVNode("section", _hoisted_40, [
                  createVNode(_component_app_heading, {
                    href: "#congratulations",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Congratulations")
                    ]),
                    _: 1
                  }),
                  _hoisted_41,
                  createVNode(_component_examples_example, { file: "v-sheet/misc-congratulations" })
                ]),
                createBaseVNode("section", _hoisted_42, [
                  createVNode(_component_app_heading, {
                    href: "#reconcile-notification",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Reconcile Notification")
                    ]),
                    _: 1
                  }),
                  _hoisted_43,
                  createVNode(_component_examples_example, { file: "v-sheet/misc-reconcile" })
                ]),
                createBaseVNode("section", _hoisted_44, [
                  createVNode(_component_app_heading, {
                    href: "#privacy-policy",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Privacy Policy")
                    ]),
                    _: 1
                  }),
                  _hoisted_45,
                  createVNode(_component_examples_example, { file: "v-sheet/misc-privacy-policy" })
                ]),
                createBaseVNode("section", _hoisted_46, [
                  createVNode(_component_app_heading, {
                    href: "#referral-program",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Referral program")
                    ]),
                    _: 1
                  }),
                  _hoisted_47,
                  createVNode(_component_examples_example, { file: "v-sheet/misc-referral-program" })
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
