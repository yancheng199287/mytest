import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode } from "./index-DGybHjCP.js";
import { _ as __5 } from "./side-navigation-CGKNrFa-.js";
const frontmatter = { "layout": "wireframe", "meta": { "title": "Base Wireframe" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "side-navigation",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "Base Wireframe" } };
    useHead(head);
    __expose({ frontmatter: { "layout": "wireframe", "meta": { "title": "Base Wireframe" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createVNode(__5)
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
