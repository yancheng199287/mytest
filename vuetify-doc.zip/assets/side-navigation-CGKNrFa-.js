import { y as _export_sfc, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, b as createVNode, l as createElementBlock, v as renderList, F as Fragment } from "./index-DGybHjCP.js";
const _sfc_main = {};
function _sfc_render(_ctx, _cache) {
  const _component_v_avatar = resolveComponent("v-avatar");
  const _component_v_navigation_drawer = resolveComponent("v-navigation-drawer");
  const _component_v_main = resolveComponent("v-main");
  const _component_v_app = resolveComponent("v-app");
  return openBlock(), createBlock(_component_v_app, { id: "inspire" }, {
    default: withCtx(() => [
      createVNode(_component_v_navigation_drawer, {
        class: "pt-4",
        color: "grey-lighten-3",
        "model-value": "",
        rail: ""
      }, {
        default: withCtx(() => [
          (openBlock(), createElementBlock(Fragment, null, renderList(6, (n) => {
            return createVNode(_component_v_avatar, {
              key: n,
              color: `grey-${n === 1 ? "darken" : "lighten"}-1`,
              size: n === 1 ? 36 : 20,
              class: "d-block text-center mx-auto mb-9"
            }, null, 8, ["color", "size"]);
          }), 64))
        ]),
        _: 1
      }),
      createVNode(_component_v_main)
    ]),
    _: 1
  });
}
const __5 = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  __5 as _
};
