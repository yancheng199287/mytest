import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "sizing" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "Sizing utility classes are used to modify the dimensions of an element.", -1);
const _hoisted_3 = { id: "height" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Specify the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "height"),
  /* @__PURE__ */ createTextVNode(" property of "),
  /* @__PURE__ */ createBaseVNode("strong", null, "block level elements"),
  /* @__PURE__ */ createTextVNode(" with a utility class. The following classes are applied using the format "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".{prefix}-{size}"),
  /* @__PURE__ */ createTextVNode(" ; where "),
  /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "prefix"),
  /* @__PURE__ */ createTextVNode(" is "),
  /* @__PURE__ */ createBaseVNode("strong", null, "h"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "size"),
  /* @__PURE__ */ createTextVNode(" is the value.")
], -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Class"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("tbody", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "h-auto")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "height: auto")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "h-screen")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "height: 100dvh")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "h-0")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "height: 0")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "h-25")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "height: 25%")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "h-50")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "height: 50%")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "h-75")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "height: 75%")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "h-100")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "height: 100%")
    ])
  ])
], -1);
const _hoisted_7 = { id: "width" };
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Specify the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "width"),
  /* @__PURE__ */ createTextVNode(" property of "),
  /* @__PURE__ */ createBaseVNode("strong", null, "block level elements"),
  /* @__PURE__ */ createTextVNode(" with a utility class. The following classes are applied using the format "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".{prefix}-{size}"),
  /* @__PURE__ */ createTextVNode(" ; where "),
  /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "prefix"),
  /* @__PURE__ */ createTextVNode(" is "),
  /* @__PURE__ */ createBaseVNode("strong", null, "w"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "size"),
  /* @__PURE__ */ createTextVNode(" is the value.")
], -1);
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Class"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("tbody", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "w-auto")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "width: auto")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "w-0")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "width: 0")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "w-25")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "width: 25%")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "w-50")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "width: 50%")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "w-75")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "width: 75%")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "w-100")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "width: 100%")
    ])
  ])
], -1);
const frontmatter = { "meta": { "title": "Sizing", "description": "Modify the dimension of block level elements using one of the Vuetify sizing utility classes.", "keywords": "css height, css width, sizing elements, element dimensions" }, "related": ["/styles/content/", "/styles/flex/", "/styles/text-and-typography/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "sizing",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "Sizing", "description": "Modify the dimension of block level elements using one of the Vuetify sizing utility classes.", "keywords": "css height, css width, sizing elements, element dimensions" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "title": "Sizing", "description": "Modify the dimension of block level elements using one of the Vuetify sizing utility classes.", "keywords": "css height, css width, sizing elements, element dimensions" }, "related": ["/styles/content/", "/styles/flex/", "/styles/text-and-typography/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_table = resolveComponent("app-table");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#sizing",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Sizing")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_promoted_entry),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#height",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Height")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_5,
                    _hoisted_6
                  ]),
                  _: 1
                }),
                createVNode(_component_examples_example, { file: "sizing/height" })
              ]),
              createBaseVNode("section", _hoisted_7, [
                createVNode(_component_app_heading, {
                  href: "#width",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Width")
                  ]),
                  _: 1
                }),
                _hoisted_8,
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_9,
                    _hoisted_10
                  ]),
                  _: 1
                }),
                createVNode(_component_examples_example, { file: "sizing/width" })
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
