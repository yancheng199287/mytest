import { y as _export_sfc, o as openBlock, l as createElementBlock } from "./index-DGybHjCP.js";
const _sfc_main$1 = {};
function _sfc_render$1(_ctx, _cache) {
  return openBlock(), createElementBlock("div", null, " Sizing / Height example ");
}
const __0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["render", _sfc_render$1]]);
const __0_raw = "<template>\n  <div>\n    Sizing / Height example\n  </div>\n</template>\n";
const _sfc_main = {};
function _sfc_render(_ctx, _cache) {
  return openBlock(), createElementBlock("div", null, " Sizing / Width example ");
}
const __1 = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
const __1_raw = "<template>\n  <div>\n    Sizing / Width example\n  </div>\n</template>\n";
const sizing = {
  "height": {
    component: __0,
    source: __0_raw
  },
  "width": {
    component: __1,
    source: __1_raw
  }
};
export {
  sizing as default
};
