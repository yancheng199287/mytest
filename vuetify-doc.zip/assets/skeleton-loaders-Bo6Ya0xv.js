import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "skeleton-loaders" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "Skeleton loaders provide a simple way to display loading placeholders in your application.", -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-skeleton-loader"),
  /* @__PURE__ */ createTextVNode(" component provides a user with a visual indicator that content is coming / loading. This is better received than traditional full-screen loaders.")
], -1);
const _hoisted_5 = { id: "api" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_8 = { id: "anatomy" };
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-skeleton-loader"),
  /* @__PURE__ */ createTextVNode(" has a default slot that is rendered when the component is not in a loading state.")
], -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Element / Area"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("tbody", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "1. Container"),
    /* @__PURE__ */ createBaseVNode("td", null, "The container is the root element of the component.")
  ])
], -1);
const _hoisted_12 = { id: "guide" };
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-skeleton-loader"),
  /* @__PURE__ */ createTextVNode(" component can be used in a variety of contexts, including cards, lists, and tables. It can be used to create a placeholder loading state for when content is being fetched from a server or loaded asynchronously.")
], -1);
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The following code snippet is an example of a basic "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-skeleton-loader"),
  /* @__PURE__ */ createTextVNode(" component. When no "),
  /* @__PURE__ */ createBaseVNode("strong", null, "type"),
  /* @__PURE__ */ createTextVNode(" property is provided, the component will default to an "),
  /* @__PURE__ */ createBaseVNode("strong", null, "image"),
  /* @__PURE__ */ createTextVNode(" type.")
], -1);
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-html" }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-skeleton-loader")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("v-skeleton-loader")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_16 = { id: "props" };
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-skeleton-loader"),
  /* @__PURE__ */ createTextVNode(" component has a small API mainly used to configure the root and item height.")
], -1);
const _hoisted_18 = { id: "type" };
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "type"),
  /* @__PURE__ */ createTextVNode(" property is used to define the type of skeleton loader. Types can be combined to create more complex skeletons. For example, the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "card"),
  /* @__PURE__ */ createTextVNode(" type is a combination of the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "image"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "heading"),
  /* @__PURE__ */ createTextVNode(" types.")
], -1);
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("p", null, "The following built-in types are available:", -1);
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Type"),
    /* @__PURE__ */ createBaseVNode("th", null, "Composition")
  ])
], -1);
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("tbody", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "actions")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "button@2")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "article")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "heading, paragraph")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "avatar")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "avatar")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "button")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "button")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "card")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "image, heading")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "card-avatar")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "image, list-item-avatar")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "chip")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "chip")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "date-picker")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "list-item, heading, divider, date-picker-options, date-picker-days, actions")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "date-picker-options")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "text, avatar@2")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "date-picker-days")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "avatar@28")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "divider")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "divider")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "heading")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "heading")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "image")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "image")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "list-item")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "text")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "list-item-avatar")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "avatar, text")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "list-item-two-line")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "sentences")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "list-item-avatar-two-line")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "avatar, sentences")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "list-item-three-line")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "paragraph")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "list-item-avatar-three-line")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "avatar, paragraph")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "ossein")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "ossein")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "paragraph")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "text@3")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "sentences")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "text@2")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "subtitle")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "text")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "table")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "table-heading, table-thead, table-tbody, table-tfoot")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "table-heading")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "heading, text")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "table-thead")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "heading@6")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "table-tbody")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "table-row-divider@6")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "table-row-divider")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "table-row, divider")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "table-row")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "text@6")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "table-tfoot")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "text@2, avatar@2")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createBaseVNode("strong", null, "text")
    ]),
    /* @__PURE__ */ createBaseVNode("td", null, "text")
  ])
], -1);
const _hoisted_23 = { id: "loading" };
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("p", null, "A skeleton loader is considered to be in a loading state if one of the following conditions are met:", -1);
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, "The default slot is not used"),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("The "),
    /* @__PURE__ */ createBaseVNode("strong", null, "loading"),
    /* @__PURE__ */ createTextVNode(" property is set to "),
    /* @__PURE__ */ createBaseVNode("strong", null, "true")
  ])
], -1);
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("If either condition is met, the skeleton loader returns the type structure in place of the default slot and applies dimensions values; e.g. "),
  /* @__PURE__ */ createBaseVNode("strong", null, "height"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "width"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "min-height"),
  /* @__PURE__ */ createTextVNode(", etc. If the condition is not met, the default slot is returned.")
], -1);
const _hoisted_27 = { id: "elevation" };
const _hoisted_28 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "elevation"),
  /* @__PURE__ */ createTextVNode(" property makes it easy to match the elevation of the skeleton loader to the content it is replacing.")
], -1);
const _hoisted_29 = { id: "boilerplate" };
const _hoisted_30 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-skeleton-loader"),
  /* @__PURE__ */ createTextVNode(" can be used as boilerplate designs when creating mockups. Mix and match various pre-defined options or create your own unique implementations. In this example, we use a custom "),
  /* @__PURE__ */ createBaseVNode("strong", null, "data"),
  /* @__PURE__ */ createTextVNode(" property to apply the same props to multiple "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-skeleton-loader"),
  /* @__PURE__ */ createTextVNode("’s at once.")
], -1);
const _hoisted_31 = { id: "examples" };
const _hoisted_32 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The following are a collection of examples that demonstrate more advanced and real world use of the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-skeleton-loader"),
  /* @__PURE__ */ createTextVNode(" component.")
], -1);
const _hoisted_33 = { id: "ice-cream-suggestions" };
const _hoisted_34 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The following example demonstrates how the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-skeleton-loader"),
  /* @__PURE__ */ createTextVNode(" component can be used to create a placeholder loading state for when content is being fetched from a server or loaded asynchronously.")
], -1);
const _hoisted_35 = { id: "sass-variables" };
const _hoisted_36 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-skeleton-loader", -1);
const _hoisted_37 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-scss" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/settings.scss",
    class: "language-scss"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "@use"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify/settings'"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token module-modifier keyword" }, "with"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token variable" }, "$skeleton-loader-gutter")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(" 24px"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token property" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token variable" }, "$skeleton-loader-button-width")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ":"),
    /* @__PURE__ */ createTextVNode(" 80px"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ";"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_38 = { id: "accessibility" };
const _hoisted_39 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-skeleton-loader", -1);
const _hoisted_40 = /* @__PURE__ */ createBaseVNode("strong", null, "alert", -1);
const _hoisted_41 = /* @__PURE__ */ createBaseVNode("strong", null, "aria-busy", -1);
const _hoisted_42 = /* @__PURE__ */ createBaseVNode("strong", null, "true", -1);
const _hoisted_43 = /* @__PURE__ */ createBaseVNode("strong", null, "aria-live", -1);
const _hoisted_44 = /* @__PURE__ */ createBaseVNode("strong", null, "polite", -1);
const _hoisted_45 = /* @__PURE__ */ createBaseVNode("strong", null, "aria-label", -1);
const _hoisted_46 = { id: "configuring-the-aria-label" };
const _hoisted_47 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Configure the default text used in the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-skeleton-loader"),
  /* @__PURE__ */ createTextVNode(" component in the locale options. The following example demonstrates how to update the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "loading-text"),
  /* @__PURE__ */ createTextVNode(" property:")
], -1);
const _hoisted_48 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-js" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/plugins/vuetify.js",
    class: "language-js"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" createVuetify "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify'"),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "export"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "default"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "createVuetify"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "locale"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "messages"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "loading"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'Loading content...'"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const frontmatter = { "meta": { "nav": "Skeleton loaders", "title": "Skeleton loader component", "description": "The skeleton loader component provides a placeholder loading state for when content is being fetched from a server or loaded asynchronously. It can be used in a variety of contexts, including cards, lists, and tables.", "keywords": "skeleton loaders, vuetify skeleton loader component, vue skeleton loader" }, "related": ["/components/cards/", "/components/progress-circular/", "/components/buttons/"], "features": { "figma": true, "label": "C: VSkeletonLoader", "github": "/components/VSkeletonLoader/", "report": true } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "skeleton-loaders",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Skeleton loaders", "title": "Skeleton loader component", "description": "The skeleton loader component provides a placeholder loading state for when content is being fetched from a server or loaded asynchronously. It can be used in a variety of contexts, including cards, lists, and tables.", "keywords": "skeleton loaders, vuetify skeleton loader component, vue skeleton loader" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Skeleton loaders", "title": "Skeleton loader component", "description": "The skeleton loader component provides a placeholder loading state for when content is being fetched from a server or loaded asynchronously. It can be used in a variety of contexts, including cards, lists, and tables.", "keywords": "skeleton loaders, vuetify skeleton loader component, vue skeleton loader" }, "related": ["/components/cards/", "/components/progress-circular/", "/components/buttons/"], "features": { "figma": true, "label": "C: VSkeletonLoader", "github": "/components/VSkeletonLoader/", "report": true } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_app_figure = resolveComponent("app-figure");
      const _component_page_features = resolveComponent("page-features");
      const _component_app_link = resolveComponent("app-link");
      const _component_alert = resolveComponent("alert");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_app_markup = resolveComponent("app-markup");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#skeleton-loaders",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Skeleton loaders")
                ]),
                _: 1
              }),
              _hoisted_2,
              createBaseVNode("p", null, [
                createBaseVNode("div", null, [
                  createVNode(_component_app_figure, {
                    alt: "Skeleton loader Entry",
                    src: "https://cdn.vuetifyjs.com/docs/images/components-temp/v-skeleton-loader/v-skeleton-loader-entry.png"
                  })
                ])
              ]),
              createVNode(_component_page_features),
              createVNode(_component_alert, { type: "success" }, {
                default: withCtx(() => [
                  createBaseVNode("p", null, [
                    createTextVNode("This feature was introduced in "),
                    createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v3.4.0" }, {
                      default: withCtx(() => [
                        createTextVNode("v3.4.0 (Blackguard)")
                      ]),
                      _: 1
                    })
                  ])
                ]),
                _: 1
              }),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_usage, { name: "v-skeleton-loader" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_6,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-skeleton-loader/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-skeleton-loader")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_8, [
                createVNode(_component_app_heading, {
                  href: "#anatomy",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Anatomy")
                  ]),
                  _: 1
                }),
                _hoisted_9,
                createBaseVNode("p", null, [
                  createBaseVNode("div", null, [
                    createVNode(_component_app_figure, {
                      alt: "Skeleton loader Anatomy",
                      src: "https://cdn.vuetifyjs.com/docs/images/components-temp/v-skeleton-loader/v-skeleton-loader-anatomy.png"
                    })
                  ])
                ]),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_10,
                    _hoisted_11
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_12, [
                createVNode(_component_app_heading, {
                  href: "#guide",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Guide")
                  ]),
                  _: 1
                }),
                _hoisted_13,
                _hoisted_14,
                createVNode(_component_app_markup, {
                  resource: "",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_15
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_16, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  _hoisted_17,
                  createBaseVNode("section", _hoisted_18, [
                    createVNode(_component_app_heading, {
                      href: "#type",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Type")
                      ]),
                      _: 1
                    }),
                    _hoisted_19,
                    createVNode(_component_examples_example, { file: "v-skeleton-loader/prop-type" }),
                    _hoisted_20,
                    createVNode(_component_app_table, null, {
                      default: withCtx(() => [
                        _hoisted_21,
                        _hoisted_22
                      ]),
                      _: 1
                    })
                  ]),
                  createBaseVNode("section", _hoisted_23, [
                    createVNode(_component_app_heading, {
                      href: "#loading",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Loading")
                      ]),
                      _: 1
                    }),
                    _hoisted_24,
                    _hoisted_25,
                    _hoisted_26,
                    createVNode(_component_examples_example, { file: "v-skeleton-loader/prop-loading" })
                  ]),
                  createBaseVNode("section", _hoisted_27, [
                    createVNode(_component_app_heading, {
                      href: "#elevation",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Elevation")
                      ]),
                      _: 1
                    }),
                    _hoisted_28,
                    createVNode(_component_examples_example, { file: "v-skeleton-loader/prop-elevation" })
                  ]),
                  createBaseVNode("section", _hoisted_29, [
                    createVNode(_component_app_heading, {
                      href: "#boilerplate",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Boilerplate")
                      ]),
                      _: 1
                    }),
                    _hoisted_30,
                    createVNode(_component_examples_example, { file: "v-skeleton-loader/prop-boilerplate" })
                  ])
                ])
              ]),
              createBaseVNode("section", _hoisted_31, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                _hoisted_32,
                createBaseVNode("section", _hoisted_33, [
                  createVNode(_component_app_heading, {
                    href: "#ice-cream-suggestions",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Ice-cream suggestions")
                    ]),
                    _: 1
                  }),
                  _hoisted_34,
                  createVNode(_component_examples_example, { file: "v-skeleton-loader/misc-ice-cream" })
                ])
              ]),
              createBaseVNode("section", _hoisted_35, [
                createVNode(_component_app_heading, {
                  href: "#sass-variables",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("SASS Variables")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("Make fine tuned changes by modifying the "),
                  _hoisted_36,
                  createTextVNode(),
                  createVNode(_component_app_link, { href: "/features/sass-variables" }, {
                    default: withCtx(() => [
                      createTextVNode("SASS variables")
                    ]),
                    _: 1
                  }),
                  createTextVNode(". This is useful when you want to change the default button height or padding.")
                ]),
                createVNode(_component_app_markup, {
                  resource: "src/settings.scss",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_37
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("For a list of all available SASS variables, navigate to the "),
                  createVNode(_component_app_link, { href: "/api/v-skeleton-loader/#sass" }, {
                    default: withCtx(() => [
                      createTextVNode("v-skeleton-loader")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" API page.")
                ])
              ]),
              createBaseVNode("section", _hoisted_38, [
                createVNode(_component_app_heading, {
                  href: "#accessibility",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Accessibility")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("By default, the "),
                  _hoisted_39,
                  createTextVNode(" component is assigned a "),
                  createVNode(_component_app_link, { href: "https://www.w3.org/WAI/standards-guidelines/aria/" }, {
                    default: withCtx(() => [
                      createTextVNode("WAI-ARIA")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" role of "),
                  createVNode(_component_app_link, { href: "https://www.w3.org/TR/wai-aria/#alert" }, {
                    default: withCtx(() => [
                      _hoisted_40
                    ]),
                    _: 1
                  }),
                  createTextVNode(". We augment this role with three aria properties. An "),
                  createVNode(_component_app_link, { href: "https://www.w3.org/TR/wai-aria-1.0/states_and_properties#aria-busy" }, {
                    default: withCtx(() => [
                      _hoisted_41
                    ]),
                    _: 1
                  }),
                  createTextVNode(" value of "),
                  _hoisted_42,
                  createTextVNode(" denotes that a widget is missing required owned elements. An "),
                  createVNode(_component_app_link, { href: "https://www.w3.org/TR/wai-aria-1.1/#aria-live" }, {
                    default: withCtx(() => [
                      _hoisted_43
                    ]),
                    _: 1
                  }),
                  createTextVNode(" value of "),
                  _hoisted_44,
                  createTextVNode(" sets the screen reader’s priority of live regions. And finally, "),
                  createVNode(_component_app_link, { href: "https://www.w3.org/TR/WCAG20-TECHS/ARIA6.html" }, {
                    default: withCtx(() => [
                      _hoisted_45
                    ]),
                    _: 1
                  }),
                  createTextVNode(", which is used to provide a human readable description of the element.")
                ]),
                createBaseVNode("section", _hoisted_46, [
                  createVNode(_component_app_heading, {
                    href: "#configuring-the-aria-label",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Configuring the aria-label")
                    ]),
                    _: 1
                  }),
                  _hoisted_47,
                  createVNode(_component_app_markup, {
                    resource: "src/plugins/vuetify.js",
                    class: "mb-4"
                  }, {
                    default: withCtx(() => [
                      _hoisted_48
                    ]),
                    _: 1
                  }),
                  createBaseVNode("p", null, [
                    createTextVNode("Navigate to the "),
                    createVNode(_component_app_link, { href: "/features/internationalization/" }, {
                      default: withCtx(() => [
                        createTextVNode("Internationalization (i18n)")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" page for more information on how to configure the locale options.")
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
