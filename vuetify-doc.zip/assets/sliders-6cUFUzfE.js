import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "sliders" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-slider"),
  /* @__PURE__ */ createTextVNode(" component can be used as an alternative visualization instead of a number input.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, "Sliders reflect a range of values along a track, from which users may select a single value. They are ideal for adjusting settings such as volume, brightness, or applying image filters.", -1);
const _hoisted_5 = { id: "api" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_8 = { id: "examples" };
const _hoisted_9 = { id: "props" };
const _hoisted_10 = { id: "colors" };
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can set the colors of the slider using the props "),
  /* @__PURE__ */ createBaseVNode("strong", null, "color"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "track-color"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "thumb-color"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_12 = { id: "disabled" };
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You cannot interact with "),
  /* @__PURE__ */ createBaseVNode("strong", null, "disabled"),
  /* @__PURE__ */ createTextVNode(" sliders.")
], -1);
const _hoisted_14 = { id: "step" };
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "step"),
  /* @__PURE__ */ createTextVNode(" prop you can control the precision of the slider, and how much it should move each step.")
], -1);
const _hoisted_16 = { id: "icons" };
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can add icons to the slider with the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "append-icon"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "prepend-icon"),
  /* @__PURE__ */ createTextVNode(" props. With "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "@click:append"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "@click:prepend"),
  /* @__PURE__ */ createTextVNode(" you can trigger a callback function when click the icon.")
], -1);
const _hoisted_18 = { id: "min-and-max" };
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can set "),
  /* @__PURE__ */ createBaseVNode("strong", null, "min"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "max"),
  /* @__PURE__ */ createTextVNode(" values of sliders.")
], -1);
const _hoisted_20 = { id: "readonly" };
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You cannot interact with "),
  /* @__PURE__ */ createBaseVNode("strong", null, "readonly"),
  /* @__PURE__ */ createTextVNode(" sliders, but they look as ordinary ones.")
], -1);
const _hoisted_22 = { id: "thumb" };
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can display a thumb label while sliding or always with the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "thumb-label"),
  /* @__PURE__ */ createTextVNode(" prop . It can have a custom color by setting "),
  /* @__PURE__ */ createBaseVNode("strong", null, "thumb-color"),
  /* @__PURE__ */ createTextVNode(" prop and a custom size with the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "thumb-size"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_24 = { id: "ticks" };
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("p", null, "Tick marks represent predetermined values to which the user can move the slider.", -1);
const _hoisted_26 = { id: "vertical-sliders" };
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can use the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "direction"),
  /* @__PURE__ */ createTextVNode(" prop to switch sliders to a vertical orientation. If you need to change the height of the slider, use css.")
], -1);
const _hoisted_28 = { id: "slots" };
const _hoisted_29 = { id: "append-and-prepend" };
const _hoisted_30 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Use slots such as "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "append"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "prepend"),
  /* @__PURE__ */ createTextVNode(" to easily customize the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-slider"),
  /* @__PURE__ */ createTextVNode(" to fit any situation.")
], -1);
const _hoisted_31 = { id: "append-text-field" };
const _hoisted_32 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Sliders can be combined with other components in its "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "append"),
  /* @__PURE__ */ createTextVNode(" slot, such as "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-text-field"),
  /* @__PURE__ */ createTextVNode(", to add additional functionality to the component.")
], -1);
const frontmatter = { "meta": { "nav": "Sliders", "title": "Slider component", "description": "The slider component can be used as an alternative visualization instead of a number input.", "keywords": "sliders, vuetify slider component, vue slider component" }, "related": ["/components/forms/", "/components/selects/", "/components/range-sliders/"], "features": { "label": "C: VSlider", "report": true, "github": "/components/VSlider/", "spec": "https://m2.material.io/components/sliders" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "sliders",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Sliders", "title": "Slider component", "description": "The slider component can be used as an alternative visualization instead of a number input.", "keywords": "sliders, vuetify slider component, vue slider component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Sliders", "title": "Slider component", "description": "The slider component can be used as an alternative visualization instead of a number input.", "keywords": "sliders, vuetify slider component, vue slider component" }, "related": ["/components/forms/", "/components/selects/", "/components/range-sliders/"], "features": { "label": "C: VSlider", "report": true, "github": "/components/VSlider/", "spec": "https://m2.material.io/components/sliders" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#sliders",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Sliders")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_usage, { name: "v-slider" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_6,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-slider/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-slider")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_8, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_9, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_10, [
                    createVNode(_component_app_heading, {
                      href: "#colors",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Colors")
                      ]),
                      _: 1
                    }),
                    _hoisted_11,
                    createVNode(_component_examples_example, { file: "v-slider/prop-colors" })
                  ]),
                  createBaseVNode("section", _hoisted_12, [
                    createVNode(_component_app_heading, {
                      href: "#disabled",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Disabled")
                      ]),
                      _: 1
                    }),
                    _hoisted_13,
                    createVNode(_component_examples_example, { file: "v-slider/prop-disabled" })
                  ]),
                  createBaseVNode("section", _hoisted_14, [
                    createVNode(_component_app_heading, {
                      href: "#step",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Step")
                      ]),
                      _: 1
                    }),
                    _hoisted_15,
                    createVNode(_component_examples_example, { file: "v-slider/prop-step" })
                  ]),
                  createBaseVNode("section", _hoisted_16, [
                    createVNode(_component_app_heading, {
                      href: "#icons",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Icons")
                      ]),
                      _: 1
                    }),
                    _hoisted_17,
                    createVNode(_component_examples_example, { file: "v-slider/prop-icons" })
                  ]),
                  createBaseVNode("section", _hoisted_18, [
                    createVNode(_component_app_heading, {
                      href: "#min-and-max",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Min and max")
                      ]),
                      _: 1
                    }),
                    _hoisted_19,
                    createVNode(_component_examples_example, { file: "v-slider/prop-min-and-max" })
                  ]),
                  createBaseVNode("section", _hoisted_20, [
                    createVNode(_component_app_heading, {
                      href: "#readonly",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Readonly")
                      ]),
                      _: 1
                    }),
                    _hoisted_21,
                    createVNode(_component_examples_example, { file: "v-slider/prop-readonly" })
                  ]),
                  createBaseVNode("section", _hoisted_22, [
                    createVNode(_component_app_heading, {
                      href: "#thumb",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Thumb")
                      ]),
                      _: 1
                    }),
                    _hoisted_23,
                    createVNode(_component_examples_example, { file: "v-slider/prop-thumb" })
                  ]),
                  createBaseVNode("section", _hoisted_24, [
                    createVNode(_component_app_heading, {
                      href: "#ticks",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Ticks")
                      ]),
                      _: 1
                    }),
                    _hoisted_25,
                    createVNode(_component_examples_example, { file: "v-slider/prop-ticks" })
                  ]),
                  createBaseVNode("section", _hoisted_26, [
                    createVNode(_component_app_heading, {
                      href: "#vertical-sliders",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Vertical sliders")
                      ]),
                      _: 1
                    }),
                    _hoisted_27,
                    createVNode(_component_examples_example, { file: "v-slider/prop-vertical" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_28, [
                  createVNode(_component_app_heading, {
                    href: "#slots",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Slots")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_29, [
                    createVNode(_component_app_heading, {
                      href: "#append-and-prepend",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Append and prepend")
                      ]),
                      _: 1
                    }),
                    _hoisted_30,
                    createVNode(_component_examples_example, { file: "v-slider/slot-append-and-prepend" })
                  ]),
                  createBaseVNode("section", _hoisted_31, [
                    createVNode(_component_app_heading, {
                      href: "#append-text-field",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Append text field")
                      ]),
                      _: 1
                    }),
                    _hoisted_32,
                    createVNode(_component_examples_example, { file: "v-slider/slot-append-text-field" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
