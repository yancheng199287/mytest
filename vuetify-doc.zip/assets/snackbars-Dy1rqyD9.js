import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "snackbars" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-snackbar"),
  /* @__PURE__ */ createTextVNode(" component is used to display a quick message to a user. Snackbars support positioning, removal delay, and callbacks.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("a "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-snackbar"),
  /* @__PURE__ */ createTextVNode(" in its simplest form displays a temporary and closable notification to the user.")
], -1);
const _hoisted_5 = { id: "api" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("td", null, "Sub-component typically used for actions", -1);
const _hoisted_9 = { id: "examples" };
const _hoisted_10 = { id: "props" };
const _hoisted_11 = { id: "multi-line" };
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "multi-line"),
  /* @__PURE__ */ createTextVNode(" property extends the height of the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-snackbar"),
  /* @__PURE__ */ createTextVNode(" to give you a little more room for content.")
], -1);
const _hoisted_13 = { id: "timeout" };
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "timeout"),
  /* @__PURE__ */ createTextVNode(" property lets you customize the delay before the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-snackbar"),
  /* @__PURE__ */ createTextVNode(" is hidden.")
], -1);
const _hoisted_15 = { id: "variants" };
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Apply different styles to the snackbar using props such as "),
  /* @__PURE__ */ createBaseVNode("strong", null, "text"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "shaped"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "outlined"),
  /* @__PURE__ */ createTextVNode(", and more.")
], -1);
const _hoisted_17 = { id: "vertical" };
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "vertical"),
  /* @__PURE__ */ createTextVNode(" property allows you to stack the content of your "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-snackbar"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const frontmatter = { "meta": { "nav": "Snackbars", "title": "Snackbar component", "description": "The snackbar component informs user of a process that your application has performed is will perform. It can be temporary and often contains actions. Timer will stop when user hovers over the snackbar.", "keywords": "snackbars, vuetify snackbar component, vue snackbar component" }, "related": ["/components/buttons/", "/styles/colors/", "/components/forms/"], "features": { "github": "/components/VSnackbar/", "label": "C: VSnackbar", "report": true, "spec": "https://m2.material.io/components/snackbars" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "snackbars",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Snackbars", "title": "Snackbar component", "description": "The snackbar component informs user of a process that your application has performed is will perform. It can be temporary and often contains actions. Timer will stop when user hovers over the snackbar.", "keywords": "snackbars, vuetify snackbar component, vue snackbar component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Snackbars", "title": "Snackbar component", "description": "The snackbar component informs user of a process that your application has performed is will perform. It can be temporary and often contains actions. Timer will stop when user hovers over the snackbar.", "keywords": "snackbars, vuetify snackbar component, vue snackbar component" }, "related": ["/components/buttons/", "/styles/colors/", "/components/forms/"], "features": { "github": "/components/VSnackbar/", "label": "C: VSnackbar", "report": true, "spec": "https://m2.material.io/components/snackbars" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#snackbars",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Snackbars")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_example, { file: "v-snackbar/usage" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_6,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-snackbar/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-snackbar")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-btn/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-btn")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_8
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_9, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_10, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_11, [
                    createVNode(_component_app_heading, {
                      href: "#multi-line",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Multi line")
                      ]),
                      _: 1
                    }),
                    _hoisted_12,
                    createVNode(_component_examples_example, { file: "v-snackbar/prop-multi-line" })
                  ]),
                  createBaseVNode("section", _hoisted_13, [
                    createVNode(_component_app_heading, {
                      href: "#timeout",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Timeout")
                      ]),
                      _: 1
                    }),
                    _hoisted_14,
                    createVNode(_component_examples_example, { file: "v-snackbar/prop-timeout" })
                  ]),
                  createBaseVNode("section", _hoisted_15, [
                    createVNode(_component_app_heading, {
                      href: "#variants",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Variants")
                      ]),
                      _: 1
                    }),
                    _hoisted_16,
                    createVNode(_component_examples_example, { file: "v-snackbar/prop-variants" })
                  ]),
                  createBaseVNode("section", _hoisted_17, [
                    createVNode(_component_app_heading, {
                      href: "#vertical",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Vertical")
                      ]),
                      _: 1
                    }),
                    _hoisted_18,
                    createVNode(_component_examples_example, { file: "v-snackbar/prop-vertical" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
