import { y as _export_sfc, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, b as createVNode, h as createTextVNode, l as createElementBlock, F as Fragment, v as renderList, U as normalizeClass, e as createBaseVNode, t as toDisplayString } from "./index-DGybHjCP.js";
const _sfc_main$4 = {};
function _sfc_render$4(_ctx, _cache) {
  const _component_v_card_text = resolveComponent("v-card-text");
  const _component_v_card = resolveComponent("v-card");
  return openBlock(), createBlock(_component_v_card, {
    class: "pa-md-4 mx-lg-auto",
    color: "secondary",
    width: "250px"
  }, {
    default: withCtx(() => [
      createVNode(_component_v_card_text, null, {
        default: withCtx(() => [
          createTextVNode(" Adjust screen size to see spacing changes ")
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __0 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["render", _sfc_render$4]]);
const __0_raw = '<template>\n  <v-card\n    class="pa-md-4 mx-lg-auto"\n    color="secondary"\n    width="250px"\n  >\n    <v-card-text>\n      Adjust screen size to see spacing changes\n    </v-card-text>\n  </v-card>\n</template>\n';
const _sfc_main$3 = {};
const _hoisted_1$1 = { class: "d-flex flex-wrap ga-3" };
function _sfc_render$3(_ctx, _cache) {
  const _component_v_card_text = resolveComponent("v-card-text");
  const _component_v_card = resolveComponent("v-card");
  return openBlock(), createElementBlock("div", _hoisted_1$1, [
    (openBlock(), createElementBlock(Fragment, null, renderList(8, (n) => {
      return createVNode(_component_v_card, {
        key: n,
        color: "secondary",
        width: "200px"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_card_text, null, {
            default: withCtx(() => [
              createTextVNode(" Gapped ")
            ]),
            _: 1
          })
        ]),
        _: 2
      }, 1024);
    }), 64))
  ]);
}
const __1 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["render", _sfc_render$3]]);
const __1_raw = '<template>\n  <div class="d-flex flex-wrap ga-3">\n    <v-card\n      v-for="n in 8"\n      :key="n"\n      color="secondary"\n      width="200px"\n    >\n      <v-card-text>\n        Gapped\n      </v-card-text>\n    </v-card>\n  </div>\n</template>\n';
const _sfc_main$2 = {};
function _sfc_render$2(_ctx, _cache) {
  const _component_v_card_text = resolveComponent("v-card-text");
  const _component_v_card = resolveComponent("v-card");
  return openBlock(), createBlock(_component_v_card, {
    class: "mx-auto",
    color: "secondary",
    width: "200px"
  }, {
    default: withCtx(() => [
      createVNode(_component_v_card_text, null, {
        default: withCtx(() => [
          createTextVNode(" Centered ")
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __2 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["render", _sfc_render$2]]);
const __2_raw = '<template>\n  <v-card\n    class="mx-auto"\n    color="secondary"\n    width="200px"\n  >\n    <v-card-text>\n      Centered\n    </v-card-text>\n  </v-card>\n</template>\n';
const _sfc_main$1 = {};
function _sfc_render$1(_ctx, _cache) {
  const _component_v_card = resolveComponent("v-card");
  const _component_v_card_text = resolveComponent("v-card-text");
  return openBlock(), createElementBlock("div", null, [
    createVNode(_component_v_card, {
      class: "mx-auto",
      color: "secondary",
      height: "100",
      "max-width": "200"
    }),
    createVNode(_component_v_card, {
      class: "mt-n12 mx-auto",
      color: "secondary",
      elevation: "12",
      height: "200",
      "max-width": "300"
    }, {
      default: withCtx(() => [
        createVNode(_component_v_card_text, null, {
          default: withCtx(() => [
            createTextVNode("This card has negative top margin applied")
          ]),
          _: 1
        })
      ]),
      _: 1
    })
  ]);
}
const __3 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["render", _sfc_render$1]]);
const __3_raw = '<template>\n  <div>\n    <v-card\n      class="mx-auto"\n      color="secondary"\n      height="100"\n      max-width="200"\n    ></v-card>\n    <v-card\n      class="mt-n12 mx-auto"\n      color="secondary"\n      elevation="12"\n      height="200"\n      max-width="300"\n    >\n      <v-card-text>This card has negative top margin applied</v-card-text>\n    </v-card>\n  </div>\n</template>\n';
const _sfc_main = {
  data() {
    const spacers = Array.from({ length: 17 }, (val, i) => `${i}`);
    const nspacers = Array.from({ length: 16 }, (val, i) => `n${i + 1}`);
    const defaults = ["auto", ...spacers];
    return {
      directions: ["t", "b", "l", "r", "s", "e", "x", "y", "a"],
      marginDirection: "a",
      marginSize: "2",
      marginSizes: [...defaults, ...nspacers],
      paddingDirection: "a",
      paddingSize: "6",
      paddingSizes: defaults,
      playgroundText: "Use the controls above to try out the different spacing helpers."
    };
  },
  computed: {
    computedPadding() {
      return `p${this.paddingDirection}-${this.paddingSize}`;
    },
    computedMargin() {
      return `m${this.marginDirection}-${this.marginSize}`;
    }
  }
};
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("strong", { class: "text-primary py-1" }, "p", -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("div", { class: "py-1" }, " - ", -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("strong", { class: "text-primary py-1" }, "m", -1);
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("div", { class: "py-1" }, " - ", -1);
const _hoisted_5 = ["textContent"];
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_v_select = resolveComponent("v-select");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_sheet = resolveComponent("v-sheet");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, {
    class: "spacing-playground pa-6",
    fluid: ""
  }, {
    default: withCtx(() => [
      createVNode(_component_v_row, null, {
        default: withCtx(() => [
          createVNode(_component_v_col, {
            class: "d-flex align-center",
            cols: "12",
            sm: "6"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_select, {
                modelValue: $data.paddingDirection,
                "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => $data.paddingDirection = $event),
                items: $data.directions,
                class: "pe-2",
                label: "Padding"
              }, {
                prepend: withCtx(() => [
                  _hoisted_1
                ]),
                "append-outer": withCtx(() => [
                  _hoisted_2
                ]),
                _: 1
              }, 8, ["modelValue", "items"]),
              createVNode(_component_v_select, {
                modelValue: $data.paddingSize,
                "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => $data.paddingSize = $event),
                items: $data.paddingSizes.slice(1),
                label: "Size"
              }, null, 8, ["modelValue", "items"])
            ]),
            _: 1
          }),
          createVNode(_component_v_col, {
            class: "d-flex",
            cols: "12",
            sm: "6"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_select, {
                modelValue: $data.marginDirection,
                "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => $data.marginDirection = $event),
                items: $data.directions,
                class: "pe-2",
                label: "Margin"
              }, {
                prepend: withCtx(() => [
                  _hoisted_3
                ]),
                "append-outer": withCtx(() => [
                  _hoisted_4
                ]),
                _: 1
              }, 8, ["modelValue", "items"]),
              createVNode(_component_v_select, {
                modelValue: $data.marginSize,
                "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => $data.marginSize = $event),
                items: $data.marginSizes,
                label: "Size"
              }, null, 8, ["modelValue", "items"])
            ]),
            _: 1
          }),
          createVNode(_component_v_col, {
            class: "bg-orange-lighten-3 pa-0",
            cols: "12"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, {
                class: normalizeClass([$options.computedMargin]),
                elevation: "4",
                rounded: ""
              }, {
                default: withCtx(() => [
                  createBaseVNode("div", {
                    class: normalizeClass([[$options.computedPadding], "bg-light-green-lighten-3"])
                  }, [
                    createBaseVNode("div", {
                      class: "bg-white text-center py-6",
                      textContent: toDisplayString($data.playgroundText)
                    }, null, 8, _hoisted_5)
                  ], 2)
                ]),
                _: 1
              }, 8, ["class"])
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __4 = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
const __4_raw = `<template>
  <v-container
    class="spacing-playground pa-6"
    fluid
  >
    <v-row>
      <v-col
        class="d-flex align-center"
        cols="12"
        sm="6"
      >
        <v-select
          v-model="paddingDirection"
          :items="directions"
          class="pe-2"
          label="Padding"
        >
          <template v-slot:prepend>
            <strong class="text-primary py-1">p</strong>
          </template>

          <template v-slot:append-outer>
            <div class="py-1">
              -
            </div>
          </template>
        </v-select>

        <v-select
          v-model="paddingSize"
          :items="paddingSizes.slice(1)"
          label="Size"
        ></v-select>
      </v-col>

      <v-col
        class="d-flex"
        cols="12"
        sm="6"
      >
        <v-select
          v-model="marginDirection"
          :items="directions"
          class="pe-2"
          label="Margin"
        >
          <template v-slot:prepend>
            <strong class="text-primary py-1">m</strong>
          </template>

          <template v-slot:append-outer>
            <div class="py-1">
              -
            </div>
          </template>
        </v-select>

        <v-select
          v-model="marginSize"
          :items="marginSizes"
          label="Size"
        ></v-select>
      </v-col>

      <v-col
        class="bg-orange-lighten-3 pa-0"
        cols="12"
      >
        <v-sheet
          :class="[computedMargin]"
          elevation="4"
          rounded
        >
          <div
            :class="[computedPadding]"
            class="bg-light-green-lighten-3"
          >
            <div
              class="bg-white text-center py-6"
              v-text="playgroundText"
            ></div>
          </div>
        </v-sheet>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
  export default {
    data () {
      const spacers = Array.from({ length: 17 }, (val, i) => \`\${i}\`)
      const nspacers = Array.from({ length: 16 }, (val, i) => \`n\${i + 1}\`)
      const defaults = ['auto', ...spacers]

      return {
        directions: ['t', 'b', 'l', 'r', 's', 'e', 'x', 'y', 'a'],
        marginDirection: 'a',
        marginSize: '2',
        marginSizes: [...defaults, ...nspacers],
        paddingDirection: 'a',
        paddingSize: '6',
        paddingSizes: defaults,
        playgroundText: 'Use the controls above to try out the different spacing helpers.',
      }
    },

    computed: {
      computedPadding () {
        return \`p\${this.paddingDirection}-\${this.paddingSize}\`
      },
      computedMargin () {
        return \`m\${this.marginDirection}-\${this.marginSize}\`
      },
    },
  }
<\/script>
`;
const spacing = {
  "breakpoints": {
    component: __0,
    source: __0_raw
  },
  "gap": {
    component: __1,
    source: __1_raw
  },
  "horizontal": {
    component: __2,
    source: __2_raw
  },
  "negative-margin": {
    component: __3,
    source: __3_raw
  },
  "usage": {
    component: __4,
    source: __4_raw
  }
};
export {
  spacing as default
};
