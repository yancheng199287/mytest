import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "spacing" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "Update your layout without creating new classes. Spacing helpers are useful for modifying the padding and margin of an element.", -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Use the playground to get a feel for what the different helper classes can do. For an explanation of "),
  /* @__PURE__ */ createBaseVNode("strong", null, "how they work"),
  /* @__PURE__ */ createTextVNode(", see the How it works section below.")
], -1);
const _hoisted_4 = { id: "how-it-works" };
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The helper classes apply "),
  /* @__PURE__ */ createBaseVNode("strong", null, "margin"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "padding"),
  /* @__PURE__ */ createTextVNode(", or "),
  /* @__PURE__ */ createBaseVNode("strong", null, "gap"),
  /* @__PURE__ */ createTextVNode(" to an element ranging from "),
  /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "0 to 16"),
  /* @__PURE__ */ createTextVNode(". Each size increment was designed to align with common Material Design spacings. These classes can be applied using the following format "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "{property}{direction}-{size}"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "property"),
  /* @__PURE__ */ createTextVNode(" applies the type of spacing:")
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "m"),
    /* @__PURE__ */ createTextVNode(" - applies "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "p"),
    /* @__PURE__ */ createTextVNode(" - applies "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "padding")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "g"),
    /* @__PURE__ */ createTextVNode(" - applies "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "gap")
  ])
], -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "direction"),
  /* @__PURE__ */ createTextVNode(" designates the side the property applies to:")
], -1);
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "t"),
    /* @__PURE__ */ createTextVNode(" - applies the spacing for "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin-top"),
    /* @__PURE__ */ createTextVNode(" and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "padding-top")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "b"),
    /* @__PURE__ */ createTextVNode(" - applies the spacing for "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin-bottom"),
    /* @__PURE__ */ createTextVNode(" and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "padding-bottom")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "l"),
    /* @__PURE__ */ createTextVNode(" - applies the spacing for "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin-left"),
    /* @__PURE__ */ createTextVNode(" and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "padding-left")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "r"),
    /* @__PURE__ */ createTextVNode(" - applies the spacing for "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin-right"),
    /* @__PURE__ */ createTextVNode(", "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "padding-right"),
    /* @__PURE__ */ createTextVNode(", and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "row-gap")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "s"),
    /* @__PURE__ */ createTextVNode(" - applies the spacing for "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin-left"),
    /* @__PURE__ */ createTextVNode("/"),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "padding-left"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "(in LTR mode)"),
    /* @__PURE__ */ createTextVNode(" and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin-right"),
    /* @__PURE__ */ createTextVNode("/"),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "padding-right"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "(in RTL mode)")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "e"),
    /* @__PURE__ */ createTextVNode(" - applies the spacing for "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin-right"),
    /* @__PURE__ */ createTextVNode("/"),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "padding-right"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "(in LTR mode)"),
    /* @__PURE__ */ createTextVNode(" and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin-left"),
    /* @__PURE__ */ createTextVNode("/"),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "padding-left"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "(in RTL mode)")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "x"),
    /* @__PURE__ */ createTextVNode(" - applies the spacing for margin and padding "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "*-left"),
    /* @__PURE__ */ createTextVNode(" and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "*-right")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "y"),
    /* @__PURE__ */ createTextVNode(" - applies the spacing for margin and padding "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "*-top"),
    /* @__PURE__ */ createTextVNode(" and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "*-bottom")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "a"),
    /* @__PURE__ */ createTextVNode(" - applies the spacing for "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin"),
    /* @__PURE__ */ createTextVNode(", "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "padding"),
    /* @__PURE__ */ createTextVNode(" and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "gap"),
    /* @__PURE__ */ createTextVNode(" in all directions")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "c"),
    /* @__PURE__ */ createTextVNode(" - applies the spacing for "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "column-gap")
  ])
], -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "size"),
  /* @__PURE__ */ createTextVNode(" controls the increment of the property in 4px intervals:")
], -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "0"),
    /* @__PURE__ */ createTextVNode(" - eliminates all "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin"),
    /* @__PURE__ */ createTextVNode(", "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "padding"),
    /* @__PURE__ */ createTextVNode(" or "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "gap"),
    /* @__PURE__ */ createTextVNode(" by setting it to "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "0")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "1"),
    /* @__PURE__ */ createTextVNode(" - sets "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin"),
    /* @__PURE__ */ createTextVNode(", "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "padding"),
    /* @__PURE__ */ createTextVNode(" or "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "gap"),
    /* @__PURE__ */ createTextVNode(" to 4px")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "2"),
    /* @__PURE__ */ createTextVNode(" - sets "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin"),
    /* @__PURE__ */ createTextVNode(", "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "padding"),
    /* @__PURE__ */ createTextVNode(" or "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "gap"),
    /* @__PURE__ */ createTextVNode(" to 8px")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "3"),
    /* @__PURE__ */ createTextVNode(" - sets "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin"),
    /* @__PURE__ */ createTextVNode(", "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "padding"),
    /* @__PURE__ */ createTextVNode(" or "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "gap"),
    /* @__PURE__ */ createTextVNode(" to 12px")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "4"),
    /* @__PURE__ */ createTextVNode(" - sets "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin"),
    /* @__PURE__ */ createTextVNode(", "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "padding"),
    /* @__PURE__ */ createTextVNode(" or "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "gap"),
    /* @__PURE__ */ createTextVNode(" to 16px")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "5"),
    /* @__PURE__ */ createTextVNode(" - sets "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin"),
    /* @__PURE__ */ createTextVNode(", "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "padding"),
    /* @__PURE__ */ createTextVNode(" or "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "gap"),
    /* @__PURE__ */ createTextVNode(" to 20px")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "6"),
    /* @__PURE__ */ createTextVNode(" - sets "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin"),
    /* @__PURE__ */ createTextVNode(", "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "padding"),
    /* @__PURE__ */ createTextVNode(" or "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "gap"),
    /* @__PURE__ */ createTextVNode(" to 24px")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "7"),
    /* @__PURE__ */ createTextVNode(" - sets "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin"),
    /* @__PURE__ */ createTextVNode(", "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "padding"),
    /* @__PURE__ */ createTextVNode(" or "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "gap"),
    /* @__PURE__ */ createTextVNode(" to 28px")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "8"),
    /* @__PURE__ */ createTextVNode(" - sets "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin"),
    /* @__PURE__ */ createTextVNode(", "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "padding"),
    /* @__PURE__ */ createTextVNode(" or "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "gap"),
    /* @__PURE__ */ createTextVNode(" to 32px")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "9"),
    /* @__PURE__ */ createTextVNode(" - sets "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin"),
    /* @__PURE__ */ createTextVNode(", "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "padding"),
    /* @__PURE__ */ createTextVNode(" or "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "gap"),
    /* @__PURE__ */ createTextVNode(" to 36px")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "10"),
    /* @__PURE__ */ createTextVNode(" - sets "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin"),
    /* @__PURE__ */ createTextVNode(", "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "padding"),
    /* @__PURE__ */ createTextVNode(" or "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "gap"),
    /* @__PURE__ */ createTextVNode(" to 40px")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "11"),
    /* @__PURE__ */ createTextVNode(" - sets "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin"),
    /* @__PURE__ */ createTextVNode(", "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "padding"),
    /* @__PURE__ */ createTextVNode(" or "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "gap"),
    /* @__PURE__ */ createTextVNode(" to 44px")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "12"),
    /* @__PURE__ */ createTextVNode(" - sets "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin"),
    /* @__PURE__ */ createTextVNode(", "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "padding"),
    /* @__PURE__ */ createTextVNode(" or "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "gap"),
    /* @__PURE__ */ createTextVNode(" to 48px")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "13"),
    /* @__PURE__ */ createTextVNode(" - sets "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin"),
    /* @__PURE__ */ createTextVNode(", "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "padding"),
    /* @__PURE__ */ createTextVNode(" or "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "gap"),
    /* @__PURE__ */ createTextVNode(" to 52px")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "14"),
    /* @__PURE__ */ createTextVNode(" - sets "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin"),
    /* @__PURE__ */ createTextVNode(", "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "padding"),
    /* @__PURE__ */ createTextVNode(" or "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "gap"),
    /* @__PURE__ */ createTextVNode(" to 56px")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "15"),
    /* @__PURE__ */ createTextVNode(" - sets "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin"),
    /* @__PURE__ */ createTextVNode(", "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "padding"),
    /* @__PURE__ */ createTextVNode(" or "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "gap"),
    /* @__PURE__ */ createTextVNode(" to 60px")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "16"),
    /* @__PURE__ */ createTextVNode(" - sets "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin"),
    /* @__PURE__ */ createTextVNode(", "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "padding"),
    /* @__PURE__ */ createTextVNode(" or "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "gap"),
    /* @__PURE__ */ createTextVNode(" to 64px")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "n1"),
    /* @__PURE__ */ createTextVNode(" - sets "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin"),
    /* @__PURE__ */ createTextVNode(" to -4px")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "n2"),
    /* @__PURE__ */ createTextVNode(" - sets "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin"),
    /* @__PURE__ */ createTextVNode(" to -8px")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "n3"),
    /* @__PURE__ */ createTextVNode(" - sets "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin"),
    /* @__PURE__ */ createTextVNode(" to -12px")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "n4"),
    /* @__PURE__ */ createTextVNode(" - sets "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin"),
    /* @__PURE__ */ createTextVNode(" to -16px")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "n5"),
    /* @__PURE__ */ createTextVNode(" - sets "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin"),
    /* @__PURE__ */ createTextVNode(" to -20px")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "n6"),
    /* @__PURE__ */ createTextVNode(" - sets "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin"),
    /* @__PURE__ */ createTextVNode(" to -24px")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "n7"),
    /* @__PURE__ */ createTextVNode(" - sets "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin"),
    /* @__PURE__ */ createTextVNode(" to -28px")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "n8"),
    /* @__PURE__ */ createTextVNode(" - sets "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin"),
    /* @__PURE__ */ createTextVNode(" to -32px")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "n9"),
    /* @__PURE__ */ createTextVNode(" - sets "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin"),
    /* @__PURE__ */ createTextVNode(" to -36px")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "n10"),
    /* @__PURE__ */ createTextVNode(" - sets "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin"),
    /* @__PURE__ */ createTextVNode(" to -40px")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "n11"),
    /* @__PURE__ */ createTextVNode(" - sets "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin"),
    /* @__PURE__ */ createTextVNode(" to -44px")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "n12"),
    /* @__PURE__ */ createTextVNode(" - sets "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin"),
    /* @__PURE__ */ createTextVNode(" to -48px")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "n13"),
    /* @__PURE__ */ createTextVNode(" - sets "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin"),
    /* @__PURE__ */ createTextVNode(" to -52px")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "n14"),
    /* @__PURE__ */ createTextVNode(" - sets "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin"),
    /* @__PURE__ */ createTextVNode(" to -56px")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "n15"),
    /* @__PURE__ */ createTextVNode(" - sets "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin"),
    /* @__PURE__ */ createTextVNode(" to -60px")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "n16"),
    /* @__PURE__ */ createTextVNode(" - sets "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "margin"),
    /* @__PURE__ */ createTextVNode(" to -64px")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "auto"),
    /* @__PURE__ */ createTextVNode(" - sets the spacing to "),
    /* @__PURE__ */ createBaseVNode("strong", null, "auto")
  ])
], -1);
const _hoisted_12 = { id: "examples" };
const _hoisted_13 = { id: "breakpoints" };
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("strong", null, "xs", -1);
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("strong", null, "sm", -1);
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("strong", null, "md", -1);
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("strong", null, "lg", -1);
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("strong", null, "xl", -1);
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("em", null, "Viewport Breakpoints", -1);
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The helper classes apply "),
  /* @__PURE__ */ createBaseVNode("strong", null, "margin"),
  /* @__PURE__ */ createTextVNode(" or "),
  /* @__PURE__ */ createBaseVNode("strong", null, "padding"),
  /* @__PURE__ */ createTextVNode(" at a given breakpoint. These classes can be applied using the following format: "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "{property}{direction}-{breakpoint}-{size}"),
  /* @__PURE__ */ createTextVNode(". This does not apply to "),
  /* @__PURE__ */ createBaseVNode("strong", null, "xs"),
  /* @__PURE__ */ createTextVNode(" as it is inferred; e.g. "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "ma-xs-2"),
  /* @__PURE__ */ createTextVNode(" equals "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "ma-2"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_21 = { id: "horizontal" };
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("p", null, "Margin helper classes let you easily center content horizontally.", -1);
const _hoisted_23 = { id: "gap" };
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("p", null, "Use the gap helper classes to easily apply a gap between content.", -1);
const _hoisted_25 = { id: "negative-margin" };
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Margin can also be applied negatively at the same "),
  /* @__PURE__ */ createBaseVNode("strong", null, "1 to 16"),
  /* @__PURE__ */ createTextVNode(" intervals.")
], -1);
const frontmatter = { "meta": { "title": "Spacing", "description": "Spacing helper classes allow you to apply margin or padding to any element in increments from 1 to 5.", "keywords": "spacing helper classes, spacing classes, vuetify spacing" }, "related": ["/styles/elevation/", "/styles/content/", "/components/grids/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "spacing",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "Spacing", "description": "Spacing helper classes allow you to apply margin or padding to any element in increments from 1 to 5.", "keywords": "spacing helper classes, spacing classes, vuetify spacing" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "title": "Spacing", "description": "Spacing helper classes allow you to apply margin or padding to any element in increments from 1 to 5.", "keywords": "spacing helper classes, spacing classes, vuetify spacing" }, "related": ["/styles/elevation/", "/styles/content/", "/components/grids/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_app_link = resolveComponent("app-link");
      const _component_features_breakpoints_table = resolveComponent("features-breakpoints-table");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#spacing",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Spacing")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_promoted_entry),
              _hoisted_3,
              createVNode(_component_examples_example, { file: "spacing/usage" }),
              createBaseVNode("section", _hoisted_4, [
                createVNode(_component_app_heading, {
                  href: "#how-it-works",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("How it works")
                  ]),
                  _: 1
                }),
                _hoisted_5,
                _hoisted_6,
                _hoisted_7,
                _hoisted_8,
                _hoisted_9,
                _hoisted_10,
                _hoisted_11
              ]),
              createBaseVNode("section", _hoisted_12, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_13, [
                  createVNode(_component_app_heading, {
                    href: "#breakpoints",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Breakpoints")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("p", null, [
                    createTextVNode("Vuetify comes with a 12 point grid system built using Flexbox. Spacing is used to create specific layouts within an application’s content. It consists of 5 media breakpoints used to target specific screen sizes or orientations: "),
                    _hoisted_14,
                    createTextVNode(", "),
                    _hoisted_15,
                    createTextVNode(", "),
                    _hoisted_16,
                    createTextVNode(", "),
                    _hoisted_17,
                    createTextVNode(" and "),
                    _hoisted_18,
                    createTextVNode(". The default resolutions are defined below in the "),
                    _hoisted_19,
                    createTextVNode(" table and can be modified by customizing the "),
                    createVNode(_component_app_link, { href: "/features/display-and-platform/" }, {
                      default: withCtx(() => [
                        createTextVNode("breakpoint service config")
                      ]),
                      _: 1
                    }),
                    createTextVNode(".")
                  ]),
                  createVNode(_component_features_breakpoints_table),
                  _hoisted_20,
                  createVNode(_component_examples_example, { file: "spacing/breakpoints" })
                ]),
                createBaseVNode("section", _hoisted_21, [
                  createVNode(_component_app_heading, {
                    href: "#horizontal",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Horizontal")
                    ]),
                    _: 1
                  }),
                  _hoisted_22,
                  createVNode(_component_examples_example, { file: "spacing/horizontal" })
                ]),
                createBaseVNode("section", _hoisted_23, [
                  createVNode(_component_app_heading, {
                    href: "#gap",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Gap")
                    ]),
                    _: 1
                  }),
                  _hoisted_24,
                  createVNode(_component_examples_example, { file: "spacing/gap" })
                ]),
                createBaseVNode("section", _hoisted_25, [
                  createVNode(_component_app_heading, {
                    href: "#negative-margin",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Negative margin")
                    ]),
                    _: 1
                  }),
                  _hoisted_26,
                  createVNode(_component_examples_example, { file: "spacing/negative-margin" })
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
