import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "sponsor-vuetify-development" };
const _hoisted_2 = { id: "preamble" };
const _hoisted_3 = { id: "one-time-donations" };
const _hoisted_4 = { id: "recurring-pledges" };
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Recurring pledges come with "),
  /* @__PURE__ */ createBaseVNode("strong", null, "exclusive"),
  /* @__PURE__ */ createTextVNode(" perks such as priority GitHub issues, application auditing, and having your logo placed on this website.")
], -1);
const _hoisted_6 = { id: "current-project-sponsors" };
const _hoisted_7 = { id: "special" };
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("p", null, "Thank you to our special sponsor. Your support is greatly appreciated.", -1);
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_10 = { id: "diamond" };
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("p", null, "These sponsors have pledged $1,500 per month.", -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_13 = { id: "platinum" };
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("p", null, "These sponsors have pledged $500 per month.", -1);
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_16 = { id: "gold" };
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("p", null, "These sponsors have pledged $250 per month.", -1);
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_19 = { id: "service" };
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("p", null, "These sponsors help keep the lights on by providing free services to the Vuetify project.", -1);
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_22 = { id: "affiliate" };
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("p", null, "We work with these companies to provide you with the best possible experience.", -1);
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_25 = { id: "bottom-line" };
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("If you run a business and are using Vuetify in a revenue-generating product, it makes business sense to sponsor Vuetify development: "),
  /* @__PURE__ */ createBaseVNode("em", null, "it ensures the project that your product relies on stays healthy and actively maintained"),
  /* @__PURE__ */ createTextVNode(". Vuetify is a "),
  /* @__PURE__ */ createBaseVNode("strong", null, "full-time"),
  /* @__PURE__ */ createTextVNode(" job for John and Heather; your sponsorship and contributions help support them.")
], -1);
const frontmatter = { "meta": { "nav": "Sponsors and backers", "title": "Sponsoring Vuetify", "description": "Help support Vuetify by backing the project. This helps with the maintenance of existing features and the development of new ones.", "keywords": "sponsor, backer, donations, patron, supporting vuetify, vuetify support" }, "related": ["/introduction/enterprise-support/", "/introduction/roadmap/", "/about/meet-the-team/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "sponsors-and-backers",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Sponsors and backers", "title": "Sponsoring Vuetify", "description": "Help support Vuetify by backing the project. This helps with the maintenance of existing features and the development of new ones.", "keywords": "sponsor, backer, donations, patron, supporting vuetify, vuetify support" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Sponsors and backers", "title": "Sponsoring Vuetify", "description": "Help support Vuetify by backing the project. This helps with the maintenance of existing features and the development of new ones.", "keywords": "sponsor, backer, donations, patron, supporting vuetify, vuetify support" }, "related": ["/introduction/enterprise-support/", "/introduction/roadmap/", "/about/meet-the-team/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_app_link = resolveComponent("app-link");
      const _component_page_features = resolveComponent("page-features");
      const _component_vo_promotions_card_vuetify = resolveComponent("vo-promotions-card-vuetify");
      const _component_sponser_sponsors = resolveComponent("sponser-sponsors");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#sponsor-vuetify-development",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Sponsor Vuetify development")
                ]),
                _: 1
              }),
              createBaseVNode("p", null, [
                createTextVNode("Vuetify is an "),
                createVNode(_component_app_link, { href: "https://github.com/vuetifyjs/vuetify/blob/master/LICENSE.md" }, {
                  default: withCtx(() => [
                    createTextVNode("MIT licensed")
                  ]),
                  _: 1
                }),
                createTextVNode(" open-source project that’s completely free to use.")
              ]),
              createVNode(_component_page_features),
              createVNode(_component_vo_promotions_card_vuetify),
              createBaseVNode("section", _hoisted_2, [
                createVNode(_component_app_heading, {
                  href: "#preamble",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Preamble")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("Vuetify is actively maintained by "),
                  createVNode(_component_app_link, { href: "https://github.com/johnleider" }, {
                    default: withCtx(() => [
                      createTextVNode("John")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" and "),
                  createVNode(_component_app_link, { href: "https://github.com/heatherleider" }, {
                    default: withCtx(() => [
                      createTextVNode("Heather")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" Leider as a full-time job. In addition, a Core team of open-source contributors help maintain and guide the future of the framework. The time and dedication it takes to maintain the core framework and ecosystem packages is substantial. You can support Vuetify’s open-source project by becoming a backer through one of the following methods:")
                ])
              ]),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#one-time-donations",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("One-time donations")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("One-time donations can be made through "),
                  createVNode(_component_app_link, { href: "https://paypal.me/vuetify" }, {
                    default: withCtx(() => [
                      createTextVNode("PayPal")
                    ]),
                    _: 1
                  }),
                  createTextVNode(".")
                ])
              ]),
              createBaseVNode("section", _hoisted_4, [
                createVNode(_component_app_heading, {
                  href: "#recurring-pledges",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Recurring Pledges")
                  ]),
                  _: 1
                }),
                _hoisted_5,
                createBaseVNode("ul", null, [
                  createBaseVNode("li", null, [
                    createVNode(_component_app_link, { href: "https://github.com/sponsors/johnleider" }, {
                      default: withCtx(() => [
                        createTextVNode("Become a backer or sponsor via GitHub")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" or "),
                    createVNode(_component_app_link, { href: "https://www.patreon.com/vuetify" }, {
                      default: withCtx(() => [
                        createTextVNode("Patreon")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" (goes directly to Vuetify to support John and Heather).")
                  ]),
                  createBaseVNode("li", null, [
                    createVNode(_component_app_link, { href: "https://opencollective.com/vuetify" }, {
                      default: withCtx(() => [
                        createTextVNode("Become a backer or sponsor through Open Collective")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" (a transparent fund for supporting the development and maintenance of Vuetify).")
                  ])
                ])
              ]),
              createBaseVNode("section", _hoisted_6, [
                createVNode(_component_app_heading, {
                  href: "#current-project-sponsors",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Current Project Sponsors")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("We thank all of our project sponsors for their continued support of Vuetify. If you have any questions about sponsorship, please reach out to "),
                  createVNode(_component_app_link, { href: "mailto:sponsor@vuetifyjs.com" }, {
                    default: withCtx(() => [
                      createTextVNode("sponsor@vuetifyjs.com")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" for more information.")
                ]),
                createBaseVNode("section", _hoisted_7, [
                  createVNode(_component_app_heading, {
                    href: "#special",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Special")
                    ]),
                    _: 1
                  }),
                  _hoisted_8,
                  createVNode(_component_sponser_sponsors, {
                    tier: "-2",
                    width: "240"
                  }),
                  _hoisted_9
                ]),
                createBaseVNode("section", _hoisted_10, [
                  createVNode(_component_app_heading, {
                    href: "#diamond",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Diamond")
                    ]),
                    _: 1
                  }),
                  _hoisted_11,
                  createVNode(_component_sponser_sponsors, { tier: "1" }),
                  _hoisted_12
                ]),
                createBaseVNode("section", _hoisted_13, [
                  createVNode(_component_app_heading, {
                    href: "#platinum",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Platinum")
                    ]),
                    _: 1
                  }),
                  _hoisted_14,
                  createVNode(_component_sponser_sponsors, { tier: "2" }),
                  _hoisted_15
                ]),
                createBaseVNode("section", _hoisted_16, [
                  createVNode(_component_app_heading, {
                    href: "#gold",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Gold")
                    ]),
                    _: 1
                  }),
                  _hoisted_17,
                  createVNode(_component_sponser_sponsors, { tier: "3" }),
                  _hoisted_18
                ]),
                createBaseVNode("section", _hoisted_19, [
                  createVNode(_component_app_heading, {
                    href: "#service",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Service")
                    ]),
                    _: 1
                  }),
                  _hoisted_20,
                  createVNode(_component_sponser_sponsors, { tier: "6" }),
                  _hoisted_21
                ]),
                createBaseVNode("section", _hoisted_22, [
                  createVNode(_component_app_heading, {
                    href: "#affiliate",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Affiliate")
                    ]),
                    _: 1
                  }),
                  _hoisted_23,
                  createVNode(_component_sponser_sponsors, { tier: "5" }),
                  _hoisted_24
                ])
              ]),
              createBaseVNode("section", _hoisted_25, [
                createVNode(_component_app_heading, {
                  href: "#bottom-line",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Bottom line")
                  ]),
                  _: 1
                }),
                _hoisted_26,
                createBaseVNode("p", null, [
                  createTextVNode("If you have any questions, please reach out to "),
                  createVNode(_component_app_link, { href: "mailto:sponsor@vuetifyjs.com" }, {
                    default: withCtx(() => [
                      createTextVNode("sponsor@vuetifyjs.com")
                    ]),
                    _: 1
                  }),
                  createTextVNode(".")
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
