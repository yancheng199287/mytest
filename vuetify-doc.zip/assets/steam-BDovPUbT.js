import { r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, b as createVNode, h as createTextVNode, e as createBaseVNode, l as createElementBlock, v as renderList, F as Fragment } from "./index-DGybHjCP.js";
const _hoisted_1 = { class: "d-flex px-2 my-2" };
const _hoisted_2 = { class: "d-flex px-2 my-2 align-center" };
const _hoisted_3 = { class: "px-2 my-2" };
const _sfc_main = {
  __name: "steam",
  setup(__props) {
    return (_ctx, _cache) => {
      const _component_v_spacer = resolveComponent("v-spacer");
      const _component_v_icon = resolveComponent("v-icon");
      const _component_v_system_bar = resolveComponent("v-system-bar");
      const _component_v_avatar = resolveComponent("v-avatar");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_app_bar = resolveComponent("v-app-bar");
      const _component_v_footer = resolveComponent("v-footer");
      const _component_v_text_field = resolveComponent("v-text-field");
      const _component_v_sheet = resolveComponent("v-sheet");
      const _component_v_divider = resolveComponent("v-divider");
      const _component_v_navigation_drawer = resolveComponent("v-navigation-drawer");
      const _component_v_slide_group_item = resolveComponent("v-slide-group-item");
      const _component_v_slide_group = resolveComponent("v-slide-group");
      const _component_v_col = resolveComponent("v-col");
      const _component_v_row = resolveComponent("v-row");
      const _component_v_container = resolveComponent("v-container");
      const _component_v_main = resolveComponent("v-main");
      const _component_v_app = resolveComponent("v-app");
      return openBlock(), createBlock(_component_v_app, { id: "inspire" }, {
        default: withCtx(() => [
          createVNode(_component_v_system_bar, null, {
            default: withCtx(() => [
              createVNode(_component_v_spacer),
              createVNode(_component_v_icon, null, {
                default: withCtx(() => [
                  createTextVNode("mdi-square")
                ]),
                _: 1
              }),
              createVNode(_component_v_icon, null, {
                default: withCtx(() => [
                  createTextVNode("mdi-circle")
                ]),
                _: 1
              }),
              createVNode(_component_v_icon, null, {
                default: withCtx(() => [
                  createTextVNode("mdi-triangle")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_app_bar, {
            color: "grey-lighten-4",
            height: "72",
            flat: ""
          }, {
            default: withCtx(() => [
              createVNode(_component_v_avatar, {
                class: "ms-2",
                color: "surface-variant",
                size: "32",
                variant: "flat"
              }),
              createVNode(_component_v_avatar, {
                class: "mx-2",
                color: "surface-variant",
                size: "32",
                variant: "flat"
              }),
              createVNode(_component_v_btn, {
                class: "me-2",
                color: "grey",
                height: "40",
                variant: "flat",
                width: "80"
              }),
              createVNode(_component_v_btn, {
                class: "me-2",
                color: "grey",
                height: "40",
                variant: "flat",
                width: "100"
              }),
              createVNode(_component_v_btn, {
                class: "me-2",
                color: "grey",
                height: "40",
                variant: "flat",
                width: "120"
              }),
              createVNode(_component_v_btn, {
                class: "me-2",
                color: "grey",
                height: "40",
                variant: "flat",
                width: "120"
              }),
              createVNode(_component_v_spacer)
            ]),
            _: 1
          }),
          createVNode(_component_v_footer, {
            color: "grey",
            height: "44",
            app: ""
          }),
          createVNode(_component_v_navigation_drawer, { floating: "" }, {
            default: withCtx(() => [
              createBaseVNode("div", _hoisted_1, [
                createVNode(_component_v_btn, {
                  class: "flex-grow-1",
                  color: "grey",
                  height: "40",
                  variant: "flat"
                }),
                createVNode(_component_v_avatar, {
                  class: "ms-2",
                  color: "surface-variant",
                  variant: "flat",
                  rounded: ""
                })
              ]),
              createBaseVNode("div", _hoisted_2, [
                createVNode(_component_v_btn, {
                  class: "flex-grow-1 me-2",
                  color: "grey-lighten-4",
                  height: "40",
                  variant: "flat"
                }),
                createVNode(_component_v_avatar, {
                  color: "surface-variant",
                  size: "18"
                }),
                createVNode(_component_v_avatar, {
                  class: "ms-1",
                  color: "surface-variant",
                  size: "18"
                })
              ]),
              createBaseVNode("div", _hoisted_3, [
                createVNode(_component_v_text_field, {
                  class: "mb-4",
                  density: "compact",
                  "prepend-inner-icon": "mdi-magnify",
                  variant: "solo-filled",
                  flat: "",
                  "hide-details": ""
                }),
                createVNode(_component_v_sheet, {
                  class: "mb-2",
                  color: "surface-variant",
                  height: "24",
                  rounded: "pill",
                  width: "50%"
                }),
                createVNode(_component_v_sheet, {
                  class: "mb-1",
                  color: "grey-lighten-1",
                  height: "12",
                  rounded: "pill",
                  width: "40%"
                }),
                createVNode(_component_v_sheet, {
                  class: "mb-1",
                  color: "grey-lighten-1",
                  height: "12",
                  rounded: "pill",
                  width: "20%"
                }),
                createVNode(_component_v_sheet, {
                  class: "mb-1",
                  color: "grey-lighten-1",
                  height: "12",
                  rounded: "pill",
                  width: "90%"
                }),
                createVNode(_component_v_sheet, {
                  color: "grey-lighten-1",
                  height: "12",
                  rounded: "pill",
                  width: "70%"
                }),
                createVNode(_component_v_divider, { class: "my-6" }),
                createVNode(_component_v_sheet, {
                  class: "mb-2",
                  color: "surface-variant",
                  height: "24",
                  rounded: "pill",
                  width: "30%"
                }),
                createVNode(_component_v_sheet, {
                  class: "mb-1",
                  color: "grey-lighten-1",
                  height: "12",
                  rounded: "pill",
                  width: "65%"
                }),
                createVNode(_component_v_sheet, {
                  class: "mb-1",
                  color: "grey-lighten-1",
                  height: "12",
                  rounded: "pill",
                  width: "70%"
                }),
                createVNode(_component_v_sheet, {
                  class: "mb-1",
                  color: "grey-lighten-1",
                  height: "12",
                  rounded: "pill",
                  width: "40%"
                }),
                createVNode(_component_v_sheet, {
                  color: "grey-lighten-1",
                  height: "12",
                  rounded: "pill",
                  width: "100%"
                }),
                createVNode(_component_v_divider, { class: "my-6" })
              ])
            ]),
            _: 1
          }),
          createVNode(_component_v_main, null, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, {
                class: "mx-auto pa-2 pt-6",
                color: "grey-lighten-4"
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_sheet, {
                    color: "grey-lighten-2",
                    height: "24",
                    rounded: "pill",
                    width: "88"
                  }),
                  createVNode(_component_v_slide_group, { "show-arrows": "" }, {
                    default: withCtx(() => [
                      (openBlock(), createElementBlock(Fragment, null, renderList(5, (n) => {
                        return createVNode(_component_v_slide_group_item, { key: n }, {
                          default: withCtx(() => [
                            createVNode(_component_v_sheet, {
                              class: "ma-3",
                              color: "grey-lighten-1",
                              height: "200",
                              width: "250",
                              rounded: ""
                            })
                          ]),
                          _: 2
                        }, 1024);
                      }), 64))
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }),
              createVNode(_component_v_sheet, {
                class: "mx-auto pa-2 pt-6",
                color: "grey-lighten-2"
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_sheet, {
                    color: "grey",
                    height: "24",
                    rounded: "pill",
                    width: "88"
                  }),
                  createVNode(_component_v_slide_group, { "show-arrows": "" }, {
                    default: withCtx(() => [
                      (openBlock(), createElementBlock(Fragment, null, renderList(15, (n) => {
                        return createVNode(_component_v_slide_group_item, { key: n }, {
                          default: withCtx(() => [
                            createVNode(_component_v_sheet, {
                              width: n === 1 ? 300 : 150,
                              class: "ma-3",
                              color: "grey-lighten-1",
                              height: "200",
                              rounded: ""
                            }, null, 8, ["width"])
                          ]),
                          _: 2
                        }, 1024);
                      }), 64))
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_container, { fluid: "" }, {
                    default: withCtx(() => [
                      createVNode(_component_v_row, null, {
                        default: withCtx(() => [
                          (openBlock(), createElementBlock(Fragment, null, renderList(24, (n) => {
                            return createVNode(_component_v_col, {
                              key: n,
                              cols: "2"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_v_sheet, {
                                  color: "grey-lighten-1",
                                  height: "200",
                                  rounded: ""
                                })
                              ]),
                              _: 2
                            }, 1024);
                          }), 64))
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __6 = _sfc_main;
export {
  __6 as _
};
