import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "steppers" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-stepper"),
  /* @__PURE__ */ createTextVNode(" component displays progress through numbered steps.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, "A stepper can be used for a multitude of scenarios, including shopping carts, record creation and more.", -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Due to the massive differences in display and functionality between horizontal and vertical steppers, the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "vertical"),
  /* @__PURE__ */ createTextVNode(" property is moving to a new component "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-stepper-vertical"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_6 = { id: "api" };
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("td", null, "Actions for stepper", -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("td", null, "Container for stepper items", -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("td", null, "Window container for stepper window items", -1);
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("td", null, "Items for stepper window", -1);
const _hoisted_14 = { id: "anatomy" };
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The recommended placement of elements inside of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-stepper"),
  /* @__PURE__ */ createTextVNode(" is:")
], -1);
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Place "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-stepper-header"),
    /* @__PURE__ */ createTextVNode(" on top")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Place "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-stepper-window"),
    /* @__PURE__ */ createTextVNode(" or other forms of content below the stepper header")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Place "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-stepper-actions"),
    /* @__PURE__ */ createTextVNode(" after the stepper window")
  ])
], -1);
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Element / Area"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("tr", null, [
  /* @__PURE__ */ createBaseVNode("td", null, "1. Container"),
  /* @__PURE__ */ createBaseVNode("td", null, [
    /* @__PURE__ */ createTextVNode("The Stepper container holds all "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-stepper"),
    /* @__PURE__ */ createTextVNode(" components and is composed of 3 major parts: "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-stepper-header"),
    /* @__PURE__ */ createTextVNode(", "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-stepper-window"),
    /* @__PURE__ */ createTextVNode(", and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-stepper-actions"),
    /* @__PURE__ */ createTextVNode(".")
  ])
], -1);
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("tr", null, [
  /* @__PURE__ */ createBaseVNode("td", null, "2. Header"),
  /* @__PURE__ */ createBaseVNode("td", null, [
    /* @__PURE__ */ createTextVNode("The header is the container for the "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-stepper-item"),
    /* @__PURE__ */ createTextVNode(" components.")
  ])
], -1);
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("tr", null, [
  /* @__PURE__ */ createBaseVNode("td", null, "3. Window"),
  /* @__PURE__ */ createBaseVNode("td", null, [
    /* @__PURE__ */ createTextVNode("The window is the container for the "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-stepper-window-item"),
    /* @__PURE__ */ createTextVNode(" components.")
  ])
], -1);
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("td", null, "4. Actions (optional)", -1);
const _hoisted_22 = { id: "guide" };
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-stepper"),
  /* @__PURE__ */ createTextVNode(" component provides a linear progression process for gathering and displaying information to a user, similar to a form wizard.")
], -1);
const _hoisted_24 = { id: "props" };
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-stepper"),
  /* @__PURE__ */ createTextVNode(" component has multiple props to customize its visual appearance and functionality.")
], -1);
const _hoisted_26 = { id: "non-editable-steps" };
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("p", null, "A basic stepper has non-editable steps that force a user to move linearly through your process.", -1);
const _hoisted_28 = { id: "editable-steps" };
const _hoisted_29 = /* @__PURE__ */ createBaseVNode("p", null, "An editable step can be selected by a user at any point and will navigate them to that step.", -1);
const _hoisted_30 = { id: "alternate-label" };
const _hoisted_31 = /* @__PURE__ */ createBaseVNode("p", null, "Steppers also have an alternative label style which places the title under the step itself.", -1);
const _hoisted_32 = { id: "linear-steppers" };
const _hoisted_33 = /* @__PURE__ */ createBaseVNode("p", null, "Linear steppers will always move a user through your defined path.", -1);
const _hoisted_34 = { id: "optional-steps" };
const _hoisted_35 = /* @__PURE__ */ createBaseVNode("p", null, "An optional step can be called out with sub-text.", -1);
const _hoisted_36 = { id: "items" };
const _hoisted_37 = /* @__PURE__ */ createBaseVNode("p", null, "If no value is provided, the stepper will assign a value based off of its index + 1", -1);
const _hoisted_38 = { id: "mobile" };
const _hoisted_39 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Use the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "mobile"),
  /* @__PURE__ */ createTextVNode(" prop to hide the title and subtitle of the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-stepper-item"),
  /* @__PURE__ */ createTextVNode(" component.")
], -1);
const _hoisted_40 = { id: "errors" };
const _hoisted_41 = /* @__PURE__ */ createBaseVNode("p", null, "An error state can be displayed to notify the user of some action that must be taken.", -1);
const _hoisted_42 = { id: "dynamic-steps" };
const _hoisted_43 = /* @__PURE__ */ createBaseVNode("p", null, "Steppers can have their steps dynamically added or removed. If a currently active step is removed, be sure to account for this by changing the applied model.", -1);
const _hoisted_44 = { id: "alternative-label-with-errors" };
const _hoisted_45 = /* @__PURE__ */ createBaseVNode("p", null, "The error state can also be applied to the alternative label style.", -1);
const _hoisted_46 = { id: "non-linear" };
const _hoisted_47 = /* @__PURE__ */ createBaseVNode("p", null, "Non-linear steppers allow the user to move through your process in whatever way they choose.", -1);
const frontmatter = { "meta": { "nav": "Steppers", "title": "Stepper component", "description": "The stepper component provides a linear progression process for gathering and displaying information to a user, similar to a form wizard.", "keywords": "steppers, vuetify stepper component, vue stepper component" }, "related": ["/components/tabs/", "/components/item-groups/", "/components/windows/"], "features": { "figma": true, "github": "/components/VStepper/", "label": "C: VStepper", "report": true, "spec": "https://m1.material.io/components/steppers.html" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "steppers",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Steppers", "title": "Stepper component", "description": "The stepper component provides a linear progression process for gathering and displaying information to a user, similar to a form wizard.", "keywords": "steppers, vuetify stepper component, vue stepper component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Steppers", "title": "Stepper component", "description": "The stepper component provides a linear progression process for gathering and displaying information to a user, similar to a form wizard.", "keywords": "steppers, vuetify stepper component, vue stepper component" }, "related": ["/components/tabs/", "/components/item-groups/", "/components/windows/"], "features": { "figma": true, "github": "/components/VStepper/", "label": "C: VStepper", "report": true, "spec": "https://m1.material.io/components/steppers.html" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_app_figure = resolveComponent("app-figure");
      const _component_page_features = resolveComponent("page-features");
      const _component_app_link = resolveComponent("app-link");
      const _component_alert = resolveComponent("alert");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#steppers",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Steppers")
                ]),
                _: 1
              }),
              _hoisted_2,
              createBaseVNode("p", null, [
                createBaseVNode("div", null, [
                  createVNode(_component_app_figure, {
                    alt: "Stepper Entry",
                    src: "https://cdn.vuetifyjs.com/docs/images/components/v-stepper/v-stepper-entry.png"
                  })
                ])
              ]),
              createVNode(_component_page_features),
              createVNode(_component_alert, { type: "success" }, {
                default: withCtx(() => [
                  createBaseVNode("p", null, [
                    createTextVNode("This feature was introduced in "),
                    createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v3.4.0" }, {
                      default: withCtx(() => [
                        createTextVNode("v3.4.0 (Blackguard)")
                      ]),
                      _: 1
                    })
                  ])
                ]),
                _: 1
              }),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_usage, { name: "v-stepper" }),
                createVNode(_component_promoted_entry),
                createVNode(_component_alert, { type: "warning" }, {
                  default: withCtx(() => [
                    _hoisted_5
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_6, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_7,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-stepper/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-stepper")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_8
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-stepper-actions/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-stepper-actions")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_9
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-stepper-header/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-stepper-header")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_10
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-stepper-item/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-stepper-item")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_11
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-stepper-window/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-stepper-window")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_12
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-stepper-window-item/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-stepper-window-item")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_13
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_14, [
                createVNode(_component_app_heading, {
                  href: "#anatomy",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Anatomy")
                  ]),
                  _: 1
                }),
                _hoisted_15,
                _hoisted_16,
                createBaseVNode("p", null, [
                  createBaseVNode("div", null, [
                    createVNode(_component_app_figure, {
                      alt: "Pending graphic",
                      src: "https://cdn.vuetifyjs.com/docs/images/components/v-stepper/v-stepper-anatomy.png",
                      title: "Stepper Anatomy"
                    })
                  ])
                ]),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_17,
                    createBaseVNode("tbody", null, [
                      _hoisted_18,
                      _hoisted_19,
                      _hoisted_20,
                      createBaseVNode("tr", null, [
                        _hoisted_21,
                        createBaseVNode("td", null, [
                          createTextVNode("A content area that typically contains one or more "),
                          createVNode(_component_app_link, { href: "/components/buttons" }, {
                            default: withCtx(() => [
                              createTextVNode("v-btn")
                            ]),
                            _: 1
                          }),
                          createTextVNode(" components")
                        ])
                      ])
                    ])
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_22, [
                createVNode(_component_app_heading, {
                  href: "#guide",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Guide")
                  ]),
                  _: 1
                }),
                _hoisted_23,
                createBaseVNode("section", _hoisted_24, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  _hoisted_25,
                  createBaseVNode("section", _hoisted_26, [
                    createVNode(_component_app_heading, {
                      href: "#non-editable-steps",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Non editable steps")
                      ]),
                      _: 1
                    }),
                    _hoisted_27,
                    createVNode(_component_examples_example, { file: "v-stepper/misc-non-editable" })
                  ]),
                  createBaseVNode("section", _hoisted_28, [
                    createVNode(_component_app_heading, {
                      href: "#editable-steps",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Editable steps")
                      ]),
                      _: 1
                    }),
                    _hoisted_29,
                    createVNode(_component_examples_example, { file: "v-stepper/misc-editable" })
                  ]),
                  createBaseVNode("section", _hoisted_30, [
                    createVNode(_component_app_heading, {
                      href: "#alternate-label",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Alternate label")
                      ]),
                      _: 1
                    }),
                    _hoisted_31,
                    createVNode(_component_examples_example, { file: "v-stepper/prop-alternate-label" })
                  ]),
                  createBaseVNode("section", _hoisted_32, [
                    createVNode(_component_app_heading, {
                      href: "#linear-steppers",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Linear steppers")
                      ]),
                      _: 1
                    }),
                    _hoisted_33,
                    createVNode(_component_examples_example, { file: "v-stepper/misc-linear" })
                  ]),
                  createBaseVNode("section", _hoisted_34, [
                    createVNode(_component_app_heading, {
                      href: "#optional-steps",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Optional steps")
                      ]),
                      _: 1
                    }),
                    _hoisted_35,
                    createVNode(_component_examples_example, { file: "v-stepper/misc-optional" })
                  ]),
                  createBaseVNode("section", _hoisted_36, [
                    createVNode(_component_app_heading, {
                      href: "#items",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Items")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("The stepper component accepts an array of items similar to other components such as "),
                      createVNode(_component_app_link, { href: "/components/lists/" }, {
                        default: withCtx(() => [
                          createTextVNode("v-list")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" and "),
                      createVNode(_component_app_link, { href: "/components/selects/" }, {
                        default: withCtx(() => [
                          createTextVNode("v-select")
                        ]),
                        _: 1
                      }),
                      createTextVNode(".")
                    ]),
                    createVNode(_component_examples_example, { file: "v-stepper/misc-horizontal" }),
                    createVNode(_component_alert, { type: "warning" }, {
                      default: withCtx(() => [
                        _hoisted_37
                      ]),
                      _: 1
                    })
                  ]),
                  createBaseVNode("section", _hoisted_38, [
                    createVNode(_component_app_heading, {
                      href: "#mobile",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Mobile")
                      ]),
                      _: 1
                    }),
                    _hoisted_39,
                    createVNode(_component_examples_example, { file: "v-stepper/prop-mobile" })
                  ]),
                  createBaseVNode("section", _hoisted_40, [
                    createVNode(_component_app_heading, {
                      href: "#errors",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Errors")
                      ]),
                      _: 1
                    }),
                    _hoisted_41,
                    createVNode(_component_examples_example, { file: "v-stepper/misc-error" })
                  ]),
                  createBaseVNode("section", _hoisted_42, [
                    createVNode(_component_app_heading, {
                      href: "#dynamic-steps",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Dynamic steps")
                      ]),
                      _: 1
                    }),
                    _hoisted_43,
                    createVNode(_component_examples_example, { file: "v-stepper/misc-dynamic" })
                  ]),
                  createBaseVNode("section", _hoisted_44, [
                    createVNode(_component_app_heading, {
                      href: "#alternative-label-with-errors",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Alternative label with errors")
                      ]),
                      _: 1
                    }),
                    _hoisted_45,
                    createVNode(_component_examples_example, { file: "v-stepper/misc-alternate-error" })
                  ]),
                  createBaseVNode("section", _hoisted_46, [
                    createVNode(_component_app_heading, {
                      href: "#non-linear",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Non linear")
                      ]),
                      _: 1
                    }),
                    _hoisted_47,
                    createVNode(_component_examples_example, { file: "v-stepper/prop-non-linear" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
