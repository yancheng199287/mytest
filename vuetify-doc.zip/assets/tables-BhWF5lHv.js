import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "tables" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The simpler of the table components is "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-table"),
  /* @__PURE__ */ createTextVNode(", a basic wrapper component for the HTML "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<table>"),
  /* @__PURE__ */ createTextVNode(" element. In addition, regular table elements such as "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<thead>"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<tbody>"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<tr>"),
  /* @__PURE__ */ createTextVNode(", and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<td>"),
  /* @__PURE__ */ createTextVNode(" work by default.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = { id: "api" };
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_7 = { id: "examples" };
const _hoisted_8 = { id: "props" };
const _hoisted_9 = { id: "theme" };
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Use "),
  /* @__PURE__ */ createBaseVNode("strong", null, "theme"),
  /* @__PURE__ */ createTextVNode(" prop to switch table to another theme.")
], -1);
const _hoisted_11 = { id: "density" };
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can show a dense version of the table by using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "density"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_13 = { id: "height" };
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Use the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "height"),
  /* @__PURE__ */ createTextVNode(" prop to set the height of the table.")
], -1);
const _hoisted_15 = { id: "fixed-header" };
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Use the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "fixed-header"),
  /* @__PURE__ */ createTextVNode(" prop together with the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "height"),
  /* @__PURE__ */ createTextVNode(" prop to fix the header to the top of the table.")
], -1);
const frontmatter = { "meta": { "nav": "Tables", "title": "Table", "description": "The table component is a lightweight wrapper around the table element that provides a Material Design feel without all the baggage.", "keywords": "table, simple table, vuetify table component, vue simple table component, table component" }, "related": ["/components/data-tables/basics/", "/components/data-tables/headers/", "/components/lists/"], "features": { "github": "/components/VTable/", "label": "C: VTable", "report": true, "spec": "https://m2.material.io/components/data-tables" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "tables",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Tables", "title": "Table", "description": "The table component is a lightweight wrapper around the table element that provides a Material Design feel without all the baggage.", "keywords": "table, simple table, vuetify table component, vue simple table component, table component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Tables", "title": "Table", "description": "The table component is a lightweight wrapper around the table element that provides a Material Design feel without all the baggage.", "keywords": "table, simple table, vuetify table component, vue simple table component, table component" }, "related": ["/components/data-tables/basics/", "/components/data-tables/headers/", "/components/lists/"], "features": { "github": "/components/VTable/", "label": "C: VTable", "report": true, "spec": "https://m2.material.io/components/data-tables" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_app_link = resolveComponent("app-link");
      const _component_alert = resolveComponent("alert");
      const _component_page_features = resolveComponent("page-features");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#tables",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Tables")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_alert, { type: "info" }, {
                default: withCtx(() => [
                  createBaseVNode("p", null, [
                    createTextVNode("More advanced tables such as "),
                    createVNode(_component_app_link, { href: "/components/data-tables/basics/" }, {
                      default: withCtx(() => [
                        createTextVNode("v-data-table")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" are available for preview in "),
                    createVNode(_component_app_link, { href: "/labs/introduction/" }, {
                      default: withCtx(() => [
                        createTextVNode("Vuetify Labs")
                      ]),
                      _: 1
                    }),
                    createTextVNode(".")
                  ])
                ]),
                _: 1
              }),
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                createVNode(_component_examples_example, { file: "v-table/usage" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_4, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_5,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-table/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-table")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_6
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_7, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_8, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_9, [
                    createVNode(_component_app_heading, {
                      href: "#theme",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Theme")
                      ]),
                      _: 1
                    }),
                    _hoisted_10,
                    createVNode(_component_examples_example, { file: "v-table/prop-dark" })
                  ]),
                  createBaseVNode("section", _hoisted_11, [
                    createVNode(_component_app_heading, {
                      href: "#density",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Density")
                      ]),
                      _: 1
                    }),
                    _hoisted_12,
                    createVNode(_component_examples_example, { file: "v-table/prop-dense" })
                  ]),
                  createBaseVNode("section", _hoisted_13, [
                    createVNode(_component_app_heading, {
                      href: "#height",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Height")
                      ]),
                      _: 1
                    }),
                    _hoisted_14,
                    createVNode(_component_examples_example, { file: "v-table/prop-height" })
                  ]),
                  createBaseVNode("section", _hoisted_15, [
                    createVNode(_component_app_heading, {
                      href: "#fixed-header",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Fixed header")
                      ]),
                      _: 1
                    }),
                    _hoisted_16,
                    createVNode(_component_examples_example, { file: "v-table/prop-fixed-header" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
