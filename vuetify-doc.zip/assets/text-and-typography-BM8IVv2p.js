import { y as _export_sfc, o as openBlock, l as createElementBlock, ao as createStaticVNode, e as createBaseVNode, r as resolveComponent, b as createVNode, w as withCtx, h as createTextVNode, F as Fragment, v as renderList, U as normalizeClass, t as toDisplayString } from "./index-DGybHjCP.js";
const _sfc_main$b = {};
const _hoisted_1$b = /* @__PURE__ */ createStaticVNode('<p class="font-weight-black"> Black text. </p><p class="font-weight-bold"> Bold text. </p><p class="font-weight-medium"> Medium weight text. </p><p class="font-weight-regular"> Normal weight text. </p><p class="font-weight-light"> Light weight text. </p><p class="font-weight-thin"> Thin weight text. </p><p class="font-italic"> Italic text. </p>', 7);
const _hoisted_8$1 = [
  _hoisted_1$b
];
function _sfc_render$a(_ctx, _cache) {
  return openBlock(), createElementBlock("div", null, _hoisted_8$1);
}
const __0 = /* @__PURE__ */ _export_sfc(_sfc_main$b, [["render", _sfc_render$a]]);
const __0_raw = '<template>\n  <div>\n    <p class="font-weight-black">\n      Black text.\n    </p>\n    <p class="font-weight-bold">\n      Bold text.\n    </p>\n    <p class="font-weight-medium">\n      Medium weight text.\n    </p>\n    <p class="font-weight-regular">\n      Normal weight text.\n    </p>\n    <p class="font-weight-light">\n      Light weight text.\n    </p>\n    <p class="font-weight-thin">\n      Thin weight text.\n    </p>\n    <p class="font-italic">\n      Italic text.\n    </p>\n  </div>\n</template>\n';
const _sfc_main$a = {};
const _hoisted_1$a = /* @__PURE__ */ createStaticVNode('<p class="text-left"> Left aligned on all viewport sizes. </p><p class="text-center"> Center aligned on all viewport sizes. </p><p class="text-right"> Right aligned on all viewport sizes. </p><p class="text-sm-left"> Left aligned on viewports SM (small) or wider. </p><p class="text-right text-md-left"> Left aligned on viewports MD (medium) or wider. </p><p class="text-right text-lg-left"> Left aligned on viewports LG (large) or wider. </p><p class="text-right text-xl-left"> Left aligned on viewports XL (extra-large) or wider. </p>', 7);
const _hoisted_8 = [
  _hoisted_1$a
];
function _sfc_render$9(_ctx, _cache) {
  return openBlock(), createElementBlock("div", null, _hoisted_8);
}
const __1 = /* @__PURE__ */ _export_sfc(_sfc_main$a, [["render", _sfc_render$9]]);
const __1_raw = '<template>\n  <div>\n    <p class="text-left">\n      Left aligned on all viewport sizes.\n    </p>\n    <p class="text-center">\n      Center aligned on all viewport sizes.\n    </p>\n    <p class="text-right">\n      Right aligned on all viewport sizes.\n    </p>\n\n    <p class="text-sm-left">\n      Left aligned on viewports SM (small) or wider.\n    </p>\n    <p class="text-right text-md-left">\n      Left aligned on viewports MD (medium) or wider.\n    </p>\n    <p class="text-right text-lg-left">\n      Left aligned on viewports LG (large) or wider.\n    </p>\n    <p class="text-right text-xl-left">\n      Left aligned on viewports XL (extra-large) or wider.\n    </p>\n  </div>\n</template>\n';
const _sfc_main$9 = {};
const _hoisted_1$9 = /* @__PURE__ */ createStaticVNode('<p class="text-left"> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p><p class="text-right"> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p><p class="text-center"> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p><p class="text-justify"> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p><p class="text-start"> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p><p class="text-end"> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>', 6);
const _hoisted_7$1 = [
  _hoisted_1$9
];
function _sfc_render$8(_ctx, _cache) {
  return openBlock(), createElementBlock("div", null, _hoisted_7$1);
}
const __2 = /* @__PURE__ */ _export_sfc(_sfc_main$9, [["render", _sfc_render$8]]);
const __2_raw = '<template>\n  <div>\n    <p class="text-left">\n      Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.\n    </p>\n\n    <p class="text-right">\n      Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.\n    </p>\n\n    <p class="text-center">\n      Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.\n    </p>\n\n    <p class="text-justify">\n      Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.\n    </p>\n\n    <p class="text-start">\n      Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.\n    </p>\n\n    <p class="text-end">\n      Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.\n    </p>\n  </div>\n</template>\n';
const _sfc_main$8 = {};
const _hoisted_1$8 = /* @__PURE__ */ createBaseVNode("p", { class: "custom-transform-class text-none" }, " Random TEXT cApitaLization ", -1);
const _hoisted_2$5 = /* @__PURE__ */ createBaseVNode("p", {
  class: "text-break",
  style: { "max-width": "4rem" }
}, " SUBDERMATOGLYPHIC ", -1);
const _hoisted_3$4 = [
  _hoisted_1$8,
  _hoisted_2$5
];
function _sfc_render$7(_ctx, _cache) {
  return openBlock(), createElementBlock("div", null, _hoisted_3$4);
}
const __3 = /* @__PURE__ */ _export_sfc(_sfc_main$8, [["render", _sfc_render$7]]);
const __3_raw = '<template>\n  <div>\n    <p class="custom-transform-class text-none">\n      Random TEXT cApitaLization\n    </p>\n    <p\n      class="text-break"\n      style="max-width: 4rem;"\n    >\n      SUBDERMATOGLYPHIC\n    </p>\n  </div>\n</template>\n\n<style lang="sass">\n  .custom-transform-class\n    text-transform: uppercase\n</style>\n';
const _sfc_main$7 = {};
const _hoisted_1$7 = { class: "d-flex justify-space-between flex-row" };
const _hoisted_2$4 = /* @__PURE__ */ createBaseVNode("a", {
  class: "text-decoration-none",
  href: "#"
}, " Non-underlined link ", -1);
const _hoisted_3$3 = /* @__PURE__ */ createBaseVNode("div", { class: "text-decoration-line-through" }, " Line-through text ", -1);
const _hoisted_4$2 = /* @__PURE__ */ createBaseVNode("div", { class: "text-decoration-overline" }, " Overline text ", -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("div", { class: "text-decoration-underline" }, " Underline text ", -1);
const _hoisted_6 = [
  _hoisted_2$4,
  _hoisted_3$3,
  _hoisted_4$2,
  _hoisted_5
];
function _sfc_render$6(_ctx, _cache) {
  return openBlock(), createElementBlock("div", _hoisted_1$7, _hoisted_6);
}
const __4 = /* @__PURE__ */ _export_sfc(_sfc_main$7, [["render", _sfc_render$6]]);
const __4_raw = '<template>\n  <div class="d-flex justify-space-between flex-row">\n    <a\n      class="text-decoration-none"\n      href="#"\n    >\n      Non-underlined link\n    </a>\n\n    <div class="text-decoration-line-through">\n      Line-through text\n    </div>\n\n    <div class="text-decoration-overline">\n      Overline text\n    </div>\n\n    <div class="text-decoration-underline">\n      Underline text\n    </div>\n  </div>\n</template>\n';
const _sfc_main$6 = {};
const _hoisted_1$6 = {
  class: "text-no-wrap bg-secondary",
  style: { "width": "8rem" }
};
function _sfc_render$5(_ctx, _cache) {
  return openBlock(), createElementBlock("div", _hoisted_1$6, " This text should overflow the parent. ");
}
const __5 = /* @__PURE__ */ _export_sfc(_sfc_main$6, [["render", _sfc_render$5]]);
const __5_raw = '<template>\n  <div\n    class="text-no-wrap bg-secondary"\n    style="width: 8rem;"\n  >\n    This text should overflow the parent.\n  </div>\n</template>\n';
const _sfc_main$5 = {};
const _hoisted_1$5 = /* @__PURE__ */ createBaseVNode("p", { class: "text-high-emphasis" }, " High-emphasis has an opacity of 87% in light theme and 100% in dark. ", -1);
const _hoisted_2$3 = /* @__PURE__ */ createBaseVNode("p", { class: "text-medium-emphasis" }, " Medium-emphasis text and hint text have opacities of 60% in light theme and 70% in dark. ", -1);
const _hoisted_3$2 = /* @__PURE__ */ createBaseVNode("p", { class: "text-disabled" }, " Disabled text has an opacity of 38% in light theme and 50% in dark. ", -1);
const _hoisted_4$1 = [
  _hoisted_1$5,
  _hoisted_2$3,
  _hoisted_3$2
];
function _sfc_render$4(_ctx, _cache) {
  return openBlock(), createElementBlock("div", null, _hoisted_4$1);
}
const __6 = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["render", _sfc_render$4]]);
const __6_raw = '<template>\n  <div>\n    <p class="text-high-emphasis">\n      High-emphasis has an opacity of 87% in light theme and 100% in dark.\n    </p>\n    <p class="text-medium-emphasis">\n      Medium-emphasis text and hint text have opacities of 60% in light theme and 70% in dark.\n    </p>\n    <p class="text-disabled">\n      Disabled text has an opacity of 38% in light theme and 50% in dark.\n    </p>\n  </div>\n</template>\n';
const _sfc_main$4 = {};
const _hoisted_1$4 = /* @__PURE__ */ createStaticVNode('<p class="text-subtitle-2 text-center"> Agnostic RTL Alignment </p><p class="text-left"> Left aligned text, irrespective of RTL or LTR. </p><p class="text-right"> Right aligned text, irrespective of RTL or LTR. </p><p class="text-subtitle-2 text-center"> Responsive RTL Alignment </p><p class="text-start"> Left aligned text on LTR and right aligned on RTL. </p><p class="text-end"> Right aligned text on LTR and left aligned on RTL. </p>', 6);
const _hoisted_7 = [
  _hoisted_1$4
];
function _sfc_render$3(_ctx, _cache) {
  return openBlock(), createElementBlock("div", null, _hoisted_7);
}
const __7 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["render", _sfc_render$3]]);
const __7_raw = '<template>\n  <div>\n    <p class="text-subtitle-2 text-center">\n      Agnostic RTL Alignment\n    </p>\n\n    <p class="text-left">\n      Left aligned text, irrespective of RTL or LTR.\n    </p>\n    <p class="text-right">\n      Right aligned text, irrespective of RTL or LTR.\n    </p>\n\n    <p class="text-subtitle-2 text-center">\n      Responsive RTL Alignment\n    </p>\n\n    <p class="text-start">\n      Left aligned text on LTR and right aligned on RTL.\n    </p>\n    <p class="text-end">\n      Right aligned text on LTR and left aligned on RTL.\n    </p>\n  </div>\n</template>\n';
const _sfc_main$3 = {};
const _hoisted_1$3 = /* @__PURE__ */ createBaseVNode("p", { class: "text-lowercase" }, " Lowercased text. ", -1);
const _hoisted_2$2 = /* @__PURE__ */ createBaseVNode("p", { class: "text-uppercase" }, " Uppercased text. ", -1);
const _hoisted_3$1 = /* @__PURE__ */ createBaseVNode("p", { class: "text-capitalize" }, " capitalized text. ", -1);
const _hoisted_4 = [
  _hoisted_1$3,
  _hoisted_2$2,
  _hoisted_3$1
];
function _sfc_render$2(_ctx, _cache) {
  return openBlock(), createElementBlock("div", null, _hoisted_4);
}
const __8 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["render", _sfc_render$2]]);
const __8_raw = '<template>\n  <div>\n    <p class="text-lowercase">\n      Lowercased text.\n    </p>\n    <p class="text-uppercase">\n      Uppercased text.\n    </p>\n    <p class="text-capitalize">\n      capitalized text.\n    </p>\n  </div>\n</template>\n';
const _sfc_main$2 = {};
const _hoisted_1$2 = /* @__PURE__ */ createBaseVNode("span", {
  class: "d-inline-block text-truncate",
  style: { "max-width": "150px" }
}, " Suspendisse faucibus, nunc et pellentesque egestas, lacus ante convallis tellus. ", -1);
const _hoisted_2$1 = [
  _hoisted_1$2
];
function _sfc_render$1(_ctx, _cache) {
  return openBlock(), createElementBlock("div", null, _hoisted_2$1);
}
const __9 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["render", _sfc_render$1]]);
const __9_raw = '<template>\n  <div>\n    <span\n      class="d-inline-block text-truncate"\n      style="max-width: 150px;"\n    >\n      Suspendisse faucibus, nunc et pellentesque egestas, lacus ante convallis tellus.\n    </span>\n  </div>\n</template>\n';
const _sfc_main$1 = {};
const _hoisted_1$1 = { class: "d-flex justify-center" };
function _sfc_render(_ctx, _cache) {
  const _component_v_card_title = resolveComponent("v-card-title");
  const _component_v_card_text = resolveComponent("v-card-text");
  const _component_v_card = resolveComponent("v-card");
  return openBlock(), createElementBlock("div", _hoisted_1$1, [
    createVNode(_component_v_card, { width: "300px" }, {
      default: withCtx(() => [
        createVNode(_component_v_card_title, { class: "text-h6 text-md-h5 text-lg-h4" }, {
          default: withCtx(() => [
            createTextVNode("Title")
          ]),
          _: 1
        }),
        createVNode(_component_v_card_text, null, {
          default: withCtx(() => [
            createTextVNode(" Body text ")
          ]),
          _: 1
        })
      ]),
      _: 1
    })
  ]);
}
const __10 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["render", _sfc_render]]);
const __10_raw = '<template>\n  <div class="d-flex justify-center">\n    <v-card width="300px">\n      <v-card-title class="text-h6 text-md-h5 text-lg-h4">Title</v-card-title>\n      <v-card-text>\n        Body text\n      </v-card-text>\n    </v-card>\n  </div>\n</template>\n';
const _hoisted_1 = { class: "text-caption pa-2 bg-grey-lighten-4" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("div", { class: "text-grey" }, "Class", -1);
const _hoisted_3 = { class: "font-weight-medium" };
const _sfc_main = {
  __name: "typography",
  setup(__props) {
    const classes = [
      ["Heading 1", "text-h1"],
      ["Heading 2", "text-h2"],
      ["Heading 3", "text-h3"],
      ["Heading 4", "text-h4"],
      ["Heading 5", "text-h5"],
      ["Heading 6", "text-h6"],
      ["Subtitle 1", "text-subtitle-1"],
      ["Subtitle 2", "text-subtitle-2"],
      ["Body 1", "text-body-1"],
      ["Body 2", "text-body-2"],
      ["Button", "text-button"],
      ["Caption", "text-caption"],
      ["Overline", "text-overline"]
    ];
    return (_ctx, _cache) => {
      const _component_v_card = resolveComponent("v-card");
      return openBlock(), createElementBlock("div", null, [
        (openBlock(), createElementBlock(Fragment, null, renderList(classes, ([name, cls]) => {
          return createVNode(_component_v_card, {
            key: name,
            class: "my-4"
          }, {
            default: withCtx(() => [
              createBaseVNode("div", {
                class: normalizeClass([cls, "pa-2"])
              }, toDisplayString(name), 3),
              createBaseVNode("div", _hoisted_1, [
                _hoisted_2,
                createBaseVNode("div", _hoisted_3, toDisplayString(cls), 1)
              ])
            ]),
            _: 2
          }, 1024);
        }), 64))
      ]);
    };
  }
};
const __11 = _sfc_main;
const __11_raw = `<template>
  <div>
    <v-card v-for="[name, cls] in classes" :key="name" class="my-4">
      <div :class="[cls, 'pa-2']">{{ name }}</div>
      <div class="text-caption pa-2 bg-grey-lighten-4">
        <div class="text-grey">Class</div>
        <div class="font-weight-medium">{{ cls }}</div>
      </div>
    </v-card>
  </div>
</template>

<script setup>
  const classes = [
    ['Heading 1', 'text-h1'],
    ['Heading 2', 'text-h2'],
    ['Heading 3', 'text-h3'],
    ['Heading 4', 'text-h4'],
    ['Heading 5', 'text-h5'],
    ['Heading 6', 'text-h6'],
    ['Subtitle 1', 'text-subtitle-1'],
    ['Subtitle 2', 'text-subtitle-2'],
    ['Body 1', 'text-body-1'],
    ['Body 2', 'text-body-2'],
    ['Button', 'text-button'],
    ['Caption', 'text-caption'],
    ['Overline', 'text-overline'],
  ]
<\/script>

<script>
  export default {
    data: () => ({
      classes: [
        ['Heading 1', 'text-h1'],
        ['Heading 2', 'text-h2'],
        ['Heading 3', 'text-h3'],
        ['Heading 4', 'text-h4'],
        ['Heading 5', 'text-h5'],
        ['Heading 6', 'text-h6'],
        ['Subtitle 1', 'text-subtitle-1'],
        ['Subtitle 2', 'text-subtitle-2'],
        ['Body 1', 'text-body-1'],
        ['Body 2', 'text-body-2'],
        ['Button', 'text-button'],
        ['Caption', 'text-caption'],
        ['Overline', 'text-overline'],
      ],
    }),
  }
<\/script>
`;
const textAndTypography = {
  "font-emphasis": {
    component: __0,
    source: __0_raw
  },
  "text-alignment-responsive": {
    component: __1,
    source: __1_raw
  },
  "text-alignment": {
    component: __2,
    source: __2_raw
  },
  "text-break": {
    component: __3,
    source: __3_raw
  },
  "text-decoration": {
    component: __4,
    source: __4_raw
  },
  "text-no-wrap": {
    component: __5,
    source: __5_raw
  },
  "text-opacity": {
    component: __6,
    source: __6_raw
  },
  "text-rtl": {
    component: __7,
    source: __7_raw
  },
  "text-transform": {
    component: __8,
    source: __8_raw
  },
  "text-truncate": {
    component: __9,
    source: __9_raw
  },
  "typography-breakpoints": {
    component: __10,
    source: __10_raw
  },
  "typography": {
    component: __11,
    source: __11_raw
  }
};
export {
  textAndTypography as default
};
