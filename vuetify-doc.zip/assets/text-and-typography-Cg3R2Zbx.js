import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "text-and-typography" };
const _hoisted_2 = { id: "typography" };
const _hoisted_3 = { id: "breakpoints" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("All of the typography classes support the responsive breakpoints seen in other parts of the framework. The base class "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".text-{value}"),
  /* @__PURE__ */ createTextVNode(" corresponds to the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "xsAndUp"),
  /* @__PURE__ */ createTextVNode(" breakpoint, while the classes "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".text-{breakpoint}-{value}"),
  /* @__PURE__ */ createTextVNode(" can be used for the rest of the breakpoints ("),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "sm"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "md"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "lg"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "xl"),
  /* @__PURE__ */ createTextVNode(").")
], -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("p", null, "The following example shows a slightly contrived example of how one can use the different classes to effect:", -1);
const _hoisted_6 = { id: "font-emphasis" };
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Material design, by default, supports "),
  /* @__PURE__ */ createBaseVNode("strong", null, "100, 300, 400, 500, 700, 900"),
  /* @__PURE__ */ createTextVNode(" font weights and italicized text.")
], -1);
const _hoisted_8 = { id: "text" };
const _hoisted_9 = { id: "alignment" };
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("p", null, "Alignment helper classes allow you to easily re-align text.", -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("p", null, "The alignment classes also support responsive breakpoints.", -1);
const _hoisted_12 = { id: "decoration" };
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Remove text decoration with the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".text-decoration-none"),
  /* @__PURE__ */ createTextVNode(" class or add an "),
  /* @__PURE__ */ createBaseVNode("em", null, "overline, underline or line-through"),
  /* @__PURE__ */ createTextVNode(" by using "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".text-decoration-overline"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".text-decoration-underline"),
  /* @__PURE__ */ createTextVNode(", and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".text-decoration-line-through"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_14 = { id: "opacity" };
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Opacity helper classes allow you to easily adjust the emphasis of text. "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "text-high-emphasis"),
  /* @__PURE__ */ createTextVNode(" has the same opacity as default text. "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "text-medium-emphasis"),
  /* @__PURE__ */ createTextVNode(" is used for hints and helper text. De-emphasize text with "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "text-disabled"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_16 = { id: "transform" };
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("p", null, "Text can be transformed with text capitalization classes.", -1);
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Text breaking and the removal of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "text-transform"),
  /* @__PURE__ */ createTextVNode(" is also possible. In the first example, the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "text-transform: uppercase"),
  /* @__PURE__ */ createTextVNode(" custom class is overwritten and allows the text casing to remain. In the second example, we break up a longer word to fit the available space.")
], -1);
const _hoisted_19 = { id: "wrapping-and-overflow" };
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can prevent wrapping text with the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".text-no-wrap"),
  /* @__PURE__ */ createTextVNode(" utility class.")
], -1);
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Longer content can be truncated with a text ellipsis using the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".text-truncate"),
  /* @__PURE__ */ createTextVNode(" utility class.")
], -1);
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("strong", null, "Requires"),
  /* @__PURE__ */ createTextVNode(),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "display: inline-block"),
  /* @__PURE__ */ createTextVNode(),
  /* @__PURE__ */ createBaseVNode("strong", null, "or"),
  /* @__PURE__ */ createTextVNode(),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "display: block"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_23 = { id: "rtl-alignment" };
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "left", -1);
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "right", -1);
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("If instead you want the alignment to respond to the current text direction, use "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "start"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "end"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const frontmatter = { "meta": { "title": "Text and typography", "description": "View the various typography styles. From headings to captions, with various weights, sizes and italics.", "keywords": "typography, headings, titles, text" }, "related": ["/styles/display/", "/styles/content/", "/features/internationalization/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "text-and-typography",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "Text and typography", "description": "View the various typography styles. From headings to captions, with various weights, sizes and italics.", "keywords": "typography, headings, titles, text" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "title": "Text and typography", "description": "View the various typography styles. From headings to captions, with various weights, sizes and italics.", "keywords": "typography, headings, titles, text" }, "related": ["/styles/display/", "/styles/content/", "/features/internationalization/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_app_link = resolveComponent("app-link");
      const _component_page_features = resolveComponent("page-features");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_alert = resolveComponent("alert");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#text-and-typography",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Text and typography")
                ]),
                _: 1
              }),
              createBaseVNode("p", null, [
                createTextVNode("Control text size, alignment, wrapping, overflow, transforms and more. By default, Vuetify uses the Material Design specification "),
                createVNode(_component_app_link, { href: "https://fonts.google.com/specimen/Roboto" }, {
                  default: withCtx(() => [
                    createTextVNode("Roboto Font")
                  ]),
                  _: 1
                }),
                createTextVNode(".")
              ]),
              createVNode(_component_page_features),
              createVNode(_component_promoted_entry),
              createBaseVNode("section", _hoisted_2, [
                createVNode(_component_app_heading, {
                  href: "#typography",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Typography")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("Control the size and style of text using the Typography helper classes. These values are based upon the "),
                  createVNode(_component_app_link, { href: "https://material.io/design/typography/the-type-system.html" }, {
                    default: withCtx(() => [
                      createTextVNode("Material Design type specification")
                    ]),
                    _: 1
                  }),
                  createTextVNode(".")
                ]),
                createVNode(_component_examples_example, { file: "text-and-typography/typography" }),
                createBaseVNode("section", _hoisted_3, [
                  createVNode(_component_app_heading, {
                    href: "#breakpoints",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Breakpoints")
                    ]),
                    _: 1
                  }),
                  _hoisted_4,
                  _hoisted_5,
                  createVNode(_component_examples_example, { file: "text-and-typography/typography-breakpoints" })
                ]),
                createBaseVNode("section", _hoisted_6, [
                  createVNode(_component_app_heading, {
                    href: "#font-emphasis",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Font emphasis")
                    ]),
                    _: 1
                  }),
                  _hoisted_7,
                  createVNode(_component_examples_example, { file: "text-and-typography/font-emphasis" })
                ])
              ]),
              createBaseVNode("section", _hoisted_8, [
                createVNode(_component_app_heading, {
                  href: "#text",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Text")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_9, [
                  createVNode(_component_app_heading, {
                    href: "#alignment",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Alignment")
                    ]),
                    _: 1
                  }),
                  _hoisted_10,
                  createVNode(_component_examples_example, { file: "text-and-typography/text-alignment" }),
                  _hoisted_11,
                  createVNode(_component_examples_example, { file: "text-and-typography/text-alignment-responsive" })
                ]),
                createBaseVNode("section", _hoisted_12, [
                  createVNode(_component_app_heading, {
                    href: "#decoration",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Decoration")
                    ]),
                    _: 1
                  }),
                  _hoisted_13,
                  createVNode(_component_examples_example, { file: "text-and-typography/text-decoration" })
                ]),
                createBaseVNode("section", _hoisted_14, [
                  createVNode(_component_app_heading, {
                    href: "#opacity",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Opacity")
                    ]),
                    _: 1
                  }),
                  _hoisted_15,
                  createVNode(_component_examples_example, { file: "text-and-typography/text-opacity" })
                ]),
                createBaseVNode("section", _hoisted_16, [
                  createVNode(_component_app_heading, {
                    href: "#transform",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Transform")
                    ]),
                    _: 1
                  }),
                  _hoisted_17,
                  createVNode(_component_examples_example, { file: "text-and-typography/text-transform" }),
                  _hoisted_18,
                  createVNode(_component_examples_example, { file: "text-and-typography/text-break" })
                ]),
                createBaseVNode("section", _hoisted_19, [
                  createVNode(_component_app_heading, {
                    href: "#wrapping-and-overflow",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Wrapping and overflow")
                    ]),
                    _: 1
                  }),
                  _hoisted_20,
                  createVNode(_component_examples_example, { file: "text-and-typography/text-no-wrap" }),
                  _hoisted_21,
                  createVNode(_component_alert, { type: "info" }, {
                    default: withCtx(() => [
                      _hoisted_22
                    ]),
                    _: 1
                  }),
                  createVNode(_component_examples_example, { file: "text-and-typography/text-truncate" })
                ])
              ]),
              createBaseVNode("section", _hoisted_23, [
                createVNode(_component_app_heading, {
                  href: "#rtl-alignment",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("RTL Alignment")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("When using "),
                  createVNode(_component_app_link, { href: "/features/bidirectionality" }, {
                    default: withCtx(() => [
                      createTextVNode("RTL")
                    ]),
                    _: 1
                  }),
                  createTextVNode(", you may want to keep the alignment regardless of current text direction. This can be achieved by setting the direction to either "),
                  _hoisted_24,
                  createTextVNode(" or "),
                  _hoisted_25,
                  createTextVNode(".")
                ]),
                _hoisted_26,
                createVNode(_component_examples_example, { file: "text-and-typography/text-rtl" })
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
