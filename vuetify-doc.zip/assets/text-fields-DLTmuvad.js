import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "text-fields" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "Text field components are used for collecting user provided information.", -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, "A simple text field with placeholder and/or label.", -1);
const _hoisted_5 = { id: "api" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_8 = { id: "anatomy" };
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The recommended placement of elements inside of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-text-field"),
  /* @__PURE__ */ createTextVNode(" is:")
], -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Place a "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-icon"),
    /* @__PURE__ */ createTextVNode(" at the start of the input or label")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, "Place label after prepended content")
], -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Element / Area"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("tbody", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "1. Container"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("The Text field container contains the "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-input"),
      /* @__PURE__ */ createTextVNode(" and "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-field"),
      /* @__PURE__ */ createTextVNode(" components")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "2. Prepend icon"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("A custom icon that is located before "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-field")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "3. Prepend-inner icon"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("A custom icon that is located at the start of "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-field")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "4. Label"),
    /* @__PURE__ */ createBaseVNode("td", null, "A content area for displaying text to users that correlates to the input")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "5. Append-inner icon"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("A custom icon that is located at the end of "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-field"),
      /* @__PURE__ */ createTextVNode(" component")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "6. Append icon"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("A custom icon that is located after "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-field"),
      /* @__PURE__ */ createTextVNode(" component")
    ])
  ])
], -1);
const _hoisted_13 = { id: "guide" };
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-text-field", -1);
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, '<input type="text">', -1);
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-input", -1);
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-field", -1);
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-text-field", -1);
const _hoisted_19 = { id: "props" };
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-text-field", -1);
const _hoisted_21 = { id: "labeling" };
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "label"),
  /* @__PURE__ */ createTextVNode(" prop displays custom text for identifying an input’s purpose. The following code snippet is an example of a basic "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-text-field"),
  /* @__PURE__ */ createTextVNode(" component:")
], -1);
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-html" }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-text-field")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "label"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("First name"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("v-text-field")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("p", null, "Using this baseline makes it easy to put together quick mock implementations of your interface without needing to hook up any functional logic.", -1);
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The following code snippet is an example of a simple form for for collecting a user’s "),
  /* @__PURE__ */ createBaseVNode("strong", null, "First"),
  /* @__PURE__ */ createTextVNode(" name:")
], -1);
const _hoisted_26 = { id: "placeholders" };
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("strong", null, "placeholder", -1);
const _hoisted_28 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("In the following snippet, we improve the user experience of a "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-text-field"),
  /* @__PURE__ */ createTextVNode(" that is capturing an email address:")
], -1);
const _hoisted_29 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-html" }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-text-field")
      ]),
      /* @__PURE__ */ createTextVNode("\n  "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "label"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("Email address"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createTextVNode("\n  "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "placeholder"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("johndoe@gmail.com"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createTextVNode("\n  "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "type"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("email"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createTextVNode("\n"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("v-text-field")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_30 = /* @__PURE__ */ createBaseVNode("p", null, "When the user focuses the input, the placeholder fades in as the label translates up. The added visual element improves the user experience when using multiple field inputs.", -1);
const _hoisted_31 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Use the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "persistent-placeholder"),
  /* @__PURE__ */ createTextVNode(" prop to force the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "placeholder"),
  /* @__PURE__ */ createTextVNode(" to be visible, even when the input is not focused.")
], -1);
const _hoisted_32 = { id: "hints-26-messages" };
const _hoisted_33 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "label"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "placeholder"),
  /* @__PURE__ */ createTextVNode(" props are useful for providing context to the input but are typically concise. For longer textual information, all Vuetify inputs contain a "),
  /* @__PURE__ */ createBaseVNode("strong", null, "details"),
  /* @__PURE__ */ createTextVNode(" section that is used to provide "),
  /* @__PURE__ */ createBaseVNode("strong", null, "hints"),
  /* @__PURE__ */ createTextVNode(", regular "),
  /* @__PURE__ */ createBaseVNode("strong", null, "messages"),
  /* @__PURE__ */ createTextVNode(", and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "error-messages"),
  /* @__PURE__ */ createTextVNode(". In the following example watch the custom hint message display when you focus the input:")
], -1);
const _hoisted_34 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("If you want to make the hint visible at all times, use the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "persistent-hint"),
  /* @__PURE__ */ createTextVNode(" property. The following example demonstrates how to force a "),
  /* @__PURE__ */ createBaseVNode("strong", null, "hint"),
  /* @__PURE__ */ createTextVNode(" to show in the input’s details:")
], -1);
const _hoisted_35 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-html" }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-text-field")
      ]),
      /* @__PURE__ */ createTextVNode("\n  "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "hint"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("Enter your password to access this website"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createTextVNode("\n  "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "label"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("Password"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createTextVNode("\n  "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "persistent-hint"),
      /* @__PURE__ */ createTextVNode("\n  "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "type"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("input"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createTextVNode("\n"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("v-text-field")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_36 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("In addition to "),
  /* @__PURE__ */ createBaseVNode("strong", null, "persistent-hint"),
  /* @__PURE__ */ createTextVNode(", there are 3 other properties that support a persistent state:")
], -1);
const _hoisted_37 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "persistent-clear"),
    /* @__PURE__ */ createTextVNode(" - always show the input clear icon when a "),
    /* @__PURE__ */ createBaseVNode("strong", null, "value"),
    /* @__PURE__ */ createTextVNode(" is present")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "persistent-counter"),
    /* @__PURE__ */ createTextVNode(" - always show input character length element")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "persistent-placeholder"),
    /* @__PURE__ */ createTextVNode(" - always show placeholder, causes label to automatically elevate")
  ])
], -1);
const _hoisted_38 = { id: "clearable" };
const _hoisted_39 = /* @__PURE__ */ createBaseVNode("strong", null, "clearable", -1);
const _hoisted_40 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-text-field", -1);
const _hoisted_41 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-text-field", -1);
const _hoisted_42 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Note that "),
  /* @__PURE__ */ createBaseVNode("strong", null, "readonly"),
  /* @__PURE__ */ createTextVNode(" will not remove the clear icon, to prevent readonly inputs from being cleared you should also disable "),
  /* @__PURE__ */ createBaseVNode("strong", null, "clearable"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_43 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-text-field", -1);
const _hoisted_44 = /* @__PURE__ */ createBaseVNode("strong", null, "onClear", -1);
const _hoisted_45 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "Component.vue",
    class: "language-html"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-text-field")
      ]),
      /* @__PURE__ */ createTextVNode("\n    "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "clearable"),
      /* @__PURE__ */ createTextVNode("\n    "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "label"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("Last name"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createTextVNode("\n    "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "placeholder"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("Doe"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createTextVNode("\n    "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "persistent-clear"),
      /* @__PURE__ */ createTextVNode("\n    "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token namespace" }, "@click:"),
        /* @__PURE__ */ createTextVNode("clear")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("onClear"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createTextVNode("\n  "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("v-text-field")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("script")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "setup"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token script" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token language-javascript" }, [
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "onClear"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode("\n    "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "alert"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
        /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'User cleared the input'"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createTextVNode("\n")
      ])
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("script")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_46 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-text-field", -1);
const _hoisted_47 = { id: "validation-26-rules" };
const _hoisted_48 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("When working with inputs you often need to validate the user’s input in some manner; i.e. Email, Password. Use the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "rules"),
  /* @__PURE__ */ createTextVNode(" property to invoke custom functions based upon the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-text-field"),
  /* @__PURE__ */ createTextVNode("’s state. It accepts an array of "),
  /* @__PURE__ */ createBaseVNode("strong", null, "functions"),
  /* @__PURE__ */ createTextVNode(" that return either "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "true"),
  /* @__PURE__ */ createTextVNode(" or a "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "string"),
  /* @__PURE__ */ createTextVNode(". In the following example, enter a value into the field and then clear it:")
], -1);
const _hoisted_49 = { id: "forms" };
const _hoisted_50 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-text-field", -1);
const _hoisted_51 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-form", -1);
const _hoisted_52 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-text-field", -1);
const _hoisted_53 = { id: "examples" };
const _hoisted_54 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The following is a collection of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-text-field"),
  /* @__PURE__ */ createTextVNode(" examples that demonstrate how different the properties work in an application.")
], -1);
const _hoisted_55 = { id: "custom-colors" };
const _hoisted_56 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "color"),
  /* @__PURE__ */ createTextVNode(" prop provides an easy way to change the color of textual content; label, prefix, suffix, etc. This color is applied as long as "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-text-field"),
  /* @__PURE__ */ createTextVNode(" is focused.")
], -1);
const _hoisted_57 = { id: "density" };
const _hoisted_58 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "density"),
  /* @__PURE__ */ createTextVNode(" prop decreases the height of the text field based upon 1 of 3 levels of density; "),
  /* @__PURE__ */ createBaseVNode("strong", null, "default"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "comfortable"),
  /* @__PURE__ */ createTextVNode(", and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "compact"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_59 = { id: "disabled-and-readonly" };
const _hoisted_60 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The state of a text field can be changed by providing the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "disabled"),
  /* @__PURE__ */ createTextVNode(" or "),
  /* @__PURE__ */ createBaseVNode("strong", null, "readonly"),
  /* @__PURE__ */ createTextVNode(" props.")
], -1);
const _hoisted_61 = { id: "hide-details" };
const _hoisted_62 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("When "),
  /* @__PURE__ */ createBaseVNode("strong", null, "hide-details"),
  /* @__PURE__ */ createTextVNode(" is set to "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "auto"),
  /* @__PURE__ */ createTextVNode(" messages will be rendered only if there’s a message (hint, error message, counter value etc) to display.")
], -1);
const _hoisted_63 = { id: "hint" };
const _hoisted_64 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "hint"),
  /* @__PURE__ */ createTextVNode(" property on text fields adds the provided string beneath the text field. Using "),
  /* @__PURE__ */ createBaseVNode("strong", null, "persistent-hint"),
  /* @__PURE__ */ createTextVNode(" keeps the hint visible when the text field is not focused.")
], -1);
const _hoisted_65 = { id: "icons" };
const _hoisted_66 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can add icons to the text field with "),
  /* @__PURE__ */ createBaseVNode("strong", null, "prepend-icon"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "append-icon"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "append-inner-icon"),
  /* @__PURE__ */ createTextVNode(" props.")
], -1);
const _hoisted_67 = { id: "prefixes-and-suffixes" };
const _hoisted_68 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "prefix"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "suffix"),
  /* @__PURE__ */ createTextVNode(" properties allows you to prepend and append inline non-modifiable text next to the text field.")
], -1);
const _hoisted_69 = { id: "validation" };
const _hoisted_70 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Vuetify includes simple validation through the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "rules"),
  /* @__PURE__ */ createTextVNode(" prop. The prop accepts a mixed array of types "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "function"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "boolean"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "string"),
  /* @__PURE__ */ createTextVNode(". When the input value changes, each element in the array will be validated. Functions pass the current v-model as an argument and must return either "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "true"),
  /* @__PURE__ */ createTextVNode(" / "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "false"),
  /* @__PURE__ */ createTextVNode(" or a "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "string"),
  /* @__PURE__ */ createTextVNode(" containing an error message.")
], -1);
const _hoisted_71 = { id: "variant" };
const _hoisted_72 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "variant"),
  /* @__PURE__ */ createTextVNode(" prop provides an easy way to customize the style of your text field. The following values are valid options: "),
  /* @__PURE__ */ createBaseVNode("strong", null, "solo"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "filled"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "outlined"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "plain"),
  /* @__PURE__ */ createTextVNode(", and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "underlined"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_73 = { id: "events" };
const _hoisted_74 = { id: "icon-events" };
const _hoisted_75 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "click:prepend"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "click:append"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "click:append-inner"),
  /* @__PURE__ */ createTextVNode(", and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "click:clear"),
  /* @__PURE__ */ createTextVNode(" are emitted when you click on the respective icon. Note that these events will not be fired if the slot is used instead.")
], -1);
const _hoisted_76 = { id: "slots" };
const _hoisted_77 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Slots allow you to customize the display of many "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-text-field"),
  /* @__PURE__ */ createTextVNode(" properties to modify what Vuetify does by default. The following slots are available on the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-text-field"),
  /* @__PURE__ */ createTextVNode(" component:")
], -1);
const _hoisted_78 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Slot name"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_79 = /* @__PURE__ */ createBaseVNode("tbody", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "1. prepend"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("Provided by "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-input"),
      /* @__PURE__ */ createTextVNode(", positioned before the input field")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "2. prepend-inner"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("Provided by "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-field"),
      /* @__PURE__ */ createTextVNode(", positioned at the start of the input field")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "3. label"),
    /* @__PURE__ */ createBaseVNode("td", null, "The form input label")
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "4. append-inner"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("Provided by "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-field"),
      /* @__PURE__ */ createTextVNode(", positioned at the end of the input field")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "5. append"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("Provided by "),
      /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-input"),
      /* @__PURE__ */ createTextVNode(", positioned after the input field")
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("td", null, "6. details"),
    /* @__PURE__ */ createBaseVNode("td", null, [
      /* @__PURE__ */ createTextVNode("Used for displaying "),
      /* @__PURE__ */ createBaseVNode("strong", null, "messages"),
      /* @__PURE__ */ createTextVNode(", "),
      /* @__PURE__ */ createBaseVNode("strong", null, "hint"),
      /* @__PURE__ */ createTextVNode(", "),
      /* @__PURE__ */ createBaseVNode("strong", null, "error-messages"),
      /* @__PURE__ */ createTextVNode(", and more")
    ])
  ])
], -1);
const _hoisted_80 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The following example uses the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "label"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "prepend"),
  /* @__PURE__ */ createTextVNode(", and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "prepend-inner"),
  /* @__PURE__ */ createTextVNode(" slots and adds custom elements to the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-text-field")
], -1);
const _hoisted_81 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "Component.vue",
    class: "language-html"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-text-field")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "v-model"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("model"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token namespace" }, "v-slot:"),
        /* @__PURE__ */ createTextVNode("label")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("span")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("Type something..."),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("span")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token namespace" }, "v-slot:"),
        /* @__PURE__ */ createTextVNode("prepend")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-icon")
      ]),
      /* @__PURE__ */ createTextVNode("\n        "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, ":color"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("model ? 'primary' : undefined"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createTextVNode("\n        "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "icon"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("$vuetify"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createTextVNode("\n      "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "/>")
    ]),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token namespace" }, "v-slot:"),
        /* @__PURE__ */ createTextVNode("append-inner")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-icon")
      ]),
      /* @__PURE__ */ createTextVNode("\n        "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "v-if"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("model"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createTextVNode("\n        "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "icon"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("mdi-check-circle"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createTextVNode("\n      "),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "/>")
    ]),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "#details"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-spacer")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "/>")
    ]),
    /* @__PURE__ */ createTextVNode("\n\n      See our "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("a")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "href"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("#"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("Terms and Service"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("a")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("v-text-field")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("script")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "setup"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token script" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token language-javascript" }, [
        /* @__PURE__ */ createTextVNode("\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
        /* @__PURE__ */ createTextVNode(" shallowRef "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vue'"),
        /* @__PURE__ */ createTextVNode("\n\n  "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "const"),
        /* @__PURE__ */ createTextVNode(" model "),
        /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "="),
        /* @__PURE__ */ createTextVNode(),
        /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "shallowRef"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
        /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "''"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
        /* @__PURE__ */ createTextVNode("\n")
      ])
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("script")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_82 = { id: "icon-slots" };
const _hoisted_83 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Instead of using "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "prepend"),
  /* @__PURE__ */ createTextVNode("/"),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "append"),
  /* @__PURE__ */ createTextVNode("/"),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "append-inner"),
  /* @__PURE__ */ createTextVNode(" icons you can use slots to extend input’s functionality.")
], -1);
const _hoisted_84 = { id: "label" };
const _hoisted_85 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Text field label can be defined in "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "label"),
  /* @__PURE__ */ createTextVNode(" slot - that will allow to use HTML content")
], -1);
const _hoisted_86 = { id: "progress" };
const _hoisted_87 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can display a progress bar instead of the bottom line. You can use the default indeterminate progress having same color as the text field or designate a custom one using the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "progress"),
  /* @__PURE__ */ createTextVNode(" slot")
], -1);
const _hoisted_88 = { id: "misc" };
const _hoisted_89 = { id: "custom-validation" };
const _hoisted_90 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-form", -1);
const _hoisted_91 = { id: "full-width-with-counter" };
const _hoisted_92 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Full width text fields allow you to create boundless inputs. In this example, we use a "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-divider"),
  /* @__PURE__ */ createTextVNode(" to separate the fields.")
], -1);
const _hoisted_93 = { id: "password-input" };
const _hoisted_94 = /* @__PURE__ */ createBaseVNode("strong", null, "type", -1);
const _hoisted_95 = { id: "login-form" };
const _hoisted_96 = /* @__PURE__ */ createBaseVNode("p", null, "In this example we use a combination of prepend and append icon to create a custom login form.", -1);
const frontmatter = { "meta": { "nav": "Text fields", "title": "Text field component", "description": "The text field component accepts textual input from users.", "keywords": "text fields, vuetify text field component, vue text field component" }, "related": ["/components/textareas/", "/components/selects/", "/components/forms/"], "features": { "label": "C: VTextField", "report": true, "github": "/components/VTextField/", "spec": "https://m2.material.io/components/text-fields" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "text-fields",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Text fields", "title": "Text field component", "description": "The text field component accepts textual input from users.", "keywords": "text fields, vuetify text field component, vue text field component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Text fields", "title": "Text field component", "description": "The text field component accepts textual input from users.", "keywords": "text fields, vuetify text field component, vue text field component" }, "related": ["/components/textareas/", "/components/selects/", "/components/forms/"], "features": { "label": "C: VTextField", "report": true, "github": "/components/VTextField/", "spec": "https://m2.material.io/components/text-fields" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_app_figure = resolveComponent("app-figure");
      const _component_page_features = resolveComponent("page-features");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_app_markup = resolveComponent("app-markup");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_alert = resolveComponent("alert");
      const _component_promoted_promoted = resolveComponent("promoted-promoted");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#text-fields",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Text fields")
                ]),
                _: 1
              }),
              _hoisted_2,
              createBaseVNode("p", null, [
                createBaseVNode("div", null, [
                  createVNode(_component_app_figure, {
                    alt: "Text-field Entry",
                    src: "https://cdn.vuetifyjs.com/docs/images/components-temp/v-text-field/v-text-field-entry.png"
                  })
                ])
              ]),
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_usage, { name: "v-text-field" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_6,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-text-field/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-text-field")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_8, [
                createVNode(_component_app_heading, {
                  href: "#anatomy",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Anatomy")
                  ]),
                  _: 1
                }),
                _hoisted_9,
                _hoisted_10,
                createBaseVNode("p", null, [
                  createBaseVNode("div", null, [
                    createVNode(_component_app_figure, {
                      alt: "Text-field Anatomy",
                      src: "https://cdn.vuetifyjs.com/docs/images/components-temp/v-text-field/v-text-field-anatomy.png"
                    })
                  ])
                ]),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_11,
                    _hoisted_12
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_13, [
                createVNode(_component_app_heading, {
                  href: "#guide",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Guide")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("The "),
                  _hoisted_14,
                  createTextVNode(" component is a versatile "),
                  _hoisted_15,
                  createTextVNode(" field which combines both the "),
                  _hoisted_16,
                  createTextVNode(" and "),
                  _hoisted_17,
                  createTextVNode(" components into a single offering. It is a commonly used element that provides the baseline for other form inputs; such as "),
                  createVNode(_component_app_link, { href: "/components/selects/" }, {
                    default: withCtx(() => [
                      createTextVNode("v-select")
                    ]),
                    _: 1
                  }),
                  createTextVNode(", "),
                  createVNode(_component_app_link, { href: "/components/autocompletes/" }, {
                    default: withCtx(() => [
                      createTextVNode("v-autocomplete")
                    ]),
                    _: 1
                  }),
                  createTextVNode(", "),
                  createVNode(_component_app_link, { href: "/components/combobox/" }, {
                    default: withCtx(() => [
                      createTextVNode("v-combobox")
                    ]),
                    _: 1
                  }),
                  createTextVNode(". In this guide you learn the basic fundamentals of "),
                  _hoisted_18,
                  createTextVNode(" and how its various properties interact with each other.")
                ]),
                createBaseVNode("section", _hoisted_19, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("p", null, [
                    createTextVNode("The "),
                    _hoisted_20,
                    createTextVNode(" component has an massive API with numerous options to modify the display, functionality, or style of your inputs. Many of the configurable options are also available through "),
                    createVNode(_component_app_link, { href: "#slots" }, {
                      default: withCtx(() => [
                        createTextVNode("slots")
                      ]),
                      _: 1
                    }),
                    createTextVNode(".")
                  ]),
                  createBaseVNode("section", _hoisted_21, [
                    createVNode(_component_app_heading, {
                      href: "#labeling",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Labeling")
                      ]),
                      _: 1
                    }),
                    _hoisted_22,
                    createVNode(_component_app_markup, {
                      resource: "",
                      class: "mb-4"
                    }, {
                      default: withCtx(() => [
                        _hoisted_23
                      ]),
                      _: 1
                    }),
                    _hoisted_24,
                    _hoisted_25,
                    createVNode(_component_examples_example, { file: "v-text-field/prop-label" })
                  ]),
                  createBaseVNode("section", _hoisted_26, [
                    createVNode(_component_app_heading, {
                      href: "#placeholders",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Placeholders")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("Sometimes a label alone doesn’t convey enough information and you need to expose more. For those use-cases, use the "),
                      _hoisted_27,
                      createTextVNode(" property with or without the "),
                      createVNode(_component_app_link, { href: "#labeling" }, {
                        default: withCtx(() => [
                          createTextVNode("label")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" or "),
                      createVNode(_component_app_link, { href: "#hint" }, {
                        default: withCtx(() => [
                          createTextVNode("hint")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" properties.")
                    ]),
                    _hoisted_28,
                    createVNode(_component_app_markup, {
                      resource: "",
                      class: "mb-4"
                    }, {
                      default: withCtx(() => [
                        _hoisted_29
                      ]),
                      _: 1
                    }),
                    _hoisted_30,
                    createVNode(_component_examples_example, { file: "v-text-field/prop-placeholder" }),
                    createVNode(_component_alert, { type: "info" }, {
                      default: withCtx(() => [
                        _hoisted_31
                      ]),
                      _: 1
                    })
                  ]),
                  createBaseVNode("section", _hoisted_32, [
                    createVNode(_component_app_heading, {
                      href: "#hints-26-messages",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Hints & messages")
                      ]),
                      _: 1
                    }),
                    _hoisted_33,
                    createVNode(_component_examples_example, {
                      file: "v-text-field/prop-messages",
                      open: ""
                    }),
                    _hoisted_34,
                    createVNode(_component_app_markup, {
                      resource: "",
                      class: "mb-4"
                    }, {
                      default: withCtx(() => [
                        _hoisted_35
                      ]),
                      _: 1
                    }),
                    _hoisted_36,
                    _hoisted_37
                  ]),
                  createBaseVNode("section", _hoisted_38, [
                    createVNode(_component_app_heading, {
                      href: "#clearable",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Clearable")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("The "),
                      _hoisted_39,
                      createTextVNode(" prop appends an inner "),
                      createVNode(_component_app_link, { href: "/components/icons/" }, {
                        default: withCtx(() => [
                          createTextVNode("v-icon")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" that clears the "),
                      _hoisted_40,
                      createTextVNode(" when clicked. When an input is cleared, it resets the current "),
                      _hoisted_41,
                      createTextVNode(" value. The following example displays an interactive icon when the mouse hovers over the input:")
                    ]),
                    createVNode(_component_examples_example, {
                      file: "v-text-field/prop-clearable",
                      open: ""
                    }),
                    _hoisted_42,
                    createBaseVNode("p", null, [
                      createTextVNode("Sometimes you may need to perform an action when the user clears an input. By using a custom "),
                      createVNode(_component_app_link, { href: "https://vuejs.org/guide/essentials/event-handling.html" }, {
                        default: withCtx(() => [
                          createTextVNode("Vue Event Handler")
                        ]),
                        _: 1
                      }),
                      createTextVNode(", you can bind a custom function that is invoked whenever the "),
                      _hoisted_43,
                      createTextVNode(" is cleared by the user. The following example demonstrates how to use a a custom event handler to invoke the "),
                      _hoisted_44,
                      createTextVNode(" method:")
                    ]),
                    createVNode(_component_app_markup, {
                      resource: "Component.vue",
                      class: "mb-4"
                    }, {
                      default: withCtx(() => [
                        _hoisted_45
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("You can see more supported events on the "),
                      _hoisted_46,
                      createTextVNode(),
                      createVNode(_component_app_link, { href: "/api/v-text-field/#events" }, {
                        default: withCtx(() => [
                          createTextVNode("API page")
                        ]),
                        _: 1
                      }),
                      createTextVNode(".")
                    ])
                  ]),
                  createBaseVNode("section", _hoisted_47, [
                    createVNode(_component_app_heading, {
                      href: "#validation-26-rules",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Validation & rules")
                      ]),
                      _: 1
                    }),
                    _hoisted_48,
                    createVNode(_component_examples_example, {
                      file: "v-text-field/prop-rules",
                      open: ""
                    })
                  ]),
                  createBaseVNode("section", _hoisted_49, [
                    createVNode(_component_app_heading, {
                      href: "#forms",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Forms")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("Group multiple "),
                      _hoisted_50,
                      createTextVNode(" components and other functionality within a "),
                      _hoisted_51,
                      createTextVNode(" component; for a more detailed look at forms, please visit the "),
                      createVNode(_component_app_link, { href: "/components/forms/" }, {
                        default: withCtx(() => [
                          createTextVNode("v-form")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" page. Forms are useful for validating more than 1 input and make it easy to interact with the state of many fields at once. The following example combines multiple "),
                      _hoisted_52,
                      createTextVNode(" components to create a login form:")
                    ]),
                    createVNode(_component_examples_example, { file: "v-text-field/misc-guide" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_53, [
                  createVNode(_component_app_heading, {
                    href: "#examples",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Examples")
                    ]),
                    _: 1
                  }),
                  _hoisted_54,
                  createBaseVNode("section", _hoisted_55, [
                    createVNode(_component_app_heading, {
                      href: "#custom-colors",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Custom colors")
                      ]),
                      _: 1
                    }),
                    _hoisted_56,
                    createVNode(_component_examples_example, { file: "v-text-field/prop-custom-colors" })
                  ]),
                  createBaseVNode("section", _hoisted_57, [
                    createVNode(_component_app_heading, {
                      href: "#density",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Density")
                      ]),
                      _: 1
                    }),
                    _hoisted_58,
                    createVNode(_component_examples_example, { file: "v-text-field/prop-dense" })
                  ]),
                  createBaseVNode("section", _hoisted_59, [
                    createVNode(_component_app_heading, {
                      href: "#disabled-and-readonly",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Disabled and readonly")
                      ]),
                      _: 1
                    }),
                    _hoisted_60,
                    createVNode(_component_examples_example, { file: "v-text-field/prop-disabled-and-readonly" })
                  ]),
                  createBaseVNode("section", _hoisted_61, [
                    createVNode(_component_app_heading, {
                      href: "#hide-details",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Hide details")
                      ]),
                      _: 1
                    }),
                    _hoisted_62,
                    createVNode(_component_examples_example, { file: "v-text-field/prop-hide-details" })
                  ]),
                  createBaseVNode("section", _hoisted_63, [
                    createVNode(_component_app_heading, {
                      href: "#hint",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Hint")
                      ]),
                      _: 1
                    }),
                    _hoisted_64,
                    createVNode(_component_examples_example, { file: "v-text-field/prop-hint" })
                  ]),
                  createBaseVNode("section", _hoisted_65, [
                    createVNode(_component_app_heading, {
                      href: "#icons",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Icons")
                      ]),
                      _: 1
                    }),
                    _hoisted_66,
                    createVNode(_component_examples_example, { file: "v-text-field/prop-icon" })
                  ]),
                  createBaseVNode("section", _hoisted_67, [
                    createVNode(_component_app_heading, {
                      href: "#prefixes-and-suffixes",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Prefixes and suffixes")
                      ]),
                      _: 1
                    }),
                    _hoisted_68,
                    createVNode(_component_examples_example, { file: "v-text-field/prop-prefixes-and-suffixes" })
                  ]),
                  createBaseVNode("section", _hoisted_69, [
                    createVNode(_component_app_heading, {
                      href: "#validation",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Validation")
                      ]),
                      _: 1
                    }),
                    _hoisted_70,
                    createVNode(_component_examples_example, { file: "v-text-field/prop-validation" })
                  ]),
                  createBaseVNode("section", _hoisted_71, [
                    createVNode(_component_app_heading, {
                      href: "#variant",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Variant")
                      ]),
                      _: 1
                    }),
                    _hoisted_72,
                    createVNode(_component_examples_example, { file: "v-text-field/prop-variant" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_73, [
                  createVNode(_component_app_heading, {
                    href: "#events",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Events")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_74, [
                    createVNode(_component_app_heading, {
                      href: "#icon-events",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Icon events")
                      ]),
                      _: 1
                    }),
                    _hoisted_75,
                    createVNode(_component_examples_example, { file: "v-text-field/event-icons" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_76, [
                  createVNode(_component_app_heading, {
                    href: "#slots",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Slots")
                    ]),
                    _: 1
                  }),
                  _hoisted_77,
                  createVNode(_component_app_table, null, {
                    default: withCtx(() => [
                      _hoisted_78,
                      _hoisted_79
                    ]),
                    _: 1
                  }),
                  _hoisted_80,
                  createVNode(_component_app_markup, {
                    resource: "Component.vue",
                    class: "mb-4"
                  }, {
                    default: withCtx(() => [
                      _hoisted_81
                    ]),
                    _: 1
                  }),
                  createVNode(_component_promoted_promoted),
                  createBaseVNode("section", _hoisted_82, [
                    createVNode(_component_app_heading, {
                      href: "#icon-slots",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Icon slots")
                      ]),
                      _: 1
                    }),
                    _hoisted_83,
                    createVNode(_component_examples_example, { file: "v-text-field/slot-icons" })
                  ]),
                  createBaseVNode("section", _hoisted_84, [
                    createVNode(_component_app_heading, {
                      href: "#label",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Label")
                      ]),
                      _: 1
                    }),
                    _hoisted_85,
                    createVNode(_component_examples_example, { file: "v-text-field/slot-label" })
                  ]),
                  createBaseVNode("section", _hoisted_86, [
                    createVNode(_component_app_heading, {
                      href: "#progress",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Progress")
                      ]),
                      _: 1
                    }),
                    _hoisted_87,
                    createVNode(_component_examples_example, { file: "v-text-field/slot-progress" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_88, [
                  createVNode(_component_app_heading, {
                    href: "#misc",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Misc")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_89, [
                    createVNode(_component_app_heading, {
                      href: "#custom-validation",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Custom validation")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("While the built in "),
                      _hoisted_90,
                      createTextVNode(" or 3rd party plugin such as "),
                      createVNode(_component_app_link, { href: "https://github.com/monterail/vuelidate" }, {
                        default: withCtx(() => [
                          createTextVNode("vuelidate")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" or "),
                      createVNode(_component_app_link, { href: "https://github.com/logaretm/vee-validate" }, {
                        default: withCtx(() => [
                          createTextVNode("vee-validation")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" can help streamline your validation process, you can choose to simply control it yourself.")
                    ]),
                    createVNode(_component_examples_example, { file: "v-text-field/misc-custom-validation" })
                  ]),
                  createBaseVNode("section", _hoisted_91, [
                    createVNode(_component_app_heading, {
                      href: "#full-width-with-counter",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Full width with counter")
                      ]),
                      _: 1
                    }),
                    _hoisted_92,
                    createVNode(_component_examples_example, { file: "v-text-field/misc-full-width-with-counter" })
                  ]),
                  createBaseVNode("section", _hoisted_93, [
                    createVNode(_component_app_heading, {
                      href: "#password-input",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Password input")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("Using the HTML input "),
                      _hoisted_94,
                      createTextVNode(),
                      createVNode(_component_app_link, { href: "https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input/password" }, {
                        default: withCtx(() => [
                          createTextVNode("password")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" can be used with an appended icon and callback to control the visibility.")
                    ]),
                    createVNode(_component_examples_example, { file: "v-text-field/misc-password" })
                  ]),
                  createBaseVNode("section", _hoisted_95, [
                    createVNode(_component_app_heading, {
                      href: "#login-form",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Login Form")
                      ]),
                      _: 1
                    }),
                    _hoisted_96,
                    createVNode(_component_examples_example, { file: "v-text-field/misc-login-form" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
