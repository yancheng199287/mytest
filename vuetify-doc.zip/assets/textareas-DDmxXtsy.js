import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "textareas" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "Textarea components are used for collecting large amounts of textual data.", -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-textarea"),
  /* @__PURE__ */ createTextVNode(" in its simplest form is a multi-line text-field, useful for larger amounts of text.")
], -1);
const _hoisted_5 = { id: "api" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_8 = { id: "examples" };
const _hoisted_9 = { id: "props" };
const _hoisted_10 = { id: "auto-grow" };
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("When using the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "auto-grow"),
  /* @__PURE__ */ createTextVNode(" prop, textarea’s will automatically increase in size when the contained text exceeds its size.")
], -1);
const _hoisted_12 = { id: "background-color" };
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "background-color"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "color"),
  /* @__PURE__ */ createTextVNode(" props give you more control over styling "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-textarea"),
  /* @__PURE__ */ createTextVNode("’s.")
], -1);
const _hoisted_14 = { id: "browser-autocomplete" };
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "autocomplete"),
  /* @__PURE__ */ createTextVNode(" prop gives you the option to enable the browser to predict user input.")
], -1);
const _hoisted_16 = { id: "clearable" };
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can clear the text from a "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-textarea"),
  /* @__PURE__ */ createTextVNode(" by using the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "clearable"),
  /* @__PURE__ */ createTextVNode(" prop, and customize the icon used with the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "clearable-icon"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_18 = { id: "counter" };
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "counter"),
  /* @__PURE__ */ createTextVNode(" prop informs the user of a character limit for the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-textarea"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_20 = { id: "icons" };
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "append-icon"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "prepend-icon"),
  /* @__PURE__ */ createTextVNode(" props help add context to "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-textarea"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_22 = { id: "no-resize" };
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-textarea"),
  /* @__PURE__ */ createTextVNode("’s have the option to remain the same size regardless of their content’s size, using the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "no-resize"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_24 = { id: "rows" };
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "rows"),
  /* @__PURE__ */ createTextVNode(" prop allows you to define how many rows the textarea has, when combined with the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "row-height"),
  /* @__PURE__ */ createTextVNode(" prop you can further customize your rows by defining their height.")
], -1);
const _hoisted_26 = { id: "misc" };
const _hoisted_27 = { id: "signup-form" };
const _hoisted_28 = /* @__PURE__ */ createBaseVNode("p", null, "Utilizing alternative input styles, you can create amazing interfaces that are easy to build and easy to use.", -1);
const frontmatter = { "meta": { "nav": "Textareas", "title": "Textarea component", "description": "The textarea component is a text field that accepts lengthy textual input from users.", "keywords": "textareas, vuetify textarea component, vue textarea component" }, "related": ["/components/forms/", "/components/selects/", "/components/text-fields/"], "features": { "label": "C: VTextarea", "report": true, "github": "/components/VTextarea/", "spec": "https://m2.material.io/components/text-fields#input-types" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "textareas",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Textareas", "title": "Textarea component", "description": "The textarea component is a text field that accepts lengthy textual input from users.", "keywords": "textareas, vuetify textarea component, vue textarea component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Textareas", "title": "Textarea component", "description": "The textarea component is a text field that accepts lengthy textual input from users.", "keywords": "textareas, vuetify textarea component, vue textarea component" }, "related": ["/components/forms/", "/components/selects/", "/components/text-fields/"], "features": { "label": "C: VTextarea", "report": true, "github": "/components/VTextarea/", "spec": "https://m2.material.io/components/text-fields#input-types" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#textareas",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Textareas")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_usage, { name: "v-textarea" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_6,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-textarea/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-textarea")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_8, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_9, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_10, [
                    createVNode(_component_app_heading, {
                      href: "#auto-grow",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Auto grow")
                      ]),
                      _: 1
                    }),
                    _hoisted_11,
                    createVNode(_component_examples_example, { file: "v-textarea/prop-auto-grow" })
                  ]),
                  createBaseVNode("section", _hoisted_12, [
                    createVNode(_component_app_heading, {
                      href: "#background-color",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Background color")
                      ]),
                      _: 1
                    }),
                    _hoisted_13,
                    createVNode(_component_examples_example, { file: "v-textarea/prop-background-color" })
                  ]),
                  createBaseVNode("section", _hoisted_14, [
                    createVNode(_component_app_heading, {
                      href: "#browser-autocomplete",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Browser autocomplete")
                      ]),
                      _: 1
                    }),
                    _hoisted_15,
                    createVNode(_component_examples_example, { file: "v-textarea/prop-browser-autocomplete" })
                  ]),
                  createBaseVNode("section", _hoisted_16, [
                    createVNode(_component_app_heading, {
                      href: "#clearable",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Clearable")
                      ]),
                      _: 1
                    }),
                    _hoisted_17,
                    createVNode(_component_examples_example, { file: "v-textarea/prop-clearable" })
                  ]),
                  createBaseVNode("section", _hoisted_18, [
                    createVNode(_component_app_heading, {
                      href: "#counter",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Counter")
                      ]),
                      _: 1
                    }),
                    _hoisted_19,
                    createVNode(_component_examples_example, { file: "v-textarea/prop-counter" })
                  ]),
                  createBaseVNode("section", _hoisted_20, [
                    createVNode(_component_app_heading, {
                      href: "#icons",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Icons")
                      ]),
                      _: 1
                    }),
                    _hoisted_21,
                    createVNode(_component_examples_example, { file: "v-textarea/prop-icons" })
                  ]),
                  createBaseVNode("section", _hoisted_22, [
                    createVNode(_component_app_heading, {
                      href: "#no-resize",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("No resize")
                      ]),
                      _: 1
                    }),
                    _hoisted_23,
                    createVNode(_component_examples_example, { file: "v-textarea/prop-no-resize" })
                  ]),
                  createBaseVNode("section", _hoisted_24, [
                    createVNode(_component_app_heading, {
                      href: "#rows",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Rows")
                      ]),
                      _: 1
                    }),
                    _hoisted_25,
                    createVNode(_component_examples_example, { file: "v-textarea/prop-rows" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_26, [
                  createVNode(_component_app_heading, {
                    href: "#misc",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Misc")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_27, [
                    createVNode(_component_app_heading, {
                      href: "#signup-form",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Signup form")
                      ]),
                      _: 1
                    }),
                    _hoisted_28,
                    createVNode(_component_examples_example, { file: "v-textarea/misc-signup-form" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
