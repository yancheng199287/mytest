import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "theme-providers" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "The theme provider allows you to style a section of your application in a different theme from the default", -1);
const _hoisted_3 = { id: "api" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_6 = { id: "examples" };
const _hoisted_7 = { id: "background" };
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("By default, "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-theme-provider"),
  /* @__PURE__ */ createTextVNode(" is a renderless component that allows you to change the applied theme for all of its children. When using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "with-background"),
  /* @__PURE__ */ createTextVNode(" prop, the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-theme-provider"),
  /* @__PURE__ */ createTextVNode(" wraps its children in an element and applies the selected theme’s background color to it.")
], -1);
const frontmatter = { "meta": { "nav": "Theme providers", "title": "Theme provider component", "description": "The theme provider allows you to style a section of your application in a different theme from the default", "keywords": "theme provider, vuetify theme provider component, vue theme provider component" }, "related": ["/features/theme/", "/styles/colors/", "/features/application-layout/"], "features": { "github": "/components/VThemeProvider/", "label": "C: VThemeProvider", "report": true } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "theme-providers",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Theme providers", "title": "Theme provider component", "description": "The theme provider allows you to style a section of your application in a different theme from the default", "keywords": "theme provider, vuetify theme provider component, vue theme provider component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Theme providers", "title": "Theme provider component", "description": "The theme provider allows you to style a section of your application in a different theme from the default", "keywords": "theme provider, vuetify theme provider component, vue theme provider component" }, "related": ["/features/theme/", "/styles/colors/", "/features/application-layout/"], "features": { "github": "/components/VThemeProvider/", "label": "C: VThemeProvider", "report": true } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#theme-providers",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Theme providers")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_promoted_entry),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_4,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-theme-provider/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-theme-provider")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_5
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_6, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_7, [
                  createVNode(_component_app_heading, {
                    href: "#background",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Background")
                    ]),
                    _: 1
                  }),
                  _hoisted_8,
                  createVNode(_component_examples_example, { file: "v-theme-provider/prop-with-background" })
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
