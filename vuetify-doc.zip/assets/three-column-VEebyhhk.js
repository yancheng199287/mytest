import { r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, b as createVNode, l as createElementBlock, v as renderList, F as Fragment } from "./index-DGybHjCP.js";
const _sfc_main = {
  __name: "three-column",
  setup(__props) {
    const links = [
      "Dashboard",
      "Messages",
      "Profile",
      "Updates"
    ];
    return (_ctx, _cache) => {
      const _component_v_avatar = resolveComponent("v-avatar");
      const _component_v_spacer = resolveComponent("v-spacer");
      const _component_v_tab = resolveComponent("v-tab");
      const _component_v_tabs = resolveComponent("v-tabs");
      const _component_v_app_bar = resolveComponent("v-app-bar");
      const _component_v_sheet = resolveComponent("v-sheet");
      const _component_v_col = resolveComponent("v-col");
      const _component_v_row = resolveComponent("v-row");
      const _component_v_container = resolveComponent("v-container");
      const _component_v_main = resolveComponent("v-main");
      const _component_v_app = resolveComponent("v-app");
      return openBlock(), createBlock(_component_v_app, { id: "inspire" }, {
        default: withCtx(() => [
          createVNode(_component_v_app_bar, {
            class: "px-3",
            density: "compact",
            flat: ""
          }, {
            default: withCtx(() => [
              createVNode(_component_v_avatar, {
                class: "hidden-md-and-up",
                color: "grey-darken-1",
                size: "32"
              }),
              createVNode(_component_v_spacer),
              createVNode(_component_v_tabs, {
                color: "grey-darken-2",
                centered: ""
              }, {
                default: withCtx(() => [
                  (openBlock(), createElementBlock(Fragment, null, renderList(links, (link) => {
                    return createVNode(_component_v_tab, {
                      key: link,
                      text: link
                    }, null, 8, ["text"]);
                  }), 64))
                ]),
                _: 1
              }),
              createVNode(_component_v_spacer),
              createVNode(_component_v_avatar, {
                class: "hidden-sm-and-down",
                color: "grey-darken-1",
                size: "32"
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_main, { class: "bg-grey-lighten-3" }, {
            default: withCtx(() => [
              createVNode(_component_v_container, null, {
                default: withCtx(() => [
                  createVNode(_component_v_row, null, {
                    default: withCtx(() => [
                      createVNode(_component_v_col, {
                        cols: "12",
                        md: "2"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_v_sheet, {
                            "min-height": "268",
                            rounded: "lg"
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_v_col, {
                        cols: "12",
                        md: "8"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_v_sheet, {
                            "min-height": "70vh",
                            rounded: "lg"
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_v_col, {
                        cols: "12",
                        md: "2"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_v_sheet, {
                            "min-height": "268",
                            rounded: "lg"
                          })
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __8 = _sfc_main;
export {
  __8 as _
};
