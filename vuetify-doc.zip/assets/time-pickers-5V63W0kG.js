import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "time-pickers" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-time-picker"),
  /* @__PURE__ */ createTextVNode(" is stand-alone component that can be utilized in many existing Vuetify components. It offers the user a visual representation for selecting the time.")
], -1);
const _hoisted_3 = { id: "installation" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, "Labs components require a manual import and installation of the component.", -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-js" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/plugins/vuetify.js",
    class: "language-js"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" VTimePicker "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify/labs/VTimePicker'"),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "export"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "default"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "createVuetify"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "components"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n    VTimePicker"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_6 = { id: "usage" };
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("p", null, "Time pickers have the light theme enabled by default.", -1);
const _hoisted_8 = { id: "api" };
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_11 = { id: "examples" };
const _hoisted_12 = { id: "props" };
const _hoisted_13 = { id: "allowed-times" };
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("p", null, "You can specify allowed times using arrays, objects, and functions. You can also specify time step/precision/interval - e.g. 10 minutes.", -1);
const _hoisted_15 = { id: "colors" };
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Time picker colors can be set using the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "color"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "header-color"),
  /* @__PURE__ */ createTextVNode(" props. If "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "header-color"),
  /* @__PURE__ */ createTextVNode(" prop is not provided header will use the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "color"),
  /* @__PURE__ */ createTextVNode(' prop value."')
], -1);
const _hoisted_17 = { id: "disabled" };
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("p", null, "You can’t interact with disabled picker.", -1);
const _hoisted_19 = { id: "elevation" };
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Emphasize the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-time-picker"),
  /* @__PURE__ */ createTextVNode(" component by providing an "),
  /* @__PURE__ */ createBaseVNode("strong", null, "elevation"),
  /* @__PURE__ */ createTextVNode(" from 0 to 24. Elevation modifies the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "box-shadow"),
  /* @__PURE__ */ createTextVNode(" css property.")
], -1);
const _hoisted_21 = { id: "format" };
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("A time picker can be switched to 24hr format. Note that the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "format"),
  /* @__PURE__ */ createTextVNode(" prop defines only the way the picker is displayed, picker’s value (model) is always in 24hr format.")
], -1);
const _hoisted_23 = { id: "no-header" };
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("p", null, "You can remove picker’s header.", -1);
const _hoisted_25 = { id: "range" };
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("This is an example of joining pickers together using "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "min"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "max"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_27 = { id: "read-only" };
const _hoisted_28 = /* @__PURE__ */ createBaseVNode("p", null, "Read-only picker behaves same as disabled one, but looks like default one.", -1);
const _hoisted_29 = { id: "scrollable" };
const _hoisted_30 = /* @__PURE__ */ createBaseVNode("p", null, "You can edit time picker’s value using mouse wheel.", -1);
const _hoisted_31 = { id: "use-seconds" };
const _hoisted_32 = /* @__PURE__ */ createBaseVNode("p", null, "Time picker can have seconds input.", -1);
const _hoisted_33 = { id: "misc" };
const _hoisted_34 = { id: "dialog-and-menu" };
const _hoisted_35 = /* @__PURE__ */ createBaseVNode("p", null, "Due to the flexibility of pickers, you can really dial in the experience exactly how you want it.", -1);
const frontmatter = { "emphasized": true, "meta": { "nav": "Time pickers", "title": "Time picker component", "description": "The time picker component is a stand-alone interface that allows the selection of hours and minutes in AM/PM and 24hr formats.", "keywords": "time pickers, vuetify time picker component, vue time picker component" }, "related": ["/components/buttons/", "/components/date-pickers/", "/components/text-fields/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "time-pickers",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Time pickers", "title": "Time picker component", "description": "The time picker component is a stand-alone interface that allows the selection of hours and minutes in AM/PM and 24hr formats.", "keywords": "time pickers, vuetify time picker component, vue time picker component" } };
    useHead(head);
    __expose({ frontmatter: { "emphasized": true, "meta": { "nav": "Time pickers", "title": "Time picker component", "description": "The time picker component is a stand-alone interface that allows the selection of hours and minutes in AM/PM and 24hr formats.", "keywords": "time pickers, vuetify time picker component, vue time picker component" }, "related": ["/components/buttons/", "/components/date-pickers/", "/components/text-fields/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_app_link = resolveComponent("app-link");
      const _component_alert = resolveComponent("alert");
      const _component_app_markup = resolveComponent("app-markup");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#time-pickers",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Time pickers")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_alert, { type: "warning" }, {
                default: withCtx(() => [
                  createBaseVNode("p", null, [
                    createTextVNode("This feature requires "),
                    createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v3.5.12" }, {
                      default: withCtx(() => [
                        createTextVNode("v3.5.12")
                      ]),
                      _: 1
                    })
                  ])
                ]),
                _: 1
              }),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#installation",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Installation")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_app_markup, {
                  resource: "src/plugins/vuetify.js",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_5
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_6, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_7,
                createVNode(_component_examples_usage, { name: "v-time-picker" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_8, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_9,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-time-picker/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-time-picker")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_10
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_11, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_12, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_13, [
                    createVNode(_component_app_heading, {
                      href: "#allowed-times",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Allowed times")
                      ]),
                      _: 1
                    }),
                    _hoisted_14,
                    createVNode(_component_examples_example, { file: "v-time-picker/prop-allowed-times" })
                  ]),
                  createBaseVNode("section", _hoisted_15, [
                    createVNode(_component_app_heading, {
                      href: "#colors",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Colors")
                      ]),
                      _: 1
                    }),
                    _hoisted_16,
                    createVNode(_component_examples_example, { file: "v-time-picker/prop-color" })
                  ]),
                  createBaseVNode("section", _hoisted_17, [
                    createVNode(_component_app_heading, {
                      href: "#disabled",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Disabled")
                      ]),
                      _: 1
                    }),
                    _hoisted_18,
                    createVNode(_component_examples_example, { file: "v-time-picker/prop-disabled" })
                  ]),
                  createBaseVNode("section", _hoisted_19, [
                    createVNode(_component_app_heading, {
                      href: "#elevation",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Elevation")
                      ]),
                      _: 1
                    }),
                    _hoisted_20,
                    createVNode(_component_examples_example, { file: "v-time-picker/prop-elevation" })
                  ]),
                  createBaseVNode("section", _hoisted_21, [
                    createVNode(_component_app_heading, {
                      href: "#format",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Format")
                      ]),
                      _: 1
                    }),
                    _hoisted_22,
                    createVNode(_component_examples_example, { file: "v-time-picker/prop-format" })
                  ]),
                  createBaseVNode("section", _hoisted_23, [
                    createVNode(_component_app_heading, {
                      href: "#no-header",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("No header")
                      ]),
                      _: 1
                    }),
                    _hoisted_24,
                    createVNode(_component_examples_example, { file: "v-time-picker/prop-hide-header" })
                  ]),
                  createBaseVNode("section", _hoisted_25, [
                    createVNode(_component_app_heading, {
                      href: "#range",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Range")
                      ]),
                      _: 1
                    }),
                    _hoisted_26,
                    createVNode(_component_examples_example, { file: "v-time-picker/prop-range" })
                  ]),
                  createBaseVNode("section", _hoisted_27, [
                    createVNode(_component_app_heading, {
                      href: "#read-only",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Read-only")
                      ]),
                      _: 1
                    }),
                    _hoisted_28,
                    createVNode(_component_examples_example, { file: "v-time-picker/prop-readonly" })
                  ]),
                  createBaseVNode("section", _hoisted_29, [
                    createVNode(_component_app_heading, {
                      href: "#scrollable",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Scrollable")
                      ]),
                      _: 1
                    }),
                    _hoisted_30,
                    createVNode(_component_examples_example, { file: "v-time-picker/prop-scrollable" })
                  ]),
                  createBaseVNode("section", _hoisted_31, [
                    createVNode(_component_app_heading, {
                      href: "#use-seconds",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Use seconds")
                      ]),
                      _: 1
                    }),
                    _hoisted_32,
                    createVNode(_component_examples_example, { file: "v-time-picker/prop-use-seconds" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_33, [
                  createVNode(_component_app_heading, {
                    href: "#misc",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Misc")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_34, [
                    createVNode(_component_app_heading, {
                      href: "#dialog-and-menu",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Dialog and menu")
                      ]),
                      _: 1
                    }),
                    _hoisted_35,
                    createVNode(_component_examples_example, { file: "v-time-picker/misc-dialog-and-menu" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
