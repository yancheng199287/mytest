import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "timelines" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-timeline"),
  /* @__PURE__ */ createTextVNode(" is useful for stylistically displaying chronological information.")
], -1);
const _hoisted_3 = { id: "api" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("td", null, "Sub-component used to display a single timeline item", -1);
const _hoisted_7 = { id: "examples" };
const _hoisted_8 = { id: "props" };
const _hoisted_9 = { id: "direction" };
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Switch between a horizontal and vertical timeline in real-time using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "direction"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_11 = { id: "side" };
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Use the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "side"),
  /* @__PURE__ */ createTextVNode(" property to force all items to one side of the timeline.")
], -1);
const _hoisted_13 = { id: "alignment" };
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("By default, "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-timeline-item"),
  /* @__PURE__ */ createTextVNode(" content is vertically aligned "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "center"),
  /* @__PURE__ */ createTextVNode(". The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "align"),
  /* @__PURE__ */ createTextVNode(" prop also supports "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "top"),
  /* @__PURE__ */ createTextVNode(" alignment.")
], -1);
const _hoisted_15 = { id: "dot-color" };
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("p", null, "Colored dots create visual breakpoints that make your timelines easier for users to read.", -1);
const _hoisted_17 = { id: "icon-dots" };
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Use icons within the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-timeline-item"),
  /* @__PURE__ */ createTextVNode(" dot to provide additional context.")
], -1);
const _hoisted_19 = { id: "size" };
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "size"),
  /* @__PURE__ */ createTextVNode(" prop allows you to customize the size of each dot.")
], -1);
const _hoisted_21 = { id: "truncated-line" };
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Truncate the start, end or both ends of the timeline center line by using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "truncate-line"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_23 = { id: "line-inset" };
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Modify the inset of dividing lines by specifying a custom amount using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "line-inset"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_25 = { id: "slots" };
const _hoisted_26 = { id: "icon" };
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Insert avatars into dots with use of the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "icon"),
  /* @__PURE__ */ createTextVNode(" slot and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-avatar"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_28 = { id: "opposite" };
const _hoisted_29 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("strong", null, "opposite"),
  /* @__PURE__ */ createTextVNode(" slot provides an additional layer of customization within your timelines.")
], -1);
const _hoisted_30 = { id: "misc" };
const _hoisted_31 = { id: "advanced" };
const frontmatter = { "meta": { "nav": "Timelines", "title": "Timeline component", "description": "The timeline component is used to display chronological information either vertically or horizontally.", "keywords": "timelines, vuetify timeline component, vue timeline component" }, "related": ["/components/cards/", "/components/icons/", "/components/grids/"], "features": { "github": "/components/VTimeline/", "label": "C: VTimeline", "report": true } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "timelines",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Timelines", "title": "Timeline component", "description": "The timeline component is used to display chronological information either vertically or horizontally.", "keywords": "timelines, vuetify timeline component, vue timeline component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Timelines", "title": "Timeline component", "description": "The timeline component is used to display chronological information either vertically or horizontally.", "keywords": "timelines, vuetify timeline component, vue timeline component" }, "related": ["/components/cards/", "/components/icons/", "/components/grids/"], "features": { "github": "/components/VTimeline/", "label": "C: VTimeline", "report": true } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#timelines",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Timelines")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_promoted_entry),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_4,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-timeline/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-timeline")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_5
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-timeline-item/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-timeline-item")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_6
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_7, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_8, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_9, [
                    createVNode(_component_app_heading, {
                      href: "#direction",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Direction")
                      ]),
                      _: 1
                    }),
                    _hoisted_10,
                    createVNode(_component_examples_example, { file: "v-timeline/prop-direction" })
                  ]),
                  createBaseVNode("section", _hoisted_11, [
                    createVNode(_component_app_heading, {
                      href: "#side",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Side")
                      ]),
                      _: 1
                    }),
                    _hoisted_12,
                    createVNode(_component_examples_example, { file: "v-timeline/prop-single-side" })
                  ]),
                  createBaseVNode("section", _hoisted_13, [
                    createVNode(_component_app_heading, {
                      href: "#alignment",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Alignment")
                      ]),
                      _: 1
                    }),
                    _hoisted_14,
                    createVNode(_component_examples_example, { file: "v-timeline/prop-align" })
                  ]),
                  createBaseVNode("section", _hoisted_15, [
                    createVNode(_component_app_heading, {
                      href: "#dot-color",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Dot color")
                      ]),
                      _: 1
                    }),
                    _hoisted_16,
                    createVNode(_component_examples_example, { file: "v-timeline/prop-color" })
                  ]),
                  createBaseVNode("section", _hoisted_17, [
                    createVNode(_component_app_heading, {
                      href: "#icon-dots",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Icon dots")
                      ]),
                      _: 1
                    }),
                    _hoisted_18,
                    createVNode(_component_examples_example, { file: "v-timeline/prop-icon-dots" })
                  ]),
                  createBaseVNode("section", _hoisted_19, [
                    createVNode(_component_app_heading, {
                      href: "#size",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Size")
                      ]),
                      _: 1
                    }),
                    _hoisted_20,
                    createVNode(_component_examples_example, { file: "v-timeline/prop-size" })
                  ]),
                  createBaseVNode("section", _hoisted_21, [
                    createVNode(_component_app_heading, {
                      href: "#truncated-line",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Truncated line")
                      ]),
                      _: 1
                    }),
                    _hoisted_22,
                    createVNode(_component_examples_example, { file: "v-timeline/prop-truncate-line" })
                  ]),
                  createBaseVNode("section", _hoisted_23, [
                    createVNode(_component_app_heading, {
                      href: "#line-inset",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Line inset")
                      ]),
                      _: 1
                    }),
                    _hoisted_24,
                    createVNode(_component_examples_example, { file: "v-timeline/prop-line-inset" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_25, [
                  createVNode(_component_app_heading, {
                    href: "#slots",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Slots")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_26, [
                    createVNode(_component_app_heading, {
                      href: "#icon",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Icon")
                      ]),
                      _: 1
                    }),
                    _hoisted_27,
                    createVNode(_component_examples_example, { file: "v-timeline/slot-icon" })
                  ]),
                  createBaseVNode("section", _hoisted_28, [
                    createVNode(_component_app_heading, {
                      href: "#opposite",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Opposite")
                      ]),
                      _: 1
                    }),
                    _hoisted_29,
                    createVNode(_component_examples_example, { file: "v-timeline/slot-opposite" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_30, [
                  createVNode(_component_app_heading, {
                    href: "#misc",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Misc")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_31, [
                    createVNode(_component_app_heading, {
                      href: "#advanced",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Advanced")
                      ]),
                      _: 1
                    }),
                    createVNode(_component_examples_example, { file: "v-timeline/misc-advanced" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
