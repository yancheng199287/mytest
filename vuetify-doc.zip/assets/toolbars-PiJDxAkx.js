import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "toolbars" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-toolbar", -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-toolbar-title", -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-toolbar-items", -1);
const _hoisted_6 = { id: "api" };
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("td", null, "Sub-component used to display the title of the toolbar", -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createTextVNode("Sub-component commonly used in "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-toolbar")
], -1);
const _hoisted_11 = { id: "caveats" };
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("When "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn"),
  /* @__PURE__ */ createTextVNode("s with the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "icon"),
  /* @__PURE__ */ createTextVNode(" prop are used inside of "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-toolbar"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-app-bar"),
  /* @__PURE__ */ createTextVNode(" they will automatically have their size increased and negative margin applied to ensure proper spacing according to the Material Design Specification. If you choose to wrap your buttons in any container, such as a "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "div"),
  /* @__PURE__ */ createTextVNode(", you will need to apply negative margin to that container in order to properly align them.")
], -1);
const _hoisted_13 = { id: "examples" };
const _hoisted_14 = { id: "props" };
const _hoisted_15 = { id: "background" };
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("strong", null, "src", -1);
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("strong", null, "img", -1);
const _hoisted_18 = { id: "collapse" };
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("p", null, "Toolbars can be collapsed to save screen space.", -1);
const _hoisted_20 = { id: "dense-toolbars" };
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Dense toolbars reduce their height to "),
  /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "48px"),
  /* @__PURE__ */ createTextVNode(". When using in conjunction with the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "prominent"),
  /* @__PURE__ */ createTextVNode(" prop, will reduce height to "),
  /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "96px"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_22 = { id: "extended" };
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Toolbars can be extended without using the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "extension"),
  /* @__PURE__ */ createTextVNode(" slot.")
], -1);
const _hoisted_24 = { id: "extension-height" };
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("p", null, "The extension’s height can be customized.", -1);
const _hoisted_26 = { id: "floating-with-search" };
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("p", null, "A floating toolbar is turned into an inline element that only takes up as much space as needed. This is particularly useful when placing toolbars over content.", -1);
const _hoisted_28 = { id: "light-and-dark" };
const _hoisted_29 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Toolbars come in "),
  /* @__PURE__ */ createBaseVNode("strong", null, "2"),
  /* @__PURE__ */ createTextVNode(" variants, light and dark. Light toolbars have dark tinted buttons and dark text whereas dark toolbars have white tinted buttons and white text.")
], -1);
const _hoisted_30 = { id: "prominent-toolbars" };
const _hoisted_31 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-toolbar", -1);
const _hoisted_32 = /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "128px", -1);
const _hoisted_33 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-toolbar-title", -1);
const _hoisted_34 = /* @__PURE__ */ createBaseVNode("strong", null, "prominent", -1);
const _hoisted_35 = /* @__PURE__ */ createBaseVNode("strong", null, "dense", -1);
const _hoisted_36 = /* @__PURE__ */ createBaseVNode("strong", null, "short", -1);
const _hoisted_37 = { id: "misc" };
const _hoisted_38 = { id: "contextual-action-bar" };
const _hoisted_39 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("It is possible to update the appearance of a toolbar in response to changes in app state. In this example, the color and content of the toolbar changes in response to user selections in the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-select"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_40 = { id: "flexible-and-card-toolbar" };
const _hoisted_41 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("In this example we offset our card onto the extended content area of a toolbar using the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "extended"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_42 = { id: "variations" };
const _hoisted_43 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("A "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-toolbar"),
  /* @__PURE__ */ createTextVNode(" has multiple variations that can be applied with themes and helper classes. These range from light and dark themes, colored and transparent.")
], -1);
const frontmatter = { "meta": { "nav": "Toolbars", "title": "Toolbar component", "description": "The toolbar component sits above the content that it affects and provides an area for labeling and additional actions.", "keywords": "toolbars, vuetify toolbar component, vue toolbar component" }, "related": ["/components/buttons/", "/components/footers/", "/components/tabs/"], "features": { "github": "/components/VToolbar/", "label": "C: VToolbar", "report": true, "spec": "https://m1.material.io/components/toolbars.html" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "toolbars",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Toolbars", "title": "Toolbar component", "description": "The toolbar component sits above the content that it affects and provides an area for labeling and additional actions.", "keywords": "toolbars, vuetify toolbar component, vue toolbar component" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "nav": "Toolbars", "title": "Toolbar component", "description": "The toolbar component sits above the content that it affects and provides an area for labeling and additional actions.", "keywords": "toolbars, vuetify toolbar component, vue toolbar component" }, "related": ["/components/buttons/", "/components/footers/", "/components/tabs/"], "features": { "github": "/components/VToolbar/", "label": "C: VToolbar", "report": true, "spec": "https://m1.material.io/components/toolbars.html" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_app_link = resolveComponent("app-link");
      const _component_page_features = resolveComponent("page-features");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_alert = resolveComponent("alert");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#toolbars",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Toolbars")
                ]),
                _: 1
              }),
              createBaseVNode("p", null, [
                createTextVNode("The "),
                _hoisted_2,
                createTextVNode(" component is pivotal to any graphical user interface (GUI), as it generally is the primary source of site navigation. The toolbar component works great in conjunction with "),
                createVNode(_component_app_link, { href: "/components/navigation-drawers" }, {
                  default: withCtx(() => [
                    createTextVNode("v-navigation-drawer")
                  ]),
                  _: 1
                }),
                createTextVNode(" and "),
                createVNode(_component_app_link, { href: "/components/cards" }, {
                  default: withCtx(() => [
                    createTextVNode("v-card")
                  ]),
                  _: 1
                }),
                createTextVNode(".")
              ]),
              createVNode(_component_page_features),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createTextVNode("A toolbar is a flexible container that can be used in a number of ways. By default, the toolbar is 64px high on desktop and 56px high on mobile. There are a number of helper components available to use with the toolbar. The "),
                  _hoisted_4,
                  createTextVNode(" is used for displaying a title and "),
                  _hoisted_5,
                  createTextVNode(" allow "),
                  createVNode(_component_app_link, { href: "/components/buttons" }, {
                    default: withCtx(() => [
                      createTextVNode("v-btn")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" to extend full height.")
                ]),
                createVNode(_component_examples_usage, { name: "v-toolbar" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_6, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_7,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-toolbar/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-toolbar")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_8
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-toolbar-items/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-toolbar-items")
                            ]),
                            _: 1
                          })
                        ]),
                        createBaseVNode("td", null, [
                          createTextVNode("Sub-component used to modify the styling of "),
                          createVNode(_component_app_link, { href: "/components/buttons" }, {
                            default: withCtx(() => [
                              createTextVNode("v-btn")
                            ]),
                            _: 1
                          })
                        ])
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-toolbar-title/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-toolbar-title")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_9
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-btn/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-btn")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_10
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_11, [
                createVNode(_component_app_heading, {
                  href: "#caveats",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Caveats")
                  ]),
                  _: 1
                }),
                createVNode(_component_alert, { type: "warning" }, {
                  default: withCtx(() => [
                    _hoisted_12
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_13, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_14, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_15, [
                    createVNode(_component_app_heading, {
                      href: "#background",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Background")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("Toolbars can display a background as opposed to a solid color using the "),
                      _hoisted_16,
                      createTextVNode(" prop. This can be modified further by using the "),
                      _hoisted_17,
                      createTextVNode(" slot and providing your own "),
                      createVNode(_component_app_link, { href: "/components/images" }, {
                        default: withCtx(() => [
                          createTextVNode("v-img")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" component. Backgrounds can be faded using a "),
                      createVNode(_component_app_link, { href: "/components/app-bars#prominent-w-scroll-shrink-and-image" }, {
                        default: withCtx(() => [
                          createTextVNode("v-app-bar")
                        ]),
                        _: 1
                      })
                    ]),
                    createVNode(_component_examples_example, { file: "v-toolbar/prop-background" })
                  ]),
                  createBaseVNode("section", _hoisted_18, [
                    createVNode(_component_app_heading, {
                      href: "#collapse",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Collapse")
                      ]),
                      _: 1
                    }),
                    _hoisted_19,
                    createVNode(_component_examples_example, { file: "v-toolbar/prop-collapse" })
                  ]),
                  createBaseVNode("section", _hoisted_20, [
                    createVNode(_component_app_heading, {
                      href: "#dense-toolbars",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Dense toolbars")
                      ]),
                      _: 1
                    }),
                    _hoisted_21,
                    createVNode(_component_examples_example, { file: "v-toolbar/prop-dense" })
                  ]),
                  createBaseVNode("section", _hoisted_22, [
                    createVNode(_component_app_heading, {
                      href: "#extended",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Extended")
                      ]),
                      _: 1
                    }),
                    _hoisted_23,
                    createVNode(_component_examples_example, { file: "v-toolbar/prop-extended" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_24, [
                  createVNode(_component_app_heading, {
                    href: "#extension-height",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Extension height")
                    ]),
                    _: 1
                  }),
                  _hoisted_25,
                  createVNode(_component_examples_example, { file: "v-toolbar/prop-extension-height" }),
                  createBaseVNode("section", _hoisted_26, [
                    createVNode(_component_app_heading, {
                      href: "#floating-with-search",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Floating with search")
                      ]),
                      _: 1
                    }),
                    _hoisted_27,
                    createVNode(_component_examples_example, { file: "v-toolbar/prop-floating-with-search" })
                  ]),
                  createBaseVNode("section", _hoisted_28, [
                    createVNode(_component_app_heading, {
                      href: "#light-and-dark",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Light and Dark")
                      ]),
                      _: 1
                    }),
                    _hoisted_29,
                    createVNode(_component_examples_example, { file: "v-toolbar/prop-light-and-dark" })
                  ]),
                  createBaseVNode("section", _hoisted_30, [
                    createVNode(_component_app_heading, {
                      href: "#prominent-toolbars",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Prominent toolbars")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("Prominent toolbars increase the "),
                      _hoisted_31,
                      createTextVNode("’s height to "),
                      _hoisted_32,
                      createTextVNode(" and positions the "),
                      _hoisted_33,
                      createTextVNode(" towards the bottom of the container. This is expanded upon in "),
                      createVNode(_component_app_link, { href: "/components/app-bars#prominent-w-scroll-shrink" }, {
                        default: withCtx(() => [
                          createTextVNode("v-app-bar")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" with the ability to shrink a "),
                      _hoisted_34,
                      createTextVNode(" toolbar to a "),
                      _hoisted_35,
                      createTextVNode(" or "),
                      _hoisted_36,
                      createTextVNode(" one.")
                    ]),
                    createVNode(_component_examples_example, { file: "v-toolbar/prop-prominent" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_37, [
                  createVNode(_component_app_heading, {
                    href: "#misc",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Misc")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_38, [
                    createVNode(_component_app_heading, {
                      href: "#contextual-action-bar",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Contextual action bar")
                      ]),
                      _: 1
                    }),
                    _hoisted_39,
                    createVNode(_component_examples_example, { file: "v-toolbar/misc-contextual-action-bar" })
                  ]),
                  createBaseVNode("section", _hoisted_40, [
                    createVNode(_component_app_heading, {
                      href: "#flexible-and-card-toolbar",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Flexible and card toolbar")
                      ]),
                      _: 1
                    }),
                    _hoisted_41,
                    createVNode(_component_examples_example, { file: "v-toolbar/misc-flexible-and-card" })
                  ]),
                  createBaseVNode("section", _hoisted_42, [
                    createVNode(_component_app_heading, {
                      href: "#variations",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Variations")
                      ]),
                      _: 1
                    }),
                    _hoisted_43,
                    createVNode(_component_examples_example, { file: "v-toolbar/misc-variations" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
