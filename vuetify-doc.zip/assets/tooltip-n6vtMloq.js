import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "tooltip-directive" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-tooltip"),
  /* @__PURE__ */ createTextVNode(" directive is a shorthand way of adding tooltips to elements in your application.")
], -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-tooltip"),
  /* @__PURE__ */ createTextVNode(" directive makes it easy to add a tooltip to any element in your application. It is a wrapper around the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-tooltip"),
  /* @__PURE__ */ createTextVNode(" component.")
], -1);
const _hoisted_5 = { id: "api" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Directive"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "The Tooltip directive", -1);
const _hoisted_8 = { id: "guide" };
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-tooltip"),
  /* @__PURE__ */ createTextVNode(" directive is a simple way to add a tooltip to any element in your application. It is a wrapper around the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-tooltip"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_10 = { id: "args" };
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-tooltip"),
  /* @__PURE__ */ createTextVNode(" directive has a number of args that can be used to customize the behavior of the tooltip.")
], -1);
const _hoisted_12 = { id: "modifiers" };
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-tooltip", -1);
const _hoisted_14 = { id: "object-literals" };
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-tooltip"),
  /* @__PURE__ */ createTextVNode(" directive can also accept an object literal as a value. This is useful when you need to pass multiple props to the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-tooltip"),
  /* @__PURE__ */ createTextVNode(" component.")
], -1);
const frontmatter = { "emphasized": true, "meta": { "nav": "Tooltip", "title": "Tooltip directive", "description": "The Tooltip directive is an easy to use implementation of VTooltip.", "keywords": "Tooltip, vuetify Tooltip directive, vue Tooltip directive, mobile Tooltip directive" }, "related": ["/components/navigation-drawers/", "/components/slide-groups/", "/components/windows/"], "features": { "report": true } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "tooltip",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Tooltip", "title": "Tooltip directive", "description": "The Tooltip directive is an easy to use implementation of VTooltip.", "keywords": "Tooltip, vuetify Tooltip directive, vue Tooltip directive, mobile Tooltip directive" } };
    useHead(head);
    __expose({ frontmatter: { "emphasized": true, "meta": { "nav": "Tooltip", "title": "Tooltip directive", "description": "The Tooltip directive is an easy to use implementation of VTooltip.", "keywords": "Tooltip, vuetify Tooltip directive, vue Tooltip directive, mobile Tooltip directive" }, "related": ["/components/navigation-drawers/", "/components/slide-groups/", "/components/windows/"], "features": { "report": true } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_examples_usage = resolveComponent("examples-usage");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#tooltip-directive",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Tooltip directive")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_promoted_entry),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_examples_usage, { name: "v-tooltip-directive" })
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_6,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-tooltip-directive/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-tooltip")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ])
                    ])
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_8, [
                createVNode(_component_app_heading, {
                  href: "#guide",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Guide")
                  ]),
                  _: 1
                }),
                _hoisted_9,
                createBaseVNode("section", _hoisted_10, [
                  createVNode(_component_app_heading, {
                    href: "#args",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Args")
                    ]),
                    _: 1
                  }),
                  _hoisted_11,
                  createVNode(_component_examples_example, { file: "v-tooltip-directive/args" })
                ]),
                createBaseVNode("section", _hoisted_12, [
                  createVNode(_component_app_heading, {
                    href: "#modifiers",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Modifiers")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("p", null, [
                    createTextVNode("Modifiers are values that are passed to the "),
                    _hoisted_13,
                    createTextVNode(" component. This is an easy way to make small modifications to boolean "),
                    createVNode(_component_app_link, { href: "/api/v-tooltip/" }, {
                      default: withCtx(() => [
                        createTextVNode("v-tooltip")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" props.")
                  ]),
                  createVNode(_component_examples_example, { file: "v-tooltip-directive/modifiers" })
                ]),
                createBaseVNode("section", _hoisted_14, [
                  createVNode(_component_app_heading, {
                    href: "#object-literals",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Object literals")
                    ]),
                    _: 1
                  }),
                  _hoisted_15,
                  createVNode(_component_examples_example, { file: "v-tooltip-directive/object-literals" })
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
