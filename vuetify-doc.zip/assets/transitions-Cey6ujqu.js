import { J as ref, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, b as createVNode, h as createTextVNode, D as withDirectives, aq as vShow, e as createBaseVNode, y as _export_sfc, l as createElementBlock, a9 as mergeProps, F as Fragment, v as renderList, t as toDisplayString, j as computed, ap as withKeys, q as createCommentVNode, U as normalizeClass } from "./index-DGybHjCP.js";
const _hoisted_1$a = /* @__PURE__ */ createBaseVNode("div", { class: "mx-4 hidden-sm-and-down" }, null, -1);
const _sfc_main$a = {
  __name: "misc-expand-x",
  setup(__props) {
    const expand = ref(false);
    const expand2 = ref(false);
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_card = resolveComponent("v-card");
      const _component_v_expand_transition = resolveComponent("v-expand-transition");
      const _component_v_col = resolveComponent("v-col");
      const _component_v_expand_x_transition = resolveComponent("v-expand-x-transition");
      const _component_v_row = resolveComponent("v-row");
      return openBlock(), createBlock(_component_v_row, {
        justify: "center",
        style: { "min-height": "160px" }
      }, {
        default: withCtx(() => [
          createVNode(_component_v_col, { class: "shrink" }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, {
                class: "ma-2",
                color: "primary",
                onClick: _cache[0] || (_cache[0] = ($event) => expand.value = !expand.value)
              }, {
                default: withCtx(() => [
                  createTextVNode(" Expand Transition ")
                ]),
                _: 1
              }),
              createVNode(_component_v_expand_transition, null, {
                default: withCtx(() => [
                  withDirectives(createVNode(_component_v_card, {
                    class: "mx-auto bg-secondary",
                    height: "100",
                    width: "100"
                  }, null, 512), [
                    [vShow, expand.value]
                  ])
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          _hoisted_1$a,
          createVNode(_component_v_col, { class: "shrink" }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, {
                class: "ma-2",
                color: "secondary",
                onClick: _cache[1] || (_cache[1] = ($event) => expand2.value = !expand2.value)
              }, {
                default: withCtx(() => [
                  createTextVNode(" Expand X Transition ")
                ]),
                _: 1
              }),
              createVNode(_component_v_expand_x_transition, null, {
                default: withCtx(() => [
                  withDirectives(createVNode(_component_v_card, {
                    class: "mx-auto bg-secondary",
                    height: "100",
                    width: "100"
                  }, null, 512), [
                    [vShow, expand2.value]
                  ])
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __0 = _sfc_main$a;
const __0_raw = `<template>
  <v-row
    justify="center"

    style="min-height: 160px;"
  >
    <v-col class="shrink">
      <v-btn
        class="ma-2"
        color="primary"
        @click="expand = !expand"
      >
        Expand Transition
      </v-btn>

      <v-expand-transition>
        <v-card
          v-show="expand"
          class="mx-auto bg-secondary"
          height="100"
          width="100"
        ></v-card>
      </v-expand-transition>
    </v-col>

    <div class="mx-4 hidden-sm-and-down"></div>

    <v-col class="shrink">
      <v-btn
        class="ma-2"
        color="secondary"
        @click="expand2 = !expand2"
      >
        Expand X Transition
      </v-btn>

      <v-expand-x-transition>
        <v-card
          v-show="expand2"
          class="mx-auto bg-secondary"
          height="100"
          width="100"
        ></v-card>
      </v-expand-x-transition>
    </v-col>
  </v-row>
</template>

<script setup>
  import { ref } from 'vue'

  const expand = ref(false)
  const expand2 = ref(false)
<\/script>

<script>
  export default {
    data: () => ({
      expand: false,
      expand2: false,
    }),
  }
<\/script>
`;
const _sfc_main$9 = {};
const _hoisted_1$9 = { class: "text-center" };
function _sfc_render$8(_ctx, _cache) {
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_list_item_title = resolveComponent("v-list-item-title");
  const _component_v_list_item = resolveComponent("v-list-item");
  const _component_v_list = resolveComponent("v-list");
  const _component_v_menu = resolveComponent("v-menu");
  return openBlock(), createElementBlock("div", _hoisted_1$9, [
    createVNode(_component_v_menu, { transition: "fab-transition" }, {
      activator: withCtx(({ props }) => [
        createVNode(_component_v_btn, mergeProps({
          color: "primary",
          dark: ""
        }, props), {
          default: withCtx(() => [
            createTextVNode(" Fab Transition ")
          ]),
          _: 2
        }, 1040)
      ]),
      default: withCtx(() => [
        createVNode(_component_v_list, null, {
          default: withCtx(() => [
            (openBlock(), createElementBlock(Fragment, null, renderList(5, (n) => {
              return createVNode(_component_v_list_item, { key: n }, {
                default: withCtx(() => [
                  createVNode(_component_v_list_item_title, {
                    textContent: toDisplayString("Item " + n)
                  }, null, 8, ["textContent"])
                ]),
                _: 2
              }, 1024);
            }), 64))
          ]),
          _: 1
        })
      ]),
      _: 1
    })
  ]);
}
const __1 = /* @__PURE__ */ _export_sfc(_sfc_main$9, [["render", _sfc_render$8]]);
const __1_raw = `<template>
  <div class="text-center">
    <v-menu transition="fab-transition">
      <template v-slot:activator="{ props }">
        <v-btn
          color="primary"
          dark
          v-bind="props"
        >
          Fab Transition
        </v-btn>
      </template>
      <v-list>
        <v-list-item
          v-for="n in 5"
          :key="n"
        >
          <v-list-item-title v-text="'Item ' + n"></v-list-item-title>
        </v-list-item>
      </v-list>
    </v-menu>
  </div>
</template>
`;
const _sfc_main$8 = {};
const _hoisted_1$8 = { class: "text-center" };
function _sfc_render$7(_ctx, _cache) {
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_list_item_title = resolveComponent("v-list-item-title");
  const _component_v_list_item = resolveComponent("v-list-item");
  const _component_v_list = resolveComponent("v-list");
  const _component_v_menu = resolveComponent("v-menu");
  return openBlock(), createElementBlock("div", _hoisted_1$8, [
    createVNode(_component_v_menu, { transition: "fade-transition" }, {
      activator: withCtx(({ props }) => [
        createVNode(_component_v_btn, mergeProps({
          color: "primary",
          dark: ""
        }, props), {
          default: withCtx(() => [
            createTextVNode(" Fade Transition ")
          ]),
          _: 2
        }, 1040)
      ]),
      default: withCtx(() => [
        createVNode(_component_v_list, null, {
          default: withCtx(() => [
            (openBlock(), createElementBlock(Fragment, null, renderList(5, (n) => {
              return createVNode(_component_v_list_item, { key: n }, {
                default: withCtx(() => [
                  createVNode(_component_v_list_item_title, {
                    textContent: toDisplayString("Item " + n)
                  }, null, 8, ["textContent"])
                ]),
                _: 2
              }, 1024);
            }), 64))
          ]),
          _: 1
        })
      ]),
      _: 1
    })
  ]);
}
const __2 = /* @__PURE__ */ _export_sfc(_sfc_main$8, [["render", _sfc_render$7]]);
const __2_raw = `<template>
  <div class="text-center">
    <v-menu transition="fade-transition">
      <template v-slot:activator="{ props }">
        <v-btn
          color="primary"
          dark
          v-bind="props"
        >
          Fade Transition
        </v-btn>
      </template>
      <v-list>
        <v-list-item
          v-for="n in 5"
          :key="n"
        >
          <v-list-item-title v-text="'Item ' + n"></v-list-item-title>
        </v-list-item>
      </v-list>
    </v-menu>
  </div>
</template>
`;
const _sfc_main$7 = {};
const _hoisted_1$7 = { class: "text-center" };
function _sfc_render$6(_ctx, _cache) {
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_list_item_title = resolveComponent("v-list-item-title");
  const _component_v_list_item = resolveComponent("v-list-item");
  const _component_v_list = resolveComponent("v-list");
  const _component_v_menu = resolveComponent("v-menu");
  return openBlock(), createElementBlock("div", _hoisted_1$7, [
    createVNode(_component_v_menu, { transition: "scale-transition" }, {
      activator: withCtx(({ props }) => [
        createVNode(_component_v_btn, mergeProps({
          color: "primary",
          dark: ""
        }, props), {
          default: withCtx(() => [
            createTextVNode(" Scale Transition ")
          ]),
          _: 2
        }, 1040)
      ]),
      default: withCtx(() => [
        createVNode(_component_v_list, null, {
          default: withCtx(() => [
            (openBlock(), createElementBlock(Fragment, null, renderList(5, (n) => {
              return createVNode(_component_v_list_item, { key: n }, {
                default: withCtx(() => [
                  createVNode(_component_v_list_item_title, {
                    textContent: toDisplayString("Item " + n)
                  }, null, 8, ["textContent"])
                ]),
                _: 2
              }, 1024);
            }), 64))
          ]),
          _: 1
        })
      ]),
      _: 1
    })
  ]);
}
const __3 = /* @__PURE__ */ _export_sfc(_sfc_main$7, [["render", _sfc_render$6]]);
const __3_raw = `<template>
  <div class="text-center">
    <v-menu transition="scale-transition">
      <template v-slot:activator="{ props }">
        <v-btn
          color="primary"
          dark
          v-bind="props"
        >
          Scale Transition
        </v-btn>
      </template>
      <v-list>
        <v-list-item
          v-for="n in 5"
          :key="n"
        >
          <v-list-item-title v-text="'Item ' + n"></v-list-item-title>
        </v-list-item>
      </v-list>
    </v-menu>
  </div>
</template>
`;
const _sfc_main$6 = {};
const _hoisted_1$6 = /* @__PURE__ */ createBaseVNode("div", { class: "mx-4 hidden-sm-and-down" }, null, -1);
function _sfc_render$5(_ctx, _cache) {
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_list_item_title = resolveComponent("v-list-item-title");
  const _component_v_list_item = resolveComponent("v-list-item");
  const _component_v_list = resolveComponent("v-list");
  const _component_v_menu = resolveComponent("v-menu");
  const _component_v_row = resolveComponent("v-row");
  return openBlock(), createBlock(_component_v_row, { justify: "center" }, {
    default: withCtx(() => [
      createVNode(_component_v_menu, { transition: "scroll-x-transition" }, {
        activator: withCtx(({ props }) => [
          createVNode(_component_v_btn, mergeProps({
            class: "ma-2",
            color: "primary"
          }, props), {
            default: withCtx(() => [
              createTextVNode(" Scroll X Transition ")
            ]),
            _: 2
          }, 1040)
        ]),
        default: withCtx(() => [
          createVNode(_component_v_list, null, {
            default: withCtx(() => [
              (openBlock(), createElementBlock(Fragment, null, renderList(5, (n) => {
                return createVNode(_component_v_list_item, {
                  key: n,
                  link: ""
                }, {
                  default: withCtx(() => [
                    createVNode(_component_v_list_item_title, {
                      textContent: toDisplayString("Item " + n)
                    }, null, 8, ["textContent"])
                  ]),
                  _: 2
                }, 1024);
              }), 64))
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      _hoisted_1$6,
      createVNode(_component_v_menu, { transition: "scroll-x-reverse-transition" }, {
        activator: withCtx(({ props }) => [
          createVNode(_component_v_btn, mergeProps({
            class: "ma-2",
            color: "secondary"
          }, props), {
            default: withCtx(() => [
              createTextVNode(" Scroll X Reverse Transition ")
            ]),
            _: 2
          }, 1040)
        ]),
        default: withCtx(() => [
          createVNode(_component_v_list, null, {
            default: withCtx(() => [
              (openBlock(), createElementBlock(Fragment, null, renderList(5, (n) => {
                return createVNode(_component_v_list_item, {
                  key: n,
                  link: ""
                }, {
                  default: withCtx(() => [
                    createVNode(_component_v_list_item_title, {
                      textContent: toDisplayString("Item " + n)
                    }, null, 8, ["textContent"])
                  ]),
                  _: 2
                }, 1024);
              }), 64))
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __4 = /* @__PURE__ */ _export_sfc(_sfc_main$6, [["render", _sfc_render$5]]);
const __4_raw = `<template>
  <v-row
    justify="center"
  >
    <v-menu transition="scroll-x-transition">
      <template v-slot:activator="{ props }">
        <v-btn
          class="ma-2"
          color="primary"
          v-bind="props"
        >
          Scroll X Transition
        </v-btn>
      </template>
      <v-list>
        <v-list-item
          v-for="n in 5"
          :key="n"
          link
        >
          <v-list-item-title v-text="'Item ' + n"></v-list-item-title>
        </v-list-item>
      </v-list>
    </v-menu>

    <div class="mx-4 hidden-sm-and-down"></div>

    <v-menu transition="scroll-x-reverse-transition">
      <template v-slot:activator="{ props }">
        <v-btn
          class="ma-2"
          color="secondary"
          v-bind="props"
        >
          Scroll X Reverse Transition
        </v-btn>
      </template>
      <v-list>
        <v-list-item
          v-for="n in 5"
          :key="n"
          link
        >
          <v-list-item-title v-text="'Item ' + n"></v-list-item-title>
        </v-list-item>
      </v-list>
    </v-menu>
  </v-row>
</template>
`;
const _sfc_main$5 = {};
const _hoisted_1$5 = /* @__PURE__ */ createBaseVNode("div", { class: "mx-4 hidden-sm-and-down" }, null, -1);
function _sfc_render$4(_ctx, _cache) {
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_list_item_title = resolveComponent("v-list-item-title");
  const _component_v_list_item = resolveComponent("v-list-item");
  const _component_v_list = resolveComponent("v-list");
  const _component_v_menu = resolveComponent("v-menu");
  const _component_v_row = resolveComponent("v-row");
  return openBlock(), createBlock(_component_v_row, { justify: "center" }, {
    default: withCtx(() => [
      createVNode(_component_v_menu, { transition: "scroll-y-transition" }, {
        activator: withCtx(({ props }) => [
          createVNode(_component_v_btn, mergeProps({
            class: "ma-2",
            color: "primary"
          }, props), {
            default: withCtx(() => [
              createTextVNode(" Scroll Y Transition ")
            ]),
            _: 2
          }, 1040)
        ]),
        default: withCtx(() => [
          createVNode(_component_v_list, null, {
            default: withCtx(() => [
              (openBlock(), createElementBlock(Fragment, null, renderList(5, (n) => {
                return createVNode(_component_v_list_item, {
                  key: n,
                  link: ""
                }, {
                  default: withCtx(() => [
                    createVNode(_component_v_list_item_title, {
                      textContent: toDisplayString("Item " + n)
                    }, null, 8, ["textContent"])
                  ]),
                  _: 2
                }, 1024);
              }), 64))
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      _hoisted_1$5,
      createVNode(_component_v_menu, { transition: "scroll-y-reverse-transition" }, {
        activator: withCtx(({ props }) => [
          createVNode(_component_v_btn, mergeProps({
            class: "ma-2",
            color: "secondary"
          }, props), {
            default: withCtx(() => [
              createTextVNode(" Scroll Y Reverse Transition ")
            ]),
            _: 2
          }, 1040)
        ]),
        default: withCtx(() => [
          createVNode(_component_v_list, null, {
            default: withCtx(() => [
              (openBlock(), createElementBlock(Fragment, null, renderList(5, (n) => {
                return createVNode(_component_v_list_item, {
                  key: n,
                  link: ""
                }, {
                  default: withCtx(() => [
                    createVNode(_component_v_list_item_title, {
                      textContent: toDisplayString("Item " + n)
                    }, null, 8, ["textContent"])
                  ]),
                  _: 2
                }, 1024);
              }), 64))
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __5 = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["render", _sfc_render$4]]);
const __5_raw = `<template>
  <v-row
    justify="center"
  >
    <v-menu transition="scroll-y-transition">
      <template v-slot:activator="{ props }">
        <v-btn
          class="ma-2"
          color="primary"
          v-bind="props"
        >
          Scroll Y Transition
        </v-btn>
      </template>
      <v-list>
        <v-list-item
          v-for="n in 5"
          :key="n"
          link
        >
          <v-list-item-title v-text="'Item ' + n"></v-list-item-title>
        </v-list-item>
      </v-list>
    </v-menu>

    <div class="mx-4 hidden-sm-and-down"></div>

    <v-menu transition="scroll-y-reverse-transition">
      <template v-slot:activator="{ props }">
        <v-btn
          class="ma-2"
          color="secondary"
          v-bind="props"
        >
          Scroll Y Reverse Transition
        </v-btn>
      </template>
      <v-list>
        <v-list-item
          v-for="n in 5"
          :key="n"
          link
        >
          <v-list-item-title v-text="'Item ' + n"></v-list-item-title>
        </v-list-item>
      </v-list>
    </v-menu>
  </v-row>
</template>
`;
const _sfc_main$4 = {};
const _hoisted_1$4 = /* @__PURE__ */ createBaseVNode("div", { class: "mx-4 hidden-sm-and-down" }, null, -1);
function _sfc_render$3(_ctx, _cache) {
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_list_item_title = resolveComponent("v-list-item-title");
  const _component_v_list_item = resolveComponent("v-list-item");
  const _component_v_list = resolveComponent("v-list");
  const _component_v_menu = resolveComponent("v-menu");
  const _component_v_row = resolveComponent("v-row");
  return openBlock(), createBlock(_component_v_row, { justify: "center" }, {
    default: withCtx(() => [
      createVNode(_component_v_menu, { transition: "slide-x-transition" }, {
        activator: withCtx(({ props }) => [
          createVNode(_component_v_btn, mergeProps({
            class: "ma-2",
            color: "primary"
          }, props), {
            default: withCtx(() => [
              createTextVNode(" Slide X Transition ")
            ]),
            _: 2
          }, 1040)
        ]),
        default: withCtx(() => [
          createVNode(_component_v_list, null, {
            default: withCtx(() => [
              (openBlock(), createElementBlock(Fragment, null, renderList(5, (n) => {
                return createVNode(_component_v_list_item, {
                  key: n,
                  link: ""
                }, {
                  default: withCtx(() => [
                    createVNode(_component_v_list_item_title, {
                      textContent: toDisplayString("Item " + n)
                    }, null, 8, ["textContent"])
                  ]),
                  _: 2
                }, 1024);
              }), 64))
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      _hoisted_1$4,
      createVNode(_component_v_menu, { transition: "slide-x-reverse-transition" }, {
        activator: withCtx(({ props }) => [
          createVNode(_component_v_btn, mergeProps({
            class: "ma-2",
            color: "secondary"
          }, props), {
            default: withCtx(() => [
              createTextVNode(" Slide X Reverse Transition ")
            ]),
            _: 2
          }, 1040)
        ]),
        default: withCtx(() => [
          createVNode(_component_v_list, null, {
            default: withCtx(() => [
              (openBlock(), createElementBlock(Fragment, null, renderList(5, (n) => {
                return createVNode(_component_v_list_item, {
                  key: n,
                  link: ""
                }, {
                  default: withCtx(() => [
                    createVNode(_component_v_list_item_title, {
                      textContent: toDisplayString("Item " + n)
                    }, null, 8, ["textContent"])
                  ]),
                  _: 2
                }, 1024);
              }), 64))
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __6 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["render", _sfc_render$3]]);
const __6_raw = `<template>
  <v-row
    justify="center"
  >
    <v-menu transition="slide-x-transition">
      <template v-slot:activator="{ props }">
        <v-btn
          class="ma-2"
          color="primary"
          v-bind="props"
        >
          Slide X Transition
        </v-btn>
      </template>
      <v-list>
        <v-list-item
          v-for="n in 5"
          :key="n"
          link
        >
          <v-list-item-title v-text="'Item ' + n"></v-list-item-title>
        </v-list-item>
      </v-list>
    </v-menu>

    <div class="mx-4 hidden-sm-and-down"></div>

    <v-menu transition="slide-x-reverse-transition">
      <template v-slot:activator="{ props }">
        <v-btn
          class="ma-2"
          color="secondary"
          v-bind="props"
        >
          Slide X Reverse Transition
        </v-btn>
      </template>
      <v-list>
        <v-list-item
          v-for="n in 5"
          :key="n"
          link
        >
          <v-list-item-title v-text="'Item ' + n"></v-list-item-title>
        </v-list-item>
      </v-list>
    </v-menu>
  </v-row>
</template>
`;
const _sfc_main$3 = {};
const _hoisted_1$3 = /* @__PURE__ */ createBaseVNode("div", { class: "mx-4 hidden-sm-and-down" }, null, -1);
function _sfc_render$2(_ctx, _cache) {
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_list_item_title = resolveComponent("v-list-item-title");
  const _component_v_list_item = resolveComponent("v-list-item");
  const _component_v_list = resolveComponent("v-list");
  const _component_v_menu = resolveComponent("v-menu");
  const _component_v_row = resolveComponent("v-row");
  return openBlock(), createBlock(_component_v_row, { justify: "center" }, {
    default: withCtx(() => [
      createVNode(_component_v_menu, { transition: "slide-y-transition" }, {
        activator: withCtx(({ props }) => [
          createVNode(_component_v_btn, mergeProps({
            class: "ma-2",
            color: "primary"
          }, props), {
            default: withCtx(() => [
              createTextVNode(" Slide Y Transition ")
            ]),
            _: 2
          }, 1040)
        ]),
        default: withCtx(() => [
          createVNode(_component_v_list, null, {
            default: withCtx(() => [
              (openBlock(), createElementBlock(Fragment, null, renderList(5, (n) => {
                return createVNode(_component_v_list_item, {
                  key: n,
                  link: ""
                }, {
                  default: withCtx(() => [
                    createVNode(_component_v_list_item_title, {
                      textContent: toDisplayString("Item " + n)
                    }, null, 8, ["textContent"])
                  ]),
                  _: 2
                }, 1024);
              }), 64))
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      _hoisted_1$3,
      createVNode(_component_v_menu, { transition: "slide-y-reverse-transition" }, {
        activator: withCtx(({ props }) => [
          createVNode(_component_v_btn, mergeProps({
            class: "ma-2",
            color: "secondary"
          }, props), {
            default: withCtx(() => [
              createTextVNode(" Slide Y Reverse Transition ")
            ]),
            _: 2
          }, 1040)
        ]),
        default: withCtx(() => [
          createVNode(_component_v_list, null, {
            default: withCtx(() => [
              (openBlock(), createElementBlock(Fragment, null, renderList(5, (n) => {
                return createVNode(_component_v_list_item, {
                  key: n,
                  link: ""
                }, {
                  default: withCtx(() => [
                    createVNode(_component_v_list_item_title, {
                      textContent: toDisplayString("Item " + n)
                    }, null, 8, ["textContent"])
                  ]),
                  _: 2
                }, 1024);
              }), 64))
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __7 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["render", _sfc_render$2]]);
const __7_raw = `<template>
  <v-row
    justify="center"
  >
    <v-menu transition="slide-y-transition">
      <template v-slot:activator="{ props }">
        <v-btn
          class="ma-2"
          color="primary"
          v-bind="props"
        >
          Slide Y Transition
        </v-btn>
      </template>
      <v-list>
        <v-list-item
          v-for="n in 5"
          :key="n"
          link
        >
          <v-list-item-title v-text="'Item ' + n"></v-list-item-title>
        </v-list-item>
      </v-list>
    </v-menu>

    <div class="mx-4 hidden-sm-and-down"></div>

    <v-menu transition="slide-y-reverse-transition">
      <template v-slot:activator="{ props }">
        <v-btn
          class="ma-2"
          color="secondary"
          v-bind="props"
        >
          Slide Y Reverse Transition
        </v-btn>
      </template>
      <v-list>
        <v-list-item
          v-for="n in 5"
          :key="n"
          link
        >
          <v-list-item-title v-text="'Item ' + n"></v-list-item-title>
        </v-list-item>
      </v-list>
    </v-menu>
  </v-row>
</template>
`;
const _hoisted_1$2 = { class: "text-h4 text-success ps-4" };
const _hoisted_2 = { class: "mx-4 text-info-darken-2" };
const _hoisted_3 = { class: "mx-4 text-success-darken-2" };
const _sfc_main$2 = {
  __name: "misc-todo",
  setup(__props) {
    const tasks = ref([
      {
        done: false,
        text: "Foobar"
      },
      {
        done: false,
        text: "Fizzbuzz"
      }
    ]);
    const newTask = ref(null);
    const completedTasks = computed(() => {
      return tasks.value.filter((task) => task.done).length;
    });
    const progress = computed(() => {
      return completedTasks.value / tasks.value.length * 100;
    });
    const remainingTasks = computed(() => {
      return tasks.value.length - completedTasks.value;
    });
    function create() {
      tasks.value.push({
        done: false,
        text: newTask.value
      });
      newTask.value = null;
    }
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_fade_transition = resolveComponent("v-fade-transition");
      const _component_v_text_field = resolveComponent("v-text-field");
      const _component_v_divider = resolveComponent("v-divider");
      const _component_v_spacer = resolveComponent("v-spacer");
      const _component_v_progress_circular = resolveComponent("v-progress-circular");
      const _component_v_row = resolveComponent("v-row");
      const _component_v_checkbox_btn = resolveComponent("v-checkbox-btn");
      const _component_v_list_item_title = resolveComponent("v-list-item-title");
      const _component_v_icon = resolveComponent("v-icon");
      const _component_v_expand_x_transition = resolveComponent("v-expand-x-transition");
      const _component_v_list_item = resolveComponent("v-list-item");
      const _component_v_slide_y_transition = resolveComponent("v-slide-y-transition");
      const _component_v_card = resolveComponent("v-card");
      const _component_v_container = resolveComponent("v-container");
      return openBlock(), createBlock(_component_v_container, { style: { "max-width": "500px" } }, {
        default: withCtx(() => [
          createVNode(_component_v_text_field, {
            modelValue: newTask.value,
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => newTask.value = $event),
            label: "What are you working on?",
            variant: "solo",
            onKeydown: withKeys(create, ["enter"])
          }, {
            "append-inner": withCtx(() => [
              createVNode(_component_v_fade_transition, null, {
                default: withCtx(() => [
                  withDirectives(createVNode(_component_v_btn, {
                    icon: "mdi-plus-circle",
                    variant: "text",
                    onClick: create
                  }, null, 512), [
                    [vShow, newTask.value]
                  ])
                ]),
                _: 1
              })
            ]),
            _: 1
          }, 8, ["modelValue"]),
          createBaseVNode("h2", _hoisted_1$2, [
            createTextVNode(" Tasks:  "),
            createVNode(_component_v_fade_transition, { "leave-absolute": "" }, {
              default: withCtx(() => [
                (openBlock(), createElementBlock("span", {
                  key: `tasks-${tasks.value.length}`
                }, toDisplayString(tasks.value.length), 1))
              ]),
              _: 1
            })
          ]),
          createVNode(_component_v_divider, { class: "mt-4" }),
          createVNode(_component_v_row, {
            align: "center",
            class: "my-1"
          }, {
            default: withCtx(() => [
              createBaseVNode("strong", _hoisted_2, " Remaining: " + toDisplayString(remainingTasks.value), 1),
              createVNode(_component_v_divider, { vertical: "" }),
              createBaseVNode("strong", _hoisted_3, " Completed: " + toDisplayString(completedTasks.value), 1),
              createVNode(_component_v_spacer),
              createVNode(_component_v_progress_circular, {
                modelValue: progress.value,
                "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => progress.value = $event),
                class: "me-2"
              }, null, 8, ["modelValue"])
            ]),
            _: 1
          }),
          createVNode(_component_v_divider, { class: "mb-4" }),
          tasks.value.length > 0 ? (openBlock(), createBlock(_component_v_card, { key: 0 }, {
            default: withCtx(() => [
              createVNode(_component_v_slide_y_transition, {
                class: "py-0",
                tag: "v-list",
                group: ""
              }, {
                default: withCtx(() => [
                  (openBlock(true), createElementBlock(Fragment, null, renderList(tasks.value, (task, i) => {
                    return openBlock(), createElementBlock(Fragment, {
                      key: `${i}-${task.text}`
                    }, [
                      i !== 0 ? (openBlock(), createBlock(_component_v_divider, {
                        key: `${i}-divider`
                      })) : createCommentVNode("", true),
                      createVNode(_component_v_list_item, {
                        onClick: ($event) => task.done = !task.done
                      }, {
                        prepend: withCtx(() => [
                          createVNode(_component_v_checkbox_btn, {
                            modelValue: task.done,
                            "onUpdate:modelValue": ($event) => task.done = $event,
                            color: "grey"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"])
                        ]),
                        append: withCtx(() => [
                          createVNode(_component_v_expand_x_transition, null, {
                            default: withCtx(() => [
                              task.done ? (openBlock(), createBlock(_component_v_icon, {
                                key: 0,
                                color: "success"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(" mdi-check ")
                                ]),
                                _: 1
                              })) : createCommentVNode("", true)
                            ]),
                            _: 2
                          }, 1024)
                        ]),
                        default: withCtx(() => [
                          createVNode(_component_v_list_item_title, null, {
                            default: withCtx(() => [
                              createBaseVNode("span", {
                                class: normalizeClass(task.done ? "text-grey" : "text-primary")
                              }, toDisplayString(task.text), 3)
                            ]),
                            _: 2
                          }, 1024)
                        ]),
                        _: 2
                      }, 1032, ["onClick"])
                    ], 64);
                  }), 128))
                ]),
                _: 1
              })
            ]),
            _: 1
          })) : createCommentVNode("", true)
        ]),
        _: 1
      });
    };
  }
};
const __8 = _sfc_main$2;
const __8_raw = `<template>
  <v-container style="max-width: 500px">
    <v-text-field
      v-model="newTask"
      label="What are you working on?"
      variant="solo"
      @keydown.enter="create"
    >
      <template v-slot:append-inner>
        <v-fade-transition>
          <v-btn
            v-show="newTask"
            icon="mdi-plus-circle"
            variant="text"
            @click="create"
          ></v-btn>
        </v-fade-transition>
      </template>
    </v-text-field>

    <h2 class="text-h4 text-success ps-4">
      Tasks:&nbsp;
      <v-fade-transition leave-absolute>
        <span :key="\`tasks-\${tasks.length}\`">
          {{ tasks.length }}
        </span>
      </v-fade-transition>
    </h2>

    <v-divider class="mt-4"></v-divider>

    <v-row
      align="center"
      class="my-1"
    >
      <strong class="mx-4 text-info-darken-2">
        Remaining: {{ remainingTasks }}
      </strong>

      <v-divider vertical></v-divider>

      <strong class="mx-4 text-success-darken-2">
        Completed: {{ completedTasks }}
      </strong>

      <v-spacer></v-spacer>

      <v-progress-circular
        v-model="progress"
        class="me-2"
      ></v-progress-circular>
    </v-row>

    <v-divider class="mb-4"></v-divider>

    <v-card v-if="tasks.length > 0">
      <v-slide-y-transition
        class="py-0"
        tag="v-list"
        group
      >
        <template v-for="(task, i) in tasks" :key="\`\${i}-\${task.text}\`">
          <v-divider
            v-if="i !== 0"
            :key="\`\${i}-divider\`"
          ></v-divider>

          <v-list-item @click="task.done = !task.done">
            <template v-slot:prepend>
              <v-checkbox-btn v-model="task.done" color="grey"></v-checkbox-btn>
            </template>

            <v-list-item-title>
              <span :class="task.done ? 'text-grey' : 'text-primary'">{{ task.text }}</span>
            </v-list-item-title>

            <template v-slot:append>
              <v-expand-x-transition>
                <v-icon v-if="task.done" color="success">
                  mdi-check
                </v-icon>
              </v-expand-x-transition>
            </template>
          </v-list-item>
        </template>
      </v-slide-y-transition>
    </v-card>
  </v-container>
</template>
<script setup>
  import { computed, ref } from 'vue'

  const tasks = ref([
    {
      done: false,
      text: 'Foobar',
    },
    {
      done: false,
      text: 'Fizzbuzz',
    },
  ])
  const newTask = ref(null)

  const completedTasks = computed(() => {
    return tasks.value.filter(task => task.done).length
  })
  const progress = computed(() => {
    return completedTasks.value / tasks.value.length * 100
  })
  const remainingTasks = computed(() => {
    return tasks.value.length - completedTasks.value
  })

  function create () {
    tasks.value.push({
      done: false,
      text: newTask.value,
    })
    newTask.value = null
  }
<\/script>

<script>
  export default {
    data: () => ({
      tasks: [
        {
          done: false,
          text: 'Foobar',
        },
        {
          done: false,
          text: 'Fizzbuzz',
        },
      ],
      newTask: null,
    }),

    computed: {
      completedTasks () {
        return this.tasks.filter(task => task.done).length
      },
      progress () {
        return this.completedTasks / this.tasks.length * 100
      },
      remainingTasks () {
        return this.tasks.length - this.completedTasks
      },
    },

    methods: {
      create () {
        this.tasks.push({
          done: false,
          text: this.newTask,
        })

        this.newTask = null
      },
    },
  }
<\/script>
`;
const _sfc_main$1 = {};
const _hoisted_1$1 = { class: "text-center" };
function _sfc_render$1(_ctx, _cache) {
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_list_item_title = resolveComponent("v-list-item-title");
  const _component_v_list_item = resolveComponent("v-list-item");
  const _component_v_list = resolveComponent("v-list");
  const _component_v_menu = resolveComponent("v-menu");
  return openBlock(), createElementBlock("div", _hoisted_1$1, [
    createVNode(_component_v_menu, {
      origin: "center center",
      transition: "scale-transition"
    }, {
      activator: withCtx(({ props }) => [
        createVNode(_component_v_btn, mergeProps({
          color: "primary",
          dark: ""
        }, props), {
          default: withCtx(() => [
            createTextVNode(" Scale Transition ")
          ]),
          _: 2
        }, 1040)
      ]),
      default: withCtx(() => [
        createVNode(_component_v_list, null, {
          default: withCtx(() => [
            (openBlock(), createElementBlock(Fragment, null, renderList(5, (n) => {
              return createVNode(_component_v_list_item, {
                key: n,
                onClick: () => {
                }
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_list_item_title, {
                    textContent: toDisplayString("Item " + n)
                  }, null, 8, ["textContent"])
                ]),
                _: 2
              }, 1024);
            }), 64))
          ]),
          _: 1
        })
      ]),
      _: 1
    })
  ]);
}
const __9 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["render", _sfc_render$1]]);
const __9_raw = `<template>
  <div class="text-center">
    <v-menu
      origin="center center"
      transition="scale-transition"
    >
      <template v-slot:activator="{ props }">
        <v-btn
          color="primary"
          dark
          v-bind="props"
        >
          Scale Transition
        </v-btn>
      </template>
      <v-list>
        <v-list-item
          v-for="n in 5"
          :key="n"
          @click="() => {}"
        >
          <v-list-item-title v-text="'Item ' + n"></v-list-item-title>
        </v-list-item>
      </v-list>
    </v-menu>
  </div>
</template>
`;
const _sfc_main = {};
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("div", { class: "mx-6 hidden-sm-and-down" }, null, -1);
function _sfc_render(_ctx, _cache) {
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_list_item_title = resolveComponent("v-list-item-title");
  const _component_v_list_item = resolveComponent("v-list-item");
  const _component_v_list = resolveComponent("v-list");
  const _component_v_menu = resolveComponent("v-menu");
  const _component_v_row = resolveComponent("v-row");
  return openBlock(), createBlock(_component_v_row, { justify: "center" }, {
    default: withCtx(() => [
      createVNode(_component_v_menu, { transition: "slide-x-transition" }, {
        activator: withCtx(({ props }) => [
          createVNode(_component_v_btn, mergeProps({
            class: "ma-2",
            color: "primary"
          }, props), {
            default: withCtx(() => [
              createTextVNode(" Slide X Transition ")
            ]),
            _: 2
          }, 1040)
        ]),
        default: withCtx(() => [
          createVNode(_component_v_list, null, {
            default: withCtx(() => [
              (openBlock(), createElementBlock(Fragment, null, renderList(5, (n) => {
                return createVNode(_component_v_list_item, {
                  key: n,
                  link: ""
                }, {
                  default: withCtx(() => [
                    createVNode(_component_v_list_item_title, {
                      textContent: toDisplayString("Item " + n)
                    }, null, 8, ["textContent"])
                  ]),
                  _: 2
                }, 1024);
              }), 64))
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      _hoisted_1,
      createVNode(_component_v_menu, { transition: "scroll-y-transition" }, {
        activator: withCtx(({ props }) => [
          createVNode(_component_v_btn, mergeProps({
            class: "ma-2",
            color: "secondary"
          }, props), {
            default: withCtx(() => [
              createTextVNode(" Scroll Y Transition ")
            ]),
            _: 2
          }, 1040)
        ]),
        default: withCtx(() => [
          createVNode(_component_v_list, null, {
            default: withCtx(() => [
              (openBlock(), createElementBlock(Fragment, null, renderList(5, (n) => {
                return createVNode(_component_v_list_item, {
                  key: n,
                  link: ""
                }, {
                  default: withCtx(() => [
                    createVNode(_component_v_list_item_title, {
                      textContent: toDisplayString("Item " + n)
                    }, null, 8, ["textContent"])
                  ]),
                  _: 2
                }, 1024);
              }), 64))
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __10 = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
const __10_raw = `<template>
  <v-row justify="center">
    <v-menu transition="slide-x-transition">
      <template v-slot:activator="{ props }">
        <v-btn
          class="ma-2"
          color="primary"
          v-bind="props"
        >
          Slide X Transition
        </v-btn>
      </template>
      <v-list>
        <v-list-item
          v-for="n in 5"
          :key="n"
          link
        >
          <v-list-item-title v-text="'Item ' + n"></v-list-item-title>
        </v-list-item>
      </v-list>
    </v-menu>

    <div class="mx-6 hidden-sm-and-down"></div>

    <v-menu transition="scroll-y-transition">
      <template v-slot:activator="{ props }">
        <v-btn
          class="ma-2"
          color="secondary"
          v-bind="props"
        >
          Scroll Y Transition
        </v-btn>
      </template>
      <v-list>
        <v-list-item
          v-for="n in 5"
          :key="n"
          link
        >
          <v-list-item-title v-text="'Item ' + n"></v-list-item-title>
        </v-list-item>
      </v-list>
    </v-menu>
  </v-row>
</template>
`;
const transitions = {
  "misc-expand-x": {
    component: __0,
    source: __0_raw
  },
  "misc-fab": {
    component: __1,
    source: __1_raw
  },
  "misc-fade": {
    component: __2,
    source: __2_raw
  },
  "misc-scale": {
    component: __3,
    source: __3_raw
  },
  "misc-scroll-x": {
    component: __4,
    source: __4_raw
  },
  "misc-scroll-y": {
    component: __5,
    source: __5_raw
  },
  "misc-slide-x": {
    component: __6,
    source: __6_raw
  },
  "misc-slide-y": {
    component: __7,
    source: __7_raw
  },
  "misc-todo": {
    component: __8,
    source: __8_raw
  },
  "prop-custom-origin": {
    component: __9,
    source: __9_raw
  },
  "usage": {
    component: __10,
    source: __10_raw
  }
};
export {
  transitions as default
};
