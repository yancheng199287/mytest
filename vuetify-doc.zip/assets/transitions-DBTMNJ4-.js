import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "transitions" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Smooth animations help make a UI feel great. Using Vue’s transition system and re-usable functional components, you can easily control the motion of your application. Most components can have their transition altered through the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "transition"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_3 = { id: "api" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Name"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createTextVNode("The expand transition is used in Expansion Panels and List Groups. There is also a horizontal version available with "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-expand-x-transition"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createTextVNode("An example of the fab transition can be found in the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-speed-dial"),
  /* @__PURE__ */ createTextVNode(" component.")
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "An example of the fade transition can be found on the Carousel component.", -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("td", null, [
  /* @__PURE__ */ createTextVNode("Many of Vuetify’s components contain a "),
  /* @__PURE__ */ createBaseVNode("strong", null, "transition"),
  /* @__PURE__ */ createTextVNode(" prop which allows you to specify your own.")
], -1);
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("td", null, "Scroll X transitions continue along the horizontal axis.", -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("td", null, "Scroll Y transitions continue along the vertical axis.", -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("td", null, "Slide X reverse transitions slide in from the right.", -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("td", null, "Slide X transitions slide in from the left.", -1);
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("td", null, "Slide Y reverse transitions slide in from the bottom.", -1);
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("td", null, "Slide Y transitions slide in from the top.", -1);
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("td", null, "Tab reverse transitions slide in from the right.", -1);
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("td", null, "Tab transitions slide in from the left.", -1);
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("td", null, "Toggle Slide X reverse transitions slide in from the right.", -1);
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("td", null, "Toggle Slide X transitions slide in from the left.", -1);
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("td", null, "Toggle Slide Y reverse transitions slide in from the bottom.", -1);
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("td", null, "Toggle Slide Y transitions slide in from the top.", -1);
const _hoisted_21 = { id: "examples" };
const _hoisted_22 = { id: "misc" };
const _hoisted_23 = { id: "expand-x" };
const _hoisted_24 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The expand transition is used in Expansion Panels and List Groups. There is also a horizontal version available with "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-expand-x-transition"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_25 = { id: "fab" };
const _hoisted_26 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("An example of the fab transition can be found in the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-speed-dial"),
  /* @__PURE__ */ createTextVNode(" component.")
], -1);
const _hoisted_27 = { id: "fade" };
const _hoisted_28 = /* @__PURE__ */ createBaseVNode("p", null, "An example of the fade transition can be found on the Carousel component.", -1);
const _hoisted_29 = { id: "scale" };
const _hoisted_30 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Many of Vuetify’s components contain a "),
  /* @__PURE__ */ createBaseVNode("strong", null, "transition"),
  /* @__PURE__ */ createTextVNode(" prop which allows you to specify your own.")
], -1);
const _hoisted_31 = { id: "scroll-x" };
const _hoisted_32 = /* @__PURE__ */ createBaseVNode("p", null, "Scroll X transitions continue along the horizontal axis.", -1);
const _hoisted_33 = { id: "scroll-y" };
const _hoisted_34 = /* @__PURE__ */ createBaseVNode("p", null, "Scroll Y transitions continue along the vertical axis.", -1);
const _hoisted_35 = { id: "slide-x" };
const _hoisted_36 = /* @__PURE__ */ createBaseVNode("p", null, "Slide x transitions move along the horizontal axis.", -1);
const _hoisted_37 = { id: "slide-y" };
const _hoisted_38 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Animations use the application’s "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "$primary-transition"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_39 = { id: "todo-list" };
const _hoisted_40 = /* @__PURE__ */ createBaseVNode("p", null, "Using multiple custom transitions, it is easy to bring a simple todo list to life!", -1);
const frontmatter = { "meta": { "title": "Transitions", "description": "Utilize Vuetify's built in CSS and Javascript transitions within components.", "keywords": "motion, transitions, vuetify transitions" }, "related": ["/components/menus/", "/styles/colors/", "/components/expansion-panels/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "transitions",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "Transitions", "description": "Utilize Vuetify's built in CSS and Javascript transitions within components.", "keywords": "motion, transitions, vuetify transitions" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "title": "Transitions", "description": "Utilize Vuetify's built in CSS and Javascript transitions within components.", "keywords": "motion, transitions, vuetify transitions" }, "related": ["/components/menus/", "/styles/colors/", "/components/expansion-panels/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#transitions",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Transitions")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_promoted_entry),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_4,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-expand-transition/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-expand-transition")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_5
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-fab-transition/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-fab-transition")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_6
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-fade-transition/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-fade-transition")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_7
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-scale-transition/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-scale-transition")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_8
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-scroll-x-transition/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-scroll-x-transition")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_9
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-scroll-y-transition/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-scroll-y-transition")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_10
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-slide-x-reverse-transition/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-slide-x-reverse-transition")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_11
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-slide-x-transition/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-slide-x-transition")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_12
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-slide-y-reverse-transition/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-slide-y-reverse-transition")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_13
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-slide-y-transition/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-slide-y-transition")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_14
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-tab-reverse-transition/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-tab-reverse-transition")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_15
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-tab-transition/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-tab-transition")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_16
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-toggle-slide-x-reverse-transition/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-toggle-slide-x-reverse-transition")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_17
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-toggle-slide-x-transition/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-toggle-slide-x-transition")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_18
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-toggle-slide-y-reverse-transition/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-toggle-slide-y-reverse-transition")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_19
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-toggle-slide-y-transition/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-toggle-slide-y-transition")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_20
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_21, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_22, [
                  createVNode(_component_app_heading, {
                    href: "#misc",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Misc")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_23, [
                    createVNode(_component_app_heading, {
                      href: "#expand-x",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Expand x")
                      ]),
                      _: 1
                    }),
                    _hoisted_24,
                    createVNode(_component_examples_example, { file: "transitions/misc-expand-x" })
                  ]),
                  createBaseVNode("section", _hoisted_25, [
                    createVNode(_component_app_heading, {
                      href: "#fab",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Fab")
                      ]),
                      _: 1
                    }),
                    _hoisted_26,
                    createVNode(_component_examples_example, { file: "transitions/misc-fab" })
                  ]),
                  createBaseVNode("section", _hoisted_27, [
                    createVNode(_component_app_heading, {
                      href: "#fade",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Fade")
                      ]),
                      _: 1
                    }),
                    _hoisted_28,
                    createVNode(_component_examples_example, { file: "transitions/misc-fade" })
                  ]),
                  createBaseVNode("section", _hoisted_29, [
                    createVNode(_component_app_heading, {
                      href: "#scale",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Scale")
                      ]),
                      _: 1
                    }),
                    _hoisted_30,
                    createVNode(_component_examples_example, { file: "transitions/misc-scale" })
                  ]),
                  createBaseVNode("section", _hoisted_31, [
                    createVNode(_component_app_heading, {
                      href: "#scroll-x",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Scroll x")
                      ]),
                      _: 1
                    }),
                    _hoisted_32,
                    createVNode(_component_examples_example, { file: "transitions/misc-scroll-x" })
                  ]),
                  createBaseVNode("section", _hoisted_33, [
                    createVNode(_component_app_heading, {
                      href: "#scroll-y",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Scroll y")
                      ]),
                      _: 1
                    }),
                    _hoisted_34,
                    createVNode(_component_examples_example, { file: "transitions/misc-scroll-y" })
                  ]),
                  createBaseVNode("section", _hoisted_35, [
                    createVNode(_component_app_heading, {
                      href: "#slide-x",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Slide x")
                      ]),
                      _: 1
                    }),
                    _hoisted_36,
                    createVNode(_component_examples_example, { file: "transitions/misc-slide-x" })
                  ]),
                  createBaseVNode("section", _hoisted_37, [
                    createVNode(_component_app_heading, {
                      href: "#slide-y",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Slide y")
                      ]),
                      _: 1
                    }),
                    _hoisted_38,
                    createVNode(_component_examples_example, { file: "transitions/misc-slide-y" })
                  ]),
                  createBaseVNode("section", _hoisted_39, [
                    createVNode(_component_app_heading, {
                      href: "#todo-list",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Todo list")
                      ]),
                      _: 1
                    }),
                    _hoisted_40,
                    createVNode(_component_examples_example, { file: "transitions/misc-todo" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
