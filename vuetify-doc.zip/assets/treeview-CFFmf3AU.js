import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "treeview" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("The "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-treeview"),
  /* @__PURE__ */ createTextVNode(" component is useful for displaying large amounts of nested data.")
], -1);
const _hoisted_3 = { id: "installation" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, "Labs components require a manual import and installation of the component.", -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-js" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "src/plugins/vuetify.js",
    class: "language-js"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" VTreeview "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify/labs/VTreeview'"),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "export"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "default"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "createVuetify"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "components"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n    VTreeview"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_6 = { id: "usage" };
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("p", null, "A basic example of the treeview component.", -1);
const _hoisted_8 = { id: "api" };
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("thead", null, [
  /* @__PURE__ */ createBaseVNode("tr", null, [
    /* @__PURE__ */ createBaseVNode("th", null, "Component"),
    /* @__PURE__ */ createBaseVNode("th", null, "Description")
  ])
], -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("td", null, "Primary Component", -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("td", null, "Sub-component used to display a single treeview node", -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("td", null, "Sub-component used to display a single treeview node’s children", -1);
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("td", null, "Sub-component used to display a single treeview node’s children", -1);
const _hoisted_14 = { id: "examples" };
const _hoisted_15 = { id: "props" };
const _hoisted_16 = { id: "activatable" };
const _hoisted_17 = /* @__PURE__ */ createBaseVNode("p", null, "Treeview nodes can be activated by clicking on them.", -1);
const _hoisted_18 = { id: "color" };
const _hoisted_19 = /* @__PURE__ */ createBaseVNode("p", null, "You can control the text and background color of the active treeview node.", -1);
const _hoisted_20 = { id: "dense-mode" };
const _hoisted_21 = /* @__PURE__ */ createBaseVNode("p", null, "Dense mode provides more compact layout with decreased heights of the items.", -1);
const _hoisted_22 = { id: "item-disabled" };
const _hoisted_23 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Setting "),
  /* @__PURE__ */ createBaseVNode("strong", null, "item-disabled"),
  /* @__PURE__ */ createTextVNode(" prop allows to control which node’s property disables the node when set to "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "true"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_24 = { id: "load-children" };
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("You can dynamically load child data by supplying a "),
  /* @__PURE__ */ createBaseVNode("span", { style: { "text-decoration": "underline" } }, "Promise"),
  /* @__PURE__ */ createTextVNode(" callback to the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "load-children"),
  /* @__PURE__ */ createTextVNode(" prop. This callback will be executed the first time a user tries to expand an item that has a children property that is an empty array.")
], -1);
const _hoisted_26 = { id: "open-all" };
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("p", null, "Treeview nodes can be pre-opened on page load.", -1);
const _hoisted_28 = { id: "selected-color" };
const _hoisted_29 = /* @__PURE__ */ createBaseVNode("p", null, "You can control the color of the selected node checkbox.", -1);
const _hoisted_30 = { id: "selection-type" };
const _hoisted_31 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Treeview now supports two different selection types. The default type is "),
  /* @__PURE__ */ createBaseVNode("strong", null, "‘leaf’"),
  /* @__PURE__ */ createTextVNode(", which will only include leaf nodes in the v-model array, but will render parent nodes as either partially or fully selected. The alternative mode is "),
  /* @__PURE__ */ createBaseVNode("strong", null, "‘independent’"),
  /* @__PURE__ */ createTextVNode(", which allows one to select parent nodes, but each node is independent of its parent and children.")
], -1);
const _hoisted_32 = { id: "slots" };
const _hoisted_33 = { id: "append-and-label" };
const _hoisted_34 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Using the the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "label"),
  /* @__PURE__ */ createTextVNode(", and an "),
  /* @__PURE__ */ createBaseVNode("strong", null, "append"),
  /* @__PURE__ */ createTextVNode(" slots we are able to create an intuitive file explorer.")
], -1);
const _hoisted_35 = { id: "misc" };
const _hoisted_36 = { id: "search-and-filter" };
const _hoisted_37 = /* @__PURE__ */ createBaseVNode("strong", null, "search", -1);
const _hoisted_38 = /* @__PURE__ */ createBaseVNode("strong", null, "filter", -1);
const _hoisted_39 = { id: "selectable-icons" };
const _hoisted_40 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Customize the "),
  /* @__PURE__ */ createBaseVNode("strong", null, "on"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("strong", null, "off"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("strong", null, "indeterminate"),
  /* @__PURE__ */ createTextVNode(" icons for your selectable tree. Combine with other advanced functionality like API loaded items.")
], -1);
const frontmatter = { "emphasized": true, "meta": { "nav": "Treeview", "title": "Treeview component", "description": "The treeview component is a user interface that is used to represent hierarchical data in a tree structure.", "keywords": "treeview, vuetify treeview component, vue treeview component" }, "related": ["/components/lists/", "/components/timelines/"], "features": { "label": "C: VTreeview", "report": true } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "treeview",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Treeview", "title": "Treeview component", "description": "The treeview component is a user interface that is used to represent hierarchical data in a tree structure.", "keywords": "treeview, vuetify treeview component, vue treeview component" } };
    useHead(head);
    __expose({ frontmatter: { "emphasized": true, "meta": { "nav": "Treeview", "title": "Treeview component", "description": "The treeview component is a user interface that is used to represent hierarchical data in a tree structure.", "keywords": "treeview, vuetify treeview component, vue treeview component" }, "related": ["/components/lists/", "/components/timelines/"], "features": { "label": "C: VTreeview", "report": true } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_app_link = resolveComponent("app-link");
      const _component_alert = resolveComponent("alert");
      const _component_app_markup = resolveComponent("app-markup");
      const _component_examples_example = resolveComponent("examples-example");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_table = resolveComponent("app-table");
      const _component_api_inline = resolveComponent("api-inline");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#treeview",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Treeview")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_alert, { type: "warning" }, {
                default: withCtx(() => [
                  createBaseVNode("p", null, [
                    createTextVNode("This feature requires "),
                    createVNode(_component_app_link, { href: "/getting-started/release-notes/?version=v3.5.9" }, {
                      default: withCtx(() => [
                        createTextVNode("v3.5.9")
                      ]),
                      _: 1
                    })
                  ])
                ]),
                _: 1
              }),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#installation",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Installation")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createVNode(_component_app_markup, {
                  resource: "src/plugins/vuetify.js",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_5
                  ]),
                  _: 1
                })
              ]),
              createBaseVNode("section", _hoisted_6, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_7,
                createVNode(_component_examples_example, { file: "v-treeview/usage" }),
                createVNode(_component_promoted_entry)
              ]),
              createBaseVNode("section", _hoisted_8, [
                createVNode(_component_app_heading, {
                  href: "#api",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("API")
                  ]),
                  _: 1
                }),
                createVNode(_component_app_table, null, {
                  default: withCtx(() => [
                    _hoisted_9,
                    createBaseVNode("tbody", null, [
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-treeview/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-treeview")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_10
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-treeview-item/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-treeview-item")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_11
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-treeview-children/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-treeview-children")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_12
                      ]),
                      createBaseVNode("tr", null, [
                        createBaseVNode("td", null, [
                          createVNode(_component_app_link, { href: "/api/v-treeview-group/" }, {
                            default: withCtx(() => [
                              createTextVNode("v-treeview-group")
                            ]),
                            _: 1
                          })
                        ]),
                        _hoisted_13
                      ])
                    ])
                  ]),
                  _: 1
                }),
                createVNode(_component_api_inline, { "hide-links": "" })
              ]),
              createBaseVNode("section", _hoisted_14, [
                createVNode(_component_app_heading, {
                  href: "#examples",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Examples")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_15, [
                  createVNode(_component_app_heading, {
                    href: "#props",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Props")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_16, [
                    createVNode(_component_app_heading, {
                      href: "#activatable",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Activatable")
                      ]),
                      _: 1
                    }),
                    _hoisted_17,
                    createVNode(_component_examples_example, { file: "v-treeview/prop-activatable" })
                  ]),
                  createBaseVNode("section", _hoisted_18, [
                    createVNode(_component_app_heading, {
                      href: "#color",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Color")
                      ]),
                      _: 1
                    }),
                    _hoisted_19,
                    createVNode(_component_examples_example, { file: "v-treeview/prop-color" })
                  ]),
                  createBaseVNode("section", _hoisted_20, [
                    createVNode(_component_app_heading, {
                      href: "#dense-mode",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Dense mode")
                      ]),
                      _: 1
                    }),
                    _hoisted_21,
                    createVNode(_component_examples_example, { file: "v-treeview/prop-dense" })
                  ]),
                  createBaseVNode("section", _hoisted_22, [
                    createVNode(_component_app_heading, {
                      href: "#item-disabled",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Item disabled")
                      ]),
                      _: 1
                    }),
                    _hoisted_23,
                    createVNode(_component_examples_example, { file: "v-treeview/prop-item-disabled" })
                  ]),
                  createBaseVNode("section", _hoisted_24, [
                    createVNode(_component_app_heading, {
                      href: "#load-children",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Load children")
                      ]),
                      _: 1
                    }),
                    _hoisted_25,
                    createVNode(_component_examples_example, { file: "v-treeview/prop-load-children" })
                  ]),
                  createBaseVNode("section", _hoisted_26, [
                    createVNode(_component_app_heading, {
                      href: "#open-all",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Open all")
                      ]),
                      _: 1
                    }),
                    _hoisted_27,
                    createVNode(_component_examples_example, { file: "v-treeview/prop-open-all" })
                  ]),
                  createBaseVNode("section", _hoisted_28, [
                    createVNode(_component_app_heading, {
                      href: "#selected-color",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Selected color")
                      ]),
                      _: 1
                    }),
                    _hoisted_29,
                    createVNode(_component_examples_example, { file: "v-treeview/prop-selected-color" })
                  ]),
                  createBaseVNode("section", _hoisted_30, [
                    createVNode(_component_app_heading, {
                      href: "#selection-type",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Selection type")
                      ]),
                      _: 1
                    }),
                    _hoisted_31,
                    createVNode(_component_examples_example, { file: "v-treeview/prop-selection-type" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_32, [
                  createVNode(_component_app_heading, {
                    href: "#slots",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Slots")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_33, [
                    createVNode(_component_app_heading, {
                      href: "#append-and-label",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Append and label")
                      ]),
                      _: 1
                    }),
                    _hoisted_34,
                    createVNode(_component_examples_example, { file: "v-treeview/slot-append-and-label" })
                  ])
                ]),
                createBaseVNode("section", _hoisted_35, [
                  createVNode(_component_app_heading, {
                    href: "#misc",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Misc")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("section", _hoisted_36, [
                    createVNode(_component_app_heading, {
                      href: "#search-and-filter",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Search and filter")
                      ]),
                      _: 1
                    }),
                    createBaseVNode("p", null, [
                      createTextVNode("Easily filter your treeview by using the "),
                      _hoisted_37,
                      createTextVNode(" prop. You can easily apply your custom filtering function if you need case-sensitive or fuzzy filtering by setting the "),
                      _hoisted_38,
                      createTextVNode(" prop. This works similar to the "),
                      createVNode(_component_app_link, { href: "/components/autocompletes" }, {
                        default: withCtx(() => [
                          createTextVNode("v-autocomplete")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" component.")
                    ]),
                    createVNode(_component_examples_example, { file: "v-treeview/misc-search-and-filter" })
                  ]),
                  createBaseVNode("section", _hoisted_39, [
                    createVNode(_component_app_heading, {
                      href: "#selectable-icons",
                      level: "4"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Selectable icons")
                      ]),
                      _: 1
                    }),
                    _hoisted_40,
                    createVNode(_component_examples_example, { file: "v-treeview/misc-selectable-icons" })
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
