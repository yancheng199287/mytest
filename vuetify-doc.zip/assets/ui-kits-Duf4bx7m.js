import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "vuetify-ui-kits" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "Easily create design prototypes with Figma components that match Vuetify’s.", -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, "The Vuetify UI Kit is a free component plugin for Figma that streamlines building your applications.", -1);
const _hoisted_5 = { id: "figma-plugin" };
const _hoisted_6 = { id: "digital-download" };
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createTextVNode("Unzip "),
  /* @__PURE__ */ createBaseVNode("strong", null, "vuetify3-ui-light-kit.fig"),
  /* @__PURE__ */ createTextVNode(" from "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "vuetify-figma-ui-kit.zip")
], -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("strong", null, "Import file", -1);
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "vuetify3-ui-light-kit.fig", -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("strong", null, "Assets", -1);
const frontmatter = { "meta": { "title": "UI Kits", "description": "Vuetify offers numerous pre-built component kits for both Figma and Adobe Xd. Kickstart your next application today.", "keywords": "vuetify ui kit, vuetify ui, ui kits, ui kit figma, ui kit adobe xd" }, "related": ["/getting-started/wireframes/", "/features/theme/", "/getting-started/installation/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ui-kits",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "UI Kits", "description": "Vuetify offers numerous pre-built component kits for both Figma and Adobe Xd. Kickstart your next application today.", "keywords": "vuetify ui kit, vuetify ui, ui kits, ui kit figma, ui kit adobe xd" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "title": "UI Kits", "description": "Vuetify offers numerous pre-built component kits for both Figma and Adobe Xd. Kickstart your next application today.", "keywords": "vuetify ui kit, vuetify ui, ui kits, ui kit figma, ui kit adobe xd" }, "related": ["/getting-started/wireframes/", "/features/theme/", "/getting-started/installation/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_app_divider = resolveComponent("app-divider");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_figure = resolveComponent("app-figure");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#vuetify-ui-kits",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Vuetify UI Kits")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_promoted_entry),
              createVNode(_component_app_divider),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createBaseVNode("section", _hoisted_5, [
                  createVNode(_component_app_heading, {
                    href: "#figma-plugin",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Figma Plugin")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("p", null, [
                    createTextVNode("The fastest and easiest way to use the Vuetify UI Kit is to install it as a "),
                    createVNode(_component_app_link, { href: "https://www.figma.com/community/file/1266515419060480209" }, {
                      default: withCtx(() => [
                        createTextVNode("plugin for Figma")
                      ]),
                      _: 1
                    }),
                    createTextVNode(".")
                  ])
                ]),
                createBaseVNode("section", _hoisted_6, [
                  createVNode(_component_app_heading, {
                    href: "#digital-download",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Digital Download")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("p", null, [
                    createTextVNode("If you need to manually install the plugin for whatever reason, you can download the latest version from the "),
                    createVNode(_component_app_link, { href: "https://store.vuetifyjs.com/" }, {
                      default: withCtx(() => [
                        createTextVNode("Vuetify Store")
                      ]),
                      _: 1
                    }),
                    createTextVNode(".")
                  ]),
                  createBaseVNode("ol", null, [
                    createBaseVNode("li", null, [
                      createVNode(_component_app_link, { href: "https://store.vuetifyjs.com/products/vuetify-ui-kit-figma" }, {
                        default: withCtx(() => [
                          createTextVNode("Download")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" for free from the our store")
                    ]),
                    _hoisted_7,
                    createBaseVNode("li", null, [
                      createTextVNode("Open Figma and create a new project: "),
                      createBaseVNode("div", null, [
                        createVNode(_component_app_figure, {
                          alt: "UI Kit New Project",
                          src: "https://cdn.vuetifyjs.com/docs/images/ui-kits/ui-kit-new-project.png"
                        })
                      ])
                    ]),
                    createBaseVNode("li", null, [
                      createTextVNode("Select "),
                      _hoisted_8,
                      createTextVNode(" and navigate to where you unzipped "),
                      _hoisted_9,
                      createTextVNode(": "),
                      createBaseVNode("div", null, [
                        createVNode(_component_app_figure, {
                          alt: "UI Kit Import File",
                          src: "https://cdn.vuetifyjs.com/docs/images/ui-kits/ui-kit-import-file.png"
                        })
                      ])
                    ]),
                    createBaseVNode("li", null, [
                      createTextVNode("Create a new design file: "),
                      createBaseVNode("div", null, [
                        createVNode(_component_app_figure, {
                          alt: "UI Kit New Design File",
                          src: "https://cdn.vuetifyjs.com/docs/images/ui-kits/ui-kit-new-design-file.png"
                        })
                      ])
                    ]),
                    createBaseVNode("li", null, [
                      createTextVNode("Access components within your projects by selecting "),
                      _hoisted_10,
                      createTextVNode(" and then searching for the desired component: "),
                      createBaseVNode("div", null, [
                        createVNode(_component_app_figure, {
                          alt: "UI Kit Search Assets",
                          src: "https://cdn.vuetifyjs.com/docs/images/ui-kits/ui-kit-search-assets.png"
                        })
                      ])
                    ])
                  ])
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
