import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "unit-testing" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "Add regression protection by adding unit tests to your Vuetify application", -1);
const _hoisted_3 = { id: "usage" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, "Unit tests are an important (and sometimes ignored) part of developing applications. They help us secure our processes and workflows, ensuring that the most critical parts of our projects are protected from accidental mistakes or oversights in our development.", -1);
const _hoisted_5 = { id: "using-vite" };
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("First, update your "),
  /* @__PURE__ */ createBaseVNode("strong", null, "vite.config.js"),
  /* @__PURE__ */ createTextVNode(" file to inline the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "vuetify"),
  /* @__PURE__ */ createTextVNode(" dependency:")
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-js" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "vite.config.js",
    class: "language-js"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" defineConfig "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vite'"),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "export"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "default"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "defineConfig"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "test"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "globals"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token boolean" }, "true"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "environment"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'jsdom'"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "server"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "deps"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n        "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "inline"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "["),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify'"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "]"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_8 = { id: "setup-vitest" };
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-bash" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-bash" }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "yarn"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "add"),
    /* @__PURE__ */ createTextVNode(" @vue/test-utils vitest resize-observer-polyfill "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token parameter variable" }, "--dev"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-bash" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-bash" }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "npm"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "install"),
    /* @__PURE__ */ createTextVNode(" @vue/test-utils vitest resize-observer-polyfill --save-dev\n")
  ])
], -1);
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-bash" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-bash" }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "pnpm"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "add"),
    /* @__PURE__ */ createTextVNode(" @vue/test-utils vitest resize-observer-polyfill --save-dev\n")
  ])
], -1);
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-bash" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-bash" }, [
    /* @__PURE__ */ createTextVNode("bun "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "add"),
    /* @__PURE__ */ createTextVNode(" @vue/test-utils vitest resize-observer-polyfill "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token parameter variable" }, "--dev"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("p", null, [
  /* @__PURE__ */ createTextVNode("Once installed, create a new folder at the root of your application named "),
  /* @__PURE__ */ createBaseVNode("strong", null, "tests/spec"),
  /* @__PURE__ */ createTextVNode(" and add a new file named "),
  /* @__PURE__ */ createBaseVNode("strong", null, "HelloWorld.spec.js"),
  /* @__PURE__ */ createTextVNode(". The following example shows how to setup a basic unit test for a Vuetify component:")
], -1);
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-js" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "tests/spec/HelloWorld.spec.js",
    class: "language-js"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" mount "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'@vue/test-utils'"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" expect"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode(" test "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vitest'"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(" createVuetify "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify'"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "*"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "as"),
    /* @__PURE__ */ createTextVNode(" components "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify/components'"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "*"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "as"),
    /* @__PURE__ */ createTextVNode(" directives "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'vuetify/directives'"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "import"),
    /* @__PURE__ */ createTextVNode(" HelloWorld "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "from"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'../../src/components/HelloWorld.vue'"),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "const"),
    /* @__PURE__ */ createTextVNode(" vuetify "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "="),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "createVuetify"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n  components"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  directives"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n\nglobal"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "."),
    /* @__PURE__ */ createTextVNode("ResizeObserver "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "="),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "require"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'resize-observer-polyfill'"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "test"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'displays message'"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "=>"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "const"),
    /* @__PURE__ */ createTextVNode(" wrapper "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "="),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "mount"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "template"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'<v-layout><hello-world></hello-world></v-layout>'"),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "props"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "global"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "components"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n        HelloWorld"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n      "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token literal-property property" }, "plugins"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, ":"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "["),
    /* @__PURE__ */ createTextVNode("vuetify"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "]"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token comment" }, "// Assert the rendered text of the component"),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "expect"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createTextVNode("wrapper"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "."),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "text"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "."),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "toContain"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token string" }, "'Components'"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const frontmatter = { "meta": { "title": "Unit testing", "description": "Learn how to create unit tests with vue-test-utils and Vuetify components in your Vue application.", "keywords": "unit testing vuetify, testing vuetify, vuetify spec tests" }, "related": ["/getting-started/frequently-asked-questions/", "/getting-started/contributing/", "/components/text-fields/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "unit-testing",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "Unit testing", "description": "Learn how to create unit tests with vue-test-utils and Vuetify components in your Vue application.", "keywords": "unit testing vuetify, testing vuetify, vuetify spec tests" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "title": "Unit testing", "description": "Learn how to create unit tests with vue-test-utils and Vuetify components in your Vue application.", "keywords": "unit testing vuetify, testing vuetify, vuetify spec tests" }, "related": ["/getting-started/frequently-asked-questions/", "/getting-started/contributing/", "/components/text-fields/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_vo_promotions_card_vuetify = resolveComponent("vo-promotions-card-vuetify");
      const _component_app_link = resolveComponent("app-link");
      const _component_app_markup = resolveComponent("app-markup");
      const _component_v_tab = resolveComponent("v-tab");
      const _component_v_window_item = resolveComponent("v-window-item");
      const _component_doc_tabs = resolveComponent("doc-tabs");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#unit-testing",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Unit Testing")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_vo_promotions_card_vuetify),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#usage",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Usage")
                  ]),
                  _: 1
                }),
                _hoisted_4,
                createBaseVNode("p", null, [
                  createTextVNode("Because of this, Vue has its own testing utility called "),
                  createVNode(_component_app_link, { href: "https://test-utils.vuejs.org/" }, {
                    default: withCtx(() => [
                      createTextVNode("vue-test-utils")
                    ]),
                    _: 1
                  }),
                  createTextVNode(". It provides useful features for interacting with Vue components and works with many popular test runners.")
                ])
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#using-vite",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Using Vite")
                  ]),
                  _: 1
                }),
                createBaseVNode("p", null, [
                  createVNode(_component_app_link, { href: "https://vitejs.dev/" }, {
                    default: withCtx(() => [
                      createTextVNode("Vite")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" is a fast, opinionated frontend build tool that serves your code via native ES Module imports during dev and bundles it with Rollup for production. It provides a great developer experience and is the recommended build tool for Vuetify applications.")
                ]),
                _hoisted_6,
                createVNode(_component_app_markup, {
                  resource: "vite.config.js",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_7
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_8, [
                  createVNode(_component_app_heading, {
                    href: "#setup-vitest",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Setup Vitest")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("p", null, [
                    createVNode(_component_app_link, { href: "https://vitest.dev/" }, {
                      default: withCtx(() => [
                        createTextVNode("Vitest")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" is a popular test runner that provides a great developer experience. It is fast, easy to use, and provides useful features like snapshot testing. To get started, install the following dependencies:")
                  ]),
                  createVNode(_component_doc_tabs, null, {
                    tabs: withCtx(() => [
                      createVNode(_component_v_tab, {
                        value: "yarn",
                        variant: "plain",
                        class: "text-none"
                      }, {
                        default: withCtx(() => [
                          createTextVNode("yarn")
                        ]),
                        _: 1
                      }),
                      createVNode(_component_v_tab, {
                        value: "npm",
                        variant: "plain",
                        class: "text-none"
                      }, {
                        default: withCtx(() => [
                          createTextVNode("npm")
                        ]),
                        _: 1
                      }),
                      createVNode(_component_v_tab, {
                        value: "pnpm",
                        variant: "plain",
                        class: "text-none"
                      }, {
                        default: withCtx(() => [
                          createTextVNode("pnpm")
                        ]),
                        _: 1
                      }),
                      createVNode(_component_v_tab, {
                        value: "bun",
                        variant: "plain",
                        class: "text-none"
                      }, {
                        default: withCtx(() => [
                          createTextVNode("bun")
                        ]),
                        _: 1
                      })
                    ]),
                    content: withCtx(() => [
                      createVNode(_component_v_window_item, { value: "yarn" }, {
                        default: withCtx(() => [
                          createVNode(_component_app_markup, {
                            resource: "",
                            class: "mb-4"
                          }, {
                            default: withCtx(() => [
                              _hoisted_9
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_v_window_item, { value: "npm" }, {
                        default: withCtx(() => [
                          createVNode(_component_app_markup, {
                            resource: "",
                            class: "mb-4"
                          }, {
                            default: withCtx(() => [
                              _hoisted_10
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_v_window_item, { value: "pnpm" }, {
                        default: withCtx(() => [
                          createVNode(_component_app_markup, {
                            resource: "",
                            class: "mb-4"
                          }, {
                            default: withCtx(() => [
                              _hoisted_11
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_v_window_item, { value: "bun" }, {
                        default: withCtx(() => [
                          createVNode(_component_app_markup, {
                            resource: "",
                            class: "mb-4"
                          }, {
                            default: withCtx(() => [
                              _hoisted_12
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }),
                  _hoisted_13,
                  createVNode(_component_app_markup, {
                    resource: "tests/spec/HelloWorld.spec.js",
                    class: "mb-4"
                  }, {
                    default: withCtx(() => [
                      _hoisted_14
                    ]),
                    _: 1
                  })
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
