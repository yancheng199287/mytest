import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "upgrade-guide" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "This page contains a detailed list of breaking changes and the steps required to upgrade your application to Vuetify 3.0", -1);
const _hoisted_3 = { class: "text-h6" };
const _hoisted_4 = { id: "setup" };
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("strong", null, "Vuetify"),
    /* @__PURE__ */ createTextVNode(" class removed, use "),
    /* @__PURE__ */ createBaseVNode("strong", null, "createVuetify"),
    /* @__PURE__ */ createTextVNode(" function")
  ])
], -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-js" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "2.x",
    class: "language-js"
  }, [
    /* @__PURE__ */ createTextVNode("Vue"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "."),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "use"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createTextVNode("Vuetify"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "const"),
    /* @__PURE__ */ createTextVNode(" vuetify "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "="),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "new"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token class-name" }, "Vuetify"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "..."),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "const"),
    /* @__PURE__ */ createTextVNode(" app "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "="),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "new"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token class-name" }, "Vue"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode("\n  vuetify"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ","),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "..."),
    /* @__PURE__ */ createTextVNode("\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-js" }, [
  /* @__PURE__ */ createBaseVNode("code", {
    resource: "3.0",
    class: "language-js"
  }, [
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "const"),
    /* @__PURE__ */ createTextVNode(" app "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "="),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "createApp"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n\n"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token keyword" }, "const"),
    /* @__PURE__ */ createTextVNode(" vuetify "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "="),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "createVuetify"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "{"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token operator" }, "..."),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "}"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n\napp"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "."),
    /* @__PURE__ */ createBaseVNode("span", { class: "token function" }, "use"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "("),
    /* @__PURE__ */ createTextVNode("vuetify"),
    /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ")"),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "import ... from 'vuetify'"),
  /* @__PURE__ */ createTextVNode(" is now a-la-carte, import "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "'vuetify/dist/vuetify.js'"),
  /* @__PURE__ */ createTextVNode(" instead to get the complete bundle (not recommended).")
], -1);
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "'vuetify/lib'"),
  /* @__PURE__ */ createTextVNode(" should no longer be used, change to "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "'vuetify'"),
  /* @__PURE__ */ createTextVNode(" / "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "'vuetify/components'"),
  /* @__PURE__ */ createTextVNode(" / "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "'vuetify/directives'"),
  /* @__PURE__ */ createTextVNode(" as appropriate.")
], -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createTextVNode("Only component styles are included, global styles must be imported separately from "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "'vuetify/styles'"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_11 = { id: "features" };
const _hoisted_12 = { id: "layout" };
const _hoisted_13 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createTextVNode("Global styles previously included as "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".v-application p"),
  /* @__PURE__ */ createTextVNode(" or "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".v-application ul"),
  /* @__PURE__ */ createTextVNode(" are no longer included. If you need margin for "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "p"),
  /* @__PURE__ */ createTextVNode(", or padding-left for "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "ul"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "ol"),
  /* @__PURE__ */ createTextVNode(", set it manually in your root component’s "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<style>"),
  /* @__PURE__ */ createTextVNode(" tag")
], -1);
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "stateless"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "clipped"),
  /* @__PURE__ */ createTextVNode(", "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "clipped-right"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "app"),
  /* @__PURE__ */ createTextVNode(" props have been removed from v-navigation-drawer, v-app-bar and v-system-bar. The position in the markup determines the appearance. Use the "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, 'order="number"'),
  /* @__PURE__ */ createTextVNode(" prop to influence it manually.")
], -1);
const _hoisted_15 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "$vuetify.breakpoint", -1);
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "$vuetify.display", -1);
const _hoisted_17 = { id: "theme" };
const _hoisted_18 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Multiple themes are now supported, so "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "light"),
    /* @__PURE__ */ createTextVNode(" / "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "dark"),
    /* @__PURE__ */ createTextVNode(" props have been removed from components. Use "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-theme-provider"),
    /* @__PURE__ */ createTextVNode(" to set the theme for a specific component tree. "),
    /* @__PURE__ */ createBaseVNode("ul", null, [
      /* @__PURE__ */ createBaseVNode("li", null, [
        /* @__PURE__ */ createTextVNode("Components that previously had a "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "dark"),
        /* @__PURE__ */ createTextVNode(" prop, such as v-app-bar, now accept "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, 'theme="dark"'),
        /* @__PURE__ */ createTextVNode(" prop")
      ])
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Theme colors set their foreground text color automatically, if you were using "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "light"),
    /* @__PURE__ */ createTextVNode(" / "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "dark"),
    /* @__PURE__ */ createTextVNode(" to get a different text color you probably don’t need it anymore.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("The variant naming scheme has changed slightly, it is now a single word instead of two. For example, "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "primary darken-1"),
    /* @__PURE__ */ createTextVNode(" is now "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "primary-darken-1"),
    /* @__PURE__ */ createTextVNode(". "),
    /* @__PURE__ */ createBaseVNode("ul", null, [
      /* @__PURE__ */ createBaseVNode("li", null, [
        /* @__PURE__ */ createTextVNode("To use variant namings as value for "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "color"),
        /* @__PURE__ */ createTextVNode(" props, the variant you intend to use needs to be enabled in the theme under "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "theme.variations.colors"),
        /* @__PURE__ */ createTextVNode(". e.g: "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "colors: ['primary']")
      ])
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Color classes have been renamed: "),
    /* @__PURE__ */ createBaseVNode("ul", null, [
      /* @__PURE__ */ createBaseVNode("li", null, [
        /* @__PURE__ */ createTextVNode("Backgrounds have a "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "bg-"),
        /* @__PURE__ */ createTextVNode(" prefix, for example "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".primary"),
        /* @__PURE__ */ createTextVNode(" is now "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".bg-primary"),
        /* @__PURE__ */ createTextVNode(".")
      ]),
      /* @__PURE__ */ createBaseVNode("li", null, [
        /* @__PURE__ */ createTextVNode("Text colors have a "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "text-"),
        /* @__PURE__ */ createTextVNode(" prefix, for example "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".primary--text"),
        /* @__PURE__ */ createTextVNode(" is now "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".text-primary"),
        /* @__PURE__ */ createTextVNode(".")
      ]),
      /* @__PURE__ */ createBaseVNode("li", null, [
        /* @__PURE__ */ createTextVNode("Variants are no longer a separate class, for example "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".primary--text.text--darken-1"),
        /* @__PURE__ */ createTextVNode(" is now "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".text-primary-darken-1"),
        /* @__PURE__ */ createTextVNode(".")
      ])
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("The theme system now uses CSS variables internally, so "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "customProperties"),
    /* @__PURE__ */ createTextVNode(" is no longer required. "),
    /* @__PURE__ */ createBaseVNode("ul", null, [
      /* @__PURE__ */ createBaseVNode("li", null, [
        /* @__PURE__ */ createTextVNode("If you were using "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "customProperties"),
        /* @__PURE__ */ createTextVNode(" in v2, the naming scheme has changed from "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "--v-primary-base"),
        /* @__PURE__ */ createTextVNode(" to "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "--v-theme-primary"),
        /* @__PURE__ */ createTextVNode(".")
      ]),
      /* @__PURE__ */ createBaseVNode("li", null, [
        /* @__PURE__ */ createTextVNode("Custom properties are now also an rgb list instead of hex so "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "rgb()"),
        /* @__PURE__ */ createTextVNode(" or "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "rgba()"),
        /* @__PURE__ */ createTextVNode(" must be used to access them, for example "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "color: rgb(var(--v-theme-primary))"),
        /* @__PURE__ */ createTextVNode(" instead of "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "color: var(--v-primary-base)"),
        /* @__PURE__ */ createTextVNode(".")
      ])
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Theme colors in the theme config are now nested inside a "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "colors"),
    /* @__PURE__ */ createTextVNode(" property, e.g. "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "const myTheme = { theme: { themes: { light: { colors: { primary: '#ccc' } } } } }")
  ])
], -1);
const _hoisted_19 = { id: "sass-variables" };
const _hoisted_20 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "$headings"),
    /* @__PURE__ */ createTextVNode(" was merged with "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "$typography"),
    /* @__PURE__ */ createTextVNode(": Access font-size of subtitle-2 with "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "map-get($typography, 'subtitle-2', 'size')")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("If you imported variables from "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "~vuetify/src/styles/settings/_variables"),
    /* @__PURE__ */ createTextVNode(" in v2, you have to replace it with "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "vuetify/settings")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Component variables that previously lived in e.g. "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "~/vuetify/src/components/VIcon/VIcon.sass"),
    /* @__PURE__ */ createTextVNode(" can now be imported from "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "vuetify/settings"),
    /* @__PURE__ */ createTextVNode(" directly too.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "$display-breakpoints"),
    /* @__PURE__ */ createTextVNode(" no longer includes "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "{breakpoint}-only"),
    /* @__PURE__ */ createTextVNode(" variables (e.g. xs-only), use "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "@media #{map-get(v.$display-breakpoints, 'xs')}"),
    /* @__PURE__ */ createTextVNode(" instead.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("The "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "$transition"),
    /* @__PURE__ */ createTextVNode(" map has been removed, replaced with individual "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "$standard-easing"),
    /* @__PURE__ */ createTextVNode(", "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "$decelerated-easing"),
    /* @__PURE__ */ createTextVNode(", "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "$accelerated-easing"),
    /* @__PURE__ */ createTextVNode(" variables.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "$container-padding-x"),
    /* @__PURE__ */ createTextVNode(" is now 16px instead of 12px as in v2. You can replace it with "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "$spacer * 3"),
    /* @__PURE__ */ createTextVNode(" to get to the previous look.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, "Too many component variables to list have been renamed or removed. There is no automated way to update these as the element structure has changed significantly, you will need to manually update these along with any custom styles.")
], -1);
const _hoisted_21 = { id: "styles-and-utility-classes" };
const _hoisted_22 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".hidden-{breakpoint}-only"),
    /* @__PURE__ */ createTextVNode(" has been renamed to "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".hidden-{breakpoint}")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".text-xs-{alignment}"),
    /* @__PURE__ */ createTextVNode(" has been renamed to "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".text-{alignment}"),
    /* @__PURE__ */ createTextVNode(" to reflect the fact that it applies to all breakpoints.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Typography classes have been renamed for consistency and are all prefixed with "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "text-"),
    /* @__PURE__ */ createTextVNode(", for example "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".display-4"),
    /* @__PURE__ */ createTextVNode(" is now "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".text-h1")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, "Transition easing classes have been removed.")
], -1);
const _hoisted_23 = { id: "components" };
const _hoisted_24 = { id: "general-changes" };
const _hoisted_25 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "value"),
    /* @__PURE__ */ createTextVNode(" prop has been replaced by "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "model-value"),
    /* @__PURE__ */ createTextVNode(" on components that support "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-model"),
    /* @__PURE__ */ createTextVNode(" usage. (Vue 3 requires this change) "),
    /* @__PURE__ */ createBaseVNode("ul", null, [
      /* @__PURE__ */ createBaseVNode("li", null, [
        /* @__PURE__ */ createTextVNode("Note that this does not apply to "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "value"),
        /* @__PURE__ */ createTextVNode(" used as a "),
        /* @__PURE__ */ createBaseVNode("em", null, "selection value"),
        /* @__PURE__ */ createTextVNode(", for example "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn"),
        /* @__PURE__ */ createTextVNode(" within "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn-toggle"),
        /* @__PURE__ */ createTextVNode(".")
      ])
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "@input"),
    /* @__PURE__ */ createTextVNode(" event has been replaced by "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "@update:model-value"),
    /* @__PURE__ */ createTextVNode(" on components that support "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-model"),
    /* @__PURE__ */ createTextVNode(" usage. (Vue 3 requires this change)")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "left"),
    /* @__PURE__ */ createTextVNode(" and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "right"),
    /* @__PURE__ */ createTextVNode(" have been replaced by "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "start"),
    /* @__PURE__ */ createTextVNode(" and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "end"),
    /* @__PURE__ */ createTextVNode(" respectively. This applies to utility classes too, for example "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".rounded-r"),
    /* @__PURE__ */ createTextVNode(" is now "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".rounded-e"),
    /* @__PURE__ */ createTextVNode(".")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Size props "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "small"),
    /* @__PURE__ */ createTextVNode(" / "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "medium"),
    /* @__PURE__ */ createTextVNode(" / "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "large"),
    /* @__PURE__ */ createTextVNode(" etc. have been combined into a single "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "size"),
    /* @__PURE__ */ createTextVNode(" prop.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "absolute"),
    /* @__PURE__ */ createTextVNode(" and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "fixed"),
    /* @__PURE__ */ createTextVNode(" props have been combined into a single "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "position"),
    /* @__PURE__ */ createTextVNode(" prop.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "top"),
    /* @__PURE__ */ createTextVNode(" / "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "bottom"),
    /* @__PURE__ */ createTextVNode(" / "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "left"),
    /* @__PURE__ */ createTextVNode(" / "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "right"),
    /* @__PURE__ */ createTextVNode(" props have been combined into a single "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "location"),
    /* @__PURE__ */ createTextVNode(" prop.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "background-color"),
    /* @__PURE__ */ createTextVNode(" prop has been renamed to "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "bg-color"),
    /* @__PURE__ */ createTextVNode(".")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "dense"),
    /* @__PURE__ */ createTextVNode(" prop on components such as v-select, v-btn-toggle, v-alert, v-text-field, v-list and v-list-item has been changed to "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "density"),
    /* @__PURE__ */ createTextVNode(" prop with the variants "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "default"),
    /* @__PURE__ */ createTextVNode(", "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "comfortable"),
    /* @__PURE__ */ createTextVNode(", "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "compact")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Activator slots work slightly different. Replace "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "#activator={ attrs, on }"),
    /* @__PURE__ */ createTextVNode(" with "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "#activator={ props }"),
    /* @__PURE__ */ createTextVNode(", then remove "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, 'v-on="on"'),
    /* @__PURE__ */ createTextVNode(" and replace "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, 'v-bind="attrs"'),
    /* @__PURE__ */ createTextVNode(" with "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, 'v-bind="props"')
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Some components have structural changes in their markup. Which means you may have to change how you query and assert them in tests. "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-switch"),
    /* @__PURE__ */ createTextVNode(" for example now uses an "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, '<input type="checkbox" />'),
    /* @__PURE__ */ createTextVNode(" under the hood, which is why the "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "aria-checked"),
    /* @__PURE__ */ createTextVNode(" and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, 'aria-role="switch"'),
    /* @__PURE__ */ createTextVNode(" attributes were removed.")
  ])
], -1);
const _hoisted_26 = { id: "input-components" };
const _hoisted_27 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Affix slots are consistent now: "),
    /* @__PURE__ */ createBaseVNode("ul", null, [
      /* @__PURE__ */ createBaseVNode("li", null, [
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "prepend"),
        /* @__PURE__ */ createTextVNode(" and "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "prepend-inner"),
        /* @__PURE__ */ createTextVNode(" are the same.")
      ]),
      /* @__PURE__ */ createBaseVNode("li", null, [
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "append"),
        /* @__PURE__ */ createTextVNode(" has been renamed to "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "append-inner"),
        /* @__PURE__ */ createTextVNode(".")
      ]),
      /* @__PURE__ */ createBaseVNode("li", null, [
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "append-outer"),
        /* @__PURE__ */ createTextVNode(" has been renamed to "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "append"),
        /* @__PURE__ */ createTextVNode(".")
      ])
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Variant props "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "filled"),
    /* @__PURE__ */ createTextVNode("/"),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "outlined"),
    /* @__PURE__ */ createTextVNode("/"),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "solo"),
    /* @__PURE__ */ createTextVNode(" have been combined into a single "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "variant"),
    /* @__PURE__ */ createTextVNode(" prop. "),
    /* @__PURE__ */ createBaseVNode("ul", null, [
      /* @__PURE__ */ createBaseVNode("li", null, [
        /* @__PURE__ */ createTextVNode("Allowed values are "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "'underlined'"),
        /* @__PURE__ */ createTextVNode(", "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "'outlined'"),
        /* @__PURE__ */ createTextVNode(", "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "'filled'"),
        /* @__PURE__ */ createTextVNode(", "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "'solo'"),
        /* @__PURE__ */ createTextVNode(", or "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "'plain'"),
        /* @__PURE__ */ createTextVNode(".")
      ])
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "success"),
    /* @__PURE__ */ createTextVNode(" and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "success-messages"),
    /* @__PURE__ */ createTextVNode(" props have been removed.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "validate-on-blur"),
    /* @__PURE__ */ createTextVNode(" prop has been renamed to "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, 'validate-on="blur"'),
    /* @__PURE__ */ createTextVNode(".")
  ])
], -1);
const _hoisted_28 = { id: "v-alert" };
const _hoisted_29 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "border"),
    /* @__PURE__ */ createTextVNode(" prop values "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "left"),
    /* @__PURE__ */ createTextVNode(" and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "right"),
    /* @__PURE__ */ createTextVNode(" have been renamed to "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "start"),
    /* @__PURE__ */ createTextVNode(" and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "end"),
    /* @__PURE__ */ createTextVNode(".")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "colored-border"),
    /* @__PURE__ */ createTextVNode(" prop has been renamed to "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "border-color"),
    /* @__PURE__ */ createTextVNode(".")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "dismissable"),
    /* @__PURE__ */ createTextVNode(" prop has been renamed to "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "closable"),
    /* @__PURE__ */ createTextVNode(".")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "outlined"),
    /* @__PURE__ */ createTextVNode(" and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "text"),
    /* @__PURE__ */ createTextVNode(" props have been combined into a single "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "variant"),
    /* @__PURE__ */ createTextVNode(" prop. "),
    /* @__PURE__ */ createBaseVNode("ul", null, [
      /* @__PURE__ */ createBaseVNode("li", null, [
        /* @__PURE__ */ createTextVNode("Allowed values are "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "'elevated'"),
        /* @__PURE__ */ createTextVNode(", "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "'flat'"),
        /* @__PURE__ */ createTextVNode(", "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "'tonal'"),
        /* @__PURE__ */ createTextVNode(", "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "'outlined'"),
        /* @__PURE__ */ createTextVNode(", "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "'text'"),
        /* @__PURE__ */ createTextVNode(", or "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "'plain'"),
        /* @__PURE__ */ createTextVNode(".")
      ])
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "text"),
    /* @__PURE__ */ createTextVNode(" prop has new purpose. It represents the text content of the alert, if default slot is not used.")
  ])
], -1);
const _hoisted_30 = { id: "v-badge" };
const _hoisted_31 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "overlap"),
    /* @__PURE__ */ createTextVNode(" has been removed and is now the default style, use "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "floating"),
    /* @__PURE__ */ createTextVNode(" to restore the v2 default.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Transition props "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "mode"),
    /* @__PURE__ */ createTextVNode(" and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "origin"),
    /* @__PURE__ */ createTextVNode(" have been removed.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "avatar"),
    /* @__PURE__ */ createTextVNode(" prop is no longer needed and has been removed.")
  ])
], -1);
const _hoisted_32 = { id: "v-banner" };
const _hoisted_33 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("The "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "actions"),
    /* @__PURE__ */ createTextVNode(" slot no longer provides a dismiss function.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "shaped"),
    /* @__PURE__ */ createTextVNode(" prop has been removed.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "icon-color"),
    /* @__PURE__ */ createTextVNode(" has been removed.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "single-line"),
    /* @__PURE__ */ createTextVNode(" has been replaced with "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, 'lines="one"'),
    /* @__PURE__ */ createTextVNode(".")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "color"),
    /* @__PURE__ */ createTextVNode(" now applies to the icon and action text. Use "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "bg-color"),
    /* @__PURE__ */ createTextVNode(" to change the background color.")
  ])
], -1);
const _hoisted_34 = { id: "v-btn-v-btn-toggle" };
const _hoisted_35 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "active-class"),
  /* @__PURE__ */ createTextVNode(" prop has been renamed to "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "selected-class")
], -1);
const _hoisted_36 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "fab"),
  /* @__PURE__ */ createTextVNode(" is no longer supported. If you just need a round button, use "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "icon"),
  /* @__PURE__ */ createTextVNode(" prop or apply a "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".rounded-circle"),
  /* @__PURE__ */ createTextVNode(" class.")
], -1);
const _hoisted_37 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "flat"),
  /* @__PURE__ */ createTextVNode(" / "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "outlined"),
  /* @__PURE__ */ createTextVNode(" / "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "text"),
  /* @__PURE__ */ createTextVNode(" / "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "plain"),
  /* @__PURE__ */ createTextVNode(" props have been combined into a single "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "variant"),
  /* @__PURE__ */ createTextVNode(" prop.")
], -1);
const _hoisted_38 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "depressed"),
  /* @__PURE__ */ createTextVNode(" has been renamed to "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, 'variant="flat"')
], -1);
const _hoisted_39 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "retain-focus-on-click", -1);
const _hoisted_40 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ":focus-visible", -1);
const _hoisted_41 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-btn-toggle"),
  /* @__PURE__ */ createTextVNode(" needs "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, 'mandatory="force"'),
  /* @__PURE__ */ createTextVNode(" prop to achieve the same behaviour as "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "mandatory"),
  /* @__PURE__ */ createTextVNode(" prop in v2.")
], -1);
const _hoisted_42 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "color", -1);
const _hoisted_43 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("The "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "$button-colored-disabled"),
    /* @__PURE__ */ createTextVNode(" sass variable can be set to false to use grey instead.")
  ])
], -1);
const _hoisted_44 = { id: "v-checkbox-v-radio-v-switch" };
const _hoisted_45 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "input-value"),
    /* @__PURE__ */ createTextVNode(" prop has been renamed to "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "model-value"),
    /* @__PURE__ */ createTextVNode(". (Vue 3 requires this change)")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "on-icon"),
    /* @__PURE__ */ createTextVNode(" and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "off-icon"),
    /* @__PURE__ */ createTextVNode(" props have been renamed to "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "true-icon"),
    /* @__PURE__ */ createTextVNode(" and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "false-icon"),
    /* @__PURE__ */ createTextVNode(".")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "on-value"),
    /* @__PURE__ */ createTextVNode(" and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "off-value"),
    /* @__PURE__ */ createTextVNode(" props have been renamed to "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "true-value"),
    /* @__PURE__ */ createTextVNode(" and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "false-value"),
    /* @__PURE__ */ createTextVNode(".")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-checkbox"),
    /* @__PURE__ */ createTextVNode("’s label slot should no longer contain a "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<label>"),
    /* @__PURE__ */ createTextVNode(" as it is already wrapped with one")
  ])
], -1);
const _hoisted_46 = { id: "v-date-picker" };
const _hoisted_47 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "Date", -1);
const _hoisted_48 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "locale", -1);
const _hoisted_49 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "locale-first-day-of-year", -1);
const _hoisted_50 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "first-day-of-week", -1);
const _hoisted_51 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "day-format", -1);
const _hoisted_52 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "weekday-format", -1);
const _hoisted_53 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "month-format", -1);
const _hoisted_54 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "year-format", -1);
const _hoisted_55 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "header-date-format", -1);
const _hoisted_56 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "title-date-format", -1);
const _hoisted_57 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "active-picker"),
  /* @__PURE__ */ createTextVNode(" has been renamed to "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "view-mode"),
  /* @__PURE__ */ createTextVNode(".")
], -1);
const _hoisted_58 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "picker-date"),
  /* @__PURE__ */ createTextVNode(" has been replaced with separate "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "month"),
  /* @__PURE__ */ createTextVNode(" and "),
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "year"),
  /* @__PURE__ */ createTextVNode(" props.")
], -1);
const _hoisted_59 = /* @__PURE__ */ createBaseVNode("li", null, [
  /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "range"),
  /* @__PURE__ */ createTextVNode(" is not currently implemented, will be added as a separate component in the future.")
], -1);
const _hoisted_60 = { id: "v-form" };
const _hoisted_61 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "validate()", -1);
const _hoisted_62 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "Promise<FormValidationResult>", -1);
const _hoisted_63 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "result.valid", -1);
const _hoisted_64 = { id: "v-list" };
const _hoisted_65 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "two-line"),
    /* @__PURE__ */ createTextVNode(" and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "three-line"),
    /* @__PURE__ */ createTextVNode(" props have been combined into a single "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "lines"),
    /* @__PURE__ */ createTextVNode(" prop with allowed values "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "'two'"),
    /* @__PURE__ */ createTextVNode(" or "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "'three'"),
    /* @__PURE__ */ createTextVNode(".")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-list-item-group"),
    /* @__PURE__ */ createTextVNode(" has been removed, just add "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "value"),
    /* @__PURE__ */ createTextVNode(" to list items to make them selectable and bind "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-model:selected"),
    /* @__PURE__ */ createTextVNode(" on v-list to get the selected value.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-list-item-icon"),
    /* @__PURE__ */ createTextVNode(" and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-list-item-avatar"),
    /* @__PURE__ */ createTextVNode(" have been removed, use "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-list-item"),
    /* @__PURE__ */ createTextVNode(" with "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "icon"),
    /* @__PURE__ */ createTextVNode(" or "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "avatar"),
    /* @__PURE__ */ createTextVNode(" props, or put an icon or avatar in the append or prepend slot.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-list-item-content"),
    /* @__PURE__ */ createTextVNode(" has been removed, lists use CSS grid for layout now instead.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-list-group"),
    /* @__PURE__ */ createTextVNode(" can now be nested arbitrarily deep, "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "sub-group"),
    /* @__PURE__ */ createTextVNode(" prop should be removed.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-list-item"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "input-value"),
    /* @__PURE__ */ createTextVNode(" prop has been replaced with "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "active"),
    /* @__PURE__ */ createTextVNode(".")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-list-item"),
    /* @__PURE__ */ createTextVNode(),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "inactive"),
    /* @__PURE__ */ createTextVNode(" prop has been replaced with "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ':active="false" :link="false"'),
    /* @__PURE__ */ createTextVNode(".")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-subheader"),
    /* @__PURE__ */ createTextVNode(" has been renamed to "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-list-subheader"),
    /* @__PURE__ */ createTextVNode(".")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-list-item"),
    /* @__PURE__ */ createTextVNode("’s "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "active"),
    /* @__PURE__ */ createTextVNode(" scoped slot prop has been renamed to "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "isActive")
  ])
], -1);
const _hoisted_66 = { id: "v-navigation-drawer" };
const _hoisted_67 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "stateless"),
    /* @__PURE__ */ createTextVNode(" prop has been removed, manually control state using "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "model-value"),
    /* @__PURE__ */ createTextVNode(" or "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-model"),
    /* @__PURE__ */ createTextVNode(" instead.")
  ])
], -1);
const _hoisted_68 = { id: "v-rating" };
const _hoisted_69 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "color"),
    /* @__PURE__ */ createTextVNode(" has been renamed to "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "active-color"),
    /* @__PURE__ */ createTextVNode(".")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "background-color"),
    /* @__PURE__ */ createTextVNode(" has been renamed to "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "color"),
    /* @__PURE__ */ createTextVNode(".")
  ])
], -1);
const _hoisted_70 = { id: "v-select-v-combobox-v-autocomplete" };
const _hoisted_71 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("v-model values not present in "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "items"),
    /* @__PURE__ */ createTextVNode(" will now be rendered instead of being ignored.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "cache-items"),
    /* @__PURE__ */ createTextVNode(" prop has been removed, caching should be handled externally.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "item-text"),
    /* @__PURE__ */ createTextVNode(" has been renamed to "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "item-title"),
    /* @__PURE__ */ createTextVNode(", and now looks up the "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "title"),
    /* @__PURE__ */ createTextVNode(" property on item objects by default. "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "value"),
    /* @__PURE__ */ createTextVNode(" is unchanged.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "item-disabled"),
    /* @__PURE__ */ createTextVNode(" has been removed, and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "disabled"),
    /* @__PURE__ */ createTextVNode(", "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "header"),
    /* @__PURE__ */ createTextVNode(", "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "divider"),
    /* @__PURE__ */ createTextVNode(", and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "avatar"),
    /* @__PURE__ */ createTextVNode(" properties are ignored on item objects. "),
    /* @__PURE__ */ createBaseVNode("ul", null, [
      /* @__PURE__ */ createBaseVNode("li", null, [
        /* @__PURE__ */ createTextVNode("Additional props to pass to "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-list-item"),
        /* @__PURE__ */ createTextVNode(" can be specified with the "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "item-props"),
        /* @__PURE__ */ createTextVNode(" prop. "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "item-props"),
        /* @__PURE__ */ createTextVNode(" can be a function that takes the item object and returns an object of props, or set to boolean "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "true"),
        /* @__PURE__ */ createTextVNode(" to spread item objects directly as props.")
      ])
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("The "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "item"),
    /* @__PURE__ */ createTextVNode(" object in slots is now an "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "ListItem"),
    /* @__PURE__ */ createTextVNode(" object, the original item object is available as "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "item.raw"),
    /* @__PURE__ */ createTextVNode(".")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("The "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "item"),
    /* @__PURE__ */ createTextVNode(" slot will no longer generate a "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-list-item"),
    /* @__PURE__ */ createTextVNode(" component automatically, instead a "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "props"),
    /* @__PURE__ */ createTextVNode(" object is supplied with the required event listeners and props:")
  ])
], -1);
const _hoisted_72 = /* @__PURE__ */ createBaseVNode("pre", { class: "language-html" }, [
  /* @__PURE__ */ createBaseVNode("code", { class: "language-html" }, [
    /* @__PURE__ */ createTextVNode("  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "#item"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("{ props }"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n    "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "<"),
        /* @__PURE__ */ createTextVNode("v-list-item")
      ]),
      /* @__PURE__ */ createTextVNode(),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-name" }, "v-bind"),
      /* @__PURE__ */ createBaseVNode("span", { class: "token attr-value" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation attr-equals" }, "="),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"'),
        /* @__PURE__ */ createTextVNode("props"),
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, '"')
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("v-list-item")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n  "),
    /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
      /* @__PURE__ */ createBaseVNode("span", { class: "token tag" }, [
        /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, "</"),
        /* @__PURE__ */ createTextVNode("template")
      ]),
      /* @__PURE__ */ createBaseVNode("span", { class: "token punctuation" }, ">")
    ]),
    /* @__PURE__ */ createTextVNode("\n")
  ])
], -1);
const _hoisted_73 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("The "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "chip"),
    /* @__PURE__ */ createTextVNode(" slot should be used instead of "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "selection"),
    /* @__PURE__ */ createTextVNode(" if the "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "chips"),
    /* @__PURE__ */ createTextVNode(" prop is set, this will provide some default values to the chips automatically.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Non-"),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "multiple"),
    /* @__PURE__ */ createTextVNode(" combobox will now update its model as you type (like a text field) instead of only on blur.")
  ])
], -1);
const _hoisted_74 = { id: "v-simple-table" };
const _hoisted_75 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-simple-table"),
    /* @__PURE__ */ createTextVNode(" has been renamed to "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-table")
  ])
], -1);
const _hoisted_76 = { id: "v-data-table" };
const _hoisted_77 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Headers objects: "),
    /* @__PURE__ */ createBaseVNode("ul", null, [
      /* @__PURE__ */ createBaseVNode("li", null, [
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "text"),
        /* @__PURE__ */ createTextVNode(" property has been renamed to "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "title"),
        /* @__PURE__ */ createTextVNode(".")
      ]),
      /* @__PURE__ */ createBaseVNode("li", null, [
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "data-table-select"),
        /* @__PURE__ */ createTextVNode(" and "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "data-table-expand"),
        /* @__PURE__ */ createTextVNode(" must be defined as "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "key"),
        /* @__PURE__ */ createTextVNode(" instead of "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "value"),
        /* @__PURE__ */ createTextVNode(".")
      ]),
      /* @__PURE__ */ createBaseVNode("li", null, [
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "class"),
        /* @__PURE__ */ createTextVNode(" has been replaced with "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "headerProps"),
        /* @__PURE__ */ createTextVNode(".")
      ]),
      /* @__PURE__ */ createBaseVNode("li", null, [
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "cellClass"),
        /* @__PURE__ */ createTextVNode(" has been replaced with "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "cellProps"),
        /* @__PURE__ */ createTextVNode(" and now accepts either a function or an object.")
      ]),
      /* @__PURE__ */ createBaseVNode("li", null, [
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "filter"),
        /* @__PURE__ */ createTextVNode(" function requires "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "search"),
        /* @__PURE__ */ createTextVNode(" to be used in order for it to be triggered.")
      ])
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Tables requires "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "search"),
    /* @__PURE__ */ createTextVNode(" prop to trigger filtering. "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "items"),
    /* @__PURE__ */ createTextVNode(" array can be pre-filter with a computed.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Server side tables using "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "server-items-length"),
    /* @__PURE__ */ createTextVNode(" must be replaced with "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "<v-data-table-server items-length />"),
    /* @__PURE__ */ createTextVNode(".")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Argument order for "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "@click:*"),
    /* @__PURE__ */ createTextVNode(" events is now consistently "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "(event, data)"),
    /* @__PURE__ */ createTextVNode(". "),
    /* @__PURE__ */ createBaseVNode("ul", null, [
      /* @__PURE__ */ createBaseVNode("li", null, [
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "onRowClick (item, data, event)"),
        /* @__PURE__ */ createTextVNode(" should be changed to "),
        /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "onRowClick (event, { item })"),
        /* @__PURE__ */ createTextVNode(".")
      ])
    ])
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "item-class"),
    /* @__PURE__ */ createTextVNode(" and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "item-style"),
    /* @__PURE__ */ createTextVNode(" have been combined into "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "row-props"),
    /* @__PURE__ */ createTextVNode(", and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "cell-props"),
    /* @__PURE__ */ createTextVNode(" has been added.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "sort-desc"),
    /* @__PURE__ */ createTextVNode(" and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "group-desc"),
    /* @__PURE__ */ createTextVNode(" have been combined into "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "sort-by"),
    /* @__PURE__ */ createTextVNode(" and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "group-by"),
    /* @__PURE__ */ createTextVNode(". These properties now take an array of "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "{ key: string, order: 'asc' | 'desc' }"),
    /* @__PURE__ */ createTextVNode(" objects instead of strings.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "current-items"),
    /* @__PURE__ */ createTextVNode(" event has been renamed to "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "update:current-items"),
    /* @__PURE__ */ createTextVNode(".")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "custom-sort"),
    /* @__PURE__ */ createTextVNode(" can now be done using the "),
    /* @__PURE__ */ createBaseVNode("strong", null, "sort"),
    /* @__PURE__ */ createTextVNode(" key in the headers object or by using the "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "custom-key-sort"),
    /* @__PURE__ */ createTextVNode(" prop.")
  ])
], -1);
const _hoisted_78 = { id: "v-slider-v-range-slider" };
const _hoisted_79 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "ticks"),
    /* @__PURE__ */ createTextVNode(" has been renamed to "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "show-ticks"),
    /* @__PURE__ */ createTextVNode(".")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "tick-labels"),
    /* @__PURE__ */ createTextVNode(" has been renamed to "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "ticks"),
    /* @__PURE__ */ createTextVNode(".")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "vertical"),
    /* @__PURE__ */ createTextVNode(" has been renamed to "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, 'direction="vertical"'),
    /* @__PURE__ */ createTextVNode(".")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "step"),
    /* @__PURE__ */ createTextVNode(" default value is now 0 instead of 1.")
  ])
], -1);
const _hoisted_80 = { id: "v-tabs" };
const _hoisted_81 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-tab-item"),
    /* @__PURE__ */ createTextVNode(" has been removed, use "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-window-item")
  ])
], -1);
const _hoisted_82 = { id: "v-img" };
const _hoisted_83 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "contain"),
    /* @__PURE__ */ createTextVNode(" has been removed and is now the default behaviour. Use "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "cover"),
    /* @__PURE__ */ createTextVNode(" to fill the entire container.")
  ])
], -1);
const _hoisted_84 = { id: "v-menu" };
const _hoisted_85 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "rounded"),
    /* @__PURE__ */ createTextVNode(" prop has been removed. Apply a rounded css class to the menu content element instead. e.g. "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, ".rounded-te")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "internal-activator"),
    /* @__PURE__ */ createTextVNode(" prop has been removed, use a ref or unique selector instead.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "absolute"),
    /* @__PURE__ */ createTextVNode(", "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "offset-y"),
    /* @__PURE__ */ createTextVNode(" and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "offset-x"),
    /* @__PURE__ */ createTextVNode(" props have been removed. Manual positioning is now done by passing a "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "[x, y]"),
    /* @__PURE__ */ createTextVNode(" array to the "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "target"),
    /* @__PURE__ */ createTextVNode(" prop.")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "nudge-*"),
    /* @__PURE__ */ createTextVNode(" props have been removed. There is no direct replacement but "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "offset"),
    /* @__PURE__ */ createTextVNode(" can be used to achieve similar results.")
  ])
], -1);
const _hoisted_86 = { id: "v-snackbar" };
const _hoisted_87 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "action"),
    /* @__PURE__ */ createTextVNode(" slot was renamed to "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "actions")
  ])
], -1);
const _hoisted_88 = { id: "v-expansion-panel" };
const _hoisted_89 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-expansion-panel-header"),
    /* @__PURE__ */ createTextVNode(" has been renamed to "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-expansion-panel-title"),
    /* @__PURE__ */ createTextVNode(".")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-expansion-panel-content"),
    /* @__PURE__ */ createTextVNode(" has been renamed to "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-expansion-panel-text"),
    /* @__PURE__ */ createTextVNode(".")
  ]),
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-expansion-panel"),
    /* @__PURE__ */ createTextVNode(" now has "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "text"),
    /* @__PURE__ */ createTextVNode(" and "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "title"),
    /* @__PURE__ */ createTextVNode(" props that can be used instead of subcomponents.")
  ])
], -1);
const _hoisted_90 = { id: "v-card" };
const _hoisted_91 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "v-card", -1);
const _hoisted_92 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "z-index", -1);
const _hoisted_93 = /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, '<v-card style="overflow: initial; z-index: initial">', -1);
const _hoisted_94 = { id: "v-sparkline" };
const _hoisted_95 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "value"),
    /* @__PURE__ */ createTextVNode(" is now "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "model-value")
  ])
], -1);
const _hoisted_96 = { id: "directives" };
const _hoisted_97 = { id: "v-intersect" };
const _hoisted_98 = /* @__PURE__ */ createBaseVNode("ul", null, [
  /* @__PURE__ */ createBaseVNode("li", null, [
    /* @__PURE__ */ createTextVNode("Handler argument order has changed from "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "entries, observer, isIntersecting"),
    /* @__PURE__ */ createTextVNode(" to "),
    /* @__PURE__ */ createBaseVNode("code", { class: "v-code" }, "isIntersecting, entries, observer")
  ])
], -1);
const frontmatter = { "emphasized": true, "meta": { "nav": "Upgrade guide", "title": "Upgrade guide", "description": "Detailed instruction on how to upgrade Vuetify to 3.0", "keywords": "migration, upgrade, releases, upgrading vuetify, alpha, v3" }, "related": ["/introduction/roadmap/", "/introduction/long-term-support/", "/introduction/enterprise-support/"] };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "upgrade-guide",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "nav": "Upgrade guide", "title": "Upgrade guide", "description": "Detailed instruction on how to upgrade Vuetify to 3.0", "keywords": "migration, upgrade, releases, upgrading vuetify, alpha, v3" } };
    useHead(head);
    __expose({ frontmatter: { "emphasized": true, "meta": { "nav": "Upgrade guide", "title": "Upgrade guide", "description": "Detailed instruction on how to upgrade Vuetify to 3.0", "keywords": "migration, upgrade, releases, upgrading vuetify, alpha, v3" }, "related": ["/introduction/roadmap/", "/introduction/long-term-support/", "/introduction/enterprise-support/"] }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_app_link = resolveComponent("app-link");
      const _component_alert = resolveComponent("alert");
      const _component_app_markup = resolveComponent("app-markup");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#upgrade-guide",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("Upgrade Guide")
                ]),
                _: 1
              }),
              _hoisted_2,
              createVNode(_component_page_features),
              createVNode(_component_alert, { type: "error" }, {
                default: withCtx(() => [
                  createBaseVNode("p", null, [
                    createBaseVNode("span", _hoisted_3, [
                      createTextVNode("Many of the changes on this page can be applied automatically using "),
                      createVNode(_component_app_link, { href: "https://www.npmjs.com/package/eslint-plugin-vuetify/" }, {
                        default: withCtx(() => [
                          createTextVNode("eslint-plugin-vuetify")
                        ]),
                        _: 1
                      })
                    ])
                  ])
                ]),
                _: 1
              }),
              createVNode(_component_alert, { type: "info" }, {
                default: withCtx(() => [
                  createBaseVNode("p", null, [
                    createTextVNode("Before upgrading, make sure to consult the Official "),
                    createVNode(_component_app_link, { href: "https://v3-migration.vuejs.org/" }, {
                      default: withCtx(() => [
                        createTextVNode("Vue 3 Migration Guide")
                      ]),
                      _: 1
                    })
                  ])
                ]),
                _: 1
              }),
              createVNode(_component_alert, { type: "warning" }, {
                default: withCtx(() => [
                  createBaseVNode("p", null, [
                    createTextVNode("Not all Vuetify 2 components are currently available in Vuetify 3; These components will be released as their development is completed via "),
                    createVNode(_component_app_link, { href: "https://vuetifyjs.com/en/labs/introduction/" }, {
                      default: withCtx(() => [
                        createTextVNode("Vuetify Labs")
                      ]),
                      _: 1
                    }),
                    createTextVNode(".")
                  ]),
                  createBaseVNode("ul", null, [
                    createBaseVNode("li", null, [
                      createVNode(_component_app_link, { href: "https://github.com/vuetifyjs/vuetify/issues/13469" }, {
                        default: withCtx(() => [
                          createTextVNode("calendar")
                        ]),
                        _: 1
                      })
                    ]),
                    createBaseVNode("li", null, [
                      createVNode(_component_app_link, { href: "https://github.com/vuetifyjs/vuetify/issues/13493" }, {
                        default: withCtx(() => [
                          createTextVNode("overflow-btn")
                        ]),
                        _: 1
                      })
                    ]),
                    createBaseVNode("li", null, [
                      createVNode(_component_app_link, { href: "https://github.com/vuetifyjs/vuetify/issues/13516" }, {
                        default: withCtx(() => [
                          createTextVNode("time-picker")
                        ]),
                        _: 1
                      })
                    ])
                  ])
                ]),
                _: 1
              }),
              createBaseVNode("section", _hoisted_4, [
                createVNode(_component_app_heading, {
                  href: "#setup",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Setup")
                  ]),
                  _: 1
                }),
                _hoisted_5,
                createVNode(_component_app_markup, {
                  resource: "2.x",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_6
                  ]),
                  _: 1
                }),
                createVNode(_component_app_markup, {
                  resource: "3.0",
                  class: "mb-4"
                }, {
                  default: withCtx(() => [
                    _hoisted_7
                  ]),
                  _: 1
                }),
                createBaseVNode("ul", null, [
                  _hoisted_8,
                  _hoisted_9,
                  _hoisted_10,
                  createBaseVNode("li", null, [
                    createVNode(_component_app_link, { href: "https://npmjs.com/package/vuetify-loader" }, {
                      default: withCtx(() => [
                        createTextVNode("vuetify-loader")
                      ]),
                      _: 1
                    }),
                    createTextVNode(" has been renamed to "),
                    createVNode(_component_app_link, { href: "https://npmjs.com/package/webpack-plugin-vuetify" }, {
                      default: withCtx(() => [
                        createTextVNode("webpack-plugin-vuetify")
                      ]),
                      _: 1
                    }),
                    createTextVNode(", and we also have a new plugin for vite "),
                    createVNode(_component_app_link, { href: "https://npmjs.com/package/vite-plugin-vuetify" }, {
                      default: withCtx(() => [
                        createTextVNode("vite-plugin-vuetify")
                      ]),
                      _: 1
                    }),
                    createTextVNode(".")
                  ])
                ])
              ]),
              createBaseVNode("section", _hoisted_11, [
                createVNode(_component_app_heading, {
                  href: "#features",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Features")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_12, [
                  createVNode(_component_app_heading, {
                    href: "#layout",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Layout")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("ul", null, [
                    _hoisted_13,
                    _hoisted_14,
                    createBaseVNode("li", null, [
                      _hoisted_15,
                      createTextVNode(" has been renamed to "),
                      _hoisted_16,
                      createTextVNode(" and extended with "),
                      createVNode(_component_app_link, { href: "/features/display-and-platform/" }, {
                        default: withCtx(() => [
                          createTextVNode("new properties")
                        ]),
                        _: 1
                      })
                    ])
                  ])
                ]),
                createBaseVNode("section", _hoisted_17, [
                  createVNode(_component_app_heading, {
                    href: "#theme",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Theme")
                    ]),
                    _: 1
                  }),
                  _hoisted_18
                ]),
                createBaseVNode("section", _hoisted_19, [
                  createVNode(_component_app_heading, {
                    href: "#sass-variables",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("SASS variables")
                    ]),
                    _: 1
                  }),
                  _hoisted_20
                ]),
                createBaseVNode("section", _hoisted_21, [
                  createVNode(_component_app_heading, {
                    href: "#styles-and-utility-classes",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Styles and utility classes")
                    ]),
                    _: 1
                  }),
                  _hoisted_22,
                  createVNode(_component_alert, { type: "info" }, {
                    default: withCtx(() => [
                      createBaseVNode("p", null, [
                        createTextVNode("An complete list of class changes will not be provided, please use "),
                        createVNode(_component_app_link, { href: "https://www.npmjs.com/package/eslint-plugin-vuetify/" }, {
                          default: withCtx(() => [
                            createTextVNode("eslint-plugin-vuetify")
                          ]),
                          _: 1
                        }),
                        createTextVNode(" to automatically fix them.")
                      ])
                    ]),
                    _: 1
                  })
                ])
              ]),
              createBaseVNode("section", _hoisted_23, [
                createVNode(_component_app_heading, {
                  href: "#components",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Components")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_24, [
                  createVNode(_component_app_heading, {
                    href: "#general-changes",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("General changes")
                    ]),
                    _: 1
                  }),
                  _hoisted_25
                ]),
                createBaseVNode("section", _hoisted_26, [
                  createVNode(_component_app_heading, {
                    href: "#input-components",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Input components")
                    ]),
                    _: 1
                  }),
                  _hoisted_27
                ]),
                createBaseVNode("section", _hoisted_28, [
                  createVNode(_component_app_heading, {
                    href: "#v-alert",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v-alert")
                    ]),
                    _: 1
                  }),
                  _hoisted_29
                ]),
                createBaseVNode("section", _hoisted_30, [
                  createVNode(_component_app_heading, {
                    href: "#v-badge",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v-badge")
                    ]),
                    _: 1
                  }),
                  _hoisted_31
                ]),
                createBaseVNode("section", _hoisted_32, [
                  createVNode(_component_app_heading, {
                    href: "#v-banner",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v-banner")
                    ]),
                    _: 1
                  }),
                  _hoisted_33
                ]),
                createBaseVNode("section", _hoisted_34, [
                  createVNode(_component_app_heading, {
                    href: "#v-btn-v-btn-toggle",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v-btn/v-btn-toggle")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("ul", null, [
                    _hoisted_35,
                    _hoisted_36,
                    _hoisted_37,
                    _hoisted_38,
                    createBaseVNode("li", null, [
                      _hoisted_39,
                      createTextVNode(" has been removed, buttons use "),
                      createVNode(_component_app_link, { href: "https://developer.mozilla.org/en-US/docs/Web/CSS/:focus-visible" }, {
                        default: withCtx(() => [
                          _hoisted_40
                        ]),
                        _: 1
                      }),
                      createTextVNode(" instead.")
                    ]),
                    _hoisted_41,
                    createBaseVNode("li", null, [
                      createTextVNode("Disabled buttons use a faded variant of the specified "),
                      _hoisted_42,
                      createTextVNode(" instead of grey ("),
                      createVNode(_component_app_link, { href: "https://github.com/vuetifyjs/vuetify/issues/15147" }, {
                        default: withCtx(() => [
                          createTextVNode("#15147")
                        ]),
                        _: 1
                      }),
                      createTextVNode(") "),
                      _hoisted_43
                    ])
                  ])
                ]),
                createBaseVNode("section", _hoisted_44, [
                  createVNode(_component_app_heading, {
                    href: "#v-checkbox-v-radio-v-switch",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v-checkbox/v-radio/v-switch")
                    ]),
                    _: 1
                  }),
                  _hoisted_45
                ]),
                createBaseVNode("section", _hoisted_46, [
                  createVNode(_component_app_heading, {
                    href: "#v-date-picker",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v-date-picker")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("ul", null, [
                    createBaseVNode("li", null, [
                      createTextVNode("Uses "),
                      _hoisted_47,
                      createTextVNode(" objects instead of strings. Some utility functions are included to help convert between the two, see "),
                      createVNode(_component_app_link, { href: "/features/dates/" }, {
                        default: withCtx(() => [
                          createTextVNode("dates")
                        ]),
                        _: 1
                      }),
                      createTextVNode(".")
                    ]),
                    createBaseVNode("li", null, [
                      _hoisted_48,
                      createTextVNode(", "),
                      _hoisted_49,
                      createTextVNode(", "),
                      _hoisted_50,
                      createTextVNode(", "),
                      _hoisted_51,
                      createTextVNode(", "),
                      _hoisted_52,
                      createTextVNode(", "),
                      _hoisted_53,
                      createTextVNode(", "),
                      _hoisted_54,
                      createTextVNode(", "),
                      _hoisted_55,
                      createTextVNode(", and "),
                      _hoisted_56,
                      createTextVNode(" are now part of the date adapter and use the globally configured "),
                      createVNode(_component_app_link, { href: "/features/internationalization/" }, {
                        default: withCtx(() => [
                          createTextVNode("locale")
                        ]),
                        _: 1
                      }),
                      createTextVNode(" instead of being passed as props.")
                    ]),
                    _hoisted_57,
                    _hoisted_58,
                    _hoisted_59
                  ])
                ]),
                createBaseVNode("section", _hoisted_60, [
                  createVNode(_component_app_heading, {
                    href: "#v-form",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v-form")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("ul", null, [
                    createBaseVNode("li", null, [
                      _hoisted_61,
                      createTextVNode(" now returns a "),
                      createVNode(_component_app_link, { href: "/api/v-form/#exposed-validate" }, {
                        default: withCtx(() => [
                          _hoisted_62
                        ]),
                        _: 1
                      }),
                      createTextVNode(" instead of a boolean. Await the promise then check "),
                      _hoisted_63,
                      createTextVNode(" to determine form state.")
                    ])
                  ])
                ]),
                createBaseVNode("section", _hoisted_64, [
                  createVNode(_component_app_heading, {
                    href: "#v-list",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v-list")
                    ]),
                    _: 1
                  }),
                  _hoisted_65
                ]),
                createBaseVNode("section", _hoisted_66, [
                  createVNode(_component_app_heading, {
                    href: "#v-navigation-drawer",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v-navigation-drawer")
                    ]),
                    _: 1
                  }),
                  _hoisted_67
                ]),
                createBaseVNode("section", _hoisted_68, [
                  createVNode(_component_app_heading, {
                    href: "#v-rating",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v-rating")
                    ]),
                    _: 1
                  }),
                  _hoisted_69
                ]),
                createBaseVNode("section", _hoisted_70, [
                  createVNode(_component_app_heading, {
                    href: "#v-select-v-combobox-v-autocomplete",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v-select/v-combobox/v-autocomplete")
                    ]),
                    _: 1
                  }),
                  _hoisted_71,
                  createVNode(_component_app_markup, {
                    resource: "",
                    class: "mb-4"
                  }, {
                    default: withCtx(() => [
                      _hoisted_72
                    ]),
                    _: 1
                  }),
                  _hoisted_73
                ]),
                createBaseVNode("section", _hoisted_74, [
                  createVNode(_component_app_heading, {
                    href: "#v-simple-table",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v-simple-table")
                    ]),
                    _: 1
                  }),
                  _hoisted_75
                ]),
                createBaseVNode("section", _hoisted_76, [
                  createVNode(_component_app_heading, {
                    href: "#v-data-table",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v-data-table")
                    ]),
                    _: 1
                  }),
                  _hoisted_77
                ]),
                createBaseVNode("section", _hoisted_78, [
                  createVNode(_component_app_heading, {
                    href: "#v-slider-v-range-slider",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v-slider/v-range-slider")
                    ]),
                    _: 1
                  }),
                  _hoisted_79
                ]),
                createBaseVNode("section", _hoisted_80, [
                  createVNode(_component_app_heading, {
                    href: "#v-tabs",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v-tabs")
                    ]),
                    _: 1
                  }),
                  _hoisted_81
                ]),
                createBaseVNode("section", _hoisted_82, [
                  createVNode(_component_app_heading, {
                    href: "#v-img",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v-img")
                    ]),
                    _: 1
                  }),
                  _hoisted_83
                ]),
                createBaseVNode("section", _hoisted_84, [
                  createVNode(_component_app_heading, {
                    href: "#v-menu",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v-menu")
                    ]),
                    _: 1
                  }),
                  _hoisted_85
                ]),
                createBaseVNode("section", _hoisted_86, [
                  createVNode(_component_app_heading, {
                    href: "#v-snackbar",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v-snackbar")
                    ]),
                    _: 1
                  }),
                  _hoisted_87
                ]),
                createBaseVNode("section", _hoisted_88, [
                  createVNode(_component_app_heading, {
                    href: "#v-expansion-panel",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v-expansion-panel")
                    ]),
                    _: 1
                  }),
                  _hoisted_89
                ]),
                createBaseVNode("section", _hoisted_90, [
                  createVNode(_component_app_heading, {
                    href: "#v-card",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v-card")
                    ]),
                    _: 1
                  }),
                  createBaseVNode("ul", null, [
                    createBaseVNode("li", null, [
                      _hoisted_91,
                      createTextVNode(" does not allow content to overflow or use higher "),
                      _hoisted_92,
                      createTextVNode(" values to display on top of elements outside it. To disable this behavior, use "),
                      _hoisted_93,
                      createTextVNode(" ("),
                      createVNode(_component_app_link, { href: "https://github.com/vuetifyjs/vuetify/issues/17593" }, {
                        default: withCtx(() => [
                          createTextVNode("#17593")
                        ]),
                        _: 1
                      }),
                      createTextVNode(", "),
                      createVNode(_component_app_link, { href: "https://github.com/vuetifyjs/vuetify/issues/17628" }, {
                        default: withCtx(() => [
                          createTextVNode("#17628")
                        ]),
                        _: 1
                      }),
                      createTextVNode(")")
                    ])
                  ])
                ]),
                createBaseVNode("section", _hoisted_94, [
                  createVNode(_component_app_heading, {
                    href: "#v-sparkline",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v-sparkline")
                    ]),
                    _: 1
                  }),
                  _hoisted_95
                ])
              ]),
              createBaseVNode("section", _hoisted_96, [
                createVNode(_component_app_heading, {
                  href: "#directives",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Directives")
                  ]),
                  _: 1
                }),
                createBaseVNode("section", _hoisted_97, [
                  createVNode(_component_app_heading, {
                    href: "#v-intersect",
                    level: "3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("v-intersect")
                    ]),
                    _: 1
                  }),
                  _hoisted_98
                ])
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
