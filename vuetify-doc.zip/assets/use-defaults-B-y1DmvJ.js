import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "usedefaults-api" };
const frontmatter = { "meta": { "title": "useDefaults API", "description": "API for the useDefaults component.", "keywords": "useDefaults, api, vuetify" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "use-defaults",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "useDefaults API", "description": "API for the useDefaults component.", "keywords": "useDefaults, api, vuetify" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "title": "useDefaults API", "description": "API for the useDefaults component.", "keywords": "useDefaults, api, vuetify" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_api_search = resolveComponent("api-search");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#usedefaults-api",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("useDefaults API")
                ]),
                _: 1
              }),
              createVNode(_component_page_features),
              createVNode(_component_promoted_entry),
              createVNode(_component_api_search)
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
