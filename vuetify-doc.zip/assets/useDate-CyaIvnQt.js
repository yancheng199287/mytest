const fileName = "useDate";
const displayName = "useDate";
const pathName = "use-date";
const exposed = {
  locale: {
    text: "any",
    type: "any",
    formatted: "any\n",
    optional: true,
    description: {
      en: "Returns the current locale being used."
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  date: {
    text: "(value?: any) => unknown",
    source: "vuetify/lib/index.d.mts#L5-L5",
    type: "function",
    parameters: [
      {
        name: "value",
        optional: false,
        text: "any",
        type: "any",
        formatted: "any"
      }
    ],
    returnType: {
      text: "unknown",
      type: "unknown",
      formatted: "unknown"
    },
    formatted: "(value: any) => unknown\n",
    optional: false,
    description: {
      en: "Takes any value and returns a date object."
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  format: {
    text: "(date: unknown, formatString: string) => string",
    source: "vuetify/lib/index.d.mts#L6-L6",
    type: "function",
    parameters: [
      {
        name: "date",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      },
      {
        name: "formatString",
        optional: false,
        text: "string",
        type: "string",
        formatted: "string"
      }
    ],
    returnType: {
      text: "string",
      type: "string",
      formatted: "string"
    },
    formatted: "(date: unknown, formatString: string) => string\n",
    optional: false,
    description: {
      en: "Takes a date object and returns it in a specified format."
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  toJsDate: {
    text: "(value: unknown) => Date",
    source: "vuetify/lib/index.d.mts#L7-L7",
    type: "function",
    parameters: [
      {
        name: "value",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      }
    ],
    returnType: {
      text: "Date",
      source: "typescript/lib/lib.es5.d.ts#L4-L4",
      type: "ref",
      ref: "Date",
      formatted: "Date"
    },
    formatted: "(value: unknown) => Date\n",
    optional: false,
    description: {
      en: "Converts date value to a JS Date Object."
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  parseISO: {
    text: "(date: string) => unknown",
    source: "vuetify/lib/index.d.mts#L8-L8",
    type: "function",
    parameters: [
      {
        name: "date",
        optional: false,
        text: "string",
        type: "string",
        formatted: "string"
      }
    ],
    returnType: {
      text: "unknown",
      type: "unknown",
      formatted: "unknown"
    },
    formatted: "(date: string) => unknown\n",
    optional: false,
    description: {
      en: "MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree/master/packages/api-generator/src/locale/en/vuetify/lib/index.d.mts#L8-L8.json))"
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  toISO: {
    text: "(date: unknown) => string",
    source: "vuetify/lib/index.d.mts#L9-L9",
    type: "function",
    parameters: [
      {
        name: "date",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      }
    ],
    returnType: {
      text: "string",
      type: "string",
      formatted: "string"
    },
    formatted: "(date: unknown) => string\n",
    optional: false,
    description: {
      en: "MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree/master/packages/api-generator/src/locale/en/vuetify/lib/index.d.mts#L9-L9.json))"
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  startOfDay: {
    text: "(date: unknown) => unknown",
    source: "vuetify/lib/index.d.mts#L10-L10",
    type: "function",
    parameters: [
      {
        name: "date",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      }
    ],
    returnType: {
      text: "unknown",
      type: "unknown",
      formatted: "unknown"
    },
    formatted: "(date: unknown) => unknown\n",
    optional: false,
    description: {
      en: "Returns the first second of the day."
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  endOfDay: {
    text: "(date: unknown) => unknown",
    source: "vuetify/lib/index.d.mts#L11-L11",
    type: "function",
    parameters: [
      {
        name: "date",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      }
    ],
    returnType: {
      text: "unknown",
      type: "unknown",
      formatted: "unknown"
    },
    formatted: "(date: unknown) => unknown\n",
    optional: false,
    description: {
      en: "Returns the last second of the day."
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  startOfWeek: {
    text: "(date: unknown) => unknown",
    source: "vuetify/lib/index.d.mts#L12-L12",
    type: "function",
    parameters: [
      {
        name: "date",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      }
    ],
    returnType: {
      text: "unknown",
      type: "unknown",
      formatted: "unknown"
    },
    formatted: "(date: unknown) => unknown\n",
    optional: false,
    description: {
      en: "Returns the first day of the week."
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  endOfWeek: {
    text: "(date: unknown) => unknown",
    source: "vuetify/lib/index.d.mts#L13-L13",
    type: "function",
    parameters: [
      {
        name: "date",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      }
    ],
    returnType: {
      text: "unknown",
      type: "unknown",
      formatted: "unknown"
    },
    formatted: "(date: unknown) => unknown\n",
    optional: false,
    description: {
      en: "Returns the last day of the week."
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  startOfMonth: {
    text: "(date: unknown) => unknown",
    source: "vuetify/lib/index.d.mts#L14-L14",
    type: "function",
    parameters: [
      {
        name: "date",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      }
    ],
    returnType: {
      text: "unknown",
      type: "unknown",
      formatted: "unknown"
    },
    formatted: "(date: unknown) => unknown\n",
    optional: false,
    description: {
      en: "Returns first day of the month."
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  endOfMonth: {
    text: "(date: unknown) => unknown",
    source: "vuetify/lib/index.d.mts#L15-L15",
    type: "function",
    parameters: [
      {
        name: "date",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      }
    ],
    returnType: {
      text: "unknown",
      type: "unknown",
      formatted: "unknown"
    },
    formatted: "(date: unknown) => unknown\n",
    optional: false,
    description: {
      en: "Returns the last day of the month."
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  startOfYear: {
    text: "(date: unknown) => unknown",
    source: "vuetify/lib/index.d.mts#L16-L16",
    type: "function",
    parameters: [
      {
        name: "date",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      }
    ],
    returnType: {
      text: "unknown",
      type: "unknown",
      formatted: "unknown"
    },
    formatted: "(date: unknown) => unknown\n",
    optional: false,
    description: {
      en: "Returns the first day of the year."
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  endOfYear: {
    text: "(date: unknown) => unknown",
    source: "vuetify/lib/index.d.mts#L17-L17",
    type: "function",
    parameters: [
      {
        name: "date",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      }
    ],
    returnType: {
      text: "unknown",
      type: "unknown",
      formatted: "unknown"
    },
    formatted: "(date: unknown) => unknown\n",
    optional: false,
    description: {
      en: "Returns the last day of the year."
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  isAfter: {
    text: "(date: unknown, comparing: unknown) => boolean",
    source: "vuetify/lib/index.d.mts#L18-L18",
    type: "function",
    parameters: [
      {
        name: "date",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      },
      {
        name: "comparing",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      }
    ],
    returnType: {
      text: "boolean",
      type: "boolean",
      formatted: "boolean"
    },
    formatted: "(date: unknown, comparing: unknown) => boolean\n",
    optional: false,
    description: {
      en: "Returns true if the first date is after the second date."
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  isAfterDay: {
    text: "(value: unknown, comparing: unknown) => boolean",
    source: "vuetify/lib/index.d.mts#L19-L19",
    type: "function",
    parameters: [
      {
        name: "value",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      },
      {
        name: "comparing",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      }
    ],
    returnType: {
      text: "boolean",
      type: "boolean",
      formatted: "boolean"
    },
    formatted: "(value: unknown, comparing: unknown) => boolean\n",
    optional: false,
    description: {
      en: "MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree/master/packages/api-generator/src/locale/en/vuetify/lib/index.d.mts#L19-L19.json))"
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  isSameDay: {
    text: "(date: unknown, comparing: unknown) => boolean",
    source: "vuetify/lib/index.d.mts#L20-L20",
    type: "function",
    parameters: [
      {
        name: "date",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      },
      {
        name: "comparing",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      }
    ],
    returnType: {
      text: "boolean",
      type: "boolean",
      formatted: "boolean"
    },
    formatted: "(date: unknown, comparing: unknown) => boolean\n",
    optional: false,
    description: {
      en: "Returns true if the two dates are the same day."
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  isSameMonth: {
    text: "(date: unknown, comparing: unknown) => boolean",
    source: "vuetify/lib/index.d.mts#L21-L21",
    type: "function",
    parameters: [
      {
        name: "date",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      },
      {
        name: "comparing",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      }
    ],
    returnType: {
      text: "boolean",
      type: "boolean",
      formatted: "boolean"
    },
    formatted: "(date: unknown, comparing: unknown) => boolean\n",
    optional: false,
    description: {
      en: "Returns true if the two dates are the same month."
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  isSameYear: {
    text: "(value: unknown, comparing: unknown) => boolean",
    source: "vuetify/lib/index.d.mts#L22-L22",
    type: "function",
    parameters: [
      {
        name: "value",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      },
      {
        name: "comparing",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      }
    ],
    returnType: {
      text: "boolean",
      type: "boolean",
      formatted: "boolean"
    },
    formatted: "(value: unknown, comparing: unknown) => boolean\n",
    optional: false,
    description: {
      en: "MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree/master/packages/api-generator/src/locale/en/vuetify/lib/index.d.mts#L22-L22.json))"
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  isBefore: {
    text: "(date: unknown, comparing: unknown) => boolean",
    source: "vuetify/lib/index.d.mts#L23-L23",
    type: "function",
    parameters: [
      {
        name: "date",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      },
      {
        name: "comparing",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      }
    ],
    returnType: {
      text: "boolean",
      type: "boolean",
      formatted: "boolean"
    },
    formatted: "(date: unknown, comparing: unknown) => boolean\n",
    optional: false,
    description: {
      en: "Returns true if the first date is before the second date."
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  isEqual: {
    text: "(date: unknown, comparing: unknown) => boolean",
    source: "vuetify/lib/index.d.mts#L24-L24",
    type: "function",
    parameters: [
      {
        name: "date",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      },
      {
        name: "comparing",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      }
    ],
    returnType: {
      text: "boolean",
      type: "boolean",
      formatted: "boolean"
    },
    formatted: "(date: unknown, comparing: unknown) => boolean\n",
    optional: false,
    description: {
      en: "Returns true if the two dates are equal."
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  isValid: {
    text: "(date: any) => boolean",
    source: "vuetify/lib/index.d.mts#L25-L25",
    type: "function",
    parameters: [
      {
        name: "date",
        optional: false,
        text: "any",
        type: "any",
        formatted: "any"
      }
    ],
    returnType: {
      text: "boolean",
      type: "boolean",
      formatted: "boolean"
    },
    formatted: "(date: any) => boolean\n",
    optional: false,
    description: {
      en: "Returns true if the date is valid."
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  isWithinRange: {
    text: "(date: unknown, range: [unknown, unknown]) => boolean",
    source: "vuetify/lib/index.d.mts#L26-L26",
    type: "function",
    parameters: [
      {
        name: "date",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      },
      {
        name: "range",
        optional: false,
        text: "[unknown, unknown]",
        type: "array",
        items: [
          {
            text: "unknown",
            type: "unknown",
            formatted: "unknown"
          },
          {
            text: "unknown",
            type: "unknown",
            formatted: "unknown"
          }
        ],
        length: 2,
        formatted: "[unknown, unknown]"
      }
    ],
    returnType: {
      text: "boolean",
      type: "boolean",
      formatted: "boolean"
    },
    formatted: "(date: unknown, range: [unknown, unknown]) => boolean\n",
    optional: false,
    description: {
      en: "Returns true if the first date is within the range of the second and third dates."
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  addMinutes: {
    text: "(date: unknown, amount: number) => unknown",
    source: "vuetify/lib/index.d.mts#L27-L27",
    type: "function",
    parameters: [
      {
        name: "date",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      },
      {
        name: "amount",
        optional: false,
        text: "number",
        type: "number",
        formatted: "number"
      }
    ],
    returnType: {
      text: "unknown",
      type: "unknown",
      formatted: "unknown"
    },
    formatted: "(date: unknown, amount: number) => unknown\n",
    optional: false,
    description: {
      en: "MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree/master/packages/api-generator/src/locale/en/vuetify/lib/index.d.mts#L27-L27.json))"
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  addHours: {
    text: "(date: unknown, amount: number) => unknown",
    source: "vuetify/lib/index.d.mts#L28-L28",
    type: "function",
    parameters: [
      {
        name: "date",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      },
      {
        name: "amount",
        optional: false,
        text: "number",
        type: "number",
        formatted: "number"
      }
    ],
    returnType: {
      text: "unknown",
      type: "unknown",
      formatted: "unknown"
    },
    formatted: "(date: unknown, amount: number) => unknown\n",
    optional: false,
    description: {
      en: "MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree/master/packages/api-generator/src/locale/en/vuetify/lib/index.d.mts#L28-L28.json))"
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  addDays: {
    text: "(date: unknown, amount: number) => unknown",
    source: "vuetify/lib/index.d.mts#L29-L29",
    type: "function",
    parameters: [
      {
        name: "date",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      },
      {
        name: "amount",
        optional: false,
        text: "number",
        type: "number",
        formatted: "number"
      }
    ],
    returnType: {
      text: "unknown",
      type: "unknown",
      formatted: "unknown"
    },
    formatted: "(date: unknown, amount: number) => unknown\n",
    optional: false,
    description: {
      en: "Adds the specified number of days to the date."
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  addWeeks: {
    text: "(date: unknown, amount: number) => unknown",
    source: "vuetify/lib/index.d.mts#L30-L30",
    type: "function",
    parameters: [
      {
        name: "date",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      },
      {
        name: "amount",
        optional: false,
        text: "number",
        type: "number",
        formatted: "number"
      }
    ],
    returnType: {
      text: "unknown",
      type: "unknown",
      formatted: "unknown"
    },
    formatted: "(date: unknown, amount: number) => unknown\n",
    optional: false,
    description: {
      en: "MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree/master/packages/api-generator/src/locale/en/vuetify/lib/index.d.mts#L30-L30.json))"
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  addMonths: {
    text: "(date: unknown, amount: number) => unknown",
    source: "vuetify/lib/index.d.mts#L31-L31",
    type: "function",
    parameters: [
      {
        name: "date",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      },
      {
        name: "amount",
        optional: false,
        text: "number",
        type: "number",
        formatted: "number"
      }
    ],
    returnType: {
      text: "unknown",
      type: "unknown",
      formatted: "unknown"
    },
    formatted: "(date: unknown, amount: number) => unknown\n",
    optional: false,
    description: {
      en: "Adds the specified number of months to the date."
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  getYear: {
    text: "(date: unknown) => number",
    source: "vuetify/lib/index.d.mts#L32-L32",
    type: "function",
    parameters: [
      {
        name: "date",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      }
    ],
    returnType: {
      text: "number",
      type: "number",
      formatted: "number"
    },
    formatted: "(date: unknown) => number\n",
    optional: false,
    description: {
      en: "Returns the year of the date."
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  setYear: {
    text: "(date: unknown, year: number) => unknown",
    source: "vuetify/lib/index.d.mts#L33-L33",
    type: "function",
    parameters: [
      {
        name: "date",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      },
      {
        name: "year",
        optional: false,
        text: "number",
        type: "number",
        formatted: "number"
      }
    ],
    returnType: {
      text: "unknown",
      type: "unknown",
      formatted: "unknown"
    },
    formatted: "(date: unknown, year: number) => unknown\n",
    optional: false,
    description: {
      en: "Sets the year of the date."
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  getDiff: {
    text: "(date: unknown, comparing: unknown, unit?: string | undefined) => number",
    source: "vuetify/lib/index.d.mts#L34-L34",
    type: "function",
    parameters: [
      {
        name: "date",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      },
      {
        name: "comparing",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      },
      {
        name: "unit",
        optional: false,
        text: "string | undefined",
        type: "anyOf",
        items: [
          {
            text: "undefined",
            type: "UNSUPPORTED",
            formatted: "undefined"
          },
          {
            text: "string",
            type: "string",
            formatted: "string"
          }
        ],
        formatted: "string"
      }
    ],
    returnType: {
      text: "number",
      type: "number",
      formatted: "number"
    },
    formatted: "(date: unknown, comparing: unknown, unit: string) => number\n",
    optional: false,
    description: {
      en: "Returns the difference between two dates in the specified unit."
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  getWeekArray: {
    text: "(date: unknown) => unknown[][]",
    source: "vuetify/lib/index.d.mts#L35-L35",
    type: "function",
    parameters: [
      {
        name: "date",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      }
    ],
    returnType: {
      text: "unknown[][]",
      source: "typescript/lib/lib.es5.d.ts#L4-L4",
      type: "array",
      items: [
        {
          text: "unknown[]",
          source: "typescript/lib/lib.es5.d.ts#L4-L4",
          type: "array",
          items: [
            {
              text: "unknown",
              type: "unknown",
              formatted: "unknown"
            }
          ],
          formatted: "unknown[]"
        }
      ],
      formatted: "unknown[][]"
    },
    formatted: "(date: unknown) => unknown[][]\n",
    optional: false,
    description: {
      en: "Returns an array of the days of the week of the date."
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  getWeekdays: {
    text: "() => string[]",
    source: "vuetify/lib/index.d.mts#L36-L36",
    type: "function",
    parameters: [],
    returnType: {
      text: "string[]",
      source: "typescript/lib/lib.es5.d.ts#L4-L4",
      type: "array",
      items: [
        {
          text: "string",
          type: "string",
          formatted: "string"
        }
      ],
      formatted: "string[]"
    },
    formatted: "() => string[]\n",
    optional: false,
    description: {
      en: "Returns an array of the names of the days of the week."
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  getMonth: {
    text: "(date: unknown) => number",
    source: "vuetify/lib/index.d.mts#L37-L37",
    type: "function",
    parameters: [
      {
        name: "date",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      }
    ],
    returnType: {
      text: "number",
      type: "number",
      formatted: "number"
    },
    formatted: "(date: unknown) => number\n",
    optional: false,
    description: {
      en: "Returns the month of the date."
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  setMonth: {
    text: "(date: unknown, month: number) => unknown",
    source: "vuetify/lib/index.d.mts#L38-L38",
    type: "function",
    parameters: [
      {
        name: "date",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      },
      {
        name: "month",
        optional: false,
        text: "number",
        type: "number",
        formatted: "number"
      }
    ],
    returnType: {
      text: "unknown",
      type: "unknown",
      formatted: "unknown"
    },
    formatted: "(date: unknown, month: number) => unknown\n",
    optional: false,
    description: {
      en: "MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree/master/packages/api-generator/src/locale/en/vuetify/lib/index.d.mts#L38-L38.json))"
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  getDate: {
    text: "(date: unknown) => number",
    source: "vuetify/lib/index.d.mts#L39-L39",
    type: "function",
    parameters: [
      {
        name: "date",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      }
    ],
    returnType: {
      text: "number",
      type: "number",
      formatted: "number"
    },
    formatted: "(date: unknown) => number\n",
    optional: false,
    description: {
      en: "MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree/master/packages/api-generator/src/locale/en/vuetify/lib/index.d.mts#L39-L39.json))"
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  setDate: {
    text: "(date: unknown, day: number) => unknown",
    source: "vuetify/lib/index.d.mts#L40-L40",
    type: "function",
    parameters: [
      {
        name: "date",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      },
      {
        name: "day",
        optional: false,
        text: "number",
        type: "number",
        formatted: "number"
      }
    ],
    returnType: {
      text: "unknown",
      type: "unknown",
      formatted: "unknown"
    },
    formatted: "(date: unknown, day: number) => unknown\n",
    optional: false,
    description: {
      en: "MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree/master/packages/api-generator/src/locale/en/vuetify/lib/index.d.mts#L40-L40.json))"
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  getNextMonth: {
    text: "(date: unknown) => unknown",
    source: "vuetify/lib/index.d.mts#L41-L41",
    type: "function",
    parameters: [
      {
        name: "date",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      }
    ],
    returnType: {
      text: "unknown",
      type: "unknown",
      formatted: "unknown"
    },
    formatted: "(date: unknown) => unknown\n",
    optional: false,
    description: {
      en: "MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree/master/packages/api-generator/src/locale/en/vuetify/lib/index.d.mts#L41-L41.json))"
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  getPreviousMonth: {
    text: "(date: unknown) => unknown",
    source: "vuetify/lib/index.d.mts#L42-L42",
    type: "function",
    parameters: [
      {
        name: "date",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      }
    ],
    returnType: {
      text: "unknown",
      type: "unknown",
      formatted: "unknown"
    },
    formatted: "(date: unknown) => unknown\n",
    optional: false,
    description: {
      en: "MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree/master/packages/api-generator/src/locale/en/vuetify/lib/index.d.mts#L42-L42.json))"
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  getHours: {
    text: "(date: unknown) => number",
    source: "vuetify/lib/index.d.mts#L43-L43",
    type: "function",
    parameters: [
      {
        name: "date",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      }
    ],
    returnType: {
      text: "number",
      type: "number",
      formatted: "number"
    },
    formatted: "(date: unknown) => number\n",
    optional: false,
    description: {
      en: "MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree/master/packages/api-generator/src/locale/en/vuetify/lib/index.d.mts#L43-L43.json))"
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  setHours: {
    text: "(date: unknown, hours: number) => unknown",
    source: "vuetify/lib/index.d.mts#L44-L44",
    type: "function",
    parameters: [
      {
        name: "date",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      },
      {
        name: "hours",
        optional: false,
        text: "number",
        type: "number",
        formatted: "number"
      }
    ],
    returnType: {
      text: "unknown",
      type: "unknown",
      formatted: "unknown"
    },
    formatted: "(date: unknown, hours: number) => unknown\n",
    optional: false,
    description: {
      en: "MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree/master/packages/api-generator/src/locale/en/vuetify/lib/index.d.mts#L44-L44.json))"
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  getMinutes: {
    text: "(date: unknown) => number",
    source: "vuetify/lib/index.d.mts#L45-L45",
    type: "function",
    parameters: [
      {
        name: "date",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      }
    ],
    returnType: {
      text: "number",
      type: "number",
      formatted: "number"
    },
    formatted: "(date: unknown) => number\n",
    optional: false,
    description: {
      en: "MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree/master/packages/api-generator/src/locale/en/vuetify/lib/index.d.mts#L45-L45.json))"
    },
    descriptionSource: {
      en: "useDate"
    }
  },
  setMinutes: {
    text: "(date: unknown, minutes: number) => unknown",
    source: "vuetify/lib/index.d.mts#L46-L46",
    type: "function",
    parameters: [
      {
        name: "date",
        optional: false,
        text: "unknown",
        type: "unknown",
        formatted: "unknown"
      },
      {
        name: "minutes",
        optional: false,
        text: "number",
        type: "number",
        formatted: "number"
      }
    ],
    returnType: {
      text: "unknown",
      type: "unknown",
      formatted: "unknown"
    },
    formatted: "(date: unknown, minutes: number) => unknown\n",
    optional: false,
    description: {
      en: "MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree/master/packages/api-generator/src/locale/en/vuetify/lib/index.d.mts#L46-L46.json))"
    },
    descriptionSource: {
      en: "useDate"
    }
  }
};
const useDate = {
  fileName,
  displayName,
  pathName,
  exposed
};
export {
  useDate as default,
  displayName,
  exposed,
  fileName,
  pathName
};
