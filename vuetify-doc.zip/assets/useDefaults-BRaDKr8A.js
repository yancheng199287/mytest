const fileName = "useDefaults";
const displayName = "useDefaults";
const pathName = "use-defaults";
const exposed = {};
const useDefaults = {
  fileName,
  displayName,
  pathName,
  exposed
};
export {
  useDefaults as default,
  displayName,
  exposed,
  fileName,
  pathName
};
