const fileName = "useDisplay";
const displayName = "useDisplay";
const pathName = "use-display";
const exposed = {
  displayClasses: {
    text: "ComputedRef<{ [x: string]: boolean; }>",
    source: "@vue/reactivity/dist/reactivity.d.ts#L134-L137",
    type: "ref",
    ref: "ComputedRef",
    formatted: "ComputedRef<{ [x: string]: boolean }>\n",
    optional: false,
    description: {
      en: "MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree/master/packages/api-generator/src/locale/en/@vue/reactivity/dist/reactivity.d.ts#L134-L137.json))"
    },
    descriptionSource: {
      en: "useDisplay"
    }
  },
  mobile: {
    text: "ComputedRef<boolean>",
    source: "@vue/reactivity/dist/reactivity.d.ts#L134-L137",
    type: "ref",
    ref: "ComputedRef",
    formatted: "ComputedRef<boolean>\n",
    optional: false,
    description: {
      en: "Returns **true** if the current browser breakpoint is considered to be a mobile breakpoint."
    },
    descriptionSource: {
      en: "useDisplay"
    }
  },
  xs: {
    text: "Ref<boolean>",
    source: "@vue/reactivity/dist/reactivity.d.ts#L413-L421",
    type: "ref",
    ref: "Ref",
    formatted: "Ref<boolean>\n",
    optional: false,
    description: {
      en: "Returns **true** if the current browser breakpoint is **xs**."
    },
    descriptionSource: {
      en: "useDisplay"
    }
  },
  sm: {
    text: "Ref<boolean>",
    source: "@vue/reactivity/dist/reactivity.d.ts#L413-L421",
    type: "ref",
    ref: "Ref",
    formatted: "Ref<boolean>\n",
    optional: false,
    description: {
      en: "Returns **true** if the current browser breakpoint is **sm**."
    },
    descriptionSource: {
      en: "useDisplay"
    }
  },
  md: {
    text: "Ref<boolean>",
    source: "@vue/reactivity/dist/reactivity.d.ts#L413-L421",
    type: "ref",
    ref: "Ref",
    formatted: "Ref<boolean>\n",
    optional: false,
    description: {
      en: "Returns **true** if the current browser breakpoint is **md**."
    },
    descriptionSource: {
      en: "useDisplay"
    }
  },
  lg: {
    text: "Ref<boolean>",
    source: "@vue/reactivity/dist/reactivity.d.ts#L413-L421",
    type: "ref",
    ref: "Ref",
    formatted: "Ref<boolean>\n",
    optional: false,
    description: {
      en: "Returns **true** if the current browser breakpoint is **lg**."
    },
    descriptionSource: {
      en: "useDisplay"
    }
  },
  xl: {
    text: "Ref<boolean>",
    source: "@vue/reactivity/dist/reactivity.d.ts#L413-L421",
    type: "ref",
    ref: "Ref",
    formatted: "Ref<boolean>\n",
    optional: false,
    description: {
      en: "Returns **true** if the current browser breakpoint is **xl**."
    },
    descriptionSource: {
      en: "useDisplay"
    }
  },
  xxl: {
    text: "Ref<boolean>",
    source: "@vue/reactivity/dist/reactivity.d.ts#L413-L421",
    type: "ref",
    ref: "Ref",
    formatted: "Ref<boolean>\n",
    optional: false,
    description: {
      en: "Returns **true** if the current browser breakpoint is **xxl**."
    },
    descriptionSource: {
      en: "useDisplay"
    }
  },
  smAndUp: {
    text: "Ref<boolean>",
    source: "@vue/reactivity/dist/reactivity.d.ts#L413-L421",
    type: "ref",
    ref: "Ref",
    formatted: "Ref<boolean>\n",
    optional: false,
    description: {
      en: "Returns **true** if the current browser breakpoint is **sm** or higher."
    },
    descriptionSource: {
      en: "useDisplay"
    }
  },
  mdAndUp: {
    text: "Ref<boolean>",
    source: "@vue/reactivity/dist/reactivity.d.ts#L413-L421",
    type: "ref",
    ref: "Ref",
    formatted: "Ref<boolean>\n",
    optional: false,
    description: {
      en: "Returns **true** if the current browser breakpoint is **md** or higher."
    },
    descriptionSource: {
      en: "useDisplay"
    }
  },
  lgAndUp: {
    text: "Ref<boolean>",
    source: "@vue/reactivity/dist/reactivity.d.ts#L413-L421",
    type: "ref",
    ref: "Ref",
    formatted: "Ref<boolean>\n",
    optional: false,
    description: {
      en: "Returns **true** if the current browser breakpoint is **lg** or higher."
    },
    descriptionSource: {
      en: "useDisplay"
    }
  },
  xlAndUp: {
    text: "Ref<boolean>",
    source: "@vue/reactivity/dist/reactivity.d.ts#L413-L421",
    type: "ref",
    ref: "Ref",
    formatted: "Ref<boolean>\n",
    optional: false,
    description: {
      en: "Returns **true** if the current browser breakpoint is **xl** or higher."
    },
    descriptionSource: {
      en: "useDisplay"
    }
  },
  smAndDown: {
    text: "Ref<boolean>",
    source: "@vue/reactivity/dist/reactivity.d.ts#L413-L421",
    type: "ref",
    ref: "Ref",
    formatted: "Ref<boolean>\n",
    optional: false,
    description: {
      en: "Returns **true** if the current browser breakpoint is **sm** or lower."
    },
    descriptionSource: {
      en: "useDisplay"
    }
  },
  mdAndDown: {
    text: "Ref<boolean>",
    source: "@vue/reactivity/dist/reactivity.d.ts#L413-L421",
    type: "ref",
    ref: "Ref",
    formatted: "Ref<boolean>\n",
    optional: false,
    description: {
      en: "Returns **true** if the current browser breakpoint is **md** or lower."
    },
    descriptionSource: {
      en: "useDisplay"
    }
  },
  lgAndDown: {
    text: "Ref<boolean>",
    source: "@vue/reactivity/dist/reactivity.d.ts#L413-L421",
    type: "ref",
    ref: "Ref",
    formatted: "Ref<boolean>\n",
    optional: false,
    description: {
      en: "Returns **true** if the current browser breakpoint is **lg** or lower."
    },
    descriptionSource: {
      en: "useDisplay"
    }
  },
  xlAndDown: {
    text: "Ref<boolean>",
    source: "@vue/reactivity/dist/reactivity.d.ts#L413-L421",
    type: "ref",
    ref: "Ref",
    formatted: "Ref<boolean>\n",
    optional: false,
    description: {
      en: "Returns **true** if the current browser breakpoint is **xl** or lower."
    },
    descriptionSource: {
      en: "useDisplay"
    }
  },
  name: {
    text: "Ref<DisplayBreakpoint>",
    source: "@vue/reactivity/dist/reactivity.d.ts#L413-L421",
    type: "ref",
    ref: "Ref",
    formatted: "Ref<DisplayBreakpoint>\n",
    optional: false,
    description: {
      en: "Name of the current breakpoint."
    },
    descriptionSource: {
      en: "useDisplay"
    }
  },
  height: {
    text: "Ref<number>",
    source: "@vue/reactivity/dist/reactivity.d.ts#L413-L421",
    type: "ref",
    ref: "Ref",
    formatted: "Ref<number>\n",
    optional: false,
    description: {
      en: "The inner height of the browser window."
    },
    descriptionSource: {
      en: "useDisplay"
    }
  },
  width: {
    text: "Ref<number>",
    source: "@vue/reactivity/dist/reactivity.d.ts#L413-L421",
    type: "ref",
    ref: "Ref",
    formatted: "Ref<number>\n",
    optional: false,
    description: {
      en: "The inner width of the browser window."
    },
    descriptionSource: {
      en: "useDisplay"
    }
  },
  mobileBreakpoint: {
    text: "Ref<number | DisplayBreakpoint>",
    source: "@vue/reactivity/dist/reactivity.d.ts#L413-L421",
    type: "ref",
    ref: "Ref",
    formatted: "Ref<number | DisplayBreakpoint>\n",
    optional: false,
    description: {
      en: "Controls which named breakpoint (**lg**, **md**, etc) or browser width (in px) is considered to be mobile."
    },
    descriptionSource: {
      en: "useDisplay"
    }
  },
  platform: {
    text: "Ref<DisplayPlatform>",
    source: "@vue/reactivity/dist/reactivity.d.ts#L413-L421",
    type: "ref",
    ref: "Ref",
    formatted: "Ref<DisplayPlatform>\n",
    optional: false,
    description: {
      en: "Name of the current platform."
    },
    descriptionSource: {
      en: "useDisplay"
    }
  },
  thresholds: {
    text: "Ref<DisplayThresholds>",
    source: "@vue/reactivity/dist/reactivity.d.ts#L413-L421",
    type: "ref",
    ref: "Ref",
    formatted: "Ref<DisplayThresholds>\n",
    optional: false,
    description: {
      en: "An object describing the width values of each breakpoint."
    },
    descriptionSource: {
      en: "useDisplay"
    }
  },
  ssr: {
    text: "boolean",
    type: "boolean",
    formatted: "boolean\n",
    optional: false,
    description: {
      en: "MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree/master/packages/api-generator/src/locale/en/useDisplay.json))"
    },
    descriptionSource: {
      en: "useDisplay"
    }
  },
  update: {
    text: "() => void",
    source: "vuetify/lib/index.d.mts#L244-L244",
    type: "function",
    parameters: [],
    returnType: {
      text: "void",
      type: "void",
      formatted: "void"
    },
    formatted: "() => void\n",
    optional: false,
    description: {
      en: "Function that updates the current width and height values."
    },
    descriptionSource: {
      en: "useDisplay"
    }
  }
};
const useDisplay = {
  fileName,
  displayName,
  pathName,
  exposed
};
export {
  useDisplay as default,
  displayName,
  exposed,
  fileName,
  pathName
};
