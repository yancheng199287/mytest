const fileName = "useGoTo";
const displayName = "useGoTo";
const pathName = "use-go-to";
const exposed = {};
const useGoTo = {
  fileName,
  displayName,
  pathName,
  exposed
};
export {
  useGoTo as default,
  displayName,
  exposed,
  fileName,
  pathName
};
