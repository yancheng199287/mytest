const fileName = "useLayout";
const displayName = "useLayout";
const pathName = "use-layout";
const exposed = {
  layoutIsReady: {
    text: "Promise<void>",
    source: "typescript/lib/lib.es5.d.ts#L4-L4",
    type: "ref",
    ref: "Promise",
    formatted: "Promise<void>\n",
    optional: false,
    description: {
      en: "MISSING DESCRIPTION ([edit in github](https://github.com/vuetifyjs/vuetify/tree/master/packages/api-generator/src/locale/en/typescript/lib/lib.es5.d.ts#L4-L4.json))"
    },
    descriptionSource: {
      en: "useLayout"
    }
  },
  getLayoutItem: {
    text: "(id: string) => LayoutItem | undefined",
    source: "vuetify/lib/index.d.mts#L341-L341",
    type: "function",
    parameters: [
      {
        name: "id",
        optional: false,
        text: "string",
        type: "string",
        formatted: "string"
      }
    ],
    returnType: {
      text: "LayoutItem | undefined",
      type: "anyOf",
      items: [
        {
          text: "undefined",
          type: "UNSUPPORTED",
          formatted: "undefined"
        },
        {
          text: "LayoutItem",
          source: "vuetify/lib/index.d.mts#L334-L338",
          type: "object",
          properties: {
            id: {
              text: "string",
              type: "string",
              formatted: "string",
              optional: false
            },
            size: {
              text: "number",
              type: "number",
              formatted: "number",
              optional: false
            },
            position: {
              text: "Position",
              source: "vuetify/lib/index.d.mts#L327-L327",
              type: "anyOf",
              items: [
                {
                  text: '"top"',
                  type: "string",
                  literal: '"top"',
                  formatted: '"top"'
                },
                {
                  text: '"left"',
                  type: "string",
                  literal: '"left"',
                  formatted: '"left"'
                },
                {
                  text: '"right"',
                  type: "string",
                  literal: '"right"',
                  formatted: '"right"'
                },
                {
                  text: '"bottom"',
                  type: "string",
                  literal: '"bottom"',
                  formatted: '"bottom"'
                }
              ],
              formatted: '"top" | "left" | "right" | "bottom"',
              optional: false
            },
            top: {
              text: "number",
              type: "number",
              formatted: "number",
              optional: false
            },
            bottom: {
              text: "number",
              type: "number",
              formatted: "number",
              optional: false
            },
            left: {
              text: "number",
              type: "number",
              formatted: "number",
              optional: false
            },
            right: {
              text: "number",
              type: "number",
              formatted: "number",
              optional: false
            }
          },
          formatted: '{ id: string; size: number; position: "top" | "left" | "right" | "bottom"; top: number; bottom: number; left: number; right: number }'
        }
      ],
      formatted: '{ id: string; size: number; position: "top" | "left" | "right" | "bottom"; top: number; bottom: number; left: number; right: number }'
    },
    formatted: "(id: string) => {\n  id: string\n  size: number\n  position: 'top' | 'left' | 'right' | 'bottom'\n  top: number\n  bottom: number\n  left: number\n  right: number\n}\n",
    optional: false,
    description: {
      en: "Function that returns position and size information about a specific layout item."
    },
    descriptionSource: {
      en: "useLayout"
    }
  },
  mainRect: {
    text: "Ref<Layer>",
    source: "@vue/reactivity/dist/reactivity.d.ts#L413-L421",
    type: "ref",
    ref: "Ref",
    formatted: "Ref<Layer>\n",
    optional: false,
    description: {
      en: "Position and size information for the v-main area."
    },
    descriptionSource: {
      en: "useLayout"
    }
  },
  mainStyles: {
    text: "Ref<CSSProperties>",
    source: "@vue/reactivity/dist/reactivity.d.ts#L413-L421",
    type: "ref",
    ref: "Ref",
    formatted: "Ref<CSSProperties>\n",
    optional: false,
    description: {
      en: "CSS styles applied to the v-main area."
    },
    descriptionSource: {
      en: "useLayout"
    }
  }
};
const useLayout = {
  fileName,
  displayName,
  pathName,
  exposed
};
export {
  useLayout as default,
  displayName,
  exposed,
  fileName,
  pathName
};
