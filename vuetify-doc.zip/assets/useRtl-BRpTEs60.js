const fileName = "useRtl";
const displayName = "useRtl";
const pathName = "use-rtl";
const exposed = {
  isRtl: {
    text: "Ref<boolean>",
    source: "@vue/reactivity/dist/reactivity.d.ts#L413-L421",
    type: "ref",
    ref: "Ref",
    formatted: "Ref<boolean>\n",
    optional: false,
    description: {
      en: "Indicates if RTL is currently active or not."
    },
    descriptionSource: {
      en: "useRtl"
    }
  },
  rtlClasses: {
    text: "Ref<string>",
    source: "@vue/reactivity/dist/reactivity.d.ts#L413-L421",
    type: "ref",
    ref: "Ref",
    formatted: "Ref<string>\n",
    optional: false,
    description: {
      en: "**FOR INTERNAL USE ONLY**"
    },
    descriptionSource: {
      en: "useRtl"
    }
  }
};
const useRtl = {
  fileName,
  displayName,
  pathName,
  exposed
};
export {
  useRtl as default,
  displayName,
  exposed,
  fileName,
  pathName
};
