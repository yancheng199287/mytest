const fileName = "useTheme";
const displayName = "useTheme";
const pathName = "use-theme";
const exposed = {
  isDisabled: {
    text: "boolean",
    type: "boolean",
    formatted: "boolean\n",
    optional: false,
    description: {
      en: "Indicates if theming is disabled."
    },
    descriptionSource: {
      en: "useTheme"
    }
  },
  themes: {
    text: "Ref<Record<string, InternalThemeDefinition>>",
    source: "@vue/reactivity/dist/reactivity.d.ts#L413-L421",
    type: "ref",
    ref: "Ref",
    formatted: "Ref<Record<string, InternalThemeDefinition>>\n",
    optional: false,
    description: {
      en: "Raw theme definitions."
    },
    descriptionSource: {
      en: "useTheme"
    }
  },
  name: {
    text: "Readonly<Ref<string>>",
    source: "typescript/lib/lib.es5.d.ts#L6-L6",
    type: "ref",
    ref: "Readonly",
    formatted: "Readonly<Ref<string>>\n",
    optional: false,
    description: {
      en: "Name of current theme."
    },
    descriptionSource: {
      en: "useTheme"
    }
  },
  current: {
    text: "Readonly<Ref<{ readonly dark: boolean; readonly colors: { readonly [x: string]: string; readonly background: string; readonly surface: string; readonly primary: string; readonly secondary: string; readonly success: string; readonly warning: string; readonly error: string; readonly info: string; readonly 'on-background': string; readonly 'on-surface': string; readonly 'on-primary': string; readonly 'on-secondary': string; readonly 'on-success': string; readonly 'on-warning': string; readonly 'on-error': string; readonly 'on-info': string; }; readonly variables: { readonly [x: string]: string | number; }; }>>",
    source: "typescript/lib/lib.es5.d.ts#L6-L6",
    type: "ref",
    ref: "Readonly",
    formatted: "Readonly<\n  Ref<{\n    readonly dark: boolean\n    readonly colors: {\n      readonly [x: string]: string\n      readonly background: string\n      readonly surface: string\n      readonly primary: string\n      readonly secondary: string\n      readonly success: string\n      readonly warning: string\n      readonly error: string\n      readonly info: string\n      readonly 'on-background': string\n      readonly 'on-surface': string\n      readonly 'on-primary': string\n      readonly 'on-secondary': string\n      readonly 'on-success': string\n      readonly 'on-warning': string\n      readonly 'on-error': string\n      readonly 'on-info': string\n    }\n    readonly variables: { readonly [x: string]: string | number }\n  }>\n>\n",
    optional: false,
    description: {
      en: "Current theme object."
    },
    descriptionSource: {
      en: "useTheme"
    }
  },
  computedThemes: {
    text: "Readonly<Ref<{ readonly [x: string]: { readonly dark: boolean; readonly colors: { readonly [x: string]: string; readonly background: string; readonly surface: string; readonly primary: string; readonly secondary: string; readonly success: string; readonly warning: string; readonly error: string; readonly info: string; readonly 'on-background': string; readonly 'on-surface': string; readonly 'on-primary': string; readonly 'on-secondary': string; readonly 'on-success': string; readonly 'on-warning': string; readonly 'on-error': string; readonly 'on-info': string; }; readonly variables: { readonly [x: string]: string | number; }; }; }>>",
    source: "typescript/lib/lib.es5.d.ts#L6-L6",
    type: "ref",
    ref: "Readonly",
    formatted: "Readonly<\n  Ref<{\n    readonly [x: string]: {\n      readonly dark: boolean\n      readonly colors: {\n        readonly [x: string]: string\n        readonly background: string\n        readonly surface: string\n        readonly primary: string\n        readonly secondary: string\n        readonly success: string\n        readonly warning: string\n        readonly error: string\n        readonly info: string\n        readonly 'on-background': string\n        readonly 'on-surface': string\n        readonly 'on-primary': string\n        readonly 'on-secondary': string\n        readonly 'on-success': string\n        readonly 'on-warning': string\n        readonly 'on-error': string\n        readonly 'on-info': string\n      }\n      readonly variables: { readonly [x: string]: string | number }\n    }\n  }>\n>\n",
    optional: false,
    description: {
      en: "Object containing all parsed theme definitions."
    },
    descriptionSource: {
      en: "useTheme"
    }
  },
  themeClasses: {
    text: "Readonly<Ref<string | undefined>>",
    source: "typescript/lib/lib.es5.d.ts#L6-L6",
    type: "ref",
    ref: "Readonly",
    formatted: "Readonly<Ref<string | undefined>>\n",
    optional: false,
    description: {
      en: "**FOR INTERNAL USE ONLY**"
    },
    descriptionSource: {
      en: "useTheme"
    }
  },
  styles: {
    text: "Readonly<Ref<string>>",
    source: "typescript/lib/lib.es5.d.ts#L6-L6",
    type: "ref",
    ref: "Readonly",
    formatted: "Readonly<Ref<string>>\n",
    optional: false,
    description: {
      en: "**FOR INTERNAL USE ONLY**"
    },
    descriptionSource: {
      en: "useTheme"
    }
  },
  global: {
    text: "{ readonly name: Ref<string>; readonly current: Readonly<Ref<{ readonly dark: boolean; readonly colors: { readonly [x: string]: string; readonly background: string; readonly surface: string; readonly primary: string; readonly secondary: string; readonly success: string; readonly warning: string; readonly error: string; readonly info: string; readonly 'on-background': string; readonly 'on-surface': string; readonly 'on-primary': string; readonly 'on-secondary': string; readonly 'on-success': string; readonly 'on-warning': string; readonly 'on-error': string; readonly 'on-info': string; }; readonly variables: { readonly [x: string]: string | number; }; }>>; }",
    source: "vuetify/lib/index.d.mts#L153-L156",
    type: "object",
    properties: {
      name: {
        text: "Ref<string>",
        source: "@vue/reactivity/dist/reactivity.d.ts#L413-L421",
        type: "ref",
        ref: "Ref",
        formatted: "Ref<string>",
        optional: false
      },
      current: {
        text: "Readonly<Ref<{ readonly dark: boolean; readonly colors: { readonly [x: string]: string; readonly background: string; readonly surface: string; readonly primary: string; readonly secondary: string; readonly success: string; readonly warning: string; readonly error: string; readonly info: string; readonly 'on-background': string; readonly 'on-surface': string; readonly 'on-primary': string; readonly 'on-secondary': string; readonly 'on-success': string; readonly 'on-warning': string; readonly 'on-error': string; readonly 'on-info': string; }; readonly variables: { readonly [x: string]: string | number; }; }>>",
        source: "typescript/lib/lib.es5.d.ts#L6-L6",
        type: "ref",
        ref: "Readonly",
        formatted: "Readonly<Ref<{ readonly dark: boolean; readonly colors: { readonly [x: string]: string; readonly background: string; readonly surface: string; readonly primary: string; readonly secondary: string; readonly success: string; readonly warning: string; readonly error: string; readonly info: string; readonly 'on-background': string; readonly 'on-surface': string; readonly 'on-primary': string; readonly 'on-secondary': string; readonly 'on-success': string; readonly 'on-warning': string; readonly 'on-error': string; readonly 'on-info': string; }; readonly variables: { readonly [x: string]: string | number; }; }>>",
        optional: false
      }
    },
    formatted: "{\n  name: Ref<string>\n  current: Readonly<\n    Ref<{\n      readonly dark: boolean\n      readonly colors: {\n        readonly [x: string]: string\n        readonly background: string\n        readonly surface: string\n        readonly primary: string\n        readonly secondary: string\n        readonly success: string\n        readonly warning: string\n        readonly error: string\n        readonly info: string\n        readonly 'on-background': string\n        readonly 'on-surface': string\n        readonly 'on-primary': string\n        readonly 'on-secondary': string\n        readonly 'on-success': string\n        readonly 'on-warning': string\n        readonly 'on-error': string\n        readonly 'on-info': string\n      }\n      readonly variables: { readonly [x: string]: string | number }\n    }>\n  >\n}\n",
    optional: false,
    description: {
      en: "Reference to the global theme instance."
    },
    descriptionSource: {
      en: "useTheme"
    }
  }
};
const useTheme = {
  fileName,
  displayName,
  pathName,
  exposed
};
export {
  useTheme as default,
  displayName,
  exposed,
  fileName,
  pathName
};
