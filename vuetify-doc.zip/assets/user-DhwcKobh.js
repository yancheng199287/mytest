import { _ as _sfc_main$3 } from "./Drawer-SbZ4cLFe.js";
import { a as useRoute, a3 as R, P as onMounted, a4 as onBeforeRouteUpdate, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, b as createVNode, l as createElementBlock, f as unref, a2 as resolveDynamicComponent, $ as _sfc_main$1, a0 as _sfc_main$2 } from "./index-DGybHjCP.js";
const _sfc_main = {
  __name: "user",
  setup(__props) {
    const route = useRoute();
    const auth = R();
    onMounted(async () => {
      await auth.verify();
    });
    onBeforeRouteUpdate(async () => {
      await auth.verify();
    });
    return (_ctx, _cache) => {
      const _component_VoNotificationsBanner = resolveComponent("VoNotificationsBanner");
      const _component_AppSettingsDrawer = _sfc_main$1;
      const _component_AppBarBar = _sfc_main$2;
      const _component_AppDrawerDrawer = _sfc_main$3;
      const _component_v_fade_transition = resolveComponent("v-fade-transition");
      const _component_router_view = resolveComponent("router-view");
      const _component_v_main = resolveComponent("v-main");
      const _component_v_app = resolveComponent("v-app");
      return openBlock(), createBlock(_component_v_app, null, {
        default: withCtx(() => [
          createVNode(_component_VoNotificationsBanner, { order: "-1" }),
          createVNode(_component_AppSettingsDrawer),
          createVNode(_component_AppBarBar),
          createVNode(_component_AppDrawerDrawer),
          createVNode(_component_v_main, null, {
            default: withCtx(() => [
              createVNode(_component_router_view, null, {
                default: withCtx(({ Component }) => [
                  createVNode(_component_v_fade_transition, { "hide-on-leave": "" }, {
                    default: withCtx(() => [
                      (openBlock(), createElementBlock("div", {
                        key: unref(route).name
                      }, [
                        (openBlock(), createBlock(resolveDynamicComponent(Component)))
                      ]))
                    ]),
                    _: 2
                  }, 1024)
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
export {
  _sfc_main as default
};
