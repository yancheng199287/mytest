import { y as _export_sfc, r as resolveComponent, o as openBlock, l as createElementBlock, b as createVNode, w as withCtx, h as createTextVNode, e as createBaseVNode, J as ref, q as createCommentVNode, c as createBlock, j as computed, ag as propsToString, f as unref, E as isRef, a9 as mergeProps } from "./index-DGybHjCP.js";
import { _ as _sfc_main$c } from "./UsageExample-M8CmNipa.js";
const _sfc_main$b = {};
const _hoisted_1$7 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_2$5 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_3$2 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
function _sfc_render$9(_ctx, _cache) {
  const _component_v_alert = resolveComponent("v-alert");
  return openBlock(), createElementBlock("div", null, [
    createVNode(_component_v_alert, {
      border: "start",
      "border-color": "deep-purple accent-4",
      elevation: "2"
    }, {
      default: withCtx(() => [
        createTextVNode(" Aliquam eu nunc. Fusce commodo aliquam arcu. In consectetuer turpis ut velit. Nulla facilisi.. Morbi mollis tellus ac sapien. Fusce vel dui. Praesent ut ligula non mi varius sagittis. Vivamus consectetuer hendrerit lacus. Suspendisse enim turpis, dictum sed, iaculis a, condimentum nec, nisi. ")
      ]),
      _: 1
    }),
    _hoisted_1$7,
    createVNode(_component_v_alert, {
      border: "top",
      "border-color": "success",
      elevation: "2"
    }, {
      default: withCtx(() => [
        createTextVNode(" Vestibulum ullamcorper mauris at ligula. Nam pretium turpis et arcu. Ut varius tincidunt libero. Curabitur ligula sapien, tincidunt non, euismod vitae, posuere imperdiet, leo. Morbi nec metus. ")
      ]),
      _: 1
    }),
    _hoisted_2$5,
    createVNode(_component_v_alert, {
      border: "bottom",
      "border-color": "warning",
      elevation: "2"
    }, {
      default: withCtx(() => [
        createTextVNode(" Sed in libero ut nibh placerat accumsan. Phasellus leo dolor, tempus non, auctor et, hendrerit quis, nisi. Phasellus leo dolor, tempus non, auctor et, hendrerit quis, nisi. Sed consequat, leo eget bibendum sodales, augue velit cursus nunc, quis gravida magna mi a libero. Donec elit libero, sodales nec, volutpat a, suscipit non, turpis. ")
      ]),
      _: 1
    }),
    _hoisted_3$2,
    createVNode(_component_v_alert, {
      border: "end",
      "border-color": "error",
      elevation: "2"
    }, {
      default: withCtx(() => [
        createTextVNode(" Fusce commodo aliquam arcu. Pellentesque posuere. Phasellus tempus. Donec posuere vulputate arcu. ")
      ]),
      _: 1
    })
  ]);
}
const __0 = /* @__PURE__ */ _export_sfc(_sfc_main$b, [["render", _sfc_render$9]]);
const __0_raw = '<template>\n  <div>\n    <v-alert\n      border="start"\n      border-color="deep-purple accent-4"\n      elevation="2"\n    >\n      Aliquam eu nunc. Fusce commodo aliquam arcu. In consectetuer turpis ut velit. Nulla facilisi..\n\n      Morbi mollis tellus ac sapien. Fusce vel dui. Praesent ut ligula non mi varius sagittis. Vivamus consectetuer hendrerit lacus. Suspendisse enim turpis, dictum sed, iaculis a, condimentum nec, nisi.\n    </v-alert>\n\n    <br>\n\n    <v-alert\n      border="top"\n      border-color="success"\n      elevation="2"\n    >\n      Vestibulum ullamcorper mauris at ligula. Nam pretium turpis et arcu. Ut varius tincidunt libero. Curabitur ligula sapien, tincidunt non, euismod vitae, posuere imperdiet, leo. Morbi nec metus.\n    </v-alert>\n\n    <br>\n\n    <v-alert\n      border="bottom"\n      border-color="warning"\n      elevation="2"\n    >\n      Sed in libero ut nibh placerat accumsan. Phasellus leo dolor, tempus non, auctor et, hendrerit quis, nisi. Phasellus leo dolor, tempus non, auctor et, hendrerit quis, nisi. Sed consequat, leo eget bibendum sodales, augue velit cursus nunc, quis gravida magna mi a libero. Donec elit libero, sodales nec, volutpat a, suscipit non, turpis.\n    </v-alert>\n\n    <br>\n\n    <v-alert\n      border="end"\n      border-color="error"\n      elevation="2"\n    >\n      Fusce commodo aliquam arcu. Pellentesque posuere. Phasellus tempus. Donec posuere vulputate arcu.\n    </v-alert>\n  </div>\n</template>\n';
const _sfc_main$a = {};
const _hoisted_1$6 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_2$4 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_3$1 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
function _sfc_render$8(_ctx, _cache) {
  const _component_v_alert = resolveComponent("v-alert");
  return openBlock(), createElementBlock("div", null, [
    createVNode(_component_v_alert, {
      border: "top",
      color: "primary"
    }, {
      default: withCtx(() => [
        createTextVNode(" I'm an alert with a top border and primary color ")
      ]),
      _: 1
    }),
    _hoisted_1$6,
    createVNode(_component_v_alert, {
      border: "end",
      color: "secondary"
    }, {
      default: withCtx(() => [
        createTextVNode(" I'm an alert with an end border and secondary color ")
      ]),
      _: 1
    }),
    _hoisted_2$4,
    createVNode(_component_v_alert, {
      border: "bottom",
      color: "success"
    }, {
      default: withCtx(() => [
        createTextVNode(" I'm an alert with a bottom border and success color ")
      ]),
      _: 1
    }),
    _hoisted_3$1,
    createVNode(_component_v_alert, {
      border: "start",
      color: "error"
    }, {
      default: withCtx(() => [
        createTextVNode(" I'm an alert with a start border and error color ")
      ]),
      _: 1
    })
  ]);
}
const __1 = /* @__PURE__ */ _export_sfc(_sfc_main$a, [["render", _sfc_render$8]]);
const __1_raw = `<template>
  <div>
    <v-alert
      border="top"
      color="primary"
    >
      I'm an alert with a top border and primary color
    </v-alert>

    <br>

    <v-alert
      border="end"
      color="secondary"
    >
      I'm an alert with an end border and secondary color
    </v-alert>

    <br>

    <v-alert
      border="bottom"
      color="success"
    >
      I'm an alert with a bottom border and success color
    </v-alert>

    <br>

    <v-alert
      border="start"
      color="error"
    >
      I'm an alert with a start border and error color
    </v-alert>
  </div>
</template>
`;
const _hoisted_1$5 = {
  key: 0,
  class: "text-center"
};
const _sfc_main$9 = {
  __name: "prop-closable",
  setup(__props) {
    const alert = ref(true);
    return (_ctx, _cache) => {
      const _component_v_alert = resolveComponent("v-alert");
      const _component_v_btn = resolveComponent("v-btn");
      return openBlock(), createElementBlock("div", null, [
        createVNode(_component_v_alert, {
          modelValue: alert.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => alert.value = $event),
          border: "start",
          "close-label": "Close Alert",
          color: "deep-purple-accent-4",
          title: "Closable Alert",
          variant: "tonal",
          closable: ""
        }, {
          default: withCtx(() => [
            createTextVNode(" Aenean imperdiet. Quisque id odio. Cras dapibus. Pellentesque ut neque. Cras dapibus. Vivamus consectetuer hendrerit lacus. Sed mollis, eros et ultrices tempus, mauris ipsum aliquam libero, non adipiscing dolor urna a orci. Sed mollis, eros et ultrices tempus, mauris ipsum aliquam libero, non adipiscing dolor urna a orci. Curabitur blandit mollis lacus. Curabitur ligula sapien, tincidunt non, euismod vitae, posuere imperdiet, leo. ")
          ]),
          _: 1
        }, 8, ["modelValue"]),
        !alert.value ? (openBlock(), createElementBlock("div", _hoisted_1$5, [
          createVNode(_component_v_btn, {
            onClick: _cache[1] || (_cache[1] = ($event) => alert.value = true)
          }, {
            default: withCtx(() => [
              createTextVNode(" Reset ")
            ]),
            _: 1
          })
        ])) : createCommentVNode("", true)
      ]);
    };
  }
};
const __2 = _sfc_main$9;
const __2_raw = `<template>
  <div>
    <v-alert
      v-model="alert"
      border="start"
      close-label="Close Alert"
      color="deep-purple-accent-4"
      title="Closable Alert"
      variant="tonal"
      closable
    >
      Aenean imperdiet. Quisque id odio. Cras dapibus. Pellentesque ut neque. Cras dapibus.

      Vivamus consectetuer hendrerit lacus. Sed mollis, eros et ultrices tempus, mauris ipsum aliquam libero, non adipiscing dolor urna a orci. Sed mollis, eros et ultrices tempus, mauris ipsum aliquam libero, non adipiscing dolor urna a orci. Curabitur blandit mollis lacus. Curabitur ligula sapien, tincidunt non, euismod vitae, posuere imperdiet, leo.
    </v-alert>

    <div
      v-if="!alert"
      class="text-center"
    >
      <v-btn @click="alert = true">
        Reset
      </v-btn>
    </div>
  </div>
</template>

<script setup>
  import { ref } from 'vue'

  const alert = ref(true)
<\/script>

<script>
  export default {
    data: () => ({
      alert: true,
    }),
  }
<\/script>
`;
const _sfc_main$8 = {};
function _sfc_render$7(_ctx, _cache) {
  const _component_v_alert = resolveComponent("v-alert");
  return openBlock(), createBlock(_component_v_alert, {
    text: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!",
    title: "Alert title"
  });
}
const __3 = /* @__PURE__ */ _export_sfc(_sfc_main$8, [["render", _sfc_render$7]]);
const __3_raw = '<template>\n  <v-alert\n    text="Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!"\n    title="Alert title"\n  ></v-alert>\n</template>\n';
const _sfc_main$7 = {};
function _sfc_render$6(_ctx, _cache) {
  const _component_v_alert = resolveComponent("v-alert");
  return openBlock(), createBlock(_component_v_alert, {
    density: "compact",
    text: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!",
    title: "Alert title",
    type: "warning"
  });
}
const __4 = /* @__PURE__ */ _export_sfc(_sfc_main$7, [["render", _sfc_render$6]]);
const __4_raw = '<template>\n  <v-alert\n    density="compact"\n    text="Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!"\n    title="Alert title"\n    type="warning"\n  ></v-alert>\n</template>\n';
const _sfc_main$6 = {};
const _hoisted_1$4 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_2$3 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
function _sfc_render$5(_ctx, _cache) {
  const _component_v_alert = resolveComponent("v-alert");
  return openBlock(), createElementBlock("div", null, [
    createVNode(_component_v_alert, {
      color: "#2A3B4D",
      density: "compact",
      icon: "mdi-firework",
      theme: "dark"
    }, {
      default: withCtx(() => [
        createTextVNode(" Suspendisse enim turpis, dictum sed, iaculis a, condimentum nec, nisi. Vivamus quis mi. Quisque ut nisi. Maecenas malesuada. ")
      ]),
      _: 1
    }),
    _hoisted_1$4,
    createVNode(_component_v_alert, {
      color: "#C51162",
      icon: "mdi-material-design",
      theme: "dark",
      border: ""
    }, {
      default: withCtx(() => [
        createTextVNode(" Phasellus blandit leo ut odio. Morbi mattis ullamcorper velit. Donec orci lectus, aliquam ut, faucibus non, euismod id, nulla. In ut quam vitae odio lacinia tincidunt. ")
      ]),
      _: 1
    }),
    _hoisted_2$3,
    createVNode(_component_v_alert, {
      color: "primary",
      icon: "$vuetify",
      theme: "dark",
      prominent: ""
    }, {
      default: withCtx(() => [
        createTextVNode(" Praesent congue erat at massa. Nullam vel sem. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Proin viverra, ligula sit amet ultrices semper, ligula arcu tristique sapien, a accumsan nisi mauris ac eros. Curabitur at lacus ac velit ornare lobortis. ")
      ]),
      _: 1
    })
  ]);
}
const __5 = /* @__PURE__ */ _export_sfc(_sfc_main$6, [["render", _sfc_render$5]]);
const __5_raw = '<template>\n  <div>\n    <v-alert\n      color="#2A3B4D"\n      density="compact"\n      icon="mdi-firework"\n      theme="dark"\n    >\n      Suspendisse enim turpis, dictum sed, iaculis a, condimentum nec, nisi. Vivamus quis mi. Quisque ut nisi. Maecenas malesuada.\n    </v-alert>\n\n    <br>\n\n    <v-alert\n      color="#C51162"\n      icon="mdi-material-design"\n      theme="dark"\n      border\n    >\n      Phasellus blandit leo ut odio. Morbi mattis ullamcorper velit. Donec orci lectus, aliquam ut, faucibus non, euismod id, nulla. In ut quam vitae odio lacinia tincidunt.\n    </v-alert>\n\n    <br>\n\n    <v-alert\n      color="primary"\n      icon="$vuetify"\n      theme="dark"\n      prominent\n    >\n      Praesent congue erat at massa. Nullam vel sem. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Proin viverra, ligula sit amet ultrices semper, ligula arcu tristique sapien, a accumsan nisi mauris ac eros. Curabitur at lacus ac velit ornare lobortis.\n    </v-alert>\n  </div>\n</template>\n';
const _sfc_main$5 = {};
const _hoisted_1$3 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_2$2 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
function _sfc_render$4(_ctx, _cache) {
  const _component_v_alert = resolveComponent("v-alert");
  return openBlock(), createElementBlock("div", null, [
    createVNode(_component_v_alert, {
      color: "purple",
      variant: "outlined"
    }, {
      title: withCtx(() => [
        createTextVNode(" Outlined Alert ")
      ]),
      default: withCtx(() => [
        createTextVNode(" Maecenas ullamcorper, dui et placerat feugiat, eros pede varius nisi, condimentum viverra felis nunc et lorem. Duis vel nibh at velit scelerisque suscipit. Praesent blandit laoreet nibh. Aenean posuere, tortor sed cursus feugiat, nunc augue blandit nunc, eu sollicitudin urna dolor sagittis lacus. Etiam sollicitudin, ipsum eu pulvinar rutrum, tellus ipsum laoreet sapien, quis venenatis ante odio sit amet eros. ")
      ]),
      _: 1
    }),
    _hoisted_1$3,
    createVNode(_component_v_alert, {
      type: "success",
      variant: "outlined"
    }, {
      default: withCtx(() => [
        createTextVNode(" Praesent venenatis metus at tortor pulvinar varius. Aenean commodo ligula eget dolor. Praesent ac massa at ligula laoreet iaculis. Vestibulum ullamcorper mauris at ligula. ")
      ]),
      _: 1
    }),
    _hoisted_2$2,
    createVNode(_component_v_alert, {
      border: "top",
      type: "warning",
      variant: "outlined",
      prominent: ""
    }, {
      default: withCtx(() => [
        createTextVNode(" Duis arcu tortor, suscipit eget, imperdiet nec, imperdiet iaculis, ipsum. Suspendisse non nisl sit amet velit hendrerit rutrum. Nullam vel sem. Pellentesque dapibus hendrerit tortor. ")
      ]),
      _: 1
    })
  ]);
}
const __6 = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["render", _sfc_render$4]]);
const __6_raw = '<template>\n  <div>\n    <v-alert\n      color="purple"\n      variant="outlined"\n    >\n      <template v-slot:title>\n        Outlined Alert\n      </template>\n\n      Maecenas ullamcorper, dui et placerat feugiat, eros pede varius nisi, condimentum viverra felis nunc et lorem. Duis vel nibh at velit scelerisque suscipit. Praesent blandit laoreet nibh. Aenean posuere, tortor sed cursus feugiat, nunc augue blandit nunc, eu sollicitudin urna dolor sagittis lacus. Etiam sollicitudin, ipsum eu pulvinar rutrum, tellus ipsum laoreet sapien, quis venenatis ante odio sit amet eros.\n    </v-alert>\n\n    <br>\n\n    <v-alert\n      type="success"\n      variant="outlined"\n    >\n      Praesent venenatis metus at tortor pulvinar varius. Aenean commodo ligula eget dolor. Praesent ac massa at ligula laoreet iaculis. Vestibulum ullamcorper mauris at ligula.\n    </v-alert>\n\n    <br>\n\n    <v-alert\n      border="top"\n      type="warning"\n      variant="outlined"\n      prominent\n    >\n      Duis arcu tortor, suscipit eget, imperdiet nec, imperdiet iaculis, ipsum. Suspendisse non nisl sit amet velit hendrerit rutrum. Nullam vel sem. Pellentesque dapibus hendrerit tortor.\n    </v-alert>\n  </div>\n</template>\n';
const _sfc_main$4 = {};
const _hoisted_1$2 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_2$1 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
function _sfc_render$3(_ctx, _cache) {
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_alert = resolveComponent("v-alert");
  return openBlock(), createElementBlock("div", null, [
    createVNode(_component_v_alert, {
      type: "error",
      prominent: ""
    }, {
      text: withCtx(() => [
        createTextVNode(" Nunc nonummy metus. Nunc interdum lacus sit amet orci Nullam dictum felis eu pede. ")
      ]),
      append: withCtx(() => [
        createVNode(_component_v_btn, {
          size: "small",
          variant: "text"
        }, {
          default: withCtx(() => [
            createTextVNode("Take action")
          ]),
          _: 1
        })
      ]),
      _: 1
    }),
    _hoisted_1$2,
    createVNode(_component_v_alert, {
      color: "blue-grey-darken-2",
      density: "compact",
      icon: "mdi-school",
      prominent: ""
    }, {
      default: withCtx(() => [
        createTextVNode(" Sed augue ipsum, egestas nec, vestibulum et, malesuada adipiscing, dui. Aenean ut eros et nisl sagittis vestibulum. Sed aliquam ultrices mauris. Donec vitae orci sed dolor rutrum auctor. ")
      ]),
      _: 1
    }),
    _hoisted_2$1,
    createVNode(_component_v_alert, {
      icon: "mdi-shield-lock-outline",
      type: "info",
      prominent: ""
    }, {
      default: withCtx(() => [
        createTextVNode(" Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Sed in libero ut nibh placerat accumsan.. Curabitur blandit mollis lacus. Curabitur blandit mollis lacus. ")
      ]),
      _: 1
    })
  ]);
}
const __7 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["render", _sfc_render$3]]);
const __7_raw = '<template>\n  <div>\n    <v-alert\n      type="error"\n      prominent\n    >\n      <template v-slot:text>\n        Nunc nonummy metus. Nunc interdum lacus sit amet orci Nullam dictum felis eu pede.\n      </template>\n\n      <template v-slot:append>\n        <v-btn size="small" variant="text">Take action</v-btn>\n      </template>\n    </v-alert>\n\n    <br>\n\n    <v-alert\n      color="blue-grey-darken-2"\n      density="compact"\n      icon="mdi-school"\n      prominent\n    >\n      Sed augue ipsum, egestas nec, vestibulum et, malesuada adipiscing, dui. Aenean ut eros et nisl sagittis vestibulum. Sed aliquam ultrices mauris. Donec vitae orci sed dolor rutrum auctor.\n    </v-alert>\n\n    <br>\n\n    <v-alert\n      icon="mdi-shield-lock-outline"\n      type="info"\n      prominent\n    >\n      Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Sed in libero ut nibh placerat accumsan.. Curabitur blandit mollis lacus. Curabitur blandit mollis lacus.\n    </v-alert>\n  </div>\n</template>\n';
const _sfc_main$3 = {};
const _hoisted_1$1 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
function _sfc_render$2(_ctx, _cache) {
  const _component_v_alert = resolveComponent("v-alert");
  return openBlock(), createElementBlock("div", null, [
    createVNode(_component_v_alert, {
      rounded: "0",
      title: "Info",
      type: "info"
    }, {
      default: withCtx(() => [
        createTextVNode(" I'm an alert with no rounded borders. Lorem ipsum dolor sit, amet consectetur adipisicing elit. Aspernatur recusandae, est itaque laboriosam amet officia? Officia repellat provident sed est adipisci voluptatibus, voluptas reprehenderit dicta voluptatum, optio enim, placeat nostrum. ")
      ]),
      _: 1
    }),
    _hoisted_1$1,
    createVNode(_component_v_alert, {
      rounded: "xl",
      title: "Success",
      type: "success",
      variant: "outlined"
    }, {
      default: withCtx(() => [
        createTextVNode(" I'm an alert with extra large rounded borders. Lorem ipsum dolor, sit amet consectetur adipisicing elit. Enim cumque vel sapiente suscipit officia ullam quam possimus provident id neque, cupiditate fuga animi expedita, beatae ipsam in veniam inventore totam. ")
      ]),
      _: 1
    }),
    _hoisted_2,
    createVNode(_component_v_alert, {
      rounded: "pill",
      title: "Warning",
      type: "warning",
      prominent: ""
    }, {
      default: withCtx(() => [
        createTextVNode(" I'm an alert with pill rounded borders. Lorem ipsum dolor sit amet consectetur adipisicing elit. Laudantium ex excepturi ea odio cum libero animi vitae repellat fuga velit explicabo quae, ducimus. ")
      ]),
      _: 1
    }),
    _hoisted_3,
    createVNode(_component_v_alert, {
      rounded: "t-xl b-lg",
      title: "Error",
      type: "error",
      prominent: ""
    }, {
      default: withCtx(() => [
        createTextVNode(" I'm an alert with top and bottom borders. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Rerum esse quis eius delectus odio repellat voluptates ullam doloribus eaque dignissimos ")
      ]),
      _: 1
    })
  ]);
}
const __8 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["render", _sfc_render$2]]);
const __8_raw = `<template>
  <div>
    <v-alert
      rounded="0"
      title="Info"
      type="info"
    >
      I'm an alert with no rounded borders. Lorem ipsum dolor sit, amet consectetur adipisicing elit. Aspernatur recusandae, est itaque laboriosam amet officia? Officia repellat provident sed est adipisci voluptatibus, voluptas reprehenderit dicta voluptatum, optio enim, placeat nostrum.
    </v-alert>

    <br>

    <v-alert
      rounded="xl"
      title="Success"
      type="success"
      variant="outlined"
    >
      I'm an alert with extra large rounded borders. Lorem ipsum dolor, sit amet consectetur adipisicing elit. Enim cumque vel sapiente suscipit officia ullam quam possimus provident id neque, cupiditate fuga animi expedita, beatae ipsam in veniam inventore totam.
    </v-alert>

    <br>

    <v-alert
      rounded="pill"
      title="Warning"
      type="warning"
      prominent
    >
      I'm an alert with pill rounded borders. Lorem ipsum dolor sit amet consectetur adipisicing elit. Laudantium ex excepturi ea odio cum libero animi vitae repellat fuga velit explicabo quae, ducimus.
    </v-alert>

    <br>

    <v-alert
      rounded="t-xl b-lg"
      title="Error"
      type="error"
      prominent
    >
      I'm an alert with top and bottom borders. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Rerum esse quis eius delectus odio repellat voluptates ullam doloribus eaque dignissimos
    </v-alert>
  </div>
</template>
`;
const _sfc_main$2 = {};
function _sfc_render$1(_ctx, _cache) {
  const _component_v_alert = resolveComponent("v-alert");
  return openBlock(), createBlock(_component_v_alert, {
    text: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!",
    title: "Alert title",
    type: "success"
  });
}
const __9 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["render", _sfc_render$1]]);
const __9_raw = '<template>\n  <v-alert\n    text="Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!"\n    title="Alert title"\n    type="success"\n  ></v-alert>\n</template>\n';
const _sfc_main$1 = {};
function _sfc_render(_ctx, _cache) {
  const _component_v_alert = resolveComponent("v-alert");
  return openBlock(), createBlock(_component_v_alert, {
    text: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!",
    title: "Alert title",
    type: "info",
    variant: "tonal"
  });
}
const __10 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["render", _sfc_render]]);
const __10_raw = '<template>\n  <v-alert\n    text="Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!"\n    title="Alert title"\n    type="info"\n    variant="tonal"\n  ></v-alert>\n</template>\n';
const _hoisted_1 = { class: "text-center" };
const name = "v-alert";
const _sfc_main = {
  __name: "usage",
  setup(__props) {
    const model = ref("default");
    const alert = ref(true);
    const closable = ref(false);
    const icon = ref(false);
    const title = ref(false);
    const type = ref();
    const options = ["outlined", "tonal"];
    const props = computed(() => {
      return {
        closable: closable.value || void 0,
        icon: icon.value ? "$vuetify" : void 0,
        title: title.value ? "Alert title" : void 0,
        text: "...",
        type: type.value || void 0,
        variant: ["outlined", "tonal"].includes(model.value) ? model.value : void 0
      };
    });
    const slots = computed(() => {
      return "";
    });
    const code = computed(() => {
      return `<${name}${propsToString(props.value)}>${slots.value}</${name}>`;
    });
    return (_ctx, _cache) => {
      const _component_v_alert = resolveComponent("v-alert");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_select = resolveComponent("v-select");
      const _component_v_checkbox = resolveComponent("v-checkbox");
      const _component_ExamplesUsageExample = _sfc_main$c;
      return openBlock(), createBlock(_component_ExamplesUsageExample, {
        modelValue: unref(model),
        "onUpdate:modelValue": _cache[6] || (_cache[6] = ($event) => isRef(model) ? model.value = $event : null),
        code: unref(code),
        name,
        options
      }, {
        configuration: withCtx(() => [
          createVNode(_component_v_select, {
            modelValue: unref(type),
            "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => isRef(type) ? type.value = $event : null),
            items: [
              "success",
              "info",
              "warning",
              "error"
            ],
            label: "Type",
            clearable: ""
          }, null, 8, ["modelValue"]),
          createVNode(_component_v_checkbox, {
            modelValue: unref(title),
            "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => isRef(title) ? title.value = $event : null),
            label: "Show title"
          }, null, 8, ["modelValue"]),
          createVNode(_component_v_checkbox, {
            modelValue: unref(closable),
            "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => isRef(closable) ? closable.value = $event : null),
            label: "Closable"
          }, null, 8, ["modelValue"]),
          createVNode(_component_v_checkbox, {
            modelValue: unref(icon),
            "onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => isRef(icon) ? icon.value = $event : null),
            label: "Custom icon"
          }, null, 8, ["modelValue"])
        ]),
        default: withCtx(() => [
          createBaseVNode("div", null, [
            unref(alert) ? (openBlock(), createBlock(_component_v_alert, mergeProps({
              key: 0,
              modelValue: unref(alert),
              "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(alert) ? alert.value = $event : null)
            }, unref(props)), {
              text: withCtx(() => [
                createTextVNode(" Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem! ")
              ]),
              _: 1
            }, 16, ["modelValue"])) : createCommentVNode("", true),
            createBaseVNode("div", _hoisted_1, [
              !unref(alert) ? (openBlock(), createBlock(_component_v_btn, {
                key: 0,
                onClick: _cache[1] || (_cache[1] = ($event) => alert.value = true)
              }, {
                default: withCtx(() => [
                  createTextVNode(" Show Alert ")
                ]),
                _: 1
              })) : createCommentVNode("", true)
            ])
          ])
        ]),
        _: 1
      }, 8, ["modelValue", "code"]);
    };
  }
};
const __11 = _sfc_main;
const __11_raw = `<template>
  <ExamplesUsageExample
    v-model="model"
    :code="code"
    :name="name"
    :options="options"
  >
    <div>
      <v-alert
        v-if="alert"
        v-model="alert"
        v-bind="props"
      >
        <template v-slot:text>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!
        </template>
      </v-alert>

      <div class="text-center">
        <v-btn v-if="!alert" @click="alert = true">
          Show Alert
        </v-btn>
      </div>
    </div>

    <template v-slot:configuration>
      <v-select
        v-model="type"
        :items="[
          'success',
          'info',
          'warning',
          'error',
        ]"
        label="Type"
        clearable
      ></v-select>

      <v-checkbox v-model="title" label="Show title"></v-checkbox>

      <v-checkbox v-model="closable" label="Closable"></v-checkbox>

      <v-checkbox v-model="icon" label="Custom icon"></v-checkbox>
    </template>
  </ExamplesUsageExample>
</template>

<script setup>
  const name = 'v-alert'
  const model = ref('default')
  const alert = ref(true)
  const closable = ref(false)
  const icon = ref(false)
  const title = ref(false)
  const type = ref()
  const options = ['outlined', 'tonal']
  const props = computed(() => {
    return {
      closable: closable.value || undefined,
      icon: icon.value ? '$vuetify' : undefined,
      title: title.value ? 'Alert title' : undefined,
      text: '...',
      type: type.value || undefined,
      variant: ['outlined', 'tonal'].includes(model.value) ? model.value : undefined,
    }
  })

  const slots = computed(() => {
    return ''
  })

  const code = computed(() => {
    return \`<\${name}\${propsToString(props.value)}>\${slots.value}</\${name}>\`
  })
<\/script>
`;
const vAlert = {
  "prop-border-color": {
    component: __0,
    source: __0_raw
  },
  "prop-border": {
    component: __1,
    source: __1_raw
  },
  "prop-closable": {
    component: __2,
    source: __2_raw
  },
  "prop-content": {
    component: __3,
    source: __3_raw
  },
  "prop-density": {
    component: __4,
    source: __4_raw
  },
  "prop-icon": {
    component: __5,
    source: __5_raw
  },
  "prop-outlined": {
    component: __6,
    source: __6_raw
  },
  "prop-prominent": {
    component: __7,
    source: __7_raw
  },
  "prop-rounded": {
    component: __8,
    source: __8_raw
  },
  "prop-type": {
    component: __9,
    source: __9_raw
  },
  "prop-variant": {
    component: __10,
    source: __10_raw
  },
  "usage": {
    component: __11,
    source: __11_raw
  }
};
export {
  vAlert as default
};
