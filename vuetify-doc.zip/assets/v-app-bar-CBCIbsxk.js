import { J as ref, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, b as createVNode, h as createTextVNode, y as _export_sfc, a9 as mergeProps, l as createElementBlock, F as Fragment, v as renderList, t as toDisplayString, j as computed, ag as propsToString, f as unref, E as isRef, ak as normalizeProps, al as guardReactiveProps, S as createSlots } from "./index-DGybHjCP.js";
import { _ as __6 } from "./prop-scroll-behavior-Dyk0JIkp.js";
import { _ as _sfc_main$7 } from "./UsageExample-M8CmNipa.js";
const _sfc_main$6 = {
  __name: "misc-app-bar-nav",
  setup(__props) {
    const drawer = ref(false);
    const group = ref(null);
    return (_ctx, _cache) => {
      const _component_v_app_bar_nav_icon = resolveComponent("v-app-bar-nav-icon");
      const _component_v_toolbar_title = resolveComponent("v-toolbar-title");
      const _component_v_app_bar = resolveComponent("v-app-bar");
      const _component_v_list_item = resolveComponent("v-list-item");
      const _component_v_list_item_group = resolveComponent("v-list-item-group");
      const _component_v_list = resolveComponent("v-list");
      const _component_v_navigation_drawer = resolveComponent("v-navigation-drawer");
      const _component_v_card = resolveComponent("v-card");
      const _component_v_main = resolveComponent("v-main");
      const _component_v_layout = resolveComponent("v-layout");
      return openBlock(), createBlock(_component_v_layout, { style: { "overflow": "hidden" } }, {
        default: withCtx(() => [
          createVNode(_component_v_app_bar, {
            color: "deep-purple",
            absolute: ""
          }, {
            default: withCtx(() => [
              createVNode(_component_v_app_bar_nav_icon, {
                onClick: _cache[0] || (_cache[0] = ($event) => drawer.value = !drawer.value)
              }),
              createVNode(_component_v_toolbar_title, null, {
                default: withCtx(() => [
                  createTextVNode("Title")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_navigation_drawer, {
            modelValue: drawer.value,
            "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => drawer.value = $event),
            absolute: "",
            temporary: ""
          }, {
            default: withCtx(() => [
              createVNode(_component_v_list, {
                dense: "",
                nav: ""
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_list_item_group, {
                    modelValue: group.value,
                    "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => group.value = $event),
                    "active-class": "deep-purple--text text--accent-4"
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_v_list_item, {
                        "prepend-icon": "mdi-home",
                        title: "Home"
                      }),
                      createVNode(_component_v_list_item, {
                        "prepend-icon": "mdi-account",
                        title: "Account"
                      })
                    ]),
                    _: 1
                  }, 8, ["modelValue"])
                ]),
                _: 1
              })
            ]),
            _: 1
          }, 8, ["modelValue"]),
          createVNode(_component_v_main, null, {
            default: withCtx(() => [
              createVNode(_component_v_card, {
                class: "mx-auto overflow-hidden",
                height: "400"
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __0 = _sfc_main$6;
const __0_raw = `<template>
  <v-layout style="overflow: hidden">
    <v-app-bar
      color="deep-purple"
      absolute
    >
      <v-app-bar-nav-icon @click="drawer = !drawer"></v-app-bar-nav-icon>

      <v-toolbar-title>Title</v-toolbar-title>
    </v-app-bar>
    <v-navigation-drawer
      v-model="drawer"
      absolute
      temporary
    >
      <v-list
        dense
        nav
      >
        <v-list-item-group
          v-model="group"
          active-class="deep-purple--text text--accent-4"
        >
          <v-list-item prepend-icon="mdi-home" title="Home"></v-list-item>

          <v-list-item prepend-icon="mdi-account" title="Account"></v-list-item>
        </v-list-item-group>
      </v-list>
    </v-navigation-drawer>
    <v-main>
      <v-card
        class="mx-auto overflow-hidden"
        height="400"
      ></v-card>
    </v-main>
  </v-layout>
</template>

<script setup>
  import { ref } from 'vue'

  const drawer = ref(false)
  const group = ref(null)
<\/script>

<script>
  export default {
    data: () => ({
      drawer: false,
      group: null,
    }),
  }
<\/script>
`;
const _sfc_main$5 = {};
function _sfc_render$4(_ctx, _cache) {
  const _component_v_img = resolveComponent("v-img");
  const _component_v_app_bar_nav_icon = resolveComponent("v-app-bar-nav-icon");
  const _component_v_toolbar_title = resolveComponent("v-toolbar-title");
  const _component_v_spacer = resolveComponent("v-spacer");
  const _component_v_icon = resolveComponent("v-icon");
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_list_item_title = resolveComponent("v-list-item-title");
  const _component_v_list_item = resolveComponent("v-list-item");
  const _component_v_list = resolveComponent("v-list");
  const _component_v_menu = resolveComponent("v-menu");
  const _component_v_tab = resolveComponent("v-tab");
  const _component_v_tabs = resolveComponent("v-tabs");
  const _component_v_app_bar = resolveComponent("v-app-bar");
  const _component_v_container = resolveComponent("v-container");
  const _component_v_sheet = resolveComponent("v-sheet");
  const _component_v_layout = resolveComponent("v-layout");
  return openBlock(), createBlock(_component_v_layout, null, {
    default: withCtx(() => [
      createVNode(_component_v_app_bar, {
        color: "#6A76AB",
        "scroll-target": "#scrolling-techniques-4",
        src: "https://picsum.photos/1920/1080?random",
        absolute: "",
        dark: "",
        "fade-img-on-scroll": "",
        prominent: "",
        "shrink-on-scroll": ""
      }, {
        image: withCtx(() => [
          createVNode(_component_v_img, { gradient: "to top right, rgba(100,115,201,.7), rgba(25,32,72,.7)" })
        ]),
        extension: withCtx(() => [
          createVNode(_component_v_tabs, { "align-tabs": "title" }, {
            default: withCtx(() => [
              createVNode(_component_v_tab, null, {
                default: withCtx(() => [
                  createTextVNode("Tab 1")
                ]),
                _: 1
              }),
              createVNode(_component_v_tab, null, {
                default: withCtx(() => [
                  createTextVNode("Tab 2")
                ]),
                _: 1
              }),
              createVNode(_component_v_tab, null, {
                default: withCtx(() => [
                  createTextVNode("Tab 3")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        default: withCtx(() => [
          createVNode(_component_v_app_bar_nav_icon),
          createVNode(_component_v_toolbar_title, null, {
            default: withCtx(() => [
              createTextVNode("Title")
            ]),
            _: 1
          }),
          createVNode(_component_v_spacer),
          createVNode(_component_v_btn, { icon: "" }, {
            default: withCtx(() => [
              createVNode(_component_v_icon, null, {
                default: withCtx(() => [
                  createTextVNode("mdi-magnify")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_btn, { icon: "" }, {
            default: withCtx(() => [
              createVNode(_component_v_icon, null, {
                default: withCtx(() => [
                  createTextVNode("mdi-heart")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_menu, null, {
            activator: withCtx(({ props }) => [
              createVNode(_component_v_btn, mergeProps({
                color: "yellow",
                icon: ""
              }, props), {
                default: withCtx(() => [
                  createVNode(_component_v_icon, null, {
                    default: withCtx(() => [
                      createTextVNode("mdi-dots-vertical")
                    ]),
                    _: 1
                  })
                ]),
                _: 2
              }, 1040)
            ]),
            default: withCtx(() => [
              createVNode(_component_v_list, null, {
                default: withCtx(() => [
                  createVNode(_component_v_list_item, null, {
                    default: withCtx(() => [
                      createVNode(_component_v_list_item_title, null, {
                        default: withCtx(() => [
                          createTextVNode("Click Me 1")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_list_item, null, {
                    default: withCtx(() => [
                      createVNode(_component_v_list_item_title, null, {
                        default: withCtx(() => [
                          createTextVNode("Click Me 2")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_list_item, null, {
                    default: withCtx(() => [
                      createVNode(_component_v_list_item_title, null, {
                        default: withCtx(() => [
                          createTextVNode("Click Me 3")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_list_item, null, {
                    default: withCtx(() => [
                      createVNode(_component_v_list_item_title, null, {
                        default: withCtx(() => [
                          createTextVNode("Click Me 4")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_sheet, {
        id: "scrolling-techniques-4",
        class: "overflow-y-auto",
        "max-height": "600",
        width: "100%"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_container, { style: { "height": "1000px" } })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __1 = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["render", _sfc_render$4]]);
const __1_raw = '<template>\n  <v-layout>\n    <v-app-bar\n      color="#6A76AB"\n      scroll-target="#scrolling-techniques-4"\n      src="https://picsum.photos/1920/1080?random"\n      absolute\n      dark\n      fade-img-on-scroll\n      prominent\n      shrink-on-scroll\n    >\n      <template v-slot:image>\n        <v-img gradient="to top right, rgba(100,115,201,.7), rgba(25,32,72,.7)"></v-img>\n      </template>\n\n      <v-app-bar-nav-icon></v-app-bar-nav-icon>\n\n      <v-toolbar-title>Title</v-toolbar-title>\n\n      <v-spacer></v-spacer>\n\n      <v-btn icon>\n        <v-icon>mdi-magnify</v-icon>\n      </v-btn>\n\n      <v-btn icon>\n        <v-icon>mdi-heart</v-icon>\n      </v-btn>\n\n      <v-menu>\n        <template v-slot:activator="{ props }">\n          <v-btn\n            color="yellow"\n            icon\n            v-bind="props"\n          >\n            <v-icon>mdi-dots-vertical</v-icon>\n          </v-btn>\n        </template>\n\n        <v-list>\n          <v-list-item>\n            <v-list-item-title>Click Me 1</v-list-item-title>\n          </v-list-item>\n\n          <v-list-item>\n            <v-list-item-title>Click Me 2</v-list-item-title>\n          </v-list-item>\n\n          <v-list-item>\n            <v-list-item-title>Click Me 3</v-list-item-title>\n          </v-list-item>\n\n          <v-list-item>\n            <v-list-item-title>Click Me 4</v-list-item-title>\n          </v-list-item>\n        </v-list>\n      </v-menu>\n\n      <template v-slot:extension>\n        <v-tabs align-tabs="title">\n          <v-tab>Tab 1</v-tab>\n\n          <v-tab>Tab 2</v-tab>\n\n          <v-tab>Tab 3</v-tab>\n        </v-tabs>\n      </template>\n    </v-app-bar>\n    <v-sheet\n      id="scrolling-techniques-4"\n      class="overflow-y-auto"\n      max-height="600"\n      width="100%"\n    >\n      <v-container style="height: 1000px;"></v-container>\n    </v-sheet>\n  </v-layout>\n</template>\n';
const _sfc_main$4 = {};
function _sfc_render$3(_ctx, _cache) {
  const _component_v_app_bar_nav_icon = resolveComponent("v-app-bar-nav-icon");
  const _component_v_toolbar_title = resolveComponent("v-toolbar-title");
  const _component_v_spacer = resolveComponent("v-spacer");
  const _component_v_icon = resolveComponent("v-icon");
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_list_item_title = resolveComponent("v-list-item-title");
  const _component_v_list_item = resolveComponent("v-list-item");
  const _component_v_list = resolveComponent("v-list");
  const _component_v_menu = resolveComponent("v-menu");
  const _component_v_app_bar = resolveComponent("v-app-bar");
  return openBlock(), createElementBlock("div", null, [
    createVNode(_component_v_app_bar, {
      color: "deep-purple-accent-4",
      dark: "",
      dense: ""
    }, {
      default: withCtx(() => [
        createVNode(_component_v_app_bar_nav_icon),
        createVNode(_component_v_toolbar_title, null, {
          default: withCtx(() => [
            createTextVNode("Page title")
          ]),
          _: 1
        }),
        createVNode(_component_v_spacer),
        createVNode(_component_v_btn, { icon: "" }, {
          default: withCtx(() => [
            createVNode(_component_v_icon, null, {
              default: withCtx(() => [
                createTextVNode("mdi-heart")
              ]),
              _: 1
            })
          ]),
          _: 1
        }),
        createVNode(_component_v_btn, { icon: "" }, {
          default: withCtx(() => [
            createVNode(_component_v_icon, null, {
              default: withCtx(() => [
                createTextVNode("mdi-magnify")
              ]),
              _: 1
            })
          ]),
          _: 1
        }),
        createVNode(_component_v_menu, null, {
          activator: withCtx(({ props }) => [
            createVNode(_component_v_btn, mergeProps({ icon: "" }, props), {
              default: withCtx(() => [
                createVNode(_component_v_icon, null, {
                  default: withCtx(() => [
                    createTextVNode("mdi-dots-vertical")
                  ]),
                  _: 1
                })
              ]),
              _: 2
            }, 1040)
          ]),
          default: withCtx(() => [
            createVNode(_component_v_list, null, {
              default: withCtx(() => [
                (openBlock(), createElementBlock(Fragment, null, renderList(5, (n) => {
                  return createVNode(_component_v_list_item, {
                    key: n,
                    onClick: () => {
                    }
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_v_list_item_title, null, {
                        default: withCtx(() => [
                          createTextVNode("Option " + toDisplayString(n), 1)
                        ]),
                        _: 2
                      }, 1024)
                    ]),
                    _: 2
                  }, 1024);
                }), 64))
              ]),
              _: 1
            })
          ]),
          _: 1
        })
      ]),
      _: 1
    })
  ]);
}
const __2 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["render", _sfc_render$3]]);
const __2_raw = '<template>\n  <div>\n    <v-app-bar\n      color="deep-purple-accent-4"\n      dark\n      dense\n    >\n      <v-app-bar-nav-icon></v-app-bar-nav-icon>\n\n      <v-toolbar-title>Page title</v-toolbar-title>\n\n      <v-spacer></v-spacer>\n\n      <v-btn icon>\n        <v-icon>mdi-heart</v-icon>\n      </v-btn>\n\n      <v-btn icon>\n        <v-icon>mdi-magnify</v-icon>\n      </v-btn>\n\n      <v-menu>\n        <template v-slot:activator="{ props }">\n          <v-btn\n            icon\n            v-bind="props"\n          >\n            <v-icon>mdi-dots-vertical</v-icon>\n          </v-btn>\n        </template>\n\n        <v-list>\n          <v-list-item\n            v-for="n in 5"\n            :key="n"\n            @click="() => {}"\n          >\n            <v-list-item-title>Option {{ n }}</v-list-item-title>\n          </v-list-item>\n        </v-list>\n      </v-menu>\n    </v-app-bar>\n  </div>\n</template>\n';
const _sfc_main$3 = {};
function _sfc_render$2(_ctx, _cache) {
  const _component_v_app_bar_nav_icon = resolveComponent("v-app-bar-nav-icon");
  const _component_v_app_bar_title = resolveComponent("v-app-bar-title");
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_app_bar = resolveComponent("v-app-bar");
  const _component_v_sheet = resolveComponent("v-sheet");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  const _component_v_main = resolveComponent("v-main");
  const _component_v_layout = resolveComponent("v-layout");
  const _component_v_card = resolveComponent("v-card");
  return openBlock(), createBlock(_component_v_card, {
    class: "mx-auto",
    "max-width": "448"
  }, {
    default: withCtx(() => [
      createVNode(_component_v_layout, null, {
        default: withCtx(() => [
          createVNode(_component_v_app_bar, {
            color: "primary",
            density: "compact"
          }, {
            prepend: withCtx(() => [
              createVNode(_component_v_app_bar_nav_icon)
            ]),
            append: withCtx(() => [
              createVNode(_component_v_btn, { icon: "mdi-dots-vertical" })
            ]),
            default: withCtx(() => [
              createVNode(_component_v_app_bar_title, null, {
                default: withCtx(() => [
                  createTextVNode("Photos")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_main, null, {
            default: withCtx(() => [
              createVNode(_component_v_container, { fluid: "" }, {
                default: withCtx(() => [
                  createVNode(_component_v_row, { dense: "" }, {
                    default: withCtx(() => [
                      (openBlock(), createElementBlock(Fragment, null, renderList(8, (n) => {
                        return createVNode(_component_v_col, {
                          key: n,
                          cols: "3"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_v_sheet, {
                              color: "surface-variant-alt",
                              height: "96"
                            })
                          ]),
                          _: 2
                        }, 1024);
                      }), 64))
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __3 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["render", _sfc_render$2]]);
const __3_raw = '<template>\n  <v-card\n    class="mx-auto"\n    max-width="448"\n  >\n    <v-layout>\n      <v-app-bar\n        color="primary"\n        density="compact"\n      >\n        <template v-slot:prepend>\n          <v-app-bar-nav-icon></v-app-bar-nav-icon>\n        </template>\n\n        <v-app-bar-title>Photos</v-app-bar-title>\n\n        <template v-slot:append>\n          <v-btn icon="mdi-dots-vertical"></v-btn>\n        </template>\n      </v-app-bar>\n\n      <v-main>\n        <v-container fluid>\n          <v-row dense>\n            <v-col\n              v-for="n in 8"\n              :key="n"\n              cols="3"\n            >\n              <v-sheet\n                color="surface-variant-alt"\n                height="96"\n              ></v-sheet>\n            </v-col>\n          </v-row>\n        </v-container>\n      </v-main>\n    </v-layout>\n  </v-card>\n</template>\n';
const _sfc_main$2 = {};
function _sfc_render$1(_ctx, _cache) {
  const _component_v_img = resolveComponent("v-img");
  const _component_v_app_bar_nav_icon = resolveComponent("v-app-bar-nav-icon");
  const _component_v_app_bar_title = resolveComponent("v-app-bar-title");
  const _component_v_spacer = resolveComponent("v-spacer");
  const _component_v_icon = resolveComponent("v-icon");
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_app_bar = resolveComponent("v-app-bar");
  const _component_v_card = resolveComponent("v-card");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  const _component_v_main = resolveComponent("v-main");
  const _component_v_layout = resolveComponent("v-layout");
  return openBlock(), createBlock(_component_v_card, {
    class: "mx-auto",
    color: "grey-lighten-3",
    "max-width": "448"
  }, {
    default: withCtx(() => [
      createVNode(_component_v_layout, null, {
        default: withCtx(() => [
          createVNode(_component_v_app_bar, {
            color: "teal-darken-4",
            image: "https://picsum.photos/1920/1080?random"
          }, {
            image: withCtx(() => [
              createVNode(_component_v_img, { gradient: "to top right, rgba(19,84,122,.8), rgba(128,208,199,.8)" })
            ]),
            prepend: withCtx(() => [
              createVNode(_component_v_app_bar_nav_icon)
            ]),
            default: withCtx(() => [
              createVNode(_component_v_app_bar_title, null, {
                default: withCtx(() => [
                  createTextVNode("Title")
                ]),
                _: 1
              }),
              createVNode(_component_v_spacer),
              createVNode(_component_v_btn, { icon: "" }, {
                default: withCtx(() => [
                  createVNode(_component_v_icon, null, {
                    default: withCtx(() => [
                      createTextVNode("mdi-magnify")
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }),
              createVNode(_component_v_btn, { icon: "" }, {
                default: withCtx(() => [
                  createVNode(_component_v_icon, null, {
                    default: withCtx(() => [
                      createTextVNode("mdi-heart")
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }),
              createVNode(_component_v_btn, { icon: "" }, {
                default: withCtx(() => [
                  createVNode(_component_v_icon, null, {
                    default: withCtx(() => [
                      createTextVNode("mdi-dots-vertical")
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_main, null, {
            default: withCtx(() => [
              createVNode(_component_v_container, { fluid: "" }, {
                default: withCtx(() => [
                  createVNode(_component_v_row, { dense: "" }, {
                    default: withCtx(() => [
                      (openBlock(), createElementBlock(Fragment, null, renderList(4, (n) => {
                        return createVNode(_component_v_col, {
                          key: n,
                          cols: "12"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_v_card, {
                              subtitle: `Subtitle for Content ${n}`,
                              title: `Content ${n}`,
                              text: "Lorem ipsum dolor sit amet consectetur, adipisicing elit.?"
                            }, null, 8, ["subtitle", "title"])
                          ]),
                          _: 2
                        }, 1024);
                      }), 64))
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __4 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["render", _sfc_render$1]]);
const __4_raw = '<template>\n  <v-card class="mx-auto" color="grey-lighten-3" max-width="448">\n    <v-layout>\n      <v-app-bar\n        color="teal-darken-4"\n        image="https://picsum.photos/1920/1080?random"\n      >\n        <template v-slot:image>\n          <v-img\n            gradient="to top right, rgba(19,84,122,.8), rgba(128,208,199,.8)"\n          ></v-img>\n        </template>\n\n        <template v-slot:prepend>\n          <v-app-bar-nav-icon></v-app-bar-nav-icon>\n        </template>\n\n        <v-app-bar-title>Title</v-app-bar-title>\n\n        <v-spacer></v-spacer>\n\n        <v-btn icon>\n          <v-icon>mdi-magnify</v-icon>\n        </v-btn>\n\n        <v-btn icon>\n          <v-icon>mdi-heart</v-icon>\n        </v-btn>\n\n        <v-btn icon>\n          <v-icon>mdi-dots-vertical</v-icon>\n        </v-btn>\n      </v-app-bar>\n\n      <v-main>\n        <v-container fluid>\n          <v-row dense>\n            <v-col\n              v-for="n in 4"\n              :key="n"\n              cols="12"\n            >\n              <v-card\n                :subtitle="`Subtitle for Content ${n}`"\n                :title="`Content ${n}`"\n                text="Lorem ipsum dolor sit amet consectetur, adipisicing elit.?"\n              ></v-card>\n            </v-col>\n          </v-row>\n        </v-container>\n      </v-main>\n    </v-layout>\n  </v-card>\n</template>\n';
const _sfc_main$1 = {};
function _sfc_render(_ctx, _cache) {
  const _component_v_app_bar_nav_icon = resolveComponent("v-app-bar-nav-icon");
  const _component_v_app_bar_title = resolveComponent("v-app-bar-title");
  const _component_v_icon = resolveComponent("v-icon");
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_app_bar = resolveComponent("v-app-bar");
  const _component_v_img = resolveComponent("v-img");
  const _component_v_card_text = resolveComponent("v-card-text");
  const _component_v_card = resolveComponent("v-card");
  const _component_v_container = resolveComponent("v-container");
  const _component_v_main = resolveComponent("v-main");
  const _component_v_layout = resolveComponent("v-layout");
  return openBlock(), createBlock(_component_v_card, {
    class: "mx-auto",
    "max-width": "448"
  }, {
    default: withCtx(() => [
      createVNode(_component_v_layout, null, {
        default: withCtx(() => [
          createVNode(_component_v_app_bar, {
            color: "info",
            density: "prominent"
          }, {
            prepend: withCtx(() => [
              createVNode(_component_v_app_bar_nav_icon)
            ]),
            append: withCtx(() => [
              createVNode(_component_v_btn, { icon: "" }, {
                default: withCtx(() => [
                  createVNode(_component_v_icon, null, {
                    default: withCtx(() => [
                      createTextVNode("mdi-dots-vertical")
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            default: withCtx(() => [
              createVNode(_component_v_app_bar_title, null, {
                default: withCtx(() => [
                  createTextVNode("My Recent Trips")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_main, null, {
            default: withCtx(() => [
              createVNode(_component_v_container, { fluid: "" }, {
                default: withCtx(() => [
                  createVNode(_component_v_card, {
                    class: "mb-2",
                    density: "compact",
                    "prepend-avatar": "https://randomuser.me/api/portraits/women/10.jpg",
                    subtitle: "Salsa, merengue, y cumbia",
                    title: "Cuba",
                    variant: "text",
                    border: ""
                  }, {
                    actions: withCtx(() => [
                      createVNode(_component_v_btn, {
                        color: "primary",
                        variant: "text"
                      }, {
                        default: withCtx(() => [
                          createTextVNode("View More")
                        ]),
                        _: 1
                      }),
                      createVNode(_component_v_btn, {
                        color: "primary",
                        variant: "text"
                      }, {
                        default: withCtx(() => [
                          createTextVNode("See in Map")
                        ]),
                        _: 1
                      })
                    ]),
                    default: withCtx(() => [
                      createVNode(_component_v_img, {
                        height: "128",
                        src: "https://picsum.photos/512/128?image=660",
                        cover: ""
                      }),
                      createVNode(_component_v_card_text, null, {
                        default: withCtx(() => [
                          createTextVNode(" During my last trip to South America, I spent 2 weeks traveling through Patagonia in Chile. ")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_card, {
                    density: "comfortable",
                    "prepend-avatar": "https://randomuser.me/api/portraits/women/17.jpg",
                    subtitle: "Salsa, merengue, y cumbia",
                    title: "Florida",
                    variant: "text",
                    border: ""
                  }, {
                    actions: withCtx(() => [
                      createVNode(_component_v_btn, {
                        color: "primary",
                        variant: "text"
                      }, {
                        default: withCtx(() => [
                          createTextVNode("View More")
                        ]),
                        _: 1
                      }),
                      createVNode(_component_v_btn, {
                        color: "primary",
                        variant: "text"
                      }, {
                        default: withCtx(() => [
                          createTextVNode("See in Map")
                        ]),
                        _: 1
                      })
                    ]),
                    default: withCtx(() => [
                      createVNode(_component_v_img, {
                        height: "128",
                        src: "https://picsum.photos/512/128?random",
                        cover: ""
                      }),
                      createVNode(_component_v_card_text, null, {
                        default: withCtx(() => [
                          createTextVNode(" During my last trip to Florida, I spent 2 weeks traveling through the Everglades. ")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __5 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["render", _sfc_render]]);
const __5_raw = '<template>\n  <v-card class="mx-auto" max-width="448">\n    <v-layout>\n      <v-app-bar\n        color="info"\n        density="prominent"\n      >\n        <template v-slot:prepend>\n          <v-app-bar-nav-icon></v-app-bar-nav-icon>\n        </template>\n\n        <v-app-bar-title>My Recent Trips</v-app-bar-title>\n\n        <template v-slot:append>\n          <v-btn icon>\n            <v-icon>mdi-dots-vertical</v-icon>\n          </v-btn>\n        </template>\n      </v-app-bar>\n\n      <v-main>\n        <v-container fluid>\n          <v-card\n            class="mb-2"\n            density="compact"\n            prepend-avatar="https://randomuser.me/api/portraits/women/10.jpg"\n            subtitle="Salsa, merengue, y cumbia"\n            title="Cuba"\n            variant="text"\n            border\n          >\n            <v-img height="128" src="https://picsum.photos/512/128?image=660" cover></v-img>\n\n            <v-card-text>\n              During my last trip to South America, I spent 2 weeks traveling through Patagonia in Chile.\n            </v-card-text>\n\n            <template v-slot:actions>\n              <v-btn color="primary" variant="text">View More</v-btn>\n\n              <v-btn color="primary" variant="text">See in Map</v-btn>\n            </template>\n          </v-card>\n\n          <v-card\n            density="comfortable"\n            prepend-avatar="https://randomuser.me/api/portraits/women/17.jpg"\n            subtitle="Salsa, merengue, y cumbia"\n            title="Florida"\n            variant="text"\n            border\n          >\n            <v-img height="128" src="https://picsum.photos/512/128?random" cover></v-img>\n\n            <v-card-text>\n              During my last trip to Florida, I spent 2 weeks traveling through the Everglades.\n            </v-card-text>\n\n            <template v-slot:actions>\n              <v-btn color="primary" variant="text">View More</v-btn>\n\n              <v-btn color="primary" variant="text">See in Map</v-btn>\n            </template>\n          </v-card>\n        </v-container>\n      </v-main>\n    </v-layout>\n  </v-card>\n</template>\n';
const __6_raw = `<template>
  <AppSheet class="mb-6">
    <ExamplesUsageExample
      v-model="model"
      :code="code"
      :name="name"
      :options="options"
    >
      <v-layout class="overflow-visible" style="height: 300px">
        <v-main id="scroll-behavior-layout" class="pt-0" scrollable>
          <v-app-bar
            v-bind="props"
            color="secondary"
            scroll-target="#scroll-behavior-layout > .v-main__scroller"
            style="position: sticky"
          >
            <template v-slot:prepend>
              <v-app-bar-nav-icon></v-app-bar-nav-icon>
            </template>

            <v-app-bar-title>Application Bar</v-app-bar-title>

            <template v-if="actions" v-slot:append>
              <v-btn icon="mdi-heart"></v-btn>

              <v-btn icon="mdi-magnify"></v-btn>

              <v-btn icon="mdi-dots-vertical"></v-btn>
            </template>
          </v-app-bar>

          <div style="height: 1000px"></div>
        </v-main>
      </v-layout>

      <template v-slot:configuration>
        <v-checkbox v-for="option in behaviors" :key="option.value" v-model="selectedBehaviors" :label="option.title" :value="option.value"></v-checkbox>
        <v-divider></v-divider>
        <v-checkbox v-model="selectedBehaviors" label="Inverted" value="inverted"></v-checkbox>
        <v-slider v-model="scrollThreshold" label="Threshold" max="1000" min="0" step="1"></v-slider>
      </template>
    </ExamplesUsageExample>
  </AppSheet>
</template>

<script setup>
  const name = 'v-app-bar'
  const model = ref('default')
  const options = []

  const actions = ref(false)
  const scrollThreshold = ref(300)
  const selectedBehaviors = ref([])
  const behaviors = [
    { value: 'hide', title: 'Hide' },
    { value: 'collapse', title: 'Collapse' },
    { value: 'elevate', title: 'Elevate' },
    { value: 'fade-image', title: 'Fade image' },
  ]

  const props = computed(() => {
    return {
      'scroll-behavior': selectedBehaviors.value.join(' ') || undefined,
      'scroll-threshold': scrollThreshold.value === 300 ? undefined : String(scrollThreshold.value),
      image: selectedBehaviors.value.includes('fade-image') ? 'https://picsum.photos/1920/1080?random' : undefined,
    }
  })

  const slots = computed(() => {
    let str = ''

    if (actions.value) {
      str += \`
  <template v-slot:append>
    <v-btn icon="mdi-heart"></v-btn>

    <v-btn icon="mdi-magnify"></v-btn>

    <v-btn icon="mdi-dots-vertical"></v-btn>
  </template>
\`
    }

    return str
  })

  const code = computed(() => {
    return \`<\${name}\${propsToString(props.value)}>\${slots.value}</\${name}>\`
  })
<\/script>
`;
const name = "v-app-bar";
const _sfc_main = {
  __name: "usage",
  setup(__props) {
    const model = ref("default");
    const actions = ref(false);
    const elevation = ref(2);
    const options = ["collapse", "rounded"];
    const props = computed(() => {
      return {
        collapse: model.value === "collapse" ? true : void 0,
        elevation: elevation.value === 4 ? void 0 : elevation.value,
        rounded: model.value === "rounded" ? true : void 0
      };
    });
    const slots = computed(() => {
      let str = "";
      str += `
  <template v-slot:prepend>
    <v-app-bar-nav-icon></v-app-bar-nav-icon>
  </template>

  <v-app-bar-title>Application Bar</v-app-bar-title>
`;
      if (actions.value) {
        str += `
  <template v-slot:append>
    <v-btn icon="mdi-heart"></v-btn>

    <v-btn icon="mdi-magnify"></v-btn>

    <v-btn icon="mdi-dots-vertical"></v-btn>
  </template>
`;
      }
      return str;
    });
    const code = computed(() => {
      return `<${name}${propsToString(props.value)}>${slots.value}</${name}>`;
    });
    return (_ctx, _cache) => {
      const _component_v_app_bar_nav_icon = resolveComponent("v-app-bar-nav-icon");
      const _component_v_app_bar_title = resolveComponent("v-app-bar-title");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_app_bar = resolveComponent("v-app-bar");
      const _component_v_main = resolveComponent("v-main");
      const _component_v_layout = resolveComponent("v-layout");
      const _component_v_checkbox = resolveComponent("v-checkbox");
      const _component_v_slider = resolveComponent("v-slider");
      const _component_ExamplesUsageExample = _sfc_main$7;
      return openBlock(), createBlock(_component_ExamplesUsageExample, {
        modelValue: unref(model),
        "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => isRef(model) ? model.value = $event : null),
        code: unref(code),
        name,
        options
      }, {
        configuration: withCtx(() => [
          createVNode(_component_v_checkbox, {
            modelValue: unref(actions),
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(actions) ? actions.value = $event : null),
            label: "Actions"
          }, null, 8, ["modelValue"]),
          createVNode(_component_v_slider, {
            modelValue: unref(elevation),
            "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(elevation) ? elevation.value = $event : null),
            label: "Elevation",
            max: "24",
            min: "0",
            step: "1"
          }, null, 8, ["modelValue"])
        ]),
        default: withCtx(() => [
          createVNode(_component_v_layout, { class: "overflow-visible" }, {
            default: withCtx(() => [
              createVNode(_component_v_app_bar, normalizeProps(guardReactiveProps(unref(props))), createSlots({
                prepend: withCtx(() => [
                  createVNode(_component_v_app_bar_nav_icon)
                ]),
                default: withCtx(() => [
                  createVNode(_component_v_app_bar_title, null, {
                    default: withCtx(() => [
                      createTextVNode("Application Bar")
                    ]),
                    _: 1
                  })
                ]),
                _: 2
              }, [
                unref(actions) ? {
                  name: "append",
                  fn: withCtx(() => [
                    createVNode(_component_v_btn, { icon: "mdi-heart" }),
                    createVNode(_component_v_btn, { icon: "mdi-magnify" }),
                    createVNode(_component_v_btn, { icon: "mdi-dots-vertical" })
                  ]),
                  key: "0"
                } : void 0
              ]), 1040),
              createVNode(_component_v_main, { style: { "height": "75px" } })
            ]),
            _: 1
          })
        ]),
        _: 1
      }, 8, ["modelValue", "code"]);
    };
  }
};
const __7 = _sfc_main;
const __7_raw = `<template>
  <ExamplesUsageExample
    v-model="model"
    :code="code"
    :name="name"
    :options="options"
  >
    <v-layout class="overflow-visible">
      <v-app-bar v-bind="props">
        <template v-slot:prepend>
          <v-app-bar-nav-icon></v-app-bar-nav-icon>
        </template>

        <v-app-bar-title>Application Bar</v-app-bar-title>

        <template v-if="actions" v-slot:append>
          <v-btn icon="mdi-heart"></v-btn>

          <v-btn icon="mdi-magnify"></v-btn>

          <v-btn icon="mdi-dots-vertical"></v-btn>
        </template>
      </v-app-bar>

      <v-main style="height: 75px;"></v-main>
    </v-layout>

    <template v-slot:configuration>
      <v-checkbox v-model="actions" label="Actions"></v-checkbox>

      <v-slider v-model="elevation" label="Elevation" max="24" min="0" step="1"></v-slider>
    </template>
  </ExamplesUsageExample>
</template>

<script setup>
  const name = 'v-app-bar'
  const model = ref('default')
  const actions = ref(false)
  const elevation = ref(2)
  const options = ['collapse', 'rounded']

  const props = computed(() => {
    return {
      collapse: model.value === 'collapse' ? true : undefined,
      elevation: elevation.value === 4 ? undefined : elevation.value,
      rounded: model.value === 'rounded' ? true : undefined,
    }
  })

  const slots = computed(() => {
    let str = ''

    str += \`
  <template v-slot:prepend>
    <v-app-bar-nav-icon></v-app-bar-nav-icon>
  </template>

  <v-app-bar-title>Application Bar</v-app-bar-title>
\`

    if (actions.value) {
      str += \`
  <template v-slot:append>
    <v-btn icon="mdi-heart"></v-btn>

    <v-btn icon="mdi-magnify"></v-btn>

    <v-btn icon="mdi-dots-vertical"></v-btn>
  </template>
\`
    }

    return str
  })

  const code = computed(() => {
    return \`<\${name}\${propsToString(props.value)}>\${slots.value}</\${name}>\`
  })
<\/script>
`;
const vAppBar = {
  "misc-app-bar-nav": {
    component: __0,
    source: __0_raw
  },
  "misc-menu": {
    component: __1,
    source: __1_raw
  },
  "prop-dense": {
    component: __2,
    source: __2_raw
  },
  "prop-density": {
    component: __3,
    source: __3_raw
  },
  "prop-image": {
    component: __4,
    source: __4_raw
  },
  "prop-prominent": {
    component: __5,
    source: __5_raw
  },
  "prop-scroll-behavior": {
    component: __6,
    source: __6_raw
  },
  "usage": {
    component: __7,
    source: __7_raw
  }
};
export {
  vAppBar as default
};
