import { r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, l as createElementBlock, F as Fragment, v as renderList, b as createVNode, e as createBaseVNode, t as toDisplayString, q as createCommentVNode, h as createTextVNode, a9 as mergeProps, y as _export_sfc, J as ref, j as computed, ag as propsToString, f as unref, E as isRef } from "./index-DGybHjCP.js";
import { _ as _sfc_main$7 } from "./UsageExample-M8CmNipa.js";
const _hoisted_1$5 = ["innerHTML"];
const _hoisted_2$2 = {
  key: 0,
  class: "text-grey"
};
const _hoisted_3$1 = ["innerHTML"];
const lorem = "Lorem ipsum dolor sit amet, at aliquam vivendum vel, everti delicatissimi cu eos. Dico iuvaret debitis mel an, et cum zril menandri. Eum in consul legimus accusam. Ea dico abhorreant duo, quo illum minimum incorrupte no, nostro voluptaria sea eu. Suas eligendi ius at, at nemore equidem est. Sed in error hendrerit, in consul constituam cum.";
const _sfc_main$6 = {
  __name: "misc-advanced",
  setup(__props) {
    const messages = [
      {
        avatar: "https://avatars0.githubusercontent.com/u/9064066?v=4&s=460",
        name: "John Leider",
        title: "Welcome to Vuetify!",
        excerpt: "Thank you for joining our community..."
      },
      {
        color: "red",
        icon: "mdi-account-multiple",
        name: "Social",
        new: 1,
        total: 3,
        title: "Twitter"
      },
      {
        color: "teal",
        icon: "mdi-tag",
        name: "Promos",
        new: 2,
        total: 4,
        title: "Shop your way",
        exceprt: "New deals available, Join Today"
      }
    ];
    return (_ctx, _cache) => {
      const _component_v_img = resolveComponent("v-img");
      const _component_v_icon = resolveComponent("v-icon");
      const _component_v_avatar = resolveComponent("v-avatar");
      const _component_v_col = resolveComponent("v-col");
      const _component_v_chip = resolveComponent("v-chip");
      const _component_v_row = resolveComponent("v-row");
      const _component_v_expansion_panel_title = resolveComponent("v-expansion-panel-title");
      const _component_v_card_text = resolveComponent("v-card-text");
      const _component_v_expansion_panel_text = resolveComponent("v-expansion-panel-text");
      const _component_v_expansion_panel = resolveComponent("v-expansion-panel");
      const _component_v_expansion_panels = resolveComponent("v-expansion-panels");
      return openBlock(), createBlock(_component_v_expansion_panels, {
        class: "pa-4",
        variant: "popout"
      }, {
        default: withCtx(() => [
          (openBlock(), createElementBlock(Fragment, null, renderList(messages, (message, i) => {
            return createVNode(_component_v_expansion_panel, {
              key: i,
              "hide-actions": ""
            }, {
              default: withCtx(() => [
                createVNode(_component_v_expansion_panel_title, null, {
                  default: withCtx(() => [
                    createVNode(_component_v_row, {
                      align: "center",
                      class: "spacer",
                      "no-gutters": ""
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_v_col, {
                          cols: "4",
                          md: "1",
                          sm: "2"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_v_avatar, { size: "36px" }, {
                              default: withCtx(() => [
                                message.avatar ? (openBlock(), createBlock(_component_v_img, {
                                  key: 0,
                                  alt: "Avatar",
                                  src: "https://avatars0.githubusercontent.com/u/9064066?v=4&s=460"
                                })) : (openBlock(), createBlock(_component_v_icon, {
                                  key: 1,
                                  color: message.color,
                                  icon: message.icon
                                }, null, 8, ["color", "icon"]))
                              ]),
                              _: 2
                            }, 1024)
                          ]),
                          _: 2
                        }, 1024),
                        createVNode(_component_v_col, {
                          class: "hidden-xs-only text-left ms-2",
                          md: "3",
                          sm: "5"
                        }, {
                          default: withCtx(() => [
                            createBaseVNode("strong", {
                              innerHTML: message.name
                            }, null, 8, _hoisted_1$5),
                            message.total ? (openBlock(), createElementBlock("span", _hoisted_2$2, "  (" + toDisplayString(message.total) + ") ", 1)) : createCommentVNode("", true)
                          ]),
                          _: 2
                        }, 1024),
                        createVNode(_component_v_col, {
                          class: "text-no-wrap text-left",
                          cols: "5",
                          sm: "3"
                        }, {
                          default: withCtx(() => [
                            message.new ? (openBlock(), createBlock(_component_v_chip, {
                              key: 0,
                              color: `${message.color}-lighten-1`,
                              class: "ms-0 me-2",
                              label: "",
                              small: ""
                            }, {
                              default: withCtx(() => [
                                createTextVNode(toDisplayString(message.new) + " new ", 1)
                              ]),
                              _: 2
                            }, 1032, ["color"])) : createCommentVNode("", true),
                            createBaseVNode("strong", {
                              innerHTML: message.title
                            }, null, 8, _hoisted_3$1)
                          ]),
                          _: 2
                        }, 1024),
                        message.excerpt ? (openBlock(), createBlock(_component_v_col, {
                          key: 0,
                          class: "text-medium-emphasis text-truncate hidden-sm-and-down"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" — " + toDisplayString(message.excerpt), 1)
                          ]),
                          _: 2
                        }, 1024)) : createCommentVNode("", true)
                      ]),
                      _: 2
                    }, 1024)
                  ]),
                  _: 2
                }, 1024),
                createVNode(_component_v_expansion_panel_text, null, {
                  default: withCtx(() => [
                    createVNode(_component_v_card_text, { textContent: lorem })
                  ]),
                  _: 1
                })
              ]),
              _: 2
            }, 1024);
          }), 64))
        ]),
        _: 1
      });
    };
  }
};
const __0 = _sfc_main$6;
const __0_raw = `<template>
  <v-expansion-panels class="pa-4" variant="popout">
    <v-expansion-panel
      v-for="(message, i) in messages"
      :key="i"
      hide-actions
    >
      <v-expansion-panel-title>
        <v-row
          align="center"
          class="spacer"
          no-gutters
        >
          <v-col
            cols="4"
            md="1"
            sm="2"
          >
            <v-avatar
              size="36px"
            >
              <v-img
                v-if="message.avatar"
                alt="Avatar"
                src="https://avatars0.githubusercontent.com/u/9064066?v=4&s=460"
              ></v-img>
              <v-icon
                v-else
                :color="message.color"
                :icon="message.icon"
              ></v-icon>
            </v-avatar>
          </v-col>

          <v-col
            class="hidden-xs-only text-left ms-2"
            md="3"
            sm="5"
          >
            <strong v-html="message.name"></strong>
            <span
              v-if="message.total"
              class="text-grey"
            >
              &nbsp;({{ message.total }})
            </span>
          </v-col>

          <v-col
            class="text-no-wrap text-left"
            cols="5"
            sm="3"
          >
            <v-chip
              v-if="message.new"
              :color="\`\${message.color}-lighten-1\`"
              class="ms-0 me-2"
              label
              small
            >
              {{ message.new }} new
            </v-chip>
            <strong v-html="message.title"></strong>
          </v-col>

          <v-col
            v-if="message.excerpt"
            class="text-medium-emphasis text-truncate hidden-sm-and-down"
          >
            &mdash;
            {{ message.excerpt }}
          </v-col>
        </v-row>
      </v-expansion-panel-title>

      <v-expansion-panel-text>
        <v-card-text v-text="lorem"></v-card-text>
      </v-expansion-panel-text>
    </v-expansion-panel>
  </v-expansion-panels>
</template>

<script setup>
  const messages = [
    {
      avatar: 'https://avatars0.githubusercontent.com/u/9064066?v=4&s=460',
      name: 'John Leider',
      title: 'Welcome to Vuetify!',
      excerpt: 'Thank you for joining our community...',
    },
    {
      color: 'red',
      icon: 'mdi-account-multiple',
      name: 'Social',
      new: 1,
      total: 3,
      title: 'Twitter',
    },
    {
      color: 'teal',
      icon: 'mdi-tag',
      name: 'Promos',
      new: 2,
      total: 4,
      title: 'Shop your way',
      exceprt: 'New deals available, Join Today',
    },
  ]
  const lorem = 'Lorem ipsum dolor sit amet, at aliquam vivendum vel, everti delicatissimi cu eos. Dico iuvaret debitis mel an, et cum zril menandri. Eum in consul legimus accusam. Ea dico abhorreant duo, quo illum minimum incorrupte no, nostro voluptaria sea eu. Suas eligendi ius at, at nemore equidem est. Sed in error hendrerit, in consul constituam cum.'
<\/script>

<script>
  export default {
    data: () => ({
      messages: [
        {
          avatar: 'https://avatars0.githubusercontent.com/u/9064066?v=4&s=460',
          name: 'John Leider',
          title: 'Welcome to Vuetify!',
          excerpt: 'Thank you for joining our community...',
        },
        {
          color: 'red',
          icon: 'mdi-account-multiple',
          name: 'Social',
          new: 1,
          total: 3,
          title: 'Twitter',
        },
        {
          color: 'teal',
          icon: 'mdi-tag',
          name: 'Promos',
          new: 2,
          total: 4,
          title: 'Shop your way',
          exceprt: 'New deals available, Join Today',
        },
      ],
      lorem: 'Lorem ipsum dolor sit amet, at aliquam vivendum vel, everti delicatissimi cu eos. Dico iuvaret debitis mel an, et cum zril menandri. Eum in consul legimus accusam. Ea dico abhorreant duo, quo illum minimum incorrupte no, nostro voluptaria sea eu. Suas eligendi ius at, at nemore equidem est. Sed in error hendrerit, in consul constituam cum.',
    }),
  }
<\/script>
`;
const _hoisted_1$4 = { class: "text-h5" };
const _hoisted_2$1 = { class: "mx-auto text-center" };
const _hoisted_3 = { class: "text-h5" };
const _hoisted_4 = { class: "text-caption mt-1" };
const _sfc_main$5 = {
  __name: "misc-avatar-menu",
  setup(__props) {
    const user = {
      initials: "JD",
      fullName: "John Doe",
      email: "john.doe@doe.com"
    };
    return (_ctx, _cache) => {
      const _component_v_avatar = resolveComponent("v-avatar");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_divider = resolveComponent("v-divider");
      const _component_v_card_text = resolveComponent("v-card-text");
      const _component_v_card = resolveComponent("v-card");
      const _component_v_menu = resolveComponent("v-menu");
      const _component_v_row = resolveComponent("v-row");
      const _component_v_container = resolveComponent("v-container");
      return openBlock(), createBlock(_component_v_container, {
        style: { "height": "300px" },
        fluid: ""
      }, {
        default: withCtx(() => [
          createVNode(_component_v_row, { justify: "center" }, {
            default: withCtx(() => [
              createVNode(_component_v_menu, {
                "min-width": "200px",
                rounded: ""
              }, {
                activator: withCtx(({ props }) => [
                  createVNode(_component_v_btn, mergeProps({ icon: "" }, props), {
                    default: withCtx(() => [
                      createVNode(_component_v_avatar, {
                        color: "brown",
                        size: "large"
                      }, {
                        default: withCtx(() => [
                          createBaseVNode("span", _hoisted_1$4, toDisplayString(user.initials), 1)
                        ]),
                        _: 1
                      })
                    ]),
                    _: 2
                  }, 1040)
                ]),
                default: withCtx(() => [
                  createVNode(_component_v_card, null, {
                    default: withCtx(() => [
                      createVNode(_component_v_card_text, null, {
                        default: withCtx(() => [
                          createBaseVNode("div", _hoisted_2$1, [
                            createVNode(_component_v_avatar, { color: "brown" }, {
                              default: withCtx(() => [
                                createBaseVNode("span", _hoisted_3, toDisplayString(user.initials), 1)
                              ]),
                              _: 1
                            }),
                            createBaseVNode("h3", null, toDisplayString(user.fullName), 1),
                            createBaseVNode("p", _hoisted_4, toDisplayString(user.email), 1),
                            createVNode(_component_v_divider, { class: "my-3" }),
                            createVNode(_component_v_btn, {
                              variant: "text",
                              rounded: ""
                            }, {
                              default: withCtx(() => [
                                createTextVNode(" Edit Account ")
                              ]),
                              _: 1
                            }),
                            createVNode(_component_v_divider, { class: "my-3" }),
                            createVNode(_component_v_btn, {
                              variant: "text",
                              rounded: ""
                            }, {
                              default: withCtx(() => [
                                createTextVNode(" Disconnect ")
                              ]),
                              _: 1
                            })
                          ])
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __1 = _sfc_main$5;
const __1_raw = `<template>
  <v-container
    style="height: 300px"
    fluid
  >
    <v-row justify="center">
      <v-menu
        min-width="200px"
        rounded
      >
        <template v-slot:activator="{ props }">
          <v-btn
            icon
            v-bind="props"
          >
            <v-avatar
              color="brown"
              size="large"
            >
              <span class="text-h5">{{ user.initials }}</span>
            </v-avatar>
          </v-btn>
        </template>
        <v-card>
          <v-card-text>
            <div class="mx-auto text-center">
              <v-avatar
                color="brown"
              >
                <span class="text-h5">{{ user.initials }}</span>
              </v-avatar>
              <h3>{{ user.fullName }}</h3>
              <p class="text-caption mt-1">
                {{ user.email }}
              </p>
              <v-divider class="my-3"></v-divider>
              <v-btn
                variant="text"
                rounded
              >
                Edit Account
              </v-btn>
              <v-divider class="my-3"></v-divider>
              <v-btn
                variant="text"
                rounded
              >
                Disconnect
              </v-btn>
            </div>
          </v-card-text>
        </v-card>
      </v-menu>
    </v-row>
  </v-container>
</template>

<script setup>
  const user = {
    initials: 'JD',
    fullName: 'John Doe',
    email: 'john.doe@doe.com',
  }
<\/script>

<script>
  export default {
    data: () => ({
      user: {
        initials: 'JD',
        fullName: 'John Doe',
        email: 'john.doe@doe.com',
      },
    }),
  }
<\/script>
`;
const _sfc_main$4 = {};
function _sfc_render$3(_ctx, _cache) {
  const _component_v_img = resolveComponent("v-img");
  const _component_v_avatar = resolveComponent("v-avatar");
  const _component_v_list_item = resolveComponent("v-list-item");
  const _component_v_card = resolveComponent("v-card");
  return openBlock(), createBlock(_component_v_card, {
    class: "mx-auto",
    "max-width": "434",
    rounded: "0"
  }, {
    default: withCtx(() => [
      createVNode(_component_v_img, {
        height: "100%",
        src: "https://cdn.vuetifyjs.com/images/cards/server-room.jpg",
        cover: ""
      }, {
        default: withCtx(() => [
          createVNode(_component_v_avatar, {
            color: "grey",
            rounded: "0",
            size: "150"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_img, {
                src: "https://cdn.vuetifyjs.com/images/profiles/marcus.jpg",
                cover: ""
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_list_item, {
            class: "text-white",
            subtitle: "Network Engineer",
            title: "Marcus Obrien"
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __2 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["render", _sfc_render$3]]);
const __2_raw = '<template>\n  <v-card\n    class="mx-auto"\n    max-width="434"\n    rounded="0"\n  >\n    <v-img\n      height="100%"\n      src="https://cdn.vuetifyjs.com/images/cards/server-room.jpg"\n      cover\n    >\n      <v-avatar\n        color="grey"\n        rounded="0"\n        size="150"\n      >\n        <v-img src="https://cdn.vuetifyjs.com/images/profiles/marcus.jpg" cover></v-img>\n      </v-avatar>\n      <v-list-item\n        class="text-white"\n        subtitle="Network Engineer"\n        title="Marcus Obrien"\n      ></v-list-item>\n    </v-img>\n  </v-card>\n</template>\n';
const _sfc_main$3 = {};
const _hoisted_1$3 = { class: "d-flex align-center justify-space-around" };
function _sfc_render$2(_ctx, _cache) {
  const _component_v_avatar = resolveComponent("v-avatar");
  return openBlock(), createElementBlock("div", _hoisted_1$3, [
    createVNode(_component_v_avatar, {
      color: "primary",
      size: "x-small"
    }, {
      default: withCtx(() => [
        createTextVNode(" 32 ")
      ]),
      _: 1
    }),
    createVNode(_component_v_avatar, { color: "secondary" }, {
      default: withCtx(() => [
        createTextVNode(" 48 ")
      ]),
      _: 1
    }),
    createVNode(_component_v_avatar, {
      color: "info",
      size: "x-large"
    }, {
      default: withCtx(() => [
        createTextVNode(" 64 ")
      ]),
      _: 1
    })
  ]);
}
const __3 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["render", _sfc_render$2]]);
const __3_raw = '<template>\n  <div class="d-flex align-center justify-space-around">\n    <v-avatar color="primary" size="x-small">\n      32\n    </v-avatar>\n\n    <v-avatar color="secondary">\n      48\n    </v-avatar>\n\n    <v-avatar color="info" size="x-large">\n      64\n    </v-avatar>\n  </div>\n</template>\n';
const _sfc_main$2 = {};
const _hoisted_1$2 = { class: "text-center" };
function _sfc_render$1(_ctx, _cache) {
  const _component_v_icon = resolveComponent("v-icon");
  const _component_v_avatar = resolveComponent("v-avatar");
  return openBlock(), createElementBlock("div", _hoisted_1$2, [
    createVNode(_component_v_avatar, {
      color: "blue-darken-2",
      rounded: "0"
    }, {
      default: withCtx(() => [
        createVNode(_component_v_icon, { icon: "mdi-alarm" })
      ]),
      _: 1
    })
  ]);
}
const __4 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["render", _sfc_render$1]]);
const __4_raw = '<template>\n  <div class="text-center">\n    <v-avatar\n      color="blue-darken-2"\n      rounded="0"\n    >\n      <v-icon icon="mdi-alarm"></v-icon>\n    </v-avatar>\n  </div>\n</template>\n';
const _sfc_main$1 = {};
const _hoisted_1$1 = { class: "d-flex align-center justify-space-around" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("span", { class: "text-h5" }, "CJ", -1);
function _sfc_render(_ctx, _cache) {
  const _component_v_icon = resolveComponent("v-icon");
  const _component_v_avatar = resolveComponent("v-avatar");
  const _component_v_img = resolveComponent("v-img");
  return openBlock(), createElementBlock("div", _hoisted_1$1, [
    createVNode(_component_v_avatar, { color: "info" }, {
      default: withCtx(() => [
        createVNode(_component_v_icon, { icon: "mdi-account-circle" })
      ]),
      _: 1
    }),
    createVNode(_component_v_avatar, null, {
      default: withCtx(() => [
        createVNode(_component_v_img, {
          alt: "John",
          src: "https://cdn.vuetifyjs.com/images/john.jpg"
        })
      ]),
      _: 1
    }),
    createVNode(_component_v_avatar, { color: "red" }, {
      default: withCtx(() => [
        _hoisted_2
      ]),
      _: 1
    })
  ]);
}
const __5 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["render", _sfc_render]]);
const __5_raw = '<template>\n  <div class="d-flex align-center justify-space-around">\n    <v-avatar color="info">\n      <v-icon icon="mdi-account-circle"></v-icon>\n    </v-avatar>\n\n    <v-avatar>\n      <v-img\n        alt="John"\n        src="https://cdn.vuetifyjs.com/images/john.jpg"\n      ></v-img>\n    </v-avatar>\n\n    <v-avatar color="red">\n      <span class="text-h5">CJ</span>\n    </v-avatar>\n  </div>\n</template>\n';
const _hoisted_1 = { class: "text-center" };
const _sfc_main = {
  __name: "usage",
  setup(__props) {
    const model = ref("default");
    const icon = ref(false);
    const image = ref(false);
    const size = ref(40);
    const options = ["tile"];
    const props = computed(() => {
      return {
        color: !image.value && !icon.value ? "surface-variant" : void 0,
        icon: icon.value ? "$vuetify" : void 0,
        image: image.value ? "smirk.png" : void 0,
        rounded: model.value === "tile" ? "0" : void 0,
        size: size.value === 40 ? void 0 : `${size.value}`
      };
    });
    const slots = computed(() => {
      return "";
    });
    const code = computed(() => {
      return `<v-avatar${propsToString(props.value)}>${slots.value}</v-avatar>`;
    });
    return (_ctx, _cache) => {
      const _component_v_avatar = resolveComponent("v-avatar");
      const _component_v_checkbox = resolveComponent("v-checkbox");
      const _component_v_slider = resolveComponent("v-slider");
      const _component_ExamplesUsageExample = _sfc_main$7;
      return openBlock(), createBlock(_component_ExamplesUsageExample, {
        modelValue: unref(model),
        "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => isRef(model) ? model.value = $event : null),
        code: unref(code),
        options,
        name: "v-avatar"
      }, {
        configuration: withCtx(() => [
          createVNode(_component_v_checkbox, {
            modelValue: unref(icon),
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(icon) ? icon.value = $event : null),
            label: "Icon"
          }, null, 8, ["modelValue"]),
          createVNode(_component_v_checkbox, {
            modelValue: unref(image),
            "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(image) ? image.value = $event : null),
            label: "Image"
          }, null, 8, ["modelValue"]),
          createVNode(_component_v_slider, {
            modelValue: unref(size),
            "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => isRef(size) ? size.value = $event : null),
            label: "Size",
            max: "80",
            min: "40",
            step: "1"
          }, null, 8, ["modelValue"])
        ]),
        default: withCtx(() => [
          createBaseVNode("div", _hoisted_1, [
            createVNode(_component_v_avatar, mergeProps(unref(props), {
              image: unref(image) ? "https://cdn.vuetifyjs.com/images/john-smirk.png" : void 0
            }), null, 16, ["image"])
          ])
        ]),
        _: 1
      }, 8, ["modelValue", "code"]);
    };
  }
};
const __6 = _sfc_main;
const __6_raw = `<template>
  <ExamplesUsageExample
    v-model="model"
    :code="code"
    :options="options"
    name="v-avatar"
  >
    <div class="text-center">
      <v-avatar
        v-bind="props"
        :image="image ? 'https://cdn.vuetifyjs.com/images/john-smirk.png' : undefined"
      ></v-avatar>
    </div>

    <template v-slot:configuration>
      <v-checkbox v-model="icon" label="Icon"></v-checkbox>

      <v-checkbox v-model="image" label="Image"></v-checkbox>

      <v-slider
        v-model="size"
        label="Size"
        max="80"
        min="40"
        step="1"
      ></v-slider>
    </template>
  </ExamplesUsageExample>
</template>

<script setup>
  const model = ref('default')
  const icon = ref(false)
  const image = ref(false)
  const size = ref(40)
  const options = ['tile']
  const props = computed(() => {
    return {
      color: !image.value && !icon.value ? 'surface-variant' : undefined,
      icon: icon.value ? '$vuetify' : undefined,
      image: image.value ? 'smirk.png' : undefined,
      rounded: model.value === 'tile' ? '0' : undefined,
      size: size.value === 40 ? undefined : \`\${size.value}\`,
    }
  })

  const slots = computed(() => {
    return ''
  })

  const code = computed(() => {
    return \`<v-avatar\${propsToString(props.value)}>\${slots.value}</v-avatar>\`
  })
<\/script>
`;
const vAvatar = {
  "misc-advanced": {
    component: __0,
    source: __0_raw
  },
  "misc-avatar-menu": {
    component: __1,
    source: __1_raw
  },
  "misc-profile-card": {
    component: __2,
    source: __2_raw
  },
  "prop-size": {
    component: __3,
    source: __3_raw
  },
  "prop-tile": {
    component: __4,
    source: __4_raw
  },
  "slot-default": {
    component: __5,
    source: __5_raw
  },
  "usage": {
    component: __6,
    source: __6_raw
  }
};
export {
  vAvatar as default
};
