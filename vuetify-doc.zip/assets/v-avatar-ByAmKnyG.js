import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "vavatar-api" };
const _hoisted_2 = { id: "links" };
const _hoisted_3 = { id: "props" };
const _hoisted_4 = { id: "slots" };
const _hoisted_5 = { id: "sass" };
const frontmatter = { "meta": { "title": "VAvatar API", "description": "API for the VAvatar component.", "keywords": "VAvatar, api, vuetify" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "v-avatar",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "VAvatar API", "description": "API for the VAvatar component.", "keywords": "VAvatar, api, vuetify" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "title": "VAvatar API", "description": "API for the VAvatar component.", "keywords": "VAvatar, api, vuetify" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_app_link = resolveComponent("app-link");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_api_search = resolveComponent("api-search");
      const _component_api_section = resolveComponent("api-section");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#vavatar-api",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("VAvatar API")
                ]),
                _: 1
              }),
              createVNode(_component_page_features),
              createBaseVNode("ul", null, [
                createBaseVNode("li", null, [
                  createVNode(_component_app_link, { href: "/components/avatars" }, {
                    default: withCtx(() => [
                      createTextVNode("Avatars")
                    ]),
                    _: 1
                  })
                ])
              ]),
              createBaseVNode("section", _hoisted_2, [
                createVNode(_component_app_heading, {
                  href: "#links",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Component Pages")
                  ]),
                  _: 1
                }),
                createVNode(_component_promoted_entry),
                createVNode(_component_api_search)
              ]),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#props",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Props")
                  ]),
                  _: 1
                }),
                createVNode(_component_api_section, {
                  name: "VAvatar",
                  section: "props"
                })
              ]),
              createBaseVNode("section", _hoisted_4, [
                createVNode(_component_app_heading, {
                  href: "#slots",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Slots")
                  ]),
                  _: 1
                }),
                createVNode(_component_api_section, {
                  name: "VAvatar",
                  section: "slots"
                })
              ]),
              createBaseVNode("section", _hoisted_5, [
                createVNode(_component_app_heading, {
                  href: "#sass",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("SASS Variables")
                  ]),
                  _: 1
                }),
                createVNode(_component_api_section, {
                  name: "VAvatar",
                  section: "sass"
                })
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
