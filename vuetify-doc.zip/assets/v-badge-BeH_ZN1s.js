import { y as _export_sfc, r as resolveComponent, o as openBlock, l as createElementBlock, b as createVNode, w as withCtx, h as createTextVNode, e as createBaseVNode, J as ref, c as createBlock, a9 as mergeProps, j as computed, ag as propsToString, f as unref, E as isRef, ak as normalizeProps, al as guardReactiveProps } from "./index-DGybHjCP.js";
import { _ as _sfc_main$8 } from "./UsageExample-M8CmNipa.js";
const _sfc_main$7 = {};
const _hoisted_1$2 = { class: "d-flex justify-space-around align-center flex-column flex-md-row fill-height" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("div", { class: "mx-3" }, null, -1);
function _sfc_render$4(_ctx, _cache) {
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_badge = resolveComponent("v-badge");
  const _component_v_img = resolveComponent("v-img");
  const _component_v_avatar = resolveComponent("v-avatar");
  return openBlock(), createElementBlock("div", _hoisted_1$2, [
    createVNode(_component_v_badge, {
      color: "error",
      icon: "mdi-lock",
      bordered: ""
    }, {
      default: withCtx(() => [
        createVNode(_component_v_btn, {
          color: "error",
          variant: "flat"
        }, {
          default: withCtx(() => [
            createTextVNode(" Lock Account ")
          ]),
          _: 1
        })
      ]),
      _: 1
    }),
    createVNode(_component_v_badge, {
      color: "deep-purple-accent-4",
      location: "bottom end",
      "offset-x": "2",
      "offset-y": "4",
      bordered: "",
      dot: ""
    }, {
      default: withCtx(() => [
        createVNode(_component_v_avatar, { size: "large" }, {
          default: withCtx(() => [
            createVNode(_component_v_img, { src: "https://cdn.vuetifyjs.com/images/lists/2.jpg" })
          ]),
          _: 1
        })
      ]),
      _: 1
    }),
    _hoisted_2,
    createVNode(_component_v_badge, { bordered: "" }, {
      badge: withCtx(() => [
        createVNode(_component_v_avatar, { size: "x-small" }, {
          default: withCtx(() => [
            createVNode(_component_v_img, { src: "https://cdn.vuetifyjs.com/images/logos/v.png" })
          ]),
          _: 1
        })
      ]),
      default: withCtx(() => [
        createVNode(_component_v_avatar, { size: "large" }, {
          default: withCtx(() => [
            createVNode(_component_v_img, { src: "https://cdn.vuetifyjs.com/images/john.png" })
          ]),
          _: 1
        })
      ]),
      _: 1
    })
  ]);
}
const __0 = /* @__PURE__ */ _export_sfc(_sfc_main$7, [["render", _sfc_render$4]]);
const __0_raw = '<template>\n  <div class="d-flex justify-space-around align-center flex-column flex-md-row fill-height">\n    <v-badge\n      color="error"\n      icon="mdi-lock"\n      bordered\n    >\n      <v-btn\n        color="error"\n        variant="flat"\n      >\n        Lock Account\n      </v-btn>\n    </v-badge>\n\n    <v-badge\n      color="deep-purple-accent-4"\n      location="bottom end"\n      offset-x="2"\n      offset-y="4"\n      bordered\n      dot\n    >\n      <v-avatar size="large">\n        <v-img src="https://cdn.vuetifyjs.com/images/lists/2.jpg"></v-img>\n      </v-avatar>\n    </v-badge>\n\n    <div class="mx-3"></div>\n\n    <v-badge\n      bordered\n    >\n      <template v-slot:badge>\n        <v-avatar size="x-small">\n          <v-img src="https://cdn.vuetifyjs.com/images/logos/v.png"></v-img>\n        </v-avatar>\n      </template>\n\n      <v-avatar size="large">\n        <v-img src="https://cdn.vuetifyjs.com/images/john.png"></v-img>\n      </v-avatar>\n    </v-badge>\n  </div>\n</template>\n';
const _sfc_main$6 = {
  __name: "misc-dynamic",
  setup(__props) {
    const messages = ref(0);
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_icon = resolveComponent("v-icon");
      const _component_v_badge = resolveComponent("v-badge");
      const _component_v_row = resolveComponent("v-row");
      const _component_v_container = resolveComponent("v-container");
      return openBlock(), createBlock(_component_v_container, null, {
        default: withCtx(() => [
          createVNode(_component_v_row, { justify: "space-around" }, {
            default: withCtx(() => [
              createBaseVNode("div", null, [
                createVNode(_component_v_btn, {
                  class: "mx-1",
                  color: "primary",
                  onClick: _cache[0] || (_cache[0] = ($event) => messages.value++)
                }, {
                  default: withCtx(() => [
                    createTextVNode(" Send Message ")
                  ]),
                  _: 1
                }),
                createVNode(_component_v_btn, {
                  class: "mx-1",
                  color: "error",
                  onClick: _cache[1] || (_cache[1] = ($event) => messages.value = 0)
                }, {
                  default: withCtx(() => [
                    createTextVNode(" Clear Notifications ")
                  ]),
                  _: 1
                })
              ]),
              createVNode(_component_v_badge, {
                content: messages.value,
                "model-value": !!messages.value,
                color: "green"
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_icon, { size: "large" }, {
                    default: withCtx(() => [
                      createTextVNode(" $vuetify ")
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }, 8, ["content", "model-value"])
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __1 = _sfc_main$6;
const __1_raw = `<template>
  <v-container>
    <v-row justify="space-around">
      <div>
        <v-btn
          class="mx-1"
          color="primary"
          @click="messages++"
        >
          Send Message
        </v-btn>

        <v-btn
          class="mx-1"
          color="error"
          @click="messages = 0"
        >
          Clear Notifications
        </v-btn>
      </div>

      <v-badge
        :content="messages"
        :model-value="!!messages"
        color="green"
      >
        <v-icon size="large">
          $vuetify
        </v-icon>
      </v-badge>
    </v-row>
  </v-container>
</template>

<script setup>
  import { ref } from 'vue'

  const messages = ref(0)
<\/script>

<script>
  export default {
    data () {
      return {
        messages: 0,
      }
    },
  }
<\/script>
`;
const _hoisted_1$1 = { class: "text-center" };
const _sfc_main$5 = {
  __name: "misc-hover",
  setup(__props) {
    const hover = ref(false);
    return (_ctx, _cache) => {
      const _component_v_icon = resolveComponent("v-icon");
      const _component_v_hover = resolveComponent("v-hover");
      const _component_v_badge = resolveComponent("v-badge");
      return openBlock(), createElementBlock("div", _hoisted_1$1, [
        createVNode(_component_v_badge, {
          "model-value": hover.value,
          color: "deep-purple",
          content: "9999+",
          location: "top-end",
          transition: "slide-x-transition"
        }, {
          default: withCtx(() => [
            createVNode(_component_v_hover, {
              modelValue: hover.value,
              "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => hover.value = $event)
            }, {
              default: withCtx(({ props }) => [
                createVNode(_component_v_icon, mergeProps({
                  color: "grey-lighten-1",
                  size: "large"
                }, props), {
                  default: withCtx(() => [
                    createTextVNode(" mdi-account ")
                  ]),
                  _: 2
                }, 1040)
              ]),
              _: 1
            }, 8, ["modelValue"])
          ]),
          _: 1
        }, 8, ["model-value"])
      ]);
    };
  }
};
const __2 = _sfc_main$5;
const __2_raw = `<template>
  <div class="text-center">
    <v-badge
      :model-value="hover"
      color="deep-purple"
      content="9999+"
      location="top-end"
      transition="slide-x-transition"
    >
      <v-hover v-slot="{ props }" v-model="hover">
        <v-icon
          color="grey-lighten-1"
          size="large"
          v-bind="props"
        >
          mdi-account
        </v-icon>
      </v-hover>
    </v-badge>
  </div>
</template>

<script setup>
  import { ref } from 'vue'

  const hover = ref(false)
<\/script>

<script>
  export default {
    data: () => ({
      hover: false,
    }),
  }
<\/script>
`;
const _sfc_main$4 = {};
function _sfc_render$3(_ctx, _cache) {
  const _component_v_badge = resolveComponent("v-badge");
  const _component_v_tab = resolveComponent("v-tab");
  const _component_v_tabs = resolveComponent("v-tabs");
  return openBlock(), createBlock(_component_v_tabs, {
    "bg-color": "primary",
    grow: ""
  }, {
    default: withCtx(() => [
      createVNode(_component_v_tab, null, {
        default: withCtx(() => [
          createVNode(_component_v_badge, {
            color: "pink",
            dot: ""
          }, {
            default: withCtx(() => [
              createTextVNode(" Item One ")
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_tab, null, {
        default: withCtx(() => [
          createVNode(_component_v_badge, {
            color: "green",
            content: "6"
          }, {
            default: withCtx(() => [
              createTextVNode(" Item Two ")
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_tab, null, {
        default: withCtx(() => [
          createVNode(_component_v_badge, {
            color: "deep-purple-accent-4",
            icon: "$vuetify"
          }, {
            default: withCtx(() => [
              createTextVNode(" Item Three ")
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __3 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["render", _sfc_render$3]]);
const __3_raw = '<template>\n  <v-tabs\n    bg-color="primary"\n    grow\n  >\n    <v-tab>\n      <v-badge\n        color="pink"\n        dot\n      >\n        Item One\n      </v-badge>\n    </v-tab>\n\n    <v-tab>\n      <v-badge\n        color="green"\n        content="6"\n      >\n        Item Two\n      </v-badge>\n    </v-tab>\n\n    <v-tab>\n      <v-badge\n        color="deep-purple-accent-4"\n        icon="$vuetify"\n      >\n        Item Three\n      </v-badge>\n    </v-tab>\n  </v-tabs>\n</template>\n';
const _sfc_main$3 = {};
function _sfc_render$2(_ctx, _cache) {
  const _component_v_spacer = resolveComponent("v-spacer");
  const _component_v_icon = resolveComponent("v-icon");
  const _component_v_badge = resolveComponent("v-badge");
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_toolbar = resolveComponent("v-toolbar");
  return openBlock(), createBlock(_component_v_toolbar, { color: "blue-grey-darken-3" }, {
    default: withCtx(() => [
      createVNode(_component_v_spacer),
      createVNode(_component_v_btn, {
        class: "text-none",
        stacked: ""
      }, {
        default: withCtx(() => [
          createVNode(_component_v_badge, {
            color: "success",
            dot: ""
          }, {
            default: withCtx(() => [
              createVNode(_component_v_icon, null, {
                default: withCtx(() => [
                  createTextVNode("mdi-home-outline")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_btn, {
        class: "text-none",
        stacked: ""
      }, {
        default: withCtx(() => [
          createVNode(_component_v_icon, null, {
            default: withCtx(() => [
              createTextVNode("mdi-account-multiple-outline")
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_btn, {
        class: "text-none",
        stacked: ""
      }, {
        default: withCtx(() => [
          createVNode(_component_v_badge, {
            color: "error",
            content: "9+"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_icon, null, {
                default: withCtx(() => [
                  createTextVNode("mdi-store-outline")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_btn, {
        class: "text-none",
        stacked: ""
      }, {
        default: withCtx(() => [
          createVNode(_component_v_badge, {
            color: "error",
            content: "2"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_icon, null, {
                default: withCtx(() => [
                  createTextVNode("mdi-bell-outline")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_btn, {
        class: "text-none",
        stacked: ""
      }, {
        default: withCtx(() => [
          createVNode(_component_v_icon, null, {
            default: withCtx(() => [
              createTextVNode("mdi-menu")
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_spacer)
    ]),
    _: 1
  });
}
const __4 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["render", _sfc_render$2]]);
const __4_raw = '<template>\n  <v-toolbar color="blue-grey-darken-3">\n    <v-spacer></v-spacer>\n\n    <v-btn class="text-none" stacked>\n      <v-badge color="success" dot>\n        <v-icon>mdi-home-outline</v-icon>\n      </v-badge>\n    </v-btn>\n\n    <v-btn class="text-none" stacked>\n      <v-icon>mdi-account-multiple-outline</v-icon>\n    </v-btn>\n\n    <v-btn class="text-none" stacked>\n      <v-badge color="error" content="9+">\n        <v-icon>mdi-store-outline</v-icon>\n      </v-badge>\n    </v-btn>\n\n    <v-btn class="text-none" stacked>\n      <v-badge color="error" content="2">\n        <v-icon>mdi-bell-outline</v-icon>\n      </v-badge>\n    </v-btn>\n\n    <v-btn class="text-none" stacked>\n      <v-icon>mdi-menu</v-icon>\n    </v-btn>\n\n    <v-spacer></v-spacer>\n  </v-toolbar>\n</template>\n';
const _sfc_main$2 = {};
function _sfc_render$1(_ctx, _cache) {
  const _component_v_icon = resolveComponent("v-icon");
  const _component_v_badge = resolveComponent("v-badge");
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_toolbar = resolveComponent("v-toolbar");
  return openBlock(), createBlock(_component_v_toolbar, {
    color: "grey-lighten-3",
    title: "Application"
  }, {
    default: withCtx(() => [
      createVNode(_component_v_btn, { stacked: "" }, {
        default: withCtx(() => [
          createVNode(_component_v_badge, {
            color: "error",
            dot: ""
          }, {
            default: withCtx(() => [
              createVNode(_component_v_icon, { icon: "mdi-newspaper-variant-outline" })
            ]),
            _: 1
          }),
          createTextVNode(" News ")
        ]),
        _: 1
      }),
      createVNode(_component_v_btn, { stacked: "" }, {
        default: withCtx(() => [
          createVNode(_component_v_badge, {
            color: "error",
            dot: ""
          }, {
            default: withCtx(() => [
              createVNode(_component_v_icon, { icon: "mdi-post" })
            ]),
            _: 1
          }),
          createTextVNode(" Blog ")
        ]),
        _: 1
      }),
      createVNode(_component_v_btn, {
        variant: "tonal",
        stacked: ""
      }, {
        default: withCtx(() => [
          createVNode(_component_v_icon, { icon: "mdi-login" }),
          createTextVNode(" Login ")
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __5 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["render", _sfc_render$1]]);
const __5_raw = '<template>\n  <v-toolbar color="grey-lighten-3" title="Application">\n    <v-btn stacked>\n      <v-badge\n        color="error"\n        dot\n      >\n        <v-icon icon="mdi-newspaper-variant-outline"></v-icon>\n      </v-badge>\n\n      News\n    </v-btn>\n\n    <v-btn stacked>\n      <v-badge\n        color="error"\n        dot\n      >\n        <v-icon icon="mdi-post"></v-icon>\n      </v-badge>\n\n      Blog\n    </v-btn>\n\n    <v-btn\n      variant="tonal"\n      stacked\n    >\n      <v-icon icon="mdi-login"></v-icon>\n\n      Login\n    </v-btn>\n  </v-toolbar>\n</template>\n';
const _sfc_main$1 = {};
function _sfc_render(_ctx, _cache) {
  const _component_v_badge = resolveComponent("v-badge");
  const _component_v_list_item = resolveComponent("v-list-item");
  const _component_v_list = resolveComponent("v-list");
  return openBlock(), createBlock(_component_v_list, {
    class: "mx-auto",
    "max-width": "256",
    border: ""
  }, {
    default: withCtx(() => [
      createVNode(_component_v_list_item, {
        "prepend-icon": "mdi-inbox-arrow-down",
        title: "Inbox",
        link: ""
      }, {
        append: withCtx(() => [
          createVNode(_component_v_badge, {
            color: "error",
            content: "6",
            inline: ""
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_list_item, {
        "prepend-icon": "mdi-send",
        title: "Sent Mail",
        link: ""
      }),
      createVNode(_component_v_list_item, {
        "prepend-icon": "mdi-delete",
        title: "Trash",
        link: ""
      }, {
        append: withCtx(() => [
          createVNode(_component_v_badge, {
            color: "info",
            content: "12",
            inline: ""
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_list_item, {
        "prepend-icon": "mdi-alert-circle",
        title: "Spam",
        link: ""
      })
    ]),
    _: 1
  });
}
const __6 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["render", _sfc_render]]);
const __6_raw = '<template>\n  <v-list\n    class="mx-auto"\n    max-width="256"\n    border\n  >\n    <v-list-item\n      prepend-icon="mdi-inbox-arrow-down"\n      title="Inbox"\n      link\n    >\n      <template v-slot:append>\n        <v-badge\n          color="error"\n          content="6"\n          inline\n        ></v-badge>\n      </template>\n    </v-list-item>\n\n    <v-list-item\n      prepend-icon="mdi-send"\n      title="Sent Mail"\n      link\n    ></v-list-item>\n\n    <v-list-item\n      prepend-icon="mdi-delete"\n      title="Trash"\n      link\n    >\n      <template v-slot:append>\n        <v-badge\n          color="info"\n          content="12"\n          inline\n        ></v-badge>\n      </template>\n    </v-list-item>\n\n    <v-list-item\n      prepend-icon="mdi-alert-circle"\n      title="Spam"\n      link\n    ></v-list-item>\n  </v-list>\n</template>\n';
const _hoisted_1 = { class: "text-center" };
const name = "v-badge";
const _sfc_main = {
  __name: "usage",
  setup(__props) {
    const model = ref("default");
    const content = ref(0);
    const dot = ref(false);
    const options = ["floating", "inline"];
    const props = computed(() => {
      return {
        content: content.value || void 0,
        dot: dot.value || void 0,
        floating: model.value === "floating" || void 0,
        inline: model.value === "inline" || void 0
      };
    });
    const slots = computed(() => {
      return `
  <v-icon icon="$vuetify" size="x-large"></v-icon>
`;
    });
    const code = computed(() => {
      return `<${name}${propsToString(props.value)}>${slots.value}</${name}>`;
    });
    return (_ctx, _cache) => {
      const _component_v_icon = resolveComponent("v-icon");
      const _component_v_badge = resolveComponent("v-badge");
      const _component_v_checkbox = resolveComponent("v-checkbox");
      const _component_v_slider = resolveComponent("v-slider");
      const _component_ExamplesUsageExample = _sfc_main$8;
      return openBlock(), createBlock(_component_ExamplesUsageExample, {
        modelValue: unref(model),
        "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => isRef(model) ? model.value = $event : null),
        code: unref(code),
        name,
        options
      }, {
        configuration: withCtx(() => [
          createVNode(_component_v_checkbox, {
            modelValue: unref(dot),
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(dot) ? dot.value = $event : null),
            label: "Dot"
          }, null, 8, ["modelValue"]),
          createVNode(_component_v_slider, {
            modelValue: unref(content),
            "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(content) ? content.value = $event : null),
            label: "Value",
            max: "100",
            min: "0",
            step: "1"
          }, null, 8, ["modelValue"])
        ]),
        default: withCtx(() => [
          createBaseVNode("div", _hoisted_1, [
            createVNode(_component_v_badge, normalizeProps(guardReactiveProps(unref(props))), {
              default: withCtx(() => [
                createVNode(_component_v_icon, {
                  icon: "$vuetify",
                  size: "x-large"
                })
              ]),
              _: 1
            }, 16)
          ])
        ]),
        _: 1
      }, 8, ["modelValue", "code"]);
    };
  }
};
const __7 = _sfc_main;
const __7_raw = `<template>
  <ExamplesUsageExample
    v-model="model"
    :code="code"
    :name="name"
    :options="options"
  >
    <div class="text-center">
      <v-badge v-bind="props">
        <v-icon
          icon="$vuetify"
          size="x-large"
        ></v-icon>
      </v-badge>
    </div>

    <template v-slot:configuration>
      <v-checkbox v-model="dot" label="Dot"></v-checkbox>

      <v-slider
        v-model="content"
        label="Value"
        max="100"
        min="0"
        step="1"
      ></v-slider>
    </template>
  </ExamplesUsageExample>
</template>

<script setup>
  const name = 'v-badge'
  const model = ref('default')
  const content = ref(0)
  const dot = ref(false)
  const options = ['floating', 'inline']
  const props = computed(() => {
    return {
      content: content.value || undefined,
      dot: dot.value || undefined,
      floating: model.value === 'floating' || undefined,
      inline: model.value === 'inline' || undefined,
    }
  })

  const slots = computed(() => {
    return \`
  <v-icon icon="$vuetify" size="x-large"></v-icon>
\`
  })

  const code = computed(() => {
    return \`<\${name}\${propsToString(props.value)}>\${slots.value}</\${name}>\`
  })
<\/script>
`;
const vBadge = {
  "misc-customization": {
    component: __0,
    source: __0_raw
  },
  "misc-dynamic": {
    component: __1,
    source: __1_raw
  },
  "misc-hover": {
    component: __2,
    source: __2_raw
  },
  "misc-tabs": {
    component: __3,
    source: __3_raw
  },
  "prop-content": {
    component: __4,
    source: __4_raw
  },
  "prop-dot": {
    component: __5,
    source: __5_raw
  },
  "prop-inline": {
    component: __6,
    source: __6_raw
  },
  "usage": {
    component: __7,
    source: __7_raw
  }
};
export {
  vBadge as default
};
