import { y as _export_sfc, r as resolveComponent, o as openBlock, l as createElementBlock, b as createVNode, w as withCtx, h as createTextVNode, J as ref, c as createBlock, j as computed, ag as propsToString, f as unref, E as isRef, q as createCommentVNode, e as createBaseVNode, a9 as mergeProps, S as createSlots } from "./index-DGybHjCP.js";
import { _ as _sfc_main$6 } from "./UsageExample-M8CmNipa.js";
const _sfc_main$5 = {};
function _sfc_render$3(_ctx, _cache) {
  const _component_v_banner_text = resolveComponent("v-banner-text");
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_banner = resolveComponent("v-banner");
  return openBlock(), createElementBlock("div", null, [
    createVNode(_component_v_banner, {
      class: "my-4",
      color: "deep-purple-accent-4",
      icon: "mdi-lock",
      lines: "one"
    }, {
      actions: withCtx(() => [
        createVNode(_component_v_btn, null, {
          default: withCtx(() => [
            createTextVNode("Action")
          ]),
          _: 1
        })
      ]),
      default: withCtx(() => [
        createVNode(_component_v_banner_text, null, {
          default: withCtx(() => [
            createTextVNode(" Banner with one line of text. ")
          ]),
          _: 1
        })
      ]),
      _: 1
    }),
    createVNode(_component_v_banner, {
      class: "my-4",
      color: "error",
      icon: "mdi-weather-hurricane",
      lines: "two"
    }, {
      actions: withCtx(() => [
        createVNode(_component_v_btn, null, {
          default: withCtx(() => [
            createTextVNode("Action")
          ]),
          _: 1
        })
      ]),
      default: withCtx(() => [
        createVNode(_component_v_banner_text, null, {
          default: withCtx(() => [
            createTextVNode(" Banner with two lines of text. If the text is too long to fit on two lines then an ellipsis will be used to hide the remaining content. So this next line will be hidden. ")
          ]),
          _: 1
        })
      ]),
      _: 1
    }),
    createVNode(_component_v_banner, {
      class: "my-4",
      color: "warning",
      icon: "$warning",
      lines: "three"
    }, {
      actions: withCtx(() => [
        createVNode(_component_v_btn, null, {
          default: withCtx(() => [
            createTextVNode("Action")
          ]),
          _: 1
        })
      ]),
      default: withCtx(() => [
        createVNode(_component_v_banner_text, null, {
          default: withCtx(() => [
            createTextVNode(" Banner with three lines of text. One or two lines is preferable. Three lines should be considered the absolute maximum length on desktop in order to keep messages short and actionable. ")
          ]),
          _: 1
        })
      ]),
      _: 1
    })
  ]);
}
const __0 = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["render", _sfc_render$3]]);
const __0_raw = '<template>\n  <div>\n    <v-banner\n      class="my-4"\n      color="deep-purple-accent-4"\n      icon="mdi-lock"\n      lines="one"\n    >\n      <v-banner-text>\n        Banner with one line of text.\n      </v-banner-text>\n\n      <template v-slot:actions>\n        <v-btn>Action</v-btn>\n      </template>\n    </v-banner>\n\n    <v-banner\n      class="my-4"\n      color="error"\n      icon="mdi-weather-hurricane"\n      lines="two"\n    >\n      <v-banner-text>\n        Banner with two lines of text. If the text is too long to fit on two lines then an ellipsis will be used to hide the remaining content. So this next line will be hidden.\n      </v-banner-text>\n\n      <template v-slot:actions>\n        <v-btn>Action</v-btn>\n      </template>\n    </v-banner>\n\n    <v-banner\n      class="my-4"\n      color="warning"\n      icon="$warning"\n      lines="three"\n    >\n      <v-banner-text>\n        Banner with three lines of text. One or two lines is preferable. Three lines should be considered the absolute maximum length on desktop in order to keep messages short and actionable.\n      </v-banner-text>\n\n      <template v-slot:actions>\n        <v-btn>Action</v-btn>\n      </template>\n    </v-banner>\n  </div>\n</template>\n';
const _sfc_main$4 = {
  __name: "prop-sticky",
  setup(__props) {
    const sticky = ref(false);
    return (_ctx, _cache) => {
      const _component_v_toolbar_title = resolveComponent("v-toolbar-title");
      const _component_v_spacer = resolveComponent("v-spacer");
      const _component_v_switch = resolveComponent("v-switch");
      const _component_v_toolbar = resolveComponent("v-toolbar");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_banner = resolveComponent("v-banner");
      const _component_v_sheet = resolveComponent("v-sheet");
      const _component_v_card_text = resolveComponent("v-card-text");
      const _component_v_footer = resolveComponent("v-footer");
      const _component_v_card = resolveComponent("v-card");
      return openBlock(), createBlock(_component_v_card, {
        class: "overflow-auto mx-auto",
        "max-height": "300",
        width: "448"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_toolbar, { color: "primary" }, {
            append: withCtx(() => [
              createVNode(_component_v_switch, {
                modelValue: sticky.value,
                "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => sticky.value = $event),
                color: "secondary",
                label: "Sticky Banner",
                "hide-details": ""
              }, null, 8, ["modelValue"])
            ]),
            default: withCtx(() => [
              createVNode(_component_v_toolbar_title, null, {
                default: withCtx(() => [
                  createTextVNode("My Document")
                ]),
                _: 1
              }),
              createVNode(_component_v_spacer)
            ]),
            _: 1
          }),
          createVNode(_component_v_banner, {
            sticky: sticky.value,
            lines: "one"
          }, {
            text: withCtx(() => [
              createTextVNode(" We can't save your edits while you are in offline mode. ")
            ]),
            actions: withCtx(() => [
              createVNode(_component_v_btn, { color: "deep-purple-accent-4" }, {
                default: withCtx(() => [
                  createTextVNode(" Go Online ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }, 8, ["sticky"]),
          createVNode(_component_v_card_text, { class: "bg-grey-lighten-4" }, {
            default: withCtx(() => [
              createVNode(_component_v_sheet, {
                class: "mx-auto",
                height: "300"
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_footer, {
            class: "justify-center",
            color: "primary"
          }, {
            default: withCtx(() => [
              createTextVNode(" End of Content ")
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __1 = _sfc_main$4;
const __1_raw = `<template>
  <v-card
    class="overflow-auto mx-auto"
    max-height="300"
    width="448"
  >
    <v-toolbar color="primary">
      <v-toolbar-title>My Document</v-toolbar-title>

      <v-spacer></v-spacer>

      <template v-slot:append>
        <v-switch
          v-model="sticky"
          color="secondary"
          label="Sticky Banner"
          hide-details
        ></v-switch>
      </template>
    </v-toolbar>

    <v-banner
      :sticky="sticky"
      lines="one"
    >
      <template v-slot:text>
        We can't save your edits while you are in offline mode.
      </template>

      <template v-slot:actions>
        <v-btn color="deep-purple-accent-4">
          Go Online
        </v-btn>
      </template>
    </v-banner>

    <v-card-text class="bg-grey-lighten-4">
      <v-sheet
        class="mx-auto"
        height="300"
      ></v-sheet>
    </v-card-text>

    <v-footer
      class="justify-center"
      color="primary"
    >
      End of Content
    </v-footer>
  </v-card>
</template>

<script setup>
  import { ref } from 'vue'

  const sticky = ref(false)
<\/script>

<script>
  export default {
    data: () => ({
      sticky: false,
    }),
  }
<\/script>
`;
const _sfc_main$3 = {};
function _sfc_render$2(_ctx, _cache) {
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_banner = resolveComponent("v-banner");
  return openBlock(), createBlock(_component_v_banner, {
    color: "warning",
    icon: "mdi-wifi-strength-alert-outline",
    lines: "one"
  }, {
    text: withCtx(() => [
      createTextVNode(" No Internet connection ")
    ]),
    actions: withCtx(() => [
      createVNode(_component_v_btn, null, {
        default: withCtx(() => [
          createTextVNode(" Dismiss ")
        ]),
        _: 1
      }),
      createVNode(_component_v_btn, null, {
        default: withCtx(() => [
          createTextVNode(" Retry ")
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __2 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["render", _sfc_render$2]]);
const __2_raw = '<template>\n  <v-banner\n    color="warning"\n    icon="mdi-wifi-strength-alert-outline"\n    lines="one"\n  >\n    <template v-slot:text>\n      No Internet connection\n    </template>\n\n    <template v-slot:actions>\n      <v-btn>\n        Dismiss\n      </v-btn>\n\n      <v-btn>\n        Retry\n      </v-btn>\n    </template>\n  </v-banner>\n</template>\n';
const _sfc_main$2 = {};
function _sfc_render$1(_ctx, _cache) {
  const _component_v_avatar = resolveComponent("v-avatar");
  const _component_v_banner_text = resolveComponent("v-banner-text");
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_banner_actions = resolveComponent("v-banner-actions");
  const _component_v_banner = resolveComponent("v-banner");
  return openBlock(), createBlock(_component_v_banner, {
    color: "pink-darken-1",
    icon: "mdi-account-box",
    lines: "two"
  }, {
    prepend: withCtx(() => [
      createVNode(_component_v_avatar)
    ]),
    default: withCtx(() => [
      createVNode(_component_v_banner_text, null, {
        default: withCtx(() => [
          createTextVNode(" Banner with two lines of text. If the text is too long to fit on two lines then an ellipsis will be used to hide the remaining content. So this next line will be hidden. ")
        ]),
        _: 1
      }),
      createVNode(_component_v_banner_actions, null, {
        default: withCtx(() => [
          createVNode(_component_v_btn, null, {
            default: withCtx(() => [
              createTextVNode("Action Button")
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __3 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["render", _sfc_render$1]]);
const __3_raw = '<template>\n  <v-banner\n    color="pink-darken-1"\n    icon="mdi-account-box"\n    lines="two"\n  >\n    <template v-slot:prepend>\n      <v-avatar></v-avatar>\n    </template>\n\n    <v-banner-text>\n      Banner with two lines of text. If the text is too long to fit on two lines then an ellipsis will be used to hide the remaining content. So this next line will be hidden.\n    </v-banner-text>\n\n    <v-banner-actions>\n      <v-btn>Action Button</v-btn>\n    </v-banner-actions>\n  </v-banner>\n</template>\n';
const _sfc_main$1 = {};
function _sfc_render(_ctx, _cache) {
  const _component_v_avatar = resolveComponent("v-avatar");
  const _component_v_banner_text = resolveComponent("v-banner-text");
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_banner_actions = resolveComponent("v-banner-actions");
  const _component_v_banner = resolveComponent("v-banner");
  return openBlock(), createBlock(_component_v_banner, {
    color: "deep-purple-accent-4",
    lines: "two"
  }, {
    prepend: withCtx(() => [
      createVNode(_component_v_avatar, {
        color: "deep-purple-accent-4",
        icon: "mdi-account-filter"
      })
    ]),
    default: withCtx(() => [
      createVNode(_component_v_banner_text, null, {
        default: withCtx(() => [
          createTextVNode(" Banner with two lines of text. If the text is too long to fit on two lines then an ellipsis will be used to hide the remaining content. So this next line will be hidden. ")
        ]),
        _: 1
      }),
      createVNode(_component_v_banner_actions, null, {
        default: withCtx(() => [
          createVNode(_component_v_btn, null, {
            default: withCtx(() => [
              createTextVNode("Action")
            ]),
            _: 1
          }),
          createVNode(_component_v_btn, null, {
            default: withCtx(() => [
              createTextVNode("Action")
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __4 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["render", _sfc_render]]);
const __4_raw = '<template>\n  <v-banner\n    color="deep-purple-accent-4"\n    lines="two"\n  >\n    <template v-slot:prepend>\n      <v-avatar\n        color="deep-purple-accent-4"\n        icon="mdi-account-filter"\n      ></v-avatar>\n    </template>\n\n    <v-banner-text>\n      Banner with two lines of text. If the text is too long to fit on two lines then an ellipsis will be used to hide the remaining content. So this next line will be hidden.\n    </v-banner-text>\n\n    <v-banner-actions>\n      <v-btn>Action</v-btn>\n\n      <v-btn>Action</v-btn>\n    </v-banner-actions>\n  </v-banner>\n</template>\n';
const name = "v-banner";
const _sfc_main = {
  __name: "usage",
  setup(__props) {
    const model = ref("default");
    const options = ["One line", "Two lines", "Three lines"];
    const icon = ref(false);
    const avatar = ref(false);
    const actions = ref(false);
    const stacked = ref(false);
    const color = ref();
    const props = computed(() => {
      return {
        avatar: avatar.value ? "smirk.png" : void 0,
        color: color.value ? color.value : void 0,
        icon: icon.value ? "$vuetify" : void 0,
        lines: model.value !== "default" ? model.value.toLocaleLowerCase().split(" ")[0] : void 0,
        text: "...",
        stacked: stacked.value
      };
    });
    const slots = computed(() => {
      return `
  <template v-slot:actions>
    <v-btn>Click me</v-btn>
  </template>
`;
    });
    const code = computed(() => {
      return `<${name}${propsToString(props.value)}>${slots.value}</${name}>`;
    });
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_banner = resolveComponent("v-banner");
      const _component_v_select = resolveComponent("v-select");
      const _component_v_checkbox = resolveComponent("v-checkbox");
      const _component_ExamplesUsageExample = _sfc_main$6;
      return openBlock(), createBlock(_component_ExamplesUsageExample, {
        modelValue: unref(model),
        "onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => isRef(model) ? model.value = $event : null),
        code: unref(code),
        name,
        options
      }, {
        configuration: withCtx(() => [
          createVNode(_component_v_select, {
            modelValue: unref(color),
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(color) ? color.value = $event : null),
            items: [
              "success",
              "info",
              "warning",
              "error"
            ],
            label: "Color",
            clearable: ""
          }, null, 8, ["modelValue"]),
          createVNode(_component_v_checkbox, {
            modelValue: unref(avatar),
            "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(avatar) ? avatar.value = $event : null),
            label: "Avatar"
          }, null, 8, ["modelValue"]),
          createVNode(_component_v_checkbox, {
            modelValue: unref(icon),
            "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => isRef(icon) ? icon.value = $event : null),
            label: "Icon"
          }, null, 8, ["modelValue"]),
          createVNode(_component_v_checkbox, {
            modelValue: unref(actions),
            "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => isRef(actions) ? actions.value = $event : null),
            label: "Actions"
          }, null, 8, ["modelValue"]),
          unref(actions) ? (openBlock(), createBlock(_component_v_checkbox, {
            key: 0,
            modelValue: unref(stacked),
            "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => isRef(stacked) ? stacked.value = $event : null),
            label: "Stacked"
          }, null, 8, ["modelValue"])) : createCommentVNode("", true)
        ]),
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createVNode(_component_v_banner, mergeProps(unref(props), {
              avatar: unref(avatar) ? "https://cdn.vuetifyjs.com/images/john-smirk.png" : void 0
            }), createSlots({
              text: withCtx(() => [
                createTextVNode(" Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquam earum, est illo quae fugit voluptatum fuga magni hic maiores ipsa, illum, tenetur accusamus cupiditate? Dolorem ad nisi eveniet officia voluptatibus. ")
              ]),
              _: 2
            }, [
              unref(actions) ? {
                name: "actions",
                fn: withCtx(() => [
                  createVNode(_component_v_btn, null, {
                    default: withCtx(() => [
                      createTextVNode("Click me")
                    ]),
                    _: 1
                  })
                ]),
                key: "0"
              } : void 0
            ]), 1040, ["avatar"])
          ])
        ]),
        _: 1
      }, 8, ["modelValue", "code"]);
    };
  }
};
const __5 = _sfc_main;
const __5_raw = `<template>
  <ExamplesUsageExample
    v-model="model"
    :code="code"
    :name="name"
    :options="options"
  >
    <div>
      <v-banner
        v-bind="props"
        :avatar="avatar ? 'https://cdn.vuetifyjs.com/images/john-smirk.png' : undefined"
      >
        <template v-slot:text>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquam earum, est illo quae fugit voluptatum fuga magni hic maiores ipsa, illum, tenetur accusamus cupiditate? Dolorem ad nisi eveniet officia voluptatibus.
        </template>

        <template v-if="actions" v-slot:actions>
          <v-btn>Click me</v-btn>
        </template>
      </v-banner>
    </div>

    <template v-slot:configuration>
      <v-select
        v-model="color"
        :items="[
          'success',
          'info',
          'warning',
          'error',
        ]"
        label="Color"
        clearable
      ></v-select>

      <v-checkbox v-model="avatar" label="Avatar"></v-checkbox>

      <v-checkbox v-model="icon" label="Icon"></v-checkbox>

      <v-checkbox v-model="actions" label="Actions"></v-checkbox>

      <v-checkbox v-if="actions" v-model="stacked" label="Stacked"></v-checkbox>
    </template>
  </ExamplesUsageExample>
</template>

<script setup>
  const name = 'v-banner'
  const model = ref('default')
  const options = ['One line', 'Two lines', 'Three lines']
  const icon = ref(false)
  const avatar = ref(false)
  const actions = ref(false)
  const stacked = ref(false)
  const color = ref()

  const props = computed(() => {
    return {
      avatar: avatar.value ? 'smirk.png' : undefined,
      color: color.value ? color.value : undefined,
      icon: icon.value ? '$vuetify' : undefined,
      lines: model.value !== 'default' ? model.value.toLocaleLowerCase().split(' ')[0] : undefined,
      text: '...',
      stacked: stacked.value,
    }
  })

  const slots = computed(() => {
    return \`
  <template v-slot:actions>
    <v-btn>Click me</v-btn>
  </template>
\`
  })

  const code = computed(() => {
    return \`<\${name}\${propsToString(props.value)}>\${slots.value}</\${name}>\`
  })
<\/script>
`;
const vBanner = {
  "prop-lines": {
    component: __0,
    source: __0_raw
  },
  "prop-sticky": {
    component: __1,
    source: __1_raw
  },
  "slot-actions": {
    component: __2,
    source: __2_raw
  },
  "slot-icon": {
    component: __3,
    source: __3_raw
  },
  "slot-prepend": {
    component: __4,
    source: __4_raw
  },
  "usage": {
    component: __5,
    source: __5_raw
  }
};
export {
  vBanner as default
};
