import { J as ref, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, b as createVNode, h as createTextVNode, e as createBaseVNode, y as _export_sfc, j as computed, ag as propsToString, f as unref, E as isRef, ak as normalizeProps, al as guardReactiveProps } from "./index-DGybHjCP.js";
import { _ as _sfc_main$8 } from "./UsageExample-M8CmNipa.js";
const _hoisted_1$5 = /* @__PURE__ */ createBaseVNode("span", null, "Nearby", -1);
const _sfc_main$7 = {
  __name: "prop-color",
  setup(__props) {
    const value = ref(0);
    return (_ctx, _cache) => {
      const _component_v_icon = resolveComponent("v-icon");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_bottom_navigation = resolveComponent("v-bottom-navigation");
      const _component_v_layout = resolveComponent("v-layout");
      return openBlock(), createBlock(_component_v_layout, {
        class: "overflow-visible",
        style: { "height": "56px" }
      }, {
        default: withCtx(() => [
          createVNode(_component_v_bottom_navigation, {
            modelValue: value.value,
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => value.value = $event),
            color: "primary",
            active: ""
          }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, null, {
                default: withCtx(() => [
                  createVNode(_component_v_icon, null, {
                    default: withCtx(() => [
                      createTextVNode("mdi-history")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" Recents ")
                ]),
                _: 1
              }),
              createVNode(_component_v_btn, null, {
                default: withCtx(() => [
                  createVNode(_component_v_icon, null, {
                    default: withCtx(() => [
                      createTextVNode("mdi-heart")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" Favorites ")
                ]),
                _: 1
              }),
              createVNode(_component_v_btn, null, {
                default: withCtx(() => [
                  createVNode(_component_v_icon, null, {
                    default: withCtx(() => [
                      createTextVNode("mdi-map-marker")
                    ]),
                    _: 1
                  }),
                  _hoisted_1$5
                ]),
                _: 1
              })
            ]),
            _: 1
          }, 8, ["modelValue"])
        ]),
        _: 1
      });
    };
  }
};
const __0 = _sfc_main$7;
const __0_raw = `<template>
  <v-layout class="overflow-visible" style="height: 56px;">
    <v-bottom-navigation
      v-model="value"
      color="primary"
      active
    >
      <v-btn>
        <v-icon>mdi-history</v-icon>

        Recents
      </v-btn>

      <v-btn>
        <v-icon>mdi-heart</v-icon>

        Favorites
      </v-btn>

      <v-btn>
        <v-icon>mdi-map-marker</v-icon>

        <span>Nearby</span>
      </v-btn>
    </v-bottom-navigation>
  </v-layout>
</template>

<script setup>
  import { ref } from 'vue'

  const value = ref(0)
<\/script>

<script>
  export default {
    data: () => ({ value: 0 }),
  }
<\/script>
`;
const _sfc_main$6 = {
  __name: "prop-grow",
  setup(__props) {
    const value = ref(1);
    return (_ctx, _cache) => {
      const _component_v_icon = resolveComponent("v-icon");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_bottom_navigation = resolveComponent("v-bottom-navigation");
      const _component_v_layout = resolveComponent("v-layout");
      return openBlock(), createBlock(_component_v_layout, {
        class: "overflow-visible",
        style: { "height": "56px" }
      }, {
        default: withCtx(() => [
          createVNode(_component_v_bottom_navigation, {
            modelValue: value.value,
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => value.value = $event),
            color: "teal",
            grow: ""
          }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, null, {
                default: withCtx(() => [
                  createVNode(_component_v_icon, null, {
                    default: withCtx(() => [
                      createTextVNode("mdi-history")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" Recents ")
                ]),
                _: 1
              }),
              createVNode(_component_v_btn, null, {
                default: withCtx(() => [
                  createVNode(_component_v_icon, null, {
                    default: withCtx(() => [
                      createTextVNode("mdi-heart")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" Favorites ")
                ]),
                _: 1
              }),
              createVNode(_component_v_btn, null, {
                default: withCtx(() => [
                  createVNode(_component_v_icon, null, {
                    default: withCtx(() => [
                      createTextVNode("mdi-map-marker")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" Nearby ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }, 8, ["modelValue"])
        ]),
        _: 1
      });
    };
  }
};
const __1 = _sfc_main$6;
const __1_raw = `<template>
  <v-layout class="overflow-visible" style="height: 56px;">
    <v-bottom-navigation
      v-model="value"
      color="teal"
      grow
    >
      <v-btn>
        <v-icon>mdi-history</v-icon>

        Recents
      </v-btn>

      <v-btn>
        <v-icon>mdi-heart</v-icon>

        Favorites
      </v-btn>

      <v-btn>
        <v-icon>mdi-map-marker</v-icon>

        Nearby
      </v-btn>
    </v-bottom-navigation>
  </v-layout>
</template>

<script setup>
  import { ref } from 'vue'

  const value = ref(1)
<\/script>

<script>
  export default {
    data: () => ({ value: 1 }),
  }
<\/script>
`;
const _sfc_main$5 = {};
const _hoisted_1$4 = /* @__PURE__ */ createBaseVNode("span", null, "Recents", -1);
const _hoisted_2$3 = /* @__PURE__ */ createBaseVNode("span", null, "Favorites", -1);
const _hoisted_3$3 = /* @__PURE__ */ createBaseVNode("span", null, "Nearby", -1);
function _sfc_render$1(_ctx, _cache) {
  const _component_v_icon = resolveComponent("v-icon");
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_bottom_navigation = resolveComponent("v-bottom-navigation");
  const _component_v_responsive = resolveComponent("v-responsive");
  const _component_v_card = resolveComponent("v-card");
  return openBlock(), createBlock(_component_v_card, {
    class: "overflow-hidden mx-auto",
    height: "200",
    "max-width": "500"
  }, {
    default: withCtx(() => [
      createVNode(_component_v_bottom_navigation, {
        "scroll-target": "#hide-on-scroll-example",
        absolute: "",
        "hide-on-scroll": "",
        horizontal: ""
      }, {
        default: withCtx(() => [
          createVNode(_component_v_btn, {
            color: "deep-purple-accent-4",
            variant: "text"
          }, {
            default: withCtx(() => [
              _hoisted_1$4,
              createVNode(_component_v_icon, null, {
                default: withCtx(() => [
                  createTextVNode("mdi-history")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_btn, {
            color: "deep-purple-accent-4",
            variant: "text"
          }, {
            default: withCtx(() => [
              _hoisted_2$3,
              createVNode(_component_v_icon, null, {
                default: withCtx(() => [
                  createTextVNode("mdi-heart")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_btn, {
            color: "deep-purple-accent-4",
            variant: "text"
          }, {
            default: withCtx(() => [
              _hoisted_3$3,
              createVNode(_component_v_icon, null, {
                default: withCtx(() => [
                  createTextVNode("mdi-map-marker")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_responsive, {
        id: "hide-on-scroll-example",
        class: "overflow-y-auto",
        "max-height": "600"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_responsive, { height: "1500" })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __2 = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["render", _sfc_render$1]]);
const __2_raw = '<template>\n  <v-card\n    class="overflow-hidden mx-auto"\n    height="200"\n    max-width="500"\n  >\n    <v-bottom-navigation\n      scroll-target="#hide-on-scroll-example"\n      absolute\n      hide-on-scroll\n      horizontal\n    >\n      <v-btn\n        color="deep-purple-accent-4"\n        variant="text"\n      >\n        <span>Recents</span>\n\n        <v-icon>mdi-history</v-icon>\n      </v-btn>\n\n      <v-btn\n        color="deep-purple-accent-4"\n        variant="text"\n      >\n        <span>Favorites</span>\n\n        <v-icon>mdi-heart</v-icon>\n      </v-btn>\n\n      <v-btn\n        color="deep-purple-accent-4"\n        variant="text"\n      >\n        <span>Nearby</span>\n\n        <v-icon>mdi-map-marker</v-icon>\n      </v-btn>\n    </v-bottom-navigation>\n\n    <v-responsive\n      id="hide-on-scroll-example"\n      class="overflow-y-auto"\n      max-height="600"\n    >\n      <v-responsive height="1500"></v-responsive>\n    </v-responsive>\n  </v-card>\n</template>\n';
const _sfc_main$4 = {
  __name: "prop-horizontal",
  setup(__props) {
    const value = ref(1);
    return (_ctx, _cache) => {
      const _component_v_icon = resolveComponent("v-icon");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_bottom_navigation = resolveComponent("v-bottom-navigation");
      const _component_v_layout = resolveComponent("v-layout");
      return openBlock(), createBlock(_component_v_layout, {
        class: "overflow-visible",
        style: { "height": "56px" }
      }, {
        default: withCtx(() => [
          createVNode(_component_v_bottom_navigation, {
            modelValue: value.value,
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => value.value = $event),
            color: "primary",
            horizontal: ""
          }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, null, {
                default: withCtx(() => [
                  createVNode(_component_v_icon, null, {
                    default: withCtx(() => [
                      createTextVNode("mdi-history")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" Recents ")
                ]),
                _: 1
              }),
              createVNode(_component_v_btn, null, {
                default: withCtx(() => [
                  createVNode(_component_v_icon, null, {
                    default: withCtx(() => [
                      createTextVNode("mdi-heart")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" Favorites ")
                ]),
                _: 1
              }),
              createVNode(_component_v_btn, null, {
                default: withCtx(() => [
                  createVNode(_component_v_icon, null, {
                    default: withCtx(() => [
                      createTextVNode("mdi-map-marker")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" Nearby ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }, 8, ["modelValue"])
        ]),
        _: 1
      });
    };
  }
};
const __3 = _sfc_main$4;
const __3_raw = `<template>

  <v-layout class="overflow-visible" style="height: 56px;">
    <v-bottom-navigation
      v-model="value"
      color="primary"
      horizontal
    >
      <v-btn>
        <v-icon>mdi-history</v-icon>

        Recents
      </v-btn>

      <v-btn>
        <v-icon>mdi-heart</v-icon>

        Favorites
      </v-btn>

      <v-btn>
        <v-icon>mdi-map-marker</v-icon>

        Nearby
      </v-btn>
    </v-bottom-navigation>
  </v-layout>
</template>

<script setup>
  import { ref } from 'vue'

  const value = ref(1)
<\/script>

<script>
  export default {
    data: () => ({ value: 1 }),
  }
<\/script>
`;
const _sfc_main$3 = {};
const _hoisted_1$3 = /* @__PURE__ */ createBaseVNode("span", null, "Recents", -1);
const _hoisted_2$2 = /* @__PURE__ */ createBaseVNode("span", null, "Favorites", -1);
const _hoisted_3$2 = /* @__PURE__ */ createBaseVNode("span", null, "Nearby", -1);
function _sfc_render(_ctx, _cache) {
  const _component_v_icon = resolveComponent("v-icon");
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_bottom_navigation = resolveComponent("v-bottom-navigation");
  const _component_v_responsive = resolveComponent("v-responsive");
  const _component_v_sheet = resolveComponent("v-sheet");
  const _component_v_card = resolveComponent("v-card");
  return openBlock(), createBlock(_component_v_card, {
    class: "mx-auto overflow-hidden",
    height: "200",
    "max-width": "500"
  }, {
    default: withCtx(() => [
      createVNode(_component_v_bottom_navigation, {
        color: "white",
        "scroll-target": "#scroll-threshold-example",
        "scroll-threshold": "500",
        absolute: "",
        "hide-on-scroll": "",
        horizontal: ""
      }, {
        default: withCtx(() => [
          createVNode(_component_v_btn, null, {
            default: withCtx(() => [
              _hoisted_1$3,
              createVNode(_component_v_icon, null, {
                default: withCtx(() => [
                  createTextVNode("mdi-history")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_btn, null, {
            default: withCtx(() => [
              _hoisted_2$2,
              createVNode(_component_v_icon, null, {
                default: withCtx(() => [
                  createTextVNode("mdi-heart")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_btn, null, {
            default: withCtx(() => [
              _hoisted_3$2,
              createVNode(_component_v_icon, null, {
                default: withCtx(() => [
                  createTextVNode("mdi-map-marker")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_sheet, {
        id: "scroll-threshold-example",
        class: "overflow-y-auto pb-16",
        "max-height": "600"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_responsive, { height: "1500" })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __4 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["render", _sfc_render]]);
const __4_raw = '<template>\n  <v-card\n    class="mx-auto overflow-hidden"\n    height="200"\n    max-width="500"\n  >\n    <v-bottom-navigation\n      color="white"\n      scroll-target="#scroll-threshold-example"\n      scroll-threshold="500"\n      absolute\n      hide-on-scroll\n      horizontal\n    >\n      <v-btn>\n        <span>Recents</span>\n\n        <v-icon>mdi-history</v-icon>\n      </v-btn>\n\n      <v-btn>\n        <span>Favorites</span>\n\n        <v-icon>mdi-heart</v-icon>\n      </v-btn>\n\n      <v-btn>\n        <span>Nearby</span>\n\n        <v-icon>mdi-map-marker</v-icon>\n      </v-btn>\n    </v-bottom-navigation>\n\n    <v-sheet\n      id="scroll-threshold-example"\n      class="overflow-y-auto pb-16"\n      max-height="600"\n    >\n      <v-responsive height="1500"></v-responsive>\n    </v-sheet>\n  </v-card>\n</template>\n';
const _hoisted_1$2 = /* @__PURE__ */ createBaseVNode("span", null, "Video", -1);
const _hoisted_2$1 = /* @__PURE__ */ createBaseVNode("span", null, "Music", -1);
const _hoisted_3$1 = /* @__PURE__ */ createBaseVNode("span", null, "Book", -1);
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("span", null, "Image", -1);
const _sfc_main$2 = {
  __name: "prop-shift",
  setup(__props) {
    const value = ref(1);
    const color = computed(() => {
      switch (value.value) {
        case 0:
          return "blue-grey";
        case 1:
          return "teal";
        case 2:
          return "brown";
        case 3:
          return "indigo";
        default:
          return "blue-grey";
      }
    });
    return (_ctx, _cache) => {
      const _component_v_icon = resolveComponent("v-icon");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_bottom_navigation = resolveComponent("v-bottom-navigation");
      const _component_v_layout = resolveComponent("v-layout");
      return openBlock(), createBlock(_component_v_layout, {
        class: "overflow-visible",
        style: { "height": "56px" }
      }, {
        default: withCtx(() => [
          createVNode(_component_v_bottom_navigation, {
            modelValue: value.value,
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => value.value = $event),
            "bg-color": color.value,
            mode: "shift"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, null, {
                default: withCtx(() => [
                  createVNode(_component_v_icon, null, {
                    default: withCtx(() => [
                      createTextVNode("mdi-television-play")
                    ]),
                    _: 1
                  }),
                  _hoisted_1$2
                ]),
                _: 1
              }),
              createVNode(_component_v_btn, null, {
                default: withCtx(() => [
                  createVNode(_component_v_icon, null, {
                    default: withCtx(() => [
                      createTextVNode("mdi-music-note")
                    ]),
                    _: 1
                  }),
                  _hoisted_2$1
                ]),
                _: 1
              }),
              createVNode(_component_v_btn, null, {
                default: withCtx(() => [
                  createVNode(_component_v_icon, null, {
                    default: withCtx(() => [
                      createTextVNode("mdi-book")
                    ]),
                    _: 1
                  }),
                  _hoisted_3$1
                ]),
                _: 1
              }),
              createVNode(_component_v_btn, null, {
                default: withCtx(() => [
                  createVNode(_component_v_icon, null, {
                    default: withCtx(() => [
                      createTextVNode("mdi-image")
                    ]),
                    _: 1
                  }),
                  _hoisted_4
                ]),
                _: 1
              })
            ]),
            _: 1
          }, 8, ["modelValue", "bg-color"])
        ]),
        _: 1
      });
    };
  }
};
const __5 = _sfc_main$2;
const __5_raw = `<template>

  <v-layout class="overflow-visible" style="height: 56px;">
    <v-bottom-navigation
      v-model="value"
      :bg-color="color"
      mode="shift"
    >
      <v-btn>
        <v-icon>mdi-television-play</v-icon>

        <span>Video</span>
      </v-btn>

      <v-btn>
        <v-icon>mdi-music-note</v-icon>

        <span>Music</span>
      </v-btn>

      <v-btn>
        <v-icon>mdi-book</v-icon>

        <span>Book</span>
      </v-btn>

      <v-btn>
        <v-icon>mdi-image</v-icon>

        <span>Image</span>
      </v-btn>
    </v-bottom-navigation>
  </v-layout>
</template>

<script setup>
  import { computed, ref } from 'vue'

  const value = ref(1)
  const color = computed(() => {
    switch (value.value) {
      case 0: return 'blue-grey'
      case 1: return 'teal'
      case 2: return 'brown'
      case 3: return 'indigo'
      default: return 'blue-grey'
    }
  })
<\/script>

<script>
  export default {
    data: () => ({ value: 1 }),

    computed: {
      color () {
        switch (this.value) {
          case 0: return 'blue-grey'
          case 1: return 'teal'
          case 2: return 'brown'
          case 3: return 'indigo'
          default: return 'blue-grey'
        }
      },
    },
  }
<\/script>
`;
const _hoisted_1$1 = { class: "mx-auto my-4" };
const _sfc_main$1 = {
  __name: "prop-toggle",
  setup(__props) {
    const active = ref(true);
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_icon = resolveComponent("v-icon");
      const _component_v_bottom_navigation = resolveComponent("v-bottom-navigation");
      const _component_v_layout = resolveComponent("v-layout");
      return openBlock(), createBlock(_component_v_layout, {
        class: "border rounded",
        style: { "height": "128px" }
      }, {
        default: withCtx(() => [
          createBaseVNode("div", _hoisted_1$1, [
            createVNode(_component_v_btn, {
              color: "deep-purple",
              variant: "outlined",
              onClick: _cache[0] || (_cache[0] = ($event) => active.value = !active.value)
            }, {
              default: withCtx(() => [
                createTextVNode(" Toggle Navigation ")
              ]),
              _: 1
            })
          ]),
          createVNode(_component_v_bottom_navigation, {
            active: active.value,
            color: "indigo"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, null, {
                default: withCtx(() => [
                  createVNode(_component_v_icon, null, {
                    default: withCtx(() => [
                      createTextVNode("mdi-history")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" Recents ")
                ]),
                _: 1
              }),
              createVNode(_component_v_btn, null, {
                default: withCtx(() => [
                  createVNode(_component_v_icon, null, {
                    default: withCtx(() => [
                      createTextVNode("mdi-heart")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" Favorites ")
                ]),
                _: 1
              }),
              createVNode(_component_v_btn, null, {
                default: withCtx(() => [
                  createVNode(_component_v_icon, null, {
                    default: withCtx(() => [
                      createTextVNode("mdi-map-marker")
                    ]),
                    _: 1
                  }),
                  createTextVNode(" Nearby ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }, 8, ["active"])
        ]),
        _: 1
      });
    };
  }
};
const __6 = _sfc_main$1;
const __6_raw = `<template>
  <v-layout class="border rounded" style="height: 128px;">
    <div class="mx-auto my-4">
      <v-btn
        color="deep-purple"
        variant="outlined"
        @click="active = !active"
      >
        Toggle Navigation
      </v-btn>
    </div>

    <v-bottom-navigation
      :active="active"
      color="indigo"
    >
      <v-btn>
        <v-icon>mdi-history</v-icon>

        Recents
      </v-btn>

      <v-btn>
        <v-icon>mdi-heart</v-icon>

        Favorites
      </v-btn>

      <v-btn>
        <v-icon>mdi-map-marker</v-icon>

        Nearby
      </v-btn>
    </v-bottom-navigation>

  </v-layout>
</template>

<script setup>
  import { ref } from 'vue'

  const active = ref(true)
<\/script>

<script>
  export default {
    data: () => ({ active: true }),
  }
<\/script>
`;
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("span", null, "Recent", -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("span", null, "Favorites", -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("span", null, "Nearby", -1);
const name = "v-bottom-navigation";
const _sfc_main = {
  __name: "usage",
  setup(__props) {
    const model = ref("default");
    const options = ["grow", "shift"];
    const elevation = ref(4);
    const props = computed(() => {
      return {
        elevation: elevation.value === 4 ? void 0 : elevation.value,
        grow: model.value === "grow" || void 0,
        mode: model.value === "shift" ? "shift" : void 0
      };
    });
    const slots = computed(() => {
      let str = "";
      str += `
  <v-btn value="recent">
    <v-icon>mdi-history</v-icon>

    <span>Recent</span>
  </v-btn>

  <v-btn value="favorites">
    <v-icon>mdi-heart</v-icon>

    <span>Favorites</span>
  </v-btn>

  <v-btn value="nearby">
    <v-icon>mdi-map-marker</v-icon>

    <span>Nearby</span>
  </v-btn>
`;
      return str;
    });
    const code = computed(() => {
      return `<${name}${propsToString(props.value)}>${slots.value}</${name}>`;
    });
    return (_ctx, _cache) => {
      const _component_v_icon = resolveComponent("v-icon");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_bottom_navigation = resolveComponent("v-bottom-navigation");
      const _component_v_layout = resolveComponent("v-layout");
      const _component_v_slider = resolveComponent("v-slider");
      const _component_ExamplesUsageExample = _sfc_main$8;
      return openBlock(), createBlock(_component_ExamplesUsageExample, {
        modelValue: unref(model),
        "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(model) ? model.value = $event : null),
        code: unref(code),
        name,
        options
      }, {
        configuration: withCtx(() => [
          createVNode(_component_v_slider, {
            modelValue: unref(elevation),
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(elevation) ? elevation.value = $event : null),
            label: "Elevation",
            max: "24",
            min: "0",
            step: "1"
          }, null, 8, ["modelValue"])
        ]),
        default: withCtx(() => [
          createVNode(_component_v_layout, { class: "overflow-visible" }, {
            default: withCtx(() => [
              createVNode(_component_v_bottom_navigation, normalizeProps(guardReactiveProps(unref(props))), {
                default: withCtx(() => [
                  createVNode(_component_v_btn, { value: "history" }, {
                    default: withCtx(() => [
                      createVNode(_component_v_icon, null, {
                        default: withCtx(() => [
                          createTextVNode("mdi-history")
                        ]),
                        _: 1
                      }),
                      _hoisted_1
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_btn, { value: "favorites" }, {
                    default: withCtx(() => [
                      createVNode(_component_v_icon, null, {
                        default: withCtx(() => [
                          createTextVNode("mdi-heart")
                        ]),
                        _: 1
                      }),
                      _hoisted_2
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_btn, { value: "nearby" }, {
                    default: withCtx(() => [
                      createVNode(_component_v_icon, null, {
                        default: withCtx(() => [
                          createTextVNode("mdi-map-marker")
                        ]),
                        _: 1
                      }),
                      _hoisted_3
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }, 16)
            ]),
            _: 1
          })
        ]),
        _: 1
      }, 8, ["modelValue", "code"]);
    };
  }
};
const __7 = _sfc_main;
const __7_raw = `<template>
  <ExamplesUsageExample
    v-model="model"
    :code="code"
    :name="name"
    :options="options"
  >
    <v-layout class="overflow-visible">
      <v-bottom-navigation v-bind="props">
        <v-btn value="history">
          <v-icon>mdi-history</v-icon>

          <span>Recent</span>
        </v-btn>

        <v-btn value="favorites">
          <v-icon>mdi-heart</v-icon>

          <span>Favorites</span>
        </v-btn>

        <v-btn value="nearby">
          <v-icon>mdi-map-marker</v-icon>

          <span>Nearby</span>
        </v-btn>
      </v-bottom-navigation>
    </v-layout>

    <template v-slot:configuration>
      <v-slider v-model="elevation" label="Elevation" max="24" min="0" step="1"></v-slider>
    </template>
  </ExamplesUsageExample>
</template>

<script setup>
  const name = 'v-bottom-navigation'
  const model = ref('default')
  const options = ['grow', 'shift']
  const elevation = ref(4)

  const props = computed(() => {
    return {
      elevation: elevation.value === 4 ? undefined : elevation.value,
      grow: model.value === 'grow' || undefined,
      mode: model.value === 'shift' ? 'shift' : undefined,
    }
  })

  const slots = computed(() => {
    let str = ''

    str += \`
  <v-btn value="recent">
    <v-icon>mdi-history</v-icon>

    <span>Recent</span>
  </v-btn>

  <v-btn value="favorites">
    <v-icon>mdi-heart</v-icon>

    <span>Favorites</span>
  </v-btn>

  <v-btn value="nearby">
    <v-icon>mdi-map-marker</v-icon>

    <span>Nearby</span>
  </v-btn>
\`

    return str
  })

  const code = computed(() => {
    return \`<\${name}\${propsToString(props.value)}>\${slots.value}</\${name}>\`
  })
<\/script>
`;
const vBottomNavigation = {
  "prop-color": {
    component: __0,
    source: __0_raw
  },
  "prop-grow": {
    component: __1,
    source: __1_raw
  },
  "prop-hide-on-scroll": {
    component: __2,
    source: __2_raw
  },
  "prop-horizontal": {
    component: __3,
    source: __3_raw
  },
  "prop-scroll-threshold": {
    component: __4,
    source: __4_raw
  },
  "prop-shift": {
    component: __5,
    source: __5_raw
  },
  "prop-toggle": {
    component: __6,
    source: __6_raw
  },
  "usage": {
    component: __7,
    source: __7_raw
  }
};
export {
  vBottomNavigation as default
};
