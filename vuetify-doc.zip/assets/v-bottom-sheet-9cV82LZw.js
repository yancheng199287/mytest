import { J as ref, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, a9 as mergeProps, h as createTextVNode, l as createElementBlock, F as Fragment, v as renderList, ac as useDisplay, U as normalizeClass, f as unref, j as computed, ag as propsToString, ak as normalizeProps, al as guardReactiveProps, E as isRef } from "./index-DGybHjCP.js";
import { _ as _sfc_main$5 } from "./UsageExample-M8CmNipa.js";
const _hoisted_1$4 = { class: "text-center" };
const _sfc_main$4 = {
  __name: "misc-open-in-list",
  setup(__props) {
    const tiles = [
      { img: "keep.png", title: "Keep" },
      { img: "inbox.png", title: "Inbox" },
      { img: "hangouts.png", title: "Hangouts" },
      { img: "messenger.png", title: "Messenger" },
      { img: "google.png", title: "Google+" }
    ];
    const sheet = ref(false);
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_list_subheader = resolveComponent("v-list-subheader");
      const _component_v_list_item = resolveComponent("v-list-item");
      const _component_v_list = resolveComponent("v-list");
      const _component_v_bottom_sheet = resolveComponent("v-bottom-sheet");
      return openBlock(), createBlock(_component_v_bottom_sheet, {
        modelValue: sheet.value,
        "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => sheet.value = $event)
      }, {
        activator: withCtx(({ props }) => [
          createBaseVNode("div", _hoisted_1$4, [
            createVNode(_component_v_btn, mergeProps(props, {
              color: "purple",
              size: "x-large",
              text: "Click Me"
            }), null, 16)
          ])
        ]),
        default: withCtx(() => [
          createVNode(_component_v_list, null, {
            default: withCtx(() => [
              createVNode(_component_v_list_subheader, null, {
                default: withCtx(() => [
                  createTextVNode("Open in")
                ]),
                _: 1
              }),
              (openBlock(), createElementBlock(Fragment, null, renderList(tiles, (tile) => {
                return createVNode(_component_v_list_item, {
                  key: tile.title,
                  "prepend-avatar": `https://cdn.vuetifyjs.com/images/bottom-sheets/${tile.img}`,
                  title: tile.title,
                  onClick: _cache[0] || (_cache[0] = ($event) => sheet.value = false)
                }, null, 8, ["prepend-avatar", "title"]);
              }), 64))
            ]),
            _: 1
          })
        ]),
        _: 1
      }, 8, ["modelValue"]);
    };
  }
};
const __0 = _sfc_main$4;
const __0_raw = `<template>
  <v-bottom-sheet v-model="sheet">
    <template v-slot:activator="{ props }">
      <div class="text-center">
        <v-btn
          v-bind="props"
          color="purple"
          size="x-large"
          text="Click Me"
        ></v-btn>
      </div>
    </template>

    <v-list>
      <v-list-subheader>Open in</v-list-subheader>

      <v-list-item
        v-for="tile in tiles"
        :key="tile.title"
        :prepend-avatar="\`https://cdn.vuetifyjs.com/images/bottom-sheets/\${tile.img}\`"
        :title="tile.title"
        @click="sheet = false"
      ></v-list-item>
    </v-list>
  </v-bottom-sheet>
</template>

<script setup>
  import { ref } from 'vue'

  const tiles = [
    { img: 'keep.png', title: 'Keep' },
    { img: 'inbox.png', title: 'Inbox' },
    { img: 'hangouts.png', title: 'Hangouts' },
    { img: 'messenger.png', title: 'Messenger' },
    { img: 'google.png', title: 'Google+' },
  ]

  const sheet = ref(false)
<\/script>

<script>
  export default {
    data: () => ({
      sheet: false,
      tiles: [
        { img: 'keep.png', title: 'Keep' },
        { img: 'inbox.png', title: 'Inbox' },
        { img: 'hangouts.png', title: 'Hangouts' },
        { img: 'messenger.png', title: 'Messenger' },
        { img: 'google.png', title: 'Google+' },
      ],
    }),
  }
<\/script>
`;
const _hoisted_1$3 = { class: "text-center" };
const _sfc_main$3 = {
  __name: "misc-player",
  setup(__props) {
    const display = useDisplay();
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_progress_linear = resolveComponent("v-progress-linear");
      const _component_v_list_item_title = resolveComponent("v-list-item-title");
      const _component_v_list_item_subtitle = resolveComponent("v-list-item-subtitle");
      const _component_v_list_item = resolveComponent("v-list-item");
      const _component_v_list = resolveComponent("v-list");
      const _component_v_sheet = resolveComponent("v-sheet");
      const _component_v_bottom_sheet = resolveComponent("v-bottom-sheet");
      return openBlock(), createBlock(_component_v_bottom_sheet, { inset: "" }, {
        activator: withCtx(({ props }) => [
          createBaseVNode("div", _hoisted_1$3, [
            createVNode(_component_v_btn, mergeProps(props, {
              color: "red",
              size: "x-large",
              text: "Click Me"
            }), null, 16)
          ])
        ]),
        default: withCtx(() => [
          createVNode(_component_v_sheet, null, {
            default: withCtx(() => [
              createVNode(_component_v_progress_linear, { "model-value": "50" }),
              createVNode(_component_v_list, null, {
                default: withCtx(() => [
                  createVNode(_component_v_list_item, null, {
                    append: withCtx(() => [
                      createVNode(_component_v_btn, {
                        icon: "mdi-rewind",
                        variant: "text"
                      }),
                      createVNode(_component_v_btn, {
                        class: normalizeClass({ "mx-5": unref(display).mdAndUp.value }),
                        icon: "mdi-pause",
                        variant: "text"
                      }, null, 8, ["class"]),
                      createVNode(_component_v_btn, {
                        class: normalizeClass([{ "me-3": unref(display).mdAndUp.value }, "ms-0"]),
                        icon: "mdi-fast-forward",
                        variant: "text"
                      }, null, 8, ["class"])
                    ]),
                    default: withCtx(() => [
                      createVNode(_component_v_list_item_title, null, {
                        default: withCtx(() => [
                          createTextVNode("The Walker")
                        ]),
                        _: 1
                      }),
                      createVNode(_component_v_list_item_subtitle, null, {
                        default: withCtx(() => [
                          createTextVNode("Fitz & The Trantrums")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __1 = _sfc_main$3;
const __1_raw = `<template>
  <v-bottom-sheet inset>
    <template v-slot:activator="{ props }">
      <div class="text-center">
        <v-btn
          v-bind="props"
          color="red"
          size="x-large"
          text="Click Me"
        ></v-btn>
      </div>
    </template>

    <v-sheet>
      <v-progress-linear model-value="50"></v-progress-linear>

      <v-list>
        <v-list-item>
          <v-list-item-title>The Walker</v-list-item-title>

          <v-list-item-subtitle>Fitz & The Trantrums</v-list-item-subtitle>

          <template v-slot:append>
            <v-btn
              icon="mdi-rewind"
              variant="text"
            ></v-btn>

            <v-btn
              :class="{ 'mx-5': display.mdAndUp.value }"
              icon="mdi-pause"
              variant="text"
            ></v-btn>

            <v-btn
              :class="{ 'me-3': display.mdAndUp.value }"
              class="ms-0"
              icon="mdi-fast-forward"
              variant="text"
            ></v-btn>
          </template>
        </v-list-item>
      </v-list>
    </v-sheet>
  </v-bottom-sheet>
</template>

<script setup>
  import { useDisplay } from 'vuetify'

  const display = useDisplay()
<\/script>

<script>
  export default {
    computed: {
      display () {
        return this.$vuetify.display
      },
    },
  }
<\/script>
`;
const _hoisted_1$2 = { class: "text-center" };
const _hoisted_2$1 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_3$1 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_4$1 = /* @__PURE__ */ createBaseVNode("div", null, " This is a bottom sheet that is using the inset prop ", -1);
const _sfc_main$2 = {
  __name: "prop-inset",
  setup(__props) {
    const sheet = ref(false);
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_card_text = resolveComponent("v-card-text");
      const _component_v_card = resolveComponent("v-card");
      const _component_v_bottom_sheet = resolveComponent("v-bottom-sheet");
      return openBlock(), createElementBlock("div", _hoisted_1$2, [
        createVNode(_component_v_btn, {
          size: "x-large",
          text: "Click Me",
          onClick: _cache[0] || (_cache[0] = ($event) => sheet.value = !sheet.value)
        }),
        createVNode(_component_v_bottom_sheet, {
          modelValue: sheet.value,
          "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => sheet.value = $event),
          inset: ""
        }, {
          default: withCtx(() => [
            createVNode(_component_v_card, {
              class: "text-center",
              height: "200"
            }, {
              default: withCtx(() => [
                createVNode(_component_v_card_text, null, {
                  default: withCtx(() => [
                    createVNode(_component_v_btn, {
                      variant: "text",
                      onClick: _cache[1] || (_cache[1] = ($event) => sheet.value = !sheet.value)
                    }, {
                      default: withCtx(() => [
                        createTextVNode(" close ")
                      ]),
                      _: 1
                    }),
                    _hoisted_2$1,
                    _hoisted_3$1,
                    _hoisted_4$1
                  ]),
                  _: 1
                })
              ]),
              _: 1
            })
          ]),
          _: 1
        }, 8, ["modelValue"])
      ]);
    };
  }
};
const __2 = _sfc_main$2;
const __2_raw = `<template>
  <div class="text-center">
    <v-btn
      size="x-large"
      text="Click Me"
      @click="sheet = !sheet"
    ></v-btn>

    <v-bottom-sheet v-model="sheet" inset>
      <v-card
        class="text-center"
        height="200"
      >
        <v-card-text>
          <v-btn
            variant="text"
            @click="sheet = !sheet"
          >
            close
          </v-btn>

          <br>
          <br>

          <div>
            This is a bottom sheet that is using the inset prop
          </div>
        </v-card-text>
      </v-card>
    </v-bottom-sheet>
  </div>
</template>

<script setup>
  import { ref } from 'vue'

  const sheet = ref(false)
<\/script>

<script>
  export default {
    data: () => ({
      sheet: false,
    }),
  }
<\/script>
`;
const _hoisted_1$1 = { class: "text-center" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("div", null, " This is a bottom sheet using the controlled by v-model instead of activator ", -1);
const _sfc_main$1 = {
  __name: "prop-model",
  setup(__props) {
    const sheet = ref(false);
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_card_text = resolveComponent("v-card-text");
      const _component_v_card = resolveComponent("v-card");
      const _component_v_bottom_sheet = resolveComponent("v-bottom-sheet");
      return openBlock(), createElementBlock("div", _hoisted_1$1, [
        createVNode(_component_v_btn, {
          size: "x-large",
          text: "Click Me",
          onClick: _cache[0] || (_cache[0] = ($event) => sheet.value = !sheet.value)
        }),
        createVNode(_component_v_bottom_sheet, {
          modelValue: sheet.value,
          "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => sheet.value = $event)
        }, {
          default: withCtx(() => [
            createVNode(_component_v_card, {
              class: "text-center",
              height: "200"
            }, {
              default: withCtx(() => [
                createVNode(_component_v_card_text, null, {
                  default: withCtx(() => [
                    createVNode(_component_v_btn, {
                      variant: "text",
                      onClick: _cache[1] || (_cache[1] = ($event) => sheet.value = !sheet.value)
                    }, {
                      default: withCtx(() => [
                        createTextVNode(" close ")
                      ]),
                      _: 1
                    }),
                    _hoisted_2,
                    _hoisted_3,
                    _hoisted_4
                  ]),
                  _: 1
                })
              ]),
              _: 1
            })
          ]),
          _: 1
        }, 8, ["modelValue"])
      ]);
    };
  }
};
const __3 = _sfc_main$1;
const __3_raw = `<template>
  <div class="text-center">
    <v-btn
      size="x-large"
      text="Click Me"
      @click="sheet = !sheet"
    ></v-btn>

    <v-bottom-sheet v-model="sheet">
      <v-card
        class="text-center"
        height="200"
      >
        <v-card-text>
          <v-btn
            variant="text"
            @click="sheet = !sheet"
          >
            close
          </v-btn>

          <br>
          <br>

          <div>
            This is a bottom sheet using the controlled by v-model instead of activator
          </div>
        </v-card-text>
      </v-card>
    </v-bottom-sheet>
  </div>
</template>

<script setup>
  import { ref } from 'vue'

  const sheet = ref(false)
<\/script>

<script>
  export default {
    data: () => ({
      sheet: false,
    }),
  }
<\/script>
`;
const _hoisted_1 = { class: "pa-2 text-center" };
const name = "v-bottom-sheet";
const _sfc_main = {
  __name: "usage",
  setup(__props) {
    const model = ref("default");
    const options = ["inset"];
    const props = computed(() => {
      return {
        inset: model.value === "inset" || void 0
      };
    });
    const slots = computed(() => {
      return `
  <template v-slot:activator="{ props }">
    <v-btn v-bind="props" text="Click Me"></v-btn>
  </template>

  <v-card
    title="Bottom Sheet"
    text="Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ut, eos? Nulla aspernatur odio rem, culpa voluptatibus eius debitis dolorem perspiciatis asperiores sed consectetur praesentium! Delectus et iure maxime eaque exercitationem!"
  ></v-card>
`;
    });
    const code = computed(() => {
      return `<v-bottom-sheet${propsToString(props.value)}>${slots.value}</v-bottom-sheet>`;
    });
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_card = resolveComponent("v-card");
      const _component_v_bottom_sheet = resolveComponent("v-bottom-sheet");
      const _component_ExamplesUsageExample = _sfc_main$5;
      return openBlock(), createBlock(_component_ExamplesUsageExample, {
        modelValue: unref(model),
        "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(model) ? model.value = $event : null),
        code: unref(code),
        name,
        options
      }, {
        default: withCtx(() => [
          createVNode(_component_v_bottom_sheet, normalizeProps(guardReactiveProps(unref(props))), {
            activator: withCtx(({ props: activatorProps }) => [
              createBaseVNode("div", _hoisted_1, [
                createVNode(_component_v_btn, mergeProps(activatorProps, {
                  size: "x-large",
                  text: "Click Me"
                }), null, 16)
              ])
            ]),
            default: withCtx(() => [
              createVNode(_component_v_card, {
                text: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ut, eos? Nulla aspernatur odio rem, culpa voluptatibus eius debitis dolorem perspiciatis asperiores sed consectetur praesentium! Delectus et iure maxime eaque exercitationem!",
                title: "Bottom Sheet"
              })
            ]),
            _: 1
          }, 16)
        ]),
        _: 1
      }, 8, ["modelValue", "code"]);
    };
  }
};
const __4 = _sfc_main;
const __4_raw = `<template>
  <ExamplesUsageExample
    v-model="model"
    :code="code"
    :name="name"
    :options="options"
  >
    <v-bottom-sheet
      v-bind="props"
    >
      <template v-slot:activator="{ props: activatorProps }">
        <div class="pa-2 text-center">
          <v-btn
            v-bind="activatorProps"
            size="x-large"
            text="Click Me"
          ></v-btn>
        </div>
      </template>

      <v-card
        text="Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ut, eos? Nulla aspernatur odio rem, culpa voluptatibus eius debitis dolorem perspiciatis asperiores sed consectetur praesentium! Delectus et iure maxime eaque exercitationem!"
        title="Bottom Sheet"
      ></v-card>
    </v-bottom-sheet>
  </ExamplesUsageExample>
</template>

<script setup>
  const name = 'v-bottom-sheet'
  const model = ref('default')
  const options = ['inset']

  const props = computed(() => {
    return {
      inset: model.value === 'inset' || undefined,
    }
  })

  const slots = computed(() => {
    return \`
  <template v-slot:activator="{ props }">
    <v-btn v-bind="props" text="Click Me"></v-btn>
  </template>

  <v-card
    title="Bottom Sheet"
    text="Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ut, eos? Nulla aspernatur odio rem, culpa voluptatibus eius debitis dolorem perspiciatis asperiores sed consectetur praesentium! Delectus et iure maxime eaque exercitationem!"
  ></v-card>
\`
  })

  const code = computed(() => {
    return \`<v-bottom-sheet\${propsToString(props.value)}>\${slots.value}</v-bottom-sheet>\`
  })
<\/script>
`;
const vBottomSheet = {
  "misc-open-in-list": {
    component: __0,
    source: __0_raw
  },
  "misc-player": {
    component: __1,
    source: __1_raw
  },
  "prop-inset": {
    component: __2,
    source: __2_raw
  },
  "prop-model": {
    component: __3,
    source: __3_raw
  },
  "usage": {
    component: __4,
    source: __4_raw
  }
};
export {
  vBottomSheet as default
};
