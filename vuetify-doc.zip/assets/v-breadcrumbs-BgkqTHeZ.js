import { r as resolveComponent, o as openBlock, l as createElementBlock, b as createVNode, w as withCtx, c as createBlock, h as createTextVNode, t as toDisplayString, J as ref, j as computed, ag as propsToString, f as unref, E as isRef, e as createBaseVNode, ak as normalizeProps, al as guardReactiveProps } from "./index-DGybHjCP.js";
import { _ as _sfc_main$6 } from "./UsageExample-M8CmNipa.js";
const _sfc_main$5 = {
  __name: "prop-divider",
  setup(__props) {
    const items = [
      {
        title: "Dashboard",
        disabled: false,
        href: "breadcrumbs_dashboard"
      },
      {
        title: "Link 1",
        disabled: false,
        href: "breadcrumbs_link_1"
      },
      {
        title: "Link 2",
        disabled: true,
        href: "breadcrumbs_link_2"
      }
    ];
    return (_ctx, _cache) => {
      const _component_v_breadcrumbs = resolveComponent("v-breadcrumbs");
      return openBlock(), createElementBlock("div", null, [
        createVNode(_component_v_breadcrumbs, {
          items,
          divider: "-"
        }),
        createVNode(_component_v_breadcrumbs, {
          items,
          divider: "."
        })
      ]);
    };
  }
};
const __0 = _sfc_main$5;
const __0_raw = `<template>
  <div>
    <v-breadcrumbs
      :items="items"
      divider="-"
    ></v-breadcrumbs>

    <v-breadcrumbs
      :items="items"
      divider="."
    ></v-breadcrumbs>
  </div>
</template>

<script setup>
  const items = [
    {
      title: 'Dashboard',
      disabled: false,
      href: 'breadcrumbs_dashboard',
    },
    {
      title: 'Link 1',
      disabled: false,
      href: 'breadcrumbs_link_1',
    },
    {
      title: 'Link 2',
      disabled: true,
      href: 'breadcrumbs_link_2',
    },
  ]
<\/script>

<script>
  export default {
    data: () => ({
      items: [
        {
          title: 'Dashboard',
          disabled: false,
          href: 'breadcrumbs_dashboard',
        },
        {
          title: 'Link 1',
          disabled: false,
          href: 'breadcrumbs_link_1',
        },
        {
          title: 'Link 2',
          disabled: true,
          href: 'breadcrumbs_link_2',
        },
      ],
    }),
  }
<\/script>
`;
const _sfc_main$4 = {
  __name: "prop-large",
  setup(__props) {
    const items = [
      {
        title: "Dashboard",
        disabled: false,
        href: "breadcrumbs_dashboard"
      },
      {
        title: "Link 1",
        disabled: false,
        href: "breadcrumbs_link_1"
      },
      {
        title: "Link 2",
        disabled: true,
        href: "breadcrumbs_link_2"
      }
    ];
    return (_ctx, _cache) => {
      const _component_v_breadcrumbs = resolveComponent("v-breadcrumbs");
      return openBlock(), createElementBlock("div", null, [
        createVNode(_component_v_breadcrumbs, { items }),
        createVNode(_component_v_breadcrumbs, {
          items,
          large: ""
        })
      ]);
    };
  }
};
const __1 = _sfc_main$4;
const __1_raw = `<template>
  <div>
    <v-breadcrumbs :items="items"></v-breadcrumbs>

    <v-breadcrumbs
      :items="items"
      large
    ></v-breadcrumbs>
  </div>
</template>

<script setup>
  const items = [
    {
      title: 'Dashboard',
      disabled: false,
      href: 'breadcrumbs_dashboard',
    },
    {
      title: 'Link 1',
      disabled: false,
      href: 'breadcrumbs_link_1',
    },
    {
      title: 'Link 2',
      disabled: true,
      href: 'breadcrumbs_link_2',
    },
  ]
<\/script>

<script>
  export default {
    data: () => ({
      items: [
        {
          title: 'Dashboard',
          disabled: false,
          href: 'breadcrumbs_dashboard',
        },
        {
          title: 'Link 1',
          disabled: false,
          href: 'breadcrumbs_link_1',
        },
        {
          title: 'Link 2',
          disabled: true,
          href: 'breadcrumbs_link_2',
        },
      ],
    }),
  }
<\/script>
`;
const _sfc_main$3 = {
  __name: "slot-icon-dividers",
  setup(__props) {
    const items = [
      {
        title: "Dashboard",
        disabled: false,
        href: "breadcrumbs_dashboard"
      },
      {
        title: "Link 1",
        disabled: false,
        href: "breadcrumbs_link_1"
      },
      {
        title: "Link 2",
        disabled: true,
        href: "breadcrumbs_link_2"
      }
    ];
    return (_ctx, _cache) => {
      const _component_v_icon = resolveComponent("v-icon");
      const _component_v_breadcrumbs = resolveComponent("v-breadcrumbs");
      return openBlock(), createElementBlock("div", null, [
        createVNode(_component_v_breadcrumbs, { items }, {
          divider: withCtx(() => [
            createVNode(_component_v_icon, { icon: "mdi-forward" })
          ]),
          _: 1
        }),
        createVNode(_component_v_breadcrumbs, { items }, {
          divider: withCtx(() => [
            createVNode(_component_v_icon, { icon: "mdi-chevron-right" })
          ]),
          _: 1
        })
      ]);
    };
  }
};
const __2 = _sfc_main$3;
const __2_raw = `<template>
  <div>
    <v-breadcrumbs :items="items">
      <template v-slot:divider>
        <v-icon icon="mdi-forward"></v-icon>
      </template>
    </v-breadcrumbs>

    <v-breadcrumbs :items="items">
      <template v-slot:divider>
        <v-icon icon="mdi-chevron-right"></v-icon>
      </template>
    </v-breadcrumbs>
  </div>
</template>

<script setup>
  const items = [
    {
      title: 'Dashboard',
      disabled: false,
      href: 'breadcrumbs_dashboard',
    },
    {
      title: 'Link 1',
      disabled: false,
      href: 'breadcrumbs_link_1',
    },
    {
      title: 'Link 2',
      disabled: true,
      href: 'breadcrumbs_link_2',
    },
  ]
<\/script>

<script>
  export default {
    data: () => ({
      items: [
        {
          title: 'Dashboard',
          disabled: false,
          href: 'breadcrumbs_dashboard',
        },
        {
          title: 'Link 1',
          disabled: false,
          href: 'breadcrumbs_link_1',
        },
        {
          title: 'Link 2',
          disabled: true,
          href: 'breadcrumbs_link_2',
        },
      ],
    }),
  }
<\/script>
`;
const _sfc_main$2 = {
  __name: "slot-prepend",
  setup(__props) {
    const items = [
      {
        title: "Dashboard",
        disabled: false,
        href: "breadcrumbs_dashboard"
      },
      {
        title: "Link 1",
        disabled: false,
        href: "breadcrumbs_link_1"
      },
      {
        title: "Link 2",
        disabled: true,
        href: "breadcrumbs_link_2"
      }
    ];
    return (_ctx, _cache) => {
      const _component_v_icon = resolveComponent("v-icon");
      const _component_v_breadcrumbs = resolveComponent("v-breadcrumbs");
      return openBlock(), createBlock(_component_v_breadcrumbs, { items }, {
        prepend: withCtx(() => [
          createVNode(_component_v_icon, {
            icon: "$vuetify",
            size: "small"
          })
        ]),
        _: 1
      });
    };
  }
};
const __3 = _sfc_main$2;
const __3_raw = `<template>
  <v-breadcrumbs :items="items">
    <template v-slot:prepend>
      <v-icon icon="$vuetify" size="small"></v-icon>
    </template>
  </v-breadcrumbs>
</template>

<script setup>
  const items = [
    {
      title: 'Dashboard',
      disabled: false,
      href: 'breadcrumbs_dashboard',
    },
    {
      title: 'Link 1',
      disabled: false,
      href: 'breadcrumbs_link_1',
    },
    {
      title: 'Link 2',
      disabled: true,
      href: 'breadcrumbs_link_2',
    },
  ]
<\/script>

<script>
  export default {
    data: () => ({
      items: [
        {
          title: 'Dashboard',
          disabled: false,
          href: 'breadcrumbs_dashboard',
        },
        {
          title: 'Link 1',
          disabled: false,
          href: 'breadcrumbs_link_1',
        },
        {
          title: 'Link 2',
          disabled: true,
          href: 'breadcrumbs_link_2',
        },
      ],
    }),
  }
<\/script>
`;
const _sfc_main$1 = {
  __name: "slot-title",
  setup(__props) {
    const items = [
      {
        title: "Dashboard",
        disabled: false,
        href: "breadcrumbs_dashboard"
      },
      {
        title: "Link 1",
        disabled: false,
        href: "breadcrumbs_link_1"
      },
      {
        title: "Link 2",
        disabled: true,
        href: "breadcrumbs_link_2"
      }
    ];
    return (_ctx, _cache) => {
      const _component_v_breadcrumbs = resolveComponent("v-breadcrumbs");
      return openBlock(), createBlock(_component_v_breadcrumbs, { items }, {
        title: withCtx(({ item }) => [
          createTextVNode(toDisplayString(item.title.toUpperCase()), 1)
        ]),
        _: 1
      });
    };
  }
};
const __4 = _sfc_main$1;
const __4_raw = `<template>
  <v-breadcrumbs :items="items">
    <template v-slot:title="{ item }">
      {{ item.title.toUpperCase() }}
    </template>
  </v-breadcrumbs>
</template>

<script setup>
  const items = [
    {
      title: 'Dashboard',
      disabled: false,
      href: 'breadcrumbs_dashboard',
    },
    {
      title: 'Link 1',
      disabled: false,
      href: 'breadcrumbs_link_1',
    },
    {
      title: 'Link 2',
      disabled: true,
      href: 'breadcrumbs_link_2',
    },
  ]
<\/script>

<script>
  export default {
    data: () => ({
      items: [
        {
          title: 'Dashboard',
          disabled: false,
          href: 'breadcrumbs_dashboard',
        },
        {
          title: 'Link 1',
          disabled: false,
          href: 'breadcrumbs_link_1',
        },
        {
          title: 'Link 2',
          disabled: true,
          href: 'breadcrumbs_link_2',
        },
      ],
    }),
  }
<\/script>
`;
const name = "v-breadcrumbs";
const _sfc_main = {
  __name: "usage",
  setup(__props) {
    const model = ref("default");
    const options = [];
    const color = ref();
    const props = computed(() => {
      return {
        "bg-color": color.value || void 0,
        items: ["Foo", "Bar", "Fizz"]
      };
    });
    const slots = computed(() => {
      return ``;
    });
    const code = computed(() => {
      return `<${name}${propsToString(props.value)}>${slots.value}</${name}>`;
    });
    return (_ctx, _cache) => {
      const _component_v_breadcrumbs = resolveComponent("v-breadcrumbs");
      const _component_v_select = resolveComponent("v-select");
      const _component_ExamplesUsageExample = _sfc_main$6;
      return openBlock(), createBlock(_component_ExamplesUsageExample, {
        modelValue: unref(model),
        "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(model) ? model.value = $event : null),
        code: unref(code),
        name,
        options
      }, {
        configuration: withCtx(() => [
          createVNode(_component_v_select, {
            modelValue: unref(color),
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(color) ? color.value = $event : null),
            items: ["primary", "success", "info"],
            label: "Background color",
            clearable: ""
          }, null, 8, ["modelValue"])
        ]),
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createVNode(_component_v_breadcrumbs, normalizeProps(guardReactiveProps(unref(props))), null, 16)
          ])
        ]),
        _: 1
      }, 8, ["modelValue", "code"]);
    };
  }
};
const __5 = _sfc_main;
const __5_raw = `<template>
  <ExamplesUsageExample
    v-model="model"
    :code="code"
    :name="name"
    :options="options"
  >
    <div>
      <v-breadcrumbs v-bind="props">
        <!-- <v-breadcrumbs-item>Item</v-breadcrumbs-item>

        <v-breadcrumbs-divider></v-breadcrumbs-divider>

        <v-breadcrumbs-item active>Item 2</v-breadcrumbs-item>

        <v-breadcrumbs-divider></v-breadcrumbs-divider>

        <v-breadcrumbs-item disabled>Item 3</v-breadcrumbs-item> -->
      </v-breadcrumbs>
    </div>

    <template v-slot:configuration>
      <v-select v-model="color" :items="['primary', 'success', 'info']" label="Background color" clearable></v-select>
    </template>
  </ExamplesUsageExample>
</template>

<script setup>
  const name = 'v-breadcrumbs'
  const model = ref('default')
  const options = []
  const color = ref()
  const props = computed(() => {
    return {
      'bg-color': color.value || undefined,
      items: ['Foo', 'Bar', 'Fizz'],
    }
  })

  const slots = computed(() => {
    return \`\`
  })

  const code = computed(() => {
    return \`<\${name}\${propsToString(props.value)}>\${slots.value}</\${name}>\`
  })
<\/script>
`;
const vBreadcrumbs = {
  "prop-divider": {
    component: __0,
    source: __0_raw
  },
  "prop-large": {
    component: __1,
    source: __1_raw
  },
  "slot-icon-dividers": {
    component: __2,
    source: __2_raw
  },
  "slot-prepend": {
    component: __3,
    source: __3_raw
  },
  "slot-title": {
    component: __4,
    source: __4_raw
  },
  "usage": {
    component: __5,
    source: __5_raw
  }
};
export {
  vBreadcrumbs as default
};
