import { y as _export_sfc, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, h as createTextVNode, b as createVNode, J as ref, l as createElementBlock, e as createBaseVNode, a9 as mergeProps, q as createCommentVNode, F as Fragment, v as renderList, B as shallowRef, O as watch, j as computed, ag as propsToString, f as unref, E as isRef, ak as normalizeProps, al as guardReactiveProps, S as createSlots } from "./index-DGybHjCP.js";
import { _ as _sfc_main$v } from "./UsageExample-M8CmNipa.js";
const _sfc_main$u = {};
function _sfc_render$j(_ctx, _cache) {
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_banner = resolveComponent("v-banner");
  return openBlock(), createBlock(_component_v_banner, { lines: "one" }, {
    text: withCtx(() => [
      createTextVNode(" Banner with one line of text. ")
    ]),
    actions: withCtx(() => [
      createVNode(_component_v_btn, null, {
        default: withCtx(() => [
          createTextVNode(" Action ")
        ]),
        _: 1
      }),
      createVNode(_component_v_btn, null, {
        default: withCtx(() => [
          createTextVNode(" Action ")
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __0 = /* @__PURE__ */ _export_sfc(_sfc_main$u, [["render", _sfc_render$j]]);
const __0_raw = '<template>\n  <v-banner\n    lines="one"\n  >\n    <template v-slot:text>\n      Banner with one line of text.\n    </template>\n\n    <template v-slot:actions>\n      <v-btn>\n        Action\n      </v-btn>\n\n      <v-btn>\n        Action\n      </v-btn>\n    </template>\n  </v-banner>\n</template>\n';
const _sfc_main$t = {
  __name: "defaults-bottom-navigation",
  setup(__props) {
    const value = ref(0);
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_bottom_navigation = resolveComponent("v-bottom-navigation");
      const _component_v_layout = resolveComponent("v-layout");
      return openBlock(), createBlock(_component_v_layout, {
        class: "overflow-visible",
        style: { "height": "56px" }
      }, {
        default: withCtx(() => [
          createVNode(_component_v_bottom_navigation, {
            modelValue: value.value,
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => value.value = $event),
            active: ""
          }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, null, {
                default: withCtx(() => [
                  createTextVNode("Home")
                ]),
                _: 1
              }),
              createVNode(_component_v_btn, null, {
                default: withCtx(() => [
                  createTextVNode("Recents")
                ]),
                _: 1
              }),
              createVNode(_component_v_btn, null, {
                default: withCtx(() => [
                  createTextVNode("Favorites")
                ]),
                _: 1
              })
            ]),
            _: 1
          }, 8, ["modelValue"])
        ]),
        _: 1
      });
    };
  }
};
const __1 = _sfc_main$t;
const __1_raw = `<template>
  <v-layout
    class="overflow-visible"
    style="height: 56px;"
  >
    <v-bottom-navigation
      v-model="value"
      active
    >
      <v-btn>Home</v-btn>

      <v-btn>Recents</v-btn>

      <v-btn>Favorites</v-btn>
    </v-bottom-navigation>
  </v-layout>
</template>

<script setup>
  import { ref } from 'vue'

  const value = ref(0)
<\/script>

<script>
  export default {
    data: () => ({ value: 0 }),
  }
<\/script>
`;
const _hoisted_1$f = { class: "d-flex align-center flex-column pa-6" };
const _sfc_main$s = {
  __name: "defaults-btn-group",
  setup(__props) {
    const toggle = ref(null);
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_btn_toggle = resolveComponent("v-btn-toggle");
      return openBlock(), createElementBlock("div", _hoisted_1$f, [
        createVNode(_component_v_btn_toggle, {
          modelValue: toggle.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => toggle.value = $event),
          variant: "outlined",
          divided: ""
        }, {
          default: withCtx(() => [
            createVNode(_component_v_btn, { icon: "mdi-format-align-left" }),
            createVNode(_component_v_btn, { icon: "mdi-format-align-center" }),
            createVNode(_component_v_btn, { icon: "mdi-format-align-right" }),
            createVNode(_component_v_btn, { icon: "mdi-format-align-justify" })
          ]),
          _: 1
        }, 8, ["modelValue"])
      ]);
    };
  }
};
const __2 = _sfc_main$s;
const __2_raw = `<template>
  <div class="d-flex align-center flex-column pa-6">
    <v-btn-toggle
      v-model="toggle"
      variant="outlined"
      divided
    >
      <v-btn icon="mdi-format-align-left"></v-btn>
      <v-btn icon="mdi-format-align-center"></v-btn>
      <v-btn icon="mdi-format-align-right"></v-btn>
      <v-btn icon="mdi-format-align-justify"></v-btn>
    </v-btn-toggle>
  </div>
</template>

<script setup>
  import { ref } from 'vue'

  const toggle = ref(null)
<\/script>

<script>
  export default {
    data: () => ({
      toggle: null,
    }),
  }
<\/script>
`;
const _sfc_main$r = {};
function _sfc_render$i(_ctx, _cache) {
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_card_actions = resolveComponent("v-card-actions");
  const _component_v_card = resolveComponent("v-card");
  return openBlock(), createBlock(_component_v_card, {
    class: "mx-auto",
    "max-width": "500",
    text: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!",
    title: "Card title"
  }, {
    default: withCtx(() => [
      createVNode(_component_v_card_actions, null, {
        default: withCtx(() => [
          createVNode(_component_v_btn, null, {
            default: withCtx(() => [
              createTextVNode("Action Button")
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __3 = /* @__PURE__ */ _export_sfc(_sfc_main$r, [["render", _sfc_render$i]]);
const __3_raw = '<template>\n  <v-card\n    class="mx-auto"\n    max-width="500"\n    text="Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!"\n    title="Card title"\n  >\n    <v-card-actions>\n      <v-btn>Action Button</v-btn>\n    </v-card-actions>\n  </v-card>\n</template>\n';
const _hoisted_1$e = { class: "position-absolute d-flex align-center justify-center w-100 h-100" };
const _sfc_main$q = {
  __name: "defaults-snackbar",
  setup(__props) {
    const snackbar = ref(false);
    function onClick() {
      snackbar.value = false;
    }
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_snackbar = resolveComponent("v-snackbar");
      const _component_v_sheet = resolveComponent("v-sheet");
      return openBlock(), createBlock(_component_v_sheet, {
        class: "position-relative",
        "min-height": "100"
      }, {
        default: withCtx(() => [
          createBaseVNode("div", _hoisted_1$e, [
            createVNode(_component_v_btn, {
              size: "x-large",
              onClick: _cache[0] || (_cache[0] = ($event) => snackbar.value = !snackbar.value)
            }, {
              default: withCtx(() => [
                createTextVNode(" Toggle Snackbar ")
              ]),
              _: 1
            })
          ]),
          createVNode(_component_v_snackbar, {
            modelValue: snackbar.value,
            "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => snackbar.value = $event),
            location: "center"
          }, {
            actions: withCtx(() => [
              createVNode(_component_v_btn, { onClick }, {
                default: withCtx(() => [
                  createTextVNode("Close")
                ]),
                _: 1
              })
            ]),
            default: withCtx(() => [
              createTextVNode(" Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem! ")
            ]),
            _: 1
          }, 8, ["modelValue"])
        ]),
        _: 1
      });
    };
  }
};
const __4 = _sfc_main$q;
const __4_raw = `<template>
  <v-sheet
    class="position-relative"
    min-height="100"
  >
    <div class="position-absolute d-flex align-center justify-center w-100 h-100">
      <v-btn
        size="x-large"
        @click="snackbar = !snackbar"
      >
        Toggle Snackbar
      </v-btn>
    </div>

    <v-snackbar
      v-model="snackbar"
      location="center"
    >
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!

      <template v-slot:actions>
        <v-btn @click="onClick">Close</v-btn>
      </template>
    </v-snackbar>
  </v-sheet>
</template>

<script setup>
  import { ref } from 'vue'

  const snackbar = ref(false)

  function onClick () {
    snackbar.value = false
  }
<\/script>

<script>
  export default {
    data: () => ({
      snackbar: false,
    }),

    methods: {
      onClick () {
        this.snackbar = false
      },
    },
  }
<\/script>
`;
const _sfc_main$p = {};
function _sfc_render$h(_ctx, _cache) {
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_toolbar_items = resolveComponent("v-toolbar-items");
  const _component_v_divider = resolveComponent("v-divider");
  const _component_v_toolbar = resolveComponent("v-toolbar");
  return openBlock(), createBlock(_component_v_toolbar, { title: "Toolbar" }, {
    default: withCtx(() => [
      createVNode(_component_v_toolbar_items, null, {
        default: withCtx(() => [
          createVNode(_component_v_btn, null, {
            default: withCtx(() => [
              createTextVNode("Dashboard")
            ]),
            _: 1
          }),
          createVNode(_component_v_btn, null, {
            default: withCtx(() => [
              createTextVNode("Resources")
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_divider, {
        class: "mx-2",
        vertical: ""
      }),
      createVNode(_component_v_btn, { icon: "mdi-dots-vertical" })
    ]),
    _: 1
  });
}
const __5 = /* @__PURE__ */ _export_sfc(_sfc_main$p, [["render", _sfc_render$h]]);
const __5_raw = '<template>\n  <v-toolbar title="Toolbar">\n    <v-toolbar-items>\n      <v-btn>Dashboard</v-btn>\n\n      <v-btn>Resources</v-btn>\n    </v-toolbar-items>\n\n    <v-divider class="mx-2" vertical></v-divider>\n\n    <v-btn icon="mdi-dots-vertical"></v-btn>\n  </v-toolbar>\n</template>\n';
const _hoisted_1$d = /* @__PURE__ */ createBaseVNode("a", {
  href: "https://www.iubenda.com/privacy-policy/76325752/cookie-policy",
  target: "_blank"
}, "Privacy Policy", -1);
const _hoisted_2$3 = /* @__PURE__ */ createBaseVNode("p", { class: "pb-4" }, " Vuetify websites use cookies to deliver and improve the visitor experience. Learn more about the cookies we use on our Cookie Policy page. ", -1);
const _hoisted_3$3 = /* @__PURE__ */ createBaseVNode("p", { class: "mb-4" }, "These cookies are required for the site to function and cannot be turned off.", -1);
const _hoisted_4$2 = /* @__PURE__ */ createBaseVNode("p", { class: "mb-4" }, "Counts website visits and clicks to understand where people most engage with links to make the experience better.", -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("p", { class: "mb-16" }, "Set by our advertising partners, these cookies are used to build a profile of your interests and show you relevant ads on other sites. They do not store personal information, but are based on uniquely identifying your browser and internet device.", -1);
const _sfc_main$o = {
  __name: "misc-cookie-settings",
  setup(__props) {
    const dialog = ref(false);
    const advertising = ref(true);
    const performance = ref(true);
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_list_subheader = resolveComponent("v-list-subheader");
      const _component_v_switch = resolveComponent("v-switch");
      const _component_v_card_text = resolveComponent("v-card-text");
      const _component_v_divider = resolveComponent("v-divider");
      const _component_v_card_actions = resolveComponent("v-card-actions");
      const _component_v_card = resolveComponent("v-card");
      const _component_v_dialog = resolveComponent("v-dialog");
      const _component_v_banner = resolveComponent("v-banner");
      return openBlock(), createBlock(_component_v_banner, {
        avatar: "https://cdn.vuetifyjs.com/docs/images/logos/v.svg",
        stacked: ""
      }, {
        text: withCtx(() => [
          createTextVNode(" Vuetify uses cookies to enable and import the use of the website. Please see our "),
          _hoisted_1$d,
          createTextVNode(' for more information. By clicking "Accept Cookies" or continuing to use the site, you agree to the use of cookies. ')
        ]),
        actions: withCtx(() => [
          createVNode(_component_v_dialog, {
            modelValue: dialog.value,
            "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => dialog.value = $event),
            "max-width": "500"
          }, {
            activator: withCtx(({ props }) => [
              createVNode(_component_v_btn, mergeProps({
                class: "text-none",
                color: "blue-darken-4",
                rounded: "0",
                variant: "outlined"
              }, props), {
                default: withCtx(() => [
                  createTextVNode(" Manage Cookies ")
                ]),
                _: 2
              }, 1040)
            ]),
            default: withCtx(() => [
              createVNode(_component_v_card, { title: "Cookie Settings" }, {
                default: withCtx(() => [
                  createVNode(_component_v_card_text, null, {
                    default: withCtx(() => [
                      _hoisted_2$3,
                      createVNode(_component_v_list_subheader, { class: "font-weight-black text-high-emphasis" }, {
                        default: withCtx(() => [
                          createTextVNode("Required Cookies")
                        ]),
                        _: 1
                      }),
                      _hoisted_3$3,
                      createVNode(_component_v_list_subheader, { class: "font-weight-black text-high-emphasis" }, {
                        default: withCtx(() => [
                          createTextVNode("Performance Cookies")
                        ]),
                        _: 1
                      }),
                      createVNode(_component_v_switch, {
                        modelValue: performance.value,
                        "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => performance.value = $event),
                        label: performance.value ? "On" : "Off",
                        color: "blue-darken-4",
                        density: "compact",
                        "hide-details": "",
                        inline: "",
                        inset: ""
                      }, null, 8, ["modelValue", "label"]),
                      _hoisted_4$2,
                      createVNode(_component_v_list_subheader, { class: "font-weight-black text-high-emphasis" }, {
                        default: withCtx(() => [
                          createTextVNode("Advertising Cookies")
                        ]),
                        _: 1
                      }),
                      createVNode(_component_v_switch, {
                        modelValue: advertising.value,
                        "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => advertising.value = $event),
                        label: advertising.value ? "On" : "Off",
                        color: "blue-darken-4",
                        density: "compact",
                        "hide-details": "",
                        inline: "",
                        inset: ""
                      }, null, 8, ["modelValue", "label"]),
                      _hoisted_5
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_divider),
                  createVNode(_component_v_card_actions, { class: "justify-center px-6 py-3" }, {
                    default: withCtx(() => [
                      createVNode(_component_v_btn, {
                        class: "flex-grow-1 text-none",
                        color: "blue-darken-4",
                        rounded: "0",
                        variant: "plain",
                        onClick: _cache[2] || (_cache[2] = ($event) => dialog.value = false)
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" Decline All ")
                        ]),
                        _: 1
                      }),
                      createVNode(_component_v_btn, {
                        class: "text-white flex-grow-1 text-none",
                        color: "blue-darken-4",
                        rounded: "0",
                        variant: "flat",
                        onClick: _cache[3] || (_cache[3] = ($event) => dialog.value = false)
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" Save and Accept ")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          }, 8, ["modelValue"]),
          createVNode(_component_v_btn, {
            class: "text-none ms-4 text-white",
            color: "blue-darken-4",
            rounded: "0",
            variant: "flat"
          }, {
            default: withCtx(() => [
              createTextVNode(" Accept Cookies ")
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __6 = _sfc_main$o;
const __6_raw = `<template>
  <v-banner
    avatar="https://cdn.vuetifyjs.com/docs/images/logos/v.svg"
    stacked
  >
    <template v-slot:text>
      Vuetify uses cookies to enable and import the use of the website. Please see our <a href="https://www.iubenda.com/privacy-policy/76325752/cookie-policy" target="_blank">Privacy Policy</a> for more information. By clicking "Accept Cookies" or continuing to use the site, you agree to the use of cookies.
    </template>

    <template v-slot:actions>
      <v-dialog v-model="dialog" max-width="500">
        <template v-slot:activator="{ props }">
          <v-btn
            class="text-none"
            color="blue-darken-4"
            rounded="0"
            variant="outlined"
            v-bind="props"
          >
            Manage Cookies
          </v-btn>
        </template>

        <v-card title="Cookie Settings">
          <v-card-text>
            <p class="pb-4">
              Vuetify websites use cookies to deliver and improve the visitor experience. Learn more about the cookies we use on our Cookie Policy page.
            </p>

            <v-list-subheader class="font-weight-black text-high-emphasis">Required Cookies</v-list-subheader>

            <p class="mb-4">These cookies are required for the site to function and cannot be turned off.</p>

            <v-list-subheader class="font-weight-black text-high-emphasis">Performance Cookies</v-list-subheader>

            <v-switch
              v-model="performance"
              :label="performance ? 'On' : 'Off'"
              color="blue-darken-4"
              density="compact"
              hide-details
              inline
              inset
            ></v-switch>

            <p class="mb-4">Counts website visits and clicks to understand where people most engage with links to make the experience better.</p>

            <v-list-subheader class="font-weight-black text-high-emphasis">Advertising Cookies</v-list-subheader>

            <v-switch
              v-model="advertising"
              :label="advertising ? 'On' : 'Off'"
              color="blue-darken-4"
              density="compact"
              hide-details
              inline
              inset
            ></v-switch>

            <p class="mb-16">Set by our advertising partners, these cookies are used to build a profile of your interests and show you relevant ads on other sites. They do not store personal information, but are based on uniquely identifying your browser and internet device.</p>
          </v-card-text>

          <v-divider></v-divider>

          <v-card-actions class="justify-center px-6 py-3">
            <v-btn
              class="flex-grow-1 text-none"
              color="blue-darken-4"
              rounded="0"
              variant="plain"
              @click="dialog=false"
            >
              Decline All
            </v-btn>

            <v-btn
              class="text-white flex-grow-1 text-none"
              color="blue-darken-4"
              rounded="0"
              variant="flat"
              @click="dialog=false"
            >
              Save and Accept
            </v-btn>
          </v-card-actions>
        </v-card>
      </v-dialog>

      <v-btn
        class="text-none ms-4 text-white"
        color="blue-darken-4"
        rounded="0"
        variant="flat"
      >
        Accept Cookies
      </v-btn>
    </template>
  </v-banner>
</template>

<script setup>
  import { ref } from 'vue'

  const dialog = ref(false)
  const advertising = ref(true)
  const performance = ref(true)
<\/script>

<script>
  export default {
    data: () => ({
      dialog: false,
      advertising: true,
      performance: true,
    }),
  }
<\/script>
`;
const _hoisted_1$c = { class: "position-absolute d-flex align-center justify-center w-100 h-100" };
const _hoisted_2$2 = { class: "py-12 text-center" };
const _hoisted_3$2 = /* @__PURE__ */ createBaseVNode("div", { class: "text-h4 font-weight-bold" }, "This receipt was sent", -1);
const _hoisted_4$1 = { class: "pa-4 text-end" };
const _sfc_main$n = {
  __name: "misc-dialog-action",
  setup(__props) {
    const dialog = ref(true);
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_divider = resolveComponent("v-divider");
      const _component_v_icon = resolveComponent("v-icon");
      const _component_v_card = resolveComponent("v-card");
      const _component_v_fade_transition = resolveComponent("v-fade-transition");
      const _component_v_sheet = resolveComponent("v-sheet");
      return openBlock(), createBlock(_component_v_sheet, {
        class: "position-relative",
        "min-height": "450"
      }, {
        default: withCtx(() => [
          createBaseVNode("div", _hoisted_1$c, [
            createVNode(_component_v_btn, {
              color: "deep-purple-darken-2",
              size: "x-large",
              onClick: _cache[0] || (_cache[0] = ($event) => dialog.value = !dialog.value)
            }, {
              default: withCtx(() => [
                createTextVNode(" Open Dialog ")
              ]),
              _: 1
            })
          ]),
          createVNode(_component_v_fade_transition, { "hide-on-leave": "" }, {
            default: withCtx(() => [
              dialog.value ? (openBlock(), createBlock(_component_v_card, {
                key: 0,
                "append-icon": "$close",
                class: "mx-auto",
                elevation: "16",
                "max-width": "500",
                title: "Send a receipt"
              }, {
                append: withCtx(() => [
                  createVNode(_component_v_btn, {
                    icon: "$close",
                    variant: "text",
                    onClick: _cache[1] || (_cache[1] = ($event) => dialog.value = false)
                  })
                ]),
                default: withCtx(() => [
                  createVNode(_component_v_divider),
                  createBaseVNode("div", _hoisted_2$2, [
                    createVNode(_component_v_icon, {
                      class: "mb-6",
                      color: "success",
                      icon: "mdi-check-circle-outline",
                      size: "128"
                    }),
                    _hoisted_3$2
                  ]),
                  createVNode(_component_v_divider),
                  createBaseVNode("div", _hoisted_4$1, [
                    createVNode(_component_v_btn, {
                      class: "text-none",
                      color: "medium-emphasis",
                      "min-width": "92",
                      variant: "outlined",
                      rounded: "",
                      onClick: _cache[2] || (_cache[2] = ($event) => dialog.value = false)
                    }, {
                      default: withCtx(() => [
                        createTextVNode(" Close ")
                      ]),
                      _: 1
                    })
                  ])
                ]),
                _: 1
              })) : createCommentVNode("", true)
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __7 = _sfc_main$n;
const __7_raw = `<template>
  <v-sheet
    class="position-relative"
    min-height="450"
  >
    <div class="position-absolute d-flex align-center justify-center w-100 h-100">
      <v-btn
        color="deep-purple-darken-2"
        size="x-large"
        @click="dialog = !dialog"
      >
        Open Dialog
      </v-btn>
    </div>

    <v-fade-transition hide-on-leave>
      <v-card
        v-if="dialog"
        append-icon="$close"
        class="mx-auto"
        elevation="16"
        max-width="500"
        title="Send a receipt"
      >
        <template v-slot:append>
          <v-btn icon="$close" variant="text" @click="dialog = false"></v-btn>
        </template>

        <v-divider></v-divider>

        <div class="py-12 text-center">
          <v-icon
            class="mb-6"
            color="success"
            icon="mdi-check-circle-outline"
            size="128"
          ></v-icon>

          <div class="text-h4 font-weight-bold">This receipt was sent</div>
        </div>

        <v-divider></v-divider>

        <div class="pa-4 text-end">
          <v-btn
            class="text-none"
            color="medium-emphasis"
            min-width="92"
            variant="outlined"
            rounded
            @click="dialog = false"
          >
            Close
          </v-btn>
        </div>
      </v-card>
    </v-fade-transition>
  </v-sheet>
</template>

<script setup>
  import { ref } from 'vue'

  const dialog = ref(true)
<\/script>
`;
const _sfc_main$m = {};
const _hoisted_1$b = /* @__PURE__ */ createBaseVNode("span", { class: "text-medium-emphasis font-weight-bold" }, "1 Fri Dec 16th - 9:00 PM", -1);
const _hoisted_2$1 = /* @__PURE__ */ createBaseVNode("div", { class: "py-2" }, [
  /* @__PURE__ */ createBaseVNode("div", { class: "text-h6" }, "Live Q&A"),
  /* @__PURE__ */ createBaseVNode("div", { class: "font-weight-light text-medium-emphasis" }, " Join the Vuetify team for a live Question and Answer session. ")
], -1);
const _hoisted_3$1 = { class: "pa-4 d-flex align-center" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("span", { class: "text-caption text-medium-emphasis ms-1 font-weight-light" }, " streaming ", -1);
function _sfc_render$g(_ctx, _cache) {
  const _component_v_icon = resolveComponent("v-icon");
  const _component_v_card_title = resolveComponent("v-card-title");
  const _component_v_divider = resolveComponent("v-divider");
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_card_item = resolveComponent("v-card-item");
  const _component_v_sheet = resolveComponent("v-sheet");
  const _component_v_spacer = resolveComponent("v-spacer");
  const _component_v_avatar = resolveComponent("v-avatar");
  const _component_v_chip = resolveComponent("v-chip");
  const _component_v_card = resolveComponent("v-card");
  return openBlock(), createBlock(_component_v_card, {
    class: "mx-auto",
    color: "#36393f",
    "max-width": "650",
    "min-height": "350",
    theme: "dark",
    variant: "flat"
  }, {
    default: withCtx(() => [
      createVNode(_component_v_sheet, { color: "#202225" }, {
        default: withCtx(() => [
          createVNode(_component_v_card_item, null, {
            prepend: withCtx(() => [
              createVNode(_component_v_card_title, null, {
                default: withCtx(() => [
                  createVNode(_component_v_icon, {
                    icon: "mdi-calendar",
                    start: ""
                  }),
                  createTextVNode(" 1 Event ")
                ]),
                _: 1
              })
            ]),
            append: withCtx(() => [
              createVNode(_component_v_btn, {
                icon: "$close",
                size: "large",
                variant: "text"
              })
            ]),
            default: withCtx(() => [
              createVNode(_component_v_divider, {
                class: "mx-2",
                vertical: ""
              }),
              createVNode(_component_v_btn, {
                class: "text-none text-subtitle-1",
                color: "#5865f2",
                size: "small",
                variant: "flat"
              }, {
                default: withCtx(() => [
                  createTextVNode(" Create Event ")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_card, {
        class: "ma-4",
        color: "#2f3136",
        rounded: "lg",
        variant: "flat"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_card_item, null, {
            default: withCtx(() => [
              createVNode(_component_v_card_title, { class: "text-body-2 d-flex align-center" }, {
                default: withCtx(() => [
                  createVNode(_component_v_icon, {
                    color: "#949cf7",
                    icon: "mdi-calendar",
                    start: ""
                  }),
                  _hoisted_1$b,
                  createVNode(_component_v_spacer),
                  createVNode(_component_v_avatar, {
                    image: "https://cdn.vuetifyjs.com/images/john-smirk.png",
                    size: "x-small"
                  }),
                  createVNode(_component_v_chip, {
                    class: "ms-2 text-medium-emphasis",
                    color: "grey-darken-4",
                    "prepend-icon": "mdi-account-multiple",
                    size: "small",
                    text: "81",
                    variant: "flat"
                  })
                ]),
                _: 1
              }),
              _hoisted_2$1
            ]),
            _: 1
          }),
          createVNode(_component_v_divider),
          createBaseVNode("div", _hoisted_3$1, [
            createVNode(_component_v_icon, {
              color: "disabled",
              icon: "mdi-broadcast",
              start: ""
            }),
            createVNode(_component_v_icon, {
              color: "#949cf7",
              icon: "mdi-video-vintage",
              size: "x-small"
            }),
            _hoisted_4,
            createVNode(_component_v_spacer),
            createVNode(_component_v_btn, {
              icon: "mdi-dots-horizontal",
              variant: "text"
            }),
            createVNode(_component_v_btn, {
              class: "me-2 text-none",
              color: "#4f545c",
              "prepend-icon": "mdi-export-variant",
              variant: "flat"
            }, {
              default: withCtx(() => [
                createTextVNode(" Share ")
              ]),
              _: 1
            }),
            createVNode(_component_v_btn, {
              class: "text-none",
              "prepend-icon": "mdi-check",
              variant: "text",
              border: ""
            }, {
              default: withCtx(() => [
                createTextVNode(" Interested ")
              ]),
              _: 1
            })
          ])
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __8 = /* @__PURE__ */ _export_sfc(_sfc_main$m, [["render", _sfc_render$g]]);
const __8_raw = '<template>\n  <v-card\n    class="mx-auto"\n    color="#36393f"\n    max-width="650"\n    min-height="350"\n    theme="dark"\n    variant="flat"\n  >\n    <v-sheet color="#202225">\n      <v-card-item>\n        <template v-slot:prepend>\n          <v-card-title>\n            <v-icon\n              icon="mdi-calendar"\n              start\n            ></v-icon>\n\n            1 Event\n          </v-card-title>\n        </template>\n\n        <v-divider class="mx-2" vertical></v-divider>\n\n        <v-btn\n          class="text-none text-subtitle-1"\n          color="#5865f2"\n          size="small"\n          variant="flat"\n        >\n          Create Event\n        </v-btn>\n\n        <template v-slot:append>\n          <v-btn\n            icon="$close"\n            size="large"\n            variant="text"\n          ></v-btn>\n        </template>\n      </v-card-item>\n    </v-sheet>\n\n    <v-card\n      class="ma-4"\n      color="#2f3136"\n      rounded="lg"\n      variant="flat"\n    >\n      <v-card-item>\n        <v-card-title class="text-body-2 d-flex align-center">\n          <v-icon\n            color="#949cf7"\n            icon="mdi-calendar"\n            start\n          ></v-icon>\n\n          <span class="text-medium-emphasis font-weight-bold">1 Fri Dec 16th - 9:00 PM</span>\n\n          <v-spacer></v-spacer>\n\n          <v-avatar\n            image="https://cdn.vuetifyjs.com/images/john-smirk.png"\n            size="x-small"\n          ></v-avatar>\n\n          <v-chip\n            class="ms-2 text-medium-emphasis"\n            color="grey-darken-4"\n            prepend-icon="mdi-account-multiple"\n            size="small"\n            text="81"\n            variant="flat"\n          ></v-chip>\n        </v-card-title>\n\n        <div class="py-2">\n          <div class="text-h6">Live Q&A</div>\n\n          <div class="font-weight-light text-medium-emphasis">\n            Join the Vuetify team for a live Question and Answer session.\n          </div>\n        </div>\n      </v-card-item>\n\n      <v-divider></v-divider>\n\n      <div class="pa-4 d-flex align-center">\n        <v-icon\n          color="disabled"\n          icon="mdi-broadcast"\n          start\n        ></v-icon>\n\n        <v-icon\n          color="#949cf7"\n          icon="mdi-video-vintage"\n          size="x-small"\n        ></v-icon>\n\n        <span class="text-caption text-medium-emphasis ms-1 font-weight-light">\n          streaming\n        </span>\n\n        <v-spacer></v-spacer>\n\n        <v-btn\n          icon="mdi-dots-horizontal"\n          variant="text"\n        ></v-btn>\n\n        <v-btn\n          class="me-2 text-none"\n          color="#4f545c"\n          prepend-icon="mdi-export-variant"\n          variant="flat"\n        >\n          Share\n        </v-btn>\n\n        <v-btn\n          class="text-none"\n          prepend-icon="mdi-check"\n          variant="text"\n          border\n        >\n          Interested\n        </v-btn>\n      </div>\n    </v-card>\n  </v-card>\n</template>\n';
const _hoisted_1$a = { class: "me-n2" };
const _sfc_main$l = {
  __name: "misc-group-survey",
  setup(__props) {
    const model = ref(null);
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_item = resolveComponent("v-item");
      const _component_v_item_group = resolveComponent("v-item-group");
      const _component_v_card = resolveComponent("v-card");
      return openBlock(), createBlock(_component_v_card, {
        class: "px-2 mx-auto",
        "max-width": "300",
        rounded: "lg",
        text: "How satisfied are you with developing using Vuetify?",
        theme: "dark",
        title: "SURVEY",
        variant: "flat"
      }, {
        append: withCtx(() => [
          createBaseVNode("div", _hoisted_1$a, [
            createVNode(_component_v_btn, {
              density: "comfortable",
              icon: "$close",
              variant: "plain"
            })
          ])
        ]),
        default: withCtx(() => [
          createVNode(_component_v_item_group, {
            modelValue: model.value,
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => model.value = $event),
            class: "d-flex justify-sm-space-between px-6 pt-2 pb-6"
          }, {
            default: withCtx(() => [
              (openBlock(), createElementBlock(Fragment, null, renderList(5, (n) => {
                return createVNode(_component_v_item, { key: n }, {
                  default: withCtx(({ toggle }) => [
                    createVNode(_component_v_btn, {
                      active: model.value != null && model.value + 1 >= n,
                      icon: `mdi-numeric-${n}`,
                      height: "40",
                      variant: "text",
                      width: "40",
                      border: "",
                      onClick: toggle
                    }, null, 8, ["active", "icon", "onClick"])
                  ]),
                  _: 2
                }, 1024);
              }), 64))
            ]),
            _: 1
          }, 8, ["modelValue"])
        ]),
        _: 1
      });
    };
  }
};
const __9 = _sfc_main$l;
const __9_raw = '<template>\n  <v-card\n    class="px-2 mx-auto"\n    max-width="300"\n    rounded="lg"\n    text="How satisfied are you with developing using Vuetify?"\n    theme="dark"\n    title="SURVEY"\n    variant="flat"\n  >\n    <template v-slot:append>\n      <div class="me-n2">\n        <v-btn\n          density="comfortable"\n          icon="$close"\n          variant="plain"\n        ></v-btn>\n      </div>\n    </template>\n\n    <v-item-group\n      v-model="model"\n      class="d-flex justify-sm-space-between px-6 pt-2 pb-6"\n    >\n      <v-item\n        v-for="n in 5"\n        :key="n"\n      >\n        <template v-slot:default="{ toggle }">\n          <v-btn\n            :active="model != null && model + 1 >= n"\n            :icon="`mdi-numeric-${n}`"\n            height="40"\n            variant="text"\n            width="40"\n            border\n            @click="toggle"\n          ></v-btn>\n        </template>\n      </v-item>\n    </v-item-group>\n  </v-card>\n</template>\n\n<script setup>\n  import { ref } from \'vue\'\n\n  const model = ref(null)\n<\/script>\n\n<script>\n  export default {\n    data: () => ({\n      model: null,\n    }),\n  }\n<\/script>\n';
const _sfc_main$k = {};
function _sfc_render$f(_ctx, _cache) {
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_row = resolveComponent("v-row");
  return openBlock(), createBlock(_component_v_row, {
    align: "center",
    justify: "space-around"
  }, {
    default: withCtx(() => [
      createVNode(_component_v_btn, null, {
        default: withCtx(() => [
          createTextVNode("Normal")
        ]),
        _: 1
      }),
      createVNode(_component_v_btn, { color: "primary" }, {
        default: withCtx(() => [
          createTextVNode(" Primary ")
        ]),
        _: 1
      }),
      createVNode(_component_v_btn, { color: "error" }, {
        default: withCtx(() => [
          createTextVNode(" Error ")
        ]),
        _: 1
      }),
      createVNode(_component_v_btn, { disabled: "" }, {
        default: withCtx(() => [
          createTextVNode(" Disabled ")
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __10 = /* @__PURE__ */ _export_sfc(_sfc_main$k, [["render", _sfc_render$f]]);
const __10_raw = '<template>\n  <v-row\n    align="center"\n    justify="space-around"\n  >\n    <v-btn>Normal</v-btn>\n    <v-btn color="primary">\n      Primary\n    </v-btn>\n    <v-btn color="error">\n      Error\n    </v-btn>\n    <v-btn disabled>\n      Disabled\n    </v-btn>\n  </v-row>\n</template>\n';
const _hoisted_1$9 = /* @__PURE__ */ createBaseVNode("span", { class: "text-h6" }, "Vuetify One Subscriber", -1);
const _hoisted_2 = {
  key: "subscribed",
  class: "text-success text-caption"
};
const _hoisted_3 = {
  key: "not-subscribed",
  class: "text-caption"
};
const _sfc_main$j = {
  __name: "misc-readonly",
  setup(__props) {
    const isSubscriber = shallowRef(false);
    return (_ctx, _cache) => {
      const _component_v_list_item_title = resolveComponent("v-list-item-title");
      const _component_v_icon = resolveComponent("v-icon");
      const _component_v_scroll_y_reverse_transition = resolveComponent("v-scroll-y-reverse-transition");
      const _component_v_list_item_subtitle = resolveComponent("v-list-item-subtitle");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_fade_transition = resolveComponent("v-fade-transition");
      const _component_v_list_item = resolveComponent("v-list-item");
      return openBlock(), createBlock(_component_v_list_item, {
        "base-color": "surface-light",
        border: "opacity-50 md",
        lines: "two",
        "max-width": "796",
        "prepend-avatar": "https://cdn.vuetifyjs.com/docs/images/one/logos/one.png",
        rounded: "lg",
        variant: "flat"
      }, {
        append: withCtx(() => [
          createVNode(_component_v_fade_transition, { mode: "out-in" }, {
            default: withCtx(() => [
              (openBlock(), createBlock(_component_v_btn, {
                key: `subscribe-${isSubscriber.value}`,
                border: `thin ${isSubscriber.value ? "error" : "success"}`,
                color: isSubscriber.value ? "error" : "success",
                "prepend-icon": isSubscriber.value ? "mdi-close" : "mdi-email",
                slim: isSubscriber.value,
                text: isSubscriber.value ? "Cancel" : "Subscribe",
                variant: isSubscriber.value ? "plain" : "tonal",
                class: "me-2 text-none",
                size: "small",
                flat: "",
                onClick: _cache[0] || (_cache[0] = ($event) => isSubscriber.value = !isSubscriber.value)
              }, null, 8, ["border", "color", "prepend-icon", "slim", "text", "variant"]))
            ]),
            _: 1
          }),
          createVNode(_component_v_fade_transition, { mode: "out-in" }, {
            default: withCtx(() => [
              (openBlock(), createBlock(_component_v_btn, {
                key: `info-${isSubscriber.value}`,
                color: isSubscriber.value ? "success" : "primary",
                "prepend-icon": isSubscriber.value ? "mdi-check" : "mdi-open-in-new",
                readonly: isSubscriber.value,
                text: isSubscriber.value ? "Subscribed" : "More Info",
                class: "text-none",
                size: "small",
                variant: "flat",
                flat: ""
              }, null, 8, ["color", "prepend-icon", "readonly", "text"]))
            ]),
            _: 1
          })
        ]),
        default: withCtx(() => [
          createVNode(_component_v_list_item_title, null, {
            default: withCtx(() => [
              _hoisted_1$9
            ]),
            _: 1
          }),
          createVNode(_component_v_list_item_subtitle, {
            opacity: isSubscriber.value ? 0.8 : void 0
          }, {
            default: withCtx(() => [
              createVNode(_component_v_scroll_y_reverse_transition, { mode: "out-in" }, {
                default: withCtx(() => [
                  isSubscriber.value ? (openBlock(), createElementBlock("div", _hoisted_2, [
                    createVNode(_component_v_icon, {
                      icon: "mdi-medal",
                      size: "1em"
                    }),
                    createTextVNode(" $2.99 /month ")
                  ])) : (openBlock(), createElementBlock("div", _hoisted_3, " Support Vuetify by becoming a Subscriber "))
                ]),
                _: 1
              })
            ]),
            _: 1
          }, 8, ["opacity"])
        ]),
        _: 1
      });
    };
  }
};
const __11 = _sfc_main$j;
const __11_raw = `<template>
  <v-list-item
    base-color="surface-light"
    border="opacity-50 md"
    lines="two"
    max-width="796"
    prepend-avatar="https://cdn.vuetifyjs.com/docs/images/one/logos/one.png"
    rounded="lg"
    variant="flat"
  >
    <v-list-item-title>
      <span class="text-h6">Vuetify One Subscriber</span>
    </v-list-item-title>

    <v-list-item-subtitle :opacity="isSubscriber ? .8 : undefined">
      <v-scroll-y-reverse-transition mode="out-in">
        <div
          v-if="isSubscriber"
          key="subscribed"
          class="text-success text-caption"
        >
          <v-icon icon="mdi-medal" size="1em"></v-icon>
          $2.99 /month
        </div>

        <div
          v-else
          key="not-subscribed"
          class="text-caption"
        >
          Support Vuetify by becoming a Subscriber
        </div>
      </v-scroll-y-reverse-transition>
    </v-list-item-subtitle>

    <template v-slot:append>
      <v-fade-transition mode="out-in">
        <v-btn
          :key="\`subscribe-\${isSubscriber}\`"
          :border="\`thin \${isSubscriber ? 'error' : 'success'}\`"
          :color="isSubscriber ? 'error' : 'success'"
          :prepend-icon="isSubscriber ? 'mdi-close' : 'mdi-email'"
          :slim="isSubscriber"
          :text="isSubscriber ? 'Cancel' : 'Subscribe'"
          :variant="isSubscriber ? 'plain' : 'tonal'"
          class="me-2 text-none"
          size="small"
          flat
          @click="isSubscriber = !isSubscriber"
        ></v-btn>
      </v-fade-transition>

      <v-fade-transition mode="out-in">
        <v-btn
          :key="\`info-\${isSubscriber}\`"
          :color="isSubscriber ? 'success' : 'primary'"
          :prepend-icon="isSubscriber ? 'mdi-check' : 'mdi-open-in-new'"
          :readonly="isSubscriber"
          :text="isSubscriber ? 'Subscribed' : 'More Info'"
          class="text-none"
          size="small"
          variant="flat"
          flat
        ></v-btn>
      </v-fade-transition>
    </template>
  </v-list-item>
</template>

<script setup>
  import { shallowRef } from 'vue'

  const isSubscriber = shallowRef(false)
<\/script>
`;
const _hoisted_1$8 = /* @__PURE__ */ createBaseVNode("div", { class: "text-subtitle-2 font-weight-black mb-1" }, "Last 4 digits of your SSN", -1);
const _sfc_main$i = {
  __name: "misc-tax-form",
  setup(__props) {
    const loading = ref(false);
    watch(loading, (val) => {
      if (!val)
        return;
      setTimeout(() => loading.value = false, 2e3);
    });
    return (_ctx, _cache) => {
      const _component_v_card_title = resolveComponent("v-card-title");
      const _component_v_card_text = resolveComponent("v-card-text");
      const _component_v_text_field = resolveComponent("v-text-field");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_card = resolveComponent("v-card");
      return openBlock(), createBlock(_component_v_card, {
        class: "mx-auto",
        elevation: "1",
        "max-width": "500"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_card_title, { class: "py-5 font-weight-black" }, {
            default: withCtx(() => [
              createTextVNode("Securely access your tax form")
            ]),
            _: 1
          }),
          createVNode(_component_v_card_text, null, {
            default: withCtx(() => [
              createTextVNode(" To download your tax form from GitHub Sponsors on Stripe Express, you must also verify the Tax ID number used on your tax forms, as they contain sensitive personal information. ")
            ]),
            _: 1
          }),
          createVNode(_component_v_card_text, null, {
            default: withCtx(() => [
              _hoisted_1$8,
              createVNode(_component_v_text_field, {
                label: "Enter value here",
                variant: "outlined",
                "single-line": ""
              }),
              createVNode(_component_v_btn, {
                disabled: loading.value,
                loading: loading.value,
                class: "text-none mb-4",
                color: "indigo-darken-3",
                size: "x-large",
                variant: "flat",
                block: "",
                onClick: _cache[0] || (_cache[0] = ($event) => loading.value = !loading.value)
              }, {
                default: withCtx(() => [
                  createTextVNode(" Verify and continue ")
                ]),
                _: 1
              }, 8, ["disabled", "loading"]),
              createVNode(_component_v_btn, {
                class: "text-none",
                color: "grey-lighten-3",
                size: "x-large",
                variant: "flat",
                block: ""
              }, {
                default: withCtx(() => [
                  createTextVNode(" Cancel ")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __12 = _sfc_main$i;
const __12_raw = `<template>
  <v-card
    class="mx-auto"
    elevation="1"
    max-width="500"
  >
    <v-card-title class="py-5 font-weight-black">Securely access your tax form</v-card-title>

    <v-card-text>
      To download your tax form from GitHub Sponsors on Stripe Express, you must also verify the Tax ID number used on your tax forms, as they contain sensitive personal information.
    </v-card-text>

    <v-card-text>
      <div class="text-subtitle-2 font-weight-black mb-1">Last 4 digits of your SSN</div>

      <v-text-field
        label="Enter value here"
        variant="outlined"
        single-line
      ></v-text-field>

      <v-btn
        :disabled="loading"
        :loading="loading"
        class="text-none mb-4"
        color="indigo-darken-3"
        size="x-large"
        variant="flat"
        block
        @click="loading = !loading"
      >
        Verify and continue
      </v-btn>

      <v-btn
        class="text-none"
        color="grey-lighten-3"
        size="x-large"
        variant="flat"
        block
      >
        Cancel
      </v-btn>
    </v-card-text>
  </v-card>
</template>

<script setup>
  import { ref, watch } from 'vue'

  const loading = ref(false)

  watch(loading, val => {
    if (!val) return
    setTimeout(() => (loading.value = false), 2000)
  })
<\/script>

<script>
  export default {
    data: () => ({
      loading: false,
    }),

    watch: {
      loading (val) {
        if (!val) return

        setTimeout(() => (this.loading = false), 2000)
      },
    },
  }
<\/script>
`;
const _sfc_main$h = {};
function _sfc_render$e(_ctx, _cache) {
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_divider = resolveComponent("v-divider");
  const _component_v_toolbar = resolveComponent("v-toolbar");
  return openBlock(), createBlock(_component_v_toolbar, null, {
    prepend: withCtx(() => [
      createVNode(_component_v_btn, { icon: "mdi-arrow-left" })
    ]),
    default: withCtx(() => [
      createVNode(_component_v_btn, {
        class: "ms-5",
        icon: "mdi-archive-plus-outline"
      }),
      createVNode(_component_v_btn, { icon: "mdi-alert-circle-outline" }),
      createVNode(_component_v_btn, { icon: "mdi-delete-outline" }),
      _ctx.$vuetify.display.smAndUp ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
        createVNode(_component_v_divider, {
          class: "mx-3 align-self-center",
          length: "24",
          thickness: "2",
          vertical: ""
        }),
        createVNode(_component_v_btn, { icon: "mdi-folder-outline" }),
        createVNode(_component_v_btn, { icon: "mdi-tag-outline" }),
        createVNode(_component_v_btn, { icon: "mdi-dots-vertical" })
      ], 64)) : createCommentVNode("", true)
    ]),
    _: 1
  });
}
const __13 = /* @__PURE__ */ _export_sfc(_sfc_main$h, [["render", _sfc_render$e]]);
const __13_raw = '<template>\n  <v-toolbar>\n    <template v-slot:prepend>\n      <v-btn icon="mdi-arrow-left"></v-btn>\n    </template>\n\n    <v-btn class="ms-5" icon="mdi-archive-plus-outline"></v-btn>\n\n    <v-btn icon="mdi-alert-circle-outline"></v-btn>\n\n    <v-btn icon="mdi-delete-outline"></v-btn>\n\n    <template v-if="$vuetify.display.smAndUp">\n      <v-divider\n        class="mx-3 align-self-center"\n        length="24"\n        thickness="2"\n        vertical\n      ></v-divider>\n\n      <v-btn icon="mdi-folder-outline"></v-btn>\n\n      <v-btn icon="mdi-tag-outline"></v-btn>\n\n      <v-btn icon="mdi-dots-vertical"></v-btn>\n    </template>\n  </v-toolbar>\n</template>\n';
const _sfc_main$g = {};
function _sfc_render$d(_ctx, _cache) {
  const _component_v_btn = resolveComponent("v-btn");
  return openBlock(), createBlock(_component_v_btn, { block: "" }, {
    default: withCtx(() => [
      createTextVNode("Block Button")
    ]),
    _: 1
  });
}
const __14 = /* @__PURE__ */ _export_sfc(_sfc_main$g, [["render", _sfc_render$d]]);
const __14_raw = "<template>\n  <v-btn block>Block Button</v-btn>\n</template>\n";
const _sfc_main$f = {};
function _sfc_render$c(_ctx, _cache) {
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, null, {
    default: withCtx(() => [
      createVNode(_component_v_row, {
        align: "center",
        justify: "center"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, { density: "compact" }, {
                default: withCtx(() => [
                  createTextVNode("Compact Button")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, { density: "comfortable" }, {
                default: withCtx(() => [
                  createTextVNode("Comfortable Button")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, { density: "default" }, {
                default: withCtx(() => [
                  createTextVNode("Default Button")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __15 = /* @__PURE__ */ _export_sfc(_sfc_main$f, [["render", _sfc_render$c]]);
const __15_raw = '<template>\n  <v-container>\n    <v-row align="center" justify="center">\n      <v-col cols="auto">\n        <v-btn density="compact">Compact Button</v-btn>\n      </v-col>\n\n      <v-col cols="auto">\n        <v-btn density="comfortable">Comfortable Button</v-btn>\n      </v-col>\n\n      <v-col cols="auto">\n        <v-btn density="default">Default Button</v-btn>\n      </v-col>\n    </v-row>\n  </v-container>\n</template>\n';
const _sfc_main$e = {};
function _sfc_render$b(_ctx, _cache) {
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, null, {
    default: withCtx(() => [
      createVNode(_component_v_row, {
        align: "center",
        justify: "center"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_col, {
            class: "text-center",
            cols: "12"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, { size: "x-large" }, {
                default: withCtx(() => [
                  createTextVNode("Default Elevation (2)")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, {
                elevation: "4",
                size: "x-large"
              }, {
                default: withCtx(() => [
                  createTextVNode("Elevation 4")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, {
                elevation: "8",
                size: "x-large"
              }, {
                default: withCtx(() => [
                  createTextVNode("Elevation 8")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, {
                elevation: "12",
                size: "x-large"
              }, {
                default: withCtx(() => [
                  createTextVNode("Elevation 12")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, {
                elevation: "16",
                size: "x-large"
              }, {
                default: withCtx(() => [
                  createTextVNode("Elevation 16")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, {
                elevation: "20",
                size: "x-large"
              }, {
                default: withCtx(() => [
                  createTextVNode("Elevation 20")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, {
                elevation: "24",
                size: "x-large"
              }, {
                default: withCtx(() => [
                  createTextVNode("Elevation 24")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __16 = /* @__PURE__ */ _export_sfc(_sfc_main$e, [["render", _sfc_render$b]]);
const __16_raw = '<template>\n  <v-container>\n    <v-row align="center" justify="center">\n      <v-col class="text-center" cols="12">\n        <v-btn size="x-large">Default Elevation (2)</v-btn>\n      </v-col>\n\n      <v-col cols="auto">\n        <v-btn elevation="4" size="x-large">Elevation 4</v-btn>\n      </v-col>\n\n      <v-col cols="auto">\n        <v-btn elevation="8" size="x-large">Elevation 8</v-btn>\n      </v-col>\n\n      <v-col cols="auto">\n        <v-btn elevation="12" size="x-large">Elevation 12</v-btn>\n      </v-col>\n\n      <v-col cols="auto">\n        <v-btn elevation="16" size="x-large">Elevation 16</v-btn>\n      </v-col>\n\n      <v-col cols="auto">\n        <v-btn elevation="20" size="x-large">Elevation 20</v-btn>\n      </v-col>\n\n      <v-col cols="auto">\n        <v-btn elevation="24" size="x-large">Elevation 24</v-btn>\n      </v-col>\n    </v-row>\n  </v-container>\n</template>\n';
const _sfc_main$d = {};
const _hoisted_1$7 = { class: "d-flex justify-space-around align-center flex-column flex-sm-row fill-height" };
function _sfc_render$a(_ctx, _cache) {
  const _component_v_btn = resolveComponent("v-btn");
  return openBlock(), createElementBlock("div", _hoisted_1$7, [
    createVNode(_component_v_btn, { variant: "flat" }, {
      default: withCtx(() => [
        createTextVNode(" Normal ")
      ]),
      _: 1
    }),
    createVNode(_component_v_btn, {
      color: "secondary",
      variant: "flat"
    }, {
      default: withCtx(() => [
        createTextVNode(" Secondary ")
      ]),
      _: 1
    }),
    createVNode(_component_v_btn, {
      color: "error",
      variant: "flat"
    }, {
      default: withCtx(() => [
        createTextVNode(" Error ")
      ]),
      _: 1
    }),
    createVNode(_component_v_btn, {
      variant: "flat",
      disabled: ""
    }, {
      default: withCtx(() => [
        createTextVNode(" Disabled ")
      ]),
      _: 1
    })
  ]);
}
const __17 = /* @__PURE__ */ _export_sfc(_sfc_main$d, [["render", _sfc_render$a]]);
const __17_raw = '<template>\n  <div class="d-flex justify-space-around align-center flex-column flex-sm-row fill-height">\n    <v-btn variant="flat">\n      Normal\n    </v-btn>\n\n    <v-btn\n      color="secondary"\n      variant="flat"\n    >\n      Secondary\n    </v-btn>\n\n    <v-btn\n      color="error"\n      variant="flat"\n    >\n      Error\n    </v-btn>\n\n    <v-btn\n      variant="flat"\n      disabled\n    >\n      Disabled\n    </v-btn>\n  </div>\n</template>\n';
const _sfc_main$c = {};
const _hoisted_1$6 = { class: "text-center" };
function _sfc_render$9(_ctx, _cache) {
  const _component_v_icon = resolveComponent("v-icon");
  const _component_v_btn = resolveComponent("v-btn");
  return openBlock(), createElementBlock("div", _hoisted_1$6, [
    createVNode(_component_v_btn, {
      class: "mx-2",
      color: "primary",
      size: "small",
      dark: "",
      fab: ""
    }, {
      default: withCtx(() => [
        createVNode(_component_v_icon, { dark: "" }, {
          default: withCtx(() => [
            createTextVNode(" mdi-minus ")
          ]),
          _: 1
        })
      ]),
      _: 1
    }),
    createVNode(_component_v_btn, {
      class: "mx-2",
      color: "pink",
      size: "small",
      dark: "",
      fab: ""
    }, {
      default: withCtx(() => [
        createVNode(_component_v_icon, { dark: "" }, {
          default: withCtx(() => [
            createTextVNode(" mdi-heart ")
          ]),
          _: 1
        })
      ]),
      _: 1
    }),
    createVNode(_component_v_btn, {
      class: "mx-2",
      color: "indigo",
      dark: "",
      fab: ""
    }, {
      default: withCtx(() => [
        createVNode(_component_v_icon, { dark: "" }, {
          default: withCtx(() => [
            createTextVNode(" mdi-plus ")
          ]),
          _: 1
        })
      ]),
      _: 1
    }),
    createVNode(_component_v_btn, {
      class: "mx-2",
      color: "teal",
      dark: "",
      fab: ""
    }, {
      default: withCtx(() => [
        createVNode(_component_v_icon, { dark: "" }, {
          default: withCtx(() => [
            createTextVNode(" mdi-format-list-bulleted-square ")
          ]),
          _: 1
        })
      ]),
      _: 1
    }),
    createVNode(_component_v_btn, {
      class: "mx-2",
      color: "cyan",
      size: "large",
      dark: "",
      fab: ""
    }, {
      default: withCtx(() => [
        createVNode(_component_v_icon, { dark: "" }, {
          default: withCtx(() => [
            createTextVNode(" mdi-pencil ")
          ]),
          _: 1
        })
      ]),
      _: 1
    }),
    createVNode(_component_v_btn, {
      class: "mx-2",
      color: "purple",
      size: "large",
      dark: "",
      fab: ""
    }, {
      default: withCtx(() => [
        createVNode(_component_v_icon, { dark: "" }, {
          default: withCtx(() => [
            createTextVNode(" mdi-android ")
          ]),
          _: 1
        })
      ]),
      _: 1
    })
  ]);
}
const __18 = /* @__PURE__ */ _export_sfc(_sfc_main$c, [["render", _sfc_render$9]]);
const __18_raw = '<template>\n  <div class="text-center">\n    <v-btn\n      class="mx-2"\n      color="primary"\n      size="small"\n      dark\n      fab\n    >\n      <v-icon dark>\n        mdi-minus\n      </v-icon>\n    </v-btn>\n\n    <v-btn\n      class="mx-2"\n      color="pink"\n      size="small"\n      dark\n      fab\n    >\n      <v-icon dark>\n        mdi-heart\n      </v-icon>\n    </v-btn>\n\n    <v-btn\n      class="mx-2"\n      color="indigo"\n      dark\n      fab\n    >\n      <v-icon dark>\n        mdi-plus\n      </v-icon>\n    </v-btn>\n\n    <v-btn\n      class="mx-2"\n      color="teal"\n      dark\n      fab\n    >\n      <v-icon dark>\n        mdi-format-list-bulleted-square\n      </v-icon>\n    </v-btn>\n\n    <v-btn\n      class="mx-2"\n      color="cyan"\n      size="large"\n      dark\n      fab\n    >\n      <v-icon dark>\n        mdi-pencil\n      </v-icon>\n    </v-btn>\n\n    <v-btn\n      class="mx-2"\n      color="purple"\n      size="large"\n      dark\n      fab\n    >\n      <v-icon dark>\n        mdi-android\n      </v-icon>\n    </v-btn>\n  </div>\n</template>\n';
const _sfc_main$b = {};
function _sfc_render$8(_ctx, _cache) {
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, null, {
    default: withCtx(() => [
      createVNode(_component_v_row, {
        align: "center",
        justify: "center"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, {
                density: "compact",
                icon: "mdi-plus"
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, {
                density: "comfortable",
                icon: "$vuetify"
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, {
                density: "default",
                icon: "mdi-open-in-new"
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_row, {
        align: "center",
        justify: "center"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, {
                icon: "mdi-account",
                size: "x-small"
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, {
                icon: "mdi-plus",
                size: "small"
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, { icon: "$vuetify" })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, {
                icon: "mdi-open-in-new",
                size: "large"
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, {
                icon: "mdi-calendar",
                size: "x-large"
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __19 = /* @__PURE__ */ _export_sfc(_sfc_main$b, [["render", _sfc_render$8]]);
const __19_raw = '<template>\n  <v-container>\n    <v-row align="center" justify="center">\n      <v-col cols="auto">\n        <v-btn density="compact" icon="mdi-plus"></v-btn>\n      </v-col>\n\n      <v-col cols="auto">\n        <v-btn density="comfortable" icon="$vuetify"></v-btn>\n      </v-col>\n\n      <v-col cols="auto">\n        <v-btn density="default" icon="mdi-open-in-new"></v-btn>\n      </v-col>\n    </v-row>\n\n    <v-row align="center" justify="center">\n      <v-col cols="auto">\n        <v-btn icon="mdi-account" size="x-small"></v-btn>\n      </v-col>\n\n      <v-col cols="auto">\n        <v-btn icon="mdi-plus" size="small"></v-btn>\n      </v-col>\n\n      <v-col cols="auto">\n        <v-btn icon="$vuetify"></v-btn>\n      </v-col>\n\n      <v-col cols="auto">\n        <v-btn icon="mdi-open-in-new" size="large"></v-btn>\n      </v-col>\n\n      <v-col cols="auto">\n        <v-btn icon="mdi-calendar" size="x-large"></v-btn>\n      </v-col>\n    </v-row>\n  </v-container>\n</template>\n';
const _sfc_main$a = {
  __name: "prop-loaders",
  setup(__props) {
    const loading = ref(false);
    function load() {
      loading.value = true;
      setTimeout(() => loading.value = false, 3e3);
    }
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_card = resolveComponent("v-card");
      return openBlock(), createBlock(_component_v_card, {
        class: "mx-auto",
        "max-width": "450",
        text: "Update your weak or re-used passwords with Password Checkup. It's free and only takes a few minutes. Click the Take Checkup button to get started.",
        title: "Strengthen your passwords"
      }, {
        actions: withCtx(() => [
          createVNode(_component_v_btn, { height: "48" }, {
            default: withCtx(() => [
              createTextVNode(" No Thanks ")
            ]),
            _: 1
          }),
          createVNode(_component_v_btn, {
            loading: loading.value,
            class: "flex-grow-1",
            height: "48",
            variant: "tonal",
            onClick: load
          }, {
            default: withCtx(() => [
              createTextVNode(" Take Checkup ")
            ]),
            _: 1
          }, 8, ["loading"])
        ]),
        _: 1
      });
    };
  }
};
const __20 = _sfc_main$a;
const __20_raw = `<template>
  <v-card
    class="mx-auto"
    max-width="450"
    text="Update your weak or re-used passwords with Password Checkup. It's free and only takes a few minutes. Click the Take Checkup button to get started."
    title="Strengthen your passwords"
  >

    <template v-slot:actions>
      <v-btn height="48">
        No Thanks
      </v-btn>

      <v-btn
        :loading="loading"
        class="flex-grow-1"
        height="48"
        variant="tonal"
        @click="load"
      >
        Take Checkup
      </v-btn>
    </template>
  </v-card>
</template>

<script setup>
  import { ref } from 'vue'

  const loading = ref(false)
  function load () {
    loading.value = true
    setTimeout(() => (loading.value = false), 3000)
  }
<\/script>

<script>
  export default {
    data: () => ({ loading: false }),

    methods: {
      load () {
        this.loading = true
        setTimeout(() => (this.loading = false), 3000)
      },
    },
  }
<\/script>
`;
const _sfc_main$9 = {};
const _hoisted_1$5 = { class: "d-flex justify-space-around align-center flex-column flex-sm-row" };
function _sfc_render$7(_ctx, _cache) {
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_icon = resolveComponent("v-icon");
  return openBlock(), createElementBlock("div", _hoisted_1$5, [
    createVNode(_component_v_btn, {
      color: "primary",
      variant: "outlined"
    }, {
      default: withCtx(() => [
        createTextVNode(" Outlined Button ")
      ]),
      _: 1
    }),
    createVNode(_component_v_btn, {
      color: "secondary",
      variant: "outlined",
      icon: ""
    }, {
      default: withCtx(() => [
        createVNode(_component_v_icon, null, {
          default: withCtx(() => [
            createTextVNode("mdi-format-list-bulleted-square")
          ]),
          _: 1
        })
      ]),
      _: 1
    }),
    createVNode(_component_v_btn, {
      color: "info",
      size: "large",
      variant: "outlined",
      icon: ""
    }, {
      default: withCtx(() => [
        createVNode(_component_v_icon, null, {
          default: withCtx(() => [
            createTextVNode("mdi-pencil")
          ]),
          _: 1
        })
      ]),
      _: 1
    })
  ]);
}
const __21 = /* @__PURE__ */ _export_sfc(_sfc_main$9, [["render", _sfc_render$7]]);
const __21_raw = '<template>\n  <div class="d-flex justify-space-around align-center flex-column flex-sm-row">\n    <v-btn\n      color="primary"\n      variant="outlined"\n    >\n      Outlined Button\n    </v-btn>\n    <v-btn\n      color="secondary"\n      variant="outlined"\n      icon\n    >\n      <v-icon>mdi-format-list-bulleted-square</v-icon>\n    </v-btn>\n    <v-btn\n      color="info"\n      size="large"\n      variant="outlined"\n      icon\n    >\n      <v-icon>mdi-pencil</v-icon>\n    </v-btn>\n  </div>\n</template>\n';
const _sfc_main$8 = {};
const _hoisted_1$4 = { class: "d-flex justify-space-around" };
function _sfc_render$6(_ctx, _cache) {
  const _component_v_btn = resolveComponent("v-btn");
  return openBlock(), createElementBlock("div", _hoisted_1$4, [
    createVNode(_component_v_btn, {
      color: "grey",
      variant: "plain"
    }, {
      default: withCtx(() => [
        createTextVNode(" Cancel ")
      ]),
      _: 1
    }),
    createVNode(_component_v_btn, {
      color: "error",
      variant: "plain"
    }, {
      default: withCtx(() => [
        createTextVNode(" Delete ")
      ]),
      _: 1
    })
  ]);
}
const __22 = /* @__PURE__ */ _export_sfc(_sfc_main$8, [["render", _sfc_render$6]]);
const __22_raw = '<template>\n  <div class="d-flex justify-space-around">\n    <v-btn\n      color="grey"\n      variant="plain"\n    >\n      Cancel\n    </v-btn>\n\n    <v-btn\n      color="error"\n      variant="plain"\n    >\n      Delete\n    </v-btn>\n  </div>\n</template>\n';
const _sfc_main$7 = {};
function _sfc_render$5(_ctx, _cache) {
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, null, {
    default: withCtx(() => [
      createVNode(_component_v_row, { justify: "center" }, {
        default: withCtx(() => [
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, {
                height: "72",
                "min-width": "164"
              }, {
                default: withCtx(() => [
                  createTextVNode(" With Ripple ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, {
                ripple: false,
                height: "72",
                "min-width": "164"
              }, {
                default: withCtx(() => [
                  createTextVNode(" Without Ripple ")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __23 = /* @__PURE__ */ _export_sfc(_sfc_main$7, [["render", _sfc_render$5]]);
const __23_raw = '<template>\n  <v-container>\n    <v-row justify="center">\n      <v-col cols="auto">\n        <v-btn\n          height="72"\n          min-width="164"\n        >\n          With Ripple\n        </v-btn>\n      </v-col>\n\n      <v-col cols="auto">\n        <v-btn\n          :ripple="false"\n          height="72"\n          min-width="164"\n        >\n          Without Ripple\n        </v-btn>\n      </v-col>\n    </v-row>\n  </v-container>\n</template>\n';
const _sfc_main$6 = {};
function _sfc_render$4(_ctx, _cache) {
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, { class: "text-center" }, {
    default: withCtx(() => [
      createVNode(_component_v_row, { justify: "center" }, {
        default: withCtx(() => [
          createVNode(_component_v_col, {
            cols: "12",
            md: "4",
            sm: "6"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, {
                rounded: "0",
                size: "x-large",
                block: ""
              }, {
                default: withCtx(() => [
                  createTextVNode("Rounded 0")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, {
            cols: "12",
            md: "4",
            sm: "6"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, {
                rounded: "xs",
                size: "x-large",
                block: ""
              }, {
                default: withCtx(() => [
                  createTextVNode("Rounded xs")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, {
            cols: "12",
            md: "4",
            sm: "6"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, {
                rounded: "sm",
                size: "x-large",
                block: ""
              }, {
                default: withCtx(() => [
                  createTextVNode("Rounded sm")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, {
            cols: "12",
            md: "4",
            sm: "6"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, {
                size: "x-large",
                block: ""
              }, {
                default: withCtx(() => [
                  createTextVNode("Button")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, {
            cols: "12",
            md: "4",
            sm: "6"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, {
                rounded: "lg",
                size: "x-large",
                block: ""
              }, {
                default: withCtx(() => [
                  createTextVNode("Rounded lg")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, {
            cols: "12",
            md: "4",
            sm: "6"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, {
                rounded: "xl",
                size: "x-large",
                block: ""
              }, {
                default: withCtx(() => [
                  createTextVNode("Rounded xl")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __24 = /* @__PURE__ */ _export_sfc(_sfc_main$6, [["render", _sfc_render$4]]);
const __24_raw = '<template>\n  <v-container class="text-center">\n    <v-row justify="center">\n      <v-col cols="12" md="4" sm="6">\n        <v-btn rounded="0" size="x-large" block>Rounded 0</v-btn>\n      </v-col>\n\n      <v-col cols="12" md="4" sm="6">\n        <v-btn rounded="xs" size="x-large" block>Rounded xs</v-btn>\n      </v-col>\n\n      <v-col cols="12" md="4" sm="6">\n        <v-btn rounded="sm" size="x-large" block>Rounded sm</v-btn>\n      </v-col>\n\n      <v-col cols="12" md="4" sm="6">\n        <v-btn size="x-large" block>Button</v-btn>\n      </v-col>\n\n      <v-col cols="12" md="4" sm="6">\n        <v-btn rounded="lg" size="x-large" block>Rounded lg</v-btn>\n      </v-col>\n\n      <v-col cols="12" md="4" sm="6">\n        <v-btn rounded="xl" size="x-large" block>Rounded xl</v-btn>\n      </v-col>\n    </v-row>\n  </v-container>\n</template>\n';
const _sfc_main$5 = {};
function _sfc_render$3(_ctx, _cache) {
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, null, {
    default: withCtx(() => [
      createVNode(_component_v_row, {
        align: "center",
        justify: "center"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, { size: "x-small" }, {
                default: withCtx(() => [
                  createTextVNode("Extra small Button")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, { size: "small" }, {
                default: withCtx(() => [
                  createTextVNode("Small Button")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, null, {
                default: withCtx(() => [
                  createTextVNode("Regular Button")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, { size: "large" }, {
                default: withCtx(() => [
                  createTextVNode("Large Button")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, { size: "x-large" }, {
                default: withCtx(() => [
                  createTextVNode("X-Large Button")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __25 = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["render", _sfc_render$3]]);
const __25_raw = '<template>\n  <v-container>\n    <v-row align="center" justify="center">\n      <v-col cols="auto">\n        <v-btn size="x-small">Extra small Button</v-btn>\n      </v-col>\n\n      <v-col cols="auto">\n        <v-btn size="small">Small Button</v-btn>\n      </v-col>\n\n      <v-col cols="auto">\n        <v-btn>Regular Button</v-btn>\n      </v-col>\n\n      <v-col cols="auto">\n        <v-btn size="large">Large Button</v-btn>\n      </v-col>\n\n      <v-col cols="auto">\n        <v-btn size="x-large">X-Large Button</v-btn>\n      </v-col>\n    </v-row>\n  </v-container>\n</template>\n';
const _sfc_main$4 = {};
function _sfc_render$2(_ctx, _cache) {
  const _component_v_icon = resolveComponent("v-icon");
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_row = resolveComponent("v-row");
  return openBlock(), createBlock(_component_v_row, {
    align: "center",
    justify: "space-around"
  }, {
    default: withCtx(() => [
      createVNode(_component_v_btn, {
        color: "success",
        tile: ""
      }, {
        default: withCtx(() => [
          createVNode(_component_v_icon, { start: "" }, {
            default: withCtx(() => [
              createTextVNode(" mdi-pencil ")
            ]),
            _: 1
          }),
          createTextVNode(" Edit ")
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __26 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["render", _sfc_render$2]]);
const __26_raw = '<template>\n  <v-row\n    align="center"\n    justify="space-around"\n  >\n    <v-btn\n      color="success"\n      tile\n    >\n      <v-icon start>\n        mdi-pencil\n      </v-icon>\n      Edit\n    </v-btn>\n  </v-row>\n</template>\n';
const _sfc_main$3 = {};
const _hoisted_1$3 = { class: "d-flex justify-space-between" };
function _sfc_render$1(_ctx, _cache) {
  const _component_v_btn = resolveComponent("v-btn");
  return openBlock(), createElementBlock("div", _hoisted_1$3, [
    createVNode(_component_v_btn, null, {
      default: withCtx(() => [
        createTextVNode("elevated (default)")
      ]),
      _: 1
    }),
    createVNode(_component_v_btn, { variant: "flat" }, {
      default: withCtx(() => [
        createTextVNode("flat")
      ]),
      _: 1
    }),
    createVNode(_component_v_btn, { variant: "tonal" }, {
      default: withCtx(() => [
        createTextVNode("tonal")
      ]),
      _: 1
    }),
    createVNode(_component_v_btn, { variant: "outlined" }, {
      default: withCtx(() => [
        createTextVNode("outlined")
      ]),
      _: 1
    }),
    createVNode(_component_v_btn, { variant: "text" }, {
      default: withCtx(() => [
        createTextVNode("text")
      ]),
      _: 1
    }),
    createVNode(_component_v_btn, { variant: "plain" }, {
      default: withCtx(() => [
        createTextVNode("plain")
      ]),
      _: 1
    })
  ]);
}
const __27 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["render", _sfc_render$1]]);
const __27_raw = '<template>\n  <div class="d-flex justify-space-between">\n    <v-btn>elevated (default)</v-btn>\n    <v-btn variant="flat">flat</v-btn>\n    <v-btn variant="tonal">tonal</v-btn>\n    <v-btn variant="outlined">outlined</v-btn>\n    <v-btn variant="text">text</v-btn>\n    <v-btn variant="plain">plain</v-btn>\n  </div>\n</template>\n';
const _hoisted_1$2 = { class: "text-center" };
const _sfc_main$2 = {
  __name: "slot-loader",
  setup(__props) {
    const loading = ref(false);
    watch(loading, (val) => {
      if (!val)
        return;
      setTimeout(() => loading.value = false, 2e3);
    });
    return (_ctx, _cache) => {
      const _component_v_progress_linear = resolveComponent("v-progress-linear");
      const _component_v_btn = resolveComponent("v-btn");
      return openBlock(), createElementBlock("div", _hoisted_1$2, [
        createVNode(_component_v_btn, {
          loading: loading.value,
          onClick: _cache[0] || (_cache[0] = ($event) => loading.value = !loading.value)
        }, {
          loader: withCtx(() => [
            createVNode(_component_v_progress_linear, { indeterminate: "" })
          ]),
          default: withCtx(() => [
            createTextVNode(" Custom loader ")
          ]),
          _: 1
        }, 8, ["loading"])
      ]);
    };
  }
};
const __28 = _sfc_main$2;
const __28_raw = `<template>
  <div class="text-center">
    <v-btn
      :loading="loading"
      @click="loading = !loading"
    >
      Custom loader

      <template v-slot:loader>
        <v-progress-linear indeterminate></v-progress-linear>
      </template>
    </v-btn>
  </div>
</template>

<script setup>
  import { ref, watch } from 'vue'

  const loading = ref(false)
  watch(loading, val => {
    if (!val) return
    setTimeout(() => (loading.value = false), 2000)
  })
<\/script>

<script>
  export default {
    data: () => ({
      loading: false,
    }),

    watch: {
      loading (val) {
        if (!val) return

        setTimeout(() => (this.loading = false), 2000)
      },
    },
  }
<\/script>
`;
const _sfc_main$1 = {};
const _hoisted_1$1 = { class: "text-center" };
function _sfc_render(_ctx, _cache) {
  const _component_v_icon = resolveComponent("v-icon");
  const _component_v_btn = resolveComponent("v-btn");
  return openBlock(), createElementBlock("div", _hoisted_1$1, [
    createVNode(_component_v_btn, {
      "append-icon": "mdi-account-circle",
      "prepend-icon": "mdi-check-circle"
    }, {
      prepend: withCtx(() => [
        createVNode(_component_v_icon, { color: "success" })
      ]),
      append: withCtx(() => [
        createVNode(_component_v_icon, { color: "warning" })
      ]),
      default: withCtx(() => [
        createTextVNode(" Button ")
      ]),
      _: 1
    })
  ]);
}
const __29 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["render", _sfc_render]]);
const __29_raw = '<template>\n  <div class="text-center">\n    <v-btn\n      append-icon="mdi-account-circle"\n      prepend-icon="mdi-check-circle"\n    >\n      <template v-slot:prepend>\n        <v-icon color="success"></v-icon>\n      </template>\n\n      Button\n\n      <template v-slot:append>\n        <v-icon color="warning"></v-icon>\n      </template>\n    </v-btn>\n  </div>\n</template>\n';
const _hoisted_1 = { class: "text-center" };
const name = "v-btn";
const _sfc_main = {
  __name: "usage",
  setup(__props) {
    const variants = ["outlined", "tonal", "text", "plain"];
    const model = ref("default");
    const icon = ref(false);
    const options = [...variants];
    const block = ref(false);
    const stacked = ref(false);
    const prepend = ref(false);
    const append = ref(false);
    const props = computed(() => {
      return {
        block: block.value || void 0,
        "prepend-icon": prepend.value ? "$vuetify" : void 0,
        "append-icon": append.value ? "$vuetify" : void 0,
        icon: icon.value ? "$vuetify" : void 0,
        stacked: stacked.value || void 0,
        variant: variants.includes(model.value) ? model.value : void 0
      };
    });
    watch(stacked, (val) => {
      if (val) {
        prepend.value = true;
        append.value = false;
        icon.value = false;
      }
    });
    watch(prepend, (val) => {
      if (val) {
        icon.value = false;
        if (stacked.value)
          append.value = false;
      }
    });
    watch(append, (val) => {
      if (val) {
        icon.value = false;
        if (stacked.value)
          prepend.value = false;
      }
    });
    watch(icon, (val) => val && (prepend.value = false, append.value = false, stacked.value = false));
    const slots = computed(() => {
      return `
  Button
`;
    });
    const code = computed(() => {
      return `<${name}${propsToString(props.value)}>${slots.value}</${name}>`;
    });
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_checkbox = resolveComponent("v-checkbox");
      const _component_ExamplesUsageExample = _sfc_main$v;
      return openBlock(), createBlock(_component_ExamplesUsageExample, {
        modelValue: unref(model),
        "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => isRef(model) ? model.value = $event : null),
        code: unref(code),
        name,
        options
      }, {
        configuration: withCtx(() => [
          createVNode(_component_v_checkbox, {
            modelValue: unref(icon),
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(icon) ? icon.value = $event : null),
            label: "Icon"
          }, null, 8, ["modelValue"]),
          createVNode(_component_v_checkbox, {
            modelValue: unref(prepend),
            "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(prepend) ? prepend.value = $event : null),
            label: "Prepend icon"
          }, null, 8, ["modelValue"]),
          createVNode(_component_v_checkbox, {
            modelValue: unref(append),
            "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => isRef(append) ? append.value = $event : null),
            label: "Append icon"
          }, null, 8, ["modelValue"]),
          createVNode(_component_v_checkbox, {
            modelValue: unref(stacked),
            "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => isRef(stacked) ? stacked.value = $event : null),
            label: "Stacked"
          }, null, 8, ["modelValue"])
        ]),
        default: withCtx(() => [
          createBaseVNode("div", _hoisted_1, [
            createVNode(_component_v_btn, normalizeProps(guardReactiveProps(unref(props))), createSlots({ _: 2 }, [
              !unref(icon) ? {
                name: "default",
                fn: withCtx(() => [
                  createTextVNode("Button")
                ]),
                key: "0"
              } : void 0
            ]), 1040)
          ])
        ]),
        _: 1
      }, 8, ["modelValue", "code"]);
    };
  }
};
const __30 = _sfc_main;
const __30_raw = `<template>
  <ExamplesUsageExample
    v-model="model"
    :code="code"
    :name="name"
    :options="options"
  >
    <div class="text-center">
      <v-btn v-bind="props">
        <template v-if="!icon" v-slot:default>Button</template>
      </v-btn>
    </div>

    <template v-slot:configuration>
      <v-checkbox v-model="icon" label="Icon"></v-checkbox>
      <v-checkbox v-model="prepend" label="Prepend icon"></v-checkbox>
      <v-checkbox v-model="append" label="Append icon"></v-checkbox>
      <v-checkbox v-model="stacked" label="Stacked"></v-checkbox>
    </template>
  </ExamplesUsageExample>
</template>

<script setup>
  const variants = ['outlined', 'tonal', 'text', 'plain']
  const name = 'v-btn'
  const model = ref('default')
  const icon = ref(false)
  const options = [...variants]
  const block = ref(false)
  const stacked = ref(false)
  const prepend = ref(false)
  const append = ref(false)
  const props = computed(() => {
    return {
      block: block.value || undefined,
      'prepend-icon': prepend.value ? '$vuetify' : undefined,
      'append-icon': append.value ? '$vuetify' : undefined,
      icon: icon.value ? '$vuetify' : undefined,
      stacked: stacked.value || undefined,
      variant: variants.includes(model.value) ? model.value : undefined,
    }
  })

  watch(stacked, val => {
    if (val) {
      prepend.value = true
      append.value = false
      icon.value = false
    }
  })

  watch(prepend, val => {
    if (val) {
      icon.value = false

      if (stacked.value) (append.value = false)
    }
  })

  watch(append, val => {
    if (val) {
      icon.value = false

      if (stacked.value) (prepend.value = false)
    }
  })
  watch(icon, val => val && (prepend.value = false, append.value = false, stacked.value = false))

  const slots = computed(() => {
    return \`
  Button
\`
  })

  const code = computed(() => {
    return \`<\${name}\${propsToString(props.value)}>\${slots.value}</\${name}>\`
  })
<\/script>
`;
const vBtn = {
  "defaults-banner-actions": {
    component: __0,
    source: __0_raw
  },
  "defaults-bottom-navigation": {
    component: __1,
    source: __1_raw
  },
  "defaults-btn-group": {
    component: __2,
    source: __2_raw
  },
  "defaults-card-actions": {
    component: __3,
    source: __3_raw
  },
  "defaults-snackbar": {
    component: __4,
    source: __4_raw
  },
  "defaults-toolbar": {
    component: __5,
    source: __5_raw
  },
  "misc-cookie-settings": {
    component: __6,
    source: __6_raw
  },
  "misc-dialog-action": {
    component: __7,
    source: __7_raw
  },
  "misc-discord-event": {
    component: __8,
    source: __8_raw
  },
  "misc-group-survey": {
    component: __9,
    source: __9_raw
  },
  "misc-raised": {
    component: __10,
    source: __10_raw
  },
  "misc-readonly": {
    component: __11,
    source: __11_raw
  },
  "misc-tax-form": {
    component: __12,
    source: __12_raw
  },
  "misc-toolbar": {
    component: __13,
    source: __13_raw
  },
  "prop-block": {
    component: __14,
    source: __14_raw
  },
  "prop-density": {
    component: __15,
    source: __15_raw
  },
  "prop-elevation": {
    component: __16,
    source: __16_raw
  },
  "prop-flat": {
    component: __17,
    source: __17_raw
  },
  "prop-floating": {
    component: __18,
    source: __18_raw
  },
  "prop-icon": {
    component: __19,
    source: __19_raw
  },
  "prop-loaders": {
    component: __20,
    source: __20_raw
  },
  "prop-outlined": {
    component: __21,
    source: __21_raw
  },
  "prop-plain": {
    component: __22,
    source: __22_raw
  },
  "prop-ripple": {
    component: __23,
    source: __23_raw
  },
  "prop-rounded": {
    component: __24,
    source: __24_raw
  },
  "prop-size": {
    component: __25,
    source: __25_raw
  },
  "prop-tile": {
    component: __26,
    source: __26_raw
  },
  "prop-variant": {
    component: __27,
    source: __27_raw
  },
  "slot-loader": {
    component: __28,
    source: __28_raw
  },
  "slot-prepend-append": {
    component: __29,
    source: __29_raw
  },
  "usage": {
    component: __30,
    source: __30_raw
  }
};
export {
  vBtn as default
};
