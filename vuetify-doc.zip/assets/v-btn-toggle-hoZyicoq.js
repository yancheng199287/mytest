import { J as ref, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, b as createVNode, e as createBaseVNode, l as createElementBlock, t as toDisplayString, y as _export_sfc, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1$7 = /* @__PURE__ */ createBaseVNode("div", { class: "mx-4" }, null, -1);
const _sfc_main$7 = {
  __name: "misc-toolbar",
  setup(__props) {
    const toggleExclusive = ref(2);
    const toggleMultiple = ref([1, 2, 3]);
    return (_ctx, _cache) => {
      const _component_v_spacer = resolveComponent("v-spacer");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_btn_toggle = resolveComponent("v-btn-toggle");
      const _component_v_toolbar = resolveComponent("v-toolbar");
      return openBlock(), createBlock(_component_v_toolbar, null, {
        default: withCtx(() => [
          createVNode(_component_v_spacer),
          createVNode(_component_v_btn_toggle, {
            modelValue: toggleMultiple.value,
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => toggleMultiple.value = $event),
            color: "primary",
            variant: "plain",
            multiple: ""
          }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, {
                value: 1,
                icon: "mdi-format-bold"
              }),
              createVNode(_component_v_btn, {
                value: 2,
                icon: "mdi-format-italic"
              }),
              createVNode(_component_v_btn, {
                value: 3,
                icon: "mdi-format-underline"
              }),
              createVNode(_component_v_btn, {
                value: 4,
                icon: "mdi-format-color-fill"
              })
            ]),
            _: 1
          }, 8, ["modelValue"]),
          _hoisted_1$7,
          createVNode(_component_v_btn_toggle, {
            modelValue: toggleExclusive.value,
            "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => toggleExclusive.value = $event),
            color: "primary",
            variant: "plain",
            dense: "",
            group: ""
          }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, {
                value: 1,
                icon: "mdi-format-align-left"
              }),
              createVNode(_component_v_btn, {
                value: 2,
                icon: "mdi-format-align-center"
              }),
              createVNode(_component_v_btn, {
                value: 3,
                icon: "mdi-format-align-right"
              }),
              createVNode(_component_v_btn, {
                value: 4,
                icon: "mdi-format-align-justify"
              })
            ]),
            _: 1
          }, 8, ["modelValue"])
        ]),
        _: 1
      });
    };
  }
};
const __0 = _sfc_main$7;
const __0_raw = `<template>
  <v-toolbar>
    <!-- <v-overflow-btn
      :items="dropdown_font"
      label="Select font"
      hide-details
      class="pa-0"
    ></v-overflow-btn>

    <v-divider vertical></v-divider>

    <v-overflow-btn
      :items="dropdown_edit"
      editable
      label="Select size"
      hide-details
      class="pa-0"
      overflow
    ></v-overflow-btn>

    <v-divider vertical></v-divider> -->

    <v-spacer></v-spacer>

    <v-btn-toggle
      v-model="toggleMultiple"
      color="primary"
      variant="plain"
      multiple
    >
      <v-btn
        :value="1"
        icon="mdi-format-bold"
      ></v-btn>

      <v-btn
        :value="2"
        icon="mdi-format-italic"
      ></v-btn>

      <v-btn
        :value="3"
        icon="mdi-format-underline"
      ></v-btn>

      <v-btn
        :value="4"
        icon="mdi-format-color-fill"
      ></v-btn>
    </v-btn-toggle>

    <div class="mx-4"></div>

    <v-btn-toggle
      v-model="toggleExclusive"
      color="primary"
      variant="plain"
      dense
      group
    >
      <v-btn
        :value="1"
        icon="mdi-format-align-left"
      ></v-btn>

      <v-btn
        :value="2"
        icon="mdi-format-align-center"
      ></v-btn>

      <v-btn
        :value="3"
        icon="mdi-format-align-right"
      ></v-btn>

      <v-btn
        :value="4"
        icon="mdi-format-align-justify"
      ></v-btn>
    </v-btn-toggle>
  </v-toolbar>
</template>

<script setup>
  import { ref } from 'vue'

  const toggleExclusive = ref(2)
  const toggleMultiple = ref([1, 2, 3])
<\/script>

<script>
  export default {
    data () {
      return {
        toggleExclusive: 2,
        toggleMultiple: [1, 2, 3],
      }
    },
  }
<\/script>
`;
const _hoisted_1$6 = { class: "d-flex justify-space-between pa-4 pb-0" };
const _hoisted_2$4 = { class: "d-flex align-center flex-column justify-center" };
const _sfc_main$6 = {
  __name: "misc-wysiwyg",
  setup(__props) {
    const alignment = ref(1);
    const formatting = ref([]);
    const value = ref("Toggle button requirements.\n\nHave at least three toggle buttons in a group\nLabel buttons with text, an icon, or");
    return (_ctx, _cache) => {
      const _component_v_icon = resolveComponent("v-icon");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_sheet = resolveComponent("v-sheet");
      const _component_v_btn_toggle = resolveComponent("v-btn-toggle");
      const _component_v_textarea = resolveComponent("v-textarea");
      const _component_v_card = resolveComponent("v-card");
      return openBlock(), createBlock(_component_v_card, {
        class: "mx-auto",
        "max-width": "600"
      }, {
        default: withCtx(() => [
          createBaseVNode("div", _hoisted_1$6, [
            createVNode(_component_v_btn_toggle, {
              modelValue: formatting.value,
              "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => formatting.value = $event),
              variant: "outlined",
              divided: "",
              multiple: ""
            }, {
              default: withCtx(() => [
                createVNode(_component_v_btn, null, {
                  default: withCtx(() => [
                    createVNode(_component_v_icon, { icon: "mdi-format-italic" })
                  ]),
                  _: 1
                }),
                createVNode(_component_v_btn, null, {
                  default: withCtx(() => [
                    createVNode(_component_v_icon, { icon: "mdi-format-bold" })
                  ]),
                  _: 1
                }),
                createVNode(_component_v_btn, null, {
                  default: withCtx(() => [
                    createVNode(_component_v_icon, { icon: "mdi-format-underline" })
                  ]),
                  _: 1
                }),
                createVNode(_component_v_btn, null, {
                  default: withCtx(() => [
                    createBaseVNode("div", _hoisted_2$4, [
                      createVNode(_component_v_icon, { icon: "mdi-format-color-text" }),
                      createVNode(_component_v_sheet, {
                        color: "purple",
                        height: "4",
                        width: "26",
                        tile: ""
                      })
                    ])
                  ]),
                  _: 1
                })
              ]),
              _: 1
            }, 8, ["modelValue"]),
            createVNode(_component_v_btn_toggle, {
              modelValue: alignment.value,
              "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => alignment.value = $event),
              variant: "outlined",
              divided: ""
            }, {
              default: withCtx(() => [
                createVNode(_component_v_btn, null, {
                  default: withCtx(() => [
                    createVNode(_component_v_icon, { icon: "mdi-format-align-center" })
                  ]),
                  _: 1
                }),
                createVNode(_component_v_btn, null, {
                  default: withCtx(() => [
                    createVNode(_component_v_icon, { icon: "mdi-format-align-left" })
                  ]),
                  _: 1
                }),
                createVNode(_component_v_btn, null, {
                  default: withCtx(() => [
                    createVNode(_component_v_icon, { icon: "mdi-format-align-right" })
                  ]),
                  _: 1
                })
              ]),
              _: 1
            }, 8, ["modelValue"])
          ]),
          createVNode(_component_v_sheet, { class: "pa-4 text-center" }, {
            default: withCtx(() => [
              createVNode(_component_v_textarea, {
                modelValue: value.value,
                "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => value.value = $event),
                rows: "2",
                variant: "outlined",
                "auto-grow": "",
                "full-width": "",
                "hide-details": ""
              }, null, 8, ["modelValue"])
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __1 = _sfc_main$6;
const __1_raw = `<template>
  <v-card
    class="mx-auto"
    max-width="600"
  >
    <div class="d-flex justify-space-between pa-4 pb-0">
      <v-btn-toggle
        v-model="formatting"
        variant="outlined"
        divided
        multiple
      >
        <v-btn>
          <v-icon icon="mdi-format-italic"></v-icon>
        </v-btn>

        <v-btn>
          <v-icon icon="mdi-format-bold"></v-icon>
        </v-btn>

        <v-btn>
          <v-icon icon="mdi-format-underline"></v-icon>
        </v-btn>

        <v-btn>
          <div class="d-flex align-center flex-column justify-center">
            <v-icon icon="mdi-format-color-text"></v-icon>

            <v-sheet
              color="purple"
              height="4"
              width="26"
              tile
            ></v-sheet>
          </div>
        </v-btn>
      </v-btn-toggle>

      <v-btn-toggle
        v-model="alignment"
        variant="outlined"
        divided
      >
        <v-btn>
          <v-icon icon="mdi-format-align-center"></v-icon>
        </v-btn>

        <v-btn>
          <v-icon icon="mdi-format-align-left"></v-icon>
        </v-btn>

        <v-btn>
          <v-icon icon="mdi-format-align-right"></v-icon>
        </v-btn>
      </v-btn-toggle>
    </div>

    <v-sheet class="pa-4 text-center">
      <v-textarea
        v-model="value"
        rows="2"
        variant="outlined"
        auto-grow
        full-width
        hide-details
      ></v-textarea>
    </v-sheet>
  </v-card>
</template>

<script setup>
  import { ref } from 'vue'

  const alignment = ref(1)
  const formatting = ref([])
  const value = ref('Toggle button requirements.\\n\\nHave at least three toggle buttons in a group\\nLabel buttons with text, an icon, or')
<\/script>

<script>
  export default {
    data: () => ({
      alignment: 1,
      formatting: [],
      value: 'Toggle button requirements.\\n\\nHave at least three toggle buttons in a group\\nLabel buttons with text, an icon, or',
    }),
  }
<\/script>
`;
const _hoisted_1$5 = { class: "d-flex align-center flex-column bg-grey-lighten-4 pa-6" };
const _sfc_main$5 = {
  __name: "prop-divided",
  setup(__props) {
    const toggle = ref(null);
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_btn_toggle = resolveComponent("v-btn-toggle");
      return openBlock(), createElementBlock("div", _hoisted_1$5, [
        createVNode(_component_v_btn_toggle, {
          modelValue: toggle.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => toggle.value = $event),
          divided: ""
        }, {
          default: withCtx(() => [
            createVNode(_component_v_btn, { icon: "mdi-format-align-left" }),
            createVNode(_component_v_btn, { icon: "mdi-format-align-center" }),
            createVNode(_component_v_btn, { icon: "mdi-format-align-right" }),
            createVNode(_component_v_btn, { icon: "mdi-format-align-justify" })
          ]),
          _: 1
        }, 8, ["modelValue"])
      ]);
    };
  }
};
const __2 = _sfc_main$5;
const __2_raw = `<template>
  <div class="d-flex align-center flex-column bg-grey-lighten-4 pa-6">
    <v-btn-toggle
      v-model="toggle"
      divided
    >
      <v-btn icon="mdi-format-align-left"></v-btn>
      <v-btn icon="mdi-format-align-center"></v-btn>
      <v-btn icon="mdi-format-align-right"></v-btn>
      <v-btn icon="mdi-format-align-justify"></v-btn>
    </v-btn-toggle>
  </div>
</template>

<script setup>
  import { ref } from 'vue'

  const toggle = ref(null)
<\/script>

<script>
  export default {
    data: () => ({
      toggle: null,
    }),
  }
<\/script>
`;
const _hoisted_1$4 = { class: "d-flex flex-column align-center bg-grey-lighten-4 pa-6" };
const _hoisted_2$3 = { class: "pt-2" };
const _sfc_main$4 = {
  __name: "prop-mandatory",
  setup(__props) {
    const toggle = ref();
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_btn_toggle = resolveComponent("v-btn-toggle");
      return openBlock(), createElementBlock("div", _hoisted_1$4, [
        createVNode(_component_v_btn_toggle, {
          modelValue: toggle.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => toggle.value = $event),
          color: "primary",
          mandatory: ""
        }, {
          default: withCtx(() => [
            createVNode(_component_v_btn, {
              icon: "mdi-format-align-left",
              value: "left"
            }),
            createVNode(_component_v_btn, {
              icon: "mdi-format-align-center",
              value: "center"
            }),
            createVNode(_component_v_btn, {
              icon: "mdi-format-align-right",
              value: "right"
            }),
            createVNode(_component_v_btn, {
              icon: "mdi-format-align-justify",
              value: "justify"
            })
          ]),
          _: 1
        }, 8, ["modelValue"]),
        createBaseVNode("pre", _hoisted_2$3, toDisplayString(toggle.value), 1)
      ]);
    };
  }
};
const __3 = _sfc_main$4;
const __3_raw = `<template>
  <div class="d-flex flex-column align-center bg-grey-lighten-4 pa-6">
    <v-btn-toggle
      v-model="toggle"
      color="primary"
      mandatory
    >
      <v-btn icon="mdi-format-align-left" value="left"></v-btn>
      <v-btn icon="mdi-format-align-center" value="center"></v-btn>
      <v-btn icon="mdi-format-align-right" value="right"></v-btn>
      <v-btn icon="mdi-format-align-justify" value="justify"></v-btn>
    </v-btn-toggle>
    <pre class="pt-2">{{ toggle }}</pre>
  </div>
</template>

<script setup>
  import { ref } from 'vue'

  const toggle = ref()
<\/script>

<script>
  export default {
    data () {
      return {
        toggle: undefined,
      }
    },
  }
<\/script>
`;
const _hoisted_1$3 = { class: "d-flex flex-column align-center bg-grey-lighten-4 pa-6" };
const _hoisted_2$2 = { class: "pt-2" };
const _sfc_main$3 = {
  __name: "prop-multiple",
  setup(__props) {
    const toggle = ref([]);
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_btn_toggle = resolveComponent("v-btn-toggle");
      return openBlock(), createElementBlock("div", _hoisted_1$3, [
        createVNode(_component_v_btn_toggle, {
          modelValue: toggle.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => toggle.value = $event),
          multiple: ""
        }, {
          default: withCtx(() => [
            createVNode(_component_v_btn, {
              icon: "mdi-format-align-left",
              value: "left"
            }),
            createVNode(_component_v_btn, {
              icon: "mdi-format-align-center",
              value: "center"
            }),
            createVNode(_component_v_btn, {
              icon: "mdi-format-align-right",
              value: "right"
            }),
            createVNode(_component_v_btn, {
              icon: "mdi-format-align-justify",
              value: "justify"
            })
          ]),
          _: 1
        }, 8, ["modelValue"]),
        createBaseVNode("pre", _hoisted_2$2, toDisplayString(toggle.value), 1)
      ]);
    };
  }
};
const __4 = _sfc_main$3;
const __4_raw = `<template>
  <div class="d-flex flex-column align-center bg-grey-lighten-4 pa-6">
    <v-btn-toggle
      v-model="toggle"
      multiple
    >
      <v-btn icon="mdi-format-align-left" value="left"></v-btn>
      <v-btn icon="mdi-format-align-center" value="center"></v-btn>
      <v-btn icon="mdi-format-align-right" value="right"></v-btn>
      <v-btn icon="mdi-format-align-justify" value="justify"></v-btn>
    </v-btn-toggle>

    <pre class="pt-2">{{ toggle }}</pre>
  </div>
</template>

<script setup>
  import { ref } from 'vue'

  const toggle = ref([])
<\/script>

<script>
  export default {
    data () {
      return {
        toggle: [],
      }
    },
  }
<\/script>
`;
const _sfc_main$2 = {};
const _hoisted_1$2 = { class: "d-flex justify-space-around bg-grey-lighten-4 pa-6" };
function _sfc_render$1(_ctx, _cache) {
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_btn_toggle = resolveComponent("v-btn-toggle");
  return openBlock(), createElementBlock("div", _hoisted_1$2, [
    createVNode(_component_v_btn_toggle, { rounded: "0" }, {
      default: withCtx(() => [
        createVNode(_component_v_btn, { icon: "mdi-format-align-left" }),
        createVNode(_component_v_btn, { icon: "mdi-format-align-center" }),
        createVNode(_component_v_btn, { icon: "mdi-format-align-right" }),
        createVNode(_component_v_btn, { icon: "mdi-format-align-justify" })
      ]),
      _: 1
    }),
    createVNode(_component_v_btn_toggle, { rounded: "xl" }, {
      default: withCtx(() => [
        createVNode(_component_v_btn, { icon: "mdi-format-align-left" }),
        createVNode(_component_v_btn, { icon: "mdi-format-align-center" }),
        createVNode(_component_v_btn, { icon: "mdi-format-align-right" }),
        createVNode(_component_v_btn, { icon: "mdi-format-align-justify" })
      ]),
      _: 1
    })
  ]);
}
const __5 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["render", _sfc_render$1]]);
const __5_raw = '<template>\n  <div class="d-flex justify-space-around bg-grey-lighten-4 pa-6">\n    <v-btn-toggle\n      rounded="0"\n    >\n      <v-btn icon="mdi-format-align-left"></v-btn>\n      <v-btn icon="mdi-format-align-center"></v-btn>\n      <v-btn icon="mdi-format-align-right"></v-btn>\n      <v-btn icon="mdi-format-align-justify"></v-btn>\n    </v-btn-toggle>\n\n    <v-btn-toggle\n      rounded="xl"\n    >\n      <v-btn icon="mdi-format-align-left"></v-btn>\n      <v-btn icon="mdi-format-align-center"></v-btn>\n      <v-btn icon="mdi-format-align-right"></v-btn>\n      <v-btn icon="mdi-format-align-justify"></v-btn>\n    </v-btn-toggle>\n  </div>\n</template>\n';
const _hoisted_1$1 = { class: "d-flex align-center flex-column bg-grey-lighten-4 pa-6" };
const _hoisted_2$1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-subtitle-2" }, "Default", -1);
const _hoisted_3$1 = /* @__PURE__ */ createBaseVNode("div", { class: "mt-6 text-subtitle-2" }, "Text", -1);
const _hoisted_4$1 = /* @__PURE__ */ createBaseVNode("div", { class: "mt-6 text-subtitle-2" }, "Plain", -1);
const _hoisted_5$1 = /* @__PURE__ */ createBaseVNode("div", { class: "mt-6 text-subtitle-2" }, "Outlined", -1);
const _sfc_main$1 = {
  __name: "prop-variant",
  setup(__props) {
    const toggle = ref(null);
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_btn_toggle = resolveComponent("v-btn-toggle");
      return openBlock(), createElementBlock("div", _hoisted_1$1, [
        _hoisted_2$1,
        createVNode(_component_v_btn_toggle, {
          modelValue: toggle.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => toggle.value = $event),
          color: "primary"
        }, {
          default: withCtx(() => [
            createVNode(_component_v_btn, { icon: "mdi-format-align-left" }),
            createVNode(_component_v_btn, { icon: "mdi-format-align-center" }),
            createVNode(_component_v_btn, { icon: "mdi-format-align-right" }),
            createVNode(_component_v_btn, { icon: "mdi-format-align-justify" })
          ]),
          _: 1
        }, 8, ["modelValue"]),
        _hoisted_3$1,
        createVNode(_component_v_btn_toggle, {
          modelValue: toggle.value,
          "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => toggle.value = $event),
          color: "primary",
          variant: "text"
        }, {
          default: withCtx(() => [
            createVNode(_component_v_btn, { icon: "mdi-format-align-left" }),
            createVNode(_component_v_btn, { icon: "mdi-format-align-center" }),
            createVNode(_component_v_btn, { icon: "mdi-format-align-right" }),
            createVNode(_component_v_btn, { icon: "mdi-format-align-justify" })
          ]),
          _: 1
        }, 8, ["modelValue"]),
        _hoisted_4$1,
        createVNode(_component_v_btn_toggle, {
          modelValue: toggle.value,
          "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => toggle.value = $event),
          color: "primary",
          variant: "plain"
        }, {
          default: withCtx(() => [
            createVNode(_component_v_btn, { icon: "mdi-format-align-left" }),
            createVNode(_component_v_btn, { icon: "mdi-format-align-center" }),
            createVNode(_component_v_btn, { icon: "mdi-format-align-right" }),
            createVNode(_component_v_btn, { icon: "mdi-format-align-justify" })
          ]),
          _: 1
        }, 8, ["modelValue"]),
        _hoisted_5$1,
        createVNode(_component_v_btn_toggle, {
          modelValue: toggle.value,
          "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => toggle.value = $event),
          color: "primary",
          variant: "outlined"
        }, {
          default: withCtx(() => [
            createVNode(_component_v_btn, { icon: "mdi-format-align-left" }),
            createVNode(_component_v_btn, { icon: "mdi-format-align-center" }),
            createVNode(_component_v_btn, { icon: "mdi-format-align-right" }),
            createVNode(_component_v_btn, { icon: "mdi-format-align-justify" })
          ]),
          _: 1
        }, 8, ["modelValue"])
      ]);
    };
  }
};
const __6 = _sfc_main$1;
const __6_raw = `<template>
  <div class="d-flex align-center flex-column bg-grey-lighten-4 pa-6">
    <div class="text-subtitle-2">Default</div>
    <v-btn-toggle
      v-model="toggle"
      color="primary"
    >
      <v-btn icon="mdi-format-align-left"></v-btn>
      <v-btn icon="mdi-format-align-center"></v-btn>
      <v-btn icon="mdi-format-align-right"></v-btn>
      <v-btn icon="mdi-format-align-justify"></v-btn>
    </v-btn-toggle>

    <div class="mt-6 text-subtitle-2">Text</div>
    <v-btn-toggle
      v-model="toggle"
      color="primary"
      variant="text"
    >
      <v-btn icon="mdi-format-align-left"></v-btn>
      <v-btn icon="mdi-format-align-center"></v-btn>
      <v-btn icon="mdi-format-align-right"></v-btn>
      <v-btn icon="mdi-format-align-justify"></v-btn>
    </v-btn-toggle>

    <div class="mt-6 text-subtitle-2">Plain</div>
    <v-btn-toggle
      v-model="toggle"
      color="primary"
      variant="plain"
    >
      <v-btn icon="mdi-format-align-left"></v-btn>
      <v-btn icon="mdi-format-align-center"></v-btn>
      <v-btn icon="mdi-format-align-right"></v-btn>
      <v-btn icon="mdi-format-align-justify"></v-btn>
    </v-btn-toggle>

    <div class="mt-6 text-subtitle-2">Outlined</div>
    <v-btn-toggle
      v-model="toggle"
      color="primary"
      variant="outlined"
    >
      <v-btn icon="mdi-format-align-left"></v-btn>
      <v-btn icon="mdi-format-align-center"></v-btn>
      <v-btn icon="mdi-format-align-right"></v-btn>
      <v-btn icon="mdi-format-align-justify"></v-btn>
    </v-btn-toggle>
  </div>
</template>

<script setup>
  import { ref } from 'vue'

  const toggle = ref(null)
<\/script>

<script>
  export default {
    data: () => ({
      toggle: null,
    }),
  }
<\/script>
`;
const _sfc_main = {
  data() {
    return {
      text: "center",
      icon: "justify",
      toggle_none: null,
      toggle_one: 0,
      toggle_exclusive: 2,
      toggle_multiple: [0, 1, 2]
    };
  }
};
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("p", null, "Exclusive", -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("p", null, "Multiple", -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("p", null, "No Options Selected", -1);
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("p", null, "Mandatory", -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("p", null, "Text Options", -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("p", null, "Text & Icon Options", -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("span", { class: "hidden-sm-and-down" }, "Left", -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("span", { class: "hidden-sm-and-down" }, "Center", -1);
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("span", { class: "hidden-sm-and-down" }, "Right", -1);
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("span", { class: "hidden-sm-and-down" }, "Justify", -1);
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_v_icon = resolveComponent("v-icon");
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_btn_toggle = resolveComponent("v-btn-toggle");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, null, {
    default: withCtx(() => [
      createVNode(_component_v_row, null, {
        default: withCtx(() => [
          createVNode(_component_v_col, {
            class: "py-2",
            cols: "12",
            sm: "6"
          }, {
            default: withCtx(() => [
              _hoisted_1,
              createVNode(_component_v_btn_toggle, {
                modelValue: $data.toggle_exclusive,
                "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => $data.toggle_exclusive = $event)
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_btn, null, {
                    default: withCtx(() => [
                      createVNode(_component_v_icon, null, {
                        default: withCtx(() => [
                          createTextVNode("mdi-format-align-left")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_btn, null, {
                    default: withCtx(() => [
                      createVNode(_component_v_icon, null, {
                        default: withCtx(() => [
                          createTextVNode("mdi-format-align-center")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_btn, null, {
                    default: withCtx(() => [
                      createVNode(_component_v_icon, null, {
                        default: withCtx(() => [
                          createTextVNode("mdi-format-align-right")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_btn, null, {
                    default: withCtx(() => [
                      createVNode(_component_v_icon, null, {
                        default: withCtx(() => [
                          createTextVNode("mdi-format-align-justify")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }, 8, ["modelValue"])
            ]),
            _: 1
          }),
          createVNode(_component_v_col, {
            class: "py-2",
            cols: "12",
            sm: "6"
          }, {
            default: withCtx(() => [
              _hoisted_2,
              createVNode(_component_v_btn_toggle, {
                modelValue: $data.toggle_multiple,
                "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => $data.toggle_multiple = $event),
                "background-color": "primary",
                dark: "",
                multiple: ""
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_btn, null, {
                    default: withCtx(() => [
                      createVNode(_component_v_icon, null, {
                        default: withCtx(() => [
                          createTextVNode("mdi-format-bold")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_btn, null, {
                    default: withCtx(() => [
                      createVNode(_component_v_icon, null, {
                        default: withCtx(() => [
                          createTextVNode("mdi-format-italic")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_btn, null, {
                    default: withCtx(() => [
                      createVNode(_component_v_icon, null, {
                        default: withCtx(() => [
                          createTextVNode("mdi-format-underline")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_btn, null, {
                    default: withCtx(() => [
                      createVNode(_component_v_icon, null, {
                        default: withCtx(() => [
                          createTextVNode("mdi-format-color-fill")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }, 8, ["modelValue"])
            ]),
            _: 1
          }),
          createVNode(_component_v_col, {
            class: "py-2",
            cols: "12",
            sm: "6"
          }, {
            default: withCtx(() => [
              _hoisted_3,
              createVNode(_component_v_btn_toggle, {
                modelValue: $data.toggle_none,
                "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => $data.toggle_none = $event)
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_btn, null, {
                    default: withCtx(() => [
                      createVNode(_component_v_icon, null, {
                        default: withCtx(() => [
                          createTextVNode("mdi-format-align-left")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_btn, null, {
                    default: withCtx(() => [
                      createVNode(_component_v_icon, null, {
                        default: withCtx(() => [
                          createTextVNode("mdi-format-align-center")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_btn, null, {
                    default: withCtx(() => [
                      createVNode(_component_v_icon, null, {
                        default: withCtx(() => [
                          createTextVNode("mdi-format-align-right")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_btn, null, {
                    default: withCtx(() => [
                      createVNode(_component_v_icon, null, {
                        default: withCtx(() => [
                          createTextVNode("mdi-format-align-justify")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }, 8, ["modelValue"])
            ]),
            _: 1
          }),
          createVNode(_component_v_col, {
            class: "py-2",
            cols: "12",
            sm: "6"
          }, {
            default: withCtx(() => [
              _hoisted_4,
              createVNode(_component_v_btn_toggle, {
                modelValue: $data.toggle_one,
                "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => $data.toggle_one = $event),
                mandatory: "",
                shaped: ""
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_btn, null, {
                    default: withCtx(() => [
                      createVNode(_component_v_icon, null, {
                        default: withCtx(() => [
                          createTextVNode("mdi-format-align-left")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_btn, null, {
                    default: withCtx(() => [
                      createVNode(_component_v_icon, null, {
                        default: withCtx(() => [
                          createTextVNode("mdi-format-align-center")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_btn, null, {
                    default: withCtx(() => [
                      createVNode(_component_v_icon, null, {
                        default: withCtx(() => [
                          createTextVNode("mdi-format-align-right")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_btn, null, {
                    default: withCtx(() => [
                      createVNode(_component_v_icon, null, {
                        default: withCtx(() => [
                          createTextVNode("mdi-format-align-justify")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }, 8, ["modelValue"])
            ]),
            _: 1
          }),
          createVNode(_component_v_col, {
            class: "py-2",
            cols: "12"
          }, {
            default: withCtx(() => [
              _hoisted_5,
              createVNode(_component_v_btn_toggle, {
                modelValue: $data.text,
                "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => $data.text = $event),
                color: "deep-purple-accent-3",
                rounded: "0",
                group: ""
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_btn, { value: "left" }, {
                    default: withCtx(() => [
                      createTextVNode(" Left ")
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_btn, { value: "center" }, {
                    default: withCtx(() => [
                      createTextVNode(" Center ")
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_btn, { value: "right" }, {
                    default: withCtx(() => [
                      createTextVNode(" Right ")
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_btn, { value: "justify" }, {
                    default: withCtx(() => [
                      createTextVNode(" Justify ")
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }, 8, ["modelValue"])
            ]),
            _: 1
          }),
          createVNode(_component_v_col, {
            class: "py-2",
            cols: "12"
          }, {
            default: withCtx(() => [
              _hoisted_6,
              createVNode(_component_v_btn_toggle, {
                modelValue: $data.icon,
                "onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => $data.icon = $event),
                borderless: ""
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_btn, { value: "left" }, {
                    default: withCtx(() => [
                      _hoisted_7,
                      createVNode(_component_v_icon, { end: "" }, {
                        default: withCtx(() => [
                          createTextVNode(" mdi-format-align-left ")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_btn, { value: "center" }, {
                    default: withCtx(() => [
                      _hoisted_8,
                      createVNode(_component_v_icon, { end: "" }, {
                        default: withCtx(() => [
                          createTextVNode(" mdi-format-align-center ")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_btn, { value: "right" }, {
                    default: withCtx(() => [
                      _hoisted_9,
                      createVNode(_component_v_icon, { end: "" }, {
                        default: withCtx(() => [
                          createTextVNode(" mdi-format-align-right ")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_btn, { value: "justify" }, {
                    default: withCtx(() => [
                      _hoisted_10,
                      createVNode(_component_v_icon, { end: "" }, {
                        default: withCtx(() => [
                          createTextVNode(" mdi-format-align-justify ")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }, 8, ["modelValue"])
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __7 = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
const __7_raw = `<template>
  <v-container>
    <v-row>
      <v-col
        class="py-2"
        cols="12"
        sm="6"
      >
        <p>Exclusive</p>

        <v-btn-toggle v-model="toggle_exclusive">
          <v-btn>
            <v-icon>mdi-format-align-left</v-icon>
          </v-btn>

          <v-btn>
            <v-icon>mdi-format-align-center</v-icon>
          </v-btn>

          <v-btn>
            <v-icon>mdi-format-align-right</v-icon>
          </v-btn>

          <v-btn>
            <v-icon>mdi-format-align-justify</v-icon>
          </v-btn>
        </v-btn-toggle>
      </v-col>

      <v-col
        class="py-2"
        cols="12"
        sm="6"
      >
        <p>Multiple</p>

        <v-btn-toggle
          v-model="toggle_multiple"
          background-color="primary"
          dark
          multiple
        >
          <v-btn>
            <v-icon>mdi-format-bold</v-icon>
          </v-btn>

          <v-btn>
            <v-icon>mdi-format-italic</v-icon>
          </v-btn>

          <v-btn>
            <v-icon>mdi-format-underline</v-icon>
          </v-btn>

          <v-btn>
            <v-icon>mdi-format-color-fill</v-icon>
          </v-btn>
        </v-btn-toggle>
      </v-col>

      <v-col
        class="py-2"
        cols="12"
        sm="6"
      >
        <p>No Options Selected</p>

        <v-btn-toggle v-model="toggle_none">
          <v-btn>
            <v-icon>mdi-format-align-left</v-icon>
          </v-btn>

          <v-btn>
            <v-icon>mdi-format-align-center</v-icon>
          </v-btn>
          <v-btn>
            <v-icon>mdi-format-align-right</v-icon>
          </v-btn>

          <v-btn>
            <v-icon>mdi-format-align-justify</v-icon>
          </v-btn>
        </v-btn-toggle>
      </v-col>

      <v-col
        class="py-2"
        cols="12"
        sm="6"
      >
        <p>Mandatory</p>

        <v-btn-toggle
          v-model="toggle_one"
          mandatory
          shaped
        >
          <v-btn>
            <v-icon>mdi-format-align-left</v-icon>
          </v-btn>

          <v-btn>
            <v-icon>mdi-format-align-center</v-icon>
          </v-btn>

          <v-btn>
            <v-icon>mdi-format-align-right</v-icon>
          </v-btn>

          <v-btn>
            <v-icon>mdi-format-align-justify</v-icon>
          </v-btn>
        </v-btn-toggle>
      </v-col>

      <v-col
        class="py-2"
        cols="12"
      >
        <p>Text Options</p>

        <v-btn-toggle
          v-model="text"
          color="deep-purple-accent-3"
          rounded="0"
          group
        >
          <v-btn value="left">
            Left
          </v-btn>

          <v-btn value="center">
            Center
          </v-btn>

          <v-btn value="right">
            Right
          </v-btn>

          <v-btn value="justify">
            Justify
          </v-btn>
        </v-btn-toggle>
      </v-col>

      <v-col
        class="py-2"
        cols="12"
      >
        <p>Text &amp; Icon Options</p>

        <v-btn-toggle
          v-model="icon"
          borderless
        >
          <v-btn value="left">
            <span class="hidden-sm-and-down">Left</span>

            <v-icon end>
              mdi-format-align-left
            </v-icon>
          </v-btn>

          <v-btn value="center">
            <span class="hidden-sm-and-down">Center</span>

            <v-icon end>
              mdi-format-align-center
            </v-icon>
          </v-btn>

          <v-btn value="right">
            <span class="hidden-sm-and-down">Right</span>

            <v-icon end>
              mdi-format-align-right
            </v-icon>
          </v-btn>

          <v-btn value="justify">
            <span class="hidden-sm-and-down">Justify</span>

            <v-icon end>
              mdi-format-align-justify
            </v-icon>
          </v-btn>
        </v-btn-toggle>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
  export default {
    data () {
      return {
        text: 'center',
        icon: 'justify',
        toggle_none: null,
        toggle_one: 0,
        toggle_exclusive: 2,
        toggle_multiple: [0, 1, 2],
      }
    },
  }
<\/script>
`;
const vBtnToggle = {
  "misc-toolbar": {
    component: __0,
    source: __0_raw
  },
  "misc-wysiwyg": {
    component: __1,
    source: __1_raw
  },
  "prop-divided": {
    component: __2,
    source: __2_raw
  },
  "prop-mandatory": {
    component: __3,
    source: __3_raw
  },
  "prop-multiple": {
    component: __4,
    source: __4_raw
  },
  "prop-rounded": {
    component: __5,
    source: __5_raw
  },
  "prop-variant": {
    component: __6,
    source: __6_raw
  },
  "usage": {
    component: __7,
    source: __7_raw
  }
};
export {
  vBtnToggle as default
};
