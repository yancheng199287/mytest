import { y as _export_sfc, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, b as createVNode, h as createTextVNode, e as createBaseVNode, J as ref, q as createCommentVNode, l as createElementBlock, F as Fragment, v as renderList, t as toDisplayString, D as withDirectives, aq as vShow, a1 as normalizeStyle, j as computed, ag as propsToString, f as unref, E as isRef, ak as normalizeProps, al as guardReactiveProps } from "./index-DGybHjCP.js";
import { _ as _sfc_main$r } from "./UsageExample-M8CmNipa.js";
const _sfc_main$q = {};
const _hoisted_1$f = /* @__PURE__ */ createBaseVNode("span", { class: "font-weight-black" }, "Welcome to Vuetify", -1);
function _sfc_render$g(_ctx, _cache) {
  const _component_v_card_text = resolveComponent("v-card-text");
  const _component_v_card = resolveComponent("v-card");
  return openBlock(), createBlock(_component_v_card, {
    class: "mx-auto",
    "prepend-icon": "$vuetify",
    subtitle: "The #1 Vue UI Library",
    width: "400"
  }, {
    title: withCtx(() => [
      _hoisted_1$f
    ]),
    default: withCtx(() => [
      createVNode(_component_v_card_text, { class: "bg-surface-light pt-4" }, {
        default: withCtx(() => [
          createTextVNode(" Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem! ")
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __0 = /* @__PURE__ */ _export_sfc(_sfc_main$q, [["render", _sfc_render$g]]);
const __0_raw = '<template>\n  <v-card\n    class="mx-auto"\n    prepend-icon="$vuetify"\n    subtitle="The #1 Vue UI Library"\n    width="400"\n  >\n    <template v-slot:title>\n      <span class="font-weight-black">Welcome to Vuetify</span>\n    </template>\n\n    <v-card-text class="bg-surface-light pt-4">\n      Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!\n    </v-card-text>\n  </v-card>\n</template>\n';
const _sfc_main$p = {};
const _hoisted_1$e = /* @__PURE__ */ createBaseVNode("div", { class: "text-center text-caption" }, "Using Props Only", -1);
const _hoisted_2$b = /* @__PURE__ */ createBaseVNode("div", { class: "text-center text-caption" }, "Using Slots Only", -1);
const _hoisted_3$9 = /* @__PURE__ */ createBaseVNode("div", { class: "text-center text-caption" }, "Using Markup Only", -1);
function _sfc_render$f(_ctx, _cache) {
  const _component_v_card = resolveComponent("v-card");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_card_title = resolveComponent("v-card-title");
  const _component_v_card_subtitle = resolveComponent("v-card-subtitle");
  const _component_v_card_item = resolveComponent("v-card-item");
  const _component_v_card_text = resolveComponent("v-card-text");
  const _component_v_row = resolveComponent("v-row");
  return openBlock(), createBlock(_component_v_row, null, {
    default: withCtx(() => [
      createVNode(_component_v_col, {
        cols: "12",
        md: "4"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_card, {
            subtitle: "This is a card subtitle",
            text: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus!",
            title: "This is a title"
          }),
          _hoisted_1$e
        ]),
        _: 1
      }),
      createVNode(_component_v_col, {
        cols: "12",
        md: "4"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_card, null, {
            title: withCtx(() => [
              createTextVNode(" This is a title ")
            ]),
            subtitle: withCtx(() => [
              createTextVNode(" This is a card subtitle ")
            ]),
            text: withCtx(() => [
              createTextVNode(" Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! ")
            ]),
            _: 1
          }),
          _hoisted_2$b
        ]),
        _: 1
      }),
      createVNode(_component_v_col, {
        cols: "12",
        md: "4"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_card, null, {
            default: withCtx(() => [
              createVNode(_component_v_card_item, null, {
                default: withCtx(() => [
                  createVNode(_component_v_card_title, null, {
                    default: withCtx(() => [
                      createTextVNode("This is a title")
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_card_subtitle, null, {
                    default: withCtx(() => [
                      createTextVNode("This is a card subtitle")
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }),
              createVNode(_component_v_card_text, null, {
                default: withCtx(() => [
                  createTextVNode(" Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          _hoisted_3$9
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __1 = /* @__PURE__ */ _export_sfc(_sfc_main$p, [["render", _sfc_render$f]]);
const __1_raw = '<template>\n  <v-row>\n    <v-col cols="12" md="4">\n      <v-card\n        subtitle="This is a card subtitle"\n        text="Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus!"\n        title="This is a title"\n      ></v-card>\n\n      <div class="text-center text-caption">Using Props Only</div>\n    </v-col>\n\n    <v-col cols="12" md="4">\n      <v-card>\n        <template v-slot:title>\n          This is a title\n        </template>\n\n        <template v-slot:subtitle>\n          This is a card subtitle\n        </template>\n\n        <template v-slot:text>\n          Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus!\n        </template>\n      </v-card>\n\n      <div class="text-center text-caption">Using Slots Only</div>\n    </v-col>\n\n    <v-col cols="12" md="4">\n      <v-card>\n        <v-card-item>\n          <v-card-title>This is a title</v-card-title>\n\n          <v-card-subtitle>This is a card subtitle</v-card-subtitle>\n        </v-card-item>\n\n        <v-card-text>\n          Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus!\n        </v-card-text>\n      </v-card>\n\n      <div class="text-center text-caption">Using Markup Only</div>\n    </v-col>\n  </v-row>\n</template>\n';
const _hoisted_1$d = /* @__PURE__ */ createBaseVNode("div", null, "Word of the Day", -1);
const _hoisted_2$a = /* @__PURE__ */ createBaseVNode("p", { class: "text-h4 font-weight-black" }, "el·ee·mos·y·nar·y", -1);
const _hoisted_3$8 = /* @__PURE__ */ createBaseVNode("p", null, "adjective", -1);
const _hoisted_4$4 = /* @__PURE__ */ createBaseVNode("div", { class: "text-medium-emphasis" }, [
  /* @__PURE__ */ createTextVNode(" relating to or dependent on charity; charitable; charitable donations. Pertaining to alms."),
  /* @__PURE__ */ createBaseVNode("br"),
  /* @__PURE__ */ createTextVNode(' "an eleemosynary educational institution." ')
], -1);
const _hoisted_5$1 = /* @__PURE__ */ createBaseVNode("p", { class: "text-h4" }, "Origin", -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("p", { class: "text-medium-emphasis" }, " late 16th century (as a noun denoting a place where alms were distributed): from medieval Latin eleemosynarius, from late Latin eleemosyna ‘alms’, from Greek eleēmosunē ‘compassion’ ", -1);
const _sfc_main$o = {
  __name: "misc-card-reveal",
  setup(__props) {
    const reveal = ref(false);
    return (_ctx, _cache) => {
      const _component_v_card_text = resolveComponent("v-card-text");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_card_actions = resolveComponent("v-card-actions");
      const _component_v_card = resolveComponent("v-card");
      const _component_v_expand_transition = resolveComponent("v-expand-transition");
      return openBlock(), createBlock(_component_v_card, {
        class: "mx-auto",
        "max-width": "344"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_card_text, null, {
            default: withCtx(() => [
              _hoisted_1$d,
              _hoisted_2$a,
              _hoisted_3$8,
              _hoisted_4$4
            ]),
            _: 1
          }),
          createVNode(_component_v_card_actions, null, {
            default: withCtx(() => [
              createVNode(_component_v_btn, {
                color: "teal-accent-4",
                text: "Learn More",
                variant: "text",
                onClick: _cache[0] || (_cache[0] = ($event) => reveal.value = true)
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_expand_transition, null, {
            default: withCtx(() => [
              reveal.value ? (openBlock(), createBlock(_component_v_card, {
                key: 0,
                class: "position-absolute w-100",
                height: "100%",
                style: { "bottom": "0" }
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_card_text, { class: "pb-0" }, {
                    default: withCtx(() => [
                      _hoisted_5$1,
                      _hoisted_6
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_card_actions, { class: "pt-0" }, {
                    default: withCtx(() => [
                      createVNode(_component_v_btn, {
                        color: "teal-accent-4",
                        text: "Close",
                        variant: "text",
                        onClick: _cache[1] || (_cache[1] = ($event) => reveal.value = false)
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })) : createCommentVNode("", true)
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __2 = _sfc_main$o;
const __2_raw = `<template>
  <v-card
    class="mx-auto"
    max-width="344"
  >
    <v-card-text>
      <div>Word of the Day</div>

      <p class="text-h4 font-weight-black">el·ee·mos·y·nar·y</p>

      <p>adjective</p>

      <div class="text-medium-emphasis">
        relating to or dependent on charity; charitable; charitable donations. Pertaining to alms.<br>
        "an eleemosynary educational institution."
      </div>
    </v-card-text>

    <v-card-actions>
      <v-btn
        color="teal-accent-4"
        text="Learn More"
        variant="text"
        @click="reveal = true"
      ></v-btn>
    </v-card-actions>

    <v-expand-transition>
      <v-card
        v-if="reveal"
        class="position-absolute w-100"
        height="100%"
        style="bottom: 0;"
      >
        <v-card-text class="pb-0">
          <p class="text-h4">Origin</p>

          <p class="text-medium-emphasis">
            late 16th century (as a noun denoting a place where alms were distributed): from medieval Latin eleemosynarius, from late Latin eleemosyna ‘alms’, from Greek eleēmosunē ‘compassion’
          </p>
        </v-card-text>

        <v-card-actions class="pt-0">
          <v-btn
            color="teal-accent-4"
            text="Close"
            variant="text"
            @click="reveal = false"
          ></v-btn>
        </v-card-actions>
      </v-card>
    </v-expand-transition>
  </v-card>
</template>

<script setup>
  import { ref } from 'vue'

  const reveal = ref(false)
<\/script>

<script>
  export default {
    data: () => ({
      reveal: false,
    }),
  }
<\/script>
`;
const _hoisted_1$c = /* @__PURE__ */ createBaseVNode("div", { class: "font-weight-bold ms-1 mb-2" }, "Today", -1);
const _hoisted_2$9 = { class: "mb-4" };
const _hoisted_3$7 = { class: "font-weight-normal" };
const _sfc_main$n = {
  __name: "misc-content-wrapping",
  setup(__props) {
    const messages = [
      {
        from: "You",
        message: `Sure, I'll see you later.`,
        time: "10:42am",
        color: "deep-purple-lighten-1"
      },
      {
        from: "John Doe",
        message: "Yeah, sure. Does 1:00pm work?",
        time: "10:37am",
        color: "green"
      },
      {
        from: "You",
        message: "Did you still want to grab lunch today?",
        time: "9:47am",
        color: "deep-purple-lighten-1"
      }
    ];
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_toolbar_title = resolveComponent("v-toolbar-title");
      const _component_v_toolbar = resolveComponent("v-toolbar");
      const _component_v_img = resolveComponent("v-img");
      const _component_v_timeline_item = resolveComponent("v-timeline-item");
      const _component_v_timeline = resolveComponent("v-timeline");
      const _component_v_card_text = resolveComponent("v-card-text");
      const _component_v_card = resolveComponent("v-card");
      return openBlock(), createBlock(_component_v_card, {
        class: "mx-auto",
        "max-width": "400"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_img, {
            color: "surface-variant",
            height: "200",
            src: "https://cdn.vuetifyjs.com/docs/images/cards/purple-flowers.jpg",
            cover: ""
          }, {
            default: withCtx(() => [
              createVNode(_component_v_toolbar, { color: "transparent" }, {
                prepend: withCtx(() => [
                  createVNode(_component_v_btn, { icon: "$menu" })
                ]),
                append: withCtx(() => [
                  createVNode(_component_v_btn, { icon: "mdi-dots-vertical" })
                ]),
                default: withCtx(() => [
                  createVNode(_component_v_toolbar_title, {
                    class: "text-h6",
                    text: "Messages"
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_card_text, null, {
            default: withCtx(() => [
              _hoisted_1$c,
              createVNode(_component_v_timeline, {
                align: "start",
                density: "compact"
              }, {
                default: withCtx(() => [
                  (openBlock(), createElementBlock(Fragment, null, renderList(messages, (message) => {
                    return createVNode(_component_v_timeline_item, {
                      key: message.time,
                      "dot-color": message.color,
                      size: "x-small"
                    }, {
                      default: withCtx(() => [
                        createBaseVNode("div", _hoisted_2$9, [
                          createBaseVNode("div", _hoisted_3$7, [
                            createBaseVNode("strong", null, toDisplayString(message.from), 1),
                            createTextVNode(" @" + toDisplayString(message.time), 1)
                          ]),
                          createBaseVNode("div", null, toDisplayString(message.message), 1)
                        ])
                      ]),
                      _: 2
                    }, 1032, ["dot-color"]);
                  }), 64))
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __3 = _sfc_main$n;
const __3_raw = `<template>
  <v-card class="mx-auto" max-width="400">
    <v-img
      color="surface-variant"
      height="200"
      src="https://cdn.vuetifyjs.com/docs/images/cards/purple-flowers.jpg"
      cover
    >
      <v-toolbar color="transparent">
        <template v-slot:prepend>
          <v-btn icon="$menu"></v-btn>
        </template>

        <v-toolbar-title class="text-h6" text="Messages"></v-toolbar-title>

        <template v-slot:append>
          <v-btn icon="mdi-dots-vertical"></v-btn>
        </template>
      </v-toolbar>
    </v-img>

    <v-card-text>
      <div class="font-weight-bold ms-1 mb-2">Today</div>

      <v-timeline align="start" density="compact">
        <v-timeline-item
          v-for="message in messages"
          :key="message.time"
          :dot-color="message.color"
          size="x-small"
        >
          <div class="mb-4">
            <div class="font-weight-normal">
              <strong>{{ message.from }}</strong> @{{ message.time }}
            </div>

            <div>{{ message.message }}</div>
          </div>
        </v-timeline-item>
      </v-timeline>
    </v-card-text>
  </v-card>
</template>

<script setup>
  const messages = [
    {
      from: 'You',
      message: \`Sure, I'll see you later.\`,
      time: '10:42am',
      color: 'deep-purple-lighten-1',
    },
    {
      from: 'John Doe',
      message: 'Yeah, sure. Does 1:00pm work?',
      time: '10:37am',
      color: 'green',
    },
    {
      from: 'You',
      message: 'Did you still want to grab lunch today?',
      time: '9:47am',
      color: 'deep-purple-lighten-1',
    },
  ]
<\/script>

<script>
  export default {
    data: () => ({
      messages: [
        {
          from: 'You',
          message: \`Sure, I'll see you later.\`,
          time: '10:42am',
          color: 'deep-purple-lighten-1',
        },
        {
          from: 'John Doe',
          message: 'Yeah, sure. Does 1:00pm work?',
          time: '10:37am',
          color: 'green',
        },
        {
          from: 'You',
          message: 'Did you still want to grab lunch today?',
          time: '9:47am',
          color: 'deep-purple-lighten-1',
        },
      ],
    }),
  }
<\/script>
`;
const _sfc_main$m = {
  __name: "misc-custom-actions",
  setup(__props) {
    const show = ref(false);
    return (_ctx, _cache) => {
      const _component_v_img = resolveComponent("v-img");
      const _component_v_card_title = resolveComponent("v-card-title");
      const _component_v_card_subtitle = resolveComponent("v-card-subtitle");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_spacer = resolveComponent("v-spacer");
      const _component_v_card_actions = resolveComponent("v-card-actions");
      const _component_v_divider = resolveComponent("v-divider");
      const _component_v_card_text = resolveComponent("v-card-text");
      const _component_v_expand_transition = resolveComponent("v-expand-transition");
      const _component_v_card = resolveComponent("v-card");
      return openBlock(), createBlock(_component_v_card, {
        class: "mx-auto",
        "max-width": "344"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_img, {
            height: "200px",
            src: "https://cdn.vuetifyjs.com/images/cards/sunshine.jpg",
            cover: ""
          }),
          createVNode(_component_v_card_title, null, {
            default: withCtx(() => [
              createTextVNode(" Top western road trips ")
            ]),
            _: 1
          }),
          createVNode(_component_v_card_subtitle, null, {
            default: withCtx(() => [
              createTextVNode(" 1,000 miles of wonder ")
            ]),
            _: 1
          }),
          createVNode(_component_v_card_actions, null, {
            default: withCtx(() => [
              createVNode(_component_v_btn, {
                color: "orange-lighten-2",
                text: "Explore"
              }),
              createVNode(_component_v_spacer),
              createVNode(_component_v_btn, {
                icon: show.value ? "mdi-chevron-up" : "mdi-chevron-down",
                onClick: _cache[0] || (_cache[0] = ($event) => show.value = !show.value)
              }, null, 8, ["icon"])
            ]),
            _: 1
          }),
          createVNode(_component_v_expand_transition, null, {
            default: withCtx(() => [
              withDirectives(createBaseVNode("div", null, [
                createVNode(_component_v_divider),
                createVNode(_component_v_card_text, null, {
                  default: withCtx(() => [
                    createTextVNode(" I'm a thing. But, like most politicians, he promised more than he could deliver. You won't have time for sleeping, soldier, not with all the bed making you'll be doing. Then we'll go with that data file! Hey, you add a one and two zeros to that or we walk! You're going to do his laundry? I've got to find a way to escape. ")
                  ]),
                  _: 1
                })
              ], 512), [
                [vShow, show.value]
              ])
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __4 = _sfc_main$m;
const __4_raw = `<template>
  <v-card
    class="mx-auto"
    max-width="344"
  >
    <v-img
      height="200px"
      src="https://cdn.vuetifyjs.com/images/cards/sunshine.jpg"
      cover
    ></v-img>

    <v-card-title>
      Top western road trips
    </v-card-title>

    <v-card-subtitle>
      1,000 miles of wonder
    </v-card-subtitle>

    <v-card-actions>
      <v-btn
        color="orange-lighten-2"
        text="Explore"
      ></v-btn>

      <v-spacer></v-spacer>

      <v-btn
        :icon="show ? 'mdi-chevron-up' : 'mdi-chevron-down'"
        @click="show = !show"
      ></v-btn>
    </v-card-actions>

    <v-expand-transition>
      <div v-show="show">
        <v-divider></v-divider>

        <v-card-text>
          I'm a thing. But, like most politicians, he promised more than he could deliver. You won't have time for sleeping, soldier, not with all the bed making you'll be doing. Then we'll go with that data file! Hey, you add a one and two zeros to that or we walk! You're going to do his laundry? I've got to find a way to escape.
        </v-card-text>
      </div>
    </v-expand-transition>
  </v-card>
</template>

<script setup>
  import { ref } from 'vue'

  const show = ref(false)
<\/script>

<script>
  export default {
    data: () => ({
      show: false,
    }),
  }
<\/script>
`;
const _sfc_main$l = {};
const _hoisted_1$b = /* @__PURE__ */ createBaseVNode("div", { class: "text-h6 mb-6" }, "Earn my first $100", -1);
const _hoisted_2$8 = /* @__PURE__ */ createBaseVNode("div", { class: "text-h4 font-weight-black mb-4" }, "0%", -1);
const _hoisted_3$6 = /* @__PURE__ */ createBaseVNode("div", null, "$0 of $100 earned — 7 days left", -1);
function _sfc_render$e(_ctx, _cache) {
  const _component_v_avatar = resolveComponent("v-avatar");
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_list_item = resolveComponent("v-list-item");
  const _component_v_divider = resolveComponent("v-divider");
  const _component_v_progress_linear = resolveComponent("v-progress-linear");
  const _component_v_card_text = resolveComponent("v-card-text");
  const _component_v_card = resolveComponent("v-card");
  return openBlock(), createBlock(_component_v_card, {
    class: "mx-auto",
    "max-width": "500",
    border: "",
    flat: ""
  }, {
    default: withCtx(() => [
      createVNode(_component_v_list_item, {
        class: "px-6",
        height: "88"
      }, {
        prepend: withCtx(() => [
          createVNode(_component_v_avatar, {
            color: "surface-light",
            size: "32"
          }, {
            default: withCtx(() => [
              createTextVNode("🎯")
            ]),
            _: 1
          })
        ]),
        title: withCtx(() => [
          createTextVNode(" Set an earnings goal. ")
        ]),
        append: withCtx(() => [
          createVNode(_component_v_btn, {
            class: "text-none",
            color: "primary",
            text: "Create goal",
            variant: "text",
            slim: ""
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_divider),
      createVNode(_component_v_card_text, { class: "text-medium-emphasis pa-6" }, {
        default: withCtx(() => [
          _hoisted_1$b,
          _hoisted_2$8,
          createVNode(_component_v_progress_linear, {
            "bg-color": "surface-variant",
            class: "mb-6",
            color: "primary",
            height: "10",
            "model-value": "2",
            rounded: "pill"
          }),
          _hoisted_3$6
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __5 = /* @__PURE__ */ _export_sfc(_sfc_main$l, [["render", _sfc_render$e]]);
const __5_raw = '<template>\n  <v-card class="mx-auto" max-width="500" border flat>\n    <v-list-item class="px-6" height="88">\n      <template v-slot:prepend>\n        <v-avatar color="surface-light" size="32">🎯</v-avatar>\n      </template>\n\n      <template v-slot:title> Set an earnings goal. </template>\n\n      <template v-slot:append>\n        <v-btn\n          class="text-none"\n          color="primary"\n          text="Create goal"\n          variant="text"\n          slim\n        ></v-btn>\n      </template>\n    </v-list-item>\n\n    <v-divider></v-divider>\n\n    <v-card-text class="text-medium-emphasis pa-6">\n      <div class="text-h6 mb-6">Earn my first $100</div>\n\n      <div class="text-h4 font-weight-black mb-4">0%</div>\n\n      <v-progress-linear\n        bg-color="surface-variant"\n        class="mb-6"\n        color="primary"\n        height="10"\n        model-value="2"\n        rounded="pill"\n      ></v-progress-linear>\n\n      <div>$0 of $100 earned — 7 days left</div>\n    </v-card-text>\n  </v-card>\n</template>\n';
const _sfc_main$k = {
  __name: "misc-grids",
  setup(__props) {
    const cards = [
      { title: "Pre-fab homes", src: "https://cdn.vuetifyjs.com/images/cards/house.jpg", flex: 12 },
      { title: "Favorite road trips", src: "https://cdn.vuetifyjs.com/images/cards/road.jpg", flex: 6 },
      { title: "Best airlines", src: "https://cdn.vuetifyjs.com/images/cards/plane.jpg", flex: 6 }
    ];
    return (_ctx, _cache) => {
      const _component_v_card_title = resolveComponent("v-card-title");
      const _component_v_img = resolveComponent("v-img");
      const _component_v_spacer = resolveComponent("v-spacer");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_card_actions = resolveComponent("v-card-actions");
      const _component_v_card = resolveComponent("v-card");
      const _component_v_col = resolveComponent("v-col");
      const _component_v_row = resolveComponent("v-row");
      const _component_v_container = resolveComponent("v-container");
      return openBlock(), createBlock(_component_v_card, {
        class: "mx-auto",
        "max-width": "500"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_container, { fluid: "" }, {
            default: withCtx(() => [
              createVNode(_component_v_row, { dense: "" }, {
                default: withCtx(() => [
                  (openBlock(), createElementBlock(Fragment, null, renderList(cards, (card) => {
                    return createVNode(_component_v_col, {
                      key: card.title,
                      cols: card.flex
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_v_card, null, {
                          default: withCtx(() => [
                            createVNode(_component_v_img, {
                              src: card.src,
                              class: "align-end",
                              gradient: "to bottom, rgba(0,0,0,.1), rgba(0,0,0,.5)",
                              height: "200px",
                              cover: ""
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_v_card_title, {
                                  class: "text-white",
                                  textContent: toDisplayString(card.title)
                                }, null, 8, ["textContent"])
                              ]),
                              _: 2
                            }, 1032, ["src"]),
                            createVNode(_component_v_card_actions, null, {
                              default: withCtx(() => [
                                createVNode(_component_v_spacer),
                                createVNode(_component_v_btn, {
                                  color: "medium-emphasis",
                                  icon: "mdi-heart",
                                  size: "small"
                                }),
                                createVNode(_component_v_btn, {
                                  color: "medium-emphasis",
                                  icon: "mdi-bookmark",
                                  size: "small"
                                }),
                                createVNode(_component_v_btn, {
                                  color: "medium-emphasis",
                                  icon: "mdi-share-variant",
                                  size: "small"
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 2
                        }, 1024)
                      ]),
                      _: 2
                    }, 1032, ["cols"]);
                  }), 64))
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __6 = _sfc_main$k;
const __6_raw = `<template>
  <v-card
    class="mx-auto"
    max-width="500"
  >
    <v-container fluid>
      <v-row dense>
        <v-col
          v-for="card in cards"
          :key="card.title"
          :cols="card.flex"
        >
          <v-card>
            <v-img
              :src="card.src"
              class="align-end"
              gradient="to bottom, rgba(0,0,0,.1), rgba(0,0,0,.5)"
              height="200px"
              cover
            >
              <v-card-title class="text-white" v-text="card.title"></v-card-title>
            </v-img>

            <v-card-actions>
              <v-spacer></v-spacer>

              <v-btn
                color="medium-emphasis"
                icon="mdi-heart"
                size="small"
              ></v-btn>

              <v-btn
                color="medium-emphasis"
                icon="mdi-bookmark"
                size="small"
              ></v-btn>

              <v-btn
                color="medium-emphasis"
                icon="mdi-share-variant"
                size="small"
              ></v-btn>
            </v-card-actions>
          </v-card>
        </v-col>
      </v-row>
    </v-container>
  </v-card>
</template>

<script setup>
  const cards = [
    { title: 'Pre-fab homes', src: 'https://cdn.vuetifyjs.com/images/cards/house.jpg', flex: 12 },
    { title: 'Favorite road trips', src: 'https://cdn.vuetifyjs.com/images/cards/road.jpg', flex: 6 },
    { title: 'Best airlines', src: 'https://cdn.vuetifyjs.com/images/cards/plane.jpg', flex: 6 },
  ]
<\/script>

<script>
  export default {
    data: () => ({
      cards: [
        { title: 'Pre-fab homes', src: 'https://cdn.vuetifyjs.com/images/cards/house.jpg', flex: 12 },
        { title: 'Favorite road trips', src: 'https://cdn.vuetifyjs.com/images/cards/road.jpg', flex: 6 },
        { title: 'Best airlines', src: 'https://cdn.vuetifyjs.com/images/cards/plane.jpg', flex: 6 },
      ],
    }),
  }
<\/script>
`;
const _sfc_main$j = {};
const _hoisted_1$a = { class: "d-flex flex-no-wrap justify-space-between" };
const _hoisted_2$7 = { class: "d-flex flex-no-wrap justify-space-between" };
function _sfc_render$d(_ctx, _cache) {
  const _component_v_spacer = resolveComponent("v-spacer");
  const _component_v_icon = resolveComponent("v-icon");
  const _component_v_system_bar = resolveComponent("v-system-bar");
  const _component_v_app_bar_nav_icon = resolveComponent("v-app-bar-nav-icon");
  const _component_v_toolbar_title = resolveComponent("v-toolbar-title");
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_app_bar = resolveComponent("v-app-bar");
  const _component_v_card_title = resolveComponent("v-card-title");
  const _component_v_card_subtitle = resolveComponent("v-card-subtitle");
  const _component_v_card_actions = resolveComponent("v-card-actions");
  const _component_v_card = resolveComponent("v-card");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_img = resolveComponent("v-img");
  const _component_v_avatar = resolveComponent("v-avatar");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  const _component_v_main = resolveComponent("v-main");
  const _component_v_layout = resolveComponent("v-layout");
  return openBlock(), createBlock(_component_v_card, {
    class: "mx-auto",
    "max-width": "400"
  }, {
    default: withCtx(() => [
      createVNode(_component_v_layout, null, {
        default: withCtx(() => [
          createVNode(_component_v_system_bar, { color: "pink-darken-2" }, {
            default: withCtx(() => [
              createVNode(_component_v_spacer),
              createVNode(_component_v_icon, null, {
                default: withCtx(() => [
                  createTextVNode("mdi-window-minimize")
                ]),
                _: 1
              }),
              createVNode(_component_v_icon, null, {
                default: withCtx(() => [
                  createTextVNode("mdi-window-maximize")
                ]),
                _: 1
              }),
              createVNode(_component_v_icon, null, {
                default: withCtx(() => [
                  createTextVNode("mdi-close")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_app_bar, { color: "pink" }, {
            default: withCtx(() => [
              createVNode(_component_v_app_bar_nav_icon),
              createVNode(_component_v_toolbar_title, null, {
                default: withCtx(() => [
                  createTextVNode("My Music")
                ]),
                _: 1
              }),
              createVNode(_component_v_spacer),
              createVNode(_component_v_btn, { icon: "mdi-magnify" })
            ]),
            _: 1
          }),
          createVNode(_component_v_main, null, {
            default: withCtx(() => [
              createVNode(_component_v_container, null, {
                default: withCtx(() => [
                  createVNode(_component_v_row, { dense: "" }, {
                    default: withCtx(() => [
                      createVNode(_component_v_col, { cols: "12" }, {
                        default: withCtx(() => [
                          createVNode(_component_v_card, { color: "#385F73" }, {
                            default: withCtx(() => [
                              createVNode(_component_v_card_title, { class: "text-h5" }, {
                                default: withCtx(() => [
                                  createTextVNode(" Unlimited music now ")
                                ]),
                                _: 1
                              }),
                              createVNode(_component_v_card_subtitle, null, {
                                default: withCtx(() => [
                                  createTextVNode(" Listen to your favorite artists and albums whenever and wherever, online and offline. ")
                                ]),
                                _: 1
                              }),
                              createVNode(_component_v_card_actions, null, {
                                default: withCtx(() => [
                                  createVNode(_component_v_btn, {
                                    text: "Listen Now",
                                    variant: "text"
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_v_col, { cols: "12" }, {
                        default: withCtx(() => [
                          createVNode(_component_v_card, { color: "#1F7087" }, {
                            default: withCtx(() => [
                              createBaseVNode("div", _hoisted_1$a, [
                                createBaseVNode("div", null, [
                                  createVNode(_component_v_card_title, { class: "text-h5" }, {
                                    default: withCtx(() => [
                                      createTextVNode(" Supermodel ")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_v_card_subtitle, null, {
                                    default: withCtx(() => [
                                      createTextVNode("Foster the People")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_v_card_actions, null, {
                                    default: withCtx(() => [
                                      createVNode(_component_v_btn, {
                                        class: "ms-2",
                                        size: "small",
                                        text: "START RADIO",
                                        variant: "outlined"
                                      })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                createVNode(_component_v_avatar, {
                                  class: "ma-3",
                                  rounded: "0",
                                  size: "125"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_v_img, { src: "https://cdn.vuetifyjs.com/images/cards/foster.jpg" })
                                  ]),
                                  _: 1
                                })
                              ])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_v_col, { cols: "12" }, {
                        default: withCtx(() => [
                          createVNode(_component_v_card, { color: "#952175" }, {
                            default: withCtx(() => [
                              createBaseVNode("div", _hoisted_2$7, [
                                createBaseVNode("div", null, [
                                  createVNode(_component_v_card_title, { class: "text-h5" }, {
                                    default: withCtx(() => [
                                      createTextVNode(" Halcyon Days ")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_v_card_subtitle, null, {
                                    default: withCtx(() => [
                                      createTextVNode("Ellie Goulding")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_v_card_actions, null, {
                                    default: withCtx(() => [
                                      createVNode(_component_v_btn, {
                                        class: "ms-2",
                                        icon: "mdi-play",
                                        variant: "text"
                                      })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                createVNode(_component_v_avatar, {
                                  class: "ma-3",
                                  rounded: "0",
                                  size: "125"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_v_img, { src: "https://cdn.vuetifyjs.com/images/cards/halcyon.png" })
                                  ]),
                                  _: 1
                                })
                              ])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __7 = /* @__PURE__ */ _export_sfc(_sfc_main$j, [["render", _sfc_render$d]]);
const __7_raw = '<template>\n  <v-card\n    class="mx-auto"\n    max-width="400"\n  >\n    <v-layout>\n      <v-system-bar color="pink-darken-2">\n        <v-spacer></v-spacer>\n\n        <v-icon>mdi-window-minimize</v-icon>\n\n        <v-icon>mdi-window-maximize</v-icon>\n\n        <v-icon>mdi-close</v-icon>\n      </v-system-bar>\n\n      <v-app-bar color="pink">\n        <v-app-bar-nav-icon></v-app-bar-nav-icon>\n\n        <v-toolbar-title>My Music</v-toolbar-title>\n\n        <v-spacer></v-spacer>\n\n        <v-btn icon="mdi-magnify"></v-btn>\n      </v-app-bar>\n\n      <v-main>\n        <v-container>\n          <v-row dense>\n            <v-col cols="12">\n              <v-card color="#385F73">\n                <v-card-title class="text-h5">\n                  Unlimited music now\n                </v-card-title>\n\n                <v-card-subtitle>\n                  Listen to your favorite artists and albums whenever and wherever, online and offline.\n                </v-card-subtitle>\n\n                <v-card-actions>\n                  <v-btn text="Listen Now" variant="text"></v-btn>\n                </v-card-actions>\n              </v-card>\n            </v-col>\n\n            <v-col cols="12">\n              <v-card color="#1F7087">\n                <div class="d-flex flex-no-wrap justify-space-between">\n                  <div>\n                    <v-card-title class="text-h5">\n                      Supermodel\n                    </v-card-title>\n\n                    <v-card-subtitle>Foster the People</v-card-subtitle>\n\n                    <v-card-actions>\n                      <v-btn\n                        class="ms-2"\n                        size="small"\n                        text="START RADIO"\n                        variant="outlined"\n                      ></v-btn>\n                    </v-card-actions>\n                  </div>\n\n                  <v-avatar\n                    class="ma-3"\n                    rounded="0"\n                    size="125"\n                  >\n                    <v-img src="https://cdn.vuetifyjs.com/images/cards/foster.jpg"></v-img>\n                  </v-avatar>\n                </div>\n              </v-card>\n            </v-col>\n\n            <v-col cols="12">\n              <v-card color="#952175">\n                <div class="d-flex flex-no-wrap justify-space-between">\n                  <div>\n                    <v-card-title class="text-h5">\n                      Halcyon Days\n                    </v-card-title>\n\n                    <v-card-subtitle>Ellie Goulding</v-card-subtitle>\n\n                    <v-card-actions>\n                      <v-btn\n                        class="ms-2"\n                        icon="mdi-play"\n                        variant="text"\n                      ></v-btn>\n                    </v-card-actions>\n                  </div>\n\n                  <v-avatar\n                    class="ma-3"\n                    rounded="0"\n                    size="125"\n                  >\n                    <v-img src="https://cdn.vuetifyjs.com/images/cards/halcyon.png"></v-img>\n                  </v-avatar>\n                </div>\n              </v-card>\n            </v-col>\n          </v-row>\n        </v-container>\n      </v-main>\n    </v-layout>\n  </v-card>\n</template>\n';
const _sfc_main$i = {};
const _hoisted_1$9 = /* @__PURE__ */ createBaseVNode("div", null, "Word of the Day", -1);
const _hoisted_2$6 = /* @__PURE__ */ createBaseVNode("p", { class: "text-h4 font-weight-black" }, "be•nev•o•lent", -1);
const _hoisted_3$5 = /* @__PURE__ */ createBaseVNode("p", null, "adjective", -1);
const _hoisted_4$3 = /* @__PURE__ */ createBaseVNode("div", { class: "text-medium-emphasis" }, [
  /* @__PURE__ */ createTextVNode(" well meaning and kindly."),
  /* @__PURE__ */ createBaseVNode("br"),
  /* @__PURE__ */ createTextVNode(' "a benevolent smile" ')
], -1);
function _sfc_render$c(_ctx, _cache) {
  const _component_v_card_text = resolveComponent("v-card-text");
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_card_actions = resolveComponent("v-card-actions");
  const _component_v_card = resolveComponent("v-card");
  return openBlock(), createBlock(_component_v_card, {
    class: "mx-auto",
    "max-width": "344"
  }, {
    default: withCtx(() => [
      createVNode(_component_v_card_text, null, {
        default: withCtx(() => [
          _hoisted_1$9,
          _hoisted_2$6,
          _hoisted_3$5,
          _hoisted_4$3
        ]),
        _: 1
      }),
      createVNode(_component_v_card_actions, null, {
        default: withCtx(() => [
          createVNode(_component_v_btn, {
            color: "deep-purple-accent-4",
            text: "Learn More",
            variant: "text"
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __8 = /* @__PURE__ */ _export_sfc(_sfc_main$i, [["render", _sfc_render$c]]);
const __8_raw = '<template>\n  <v-card\n    class="mx-auto"\n    max-width="344"\n  >\n    <v-card-text>\n      <div>Word of the Day</div>\n\n      <p class="text-h4 font-weight-black">be•nev•o•lent</p>\n\n      <p>adjective</p>\n\n      <div class="text-medium-emphasis">\n        well meaning and kindly.<br>\n        "a benevolent smile"\n      </div>\n    </v-card-text>\n\n    <v-card-actions>\n      <v-btn\n        color="deep-purple-accent-4"\n        text="Learn More"\n        variant="text"\n      ></v-btn>\n    </v-card-actions>\n  </v-card>\n</template>\n';
const _sfc_main$h = {};
function _sfc_render$b(_ctx, _cache) {
  const _component_v_img = resolveComponent("v-img");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_icon = resolveComponent("v-icon");
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  const _component_v_card = resolveComponent("v-card");
  return openBlock(), createBlock(_component_v_card, { class: "d-inline-block mx-auto" }, {
    default: withCtx(() => [
      createVNode(_component_v_container, null, {
        default: withCtx(() => [
          createVNode(_component_v_row, { justify: "space-between" }, {
            default: withCtx(() => [
              createVNode(_component_v_col, { cols: "auto" }, {
                default: withCtx(() => [
                  createVNode(_component_v_img, {
                    height: "200",
                    src: "https://cdn.vuetifyjs.com/images/cards/store.jpg",
                    width: "200"
                  })
                ]),
                _: 1
              }),
              createVNode(_component_v_col, {
                class: "text-center ps-0",
                cols: "auto"
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_row, {
                    class: "flex-column ma-0 fill-height",
                    justify: "center"
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_v_col, { class: "px-0" }, {
                        default: withCtx(() => [
                          createVNode(_component_v_btn, { icon: "" }, {
                            default: withCtx(() => [
                              createVNode(_component_v_icon, null, {
                                default: withCtx(() => [
                                  createTextVNode("mdi-heart")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_v_col, { class: "px-0" }, {
                        default: withCtx(() => [
                          createVNode(_component_v_btn, { icon: "" }, {
                            default: withCtx(() => [
                              createVNode(_component_v_icon, null, {
                                default: withCtx(() => [
                                  createTextVNode("mdi-bookmark")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_v_col, { class: "px-0" }, {
                        default: withCtx(() => [
                          createVNode(_component_v_btn, { icon: "" }, {
                            default: withCtx(() => [
                              createVNode(_component_v_icon, null, {
                                default: withCtx(() => [
                                  createTextVNode("mdi-share-variant")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __9 = /* @__PURE__ */ _export_sfc(_sfc_main$h, [["render", _sfc_render$b]]);
const __9_raw = '<template>\n  <v-card class="d-inline-block mx-auto">\n    <v-container>\n      <v-row justify="space-between">\n        <v-col cols="auto">\n          <v-img\n            height="200"\n            src="https://cdn.vuetifyjs.com/images/cards/store.jpg"\n            width="200"\n          ></v-img>\n        </v-col>\n\n        <v-col\n          class="text-center ps-0"\n          cols="auto"\n        >\n          <v-row\n            class="flex-column ma-0 fill-height"\n            justify="center"\n          >\n            <v-col class="px-0">\n              <v-btn icon>\n                <v-icon>mdi-heart</v-icon>\n              </v-btn>\n            </v-col>\n\n            <v-col class="px-0">\n              <v-btn icon>\n                <v-icon>mdi-bookmark</v-icon>\n              </v-btn>\n            </v-col>\n\n            <v-col class="px-0">\n              <v-btn icon>\n                <v-icon>mdi-share-variant</v-icon>\n              </v-btn>\n            </v-col>\n          </v-row>\n        </v-col>\n      </v-row>\n    </v-container>\n  </v-card>\n</template>\n';
const _sfc_main$g = {};
const _hoisted_1$8 = /* @__PURE__ */ createBaseVNode("div", null, "Whitehaven Beach", -1);
const _hoisted_2$5 = /* @__PURE__ */ createBaseVNode("div", null, "Whitsunday Island, Whitsunday Islands", -1);
function _sfc_render$a(_ctx, _cache) {
  const _component_v_card_title = resolveComponent("v-card-title");
  const _component_v_img = resolveComponent("v-img");
  const _component_v_card_subtitle = resolveComponent("v-card-subtitle");
  const _component_v_card_text = resolveComponent("v-card-text");
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_card_actions = resolveComponent("v-card-actions");
  const _component_v_card = resolveComponent("v-card");
  return openBlock(), createBlock(_component_v_card, {
    class: "mx-auto",
    "max-width": "400"
  }, {
    default: withCtx(() => [
      createVNode(_component_v_img, {
        class: "align-end text-white",
        height: "200",
        src: "https://cdn.vuetifyjs.com/images/cards/docks.jpg",
        cover: ""
      }, {
        default: withCtx(() => [
          createVNode(_component_v_card_title, null, {
            default: withCtx(() => [
              createTextVNode("Top 10 Australian beaches")
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_card_subtitle, { class: "pt-4" }, {
        default: withCtx(() => [
          createTextVNode(" Number 10 ")
        ]),
        _: 1
      }),
      createVNode(_component_v_card_text, null, {
        default: withCtx(() => [
          _hoisted_1$8,
          _hoisted_2$5
        ]),
        _: 1
      }),
      createVNode(_component_v_card_actions, null, {
        default: withCtx(() => [
          createVNode(_component_v_btn, {
            color: "orange",
            text: "Share"
          }),
          createVNode(_component_v_btn, {
            color: "orange",
            text: "Explore"
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __10 = /* @__PURE__ */ _export_sfc(_sfc_main$g, [["render", _sfc_render$a]]);
const __10_raw = '<template>\n  <v-card\n    class="mx-auto"\n    max-width="400"\n  >\n    <v-img\n      class="align-end text-white"\n      height="200"\n      src="https://cdn.vuetifyjs.com/images/cards/docks.jpg"\n      cover\n    >\n      <v-card-title>Top 10 Australian beaches</v-card-title>\n    </v-img>\n\n    <v-card-subtitle class="pt-4">\n      Number 10\n    </v-card-subtitle>\n\n    <v-card-text>\n      <div>Whitehaven Beach</div>\n\n      <div>Whitsunday Island, Whitsunday Islands</div>\n    </v-card-text>\n\n    <v-card-actions>\n      <v-btn color="orange" text="Share"></v-btn>\n\n      <v-btn color="orange" text="Explore"></v-btn>\n    </v-card-actions>\n  </v-card>\n</template>\n';
const _hoisted_1$7 = /* @__PURE__ */ createBaseVNode("div", { class: "text-green-darken-3 text-h3 font-weight-bold" }, "90%", -1);
const _hoisted_2$4 = /* @__PURE__ */ createBaseVNode("div", { class: "text-h6 text-medium-emphasis font-weight-regular" }, " $2,938.00 remaining ", -1);
const _hoisted_3$4 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_4$2 = /* @__PURE__ */ createBaseVNode("div", { class: "d-flex justify-space-between py-3" }, [
  /* @__PURE__ */ createBaseVNode("span", { class: "text-green-darken-3 font-weight-medium" }, " $26,442.00 remitted "),
  /* @__PURE__ */ createBaseVNode("span", { class: "text-medium-emphasis" }, " $29,380.00 total ")
], -1);
const review = "30%";
const _sfc_main$f = {
  __name: "misc-shopify-funding",
  setup(__props) {
    return (_ctx, _cache) => {
      const _component_v_card_title = resolveComponent("v-card-title");
      const _component_v_badge = resolveComponent("v-badge");
      const _component_v_progress_linear = resolveComponent("v-progress-linear");
      const _component_v_card_text = resolveComponent("v-card-text");
      const _component_v_divider = resolveComponent("v-divider");
      const _component_v_list_item = resolveComponent("v-list-item");
      const _component_v_card = resolveComponent("v-card");
      const _component_v_container = resolveComponent("v-container");
      return openBlock(), createBlock(_component_v_container, null, {
        default: withCtx(() => [
          createVNode(_component_v_card, null, {
            default: withCtx(() => [
              createVNode(_component_v_card_title, { class: "text-overline" }, {
                default: withCtx(() => [
                  createTextVNode(" Progress "),
                  _hoisted_1$7,
                  _hoisted_2$4
                ]),
                _: 1
              }),
              _hoisted_3$4,
              createVNode(_component_v_card_text, null, {
                default: withCtx(() => [
                  createBaseVNode("div", {
                    style: normalizeStyle(`right: calc(${review} - 32px)`),
                    class: "position-absolute mt-n8 text-caption text-green-darken-3"
                  }, " Eligibility review ", 4),
                  createVNode(_component_v_progress_linear, {
                    color: "green-darken-3",
                    height: "22",
                    "model-value": "90",
                    rounded: "lg"
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_v_badge, {
                        style: normalizeStyle(`right: ${review}`),
                        class: "position-absolute",
                        color: "white",
                        dot: "",
                        inline: ""
                      }, null, 8, ["style"])
                    ]),
                    _: 1
                  }),
                  _hoisted_4$2
                ]),
                _: 1
              }),
              createVNode(_component_v_divider),
              createVNode(_component_v_list_item, {
                "append-icon": "mdi-chevron-right",
                lines: "two",
                subtitle: "Details and agreement",
                link: ""
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __11 = _sfc_main$f;
const __11_raw = '<template>\n  <v-container>\n    <v-card>\n      <v-card-title class="text-overline">\n        Progress\n\n        <div class="text-green-darken-3 text-h3 font-weight-bold">90%</div>\n\n        <div class="text-h6 text-medium-emphasis font-weight-regular">\n          $2,938.00 remaining\n        </div>\n      </v-card-title>\n      <br>\n      <v-card-text>\n        <div\n          :style="`right: calc(${review} - 32px)`"\n          class="position-absolute mt-n8 text-caption text-green-darken-3"\n        >\n          Eligibility review\n        </div>\n        <v-progress-linear\n          color="green-darken-3"\n          height="22"\n          model-value="90"\n          rounded="lg"\n        >\n          <v-badge\n            :style="`right: ${review}`"\n            class="position-absolute"\n            color="white"\n            dot\n            inline\n          ></v-badge>\n        </v-progress-linear>\n\n        <div class="d-flex justify-space-between py-3">\n          <span class="text-green-darken-3 font-weight-medium">\n            $26,442.00 remitted\n          </span>\n\n          <span class="text-medium-emphasis"> $29,380.00 total </span>\n        </div>\n      </v-card-text>\n\n      <v-divider></v-divider>\n\n      <v-list-item\n        append-icon="mdi-chevron-right"\n        lines="two"\n        subtitle="Details and agreement"\n        link\n      ></v-list-item>\n    </v-card>\n  </v-container>\n</template>\n\n<script setup>\n  const review = \'30%\'\n<\/script>\n\n<script>\n  export default {\n    data: () => ({ review: \'30%\' }),\n  }\n<\/script>\n';
const _sfc_main$e = {};
const _hoisted_1$6 = { class: "justify-self-end" };
const _hoisted_2$3 = /* @__PURE__ */ createBaseVNode("span", { class: "subheading me-2" }, "256", -1);
const _hoisted_3$3 = /* @__PURE__ */ createBaseVNode("span", { class: "me-1" }, "·", -1);
const _hoisted_4$1 = /* @__PURE__ */ createBaseVNode("span", { class: "subheading" }, "45", -1);
function _sfc_render$9(_ctx, _cache) {
  const _component_v_icon = resolveComponent("v-icon");
  const _component_v_card_text = resolveComponent("v-card-text");
  const _component_v_avatar = resolveComponent("v-avatar");
  const _component_v_list_item_title = resolveComponent("v-list-item-title");
  const _component_v_list_item_subtitle = resolveComponent("v-list-item-subtitle");
  const _component_v_list_item = resolveComponent("v-list-item");
  const _component_v_card_actions = resolveComponent("v-card-actions");
  const _component_v_card = resolveComponent("v-card");
  return openBlock(), createBlock(_component_v_card, {
    class: "mx-auto text-white",
    color: "#26c6da",
    "max-width": "400",
    "prepend-icon": "mdi-twitter",
    title: "Twitter"
  }, {
    prepend: withCtx(() => [
      createVNode(_component_v_icon, { size: "x-large" })
    ]),
    default: withCtx(() => [
      createVNode(_component_v_card_text, { class: "text-h5 py-2" }, {
        default: withCtx(() => [
          createTextVNode(' "Turns out semicolon-less style is easier and safer in TS because most gotcha edge cases are type invalid as well." ')
        ]),
        _: 1
      }),
      createVNode(_component_v_card_actions, null, {
        default: withCtx(() => [
          createVNode(_component_v_list_item, { class: "w-100" }, {
            prepend: withCtx(() => [
              createVNode(_component_v_avatar, {
                color: "grey-darken-3",
                image: "https://avataaars.io/?avatarStyle=Transparent&topType=ShortHairShortCurly&accessoriesType=Prescription02&hairColor=Black&facialHairType=Blank&clotheType=Hoodie&clotheColor=White&eyeType=Default&eyebrowType=DefaultNatural&mouthType=Default&skinColor=Light"
              })
            ]),
            append: withCtx(() => [
              createBaseVNode("div", _hoisted_1$6, [
                createVNode(_component_v_icon, {
                  class: "me-1",
                  icon: "mdi-heart"
                }),
                _hoisted_2$3,
                _hoisted_3$3,
                createVNode(_component_v_icon, {
                  class: "me-1",
                  icon: "mdi-share-variant"
                }),
                _hoisted_4$1
              ])
            ]),
            default: withCtx(() => [
              createVNode(_component_v_list_item_title, null, {
                default: withCtx(() => [
                  createTextVNode("Evan You")
                ]),
                _: 1
              }),
              createVNode(_component_v_list_item_subtitle, null, {
                default: withCtx(() => [
                  createTextVNode("Vue Creator")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __12 = /* @__PURE__ */ _export_sfc(_sfc_main$e, [["render", _sfc_render$9]]);
const __12_raw = '<template>\n  <v-card\n    class="mx-auto text-white"\n    color="#26c6da"\n    max-width="400"\n    prepend-icon="mdi-twitter"\n    title="Twitter"\n  >\n    <template v-slot:prepend>\n      <v-icon size="x-large"></v-icon>\n    </template>\n\n    <v-card-text class="text-h5 py-2">\n      "Turns out semicolon-less style is easier and safer in TS because most gotcha edge cases are type invalid as well."\n    </v-card-text>\n\n    <v-card-actions>\n      <v-list-item class="w-100">\n        <template v-slot:prepend>\n          <v-avatar\n            color="grey-darken-3"\n            image="https://avataaars.io/?avatarStyle=Transparent&topType=ShortHairShortCurly&accessoriesType=Prescription02&hairColor=Black&facialHairType=Blank&clotheType=Hoodie&clotheColor=White&eyeType=Default&eyebrowType=DefaultNatural&mouthType=Default&skinColor=Light"\n          ></v-avatar>\n        </template>\n\n        <v-list-item-title>Evan You</v-list-item-title>\n\n        <v-list-item-subtitle>Vue Creator</v-list-item-subtitle>\n\n        <template v-slot:append>\n          <div class="justify-self-end">\n            <v-icon class="me-1" icon="mdi-heart"></v-icon>\n            <span class="subheading me-2">256</span>\n            <span class="me-1">·</span>\n            <v-icon class="me-1" icon="mdi-share-variant"></v-icon>\n            <span class="subheading">45</span>\n          </div>\n        </template>\n      </v-list-item>\n    </v-card-actions>\n  </v-card>\n</template>\n';
const _hoisted_1$5 = { class: "d-flex py-3 justify-space-between" };
const _hoisted_2$2 = { key: 0 };
const _hoisted_3$2 = { class: "py-2" };
const _sfc_main$d = {
  __name: "misc-weather-card",
  setup(__props) {
    const labels = { 0: "SU", 1: "MO", 2: "TU", 3: "WED", 4: "TH", 5: "FR", 6: "SA" };
    const forecast = [
      { day: "Tuesday", icon: "mdi-white-balance-sunny", temp: "24°/12°" },
      { day: "Wednesday", icon: "mdi-white-balance-sunny", temp: "22°/14°" },
      { day: "Thursday", icon: "mdi-cloud", temp: "25°/15°" }
    ];
    const expand = ref(false);
    const time = ref(0);
    return (_ctx, _cache) => {
      const _component_v_icon = resolveComponent("v-icon");
      const _component_v_card_item = resolveComponent("v-card-item");
      const _component_v_col = resolveComponent("v-col");
      const _component_v_row = resolveComponent("v-row");
      const _component_v_card_text = resolveComponent("v-card-text");
      const _component_v_list_item_subtitle = resolveComponent("v-list-item-subtitle");
      const _component_v_list_item = resolveComponent("v-list-item");
      const _component_v_slider = resolveComponent("v-slider");
      const _component_v_list = resolveComponent("v-list");
      const _component_v_expand_transition = resolveComponent("v-expand-transition");
      const _component_v_divider = resolveComponent("v-divider");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_card_actions = resolveComponent("v-card-actions");
      const _component_v_card = resolveComponent("v-card");
      return openBlock(), createBlock(_component_v_card, {
        class: "mx-auto",
        "max-width": "368"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_card_item, { title: "Florida" }, {
            subtitle: withCtx(() => [
              createVNode(_component_v_icon, {
                class: "me-1 pb-1",
                color: "error",
                icon: "mdi-alert",
                size: "18"
              }),
              createTextVNode(" Extreme Weather Alert ")
            ]),
            _: 1
          }),
          createVNode(_component_v_card_text, { class: "py-0" }, {
            default: withCtx(() => [
              createVNode(_component_v_row, {
                align: "center",
                "no-gutters": ""
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_col, {
                    class: "text-h2",
                    cols: "6"
                  }, {
                    default: withCtx(() => [
                      createTextVNode(" 64°F ")
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_col, {
                    class: "text-right",
                    cols: "6"
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_v_icon, {
                        color: "error",
                        icon: "mdi-weather-hurricane",
                        size: "88"
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createBaseVNode("div", _hoisted_1$5, [
            createVNode(_component_v_list_item, {
              density: "compact",
              "prepend-icon": "mdi-weather-windy"
            }, {
              default: withCtx(() => [
                createVNode(_component_v_list_item_subtitle, null, {
                  default: withCtx(() => [
                    createTextVNode("123 km/h")
                  ]),
                  _: 1
                })
              ]),
              _: 1
            }),
            createVNode(_component_v_list_item, {
              density: "compact",
              "prepend-icon": "mdi-weather-pouring"
            }, {
              default: withCtx(() => [
                createVNode(_component_v_list_item_subtitle, null, {
                  default: withCtx(() => [
                    createTextVNode("48%")
                  ]),
                  _: 1
                })
              ]),
              _: 1
            })
          ]),
          createVNode(_component_v_expand_transition, null, {
            default: withCtx(() => [
              expand.value ? (openBlock(), createElementBlock("div", _hoisted_2$2, [
                createBaseVNode("div", _hoisted_3$2, [
                  createVNode(_component_v_slider, {
                    modelValue: time.value,
                    "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => time.value = $event),
                    max: 6,
                    step: 1,
                    ticks: labels,
                    class: "mx-4",
                    color: "primary",
                    density: "compact",
                    "show-ticks": "always",
                    "thumb-size": "10",
                    "hide-details": ""
                  }, null, 8, ["modelValue"])
                ]),
                createVNode(_component_v_list, { class: "bg-transparent" }, {
                  default: withCtx(() => [
                    (openBlock(), createElementBlock(Fragment, null, renderList(forecast, (item) => {
                      return createVNode(_component_v_list_item, {
                        key: item.day,
                        "append-icon": item.icon,
                        subtitle: item.temp,
                        title: item.day
                      }, null, 8, ["append-icon", "subtitle", "title"]);
                    }), 64))
                  ]),
                  _: 1
                })
              ])) : createCommentVNode("", true)
            ]),
            _: 1
          }),
          createVNode(_component_v_divider),
          createVNode(_component_v_card_actions, null, {
            default: withCtx(() => [
              createVNode(_component_v_btn, {
                text: !expand.value ? "Full Report" : "Hide Report",
                onClick: _cache[1] || (_cache[1] = ($event) => expand.value = !expand.value)
              }, null, 8, ["text"])
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __13 = _sfc_main$d;
const __13_raw = `<template>
  <v-card
    class="mx-auto"
    max-width="368"
  >
    <v-card-item title="Florida">
      <template v-slot:subtitle>
        <v-icon
          class="me-1 pb-1"
          color="error"
          icon="mdi-alert"
          size="18"
        ></v-icon>

        Extreme Weather Alert
      </template>
    </v-card-item>

    <v-card-text class="py-0">
      <v-row align="center" no-gutters>
        <v-col
          class="text-h2"
          cols="6"
        >
          64&deg;F
        </v-col>

        <v-col class="text-right" cols="6">
          <v-icon
            color="error"
            icon="mdi-weather-hurricane"
            size="88"
          ></v-icon>
        </v-col>
      </v-row>
    </v-card-text>

    <div class="d-flex py-3 justify-space-between">
      <v-list-item
        density="compact"
        prepend-icon="mdi-weather-windy"
      >
        <v-list-item-subtitle>123 km/h</v-list-item-subtitle>
      </v-list-item>

      <v-list-item
        density="compact"
        prepend-icon="mdi-weather-pouring"
      >
        <v-list-item-subtitle>48%</v-list-item-subtitle>
      </v-list-item>
    </div>

    <v-expand-transition>
      <div v-if="expand">
        <div class="py-2">
          <v-slider
            v-model="time"
            :max="6"
            :step="1"
            :ticks="labels"
            class="mx-4"
            color="primary"
            density="compact"
            show-ticks="always"
            thumb-size="10"
            hide-details
          ></v-slider>
        </div>

        <v-list class="bg-transparent">
          <v-list-item
            v-for="item in forecast"
            :key="item.day"
            :append-icon="item.icon"
            :subtitle="item.temp"
            :title="item.day"
          >
          </v-list-item>
        </v-list>
      </div>
    </v-expand-transition>

    <v-divider></v-divider>

    <v-card-actions>
      <v-btn
        :text="!expand ? 'Full Report' : 'Hide Report'"
        @click="expand = !expand"
      ></v-btn>
    </v-card-actions>
  </v-card>
</template>

<script setup>
  import { ref } from 'vue'

  const labels = { 0: 'SU', 1: 'MO', 2: 'TU', 3: 'WED', 4: 'TH', 5: 'FR', 6: 'SA' }
  const forecast = [
    { day: 'Tuesday', icon: 'mdi-white-balance-sunny', temp: '24\\u00B0/12\\u00B0' },
    { day: 'Wednesday', icon: 'mdi-white-balance-sunny', temp: '22\\u00B0/14\\u00B0' },
    { day: 'Thursday', icon: 'mdi-cloud', temp: '25\\u00B0/15\\u00B0' },
  ]

  const expand = ref(false)
  const time = ref(0)
<\/script>

<script>
  export default {
    data: () => ({
      labels: { 0: 'SU', 1: 'MO', 2: 'TU', 3: 'WED', 4: 'TH', 5: 'FR', 6: 'SA' },
      expand: false,
      time: 0,
      forecast: [
        { day: 'Tuesday', icon: 'mdi-white-balance-sunny', temp: '24\\xB0/12\\xB0' },
        { day: 'Wednesday', icon: 'mdi-white-balance-sunny', temp: '22\\xB0/14\\xB0' },
        { day: 'Thursday', icon: 'mdi-cloud', temp: '25\\xB0/15\\xB0' },
      ],
    }),
  }
<\/script>
`;
const _hoisted_1$4 = { class: "text-overline mb-1" };
const _hoisted_2$1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-h6 mb-1" }, " Headline ", -1);
const _hoisted_3$1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "Greyhound divisely hello coldly fonwderfully", -1);
const _sfc_main$c = {
  __name: "prop-color",
  setup(__props) {
    const variants = ["elevated", "flat", "tonal", "outlined"];
    const color = ref("indigo");
    return (_ctx, _cache) => {
      const _component_v_radio = resolveComponent("v-radio");
      const _component_v_radio_group = resolveComponent("v-radio-group");
      const _component_v_col = resolveComponent("v-col");
      const _component_v_card_item = resolveComponent("v-card-item");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_card_actions = resolveComponent("v-card-actions");
      const _component_v_card = resolveComponent("v-card");
      const _component_v_row = resolveComponent("v-row");
      return openBlock(), createBlock(_component_v_row, { justify: "center" }, {
        default: withCtx(() => [
          createVNode(_component_v_col, { cols: "auto" }, {
            default: withCtx(() => [
              createVNode(_component_v_radio_group, {
                modelValue: color.value,
                "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => color.value = $event),
                "hide-details": "",
                inline: ""
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_radio, {
                    color: "indigo",
                    label: "indigo",
                    value: "indigo"
                  }),
                  createVNode(_component_v_radio, {
                    color: "indigo-darken-3",
                    label: "indigo-darken-3",
                    value: "indigo-darken-3"
                  }),
                  createVNode(_component_v_radio, {
                    color: "primary",
                    label: "primary",
                    value: "primary"
                  }),
                  createVNode(_component_v_radio, {
                    color: "secondary",
                    label: "secondary",
                    value: "secondary"
                  })
                ]),
                _: 1
              }, 8, ["modelValue"])
            ]),
            _: 1
          }),
          (openBlock(), createElementBlock(Fragment, null, renderList(variants, (variant, i) => {
            return createVNode(_component_v_col, {
              key: i,
              cols: "12",
              md: "6"
            }, {
              default: withCtx(() => [
                createVNode(_component_v_card, {
                  color: color.value,
                  variant,
                  class: "mx-auto"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_v_card_item, null, {
                      default: withCtx(() => [
                        createBaseVNode("div", null, [
                          createBaseVNode("div", _hoisted_1$4, toDisplayString(variant), 1),
                          _hoisted_2$1,
                          _hoisted_3$1
                        ])
                      ]),
                      _: 2
                    }, 1024),
                    createVNode(_component_v_card_actions, null, {
                      default: withCtx(() => [
                        createVNode(_component_v_btn, null, {
                          default: withCtx(() => [
                            createTextVNode(" Button ")
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    })
                  ]),
                  _: 2
                }, 1032, ["color", "variant"])
              ]),
              _: 2
            }, 1024);
          }), 64))
        ]),
        _: 1
      });
    };
  }
};
const __14 = _sfc_main$c;
const __14_raw = `<template>
  <v-row justify="center">
    <v-col cols="auto">
      <v-radio-group
        v-model="color"
        hide-details
        inline
      >
        <v-radio
          color="indigo"
          label="indigo"
          value="indigo"
        ></v-radio>

        <v-radio
          color="indigo-darken-3"
          label="indigo-darken-3"
          value="indigo-darken-3"
        ></v-radio>

        <v-radio
          color="primary"
          label="primary"
          value="primary"
        ></v-radio>

        <v-radio
          color="secondary"
          label="secondary"
          value="secondary"
        ></v-radio>
      </v-radio-group>
    </v-col>

    <v-col
      v-for="(variant, i) in variants"
      :key="i"
      cols="12"
      md="6"
    >
      <v-card
        :color="color"
        :variant="variant"
        class="mx-auto"
      >
        <v-card-item>
          <div>
            <div class="text-overline mb-1">
              {{ variant }}
            </div>
            <div class="text-h6 mb-1">
              Headline
            </div>
            <div class="text-caption">Greyhound divisely hello coldly fonwderfully</div>
          </div>
        </v-card-item>

        <v-card-actions>
          <v-btn>
            Button
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-col>
  </v-row>
</template>

<script setup>
  import { ref } from 'vue'

  const variants = ['elevated', 'flat', 'tonal', 'outlined']
  const color = ref('indigo')
<\/script>
`;
const _sfc_main$b = {};
function _sfc_render$8(_ctx, _cache) {
  const _component_v_card = resolveComponent("v-card");
  return openBlock(), createBlock(_component_v_card, {
    class: "mx-auto",
    "max-width": "344",
    subtitle: "The card stays disabled",
    title: "Disabled card",
    disabled: "",
    link: ""
  });
}
const __15 = /* @__PURE__ */ _export_sfc(_sfc_main$b, [["render", _sfc_render$8]]);
const __15_raw = '<template>\n  <v-card\n    class="mx-auto"\n    max-width="344"\n    subtitle="The card stays disabled"\n    title="Disabled card"\n    disabled\n    link\n  ></v-card>\n</template>\n';
const _sfc_main$a = {};
const _hoisted_1$3 = /* @__PURE__ */ createBaseVNode("div", null, [
  /* @__PURE__ */ createBaseVNode("div", { class: "text-overline mb-1" }, " OVERLINE "),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-h6 mb-1" }, " Headline "),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "Greyhound divisely hello coldly fonwderfully")
], -1);
function _sfc_render$7(_ctx, _cache) {
  const _component_v_card_item = resolveComponent("v-card-item");
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_card_actions = resolveComponent("v-card-actions");
  const _component_v_card = resolveComponent("v-card");
  return openBlock(), createBlock(_component_v_card, {
    class: "mx-auto",
    "max-width": "344",
    variant: "elevated"
  }, {
    default: withCtx(() => [
      createVNode(_component_v_card_item, null, {
        default: withCtx(() => [
          _hoisted_1$3
        ]),
        _: 1
      }),
      createVNode(_component_v_card_actions, null, {
        default: withCtx(() => [
          createVNode(_component_v_btn, {
            text: "Button",
            variant: "outlined"
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __16 = /* @__PURE__ */ _export_sfc(_sfc_main$a, [["render", _sfc_render$7]]);
const __16_raw = '<template>\n  <v-card\n    class="mx-auto"\n    max-width="344"\n    variant="elevated"\n  >\n    <v-card-item>\n      <div>\n        <div class="text-overline mb-1">\n          OVERLINE\n        </div>\n\n        <div class="text-h6 mb-1">\n          Headline\n        </div>\n\n        <div class="text-caption">Greyhound divisely hello coldly fonwderfully</div>\n      </div>\n    </v-card-item>\n\n    <v-card-actions>\n      <v-btn text="Button" variant="outlined">\n\n      </v-btn>\n    </v-card-actions>\n  </v-card>\n</template>\n';
const _sfc_main$9 = {};
function _sfc_render$6(_ctx, _cache) {
  const _component_v_card_title = resolveComponent("v-card-title");
  const _component_v_card_subtitle = resolveComponent("v-card-subtitle");
  const _component_v_card_item = resolveComponent("v-card-item");
  const _component_v_card_text = resolveComponent("v-card-text");
  const _component_v_card = resolveComponent("v-card");
  return openBlock(), createBlock(_component_v_card, {
    class: "mx-auto my-8",
    elevation: "16",
    "max-width": "344"
  }, {
    default: withCtx(() => [
      createVNode(_component_v_card_item, null, {
        default: withCtx(() => [
          createVNode(_component_v_card_title, null, {
            default: withCtx(() => [
              createTextVNode(" Card title ")
            ]),
            _: 1
          }),
          createVNode(_component_v_card_subtitle, null, {
            default: withCtx(() => [
              createTextVNode(" Card subtitle secondary text ")
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_card_text, null, {
        default: withCtx(() => [
          createTextVNode(" Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ")
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __17 = /* @__PURE__ */ _export_sfc(_sfc_main$9, [["render", _sfc_render$6]]);
const __17_raw = '<template>\n  <v-card\n    class="mx-auto my-8"\n    elevation="16"\n    max-width="344"\n  >\n    <v-card-item>\n      <v-card-title>\n        Card title\n      </v-card-title>\n\n      <v-card-subtitle>\n        Card subtitle secondary text\n      </v-card-subtitle>\n    </v-card-item>\n\n    <v-card-text>\n      Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.\n    </v-card-text>\n  </v-card>\n</template>\n';
const _sfc_main$8 = {};
function _sfc_render$5(_ctx, _cache) {
  const _component_v_card_title = resolveComponent("v-card-title");
  const _component_v_card_subtitle = resolveComponent("v-card-subtitle");
  const _component_v_card_item = resolveComponent("v-card-item");
  const _component_v_card_text = resolveComponent("v-card-text");
  const _component_v_card = resolveComponent("v-card");
  return openBlock(), createBlock(_component_v_card, {
    class: "mx-auto",
    "max-width": "344",
    hover: ""
  }, {
    default: withCtx(() => [
      createVNode(_component_v_card_item, null, {
        default: withCtx(() => [
          createVNode(_component_v_card_title, null, {
            default: withCtx(() => [
              createTextVNode(" Card title ")
            ]),
            _: 1
          }),
          createVNode(_component_v_card_subtitle, null, {
            default: withCtx(() => [
              createTextVNode(" Card subtitle secondary text ")
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_card_text, null, {
        default: withCtx(() => [
          createTextVNode(" Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ")
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __18 = /* @__PURE__ */ _export_sfc(_sfc_main$8, [["render", _sfc_render$5]]);
const __18_raw = '<template>\n  <v-card\n    class="mx-auto"\n    max-width="344"\n    hover\n  >\n    <v-card-item>\n      <v-card-title>\n        Card title\n      </v-card-title>\n\n      <v-card-subtitle>\n        Card subtitle secondary text\n      </v-card-subtitle>\n    </v-card-item>\n\n    <v-card-text>\n      Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.\n    </v-card-text>\n  </v-card>\n</template>\n';
const _sfc_main$7 = {};
function _sfc_render$4(_ctx, _cache) {
  const _component_v_card = resolveComponent("v-card");
  return openBlock(), createBlock(_component_v_card, {
    "append-icon": "mdi-open-in-new",
    class: "mx-auto",
    href: "https://github.com/vuetifyjs/vuetify/",
    "max-width": "344",
    "prepend-icon": "mdi-github",
    rel: "noopener",
    subtitle: "Check out the official repository",
    target: "_blank",
    title: "Vuetify on GitHub"
  });
}
const __19 = /* @__PURE__ */ _export_sfc(_sfc_main$7, [["render", _sfc_render$4]]);
const __19_raw = '<template>\n  <v-card\n    append-icon="mdi-open-in-new"\n    class="mx-auto"\n    href="https://github.com/vuetifyjs/vuetify/"\n    max-width="344"\n    prepend-icon="mdi-github"\n    rel="noopener"\n    subtitle="Check out the official repository"\n    target="_blank"\n    title="Vuetify on GitHub"\n  ></v-card>\n</template>\n';
const _sfc_main$6 = {};
function _sfc_render$3(_ctx, _cache) {
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_card = resolveComponent("v-card");
  return openBlock(), createBlock(_component_v_card, {
    class: "mx-auto",
    color: "surface-variant",
    image: "https://cdn.vuetifyjs.com/docs/images/cards/dark-beach.jpg",
    "max-width": "340",
    subtitle: "Take a walk down the beach",
    title: "Evening sunset"
  }, {
    actions: withCtx(() => [
      createVNode(_component_v_btn, {
        "append-icon": "mdi-chevron-right",
        color: "red-lighten-2",
        text: "Book Activity",
        variant: "outlined",
        block: ""
      })
    ]),
    _: 1
  });
}
const __20 = /* @__PURE__ */ _export_sfc(_sfc_main$6, [["render", _sfc_render$3]]);
const __20_raw = '<template>\n  <v-card\n    class="mx-auto"\n    color="surface-variant"\n    image="https://cdn.vuetifyjs.com/docs/images/cards/dark-beach.jpg"\n    max-width="340"\n    subtitle="Take a walk down the beach"\n    title="Evening sunset"\n  >\n    <template v-slot:actions>\n      <v-btn\n        append-icon="mdi-chevron-right"\n        color="red-lighten-2"\n        text="Book Activity"\n        variant="outlined"\n        block\n      ></v-btn>\n    </template>\n  </v-card>\n</template>\n';
const _sfc_main$5 = {};
function _sfc_render$2(_ctx, _cache) {
  const _component_v_card = resolveComponent("v-card");
  return openBlock(), createBlock(_component_v_card, {
    class: "mx-auto",
    "max-width": "344",
    subtitle: "Same looks, no anchor",
    title: "Hover and click me",
    link: ""
  });
}
const __21 = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["render", _sfc_render$2]]);
const __21_raw = '<template>\n  <v-card\n    class="mx-auto"\n    max-width="344"\n    subtitle="Same looks, no anchor"\n    title="Hover and click me"\n    link\n  ></v-card>\n</template>\n';
const _hoisted_1$2 = /* @__PURE__ */ createBaseVNode("span", { class: "me-1" }, "Local Favorite", -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("div", { class: "text-grey ms-4" }, " 4.5 (413) ", -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("div", { class: "my-4 text-subtitle-1" }, " $ • Italian, Cafe ", -1);
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("div", null, "Small plates, salads & sandwiches - an intimate setting with 12 indoor seats plus patio seating.", -1);
const _hoisted_5 = { class: "px-4 mb-2" };
const _sfc_main$4 = {
  __name: "prop-loading",
  setup(__props) {
    const loading = ref(false);
    const selection = ref(1);
    function reserve() {
      loading.value = true;
      setTimeout(() => loading.value = false, 2e3);
    }
    return (_ctx, _cache) => {
      const _component_v_progress_linear = resolveComponent("v-progress-linear");
      const _component_v_img = resolveComponent("v-img");
      const _component_v_card_title = resolveComponent("v-card-title");
      const _component_v_icon = resolveComponent("v-icon");
      const _component_v_card_subtitle = resolveComponent("v-card-subtitle");
      const _component_v_card_item = resolveComponent("v-card-item");
      const _component_v_rating = resolveComponent("v-rating");
      const _component_v_row = resolveComponent("v-row");
      const _component_v_card_text = resolveComponent("v-card-text");
      const _component_v_divider = resolveComponent("v-divider");
      const _component_v_chip = resolveComponent("v-chip");
      const _component_v_chip_group = resolveComponent("v-chip-group");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_card_actions = resolveComponent("v-card-actions");
      const _component_v_card = resolveComponent("v-card");
      return openBlock(), createBlock(_component_v_card, {
        disabled: loading.value,
        loading: loading.value,
        class: "mx-auto my-12",
        "max-width": "374"
      }, {
        loader: withCtx(({ isActive }) => [
          createVNode(_component_v_progress_linear, {
            active: isActive,
            color: "deep-purple",
            height: "4",
            indeterminate: ""
          }, null, 8, ["active"])
        ]),
        default: withCtx(() => [
          createVNode(_component_v_img, {
            height: "250",
            src: "https://cdn.vuetifyjs.com/images/cards/cooking.png",
            cover: ""
          }),
          createVNode(_component_v_card_item, null, {
            default: withCtx(() => [
              createVNode(_component_v_card_title, null, {
                default: withCtx(() => [
                  createTextVNode("Cafe Badilico")
                ]),
                _: 1
              }),
              createVNode(_component_v_card_subtitle, null, {
                default: withCtx(() => [
                  _hoisted_1$2,
                  createVNode(_component_v_icon, {
                    color: "error",
                    icon: "mdi-fire-circle",
                    size: "small"
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_card_text, null, {
            default: withCtx(() => [
              createVNode(_component_v_row, {
                align: "center",
                class: "mx-0"
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_rating, {
                    "model-value": 4.5,
                    color: "amber",
                    density: "compact",
                    size: "small",
                    "half-increments": "",
                    readonly: ""
                  }),
                  _hoisted_2
                ]),
                _: 1
              }),
              _hoisted_3,
              _hoisted_4
            ]),
            _: 1
          }),
          createVNode(_component_v_divider, { class: "mx-4 mb-1" }),
          createVNode(_component_v_card_title, null, {
            default: withCtx(() => [
              createTextVNode("Tonight's availability")
            ]),
            _: 1
          }),
          createBaseVNode("div", _hoisted_5, [
            createVNode(_component_v_chip_group, {
              modelValue: selection.value,
              "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => selection.value = $event),
              "selected-class": "bg-deep-purple-lighten-2"
            }, {
              default: withCtx(() => [
                createVNode(_component_v_chip, null, {
                  default: withCtx(() => [
                    createTextVNode("5:30PM")
                  ]),
                  _: 1
                }),
                createVNode(_component_v_chip, null, {
                  default: withCtx(() => [
                    createTextVNode("7:30PM")
                  ]),
                  _: 1
                }),
                createVNode(_component_v_chip, null, {
                  default: withCtx(() => [
                    createTextVNode("8:00PM")
                  ]),
                  _: 1
                }),
                createVNode(_component_v_chip, null, {
                  default: withCtx(() => [
                    createTextVNode("9:00PM")
                  ]),
                  _: 1
                })
              ]),
              _: 1
            }, 8, ["modelValue"])
          ]),
          createVNode(_component_v_card_actions, null, {
            default: withCtx(() => [
              createVNode(_component_v_btn, {
                color: "deep-purple-lighten-2",
                text: "Reserve",
                block: "",
                border: "",
                onClick: reserve
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      }, 8, ["disabled", "loading"]);
    };
  }
};
const __22 = _sfc_main$4;
const __22_raw = `<template>
  <v-card
    :disabled="loading"
    :loading="loading"
    class="mx-auto my-12"
    max-width="374"
  >
    <template v-slot:loader="{ isActive }">
      <v-progress-linear
        :active="isActive"
        color="deep-purple"
        height="4"
        indeterminate
      ></v-progress-linear>
    </template>

    <v-img
      height="250"
      src="https://cdn.vuetifyjs.com/images/cards/cooking.png"
      cover
    ></v-img>

    <v-card-item>
      <v-card-title>Cafe Badilico</v-card-title>

      <v-card-subtitle>
        <span class="me-1">Local Favorite</span>

        <v-icon
          color="error"
          icon="mdi-fire-circle"
          size="small"
        ></v-icon>
      </v-card-subtitle>
    </v-card-item>

    <v-card-text>
      <v-row
        align="center"
        class="mx-0"
      >
        <v-rating
          :model-value="4.5"
          color="amber"
          density="compact"
          size="small"
          half-increments
          readonly
        ></v-rating>

        <div class="text-grey ms-4">
          4.5 (413)
        </div>
      </v-row>

      <div class="my-4 text-subtitle-1">
        $ • Italian, Cafe
      </div>

      <div>Small plates, salads & sandwiches - an intimate setting with 12 indoor seats plus patio seating.</div>
    </v-card-text>

    <v-divider class="mx-4 mb-1"></v-divider>

    <v-card-title>Tonight's availability</v-card-title>

    <div class="px-4 mb-2">
      <v-chip-group v-model="selection" selected-class="bg-deep-purple-lighten-2">
        <v-chip>5:30PM</v-chip>

        <v-chip>7:30PM</v-chip>

        <v-chip>8:00PM</v-chip>

        <v-chip>9:00PM</v-chip>
      </v-chip-group>
    </div>

    <v-card-actions>
      <v-btn
        color="deep-purple-lighten-2"
        text="Reserve"
        block
        border
        @click="reserve"
      ></v-btn>
    </v-card-actions>
  </v-card>
</template>

<script setup>
  import { ref } from 'vue'

  const loading = ref(false)
  const selection = ref(1)
  function reserve () {
    loading.value = true
    setTimeout(() => (loading.value = false), 2000)
  }
<\/script>

<script>
  export default {
    data: () => ({
      loading: false,
      selection: 1,
    }),

    methods: {
      reserve () {
        this.loading = true

        setTimeout(() => (this.loading = false), 2000)
      },
    },
  }
<\/script>
`;
const _sfc_main$3 = {};
const _hoisted_1$1 = /* @__PURE__ */ createBaseVNode("div", null, [
  /* @__PURE__ */ createBaseVNode("div", { class: "text-overline mb-1" }, " OVERLINE "),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-h6 mb-1" }, " Headline "),
  /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, "Greyhound divisely hello coldly fonwderfully")
], -1);
function _sfc_render$1(_ctx, _cache) {
  const _component_v_card_item = resolveComponent("v-card-item");
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_card_actions = resolveComponent("v-card-actions");
  const _component_v_card = resolveComponent("v-card");
  return openBlock(), createBlock(_component_v_card, {
    class: "mx-auto",
    "max-width": "344",
    variant: "outlined"
  }, {
    default: withCtx(() => [
      createVNode(_component_v_card_item, null, {
        default: withCtx(() => [
          _hoisted_1$1
        ]),
        _: 1
      }),
      createVNode(_component_v_card_actions, null, {
        default: withCtx(() => [
          createVNode(_component_v_btn, {
            text: "Button",
            variant: "outlined"
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __23 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["render", _sfc_render$1]]);
const __23_raw = '<template>\n  <v-card\n    class="mx-auto"\n    max-width="344"\n    variant="outlined"\n  >\n    <v-card-item>\n      <div>\n        <div class="text-overline mb-1">\n          OVERLINE\n        </div>\n\n        <div class="text-h6 mb-1">\n          Headline\n        </div>\n\n        <div class="text-caption">Greyhound divisely hello coldly fonwderfully</div>\n      </div>\n    </v-card-item>\n\n    <v-card-actions>\n      <v-btn text="Button" variant="outlined"></v-btn>\n    </v-card-actions>\n  </v-card>\n</template>\n';
const _hoisted_1 = { class: "text-center text-caption" };
const _sfc_main$2 = {
  __name: "prop-variant",
  setup(__props) {
    const variants = ["elevated", "flat", "tonal", "outlined", "text", "plain"];
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_card = resolveComponent("v-card");
      const _component_v_col = resolveComponent("v-col");
      const _component_v_row = resolveComponent("v-row");
      return openBlock(), createBlock(_component_v_row, { dense: "" }, {
        default: withCtx(() => [
          (openBlock(), createElementBlock(Fragment, null, renderList(variants, (variant, i) => {
            return createVNode(_component_v_col, {
              key: i,
              cols: "12",
              md: "4"
            }, {
              default: withCtx(() => [
                createVNode(_component_v_card, {
                  variant,
                  class: "mx-auto",
                  color: "surface-variant",
                  "max-width": "344",
                  subtitle: "Greyhound divisely hello coldly fonwderfully",
                  title: "Headline"
                }, {
                  actions: withCtx(() => [
                    createVNode(_component_v_btn, { text: "Button" })
                  ]),
                  _: 2
                }, 1032, ["variant"]),
                createBaseVNode("div", _hoisted_1, toDisplayString(variant), 1)
              ]),
              _: 2
            }, 1024);
          }), 64))
        ]),
        _: 1
      });
    };
  }
};
const __24 = _sfc_main$2;
const __24_raw = `<template>
  <v-row dense>
    <v-col
      v-for="(variant, i) in variants"
      :key="i"
      cols="12"
      md="4"
    >
      <v-card
        :variant="variant"
        class="mx-auto"
        color="surface-variant"
        max-width="344"
        subtitle="Greyhound divisely hello coldly fonwderfully"
        title="Headline"
      >
        <template v-slot:actions>
          <v-btn text="Button"></v-btn>
        </template>
      </v-card>

      <div class="text-center text-caption">{{ variant }}</div>
    </v-col>
  </v-row>
</template>

<script setup>
  const variants = ['elevated', 'flat', 'tonal', 'outlined', 'text', 'plain']
<\/script>

<script>
  export default {
    data: () => ({
      variants: ['elevated', 'flat', 'tonal', 'outlined', 'text', 'plain'],
    }),
  }
<\/script>
`;
const _sfc_main$1 = {};
function _sfc_render(_ctx, _cache) {
  const _component_v_card_text = resolveComponent("v-card-text");
  const _component_v_card = resolveComponent("v-card");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_icon = resolveComponent("v-icon");
  const _component_v_avatar = resolveComponent("v-avatar");
  const _component_v_img = resolveComponent("v-img");
  const _component_v_row = resolveComponent("v-row");
  return openBlock(), createBlock(_component_v_row, {
    align: "center",
    justify: "center",
    dense: ""
  }, {
    default: withCtx(() => [
      createVNode(_component_v_col, {
        cols: "12",
        md: "6"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_card, {
            "append-icon": "mdi-check",
            class: "mx-auto",
            "prepend-icon": "mdi-account",
            subtitle: "prepend-icon and append-icon",
            title: "Icons"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_card_text, null, {
                default: withCtx(() => [
                  createTextVNode("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod.")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_col, {
        cols: "12",
        md: "6"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_card, {
            class: "mx-auto",
            subtitle: "prepend and append",
            title: "Icons"
          }, {
            prepend: withCtx(() => [
              createVNode(_component_v_icon, {
                color: "primary",
                icon: "mdi-account"
              })
            ]),
            append: withCtx(() => [
              createVNode(_component_v_icon, {
                color: "success",
                icon: "mdi-check"
              })
            ]),
            default: withCtx(() => [
              createVNode(_component_v_card_text, null, {
                default: withCtx(() => [
                  createTextVNode("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod.")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_col, {
        cols: "12",
        md: "6"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_card, {
            "append-avatar": "https://cdn.vuetifyjs.com/images/john.jpg",
            class: "mx-auto",
            "prepend-avatar": "https://cdn.vuetifyjs.com/images/logos/v-alt.svg",
            subtitle: "prepend-avatar and append-avatar",
            title: "Avatars"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_card_text, null, {
                default: withCtx(() => [
                  createTextVNode("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod.")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_col, {
        cols: "12",
        md: "6"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_card, {
            class: "mx-auto",
            subtitle: "prepend and append",
            title: "Avatars"
          }, {
            prepend: withCtx(() => [
              createVNode(_component_v_avatar, { color: "blue-darken-2" }, {
                default: withCtx(() => [
                  createVNode(_component_v_icon, { icon: "mdi-alarm" })
                ]),
                _: 1
              })
            ]),
            append: withCtx(() => [
              createVNode(_component_v_avatar, { size: "24" }, {
                default: withCtx(() => [
                  createVNode(_component_v_img, {
                    alt: "John",
                    src: "https://cdn.vuetifyjs.com/images/john.png"
                  })
                ]),
                _: 1
              })
            ]),
            default: withCtx(() => [
              createVNode(_component_v_card_text, null, {
                default: withCtx(() => [
                  createTextVNode("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod.")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __25 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["render", _sfc_render]]);
const __25_raw = '<template>\n  <v-row align="center" justify="center" dense>\n    <v-col cols="12" md="6">\n      <v-card\n        append-icon="mdi-check"\n        class="mx-auto"\n        prepend-icon="mdi-account"\n        subtitle="prepend-icon and append-icon"\n        title="Icons"\n      >\n        <v-card-text>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod.</v-card-text>\n      </v-card>\n    </v-col>\n\n    <v-col cols="12" md="6">\n      <v-card\n        class="mx-auto"\n        subtitle="prepend and append"\n        title="Icons"\n      >\n        <template v-slot:prepend>\n          <v-icon color="primary" icon="mdi-account"></v-icon>\n        </template>\n        <template v-slot:append>\n          <v-icon color="success" icon="mdi-check"></v-icon>\n        </template>\n        <v-card-text>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod.</v-card-text>\n      </v-card>\n    </v-col>\n\n    <v-col cols="12" md="6">\n      <v-card\n        append-avatar="https://cdn.vuetifyjs.com/images/john.jpg"\n        class="mx-auto"\n        prepend-avatar="https://cdn.vuetifyjs.com/images/logos/v-alt.svg"\n        subtitle="prepend-avatar and append-avatar"\n        title="Avatars"\n      >\n        <v-card-text>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod.</v-card-text>\n      </v-card>\n    </v-col>\n\n    <v-col cols="12" md="6">\n      <v-card\n        class="mx-auto"\n        subtitle="prepend and append"\n        title="Avatars"\n      >\n        <template v-slot:prepend>\n          <v-avatar color="blue-darken-2">\n            <v-icon icon="mdi-alarm"></v-icon>\n          </v-avatar>\n        </template>\n        <template v-slot:append>\n          <v-avatar size="24">\n            <v-img\n              alt="John"\n              src="https://cdn.vuetifyjs.com/images/john.png"\n            ></v-img>\n          </v-avatar>\n        </template>\n        <v-card-text>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod.</v-card-text>\n      </v-card>\n    </v-col>\n  </v-row>\n</template>\n';
const name = "v-card";
const _sfc_main = {
  __name: "usage",
  setup(__props) {
    const model = ref("default");
    const actions = ref(false);
    const loading = ref(false);
    const subtitle = ref(false);
    const title = ref(false);
    const options = ["outlined", "tonal"];
    const props = computed(() => {
      return {
        loading: loading.value || void 0,
        title: title.value ? "Card title" : void 0,
        subtitle: subtitle.value ? "Subtitle" : void 0,
        text: "...",
        variant: ["outlined", "tonal"].includes(model.value) ? model.value : void 0
      };
    });
    const slots = computed(() => {
      let str = "";
      if (actions.value) {
        str += `
  <v-card-actions>
    <v-btn>Click me</v-btn>
  </v-card-actions>
`;
      }
      return str;
    });
    const code = computed(() => {
      return `<${name}${propsToString(props.value)}>${slots.value}</${name}>`;
    });
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_card_actions = resolveComponent("v-card-actions");
      const _component_v_card = resolveComponent("v-card");
      const _component_v_checkbox = resolveComponent("v-checkbox");
      const _component_ExamplesUsageExample = _sfc_main$r;
      return openBlock(), createBlock(_component_ExamplesUsageExample, {
        modelValue: unref(model),
        "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => isRef(model) ? model.value = $event : null),
        code: unref(code),
        name,
        options
      }, {
        configuration: withCtx(() => [
          createVNode(_component_v_checkbox, {
            modelValue: unref(title),
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(title) ? title.value = $event : null),
            label: "Show title"
          }, null, 8, ["modelValue"]),
          createVNode(_component_v_checkbox, {
            modelValue: unref(subtitle),
            "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(subtitle) ? subtitle.value = $event : null),
            label: "Show subtitle"
          }, null, 8, ["modelValue"]),
          createVNode(_component_v_checkbox, {
            modelValue: unref(actions),
            "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => isRef(actions) ? actions.value = $event : null),
            label: "Show actions"
          }, null, 8, ["modelValue"]),
          createVNode(_component_v_checkbox, {
            modelValue: unref(loading),
            "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => isRef(loading) ? loading.value = $event : null),
            label: "Loading"
          }, null, 8, ["modelValue"])
        ]),
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createVNode(_component_v_card, normalizeProps(guardReactiveProps(unref(props))), {
              text: withCtx(() => [
                createTextVNode(" Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem! ")
              ]),
              default: withCtx(() => [
                unref(actions) ? (openBlock(), createBlock(_component_v_card_actions, { key: 0 }, {
                  default: withCtx(() => [
                    createVNode(_component_v_btn, null, {
                      default: withCtx(() => [
                        createTextVNode("Click me")
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                })) : createCommentVNode("", true)
              ]),
              _: 1
            }, 16)
          ])
        ]),
        _: 1
      }, 8, ["modelValue", "code"]);
    };
  }
};
const __26 = _sfc_main;
const __26_raw = `<template>
  <ExamplesUsageExample
    v-model="model"
    :code="code"
    :name="name"
    :options="options"
  >
    <div>

      <v-card v-bind="props">
        <template v-slot:text>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!
        </template>

        <v-card-actions v-if="actions">
          <v-btn>Click me</v-btn>
        </v-card-actions>
      </v-card>
    </div>

    <template v-slot:configuration>
      <v-checkbox v-model="title" label="Show title"></v-checkbox>

      <v-checkbox v-model="subtitle" label="Show subtitle"></v-checkbox>

      <v-checkbox v-model="actions" label="Show actions"></v-checkbox>

      <v-checkbox v-model="loading" label="Loading"></v-checkbox>
    </template>
  </ExamplesUsageExample>
</template>

<script setup>
  const name = 'v-card'
  const model = ref('default')
  const actions = ref(false)
  const loading = ref(false)
  const subtitle = ref(false)
  const title = ref(false)
  const options = ['outlined', 'tonal']
  const props = computed(() => {
    return {
      loading: loading.value || undefined,
      title: title.value ? 'Card title' : undefined,
      subtitle: subtitle.value ? 'Subtitle' : undefined,
      text: '...',
      variant: ['outlined', 'tonal'].includes(model.value) ? model.value : undefined,
    }
  })

  const slots = computed(() => {
    let str = ''

    if (actions.value) {
      str += \`
  <v-card-actions>
    <v-btn>Click me</v-btn>
  </v-card-actions>
\`
    }

    return str
  })

  const code = computed(() => {
    return \`<\${name}\${propsToString(props.value)}>\${slots.value}</\${name}>\`
  })
<\/script>
`;
const vCard = {
  "basics-combine": {
    component: __0,
    source: __0_raw
  },
  "basics-content": {
    component: __1,
    source: __1_raw
  },
  "misc-card-reveal": {
    component: __2,
    source: __2_raw
  },
  "misc-content-wrapping": {
    component: __3,
    source: __3_raw
  },
  "misc-custom-actions": {
    component: __4,
    source: __4_raw
  },
  "misc-earnings-goal": {
    component: __5,
    source: __5_raw
  },
  "misc-grids": {
    component: __6,
    source: __6_raw
  },
  "misc-horizontal-cards": {
    component: __7,
    source: __7_raw
  },
  "misc-information-card": {
    component: __8,
    source: __8_raw
  },
  "misc-intermediate": {
    component: __9,
    source: __9_raw
  },
  "misc-media-with-text": {
    component: __10,
    source: __10_raw
  },
  "misc-shopify-funding": {
    component: __11,
    source: __11_raw
  },
  "misc-twitter-card": {
    component: __12,
    source: __12_raw
  },
  "misc-weather-card": {
    component: __13,
    source: __13_raw
  },
  "prop-color": {
    component: __14,
    source: __14_raw
  },
  "prop-disabled": {
    component: __15,
    source: __15_raw
  },
  "prop-elevated": {
    component: __16,
    source: __16_raw
  },
  "prop-elevation": {
    component: __17,
    source: __17_raw
  },
  "prop-hover": {
    component: __18,
    source: __18_raw
  },
  "prop-href": {
    component: __19,
    source: __19_raw
  },
  "prop-image": {
    component: __20,
    source: __20_raw
  },
  "prop-link": {
    component: __21,
    source: __21_raw
  },
  "prop-loading": {
    component: __22,
    source: __22_raw
  },
  "prop-outlined": {
    component: __23,
    source: __23_raw
  },
  "prop-variant": {
    component: __24,
    source: __24_raw
  },
  "slot-prepend-append": {
    component: __25,
    source: __25_raw
  },
  "usage": {
    component: __26,
    source: __26_raw
  }
};
export {
  vCard as default
};
