import { r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, b as createVNode, l as createElementBlock, F as Fragment, v as renderList, e as createBaseVNode, t as toDisplayString, J as ref, h as createTextVNode, j as computed, ag as propsToString, ak as normalizeProps, al as guardReactiveProps, f as unref, E as isRef } from "./index-DGybHjCP.js";
import { _ as _sfc_main$9 } from "./UsageExample-M8CmNipa.js";
const _hoisted_1$4 = { class: "d-flex fill-height justify-center align-center" };
const _hoisted_2$4 = { class: "text-h2" };
const _sfc_main$8 = {
  __name: "prop-custom-icons",
  setup(__props) {
    const colors = [
      "green",
      "secondary",
      "yellow darken-4",
      "red lighten-2",
      "orange darken-1"
    ];
    const slides = [
      "First",
      "Second",
      "Third",
      "Fourth",
      "Fifth"
    ];
    return (_ctx, _cache) => {
      const _component_v_sheet = resolveComponent("v-sheet");
      const _component_v_carousel_item = resolveComponent("v-carousel-item");
      const _component_v_carousel = resolveComponent("v-carousel");
      const _component_v_card = resolveComponent("v-card");
      return openBlock(), createBlock(_component_v_card, {
        class: "mx-auto",
        elevation: "24",
        "max-width": "444"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_carousel, {
            continuous: false,
            "show-arrows": false,
            "delimiter-icon": "mdi-square",
            height: "300",
            "hide-delimiter-background": ""
          }, {
            default: withCtx(() => [
              (openBlock(), createElementBlock(Fragment, null, renderList(slides, (slide, i) => {
                return createVNode(_component_v_carousel_item, { key: i }, {
                  default: withCtx(() => [
                    createVNode(_component_v_sheet, {
                      color: colors[i],
                      height: "100%",
                      tile: ""
                    }, {
                      default: withCtx(() => [
                        createBaseVNode("div", _hoisted_1$4, [
                          createBaseVNode("div", _hoisted_2$4, toDisplayString(slide) + " Slide ", 1)
                        ])
                      ]),
                      _: 2
                    }, 1032, ["color"])
                  ]),
                  _: 2
                }, 1024);
              }), 64))
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __0 = _sfc_main$8;
const __0_raw = `<template>
  <v-card
    class="mx-auto"
    elevation="24"
    max-width="444"
  >
    <v-carousel
      :continuous="false"
      :show-arrows="false"
      delimiter-icon="mdi-square"
      height="300"
      hide-delimiter-background
    >
      <v-carousel-item
        v-for="(slide, i) in slides"
        :key="i"
      >
        <v-sheet
          :color="colors[i]"
          height="100%"
          tile
        >
          <div class="d-flex fill-height justify-center align-center">
            <div class="text-h2">
              {{ slide }} Slide
            </div>
          </div>
        </v-sheet>
      </v-carousel-item>
    </v-carousel>
  </v-card>
</template>

<script setup>
  const colors = [
    'green',
    'secondary',
    'yellow darken-4',
    'red lighten-2',
    'orange darken-1',
  ]
  const slides = [
    'First',
    'Second',
    'Third',
    'Fourth',
    'Fifth',
  ]
<\/script>

<script>
  export default {
    data () {
      return {
        colors: [
          'green',
          'secondary',
          'yellow darken-4',
          'red lighten-2',
          'orange darken-1',
        ],
        slides: [
          'First',
          'Second',
          'Third',
          'Fourth',
          'Fifth',
        ],
      }
    },
  }
<\/script>
`;
const _sfc_main$7 = {
  __name: "prop-custom-transition",
  setup(__props) {
    const items = [
      {
        src: "https://cdn.vuetifyjs.com/images/carousel/squirrel.jpg"
      },
      {
        src: "https://cdn.vuetifyjs.com/images/carousel/sky.jpg"
      },
      {
        src: "https://cdn.vuetifyjs.com/images/carousel/bird.jpg"
      },
      {
        src: "https://cdn.vuetifyjs.com/images/carousel/planet.jpg"
      }
    ];
    return (_ctx, _cache) => {
      const _component_v_carousel_item = resolveComponent("v-carousel-item");
      const _component_v_carousel = resolveComponent("v-carousel");
      return openBlock(), createBlock(_component_v_carousel, null, {
        default: withCtx(() => [
          (openBlock(), createElementBlock(Fragment, null, renderList(items, (item, i) => {
            return createVNode(_component_v_carousel_item, {
              key: i,
              src: item.src,
              "reverse-transition": "fade-transition",
              transition: "fade-transition",
              cover: ""
            }, null, 8, ["src"]);
          }), 64))
        ]),
        _: 1
      });
    };
  }
};
const __1 = _sfc_main$7;
const __1_raw = `<template>
  <v-carousel>
    <v-carousel-item
      v-for="(item,i) in items"
      :key="i"
      :src="item.src"
      reverse-transition="fade-transition"
      transition="fade-transition"
      cover
    ></v-carousel-item>
  </v-carousel>
</template>

<script setup>
  const items = [
    {
      src: 'https://cdn.vuetifyjs.com/images/carousel/squirrel.jpg',
    },
    {
      src: 'https://cdn.vuetifyjs.com/images/carousel/sky.jpg',
    },
    {
      src: 'https://cdn.vuetifyjs.com/images/carousel/bird.jpg',
    },
    {
      src: 'https://cdn.vuetifyjs.com/images/carousel/planet.jpg',
    },
  ]
<\/script>

<script>
  export default {
    data () {
      return {
        items: [
          {
            src: 'https://cdn.vuetifyjs.com/images/carousel/squirrel.jpg',
          },
          {
            src: 'https://cdn.vuetifyjs.com/images/carousel/sky.jpg',
          },
          {
            src: 'https://cdn.vuetifyjs.com/images/carousel/bird.jpg',
          },
          {
            src: 'https://cdn.vuetifyjs.com/images/carousel/planet.jpg',
          },
        ],
      }
    },
  }
<\/script>
`;
const _hoisted_1$3 = { class: "d-flex fill-height justify-center align-center" };
const _hoisted_2$3 = { class: "text-h2" };
const _sfc_main$6 = {
  __name: "prop-cycle",
  setup(__props) {
    const colors = [
      "indigo",
      "warning",
      "pink darken-2",
      "red lighten-1",
      "deep-purple accent-4"
    ];
    const slides = [
      "First",
      "Second",
      "Third",
      "Fourth",
      "Fifth"
    ];
    return (_ctx, _cache) => {
      const _component_v_sheet = resolveComponent("v-sheet");
      const _component_v_carousel_item = resolveComponent("v-carousel-item");
      const _component_v_carousel = resolveComponent("v-carousel");
      return openBlock(), createBlock(_component_v_carousel, {
        height: "400",
        "show-arrows": "hover",
        cycle: "",
        "hide-delimiter-background": ""
      }, {
        default: withCtx(() => [
          (openBlock(), createElementBlock(Fragment, null, renderList(slides, (slide, i) => {
            return createVNode(_component_v_carousel_item, { key: i }, {
              default: withCtx(() => [
                createVNode(_component_v_sheet, {
                  color: colors[i],
                  height: "100%"
                }, {
                  default: withCtx(() => [
                    createBaseVNode("div", _hoisted_1$3, [
                      createBaseVNode("div", _hoisted_2$3, toDisplayString(slide) + " Slide ", 1)
                    ])
                  ]),
                  _: 2
                }, 1032, ["color"])
              ]),
              _: 2
            }, 1024);
          }), 64))
        ]),
        _: 1
      });
    };
  }
};
const __2 = _sfc_main$6;
const __2_raw = `<template>
  <v-carousel
    height="400"
    show-arrows="hover"
    cycle
    hide-delimiter-background
  >
    <v-carousel-item
      v-for="(slide, i) in slides"
      :key="i"
    >
      <v-sheet
        :color="colors[i]"
        height="100%"
      >
        <div class="d-flex fill-height justify-center align-center">
          <div class="text-h2">
            {{ slide }} Slide
          </div>
        </div>
      </v-sheet>
    </v-carousel-item>
  </v-carousel>
</template>

<script setup>
  const colors = [
    'indigo',
    'warning',
    'pink darken-2',
    'red lighten-1',
    'deep-purple accent-4',
  ]
  const slides = [
    'First',
    'Second',
    'Third',
    'Fourth',
    'Fifth',
  ]
<\/script>

<script>
  export default {
    data () {
      return {
        colors: [
          'indigo',
          'warning',
          'pink darken-2',
          'red lighten-1',
          'deep-purple accent-4',
        ],
        slides: [
          'First',
          'Second',
          'Third',
          'Fourth',
          'Fifth',
        ],
      }
    },
  }
<\/script>
`;
const _sfc_main$5 = {
  __name: "prop-hide-controls",
  setup(__props) {
    const items = [
      {
        src: "https://cdn.vuetifyjs.com/images/carousel/squirrel.jpg"
      },
      {
        src: "https://cdn.vuetifyjs.com/images/carousel/sky.jpg"
      },
      {
        src: "https://cdn.vuetifyjs.com/images/carousel/bird.jpg"
      },
      {
        src: "https://cdn.vuetifyjs.com/images/carousel/planet.jpg"
      }
    ];
    return (_ctx, _cache) => {
      const _component_v_carousel_item = resolveComponent("v-carousel-item");
      const _component_v_carousel = resolveComponent("v-carousel");
      return openBlock(), createBlock(_component_v_carousel, { "show-arrows": false }, {
        default: withCtx(() => [
          (openBlock(), createElementBlock(Fragment, null, renderList(items, (item, i) => {
            return createVNode(_component_v_carousel_item, {
              key: i,
              src: item.src,
              cover: ""
            }, null, 8, ["src"]);
          }), 64))
        ]),
        _: 1
      });
    };
  }
};
const __3 = _sfc_main$5;
const __3_raw = `<template>
  <v-carousel :show-arrows="false">
    <v-carousel-item
      v-for="(item,i) in items"
      :key="i"
      :src="item.src"
      cover
    ></v-carousel-item>
  </v-carousel>
</template>

<script setup>
  const items = [
    {
      src: 'https://cdn.vuetifyjs.com/images/carousel/squirrel.jpg',
    },
    {
      src: 'https://cdn.vuetifyjs.com/images/carousel/sky.jpg',
    },
    {
      src: 'https://cdn.vuetifyjs.com/images/carousel/bird.jpg',
    },
    {
      src: 'https://cdn.vuetifyjs.com/images/carousel/planet.jpg',
    },
  ]
<\/script>

<script>
  export default {
    data () {
      return {
        items: [
          {
            src: 'https://cdn.vuetifyjs.com/images/carousel/squirrel.jpg',
          },
          {
            src: 'https://cdn.vuetifyjs.com/images/carousel/sky.jpg',
          },
          {
            src: 'https://cdn.vuetifyjs.com/images/carousel/bird.jpg',
          },
          {
            src: 'https://cdn.vuetifyjs.com/images/carousel/planet.jpg',
          },
        ],
      }
    },
  }
<\/script>
`;
const _sfc_main$4 = {
  __name: "prop-hide-delimiters",
  setup(__props) {
    const items = [
      {
        src: "https://cdn.vuetifyjs.com/images/carousel/squirrel.jpg"
      },
      {
        src: "https://cdn.vuetifyjs.com/images/carousel/sky.jpg"
      },
      {
        src: "https://cdn.vuetifyjs.com/images/carousel/bird.jpg"
      },
      {
        src: "https://cdn.vuetifyjs.com/images/carousel/planet.jpg"
      }
    ];
    return (_ctx, _cache) => {
      const _component_v_carousel_item = resolveComponent("v-carousel-item");
      const _component_v_carousel = resolveComponent("v-carousel");
      return openBlock(), createBlock(_component_v_carousel, { "hide-delimiters": "" }, {
        default: withCtx(() => [
          (openBlock(), createElementBlock(Fragment, null, renderList(items, (item, i) => {
            return createVNode(_component_v_carousel_item, {
              key: i,
              src: item.src,
              cover: ""
            }, null, 8, ["src"]);
          }), 64))
        ]),
        _: 1
      });
    };
  }
};
const __4 = _sfc_main$4;
const __4_raw = `<template>
  <v-carousel hide-delimiters>
    <v-carousel-item
      v-for="(item,i) in items"
      :key="i"
      :src="item.src"
      cover
    ></v-carousel-item>
  </v-carousel>
</template>

<script setup>
  const items = [
    {
      src: 'https://cdn.vuetifyjs.com/images/carousel/squirrel.jpg',
    },
    {
      src: 'https://cdn.vuetifyjs.com/images/carousel/sky.jpg',
    },
    {
      src: 'https://cdn.vuetifyjs.com/images/carousel/bird.jpg',
    },
    {
      src: 'https://cdn.vuetifyjs.com/images/carousel/planet.jpg',
    },
  ]
<\/script>

<script>
  export default {
    data () {
      return {
        items: [
          {
            src: 'https://cdn.vuetifyjs.com/images/carousel/squirrel.jpg',
          },
          {
            src: 'https://cdn.vuetifyjs.com/images/carousel/sky.jpg',
          },
          {
            src: 'https://cdn.vuetifyjs.com/images/carousel/bird.jpg',
          },
          {
            src: 'https://cdn.vuetifyjs.com/images/carousel/planet.jpg',
          },
        ],
      }
    },
  }
<\/script>
`;
const _hoisted_1$2 = { class: "d-flex justify-space-around align-center py-4" };
const _hoisted_2$2 = { class: "d-flex fill-height justify-center align-center" };
const _hoisted_3 = { class: "text-h2" };
const _sfc_main$3 = {
  __name: "prop-model",
  setup(__props) {
    const colors = [
      "primary",
      "secondary",
      "yellow darken-2",
      "red",
      "orange"
    ];
    const model = ref(0);
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_sheet = resolveComponent("v-sheet");
      const _component_v_carousel_item = resolveComponent("v-carousel-item");
      const _component_v_carousel = resolveComponent("v-carousel");
      return openBlock(), createElementBlock("div", null, [
        createBaseVNode("div", _hoisted_1$2, [
          createVNode(_component_v_btn, {
            icon: "mdi-minus",
            variant: "text",
            onClick: _cache[0] || (_cache[0] = ($event) => model.value = Math.max(model.value - 1, 0))
          }),
          createTextVNode(" " + toDisplayString(model.value) + " ", 1),
          createVNode(_component_v_btn, {
            icon: "mdi-plus",
            variant: "text",
            onClick: _cache[1] || (_cache[1] = ($event) => model.value = Math.min(model.value + 1, 4))
          })
        ]),
        createVNode(_component_v_carousel, {
          modelValue: model.value,
          "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => model.value = $event)
        }, {
          default: withCtx(() => [
            (openBlock(), createElementBlock(Fragment, null, renderList(colors, (color, i) => {
              return createVNode(_component_v_carousel_item, {
                key: color,
                value: i
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_sheet, {
                    color,
                    height: "100%",
                    tile: ""
                  }, {
                    default: withCtx(() => [
                      createBaseVNode("div", _hoisted_2$2, [
                        createBaseVNode("div", _hoisted_3, " Slide " + toDisplayString(i + 1), 1)
                      ])
                    ]),
                    _: 2
                  }, 1032, ["color"])
                ]),
                _: 2
              }, 1032, ["value"]);
            }), 64))
          ]),
          _: 1
        }, 8, ["modelValue"])
      ]);
    };
  }
};
const __5 = _sfc_main$3;
const __5_raw = `<template>
  <div>
    <div class="d-flex justify-space-around align-center py-4">
      <v-btn
        icon="mdi-minus"
        variant="text"
        @click="model = Math.max(model - 1, 0)"
      ></v-btn>
      {{ model }}
      <v-btn
        icon="mdi-plus"
        variant="text"
        @click="model = Math.min(model + 1, 4)"
      ></v-btn>
    </div>
    <v-carousel v-model="model">
      <v-carousel-item
        v-for="(color, i) in colors"
        :key="color"
        :value="i"
      >
        <v-sheet
          :color="color"
          height="100%"
          tile
        >
          <div class="d-flex fill-height justify-center align-center">
            <div class="text-h2">
              Slide {{ i + 1 }}
            </div>
          </div>
        </v-sheet>
      </v-carousel-item>
    </v-carousel>
  </div>
</template>

<script setup>
  import { ref } from 'vue'

  const colors = [
    'primary',
    'secondary',
    'yellow darken-2',
    'red',
    'orange',
  ]

  const model = ref(0)
<\/script>

<script>
  export default {
    data () {
      return {
        colors: [
          'primary',
          'secondary',
          'yellow darken-2',
          'red',
          'orange',
        ],
        model: 0,
      }
    },
  }
<\/script>
`;
const _hoisted_1$1 = { class: "d-flex fill-height justify-center align-center" };
const _hoisted_2$1 = { class: "text-h2" };
const _sfc_main$2 = {
  __name: "prop-progress",
  setup(__props) {
    const slides = [
      "First",
      "Second",
      "Third",
      "Fourth",
      "Fifth"
    ];
    return (_ctx, _cache) => {
      const _component_v_sheet = resolveComponent("v-sheet");
      const _component_v_carousel_item = resolveComponent("v-carousel-item");
      const _component_v_carousel = resolveComponent("v-carousel");
      return openBlock(), createBlock(_component_v_carousel, {
        height: "400",
        progress: "primary",
        "hide-delimiters": ""
      }, {
        default: withCtx(() => [
          (openBlock(), createElementBlock(Fragment, null, renderList(slides, (slide, i) => {
            return createVNode(_component_v_carousel_item, { key: i }, {
              default: withCtx(() => [
                createVNode(_component_v_sheet, { height: "100%" }, {
                  default: withCtx(() => [
                    createBaseVNode("div", _hoisted_1$1, [
                      createBaseVNode("div", _hoisted_2$1, toDisplayString(slide) + " Slide ", 1)
                    ])
                  ]),
                  _: 2
                }, 1024)
              ]),
              _: 2
            }, 1024);
          }), 64))
        ]),
        _: 1
      });
    };
  }
};
const __6 = _sfc_main$2;
const __6_raw = `<template>
  <v-carousel
    height="400"
    progress="primary"
    hide-delimiters
  >
    <v-carousel-item
      v-for="(slide, i) in slides"
      :key="i"
    >
      <v-sheet
        height="100%"
      >
        <div class="d-flex fill-height justify-center align-center">
          <div class="text-h2">
            {{ slide }} Slide
          </div>
        </div>
      </v-sheet>
    </v-carousel-item>
  </v-carousel>
</template>

<script setup>
  const slides = [
    'First',
    'Second',
    'Third',
    'Fourth',
    'Fifth',
  ]
<\/script>

<script>
  export default {
    data () {
      return {
        slides: [
          'First',
          'Second',
          'Third',
          'Fourth',
          'Fifth',
        ],
      }
    },
  }
<\/script>
`;
const _hoisted_1 = { class: "d-flex fill-height justify-center align-center" };
const _hoisted_2 = { class: "text-h2" };
const _sfc_main$1 = {
  __name: "slots-next-prev",
  setup(__props) {
    const colors = [
      "indigo",
      "warning",
      "pink darken-2",
      "red lighten-1",
      "deep-purple accent-4"
    ];
    const slides = [
      "First",
      "Second",
      "Third",
      "Fourth",
      "Fifth"
    ];
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_sheet = resolveComponent("v-sheet");
      const _component_v_carousel_item = resolveComponent("v-carousel-item");
      const _component_v_carousel = resolveComponent("v-carousel");
      return openBlock(), createBlock(_component_v_carousel, {
        height: "400",
        "hide-delimiter-background": "",
        "show-arrows": ""
      }, {
        prev: withCtx(({ props }) => [
          createVNode(_component_v_btn, {
            color: "success",
            variant: "elevated",
            onClick: props.onClick
          }, {
            default: withCtx(() => [
              createTextVNode("Previous slide")
            ]),
            _: 2
          }, 1032, ["onClick"])
        ]),
        next: withCtx(({ props }) => [
          createVNode(_component_v_btn, {
            color: "info",
            variant: "elevated",
            onClick: props.onClick
          }, {
            default: withCtx(() => [
              createTextVNode("Next slide")
            ]),
            _: 2
          }, 1032, ["onClick"])
        ]),
        default: withCtx(() => [
          (openBlock(), createElementBlock(Fragment, null, renderList(slides, (slide, i) => {
            return createVNode(_component_v_carousel_item, { key: i }, {
              default: withCtx(() => [
                createVNode(_component_v_sheet, {
                  color: colors[i],
                  height: "100%"
                }, {
                  default: withCtx(() => [
                    createBaseVNode("div", _hoisted_1, [
                      createBaseVNode("div", _hoisted_2, toDisplayString(slide) + " Slide ", 1)
                    ])
                  ]),
                  _: 2
                }, 1032, ["color"])
              ]),
              _: 2
            }, 1024);
          }), 64))
        ]),
        _: 1
      });
    };
  }
};
const __7 = _sfc_main$1;
const __7_raw = `<template>
  <v-carousel
    height="400"
    hide-delimiter-background
    show-arrows
  >
    <template v-slot:prev="{ props }">
      <v-btn
        color="success"
        variant="elevated"
        @click="props.onClick"
      >Previous slide</v-btn>
    </template>
    <template v-slot:next="{ props }">
      <v-btn
        color="info"
        variant="elevated"
        @click="props.onClick"
      >Next slide</v-btn>
    </template>
    <v-carousel-item
      v-for="(slide, i) in slides"
      :key="i"
    >
      <v-sheet
        :color="colors[i]"
        height="100%"
      >
        <div class="d-flex fill-height justify-center align-center">
          <div class="text-h2">
            {{ slide }} Slide
          </div>
        </div>
      </v-sheet>
    </v-carousel-item>
  </v-carousel>
</template>

<script setup>
  const colors = [
    'indigo',
    'warning',
    'pink darken-2',
    'red lighten-1',
    'deep-purple accent-4',
  ]
  const slides = [
    'First',
    'Second',
    'Third',
    'Fourth',
    'Fifth',
  ]
<\/script>

<script>
  export default {
    data () {
      return {
        colors: [
          'indigo',
          'warning',
          'pink darken-2',
          'red lighten-1',
          'deep-purple accent-4',
        ],
        slides: [
          'First',
          'Second',
          'Third',
          'Fourth',
          'Fifth',
        ],
      }
    },
  }
<\/script>
`;
const name = "v-carousel";
const _sfc_main = {
  __name: "usage",
  setup(__props) {
    const model = ref("default");
    const options = ["Hide delimiters", "Show arrows on hover"];
    const props = computed(() => {
      return {
        "hide-delimiters": model.value === "Hide delimiters" || void 0,
        "show-arrows": model.value === "Show arrows on hover" ? "hover" : void 0
      };
    });
    const slots = computed(() => {
      return `
  <v-carousel-item
    src="https://cdn.vuetifyjs.com/images/cards/docks.jpg"
    cover
  ></v-carousel-item>

  <v-carousel-item
    src="https://cdn.vuetifyjs.com/images/cards/hotel.jpg"
    cover
  ></v-carousel-item>

  <v-carousel-item
    src="https://cdn.vuetifyjs.com/images/cards/sunshine.jpg"
    cover
  ></v-carousel-item>
`;
    });
    const code = computed(() => {
      return `<${name}${propsToString(props.value)}>${slots.value}</${name}>`;
    });
    return (_ctx, _cache) => {
      const _component_v_carousel_item = resolveComponent("v-carousel-item");
      const _component_v_carousel = resolveComponent("v-carousel");
      const _component_ExamplesUsageExample = _sfc_main$9;
      return openBlock(), createBlock(_component_ExamplesUsageExample, {
        modelValue: unref(model),
        "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(model) ? model.value = $event : null),
        code: unref(code),
        name,
        options
      }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createVNode(_component_v_carousel, normalizeProps(guardReactiveProps(unref(props))), {
              default: withCtx(() => [
                createVNode(_component_v_carousel_item, {
                  src: "https://cdn.vuetifyjs.com/images/cards/docks.jpg",
                  cover: ""
                }),
                createVNode(_component_v_carousel_item, {
                  src: "https://cdn.vuetifyjs.com/images/cards/hotel.jpg",
                  cover: ""
                }),
                createVNode(_component_v_carousel_item, {
                  src: "https://cdn.vuetifyjs.com/images/cards/sunshine.jpg",
                  cover: ""
                })
              ]),
              _: 1
            }, 16)
          ])
        ]),
        _: 1
      }, 8, ["modelValue", "code"]);
    };
  }
};
const __8 = _sfc_main;
const __8_raw = `<template>
  <ExamplesUsageExample
    v-model="model"
    :code="code"
    :name="name"
    :options="options"
  >
    <div>
      <v-carousel v-bind="props">
        <v-carousel-item
          src="https://cdn.vuetifyjs.com/images/cards/docks.jpg"
          cover
        ></v-carousel-item>

        <v-carousel-item
          src="https://cdn.vuetifyjs.com/images/cards/hotel.jpg"
          cover
        ></v-carousel-item>

        <v-carousel-item
          src="https://cdn.vuetifyjs.com/images/cards/sunshine.jpg"
          cover
        ></v-carousel-item>
      </v-carousel>
    </div>
  </ExamplesUsageExample>
</template>

<script setup>
  const name = 'v-carousel'
  const model = ref('default')
  const options = ['Hide delimiters', 'Show arrows on hover']
  const props = computed(() => {
    return {
      'hide-delimiters': model.value === 'Hide delimiters' || undefined,
      'show-arrows': model.value === 'Show arrows on hover' ? 'hover' : undefined,
    }
  })

  const slots = computed(() => {
    return \`
  <v-carousel-item
    src="https://cdn.vuetifyjs.com/images/cards/docks.jpg"
    cover
  ></v-carousel-item>

  <v-carousel-item
    src="https://cdn.vuetifyjs.com/images/cards/hotel.jpg"
    cover
  ></v-carousel-item>

  <v-carousel-item
    src="https://cdn.vuetifyjs.com/images/cards/sunshine.jpg"
    cover
  ></v-carousel-item>
\`
  })

  const code = computed(() => {
    return \`<\${name}\${propsToString(props.value)}>\${slots.value}</\${name}>\`
  })
<\/script>
`;
const vCarousel = {
  "prop-custom-icons": {
    component: __0,
    source: __0_raw
  },
  "prop-custom-transition": {
    component: __1,
    source: __1_raw
  },
  "prop-cycle": {
    component: __2,
    source: __2_raw
  },
  "prop-hide-controls": {
    component: __3,
    source: __3_raw
  },
  "prop-hide-delimiters": {
    component: __4,
    source: __4_raw
  },
  "prop-model": {
    component: __5,
    source: __5_raw
  },
  "prop-progress": {
    component: __6,
    source: __6_raw
  },
  "slots-next-prev": {
    component: __7,
    source: __7_raw
  },
  "usage": {
    component: __8,
    source: __8_raw
  }
};
export {
  vCarousel as default
};
