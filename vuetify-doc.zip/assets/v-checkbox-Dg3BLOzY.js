import { J as ref, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, b as createVNode, e as createBaseVNode, l as createElementBlock, t as toDisplayString, y as _export_sfc, h as createTextVNode, a9 as mergeProps, V as withModifiers, j as computed, ag as propsToString, f as unref, E as isRef } from "./index-DGybHjCP.js";
import { _ as _sfc_main$7 } from "./UsageExample-M8CmNipa.js";
const _hoisted_1 = { class: "d-flex pa-4" };
const _hoisted_2 = { class: "d-flex pa-4" };
const _sfc_main$6 = {
  __name: "misc-inline-textfield",
  setup(__props) {
    const includeFiles = ref(true);
    const enabled = ref(false);
    return (_ctx, _cache) => {
      const _component_v_checkbox_btn = resolveComponent("v-checkbox-btn");
      const _component_v_text_field = resolveComponent("v-text-field");
      const _component_v_card_text = resolveComponent("v-card-text");
      const _component_v_card = resolveComponent("v-card");
      return openBlock(), createBlock(_component_v_card, null, {
        default: withCtx(() => [
          createVNode(_component_v_card_text, null, {
            default: withCtx(() => [
              createBaseVNode("div", _hoisted_1, [
                createVNode(_component_v_checkbox_btn, {
                  modelValue: includeFiles.value,
                  "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => includeFiles.value = $event),
                  class: "pe-2"
                }, null, 8, ["modelValue"]),
                createVNode(_component_v_text_field, {
                  label: "Include files",
                  "hide-details": ""
                })
              ]),
              createBaseVNode("div", _hoisted_2, [
                createVNode(_component_v_checkbox_btn, {
                  modelValue: enabled.value,
                  "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => enabled.value = $event),
                  class: "pe-2"
                }, null, 8, ["modelValue"]),
                createVNode(_component_v_text_field, {
                  disabled: !enabled.value,
                  label: "I only work if you check the box",
                  "hide-details": ""
                }, null, 8, ["disabled"])
              ])
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __0 = _sfc_main$6;
const __0_raw = `<template>
  <v-card>
    <v-card-text>
      <div class="d-flex pa-4">
        <v-checkbox-btn
          v-model="includeFiles"
          class="pe-2"
        ></v-checkbox-btn>
        <v-text-field
          label="Include files"
          hide-details
        ></v-text-field>
      </div>
      <div class="d-flex pa-4">
        <v-checkbox-btn
          v-model="enabled"
          class="pe-2"
        ></v-checkbox-btn>
        <v-text-field
          :disabled="!enabled"
          label="I only work if you check the box"
          hide-details
        ></v-text-field>
      </div>
    </v-card-text>
  </v-card>
</template>

<script setup>
  import { ref } from 'vue'

  const includeFiles = ref(true)
  const enabled = ref(false)
<\/script>

<script>
  export default {
    data: () => ({
      includeFiles: true,
      enabled: false,
    }),
  }
<\/script>
`;
const _sfc_main$5 = {
  __name: "prop-colors",
  setup(__props) {
    const ex4 = ["red", "indigo", "orange", "primary", "secondary", "success", "info", "warning", "error", "red darken-3", "indigo darken-3", "orange darken-3"];
    return (_ctx, _cache) => {
      const _component_v_checkbox = resolveComponent("v-checkbox");
      const _component_v_col = resolveComponent("v-col");
      const _component_v_row = resolveComponent("v-row");
      const _component_v_container = resolveComponent("v-container");
      return openBlock(), createElementBlock("div", null, [
        createVNode(_component_v_container, { fluid: "" }, {
          default: withCtx(() => [
            createVNode(_component_v_row, null, {
              default: withCtx(() => [
                createVNode(_component_v_col, {
                  cols: "12",
                  md: "4",
                  sm: "4"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_v_checkbox, {
                      modelValue: ex4,
                      "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => ex4 = $event),
                      color: "red",
                      label: "red",
                      value: "red",
                      "hide-details": ""
                    }),
                    createVNode(_component_v_checkbox, {
                      modelValue: ex4,
                      "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => ex4 = $event),
                      color: "red-darken-3",
                      label: "red-darken-3",
                      value: "red-darken-3",
                      "hide-details": ""
                    })
                  ]),
                  _: 1
                }),
                createVNode(_component_v_col, {
                  cols: "12",
                  md: "4",
                  sm: "4"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_v_checkbox, {
                      modelValue: ex4,
                      "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => ex4 = $event),
                      color: "indigo",
                      label: "indigo",
                      value: "indigo",
                      "hide-details": ""
                    }),
                    createVNode(_component_v_checkbox, {
                      modelValue: ex4,
                      "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => ex4 = $event),
                      color: "indigo-darken-3",
                      label: "indigo-darken-3",
                      value: "indigo-darken-3",
                      "hide-details": ""
                    })
                  ]),
                  _: 1
                }),
                createVNode(_component_v_col, {
                  cols: "12",
                  md: "4",
                  sm: "4"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_v_checkbox, {
                      modelValue: ex4,
                      "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => ex4 = $event),
                      color: "orange",
                      label: "orange",
                      value: "orange",
                      "hide-details": ""
                    }),
                    createVNode(_component_v_checkbox, {
                      modelValue: ex4,
                      "onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => ex4 = $event),
                      color: "orange-darken-3",
                      label: "orange-darken-3",
                      value: "orange-darken-3",
                      "hide-details": ""
                    })
                  ]),
                  _: 1
                })
              ]),
              _: 1
            }),
            createVNode(_component_v_row, { class: "mt-12" }, {
              default: withCtx(() => [
                createVNode(_component_v_col, {
                  cols: "12",
                  md: "4",
                  sm: "4"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_v_checkbox, {
                      modelValue: ex4,
                      "onUpdate:modelValue": _cache[6] || (_cache[6] = ($event) => ex4 = $event),
                      color: "primary",
                      label: "primary",
                      value: "primary",
                      "hide-details": ""
                    }),
                    createVNode(_component_v_checkbox, {
                      modelValue: ex4,
                      "onUpdate:modelValue": _cache[7] || (_cache[7] = ($event) => ex4 = $event),
                      color: "secondary",
                      label: "secondary",
                      value: "secondary",
                      "hide-details": ""
                    })
                  ]),
                  _: 1
                }),
                createVNode(_component_v_col, {
                  cols: "12",
                  md: "4",
                  sm: "4"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_v_checkbox, {
                      modelValue: ex4,
                      "onUpdate:modelValue": _cache[8] || (_cache[8] = ($event) => ex4 = $event),
                      color: "success",
                      label: "success",
                      value: "success",
                      "hide-details": ""
                    }),
                    createVNode(_component_v_checkbox, {
                      modelValue: ex4,
                      "onUpdate:modelValue": _cache[9] || (_cache[9] = ($event) => ex4 = $event),
                      color: "info",
                      label: "info",
                      value: "info",
                      "hide-details": ""
                    })
                  ]),
                  _: 1
                }),
                createVNode(_component_v_col, {
                  cols: "12",
                  md: "4",
                  sm: "4"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_v_checkbox, {
                      modelValue: ex4,
                      "onUpdate:modelValue": _cache[10] || (_cache[10] = ($event) => ex4 = $event),
                      color: "warning",
                      label: "warning",
                      value: "warning",
                      "hide-details": ""
                    }),
                    createVNode(_component_v_checkbox, {
                      modelValue: ex4,
                      "onUpdate:modelValue": _cache[11] || (_cache[11] = ($event) => ex4 = $event),
                      color: "error",
                      label: "error",
                      value: "error",
                      "hide-details": ""
                    })
                  ]),
                  _: 1
                })
              ]),
              _: 1
            })
          ]),
          _: 1
        })
      ]);
    };
  }
};
const __1 = _sfc_main$5;
const __1_raw = `<template>
  <div>
    <v-container fluid>
      <v-row>
        <v-col
          cols="12"
          md="4"
          sm="4"
        >
          <v-checkbox
            v-model="ex4"
            color="red"
            label="red"
            value="red"
            hide-details
          ></v-checkbox>
          <v-checkbox
            v-model="ex4"
            color="red-darken-3"
            label="red-darken-3"
            value="red-darken-3"
            hide-details
          ></v-checkbox>
        </v-col>
        <v-col
          cols="12"
          md="4"
          sm="4"
        >
          <v-checkbox
            v-model="ex4"
            color="indigo"
            label="indigo"
            value="indigo"
            hide-details
          ></v-checkbox>
          <v-checkbox
            v-model="ex4"
            color="indigo-darken-3"
            label="indigo-darken-3"
            value="indigo-darken-3"
            hide-details
          ></v-checkbox>
        </v-col>
        <v-col
          cols="12"
          md="4"
          sm="4"
        >
          <v-checkbox
            v-model="ex4"
            color="orange"
            label="orange"
            value="orange"
            hide-details
          ></v-checkbox>
          <v-checkbox
            v-model="ex4"
            color="orange-darken-3"
            label="orange-darken-3"
            value="orange-darken-3"
            hide-details
          ></v-checkbox>
        </v-col>
      </v-row>

      <v-row class="mt-12">
        <v-col
          cols="12"
          md="4"
          sm="4"
        >
          <v-checkbox
            v-model="ex4"
            color="primary"
            label="primary"
            value="primary"
            hide-details
          ></v-checkbox>
          <v-checkbox
            v-model="ex4"
            color="secondary"
            label="secondary"
            value="secondary"
            hide-details
          ></v-checkbox>
        </v-col>
        <v-col
          cols="12"
          md="4"
          sm="4"
        >
          <v-checkbox
            v-model="ex4"
            color="success"
            label="success"
            value="success"
            hide-details
          ></v-checkbox>
          <v-checkbox
            v-model="ex4"
            color="info"
            label="info"
            value="info"
            hide-details
          ></v-checkbox>
        </v-col>
        <v-col
          cols="12"
          md="4"
          sm="4"
        >
          <v-checkbox
            v-model="ex4"
            color="warning"
            label="warning"
            value="warning"
            hide-details
          ></v-checkbox>
          <v-checkbox
            v-model="ex4"
            color="error"
            label="error"
            value="error"
            hide-details
          ></v-checkbox>
        </v-col>
      </v-row>
    </v-container>
  </div>
</template>

<script setup>
  const ex4 = ['red', 'indigo', 'orange', 'primary', 'secondary', 'success', 'info', 'warning', 'error', 'red darken-3', 'indigo darken-3', 'orange darken-3']
<\/script>

<script>
  export default {
    data () {
      return {
        ex4: ['red', 'indigo', 'orange', 'primary', 'secondary', 'success', 'info', 'warning', 'error', 'red darken-3', 'indigo darken-3', 'orange darken-3'],
      }
    },
  }
<\/script>
`;
const _sfc_main$4 = {
  __name: "prop-model-as-array",
  setup(__props) {
    const selected = ref(["John"]);
    return (_ctx, _cache) => {
      const _component_v_checkbox = resolveComponent("v-checkbox");
      const _component_v_container = resolveComponent("v-container");
      return openBlock(), createBlock(_component_v_container, { fluid: "" }, {
        default: withCtx(() => [
          createBaseVNode("p", null, toDisplayString(selected.value), 1),
          createVNode(_component_v_checkbox, {
            modelValue: selected.value,
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => selected.value = $event),
            label: "John",
            value: "John"
          }, null, 8, ["modelValue"]),
          createVNode(_component_v_checkbox, {
            modelValue: selected.value,
            "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => selected.value = $event),
            label: "Jacob",
            value: "Jacob"
          }, null, 8, ["modelValue"])
        ]),
        _: 1
      });
    };
  }
};
const __2 = _sfc_main$4;
const __2_raw = `<template>
  <v-container fluid>
    <p>{{ selected }}</p>
    <v-checkbox
      v-model="selected"
      label="John"
      value="John"
    ></v-checkbox>
    <v-checkbox
      v-model="selected"
      label="Jacob"
      value="Jacob"
    ></v-checkbox>
  </v-container>
</template>

<script setup>
  import { ref } from 'vue'

  const selected = ref(['John'])
<\/script>

<script>
  export default {
    data () {
      return {
        selected: ['John'],
      }
    },
  }
<\/script>
`;
const _sfc_main$3 = {
  __name: "prop-model-as-boolean",
  setup(__props) {
    const checkbox1 = ref(true);
    const checkbox2 = ref(false);
    return (_ctx, _cache) => {
      const _component_v_checkbox = resolveComponent("v-checkbox");
      const _component_v_container = resolveComponent("v-container");
      return openBlock(), createBlock(_component_v_container, { fluid: "" }, {
        default: withCtx(() => [
          createVNode(_component_v_checkbox, {
            modelValue: checkbox1.value,
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => checkbox1.value = $event),
            label: `Checkbox 1: ${checkbox1.value.toString()}`
          }, null, 8, ["modelValue", "label"]),
          createVNode(_component_v_checkbox, {
            modelValue: checkbox2.value,
            "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => checkbox2.value = $event),
            label: `Checkbox 2: ${checkbox2.value.toString()}`
          }, null, 8, ["modelValue", "label"])
        ]),
        _: 1
      });
    };
  }
};
const __3 = _sfc_main$3;
const __3_raw = '<template>\n  <v-container fluid>\n    <v-checkbox\n      v-model="checkbox1"\n      :label="`Checkbox 1: ${checkbox1.toString()}`"\n    ></v-checkbox>\n    <v-checkbox\n      v-model="checkbox2"\n      :label="`Checkbox 2: ${checkbox2.toString()}`"\n    ></v-checkbox>\n  </v-container>\n</template>\n\n<script setup>\n  import { ref } from \'vue\'\n\n  const checkbox1 = ref(true)\n  const checkbox2 = ref(false)\n<\/script>\n\n<script>\n  export default {\n    data () {\n      return {\n        checkbox1: true,\n        checkbox2: false,\n      }\n    },\n  }\n<\/script>\n';
const _sfc_main$2 = {};
function _sfc_render(_ctx, _cache) {
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_checkbox = resolveComponent("v-checkbox");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, { fluid: "" }, {
    default: withCtx(() => [
      createVNode(_component_v_row, null, {
        default: withCtx(() => [
          createVNode(_component_v_col, { cols: "4" }, {
            default: withCtx(() => [
              createTextVNode(" on ")
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "4" }, {
            default: withCtx(() => [
              createTextVNode(" off ")
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "4" }, {
            default: withCtx(() => [
              createTextVNode(" indeterminate ")
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_row, null, {
        default: withCtx(() => [
          createVNode(_component_v_col, { cols: "4" }, {
            default: withCtx(() => [
              createVNode(_component_v_checkbox, { "model-value": true })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "4" }, {
            default: withCtx(() => [
              createVNode(_component_v_checkbox, { "model-value": false })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "4" }, {
            default: withCtx(() => [
              createVNode(_component_v_checkbox, { indeterminate: "" })
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_row, null, {
        default: withCtx(() => [
          createVNode(_component_v_col, { cols: "4" }, {
            default: withCtx(() => [
              createTextVNode(" on disabled ")
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "4" }, {
            default: withCtx(() => [
              createTextVNode(" off disabled ")
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_row, null, {
        default: withCtx(() => [
          createVNode(_component_v_col, { cols: "4" }, {
            default: withCtx(() => [
              createVNode(_component_v_checkbox, {
                "model-value": true,
                disabled: ""
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "4" }, {
            default: withCtx(() => [
              createVNode(_component_v_checkbox, {
                "model-value": false,
                disabled: ""
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, { cols: "4" }, {
            default: withCtx(() => [
              createVNode(_component_v_checkbox, {
                disabled: "",
                indeterminate: ""
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __4 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["render", _sfc_render]]);
const __4_raw = '<template>\n  <v-container fluid>\n    <v-row>\n      <v-col cols="4">\n        on\n      </v-col>\n      <v-col cols="4">\n        off\n      </v-col>\n      <v-col cols="4">\n        indeterminate\n      </v-col>\n    </v-row>\n    <v-row>\n      <v-col cols="4">\n        <v-checkbox\n          :model-value="true"\n        ></v-checkbox>\n      </v-col>\n      <v-col cols="4">\n        <v-checkbox :model-value="false"></v-checkbox>\n      </v-col>\n      <v-col cols="4">\n        <v-checkbox\n          indeterminate\n        ></v-checkbox>\n      </v-col>\n    </v-row>\n    <v-row>\n      <v-col cols="4">\n        on disabled\n      </v-col>\n      <v-col cols="4">\n        off disabled\n      </v-col>\n    </v-row>\n    <v-row>\n      <v-col cols="4">\n        <v-checkbox\n          :model-value="true"\n          disabled\n        ></v-checkbox>\n      </v-col>\n      <v-col cols="4">\n        <v-checkbox\n          :model-value="false"\n          disabled\n        ></v-checkbox>\n      </v-col>\n      <v-col cols="4">\n        <v-checkbox\n          disabled\n          indeterminate\n        ></v-checkbox>\n      </v-col>\n    </v-row>\n  </v-container>\n</template>\n';
const _sfc_main$1 = {
  __name: "slot-label",
  setup(__props) {
    const checkbox = ref(false);
    return (_ctx, _cache) => {
      const _component_v_tooltip = resolveComponent("v-tooltip");
      const _component_v_checkbox = resolveComponent("v-checkbox");
      const _component_v_container = resolveComponent("v-container");
      return openBlock(), createBlock(_component_v_container, { fluid: "" }, {
        default: withCtx(() => [
          createVNode(_component_v_checkbox, {
            modelValue: checkbox.value,
            "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => checkbox.value = $event)
          }, {
            label: withCtx(() => [
              createBaseVNode("div", null, [
                createTextVNode(" I agree that "),
                createVNode(_component_v_tooltip, { location: "bottom" }, {
                  activator: withCtx(({ props }) => [
                    createBaseVNode("a", mergeProps({
                      href: "https://vuetifyjs.com",
                      target: "_blank"
                    }, props, {
                      onClick: _cache[0] || (_cache[0] = withModifiers(() => {
                      }, ["stop"]))
                    }), " Vuetify ", 16)
                  ]),
                  default: withCtx(() => [
                    createTextVNode(" Opens in new window ")
                  ]),
                  _: 1
                }),
                createTextVNode(" is awesome ")
              ])
            ]),
            _: 1
          }, 8, ["modelValue"])
        ]),
        _: 1
      });
    };
  }
};
const __5 = _sfc_main$1;
const __5_raw = `<template>
  <v-container fluid>
    <v-checkbox v-model="checkbox">
      <template v-slot:label>
        <div>
          I agree that
          <v-tooltip location="bottom">
            <template v-slot:activator="{ props }">
              <a
                href="https://vuetifyjs.com"
                target="_blank"
                v-bind="props"
                @click.stop
              >
                Vuetify
              </a>
            </template>
            Opens in new window
          </v-tooltip>
          is awesome
        </div>
      </template>
    </v-checkbox>
  </v-container>
</template>

<script setup>
  import { ref } from 'vue'

  const checkbox = ref(false)
<\/script>

<script>
  export default {
    data () {
      return {
        checkbox: false,
      }
    },
  }
<\/script>
`;
const name = "v-checkbox";
const _sfc_main = {
  __name: "usage",
  setup(__props) {
    const model = ref("default");
    const options = [];
    const props = computed(() => {
      return {
        label: "Checkbox"
      };
    });
    const slots = computed(() => {
      return ``;
    });
    const code = computed(() => {
      return `<${name}${propsToString(props.value)}>${slots.value}</${name}>`;
    });
    return (_ctx, _cache) => {
      const _component_v_checkbox = resolveComponent("v-checkbox");
      const _component_ExamplesUsageExample = _sfc_main$7;
      return openBlock(), createBlock(_component_ExamplesUsageExample, {
        modelValue: unref(model),
        "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(model) ? model.value = $event : null),
        code: unref(code),
        name,
        options
      }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createVNode(_component_v_checkbox, mergeProps(unref(props), { "hide-details": "" }), null, 16)
          ])
        ]),
        _: 1
      }, 8, ["modelValue", "code"]);
    };
  }
};
const __6 = _sfc_main;
const __6_raw = '<template>\n  <ExamplesUsageExample\n    v-model="model"\n    :code="code"\n    :name="name"\n    :options="options"\n  >\n    <div>\n      <v-checkbox v-bind="props" hide-details></v-checkbox>\n    </div>\n  </ExamplesUsageExample>\n</template>\n\n<script setup>\n  const name = \'v-checkbox\'\n  const model = ref(\'default\')\n  const options = []\n  const props = computed(() => {\n    return {\n      label: \'Checkbox\',\n    }\n  })\n\n  const slots = computed(() => {\n    return ``\n  })\n\n  const code = computed(() => {\n    return `<${name}${propsToString(props.value)}>${slots.value}</${name}>`\n  })\n<\/script>\n';
const vCheckbox = {
  "misc-inline-textfield": {
    component: __0,
    source: __0_raw
  },
  "prop-colors": {
    component: __1,
    source: __1_raw
  },
  "prop-model-as-array": {
    component: __2,
    source: __2_raw
  },
  "prop-model-as-boolean": {
    component: __3,
    source: __3_raw
  },
  "prop-states": {
    component: __4,
    source: __4_raw
  },
  "slot-label": {
    component: __5,
    source: __5_raw
  },
  "usage": {
    component: __6,
    source: __6_raw
  }
};
export {
  vCheckbox as default
};
