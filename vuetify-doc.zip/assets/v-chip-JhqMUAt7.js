import { y as _export_sfc, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, b as createVNode, e as createBaseVNode, h as createTextVNode, J as ref, j as computed, O as watch, l as createElementBlock, F as Fragment, v as renderList, t as toDisplayString, q as createCommentVNode, a9 as mergeProps, ag as propsToString, f as unref, E as isRef } from "./index-DGybHjCP.js";
import { _ as _sfc_main$f } from "./UsageExample-M8CmNipa.js";
const _sfc_main$e = {
  methods: {
    alarm() {
      alert("Turning on alarm...");
    },
    blinds() {
      alert("Toggling blinds...");
    },
    lights() {
      alert("Toggling lights...");
    }
  }
};
const _hoisted_1$c = /* @__PURE__ */ createBaseVNode("div", { class: "text-h4 mb-2" }, " Welcome Home... ", -1);
const _hoisted_2$4 = /* @__PURE__ */ createBaseVNode("div", { class: "text-h6 font-weight-regular text-grey" }, " Monday, 12:30 PM, Mostly Sunny ", -1);
const _hoisted_3$1 = { class: "d-flex align-center" };
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("span", { class: "text-body-2 text-grey" }, "81° / 62°", -1);
function _sfc_render$7(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_v_img = resolveComponent("v-img");
  const _component_v_avatar = resolveComponent("v-avatar");
  const _component_v_card_title = resolveComponent("v-card-title");
  const _component_v_divider = resolveComponent("v-divider");
  const _component_v_chip = resolveComponent("v-chip");
  const _component_v_card_text = resolveComponent("v-card-text");
  const _component_v_card = resolveComponent("v-card");
  return openBlock(), createBlock(_component_v_card, {
    class: "mx-auto",
    "max-width": "450"
  }, {
    default: withCtx(() => [
      createVNode(_component_v_img, {
        "aspect-ratio": 16 / 9,
        src: "https://cdn.vuetifyjs.com/images/cards/house.jpg",
        cover: ""
      }),
      createVNode(_component_v_card_title, { class: "flex-column align-start" }, {
        default: withCtx(() => [
          _hoisted_1$c,
          _hoisted_2$4,
          createBaseVNode("div", _hoisted_3$1, [
            createVNode(_component_v_avatar, {
              class: "me-4",
              size: "24"
            }, {
              default: withCtx(() => [
                createVNode(_component_v_img, {
                  src: "https://cdn.vuetifyjs.com/images/weather/part-cloud-48px.png",
                  contain: ""
                })
              ]),
              _: 1
            }),
            _hoisted_4
          ])
        ]),
        _: 1
      }),
      createVNode(_component_v_divider, { class: "mx-4" }),
      createVNode(_component_v_card_text, { class: "d-flex justify-space-between" }, {
        default: withCtx(() => [
          createVNode(_component_v_chip, {
            "prepend-icon": "mdi-brightness-5",
            onClick: $options.lights
          }, {
            default: withCtx(() => [
              createTextVNode(" Turn on lights ")
            ]),
            _: 1
          }, 8, ["onClick"]),
          createVNode(_component_v_chip, {
            "prepend-icon": "mdi-alarm-check",
            onClick: $options.alarm
          }, {
            default: withCtx(() => [
              createTextVNode(" Set alarm ")
            ]),
            _: 1
          }, 8, ["onClick"]),
          createVNode(_component_v_chip, {
            icon: "mdi-blinds",
            onClick: $options.blinds
          }, {
            default: withCtx(() => [
              createTextVNode(" Close blinds ")
            ]),
            _: 1
          }, 8, ["onClick"])
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __0 = /* @__PURE__ */ _export_sfc(_sfc_main$e, [["render", _sfc_render$7]]);
const __0_raw = `<template>
  <v-card
    class="mx-auto"
    max-width="450"
  >
    <v-img
      :aspect-ratio="16/9"
      src="https://cdn.vuetifyjs.com/images/cards/house.jpg"
      cover
    >
    </v-img>
    <v-card-title class="flex-column align-start">
      <div class="text-h4 mb-2">
        Welcome Home...
      </div>
      <div class="text-h6 font-weight-regular text-grey">
        Monday, 12:30 PM, Mostly Sunny
      </div>
      <div class="d-flex align-center">
        <v-avatar
          class="me-4"
          size="24"
        >
          <v-img
            src="https://cdn.vuetifyjs.com/images/weather/part-cloud-48px.png"
            contain
          ></v-img>
        </v-avatar>

        <span class="text-body-2 text-grey">81° / 62°</span>
      </div>
    </v-card-title>

    <v-divider class="mx-4"></v-divider>

    <v-card-text class="d-flex justify-space-between">
      <v-chip
        prepend-icon="mdi-brightness-5"
        @click="lights"
      >
        Turn on lights
      </v-chip>
      <v-chip
        prepend-icon="mdi-alarm-check"
        @click="alarm"
      >
        Set alarm
      </v-chip>
      <v-chip
        icon="mdi-blinds"
        @click="blinds"
      >
        Close blinds
      </v-chip>
    </v-card-text>
  </v-card>
</template>

<script>
  export default {
    methods: {
      alarm () {
        alert('Turning on alarm...')
      },
      blinds () {
        alert('Toggling blinds...')
      },
      lights () {
        alert('Toggling lights...')
      },
    },
  }
<\/script>
`;
const _sfc_main$d = {
  __name: "misc-custom-list",
  setup(__props) {
    const items = [
      {
        text: "Nature",
        icon: "mdi-nature"
      },
      {
        text: "Nightlife",
        icon: "mdi-glass-wine"
      },
      {
        text: "November",
        icon: "mdi-calendar-range"
      },
      {
        text: "Portland",
        icon: "mdi-map-marker"
      },
      {
        text: "Biking",
        icon: "mdi-bike"
      }
    ];
    const searchField = ref();
    const loading = ref(false);
    const search = ref("");
    const selected = ref([]);
    const allSelected = computed(() => {
      return selected.value.length === items.length;
    });
    const categories = computed(() => {
      const _search = search.value.toLowerCase();
      if (!_search)
        return items;
      return items.filter((item) => {
        const text = item.text.toLowerCase();
        return text.indexOf(_search) > -1;
      });
    });
    const selections = computed(() => {
      const selections2 = [];
      for (const selection of selected.value) {
        selections2.push(selection);
      }
      return selections2;
    });
    watch(selected, () => {
      search.value = "";
    });
    function next() {
      loading.value = true;
      setTimeout(() => {
        search.value = "";
        selected.value = [];
        loading.value = false;
      }, 2e3);
    }
    return (_ctx, _cache) => {
      const _component_v_app_bar_nav_icon = resolveComponent("v-app-bar-nav-icon");
      const _component_v_toolbar_title = resolveComponent("v-toolbar-title");
      const _component_v_spacer = resolveComponent("v-spacer");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_toolbar = resolveComponent("v-toolbar");
      const _component_v_icon = resolveComponent("v-icon");
      const _component_v_chip = resolveComponent("v-chip");
      const _component_v_col = resolveComponent("v-col");
      const _component_v_text_field = resolveComponent("v-text-field");
      const _component_v_row = resolveComponent("v-row");
      const _component_v_container = resolveComponent("v-container");
      const _component_v_divider = resolveComponent("v-divider");
      const _component_v_list_item_title = resolveComponent("v-list-item-title");
      const _component_v_list_item = resolveComponent("v-list-item");
      const _component_v_list = resolveComponent("v-list");
      const _component_v_card_actions = resolveComponent("v-card-actions");
      const _component_v_card = resolveComponent("v-card");
      return openBlock(), createBlock(_component_v_card, {
        class: "mx-auto",
        "max-width": "500"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_toolbar, {
            color: "transparent",
            flat: ""
          }, {
            default: withCtx(() => [
              createVNode(_component_v_app_bar_nav_icon),
              createVNode(_component_v_toolbar_title, null, {
                default: withCtx(() => [
                  createTextVNode("Photo Info")
                ]),
                _: 1
              }),
              createVNode(_component_v_spacer),
              createVNode(_component_v_btn, {
                icon: "mdi-magnify",
                onClick: _cache[0] || (_cache[0] = ($event) => searchField.value.focus())
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_container, null, {
            default: withCtx(() => [
              createVNode(_component_v_row, {
                align: "center",
                justify: "start"
              }, {
                default: withCtx(() => [
                  (openBlock(true), createElementBlock(Fragment, null, renderList(selections.value, (selection, i) => {
                    return openBlock(), createBlock(_component_v_col, {
                      key: selection.text,
                      class: "py-1 pe-0",
                      cols: "auto"
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_v_chip, {
                          disabled: loading.value,
                          closable: "",
                          "onClick:close": ($event) => selected.value.splice(i, 1)
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_v_icon, {
                              icon: selection.icon,
                              start: ""
                            }, null, 8, ["icon"]),
                            createTextVNode(" " + toDisplayString(selection.text), 1)
                          ]),
                          _: 2
                        }, 1032, ["disabled", "onClick:close"])
                      ]),
                      _: 2
                    }, 1024);
                  }), 128)),
                  !allSelected.value ? (openBlock(), createBlock(_component_v_col, {
                    key: 0,
                    cols: "12"
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_v_text_field, {
                        ref_key: "searchField",
                        ref: searchField,
                        modelValue: search.value,
                        "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => search.value = $event),
                        label: "Search",
                        "hide-details": "",
                        "single-line": ""
                      }, null, 8, ["modelValue"])
                    ]),
                    _: 1
                  })) : createCommentVNode("", true)
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          !allSelected.value ? (openBlock(), createBlock(_component_v_divider, { key: 0 })) : createCommentVNode("", true),
          createVNode(_component_v_list, null, {
            default: withCtx(() => [
              (openBlock(true), createElementBlock(Fragment, null, renderList(categories.value, (item) => {
                return openBlock(), createElementBlock(Fragment, null, [
                  !selected.value.includes(item) ? (openBlock(), createBlock(_component_v_list_item, {
                    key: item.text,
                    disabled: loading.value,
                    onClick: ($event) => selected.value.push(item)
                  }, {
                    prepend: withCtx(() => [
                      createVNode(_component_v_icon, {
                        disabled: loading.value,
                        icon: item.icon
                      }, null, 8, ["disabled", "icon"])
                    ]),
                    default: withCtx(() => [
                      createVNode(_component_v_list_item_title, {
                        textContent: toDisplayString(item.text)
                      }, null, 8, ["textContent"])
                    ]),
                    _: 2
                  }, 1032, ["disabled", "onClick"])) : createCommentVNode("", true)
                ], 64);
              }), 256))
            ]),
            _: 1
          }),
          createVNode(_component_v_divider),
          createVNode(_component_v_card_actions, null, {
            default: withCtx(() => [
              createVNode(_component_v_spacer),
              createVNode(_component_v_btn, {
                disabled: !selected.value.length,
                loading: loading.value,
                color: "purple",
                variant: "text",
                onClick: next
              }, {
                default: withCtx(() => [
                  createTextVNode(" Next ")
                ]),
                _: 1
              }, 8, ["disabled", "loading"])
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __1 = _sfc_main$d;
const __1_raw = `<template>
  <v-card
    class="mx-auto"
    max-width="500"
  >
    <v-toolbar
      color="transparent"
      flat
    >
      <v-app-bar-nav-icon></v-app-bar-nav-icon>

      <v-toolbar-title>Photo Info</v-toolbar-title>

      <v-spacer></v-spacer>

      <v-btn
        icon="mdi-magnify"
        @click="searchField.focus()"
      >
      </v-btn>
    </v-toolbar>

    <v-container>
      <v-row
        align="center"
        justify="start"
      >
        <v-col
          v-for="(selection, i) in selections"
          :key="selection.text"
          class="py-1 pe-0"
          cols="auto"
        >
          <v-chip
            :disabled="loading"
            closable
            @click:close="selected.splice(i, 1)"
          >
            <v-icon
              :icon="selection.icon"
              start
            ></v-icon>

            {{ selection.text }}
          </v-chip>
        </v-col>

        <v-col
          v-if="!allSelected"
          cols="12"
        >
          <v-text-field
            ref="searchField"
            v-model="search"
            label="Search"
            hide-details
            single-line
          ></v-text-field>
        </v-col>
      </v-row>
    </v-container>

    <v-divider v-if="!allSelected"></v-divider>

    <v-list>
      <template v-for="item in categories">
        <v-list-item
          v-if="!selected.includes(item)"
          :key="item.text"
          :disabled="loading"
          @click="selected.push(item)"
        >
          <template v-slot:prepend>
            <v-icon
              :disabled="loading"
              :icon="item.icon"
            ></v-icon>
          </template>

          <v-list-item-title v-text="item.text"></v-list-item-title>
        </v-list-item>
      </template>
    </v-list>

    <v-divider></v-divider>

    <v-card-actions>
      <v-spacer></v-spacer>

      <v-btn
        :disabled="!selected.length"
        :loading="loading"
        color="purple"
        variant="text"
        @click="next"
      >
        Next
      </v-btn>
    </v-card-actions>
  </v-card>
</template>

<script setup>
  import { computed, ref, watch } from 'vue'

  const items = [
    {
      text: 'Nature',
      icon: 'mdi-nature',
    },
    {
      text: 'Nightlife',
      icon: 'mdi-glass-wine',
    },
    {
      text: 'November',
      icon: 'mdi-calendar-range',
    },
    {
      text: 'Portland',
      icon: 'mdi-map-marker',
    },
    {
      text: 'Biking',
      icon: 'mdi-bike',
    },
  ]
  const searchField = ref()

  const loading = ref(false)
  const search = ref('')
  const selected = ref([])

  const allSelected = computed(() => {
    return selected.value.length === items.length
  })
  const categories = computed(() => {
    const _search = search.value.toLowerCase()
    if (!_search) return items
    return items.filter(item => {
      const text = item.text.toLowerCase()
      return text.indexOf(_search) > -1
    })
  })
  const selections = computed(() => {
    const selections = []
    for (const selection of selected.value) {
      selections.push(selection)
    }
    return selections
  })

  watch(selected, () => {
    search.value = ''
  })

  function next () {
    loading.value = true
    setTimeout(() => {
      search.value = ''
      selected.value = []
      loading.value = false
    }, 2000)
  }
<\/script>

<script>
  export default {
    data: () => ({
      items: [
        {
          text: 'Nature',
          icon: 'mdi-nature',
        },
        {
          text: 'Nightlife',
          icon: 'mdi-glass-wine',
        },
        {
          text: 'November',
          icon: 'mdi-calendar-range',
        },
        {
          text: 'Portland',
          icon: 'mdi-map-marker',
        },
        {
          text: 'Biking',
          icon: 'mdi-bike',
        },
      ],
      loading: false,
      search: '',
      selected: [],
    }),

    computed: {
      allSelected () {
        return this.selected.length === this.items.length
      },
      categories () {
        const search = this.search.toLowerCase()

        if (!search) return this.items

        return this.items.filter(item => {
          const text = item.text.toLowerCase()

          return text.indexOf(search) > -1
        })
      },
      selections () {
        const selections = []

        for (const selection of this.selected) {
          selections.push(selection)
        }

        return selections
      },
    },

    watch: {
      selected () {
        this.search = ''
      },
    },

    methods: {
      next () {
        this.loading = true

        setTimeout(() => {
          this.search = ''
          this.selected = []
          this.loading = false
        }, 2000)
      },
    },
  }
<\/script>
`;
const _hoisted_1$b = /* @__PURE__ */ createBaseVNode("span", { class: "me-4" }, "To", -1);
const _hoisted_2$3 = { class: "pa-3" };
const _sfc_main$c = {
  __name: "misc-expandable",
  setup(__props) {
    const menu = ref(false);
    return (_ctx, _cache) => {
      const _component_v_img = resolveComponent("v-img");
      const _component_v_avatar = resolveComponent("v-avatar");
      const _component_v_chip = resolveComponent("v-chip");
      const _component_v_list_item_title = resolveComponent("v-list-item-title");
      const _component_v_list_item_subtitle = resolveComponent("v-list-item-subtitle");
      const _component_v_icon = resolveComponent("v-icon");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_list_item_action = resolveComponent("v-list-item-action");
      const _component_v_list_item = resolveComponent("v-list-item");
      const _component_v_list = resolveComponent("v-list");
      const _component_v_card = resolveComponent("v-card");
      const _component_v_menu = resolveComponent("v-menu");
      const _component_v_row = resolveComponent("v-row");
      const _component_v_divider = resolveComponent("v-divider");
      const _component_v_text_field = resolveComponent("v-text-field");
      const _component_v_textarea = resolveComponent("v-textarea");
      return openBlock(), createBlock(_component_v_card, {
        class: "mx-auto",
        "max-width": "400"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_row, {
            align: "center",
            class: "pa-6"
          }, {
            default: withCtx(() => [
              _hoisted_1$b,
              createVNode(_component_v_menu, {
                modelValue: menu.value,
                "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => menu.value = $event),
                location: "top start",
                origin: "top start",
                transition: "scale-transition"
              }, {
                activator: withCtx(({ props }) => [
                  createVNode(_component_v_chip, mergeProps(props, {
                    link: "",
                    pill: ""
                  }), {
                    default: withCtx(() => [
                      createVNode(_component_v_avatar, { start: "" }, {
                        default: withCtx(() => [
                          createVNode(_component_v_img, { src: "https://cdn.vuetifyjs.com/images/john.png" })
                        ]),
                        _: 1
                      }),
                      createTextVNode(" John Leider ")
                    ]),
                    _: 2
                  }, 1040)
                ]),
                default: withCtx(() => [
                  createVNode(_component_v_card, { width: "300" }, {
                    default: withCtx(() => [
                      createVNode(_component_v_list, { "bg-color": "black" }, {
                        default: withCtx(() => [
                          createVNode(_component_v_list_item, null, {
                            prepend: withCtx(() => [
                              createVNode(_component_v_avatar, { image: "https://cdn.vuetifyjs.com/images/john.png" })
                            ]),
                            append: withCtx(() => [
                              createVNode(_component_v_list_item_action, null, {
                                default: withCtx(() => [
                                  createVNode(_component_v_btn, {
                                    variant: "text",
                                    icon: "",
                                    onClick: _cache[0] || (_cache[0] = ($event) => menu.value = false)
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_v_icon, null, {
                                        default: withCtx(() => [
                                          createTextVNode("mdi-close-circle")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            default: withCtx(() => [
                              createVNode(_component_v_list_item_title, null, {
                                default: withCtx(() => [
                                  createTextVNode("John Leider")
                                ]),
                                _: 1
                              }),
                              createVNode(_component_v_list_item_subtitle, null, {
                                default: withCtx(() => [
                                  createTextVNode("john@google.com")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_v_list, null, {
                        default: withCtx(() => [
                          createVNode(_component_v_list_item, {
                            "prepend-icon": "mdi-briefcase",
                            link: ""
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_v_list_item_subtitle, null, {
                                default: withCtx(() => [
                                  createTextVNode("john@gmail.com")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }, 8, ["modelValue"])
            ]),
            _: 1
          }),
          createVNode(_component_v_divider),
          createBaseVNode("div", _hoisted_2$3, [
            createVNode(_component_v_text_field, {
              label: "Subject",
              "model-value": "Re: Vacation Request",
              variant: "underlined",
              "single-line": ""
            }),
            createVNode(_component_v_textarea, {
              label: "Message",
              variant: "underlined",
              "single-line": ""
            })
          ])
        ]),
        _: 1
      });
    };
  }
};
const __2 = _sfc_main$c;
const __2_raw = `<template>
  <v-card
    class="mx-auto"
    max-width="400"
  >
    <v-row
      align="center"
      class="pa-6"
    >
      <span class="me-4">To</span>

      <v-menu
        v-model="menu"
        location="top start"
        origin="top start"
        transition="scale-transition"
      >
        <template v-slot:activator="{ props }">
          <v-chip
            v-bind="props"
            link
            pill
          >
            <v-avatar start>
              <v-img src="https://cdn.vuetifyjs.com/images/john.png"></v-img>
            </v-avatar>

            John Leider
          </v-chip>
        </template>

        <v-card width="300">
          <v-list bg-color="black">
            <v-list-item>
              <template v-slot:prepend>
                <v-avatar image="https://cdn.vuetifyjs.com/images/john.png"></v-avatar>
              </template>

              <v-list-item-title>John Leider</v-list-item-title>

              <v-list-item-subtitle>john@google.com</v-list-item-subtitle>

              <template v-slot:append>
                <v-list-item-action>
                  <v-btn
                    variant="text"
                    icon
                    @click="menu = false"
                  >
                    <v-icon>mdi-close-circle</v-icon>
                  </v-btn>
                </v-list-item-action>
              </template>
            </v-list-item>
          </v-list>

          <v-list>
            <v-list-item prepend-icon="mdi-briefcase" link>
              <v-list-item-subtitle>john@gmail.com</v-list-item-subtitle>
            </v-list-item>
          </v-list>
        </v-card>
      </v-menu>
    </v-row>

    <v-divider></v-divider>

    <div class="pa-3">
      <v-text-field
        label="Subject"
        model-value="Re: Vacation Request"
        variant="underlined"
        single-line
      ></v-text-field>

      <v-textarea
        label="Message"
        variant="underlined"
        single-line
      ></v-textarea>
    </div>
  </v-card>
</template>

<script setup>
  import { ref } from 'vue'

  const menu = ref(false)
<\/script>

<script>
  export default {
    data: () => ({
      menu: false,
    }),
  }
<\/script>
`;
const _hoisted_1$a = {
  key: 0,
  class: "py-3 px-4"
};
const _hoisted_2$2 = ["textContent"];
const _sfc_main$b = {
  __name: "misc-filtering",
  setup(__props) {
    const items = [
      {
        image: "https://cdn.vuetifyjs.com/docs/images/chips/globe.png",
        title: "TBI’s 5 Best: SF Mocktails to Finish Dry January Strong",
        category: "Travel",
        keyword: "Drinks"
      },
      {
        image: "https://cdn.vuetifyjs.com/docs/images/chips/cpu.png",
        title: "PWAs on iOS 12.2 beta: the good, the bad, and the “not sure yet if good”",
        category: "Technology",
        keyword: "Phones"
      },
      {
        image: "https://cdn.vuetifyjs.com/docs/images/chips/rocket.png",
        title: "How to Get Media Mentions for Your Business",
        category: "Media",
        keyword: "Social"
      },
      {
        image: "https://cdn.vuetifyjs.com/docs/images/chips/bulb.png",
        title: "The Pitfalls Of Outsourcing Self-Awareness To Artificial Intelligence",
        category: "Technology",
        keyword: "Military"
      },
      {
        image: "https://cdn.vuetifyjs.com/docs/images/chips/raft.png",
        title: "Degrees of Freedom and Sudoko",
        category: "Travel",
        keyword: "Social"
      }
    ];
    const search = ref("");
    const keywords = computed(() => {
      if (!search.value)
        return [];
      const keywords2 = [];
      for (const search2 of searching.value) {
        keywords2.push(search2.keyword);
      }
      return keywords2;
    });
    const searching = computed(() => {
      if (!search.value)
        return items;
      const _search = search.value.toLowerCase();
      return items.filter((item) => {
        const text = item.title.toLowerCase();
        return text.indexOf(_search) > -1;
      });
    });
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_text_field = resolveComponent("v-text-field");
      const _component_v_toolbar = resolveComponent("v-toolbar");
      const _component_v_chip = resolveComponent("v-chip");
      const _component_v_divider = resolveComponent("v-divider");
      const _component_v_img = resolveComponent("v-img");
      const _component_v_avatar = resolveComponent("v-avatar");
      const _component_v_list_item_title = resolveComponent("v-list-item-title");
      const _component_v_list_item = resolveComponent("v-list-item");
      const _component_v_list = resolveComponent("v-list");
      const _component_v_card = resolveComponent("v-card");
      return openBlock(), createBlock(_component_v_card, {
        class: "mx-auto",
        "max-width": "450"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_toolbar, {
            color: "primary",
            height: "88",
            flat: ""
          }, {
            prepend: withCtx(() => [
              createVNode(_component_v_btn, { icon: "mdi-arrow-left" })
            ]),
            append: withCtx(() => [
              createVNode(_component_v_btn, { icon: "mdi-dots-vertical" })
            ]),
            default: withCtx(() => [
              createVNode(_component_v_text_field, {
                modelValue: search.value,
                "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => search.value = $event),
                label: "Search News",
                "prepend-inner-icon": "mdi-magnify",
                clearable: "",
                "hide-details": "",
                "single-line": ""
              }, null, 8, ["modelValue"])
            ]),
            _: 1
          }),
          keywords.value.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_1$a, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(keywords.value, (keyword, i) => {
              return openBlock(), createBlock(_component_v_chip, {
                key: i,
                class: "me-2"
              }, {
                default: withCtx(() => [
                  createTextVNode(toDisplayString(keyword), 1)
                ]),
                _: 2
              }, 1024);
            }), 128))
          ])) : createCommentVNode("", true),
          createVNode(_component_v_divider),
          createVNode(_component_v_list, { lines: "three" }, {
            default: withCtx(() => [
              (openBlock(true), createElementBlock(Fragment, null, renderList(searching.value, (item, i) => {
                return openBlock(), createBlock(_component_v_list_item, {
                  key: i,
                  link: ""
                }, {
                  prepend: withCtx(() => [
                    createVNode(_component_v_avatar, {
                      class: "me-4 mt-2",
                      rounded: "0"
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_v_img, {
                          src: item.image,
                          cover: ""
                        }, null, 8, ["src"])
                      ]),
                      _: 2
                    }, 1024)
                  ]),
                  default: withCtx(() => [
                    createVNode(_component_v_list_item_title, {
                      class: "text-uppercase font-weight-regular text-caption",
                      textContent: toDisplayString(item.category)
                    }, null, 8, ["textContent"]),
                    createBaseVNode("div", {
                      textContent: toDisplayString(item.title)
                    }, null, 8, _hoisted_2$2)
                  ]),
                  _: 2
                }, 1024);
              }), 128))
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __3 = _sfc_main$b;
const __3_raw = `<template>
  <v-card
    class="mx-auto"
    max-width="450"
  >
    <v-toolbar
      color="primary"
      height="88"
      flat
    >
      <template v-slot:prepend>
        <v-btn icon="mdi-arrow-left">
        </v-btn>
      </template>

      <v-text-field
        v-model="search"
        label="Search News"
        prepend-inner-icon="mdi-magnify"
        clearable
        hide-details
        single-line
      ></v-text-field>

      <template v-slot:append>
        <v-btn icon="mdi-dots-vertical"></v-btn>
      </template>
    </v-toolbar>

    <div v-if="keywords.length > 0" class="py-3 px-4">
      <v-chip
        v-for="(keyword, i) in keywords"
        :key="i"
        class="me-2"
      >
        {{ keyword }}
      </v-chip>

    </div>

    <v-divider></v-divider>

    <v-list lines="three">
      <v-list-item
        v-for="(item, i) in searching"
        :key="i"
        link
      >
        <template v-slot:prepend>
          <v-avatar
            class="me-4 mt-2"
            rounded="0"
          >
            <v-img :src="item.image" cover></v-img>
          </v-avatar>
        </template>

        <v-list-item-title
          class="text-uppercase font-weight-regular text-caption"
          v-text="item.category"
        ></v-list-item-title>

        <div v-text="item.title"></div>
      </v-list-item>
    </v-list>
  </v-card>
</template>

<script setup>
  import { computed, ref } from 'vue'

  const items = [
    {
      image: 'https://cdn.vuetifyjs.com/docs/images/chips/globe.png',
      title: 'TBI\\u2019s 5 Best: SF Mocktails to Finish Dry January Strong',
      category: 'Travel',
      keyword: 'Drinks',
    },
    {
      image: 'https://cdn.vuetifyjs.com/docs/images/chips/cpu.png',
      title: 'PWAs on iOS 12.2 beta: the good, the bad, and the \\u201Cnot sure yet if good\\u201D',
      category: 'Technology',
      keyword: 'Phones',
    },
    {
      image: 'https://cdn.vuetifyjs.com/docs/images/chips/rocket.png',
      title: 'How to Get Media Mentions for Your Business',
      category: 'Media',
      keyword: 'Social',
    },
    {
      image: 'https://cdn.vuetifyjs.com/docs/images/chips/bulb.png',
      title: 'The Pitfalls Of Outsourcing Self-Awareness To Artificial Intelligence',
      category: 'Technology',
      keyword: 'Military',
    },
    {
      image: 'https://cdn.vuetifyjs.com/docs/images/chips/raft.png',
      title: 'Degrees of Freedom and Sudoko',
      category: 'Travel',
      keyword: 'Social',
    },
  ]

  const search = ref('')

  const keywords = computed(() => {
    if (!search.value) return []

    const keywords = []

    for (const search of searching.value) {
      keywords.push(search.keyword)
    }

    return keywords
  })
  const searching = computed(() => {
    if (!search.value) return items

    const _search = search.value.toLowerCase()

    return items.filter(item => {
      const text = item.title.toLowerCase()
      return text.indexOf(_search) > -1
    })
  })
<\/script>

<script>
  export default {
    data: () => ({
      items: [
        {
          image: 'https://cdn.vuetifyjs.com/docs/images/chips/globe.png',
          title: 'TBI’s 5 Best: SF Mocktails to Finish Dry January Strong',
          category: 'Travel',
          keyword: 'Drinks',

        },
        {
          image: 'https://cdn.vuetifyjs.com/docs/images/chips/cpu.png',
          title: 'PWAs on iOS 12.2 beta: the good, the bad, and the “not sure yet if good”',
          category: 'Technology',
          keyword: 'Phones',
        },
        {
          image: 'https://cdn.vuetifyjs.com/docs/images/chips/rocket.png',
          title: 'How to Get Media Mentions for Your Business',
          category: 'Media',
          keyword: 'Social',
        },
        {
          image: 'https://cdn.vuetifyjs.com/docs/images/chips/bulb.png',
          title: 'The Pitfalls Of Outsourcing Self-Awareness To Artificial Intelligence',
          category: 'Technology',
          keyword: 'Military',
        },
        {
          image: 'https://cdn.vuetifyjs.com/docs/images/chips/raft.png',
          title: 'Degrees of Freedom and Sudoko',
          category: 'Travel',
          keyword: 'Social',
        },
      ],
      search: '',
    }),

    computed: {
      keywords () {
        if (!this.search) return []

        const keywords = []

        for (const search of this.searching) {
          keywords.push(search.keyword)
        }

        return keywords
      },
      searching () {
        if (!this.search) return this.items

        const search = this.search.toLowerCase()

        return this.items.filter(item => {
          const text = item.title.toLowerCase()

          return text.indexOf(search) > -1
        })
      },
    },
  }
<\/script>
`;
const _hoisted_1$9 = /* @__PURE__ */ createBaseVNode("span", null, "(interest)", -1);
const _sfc_main$a = {
  __name: "misc-in-selects",
  setup(__props) {
    const items = ["Streaming", "Eating"];
    const chips = ref(["Programming", "Playing video games", "Watching movies", "Sleeping"]);
    function remove(item) {
      chips.value.splice(chips.value.indexOf(item), 1);
    }
    return (_ctx, _cache) => {
      const _component_v_chip = resolveComponent("v-chip");
      const _component_v_combobox = resolveComponent("v-combobox");
      return openBlock(), createBlock(_component_v_combobox, {
        modelValue: chips.value,
        "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => chips.value = $event),
        items,
        label: "Your favorite hobbies",
        "prepend-icon": "mdi-filter-variant",
        variant: "solo",
        chips: "",
        clearable: "",
        multiple: ""
      }, {
        selection: withCtx(({ attrs, item, select, selected }) => [
          createVNode(_component_v_chip, mergeProps(attrs, {
            "model-value": selected,
            closable: "",
            onClick: select,
            "onClick:close": ($event) => remove(item)
          }), {
            default: withCtx(() => [
              createBaseVNode("strong", null, toDisplayString(item), 1),
              createTextVNode("  "),
              _hoisted_1$9
            ]),
            _: 2
          }, 1040, ["model-value", "onClick", "onClick:close"])
        ]),
        _: 1
      }, 8, ["modelValue"]);
    };
  }
};
const __4 = _sfc_main$a;
const __4_raw = `<template>
  <v-combobox
    v-model="chips"
    :items="items"
    label="Your favorite hobbies"
    prepend-icon="mdi-filter-variant"
    variant="solo"
    chips
    clearable
    multiple
  >
    <template v-slot:selection="{ attrs, item, select, selected }">
      <v-chip
        v-bind="attrs"
        :model-value="selected"
        closable
        @click="select"
        @click:close="remove(item)"
      >
        <strong>{{ item }}</strong>&nbsp;
        <span>(interest)</span>
      </v-chip>
    </template>
  </v-combobox>
</template>

<script setup>
  import { ref } from 'vue'

  const items = ['Streaming', 'Eating']

  const chips = ref(['Programming', 'Playing video games', 'Watching movies', 'Sleeping'])

  function remove (item) {
    chips.value.splice(chips.value.indexOf(item), 1)
  }
<\/script>

<script>
  export default {
    data () {
      return {
        chips: ['Programming', 'Playing video games', 'Watching movies', 'Sleeping'],
        items: ['Streaming', 'Eating'],
      }
    },

    methods: {
      remove (item) {
        this.chips.splice(this.chips.indexOf(item), 1)
      },
    },
  }
<\/script>
`;
const _hoisted_1$8 = { class: "text-center" };
const _sfc_main$9 = {
  __name: "prop-closable",
  setup(__props) {
    const chip = ref(true);
    return (_ctx, _cache) => {
      const _component_v_chip = resolveComponent("v-chip");
      const _component_v_btn = resolveComponent("v-btn");
      return openBlock(), createElementBlock("div", _hoisted_1$8, [
        chip.value ? (openBlock(), createBlock(_component_v_chip, {
          key: 0,
          class: "ma-2",
          closable: "",
          "onClick:close": _cache[0] || (_cache[0] = ($event) => chip.value = false)
        }, {
          default: withCtx(() => [
            createTextVNode(" Closable ")
          ]),
          _: 1
        })) : createCommentVNode("", true),
        !chip.value ? (openBlock(), createBlock(_component_v_btn, {
          key: 1,
          color: "primary",
          close: "",
          dark: "",
          onClick: _cache[1] || (_cache[1] = ($event) => chip.value = true)
        }, {
          default: withCtx(() => [
            createTextVNode(" Reset Chip ")
          ]),
          _: 1
        })) : createCommentVNode("", true)
      ]);
    };
  }
};
const __5 = _sfc_main$9;
const __5_raw = `<template>
  <div class="text-center">
    <v-chip
      v-if="chip"
      class="ma-2"
      closable
      @click:close="chip = false"
    >
      Closable
    </v-chip>

    <v-btn
      v-if="!chip"
      color="primary"
      close
      dark
      @click="chip = true"
    >
      Reset Chip
    </v-btn>
  </div>
</template>

<script setup>
  import { ref } from 'vue'

  const chip = ref(true)
<\/script>

<script>
  export default {
    data () {
      return {
        chip: true,
      }
    },
  }
<\/script>
`;
const _sfc_main$8 = {};
const _hoisted_1$7 = { class: "d-flex justify-center ga-2" };
const _hoisted_2$1 = { class: "d-flex justify-center ga-2 mt-2" };
function _sfc_render$6(_ctx, _cache) {
  const _component_v_chip = resolveComponent("v-chip");
  return openBlock(), createElementBlock(Fragment, null, [
    createBaseVNode("div", _hoisted_1$7, [
      createVNode(_component_v_chip, null, {
        default: withCtx(() => [
          createTextVNode(" Default ")
        ]),
        _: 1
      }),
      createVNode(_component_v_chip, { color: "primary" }, {
        default: withCtx(() => [
          createTextVNode(" Primary ")
        ]),
        _: 1
      }),
      createVNode(_component_v_chip, { color: "secondary" }, {
        default: withCtx(() => [
          createTextVNode(" Secondary ")
        ]),
        _: 1
      }),
      createVNode(_component_v_chip, { color: "red" }, {
        default: withCtx(() => [
          createTextVNode(" Red ")
        ]),
        _: 1
      }),
      createVNode(_component_v_chip, { color: "green" }, {
        default: withCtx(() => [
          createTextVNode(" Green ")
        ]),
        _: 1
      })
    ]),
    createBaseVNode("div", _hoisted_2$1, [
      createVNode(_component_v_chip, { variant: "flat" }, {
        default: withCtx(() => [
          createTextVNode(" Default flat ")
        ]),
        _: 1
      }),
      createVNode(_component_v_chip, {
        color: "primary",
        variant: "flat"
      }, {
        default: withCtx(() => [
          createTextVNode(" Primary flat ")
        ]),
        _: 1
      }),
      createVNode(_component_v_chip, {
        color: "secondary",
        variant: "flat"
      }, {
        default: withCtx(() => [
          createTextVNode(" Secondary flat ")
        ]),
        _: 1
      }),
      createVNode(_component_v_chip, {
        color: "red",
        variant: "flat"
      }, {
        default: withCtx(() => [
          createTextVNode(" Red flat ")
        ]),
        _: 1
      }),
      createVNode(_component_v_chip, {
        color: "green",
        variant: "flat"
      }, {
        default: withCtx(() => [
          createTextVNode(" Green flat ")
        ]),
        _: 1
      })
    ])
  ], 64);
}
const __6 = /* @__PURE__ */ _export_sfc(_sfc_main$8, [["render", _sfc_render$6]]);
const __6_raw = '<template>\n  <div class="d-flex justify-center ga-2">\n    <v-chip>\n      Default\n    </v-chip>\n\n    <v-chip color="primary">\n      Primary\n    </v-chip>\n\n    <v-chip color="secondary">\n      Secondary\n    </v-chip>\n\n    <v-chip color="red">\n      Red\n    </v-chip>\n\n    <v-chip color="green">\n      Green\n    </v-chip>\n  </div>\n  <div class="d-flex justify-center ga-2 mt-2">\n    <v-chip variant="flat">\n      Default flat\n    </v-chip>\n\n    <v-chip color="primary" variant="flat">\n      Primary flat\n    </v-chip>\n\n    <v-chip color="secondary" variant="flat">\n      Secondary flat\n    </v-chip>\n\n    <v-chip color="red" variant="flat">\n      Red flat\n    </v-chip>\n\n    <v-chip color="green" variant="flat">\n      Green flat\n    </v-chip>\n  </div>\n</template>\n<script setup lang="ts">\n<\/script>\n';
const _sfc_main$7 = {};
const _hoisted_1$6 = { class: "text-center" };
function _sfc_render$5(_ctx, _cache) {
  const _component_v_chip = resolveComponent("v-chip");
  return openBlock(), createElementBlock("div", _hoisted_1$6, [
    createVNode(_component_v_chip, { draggable: "" }, {
      default: withCtx(() => [
        createTextVNode(" Default ")
      ]),
      _: 1
    })
  ]);
}
const __7 = /* @__PURE__ */ _export_sfc(_sfc_main$7, [["render", _sfc_render$5]]);
const __7_raw = '<template>\n  <div class="text-center">\n    <v-chip draggable>\n      Default\n    </v-chip>\n  </div>\n</template>\n';
const _sfc_main$6 = {
  __name: "prop-filter",
  setup(__props) {
    const active = ref(false);
    return (_ctx, _cache) => {
      const _component_v_chip = resolveComponent("v-chip");
      const _component_v_switch = resolveComponent("v-switch");
      const _component_v_row = resolveComponent("v-row");
      return openBlock(), createBlock(_component_v_row, {
        align: "center",
        justify: "space-around"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_chip, {
            "model-value": active.value,
            class: "ma-2",
            filter: ""
          }, {
            default: withCtx(() => [
              createTextVNode(" I'm v-chip ")
            ]),
            _: 1
          }, 8, ["model-value"]),
          createVNode(_component_v_chip, {
            "model-value": active.value,
            class: "ma-2",
            "filter-icon": "mdi-plus",
            filter: ""
          }, {
            default: withCtx(() => [
              createTextVNode(" I'm v-chip ")
            ]),
            _: 1
          }, 8, ["model-value"]),
          createVNode(_component_v_chip, {
            "model-value": active.value,
            class: "ma-2",
            "filter-icon": "mdi-minus",
            filter: ""
          }, {
            default: withCtx(() => [
              createTextVNode(" I'm v-chip ")
            ]),
            _: 1
          }, 8, ["model-value"]),
          createVNode(_component_v_switch, {
            modelValue: active.value,
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => active.value = $event),
            label: "Active"
          }, null, 8, ["modelValue"])
        ]),
        _: 1
      });
    };
  }
};
const __8 = _sfc_main$6;
const __8_raw = `<template>
  <v-row
    align="center"
    justify="space-around"
  >
    <v-chip
      :model-value="active"
      class="ma-2"
      filter
    >
      I'm v-chip
    </v-chip>

    <v-chip
      :model-value="active"
      class="ma-2"
      filter-icon="mdi-plus"
      filter
    >
      I'm v-chip
    </v-chip>

    <v-chip
      :model-value="active"
      class="ma-2"
      filter-icon="mdi-minus"
      filter
    >
      I'm v-chip
    </v-chip>

    <v-switch
      v-model="active"
      label="Active"
    ></v-switch>
  </v-row>
</template>

<script setup>
  import { ref } from 'vue'

  const active = ref(false)
<\/script>

<script>
  export default {
    data: () => ({
      active: false,
    }),
  }
<\/script>
`;
const _sfc_main$5 = {};
const _hoisted_1$5 = { class: "text-center" };
function _sfc_render$4(_ctx, _cache) {
  const _component_v_chip = resolveComponent("v-chip");
  const _component_v_icon = resolveComponent("v-icon");
  return openBlock(), createElementBlock("div", _hoisted_1$5, [
    createVNode(_component_v_chip, {
      class: "ma-2",
      label: ""
    }, {
      default: withCtx(() => [
        createTextVNode(" Label ")
      ]),
      _: 1
    }),
    createVNode(_component_v_chip, {
      class: "ma-2",
      color: "pink",
      label: ""
    }, {
      default: withCtx(() => [
        createVNode(_component_v_icon, {
          icon: "mdi-label",
          start: ""
        }),
        createTextVNode(" Tags ")
      ]),
      _: 1
    }),
    createVNode(_component_v_chip, {
      class: "ma-2",
      color: "primary",
      label: ""
    }, {
      default: withCtx(() => [
        createVNode(_component_v_icon, {
          icon: "mdi-account-circle-outline",
          start: ""
        }),
        createTextVNode(" John Leider ")
      ]),
      _: 1
    }),
    createVNode(_component_v_chip, {
      class: "ma-2",
      color: "cyan",
      closable: "",
      label: ""
    }, {
      default: withCtx(() => [
        createVNode(_component_v_icon, {
          icon: "mdi-twitter",
          start: ""
        }),
        createTextVNode(" New Tweets ")
      ]),
      _: 1
    })
  ]);
}
const __9 = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["render", _sfc_render$4]]);
const __9_raw = '<template>\n  <div class="text-center">\n    <v-chip\n      class="ma-2"\n      label\n    >\n      Label\n    </v-chip>\n\n    <v-chip\n      class="ma-2"\n      color="pink"\n      label\n    >\n      <v-icon icon="mdi-label" start></v-icon>\n      Tags\n    </v-chip>\n\n    <v-chip\n      class="ma-2"\n      color="primary"\n      label\n    >\n      <v-icon icon="mdi-account-circle-outline" start></v-icon>\n      John Leider\n    </v-chip>\n\n    <v-chip\n      class="ma-2"\n      color="cyan"\n      closable\n      label\n    >\n      <v-icon icon="mdi-twitter" start></v-icon>\n      New Tweets\n    </v-chip>\n  </div>\n</template>\n';
const _sfc_main$4 = {};
const _hoisted_1$4 = { class: "text-center" };
function _sfc_render$3(_ctx, _cache) {
  const _component_v_chip = resolveComponent("v-chip");
  return openBlock(), createElementBlock("div", _hoisted_1$4, [
    createVNode(_component_v_chip, {
      ripple: false,
      link: ""
    }, {
      default: withCtx(() => [
        createTextVNode(" Default ")
      ]),
      _: 1
    })
  ]);
}
const __10 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["render", _sfc_render$3]]);
const __10_raw = '<template>\n  <div class="text-center">\n    <v-chip :ripple="false" link>\n      Default\n    </v-chip>\n  </div>\n</template>\n';
const _sfc_main$3 = {};
const _hoisted_1$3 = { class: "text-center" };
function _sfc_render$2(_ctx, _cache) {
  const _component_v_icon = resolveComponent("v-icon");
  const _component_v_chip = resolveComponent("v-chip");
  return openBlock(), createElementBlock("div", _hoisted_1$3, [
    createVNode(_component_v_chip, {
      class: "ma-2",
      color: "success",
      variant: "outlined"
    }, {
      default: withCtx(() => [
        createVNode(_component_v_icon, {
          icon: "mdi-server-plus",
          start: ""
        }),
        createTextVNode(" Server Status ")
      ]),
      _: 1
    }),
    createVNode(_component_v_chip, {
      class: "ma-2",
      color: "primary",
      variant: "outlined"
    }, {
      default: withCtx(() => [
        createTextVNode(" User Account "),
        createVNode(_component_v_icon, {
          icon: "mdi-account-outline",
          end: ""
        })
      ]),
      _: 1
    })
  ]);
}
const __11 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["render", _sfc_render$2]]);
const __11_raw = '<template>\n  <div class="text-center">\n    <v-chip\n      class="ma-2"\n      color="success"\n      variant="outlined"\n    >\n      <v-icon icon="mdi-server-plus" start></v-icon>\n      Server Status\n    </v-chip>\n\n    <v-chip\n      class="ma-2"\n      color="primary"\n      variant="outlined"\n    >\n      User Account\n      <v-icon icon="mdi-account-outline" end></v-icon>\n    </v-chip>\n  </div>\n</template>\n';
const _sfc_main$2 = {};
const _hoisted_1$2 = { class: "d-flex justify-center align-center ga-2" };
const _hoisted_2 = { class: "d-flex justify-center align-center ga-2 mt-2" };
const _hoisted_3 = { class: "d-flex justify-center align-center ga-2 mt-2" };
function _sfc_render$1(_ctx, _cache) {
  const _component_v_label = resolveComponent("v-label");
  const _component_v_chip = resolveComponent("v-chip");
  return openBlock(), createElementBlock(Fragment, null, [
    createBaseVNode("div", _hoisted_1$2, [
      createVNode(_component_v_label, { style: { "width": "100px" } }, {
        default: withCtx(() => [
          createTextVNode("default")
        ]),
        _: 1
      }),
      createVNode(_component_v_chip, { size: "x-small" }, {
        default: withCtx(() => [
          createTextVNode(" x-small ")
        ]),
        _: 1
      }),
      createVNode(_component_v_chip, { size: "small" }, {
        default: withCtx(() => [
          createTextVNode(" small ")
        ]),
        _: 1
      }),
      createVNode(_component_v_chip, null, {
        default: withCtx(() => [
          createTextVNode(" default ")
        ]),
        _: 1
      }),
      createVNode(_component_v_chip, { size: "large" }, {
        default: withCtx(() => [
          createTextVNode(" large ")
        ]),
        _: 1
      }),
      createVNode(_component_v_chip, { size: "x-large" }, {
        default: withCtx(() => [
          createTextVNode(" x-large ")
        ]),
        _: 1
      })
    ]),
    createBaseVNode("div", _hoisted_2, [
      createVNode(_component_v_label, { style: { "width": "100px" } }, {
        default: withCtx(() => [
          createTextVNode("comfortable")
        ]),
        _: 1
      }),
      createVNode(_component_v_chip, {
        density: "comfortable",
        size: "x-small"
      }, {
        default: withCtx(() => [
          createTextVNode(" x-small ")
        ]),
        _: 1
      }),
      createVNode(_component_v_chip, {
        density: "comfortable",
        size: "small"
      }, {
        default: withCtx(() => [
          createTextVNode(" small ")
        ]),
        _: 1
      }),
      createVNode(_component_v_chip, { density: "comfortable" }, {
        default: withCtx(() => [
          createTextVNode(" default ")
        ]),
        _: 1
      }),
      createVNode(_component_v_chip, {
        density: "comfortable",
        size: "large"
      }, {
        default: withCtx(() => [
          createTextVNode(" large ")
        ]),
        _: 1
      }),
      createVNode(_component_v_chip, {
        density: "comfortable",
        size: "x-large"
      }, {
        default: withCtx(() => [
          createTextVNode(" x-large ")
        ]),
        _: 1
      })
    ]),
    createBaseVNode("div", _hoisted_3, [
      createVNode(_component_v_label, { style: { "width": "100px" } }, {
        default: withCtx(() => [
          createTextVNode("compact")
        ]),
        _: 1
      }),
      createVNode(_component_v_chip, {
        density: "compact",
        size: "x-small"
      }, {
        default: withCtx(() => [
          createTextVNode(" x-small ")
        ]),
        _: 1
      }),
      createVNode(_component_v_chip, {
        density: "compact",
        size: "small"
      }, {
        default: withCtx(() => [
          createTextVNode(" small ")
        ]),
        _: 1
      }),
      createVNode(_component_v_chip, { density: "compact" }, {
        default: withCtx(() => [
          createTextVNode(" default ")
        ]),
        _: 1
      }),
      createVNode(_component_v_chip, {
        density: "compact",
        size: "large"
      }, {
        default: withCtx(() => [
          createTextVNode(" large ")
        ]),
        _: 1
      }),
      createVNode(_component_v_chip, {
        density: "compact",
        size: "x-large"
      }, {
        default: withCtx(() => [
          createTextVNode(" x-large ")
        ]),
        _: 1
      })
    ])
  ], 64);
}
const __12 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["render", _sfc_render$1]]);
const __12_raw = '<template>\n  <div class="d-flex justify-center align-center ga-2">\n    <v-label style="width: 100px">default</v-label>\n\n    <v-chip size="x-small">\n      x-small\n    </v-chip>\n\n    <v-chip size="small">\n      small\n    </v-chip>\n\n    <v-chip>\n      default\n    </v-chip>\n\n    <v-chip size="large">\n      large\n    </v-chip>\n\n    <v-chip size="x-large">\n      x-large\n    </v-chip>\n  </div>\n  <div class="d-flex justify-center align-center ga-2 mt-2">\n    <v-label style="width: 100px">comfortable</v-label>\n\n    <v-chip density="comfortable" size="x-small">\n      x-small\n    </v-chip>\n\n    <v-chip density="comfortable" size="small">\n      small\n    </v-chip>\n\n    <v-chip density="comfortable">\n      default\n    </v-chip>\n\n    <v-chip density="comfortable" size="large">\n      large\n    </v-chip>\n\n    <v-chip density="comfortable" size="x-large">\n      x-large\n    </v-chip>\n  </div>\n  <div class="d-flex justify-center align-center ga-2 mt-2">\n    <v-label style="width: 100px">compact</v-label>\n\n    <v-chip density="compact" size="x-small">\n      x-small\n    </v-chip>\n\n    <v-chip density="compact" size="small">\n      small\n    </v-chip>\n\n    <v-chip density="compact">\n      default\n    </v-chip>\n\n    <v-chip density="compact" size="large">\n      large\n    </v-chip>\n\n    <v-chip density="compact" size="x-large">\n      x-large\n    </v-chip>\n  </div>\n</template>\n<script setup lang="ts">\n<\/script>\n';
const _sfc_main$1 = {};
const _hoisted_1$1 = { class: "text-center" };
function _sfc_render(_ctx, _cache) {
  const _component_v_chip = resolveComponent("v-chip");
  const _component_v_avatar = resolveComponent("v-avatar");
  return openBlock(), createElementBlock("div", _hoisted_1$1, [
    createVNode(_component_v_chip, {
      class: "ma-2",
      color: "indigo",
      "prepend-icon": "mdi-account-circle"
    }, {
      default: withCtx(() => [
        createTextVNode(" Mike ")
      ]),
      _: 1
    }),
    createVNode(_component_v_chip, {
      "append-icon": "mdi-star",
      class: "ma-2",
      color: "orange"
    }, {
      default: withCtx(() => [
        createTextVNode(" Premium ")
      ]),
      _: 1
    }),
    createVNode(_component_v_chip, {
      "append-icon": "mdi-cake-variant",
      class: "ma-2",
      color: "primary"
    }, {
      default: withCtx(() => [
        createTextVNode(" 1 Year ")
      ]),
      _: 1
    }),
    createVNode(_component_v_chip, {
      class: "ma-2",
      color: "green"
    }, {
      prepend: withCtx(() => [
        createVNode(_component_v_avatar, { class: "green-darken-4" }, {
          default: withCtx(() => [
            createTextVNode(" 1 ")
          ]),
          _: 1
        })
      ]),
      default: withCtx(() => [
        createTextVNode(" Years ")
      ]),
      _: 1
    }),
    createVNode(_component_v_chip, {
      "model-value": true,
      class: "ma-2",
      color: "teal",
      "prepend-icon": "mdi-checkbox-marked-circle",
      closable: ""
    }, {
      default: withCtx(() => [
        createTextVNode(" Confirmed ")
      ]),
      _: 1
    }),
    createVNode(_component_v_chip, {
      "model-value": true,
      class: "ma-2",
      "close-icon": "mdi-delete",
      color: "teal",
      "prepend-icon": "mdi-checkbox-marked-circle",
      closable: ""
    }, {
      default: withCtx(() => [
        createTextVNode(" Confirmed ")
      ]),
      _: 1
    })
  ]);
}
const __13 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["render", _sfc_render]]);
const __13_raw = '<template>\n  <div class="text-center">\n    <v-chip\n      class="ma-2"\n      color="indigo"\n      prepend-icon="mdi-account-circle"\n    >\n      Mike\n    </v-chip>\n\n    <v-chip\n      append-icon="mdi-star"\n      class="ma-2"\n      color="orange"\n    >\n      Premium\n    </v-chip>\n\n    <v-chip\n      append-icon="mdi-cake-variant"\n      class="ma-2"\n      color="primary"\n    >\n      1 Year\n    </v-chip>\n\n    <v-chip\n      class="ma-2"\n      color="green"\n    >\n      <template v-slot:prepend>\n        <v-avatar\n          class="green-darken-4"\n        >\n          1\n        </v-avatar>\n      </template>\n      Years\n    </v-chip>\n\n    <v-chip\n      :model-value="true"\n      class="ma-2"\n      color="teal"\n      prepend-icon="mdi-checkbox-marked-circle"\n      closable\n    >\n      Confirmed\n    </v-chip>\n\n    <v-chip\n      :model-value="true"\n      class="ma-2"\n      close-icon="mdi-delete"\n      color="teal"\n      prepend-icon="mdi-checkbox-marked-circle"\n      closable\n    >\n      Confirmed\n    </v-chip>\n  </div>\n</template>\n';
const _hoisted_1 = { class: "text-center" };
const name = "v-chip";
const _sfc_main = {
  __name: "usage",
  setup(__props) {
    const variants = ["outlined", "elevated", "text", "plain"];
    const model = ref("default");
    const options = [...variants];
    const block = ref(false);
    const stacked = ref(false);
    const prepend = ref(false);
    const append = ref(false);
    const closable = ref(false);
    const props = computed(() => {
      return {
        block: block.value || void 0,
        closable: closable.value || void 0,
        stacked: stacked.value || void 0,
        "prepend-icon": prepend.value ? "$vuetify" : void 0,
        "append-icon": append.value ? "$vuetify" : void 0,
        variant: variants.includes(model.value) ? model.value : void 0
      };
    });
    const chipModel = ref(true);
    watch(stacked, (val) => val && (prepend.value = true));
    const slots = computed(() => {
      return `
  Chip
`;
    });
    const code = computed(() => {
      return `<${name}${propsToString(props.value)}>${slots.value}</${name}>`;
    });
    return (_ctx, _cache) => {
      const _component_v_chip = resolveComponent("v-chip");
      const _component_v_checkbox = resolveComponent("v-checkbox");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_fade_transition = resolveComponent("v-fade-transition");
      const _component_ExamplesUsageExample = _sfc_main$f;
      return openBlock(), createBlock(_component_ExamplesUsageExample, {
        modelValue: unref(model),
        "onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => isRef(model) ? model.value = $event : null),
        code: unref(code),
        name,
        options
      }, {
        configuration: withCtx(() => [
          createVNode(_component_v_checkbox, {
            modelValue: unref(prepend),
            "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(prepend) ? prepend.value = $event : null),
            label: "Prepend icon"
          }, null, 8, ["modelValue"]),
          createVNode(_component_v_checkbox, {
            modelValue: unref(append),
            "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => isRef(append) ? append.value = $event : null),
            label: "Append icon"
          }, null, 8, ["modelValue"]),
          createVNode(_component_v_checkbox, {
            modelValue: unref(closable),
            "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => isRef(closable) ? closable.value = $event : null),
            label: "Closable"
          }, {
            append: withCtx(() => [
              createVNode(_component_v_fade_transition, null, {
                default: withCtx(() => [
                  !unref(chipModel) ? (openBlock(), createBlock(_component_v_btn, {
                    key: 0,
                    variant: "plain",
                    onClick: _cache[3] || (_cache[3] = ($event) => chipModel.value = true)
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Reset")
                    ]),
                    _: 1
                  })) : createCommentVNode("", true)
                ]),
                _: 1
              })
            ]),
            _: 1
          }, 8, ["modelValue"])
        ]),
        default: withCtx(() => [
          createBaseVNode("div", _hoisted_1, [
            createVNode(_component_v_chip, mergeProps(unref(props), {
              modelValue: unref(chipModel),
              "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(chipModel) ? chipModel.value = $event : null)
            }), {
              default: withCtx(() => [
                createTextVNode(" Chip ")
              ]),
              _: 1
            }, 16, ["modelValue"])
          ])
        ]),
        _: 1
      }, 8, ["modelValue", "code"]);
    };
  }
};
const __14 = _sfc_main;
const __14_raw = `<template>
  <ExamplesUsageExample
    v-model="model"
    :code="code"
    :name="name"
    :options="options"
  >
    <div class="text-center">
      <v-chip v-bind="props" v-model="chipModel">
        Chip
      </v-chip>
    </div>

    <template v-slot:configuration>
      <v-checkbox v-model="prepend" label="Prepend icon"></v-checkbox>
      <v-checkbox v-model="append" label="Append icon"></v-checkbox>
      <v-checkbox v-model="closable" label="Closable">
        <template v-slot:append>
          <v-fade-transition>
            <v-btn v-if="!chipModel" variant="plain" @click="chipModel = true">Reset</v-btn>
          </v-fade-transition>
        </template>
      </v-checkbox>
    </template>
  </ExamplesUsageExample>
</template>

<script setup>
  const variants = ['outlined', 'elevated', 'text', 'plain']
  const name = 'v-chip'
  const model = ref('default')
  const options = [...variants]
  const block = ref(false)
  const stacked = ref(false)
  const prepend = ref(false)
  const append = ref(false)
  const closable = ref(false)
  const props = computed(() => {
    return {
      block: block.value || undefined,
      closable: closable.value || undefined,
      stacked: stacked.value || undefined,
      'prepend-icon': prepend.value ? '$vuetify' : undefined,
      'append-icon': append.value ? '$vuetify' : undefined,
      variant: variants.includes(model.value) ? model.value : undefined,
    }
  })

  const chipModel = ref(true)

  watch(stacked, val => val && (prepend.value = true))

  const slots = computed(() => {
    return \`
  Chip
\`
  })

  const code = computed(() => {
    return \`<\${name}\${propsToString(props.value)}>\${slots.value}</\${name}>\`
  })
<\/script>
`;
const vChip = {
  "event-action-chips": {
    component: __0,
    source: __0_raw
  },
  "misc-custom-list": {
    component: __1,
    source: __1_raw
  },
  "misc-expandable": {
    component: __2,
    source: __2_raw
  },
  "misc-filtering": {
    component: __3,
    source: __3_raw
  },
  "misc-in-selects": {
    component: __4,
    source: __4_raw
  },
  "prop-closable": {
    component: __5,
    source: __5_raw
  },
  "prop-colored": {
    component: __6,
    source: __6_raw
  },
  "prop-draggable": {
    component: __7,
    source: __7_raw
  },
  "prop-filter": {
    component: __8,
    source: __8_raw
  },
  "prop-label": {
    component: __9,
    source: __9_raw
  },
  "prop-no-ripple": {
    component: __10,
    source: __10_raw
  },
  "prop-outlined": {
    component: __11,
    source: __11_raw
  },
  "prop-sizes": {
    component: __12,
    source: __12_raw
  },
  "slot-icon": {
    component: __13,
    source: __13_raw
  },
  "usage": {
    component: __14,
    source: __14_raw
  }
};
export {
  vChip as default
};
