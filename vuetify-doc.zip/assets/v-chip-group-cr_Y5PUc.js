import { J as ref, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, b as createVNode, h as createTextVNode, l as createElementBlock, F as Fragment, v as renderList, e as createBaseVNode, B as shallowRef, t as toDisplayString, j as computed, ag as propsToString, ak as normalizeProps, al as guardReactiveProps, f as unref, E as isRef } from "./index-DGybHjCP.js";
import { _ as _sfc_main$8 } from "./UsageExample-M8CmNipa.js";
const _hoisted_1$4 = /* @__PURE__ */ createBaseVNode("h2", { class: "text-h4" }, "Shirt Blouse", -1);
const _hoisted_2$3 = /* @__PURE__ */ createBaseVNode("span", { class: "text-h6" }, "$44.50", -1);
const _hoisted_3$2 = /* @__PURE__ */ createBaseVNode("span", { class: "subheading" }, "Select size", -1);
const _sfc_main$7 = {
  __name: "misc-product-card",
  setup(__props) {
    const sizes = [
      "04",
      "06",
      "08",
      "10",
      "12",
      "14"
    ];
    const selection = ref("08");
    return (_ctx, _cache) => {
      const _component_v_spacer = resolveComponent("v-spacer");
      const _component_v_card_title = resolveComponent("v-card-title");
      const _component_v_card_text = resolveComponent("v-card-text");
      const _component_v_divider = resolveComponent("v-divider");
      const _component_v_chip = resolveComponent("v-chip");
      const _component_v_chip_group = resolveComponent("v-chip-group");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_card_actions = resolveComponent("v-card-actions");
      const _component_v_card = resolveComponent("v-card");
      return openBlock(), createBlock(_component_v_card, {
        class: "mx-auto",
        "max-width": "400"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_card_title, null, {
            default: withCtx(() => [
              _hoisted_1$4,
              createVNode(_component_v_spacer),
              _hoisted_2$3
            ]),
            _: 1
          }),
          createVNode(_component_v_card_text, null, {
            default: withCtx(() => [
              createTextVNode(" Our blouses are available in 8 colors. You can custom order a built-in arch support for any of the models. ")
            ]),
            _: 1
          }),
          createVNode(_component_v_divider, { class: "mx-4" }),
          createVNode(_component_v_card_text, null, {
            default: withCtx(() => [
              _hoisted_3$2,
              createVNode(_component_v_chip_group, {
                modelValue: selection.value,
                "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => selection.value = $event),
                "selected-class": "text-deep-purple-accent-4",
                mandatory: ""
              }, {
                default: withCtx(() => [
                  (openBlock(), createElementBlock(Fragment, null, renderList(sizes, (size) => {
                    return createVNode(_component_v_chip, {
                      key: size,
                      text: size,
                      value: size,
                      variant: "outlined"
                    }, null, 8, ["text", "value"]);
                  }), 64))
                ]),
                _: 1
              }, 8, ["modelValue"])
            ]),
            _: 1
          }),
          createVNode(_component_v_card_actions, null, {
            default: withCtx(() => [
              createVNode(_component_v_btn, {
                color: "deep-purple-accent-4",
                text: "Add to Cart",
                variant: "flat",
                block: ""
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __0 = _sfc_main$7;
const __0_raw = `<template>
  <v-card
    class="mx-auto"
    max-width="400"
  >
    <v-card-title>
      <h2 class="text-h4">Shirt Blouse</h2>

      <v-spacer></v-spacer>

      <span class="text-h6">$44.50</span>
    </v-card-title>

    <v-card-text>
      Our blouses are available in 8 colors. You can custom order a built-in arch support for any of the models.
    </v-card-text>

    <v-divider class="mx-4"></v-divider>

    <v-card-text>
      <span class="subheading">Select size</span>

      <v-chip-group
        v-model="selection"
        selected-class="text-deep-purple-accent-4"
        mandatory
      >
        <v-chip
          v-for="size in sizes"
          :key="size"
          :text="size"
          :value="size"
          variant="outlined"
        ></v-chip>
      </v-chip-group>
    </v-card-text>

    <v-card-actions>
      <v-btn
        color="deep-purple-accent-4"
        text="Add to Cart"
        variant="flat"
        block
      ></v-btn>
    </v-card-actions>
  </v-card>
</template>

<script setup>
  import { ref } from 'vue'

  const sizes = [
    '04',
    '06',
    '08',
    '10',
    '12',
    '14',
  ]

  const selection = ref('08')
<\/script>

<script>
  export default {
    data: () => ({
      selection: '08',
      sizes: [
        '04', '06', '08', '10', '12', '14',
      ],
    }),
  }
<\/script>
`;
const _hoisted_1$3 = { class: "pa-4" };
const _hoisted_2$2 = /* @__PURE__ */ createBaseVNode("div", { class: "text-h6" }, "What are you into?", -1);
const _hoisted_3$1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-subtitle-1" }, "Select topics to continue", -1);
const _hoisted_4 = { class: "pa-2" };
const _sfc_main$6 = {
  __name: "misc-reddit-categories",
  setup(__props) {
    const topics = [
      "🎤 Advice",
      "🐕 Animals",
      "🤖 Anime",
      "🎨 Art & Design",
      "💄 Beauty",
      "🏢 Business",
      "📚 Books",
      "💡 Damn That's Interesting",
      "💃 Hobbies",
      "🎮 Gaming",
      "🎥 Movies",
      "🎵 Music",
      "📺 TV",
      "🌮 Food",
      "😂 Funny",
      "💖 Health & Lifestyle",
      "🎓 School",
      "📰 News",
      "🌲 Nature",
      "🎨 Photography",
      "🎏 Sports"
    ];
    return (_ctx, _cache) => {
      const _component_v_chip = resolveComponent("v-chip");
      const _component_v_chip_group = resolveComponent("v-chip-group");
      const _component_v_responsive = resolveComponent("v-responsive");
      const _component_v_divider = resolveComponent("v-divider");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_sheet = resolveComponent("v-sheet");
      return openBlock(), createBlock(_component_v_sheet, {
        class: "mx-auto",
        "max-width": "400",
        rounded: "xl",
        border: ""
      }, {
        default: withCtx(() => [
          createBaseVNode("div", _hoisted_1$3, [
            _hoisted_2$2,
            _hoisted_3$1,
            createVNode(_component_v_responsive, {
              class: "overflow-y-auto",
              "max-height": "280"
            }, {
              default: withCtx(() => [
                createVNode(_component_v_chip_group, {
                  class: "mt-3",
                  column: ""
                }, {
                  default: withCtx(() => [
                    (openBlock(), createElementBlock(Fragment, null, renderList(topics, (topic) => {
                      return createVNode(_component_v_chip, {
                        key: topic,
                        text: topic,
                        value: topic
                      }, null, 8, ["text", "value"]);
                    }), 64))
                  ]),
                  _: 1
                })
              ]),
              _: 1
            })
          ]),
          createVNode(_component_v_divider),
          createBaseVNode("div", _hoisted_4, [
            createVNode(_component_v_btn, {
              color: "orange-darken-1",
              rounded: "t-0 b-xl",
              size: "x-large",
              text: "Continue",
              variant: "flat",
              block: ""
            })
          ])
        ]),
        _: 1
      });
    };
  }
};
const __1 = _sfc_main$6;
const __1_raw = `<template>
  <v-sheet
    class="mx-auto"
    max-width="400"
    rounded="xl"
    border
  >
    <div class="pa-4">
      <div class="text-h6">What are you into?</div>

      <div class="text-subtitle-1">Select topics to continue</div>

      <v-responsive class="overflow-y-auto" max-height="280">
        <v-chip-group class="mt-3" column>
          <v-chip
            v-for="topic in topics"
            :key="topic"
            :text="topic"
            :value="topic"
          ></v-chip>
        </v-chip-group>
      </v-responsive>
    </div>

    <v-divider></v-divider>

    <div class="pa-2">
      <v-btn
        color="orange-darken-1"
        rounded="t-0 b-xl"
        size="x-large"
        text="Continue"
        variant="flat"
        block
      ></v-btn>
    </div>
  </v-sheet>
</template>

<script setup>
  const topics = [
    '🎤 Advice',
    '🐕 Animals',
    '🤖 Anime',
    '🎨 Art & Design',
    '💄 Beauty',
    '🏢 Business',
    '📚 Books',
    '💡 Damn That\\'s Interesting',
    '💃 Hobbies',
    '🎮 Gaming',
    '🎥 Movies',
    '🎵 Music',
    '📺 TV',
    '🌮 Food',
    '😂 Funny',
    '💖 Health & Lifestyle',
    '🎓 School',
    '📰 News',
    '🌲 Nature',
    '🎨 Photography',
    '🎏 Sports',
  ]
<\/script>

<script>
  export default {
    data: () => ({
      topics: [
        '🎤 Advice',
        '🐕 Animals',
        '🤖 Anime',
        '🎨 Art & Design',
        '💄 Beauty',
        '🏢 Business',
        '📚 Books',
        '💡 Damn That\\'s Interesting',
        '💃 Hobbies',
        '🎮 Gaming',
        '🎥 Movies',
        '🎵 Music',
        '📺 TV',
        '🌮 Food',
        '😂 Funny',
        '💖 Health & Lifestyle',
        '🎓 School',
        '📰 News',
        '🌲 Nature',
        '🎨 Photography',
        '🎏 Sports',
      ],
    }),
  }
<\/script>
`;
const _hoisted_1$2 = /* @__PURE__ */ createBaseVNode("h2", { class: "text-h4" }, "Toothbrush", -1);
const _hoisted_2$1 = /* @__PURE__ */ createBaseVNode("span", { class: "text-h6" }, "$4.99", -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("span", { class: "subheading" }, "Select type", -1);
const _sfc_main$5 = {
  __name: "misc-toothbrush-card",
  setup(__props) {
    const selection = shallowRef(2);
    return (_ctx, _cache) => {
      const _component_v_spacer = resolveComponent("v-spacer");
      const _component_v_card_title = resolveComponent("v-card-title");
      const _component_v_card_text = resolveComponent("v-card-text");
      const _component_v_divider = resolveComponent("v-divider");
      const _component_v_chip = resolveComponent("v-chip");
      const _component_v_chip_group = resolveComponent("v-chip-group");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_card_actions = resolveComponent("v-card-actions");
      const _component_v_card = resolveComponent("v-card");
      return openBlock(), createBlock(_component_v_card, {
        class: "mx-auto",
        "max-width": "400"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_card_title, null, {
            default: withCtx(() => [
              _hoisted_1$2,
              createVNode(_component_v_spacer),
              _hoisted_2$1
            ]),
            _: 1
          }),
          createVNode(_component_v_card_text, null, {
            default: withCtx(() => [
              createTextVNode(" Our company takes pride in making handmade brushes. Our toothbrushes are available in 4 different bristel types, from extra soft to hard. ")
            ]),
            _: 1
          }),
          createVNode(_component_v_divider, { class: "mx-4" }),
          createVNode(_component_v_card_text, null, {
            default: withCtx(() => [
              _hoisted_3,
              createVNode(_component_v_chip_group, {
                modelValue: selection.value,
                "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => selection.value = $event),
                variant: "flat",
                mandatory: ""
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_chip, {
                    text: "Extra Soft",
                    border: ""
                  }),
                  createVNode(_component_v_chip, {
                    text: "Soft",
                    border: ""
                  }),
                  createVNode(_component_v_chip, {
                    text: "Medium",
                    border: ""
                  }),
                  createVNode(_component_v_chip, {
                    text: "Hard",
                    border: ""
                  })
                ]),
                _: 1
              }, 8, ["modelValue"])
            ]),
            _: 1
          }),
          createVNode(_component_v_card_actions, null, {
            default: withCtx(() => [
              createVNode(_component_v_btn, {
                color: "secondary",
                text: "Add to Cart",
                variant: "flat",
                block: ""
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __2 = _sfc_main$5;
const __2_raw = `<template>
  <v-card
    class="mx-auto"
    max-width="400"
  >
    <v-card-title>
      <h2 class="text-h4">Toothbrush</h2>

      <v-spacer></v-spacer>

      <span class="text-h6">$4.99</span>
    </v-card-title>

    <v-card-text>
      Our company takes pride in making handmade brushes.
      Our toothbrushes are available in 4 different bristel types, from extra soft to hard.
    </v-card-text>

    <v-divider class="mx-4"></v-divider>

    <v-card-text>
      <span class="subheading">Select type</span>

      <v-chip-group
        v-model="selection"
        variant="flat"
        mandatory
      >
        <v-chip text="Extra Soft" border></v-chip>
        <v-chip text="Soft" border></v-chip>
        <v-chip text="Medium" border></v-chip>
        <v-chip text="Hard" border></v-chip>
      </v-chip-group>
    </v-card-text>

    <v-card-actions>
      <v-btn
        color="secondary"
        text="Add to Cart"
        variant="flat"
        block
      ></v-btn>
    </v-card-actions>
  </v-card>
</template>

<script setup>
  import { shallowRef } from 'vue'

  const selection = shallowRef(2)
<\/script>

<script>
  export default {
    data: () => ({
      selection: 2,
    }),
  }
<\/script>
`;
const _hoisted_1$1 = { class: "pa-4" };
const _sfc_main$4 = {
  __name: "prop-column",
  setup(__props) {
    const tags = [
      "Work",
      "Home Improvement",
      "Vacation",
      "Food",
      "Drawers",
      "Shopping",
      "Art",
      "Tech",
      "Creative Writing"
    ];
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_sheet = resolveComponent("v-sheet");
      const _component_v_chip = resolveComponent("v-chip");
      const _component_v_chip_group = resolveComponent("v-chip-group");
      return openBlock(), createBlock(_component_v_sheet, {
        class: "mx-auto",
        elevation: "10",
        "max-width": "300",
        rounded: "xl"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_sheet, {
            class: "pa-3 bg-primary text-right",
            rounded: "t-xl"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, { icon: "mdi-content-save-cog-outline" }),
              createVNode(_component_v_btn, {
                class: "ms-2",
                icon: "mdi-check-bold"
              })
            ]),
            _: 1
          }),
          createBaseVNode("div", _hoisted_1$1, [
            createVNode(_component_v_chip_group, {
              "selected-class": "text-primary",
              column: ""
            }, {
              default: withCtx(() => [
                (openBlock(), createElementBlock(Fragment, null, renderList(tags, (tag) => {
                  return createVNode(_component_v_chip, { key: tag }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(tag), 1)
                    ]),
                    _: 2
                  }, 1024);
                }), 64))
              ]),
              _: 1
            })
          ])
        ]),
        _: 1
      });
    };
  }
};
const __3 = _sfc_main$4;
const __3_raw = `<template>
  <v-sheet
    class="mx-auto"
    elevation="10"
    max-width="300"
    rounded="xl"
  >
    <v-sheet
      class="pa-3 bg-primary text-right"
      rounded="t-xl"
    >
      <v-btn icon="mdi-content-save-cog-outline"></v-btn>

      <v-btn
        class="ms-2"
        icon="mdi-check-bold"
      ></v-btn>
    </v-sheet>

    <div class="pa-4">
      <v-chip-group
        selected-class="text-primary"
        column
      >
        <v-chip
          v-for="tag in tags"
          :key="tag"
        >
          {{ tag }}
        </v-chip>
      </v-chip-group>
    </div>
  </v-sheet>
</template>

<script setup>
  const tags = [
    'Work',
    'Home Improvement',
    'Vacation',
    'Food',
    'Drawers',
    'Shopping',
    'Art',
    'Tech',
    'Creative Writing',
  ]
<\/script>

<script>
  export default {
    data: () => ({
      tags: [
        'Work',
        'Home Improvement',
        'Vacation',
        'Food',
        'Drawers',
        'Shopping',
        'Art',
        'Tech',
        'Creative Writing',
      ],
    }),
  }
<\/script>
`;
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("h2", { class: "text-h6 mb-2" }, "Choose amenities", -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("h2", { class: "text-h6 mb-2" }, "Choose neighborhoods", -1);
const _sfc_main$3 = {
  __name: "prop-filter",
  setup(__props) {
    const amenities = shallowRef([1, 4]);
    const neighborhoods = shallowRef([1]);
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_toolbar_title = resolveComponent("v-toolbar-title");
      const _component_v_toolbar = resolveComponent("v-toolbar");
      const _component_v_chip = resolveComponent("v-chip");
      const _component_v_chip_group = resolveComponent("v-chip-group");
      const _component_v_card_text = resolveComponent("v-card-text");
      const _component_v_card = resolveComponent("v-card");
      return openBlock(), createBlock(_component_v_card, {
        class: "mx-auto",
        "max-width": "400"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_toolbar, { color: "deep-purple-accent-4" }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, { icon: "mdi-close" }),
              createVNode(_component_v_toolbar_title, null, {
                default: withCtx(() => [
                  createTextVNode("Filter results")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_card_text, null, {
            default: withCtx(() => [
              _hoisted_1,
              createVNode(_component_v_chip_group, {
                modelValue: amenities.value,
                "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => amenities.value = $event),
                column: "",
                multiple: ""
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_chip, {
                    text: "Elevator",
                    variant: "outlined",
                    filter: ""
                  }),
                  createVNode(_component_v_chip, {
                    text: "Washer / Dryer",
                    variant: "outlined",
                    filter: ""
                  }),
                  createVNode(_component_v_chip, {
                    text: "Fireplace",
                    variant: "outlined",
                    filter: ""
                  }),
                  createVNode(_component_v_chip, {
                    text: "Wheelchair access",
                    variant: "outlined",
                    filter: ""
                  }),
                  createVNode(_component_v_chip, {
                    text: "Dogs ok",
                    variant: "outlined",
                    filter: ""
                  }),
                  createVNode(_component_v_chip, {
                    text: "Cats ok",
                    variant: "outlined",
                    filter: ""
                  })
                ]),
                _: 1
              }, 8, ["modelValue"])
            ]),
            _: 1
          }),
          createVNode(_component_v_card_text, null, {
            default: withCtx(() => [
              _hoisted_2,
              createVNode(_component_v_chip_group, {
                modelValue: neighborhoods.value,
                "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => neighborhoods.value = $event),
                column: "",
                multiple: ""
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_chip, {
                    text: "Snowy Rock Place",
                    variant: "outlined",
                    filter: ""
                  }),
                  createVNode(_component_v_chip, {
                    text: "Honeylane Circle",
                    variant: "outlined",
                    filter: ""
                  }),
                  createVNode(_component_v_chip, {
                    text: "Donna Drive",
                    variant: "outlined",
                    filter: ""
                  }),
                  createVNode(_component_v_chip, {
                    text: "Elaine Street",
                    variant: "outlined",
                    filter: ""
                  }),
                  createVNode(_component_v_chip, {
                    text: "Court Street",
                    variant: "outlined",
                    filter: ""
                  }),
                  createVNode(_component_v_chip, {
                    text: "Kennedy Park",
                    variant: "outlined",
                    filter: ""
                  })
                ]),
                _: 1
              }, 8, ["modelValue"])
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __4 = _sfc_main$3;
const __4_raw = `<template>
  <v-card
    class="mx-auto"
    max-width="400"
  >
    <v-toolbar color="deep-purple-accent-4">
      <v-btn icon="mdi-close"></v-btn>

      <v-toolbar-title>Filter results</v-toolbar-title>
    </v-toolbar>

    <v-card-text>
      <h2 class="text-h6 mb-2">Choose amenities</h2>

      <v-chip-group
        v-model="amenities"
        column
        multiple
      >
        <v-chip
          text="Elevator"
          variant="outlined"
          filter
        ></v-chip>

        <v-chip
          text="Washer / Dryer"
          variant="outlined"
          filter
        ></v-chip>

        <v-chip
          text="Fireplace"
          variant="outlined"
          filter
        ></v-chip>

        <v-chip
          text="Wheelchair access"
          variant="outlined"
          filter
        ></v-chip>

        <v-chip
          text="Dogs ok"
          variant="outlined"
          filter
        ></v-chip>

        <v-chip
          text="Cats ok"
          variant="outlined"
          filter
        ></v-chip>
      </v-chip-group>
    </v-card-text>

    <v-card-text>
      <h2 class="text-h6 mb-2">Choose neighborhoods</h2>

      <v-chip-group
        v-model="neighborhoods"
        column
        multiple
      >
        <v-chip
          text="Snowy Rock Place"
          variant="outlined"
          filter
        ></v-chip>

        <v-chip
          text="Honeylane Circle"
          variant="outlined"
          filter
        ></v-chip>

        <v-chip
          text="Donna Drive"
          variant="outlined"
          filter
        ></v-chip>

        <v-chip
          text="Elaine Street"
          variant="outlined"
          filter
        ></v-chip>

        <v-chip
          text="Court Street"
          variant="outlined"
          filter
        ></v-chip>

        <v-chip
          text="Kennedy Park"
          variant="outlined"
          filter
        ></v-chip>
      </v-chip-group>
    </v-card-text>
  </v-card>
</template>

<script setup>
  import { shallowRef } from 'vue'

  const amenities = shallowRef([1, 4])
  const neighborhoods = shallowRef([1])
<\/script>

<script>
  export default {
    data: () => ({
      amenities: [1, 4],
      neighborhoods: [1],
    }),
  }
<\/script>
`;
const _sfc_main$2 = {
  __name: "prop-mandatory",
  setup(__props) {
    const tags = [
      "Work",
      "Home Improvement",
      "Vacation",
      "Food",
      "Drawers",
      "Shopping",
      "Art",
      "Tech",
      "Creative Writing"
    ];
    return (_ctx, _cache) => {
      const _component_v_chip = resolveComponent("v-chip");
      const _component_v_chip_group = resolveComponent("v-chip-group");
      const _component_v_sheet = resolveComponent("v-sheet");
      return openBlock(), createBlock(_component_v_sheet, { class: "py-4 px-1" }, {
        default: withCtx(() => [
          createVNode(_component_v_chip_group, {
            "selected-class": "text-primary",
            mandatory: ""
          }, {
            default: withCtx(() => [
              (openBlock(), createElementBlock(Fragment, null, renderList(tags, (tag) => {
                return createVNode(_component_v_chip, {
                  key: tag,
                  text: tag
                }, null, 8, ["text"]);
              }), 64))
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __5 = _sfc_main$2;
const __5_raw = `<template>
  <v-sheet class="py-4 px-1">
    <v-chip-group
      selected-class="text-primary"
      mandatory
    >
      <v-chip
        v-for="tag in tags"
        :key="tag"
        :text="tag"
      ></v-chip>
    </v-chip-group>
  </v-sheet>
</template>

<script setup>
  const tags = [
    'Work',
    'Home Improvement',
    'Vacation',
    'Food',
    'Drawers',
    'Shopping',
    'Art',
    'Tech',
    'Creative Writing',
  ]
<\/script>

<script>
  export default {
    data: () => ({
      tags: [
        'Work',
        'Home Improvement',
        'Vacation',
        'Food',
        'Drawers',
        'Shopping',
        'Art',
        'Tech',
        'Creative Writing',
      ],
    }),
  }
<\/script>
`;
const _sfc_main$1 = {
  __name: "prop-multiple",
  setup(__props) {
    const tags = [
      "Work",
      "Home Improvement",
      "Vacation",
      "Food",
      "Drawers",
      "Shopping",
      "Art",
      "Tech",
      "Creative Writing"
    ];
    return (_ctx, _cache) => {
      const _component_v_chip = resolveComponent("v-chip");
      const _component_v_chip_group = resolveComponent("v-chip-group");
      const _component_v_sheet = resolveComponent("v-sheet");
      return openBlock(), createBlock(_component_v_sheet, { class: "py-4 px-1" }, {
        default: withCtx(() => [
          createVNode(_component_v_chip_group, {
            "selected-class": "text-primary",
            multiple: ""
          }, {
            default: withCtx(() => [
              (openBlock(), createElementBlock(Fragment, null, renderList(tags, (tag) => {
                return createVNode(_component_v_chip, {
                  key: tag,
                  text: tag
                }, null, 8, ["text"]);
              }), 64))
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __6 = _sfc_main$1;
const __6_raw = `<template>
  <v-sheet class="py-4 px-1">
    <v-chip-group
      selected-class="text-primary"
      multiple
    >
      <v-chip
        v-for="tag in tags"
        :key="tag"
        :text="tag"
      ></v-chip>
    </v-chip-group>
  </v-sheet>
</template>

<script setup>
  const tags = [
    'Work',
    'Home Improvement',
    'Vacation',
    'Food',
    'Drawers',
    'Shopping',
    'Art',
    'Tech',
    'Creative Writing',
  ]
<\/script>

<script>
  export default {
    data: () => ({
      tags: [
        'Work',
        'Home Improvement',
        'Vacation',
        'Food',
        'Drawers',
        'Shopping',
        'Art',
        'Tech',
        'Creative Writing',
      ],
    }),
  }
<\/script>
`;
const name = "v-chip-group";
const _sfc_main = {
  __name: "usage",
  setup(__props) {
    const model = ref("default");
    const options = ["filter"];
    const props = computed(() => {
      return {
        filter: model.value === "filter" || void 0
      };
    });
    const slots = computed(() => {
      return `
  <v-chip>Chip 1</v-chip>

  <v-chip>Chip 2</v-chip>

  <v-chip>Chip 3</v-chip>
`;
    });
    const code = computed(() => {
      return `<${name}${propsToString(props.value)}>${slots.value}</${name}>`;
    });
    return (_ctx, _cache) => {
      const _component_v_chip = resolveComponent("v-chip");
      const _component_v_chip_group = resolveComponent("v-chip-group");
      const _component_ExamplesUsageExample = _sfc_main$8;
      return openBlock(), createBlock(_component_ExamplesUsageExample, {
        modelValue: unref(model),
        "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(model) ? model.value = $event : null),
        code: unref(code),
        name,
        options
      }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createVNode(_component_v_chip_group, normalizeProps(guardReactiveProps(unref(props))), {
              default: withCtx(() => [
                createVNode(_component_v_chip, null, {
                  default: withCtx(() => [
                    createTextVNode("Chip 1")
                  ]),
                  _: 1
                }),
                createVNode(_component_v_chip, null, {
                  default: withCtx(() => [
                    createTextVNode("Chip 2")
                  ]),
                  _: 1
                }),
                createVNode(_component_v_chip, null, {
                  default: withCtx(() => [
                    createTextVNode("Chip 3")
                  ]),
                  _: 1
                })
              ]),
              _: 1
            }, 16)
          ])
        ]),
        _: 1
      }, 8, ["modelValue", "code"]);
    };
  }
};
const __7 = _sfc_main;
const __7_raw = '<template>\n  <ExamplesUsageExample\n    v-model="model"\n    :code="code"\n    :name="name"\n    :options="options"\n  >\n    <div>\n      <v-chip-group v-bind="props">\n        <v-chip>Chip 1</v-chip>\n\n        <v-chip>Chip 2</v-chip>\n\n        <v-chip>Chip 3</v-chip>\n      </v-chip-group>\n    </div>\n  </ExamplesUsageExample>\n</template>\n\n<script setup>\n  const name = \'v-chip-group\'\n  const model = ref(\'default\')\n  const options = [\'filter\']\n  const props = computed(() => {\n    return {\n      filter: model.value === \'filter\' || undefined,\n    }\n  })\n\n  const slots = computed(() => {\n    return `\n  <v-chip>Chip 1</v-chip>\n\n  <v-chip>Chip 2</v-chip>\n\n  <v-chip>Chip 3</v-chip>\n`\n  })\n\n  const code = computed(() => {\n    return `<${name}${propsToString(props.value)}>${slots.value}</${name}>`\n  })\n<\/script>\n';
const vChipGroup = {
  "misc-product-card": {
    component: __0,
    source: __0_raw
  },
  "misc-reddit-categories": {
    component: __1,
    source: __1_raw
  },
  "misc-toothbrush-card": {
    component: __2,
    source: __2_raw
  },
  "prop-column": {
    component: __3,
    source: __3_raw
  },
  "prop-filter": {
    component: __4,
    source: __4_raw
  },
  "prop-mandatory": {
    component: __5,
    source: __5_raw
  },
  "prop-multiple": {
    component: __6,
    source: __6_raw
  },
  "usage": {
    component: __7,
    source: __7_raw
  }
};
export {
  vChipGroup as default
};
