import { J as ref, r as resolveComponent, C as resolveDirective, o as openBlock, l as createElementBlock, b as createVNode, D as withDirectives, c as createBlock, w as withCtx, e as createBaseVNode, t as toDisplayString, F as Fragment, h as createTextVNode, y as _export_sfc } from "./index-DGybHjCP.js";
const _hoisted_1$2 = { class: "text-h6 text-md-h4 fill-height d-flex align-center justify-center" };
const _sfc_main$2 = {
  __name: "option-close-on-outside-click",
  setup(__props) {
    const active = ref(false);
    const clickOutsideEnabled = ref(false);
    function onClickOutside() {
      active.value = false;
    }
    function onCloseConditional(e) {
      return clickOutsideEnabled.value;
    }
    return (_ctx, _cache) => {
      const _component_v_switch = resolveComponent("v-switch");
      const _component_v_card = resolveComponent("v-card");
      const _directive_click_outside = resolveDirective("click-outside");
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(_component_v_switch, {
          modelValue: clickOutsideEnabled.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => clickOutsideEnabled.value = $event),
          label: `Click outside ${clickOutsideEnabled.value ? "enabled" : "disabled"}`
        }, null, 8, ["modelValue", "label"]),
        withDirectives((openBlock(), createBlock(_component_v_card, {
          color: active.value ? "primary" : void 0,
          dark: active.value,
          class: "mx-auto",
          height: "256",
          rounded: "xl",
          width: "256",
          onClick: _cache[1] || (_cache[1] = ($event) => active.value = true)
        }, {
          default: withCtx(() => [
            createBaseVNode("div", _hoisted_1$2, toDisplayString(active.value ? "Click Outside" : "Click Me"), 1)
          ]),
          _: 1
        }, 8, ["color", "dark"])), [
          [_directive_click_outside, {
            handler: onClickOutside,
            closeConditional: onCloseConditional
          }]
        ])
      ], 64);
    };
  }
};
const __0 = _sfc_main$2;
const __0_raw = `<template>
  <v-switch v-model="clickOutsideEnabled" :label="\`Click outside \${clickOutsideEnabled ? 'enabled' : 'disabled'}\`"></v-switch>
  <v-card
    :color="active ? 'primary' : undefined"
    :dark="active"
    class="mx-auto"
    height="256"
    rounded="xl"
    width="256"
    v-click-outside="{
      handler: onClickOutside,
      closeConditional: onCloseConditional
    }"
    @click="active = true"
  >
    <div class="text-h6 text-md-h4 fill-height d-flex align-center justify-center">
      {{ active ? 'Click Outside' : 'Click Me' }}
    </div>
  </v-card>
</template>

<script setup>
  import { ref } from 'vue'

  const active = ref(false)
  const clickOutsideEnabled = ref(false)

  function onClickOutside () {
    active.value = false
  }
  function onCloseConditional (e) {
    return clickOutsideEnabled.value
  }
<\/script>

<script>
  export default {
    data: () => ({
      active: false,
      clickOutsideEnabled: false,
    }),

    methods: {
      onClickOutside () {
        this.active = false
      },
      onCloseConditional (e) {
        return this.clickOutsideEnabled
      },
    },
  }
<\/script>
`;
const _hoisted_1$1 = { class: "text-h6 text-md-h4 fill-height d-flex align-center justify-center" };
const _hoisted_2 = { class: "d-flex justify-center" };
const _sfc_main$1 = {
  __name: "option-include",
  setup(__props) {
    const active = ref(false);
    function onClickOutside() {
      active.value = false;
    }
    function include() {
      return [document.querySelector(".included")];
    }
    return (_ctx, _cache) => {
      const _component_v_card = resolveComponent("v-card");
      const _component_v_card_text = resolveComponent("v-card-text");
      const _directive_click_outside = resolveDirective("click-outside");
      return openBlock(), createElementBlock(Fragment, null, [
        withDirectives((openBlock(), createBlock(_component_v_card, {
          color: active.value ? "primary" : void 0,
          dark: active.value,
          class: "mx-auto",
          height: "256",
          rounded: "xl",
          width: "256",
          onClick: _cache[0] || (_cache[0] = ($event) => active.value = true)
        }, {
          default: withCtx(() => [
            createBaseVNode("div", _hoisted_1$1, toDisplayString(active.value ? "Click Outside" : "Click Me"), 1)
          ]),
          _: 1
        }, 8, ["color", "dark"])), [
          [_directive_click_outside, {
            handler: onClickOutside,
            include
          }]
        ]),
        createBaseVNode("div", _hoisted_2, [
          createVNode(_component_v_card, {
            class: "ma-2 included",
            rounded: "lg"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_card_text, { class: "text-h6" }, {
                default: withCtx(() => [
                  createTextVNode(" This element is included ")
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_card, {
            class: "ma-2",
            rounded: "lg"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_card_text, { class: "text-h6" }, {
                default: withCtx(() => [
                  createTextVNode(" This element is not included ")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ])
      ], 64);
    };
  }
};
const __1 = _sfc_main$1;
const __1_raw = `<template>
  <v-card
    :color="active ? 'primary' : undefined"
    :dark="active"
    class="mx-auto"
    height="256"
    rounded="xl"
    width="256"
    v-click-outside="{
      handler: onClickOutside,
      include
    }"
    @click="active = true"
  >
    <div class="text-h6 text-md-h4 fill-height d-flex align-center justify-center">
      {{ active ? 'Click Outside' : 'Click Me' }}
    </div>
  </v-card>

  <div class="d-flex justify-center">
    <v-card
      class="ma-2 included"
      rounded="lg"
    >
      <v-card-text class="text-h6">
        This element is included
      </v-card-text>
    </v-card>

    <v-card
      class="ma-2"
      rounded="lg"
    >
      <v-card-text class="text-h6">
        This element is not included
      </v-card-text>
    </v-card>
  </div>
</template>

<script setup>
  import { ref } from 'vue'

  const active = ref(false)

  function onClickOutside () {
    active.value = false
  }
  function include () {
    return [document.querySelector('.included')]
  }
<\/script>

<script>
  export default {
    data: () => ({
      active: false,
    }),
    methods: {
      onClickOutside () {
        this.active = false
      },
      include () {
        return [document.querySelector('.included')]
      },
    },
  }
<\/script>
`;
const _sfc_main = {
  data: () => ({
    active: false
  }),
  methods: {
    onClickOutside() {
      this.active = false;
    }
  }
};
const _hoisted_1 = { class: "text-h6 text-md-h4 fill-height d-flex align-center justify-center" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_v_card = resolveComponent("v-card");
  const _directive_click_outside = resolveDirective("click-outside");
  return withDirectives((openBlock(), createBlock(_component_v_card, {
    color: _ctx.active ? "primary" : void 0,
    dark: _ctx.active,
    class: "mx-auto",
    height: "256",
    rounded: "xl",
    width: "256",
    onClick: _cache[0] || (_cache[0] = ($event) => _ctx.active = true)
  }, {
    default: withCtx(() => [
      createBaseVNode("div", _hoisted_1, toDisplayString(_ctx.active ? "Click Outside" : "Click Me"), 1)
    ]),
    _: 1
  }, 8, ["color", "dark"])), [
    [_directive_click_outside, $options.onClickOutside]
  ]);
}
const __2 = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
const __2_raw = `<template>
  <v-card
    :color="active ? 'primary' : undefined"
    :dark="active"
    class="mx-auto"
    height="256"
    rounded="xl"
    width="256"
    v-click-outside="onClickOutside"
    @click="active = true"
  >
    <div class="text-h6 text-md-h4 fill-height d-flex align-center justify-center">
      {{ active ? 'Click Outside' : 'Click Me' }}
    </div>
  </v-card>
</template>

<script>
  export default {
    data: () => ({
      active: false,
    }),

    methods: {
      onClickOutside () {
        this.active = false
      },
    },
  }
<\/script>
`;
const vClickOutside = {
  "option-close-on-outside-click": {
    component: __0,
    source: __0_raw
  },
  "option-include": {
    component: __1,
    source: __1_raw
  },
  "usage": {
    component: __2,
    source: __2_raw
  }
};
export {
  vClickOutside as default
};
