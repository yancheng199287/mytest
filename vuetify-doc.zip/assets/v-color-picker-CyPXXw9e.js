import { J as ref, r as resolveComponent, o as openBlock, l as createElementBlock, b as createVNode, e as createBaseVNode, c as createBlock, w as withCtx, h as createTextVNode, t as toDisplayString, j as computed, ag as propsToString, f as unref, E as isRef, ak as normalizeProps, al as guardReactiveProps } from "./index-DGybHjCP.js";
import { _ as _sfc_main$6 } from "./UsageExample-M8CmNipa.js";
const _hoisted_1$4 = { class: "d-flex justify-space-around" };
const _sfc_main$5 = {
  __name: "prop-canvas",
  setup(__props) {
    const c1 = ref("#ff00ff");
    const c2 = ref("#00ff00");
    return (_ctx, _cache) => {
      const _component_v_color_picker = resolveComponent("v-color-picker");
      return openBlock(), createElementBlock("div", _hoisted_1$4, [
        createVNode(_component_v_color_picker, {
          modelValue: c1.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => c1.value = $event),
          "hide-canvas": "",
          "hide-sliders": ""
        }, null, 8, ["modelValue"]),
        createVNode(_component_v_color_picker, {
          modelValue: c2.value,
          "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => c2.value = $event),
          "hide-inputs": "",
          "show-swatches": ""
        }, null, 8, ["modelValue"])
      ]);
    };
  }
};
const __0 = _sfc_main$5;
const __0_raw = `<template>
  <div class="d-flex justify-space-around">
    <v-color-picker
      v-model="c1"
      hide-canvas
      hide-sliders
    ></v-color-picker>

    <v-color-picker
      v-model="c2"
      hide-inputs
      show-swatches
    ></v-color-picker>
  </div>
</template>

<script setup>
  import { ref } from 'vue'

  const c1 = ref('#ff00ff')
  const c2 = ref('#00ff00')
<\/script>

<script>

  export default {
    data: () => ({
      c1: '#ff00ff',
      c2: '#00ff00',
    }),
  }
<\/script>
`;
const _hoisted_1$3 = { class: "d-flex justify-space-around" };
const _sfc_main$4 = {
  __name: "prop-elevation",
  setup(__props) {
    const picker = ref(null);
    return (_ctx, _cache) => {
      const _component_v_color_picker = resolveComponent("v-color-picker");
      return openBlock(), createElementBlock("div", _hoisted_1$3, [
        createVNode(_component_v_color_picker, {
          modelValue: picker.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => picker.value = $event),
          elevation: "0"
        }, null, 8, ["modelValue"]),
        createVNode(_component_v_color_picker, {
          modelValue: picker.value,
          "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => picker.value = $event),
          elevation: "15"
        }, null, 8, ["modelValue"])
      ]);
    };
  }
};
const __1 = _sfc_main$4;
const __1_raw = `<template>
  <div class="d-flex justify-space-around">
    <v-color-picker
      v-model="picker"
      elevation="0"
    ></v-color-picker>

    <v-color-picker
      v-model="picker"
      elevation="15"
    ></v-color-picker>
  </div>
</template>

<script setup>
  import { ref } from 'vue'

  const picker = ref(null)
<\/script>

<script>
  export default {
    data () {
      return {
        picker: null,
      }
    },
  }
<\/script>
`;
const _hoisted_1$2 = { class: "d-flex justify-space-around" };
const _hoisted_2 = { class: "d-flex flex-column" };
const _sfc_main$3 = {
  __name: "prop-mode",
  setup(__props) {
    const color = ref("#ff00ff");
    const mode = ref("hsla");
    const modes = ref(["hsla", "rgba", "hexa"]);
    return (_ctx, _cache) => {
      const _component_v_color_picker = resolveComponent("v-color-picker");
      const _component_v_select = resolveComponent("v-select");
      return openBlock(), createElementBlock("div", _hoisted_1$2, [
        createVNode(_component_v_color_picker, {
          modelValue: color.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => color.value = $event),
          modes: ["rgba"]
        }, null, 8, ["modelValue"]),
        createBaseVNode("div", _hoisted_2, [
          createVNode(_component_v_color_picker, {
            modelValue: color.value,
            "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => color.value = $event),
            mode: mode.value,
            "onUpdate:mode": _cache[2] || (_cache[2] = ($event) => mode.value = $event)
          }, null, 8, ["modelValue", "mode"]),
          createVNode(_component_v_select, {
            modelValue: mode.value,
            "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => mode.value = $event),
            items: modes.value,
            style: { "max-width": "300px" }
          }, null, 8, ["modelValue", "items"])
        ])
      ]);
    };
  }
};
const __2 = _sfc_main$3;
const __2_raw = `<template>
  <div class="d-flex justify-space-around">
    <v-color-picker
      v-model="color"
      :modes="['rgba']"
    ></v-color-picker>

    <div class="d-flex flex-column">
      <v-color-picker
        v-model="color"
        v-model:mode="mode"
      ></v-color-picker>
      <v-select
        v-model="mode"
        :items="modes"
        style="max-width: 300px"
      ></v-select>
    </div>
  </div>
</template>

<script setup>
  import { ref } from 'vue'

  const color = ref('#ff00ff')
  const mode = ref('hsla')
  const modes = ref(['hsla', 'rgba', 'hexa'])
<\/script>

<script>
  export default {
    data: () => ({
      color: '#ff00ff',
      mode: 'hsla',
      modes: ['hsla', 'rgba', 'hexa'],
    }),
  }
<\/script>
`;
const _sfc_main$2 = {
  __name: "prop-model",
  setup(__props) {
    const color = ref(null);
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_col = resolveComponent("v-col");
      const _component_v_color_picker = resolveComponent("v-color-picker");
      const _component_v_sheet = resolveComponent("v-sheet");
      const _component_v_row = resolveComponent("v-row");
      const _component_v_container = resolveComponent("v-container");
      return openBlock(), createBlock(_component_v_container, null, {
        default: withCtx(() => [
          createVNode(_component_v_row, null, {
            default: withCtx(() => [
              createVNode(_component_v_col, {
                cols: "12",
                md: "4"
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_btn, {
                    class: "my-4",
                    block: "",
                    onClick: _cache[0] || (_cache[0] = ($event) => color.value = null)
                  }, {
                    default: withCtx(() => [
                      createTextVNode("null")
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_btn, {
                    class: "my-4",
                    block: "",
                    onClick: _cache[1] || (_cache[1] = ($event) => color.value = "#ff00ff")
                  }, {
                    default: withCtx(() => [
                      createTextVNode("hex")
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_btn, {
                    class: "my-4",
                    block: "",
                    onClick: _cache[2] || (_cache[2] = ($event) => color.value = "#ff00ffff")
                  }, {
                    default: withCtx(() => [
                      createTextVNode("hexa")
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_btn, {
                    class: "my-4",
                    block: "",
                    onClick: _cache[3] || (_cache[3] = ($event) => color.value = { r: 255, g: 0, b: 255, a: 1 })
                  }, {
                    default: withCtx(() => [
                      createTextVNode("rgba")
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_btn, {
                    class: "my-4",
                    block: "",
                    onClick: _cache[4] || (_cache[4] = ($event) => color.value = { h: 300, s: 1, l: 0.5, a: 1 })
                  }, {
                    default: withCtx(() => [
                      createTextVNode("hsla")
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_btn, {
                    class: "my-4",
                    block: "",
                    onClick: _cache[5] || (_cache[5] = ($event) => color.value = { h: 300, s: 1, v: 1, a: 1 })
                  }, {
                    default: withCtx(() => [
                      createTextVNode("hsva")
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }),
              createVNode(_component_v_col, { class: "d-flex justify-center" }, {
                default: withCtx(() => [
                  createVNode(_component_v_color_picker, {
                    modelValue: color.value,
                    "onUpdate:modelValue": _cache[6] || (_cache[6] = ($event) => color.value = $event)
                  }, null, 8, ["modelValue"])
                ]),
                _: 1
              }),
              createVNode(_component_v_col, {
                cols: "12",
                md: "4"
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_sheet, { class: "pa-4" }, {
                    default: withCtx(() => [
                      createBaseVNode("pre", null, toDisplayString(color.value), 1)
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __3 = _sfc_main$2;
const __3_raw = `<template>
  <v-container>
    <v-row>
      <v-col
        cols="12"
        md="4"
      >
        <v-btn class="my-4" block @click="color = null">null</v-btn>
        <v-btn class="my-4" block @click="color = '#ff00ff'">hex</v-btn>
        <v-btn class="my-4" block @click="color = '#ff00ffff'">hexa</v-btn>
        <v-btn class="my-4" block @click="color = { r: 255, g: 0, b: 255, a: 1 }">rgba</v-btn>
        <v-btn class="my-4" block @click="color = { h: 300, s: 1, l: 0.5, a: 1 }">hsla</v-btn>
        <v-btn class="my-4" block @click="color = { h: 300, s: 1, v: 1, a: 1 }">hsva</v-btn>
      </v-col>
      <v-col
        class="d-flex justify-center"
      >
        <v-color-picker v-model="color"></v-color-picker>
      </v-col>
      <v-col
        cols="12"
        md="4"
      >
        <v-sheet
          class="pa-4"
        >
          <pre>{{ color }}</pre>
        </v-sheet>
      </v-col>
    </v-row>
  </v-container>
</template>

<script setup>
  import { ref } from 'vue'

  const color = ref(null)
<\/script>

<script>
  export default {
    data: () => ({
      color: null,
    }),
  }
<\/script>
`;
const _hoisted_1$1 = { class: "d-flex justify-space-around" };
const _sfc_main$1 = {
  __name: "prop-swatches",
  setup(__props) {
    const swatches = [
      ["#FF0000", "#AA0000", "#550000"],
      ["#FFFF00", "#AAAA00", "#555500"],
      ["#00FF00", "#00AA00", "#005500"],
      ["#00FFFF", "#00AAAA", "#005555"],
      ["#0000FF", "#0000AA", "#000055"]
    ];
    return (_ctx, _cache) => {
      const _component_v_color_picker = resolveComponent("v-color-picker");
      return openBlock(), createElementBlock("div", _hoisted_1$1, [
        createVNode(_component_v_color_picker, {
          class: "ma-2",
          "swatches-max-height": "400px",
          "show-swatches": ""
        }),
        createVNode(_component_v_color_picker, {
          swatches,
          class: "ma-2",
          "show-swatches": ""
        })
      ]);
    };
  }
};
const __4 = _sfc_main$1;
const __4_raw = `<template>
  <div class="d-flex justify-space-around">
    <v-color-picker
      class="ma-2"
      swatches-max-height="400px"
      show-swatches
    ></v-color-picker>
    <v-color-picker
      :swatches="swatches"
      class="ma-2"
      show-swatches
    ></v-color-picker>
  </div>
</template>

<script setup>
  const swatches = [
    ['#FF0000', '#AA0000', '#550000'],
    ['#FFFF00', '#AAAA00', '#555500'],
    ['#00FF00', '#00AA00', '#005500'],
    ['#00FFFF', '#00AAAA', '#005555'],
    ['#0000FF', '#0000AA', '#000055'],
  ]
<\/script>

<script>
  export default {
    data: () => ({
      swatches: [
        ['#FF0000', '#AA0000', '#550000'],
        ['#FFFF00', '#AAAA00', '#555500'],
        ['#00FF00', '#00AA00', '#005500'],
        ['#00FFFF', '#00AAAA', '#005555'],
        ['#0000FF', '#0000AA', '#000055'],
      ],
    }),
  }
<\/script>
`;
const _hoisted_1 = { class: "d-flex justify-center" };
const name = "v-color-picker";
const _sfc_main = {
  __name: "usage",
  setup(__props) {
    const model = ref("default");
    const options = ["Disabled", "Show swatches"];
    const hideCanvas = ref();
    const hideInputs = ref();
    const props = computed(() => {
      return {
        disabled: model.value === "Disabled" ? true : void 0,
        "hide-canvas": hideCanvas.value || void 0,
        "hide-inputs": hideInputs.value || void 0,
        "show-swatches": model.value === "Show swatches" ? true : void 0
      };
    });
    const slots = computed(() => {
      return ``;
    });
    const code = computed(() => {
      return `<${name}${propsToString(props.value)}>${slots.value}</${name}>`;
    });
    return (_ctx, _cache) => {
      const _component_v_color_picker = resolveComponent("v-color-picker");
      const _component_v_checkbox = resolveComponent("v-checkbox");
      const _component_ExamplesUsageExample = _sfc_main$6;
      return openBlock(), createBlock(_component_ExamplesUsageExample, {
        modelValue: unref(model),
        "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => isRef(model) ? model.value = $event : null),
        code: unref(code),
        name,
        options
      }, {
        configuration: withCtx(() => [
          createVNode(_component_v_checkbox, {
            modelValue: unref(hideCanvas),
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(hideCanvas) ? hideCanvas.value = $event : null),
            label: "Hide canvas"
          }, null, 8, ["modelValue"]),
          createVNode(_component_v_checkbox, {
            modelValue: unref(hideInputs),
            "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(hideInputs) ? hideInputs.value = $event : null),
            label: "Hide inputs"
          }, null, 8, ["modelValue"])
        ]),
        default: withCtx(() => [
          createBaseVNode("div", _hoisted_1, [
            createVNode(_component_v_color_picker, normalizeProps(guardReactiveProps(unref(props))), null, 16)
          ])
        ]),
        _: 1
      }, 8, ["modelValue", "code"]);
    };
  }
};
const __5 = _sfc_main;
const __5_raw = `<template>
  <ExamplesUsageExample
    v-model="model"
    :code="code"
    :name="name"
    :options="options"
  >
    <div class="d-flex justify-center">
      <v-color-picker v-bind="props"></v-color-picker>
    </div>

    <template v-slot:configuration>
      <v-checkbox v-model="hideCanvas" label="Hide canvas"></v-checkbox>

      <v-checkbox v-model="hideInputs" label="Hide inputs"></v-checkbox>
    </template>
  </ExamplesUsageExample>
</template>

<script setup>
  const name = 'v-color-picker'
  const model = ref('default')
  const options = ['Disabled', 'Show swatches']
  const hideCanvas = ref()
  const hideInputs = ref()
  const props = computed(() => {
    return {
      disabled: model.value === 'Disabled' ? true : undefined,
      'hide-canvas': hideCanvas.value || undefined,
      'hide-inputs': hideInputs.value || undefined,
      'show-swatches': model.value === 'Show swatches' ? true : undefined,
    }
  })

  const slots = computed(() => {
    return \`\`
  })

  const code = computed(() => {
    return \`<\${name}\${propsToString(props.value)}>\${slots.value}</\${name}>\`
  })
<\/script>
`;
const vColorPicker = {
  "prop-canvas": {
    component: __0,
    source: __0_raw
  },
  "prop-elevation": {
    component: __1,
    source: __1_raw
  },
  "prop-mode": {
    component: __2,
    source: __2_raw
  },
  "prop-model": {
    component: __3,
    source: __3_raw
  },
  "prop-swatches": {
    component: __4,
    source: __4_raw
  },
  "usage": {
    component: __5,
    source: __5_raw
  }
};
export {
  vColorPicker as default
};
