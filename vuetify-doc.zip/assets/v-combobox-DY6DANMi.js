import { y as _export_sfc, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, b as createVNode, h as createTextVNode, t as toDisplayString, a9 as mergeProps, e as createBaseVNode, q as createCommentVNode, ap as withKeys, V as withModifiers, J as ref, O as watch, W as nextTick, j as computed, ag as propsToString, f as unref, E as isRef, ak as normalizeProps, al as guardReactiveProps } from "./index-DGybHjCP.js";
import { _ as _sfc_main$5 } from "./UsageExample-M8CmNipa.js";
const _sfc_main$4 = {
  data: () => ({
    activator: null,
    attach: null,
    colors: ["green", "purple", "indigo", "cyan", "teal", "orange"],
    editing: null,
    editingIndex: -1,
    items: [
      { header: "Select an option or create one" },
      {
        text: "Foo",
        color: "blue"
      },
      {
        text: "Bar",
        color: "red"
      }
    ],
    nonce: 1,
    menu: false,
    model: [
      {
        text: "Foo",
        color: "blue"
      }
    ],
    x: 0,
    search: null,
    y: 0
  }),
  watch: {
    model(val, prev) {
      if (val.length === prev.length)
        return;
      this.model = val.map((v) => {
        if (typeof v === "string") {
          v = {
            text: v,
            color: this.colors[this.nonce - 1]
          };
          this.items.push(v);
          this.nonce++;
        }
        return v;
      });
    }
  },
  methods: {
    edit(index, item) {
      if (!this.editing) {
        this.editing = item;
        this.editingIndex = index;
      } else {
        this.editing = null;
        this.editingIndex = -1;
      }
    },
    filter(item, queryText, itemText) {
      if (item.header)
        return false;
      const hasValue = (val) => val != null ? val : "";
      const text = hasValue(itemText);
      const query = hasValue(queryText);
      return text.toString().toLowerCase().indexOf(query.toString().toLowerCase()) > -1;
    }
  }
};
const _hoisted_1$1 = /* @__PURE__ */ createBaseVNode("span", { class: "subheading" }, "Create", -1);
const _hoisted_2 = { class: "pe-2" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_v_chip = resolveComponent("v-chip");
  const _component_v_list_item = resolveComponent("v-list-item");
  const _component_v_icon = resolveComponent("v-icon");
  const _component_v_text_field = resolveComponent("v-text-field");
  const _component_v_spacer = resolveComponent("v-spacer");
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_list_item_action = resolveComponent("v-list-item-action");
  const _component_v_combobox = resolveComponent("v-combobox");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, { fluid: "" }, {
    default: withCtx(() => [
      createVNode(_component_v_combobox, {
        modelValue: _ctx.model,
        "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => _ctx.model = $event),
        "search-input": _ctx.search,
        "onUpdate:searchInput": _cache[3] || (_cache[3] = ($event) => _ctx.search = $event),
        "custom-filter": $options.filter,
        "hide-no-data": !_ctx.search,
        items: _ctx.items,
        label: "Search for an option",
        variant: "solo",
        "hide-selected": "",
        multiple: "",
        "small-chips": ""
      }, {
        "no-data": withCtx(() => [
          createVNode(_component_v_list_item, null, {
            default: withCtx(() => [
              _hoisted_1$1,
              createVNode(_component_v_chip, {
                color: `${_ctx.colors[_ctx.nonce - 1]} lighten-3`,
                label: "",
                small: ""
              }, {
                default: withCtx(() => [
                  createTextVNode(toDisplayString(_ctx.search), 1)
                ]),
                _: 1
              }, 8, ["color"])
            ]),
            _: 1
          })
        ]),
        selection: withCtx(({ attrs, item, parent, selected }) => [
          item === Object(item) ? (openBlock(), createBlock(_component_v_chip, mergeProps({ key: 0 }, attrs, {
            color: `${item.color} lighten-3`,
            "model-value": selected,
            label: "",
            small: ""
          }), {
            default: withCtx(() => [
              createBaseVNode("span", _hoisted_2, toDisplayString(item.text), 1),
              createVNode(_component_v_icon, {
                size: "small",
                onClick: ($event) => parent.selectItem(item)
              }, {
                default: withCtx(() => [
                  createTextVNode(" $delete ")
                ]),
                _: 2
              }, 1032, ["onClick"])
            ]),
            _: 2
          }, 1040, ["color", "model-value"])) : createCommentVNode("", true)
        ]),
        item: withCtx(({ index, item }) => [
          _ctx.editing === item ? (openBlock(), createBlock(_component_v_text_field, {
            key: 0,
            modelValue: _ctx.editing.text,
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => _ctx.editing.text = $event),
            "bg-color": "transparent",
            variant: "solo",
            autofocus: "",
            flat: "",
            "hide-details": "",
            onKeyup: withKeys(($event) => $options.edit(index, item), ["enter"])
          }, null, 8, ["modelValue", "onKeyup"])) : (openBlock(), createBlock(_component_v_chip, {
            key: 1,
            color: `${item.color} lighten-3`,
            dark: "",
            label: "",
            small: ""
          }, {
            default: withCtx(() => [
              createTextVNode(toDisplayString(item.text), 1)
            ]),
            _: 2
          }, 1032, ["color"])),
          createVNode(_component_v_spacer),
          createVNode(_component_v_list_item_action, {
            onClick: _cache[1] || (_cache[1] = withModifiers(() => {
            }, ["stop"]))
          }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, {
                icon: "",
                onClick: withModifiers(($event) => $options.edit(index, item), ["stop", "prevent"])
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_icon, null, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(_ctx.editing !== item ? "mdi-pencil" : "mdi-check"), 1)
                    ]),
                    _: 2
                  }, 1024)
                ]),
                _: 2
              }, 1032, ["onClick"])
            ]),
            _: 2
          }, 1024)
        ]),
        _: 1
      }, 8, ["modelValue", "search-input", "custom-filter", "hide-no-data", "items"])
    ]),
    _: 1
  });
}
const __0 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["render", _sfc_render]]);
const __0_raw = `<template>
  <v-container fluid>
    <v-combobox
      v-model="model"
      v-model:search-input="search"
      :custom-filter="filter"
      :hide-no-data="!search"
      :items="items"
      label="Search for an option"
      variant="solo"
      hide-selected
      multiple
      small-chips
    >
      <template v-slot:no-data>
        <v-list-item>
          <span class="subheading">Create</span>
          <v-chip
            :color="\`\${colors[nonce - 1]} lighten-3\`"
            label
            small
          >
            {{ search }}
          </v-chip>
        </v-list-item>
      </template>
      <template v-slot:selection="{ attrs, item, parent, selected }">
        <v-chip
          v-if="item === Object(item)"
          v-bind="attrs"
          :color="\`\${item.color} lighten-3\`"
          :model-value="selected"
          label
          small
        >
          <span class="pe-2">
            {{ item.text }}
          </span>
          <v-icon
            size="small"
            @click="parent.selectItem(item)"
          >
            $delete
          </v-icon>
        </v-chip>
      </template>
      <template v-slot:item="{ index, item }">
        <v-text-field
          v-if="editing === item"
          v-model="editing.text"
          bg-color="transparent"
          variant="solo"
          autofocus
          flat
          hide-details
          @keyup.enter="edit(index, item)"
        ></v-text-field>
        <v-chip
          v-else
          :color="\`\${item.color} lighten-3\`"
          dark
          label
          small
        >
          {{ item.text }}
        </v-chip>
        <v-spacer></v-spacer>
        <v-list-item-action @click.stop>
          <v-btn
            icon
            @click.stop.prevent="edit(index, item)"
          >
            <v-icon>{{ editing !== item ? 'mdi-pencil' : 'mdi-check' }}</v-icon>
          </v-btn>
        </v-list-item-action>
      </template>
    </v-combobox>
  </v-container>
</template>

<script>
  export default {
    data: () => ({
      activator: null,
      attach: null,
      colors: ['green', 'purple', 'indigo', 'cyan', 'teal', 'orange'],
      editing: null,
      editingIndex: -1,
      items: [
        { header: 'Select an option or create one' },
        {
          text: 'Foo',
          color: 'blue',
        },
        {
          text: 'Bar',
          color: 'red',
        },
      ],
      nonce: 1,
      menu: false,
      model: [
        {
          text: 'Foo',
          color: 'blue',
        },
      ],
      x: 0,
      search: null,
      y: 0,
    }),

    watch: {
      model (val, prev) {
        if (val.length === prev.length) return

        this.model = val.map(v => {
          if (typeof v === 'string') {
            v = {
              text: v,
              color: this.colors[this.nonce - 1],
            }

            this.items.push(v)

            this.nonce++
          }

          return v
        })
      },
    },

    methods: {
      edit (index, item) {
        if (!this.editing) {
          this.editing = item
          this.editingIndex = index
        } else {
          this.editing = null
          this.editingIndex = -1
        }
      },
      filter (item, queryText, itemText) {
        if (item.header) return false

        const hasValue = val => val != null ? val : ''

        const text = hasValue(itemText)
        const query = hasValue(queryText)

        return text.toString()
          .toLowerCase()
          .indexOf(query.toString().toLowerCase()) > -1
      },
    },
  }
<\/script>
`;
const _sfc_main$3 = {
  __name: "prop-density",
  setup(__props) {
    const items = ["foo", "bar", "fizz", "buzz"];
    const value = ref("foo");
    return (_ctx, _cache) => {
      const _component_v_combobox = resolveComponent("v-combobox");
      const _component_v_col = resolveComponent("v-col");
      const _component_v_row = resolveComponent("v-row");
      const _component_v_container = resolveComponent("v-container");
      const _component_v_card = resolveComponent("v-card");
      return openBlock(), createBlock(_component_v_card, null, {
        default: withCtx(() => [
          createVNode(_component_v_container, { fluid: "" }, {
            default: withCtx(() => [
              createVNode(_component_v_row, null, {
                default: withCtx(() => [
                  createVNode(_component_v_col, { cols: "12" }, {
                    default: withCtx(() => [
                      createVNode(_component_v_combobox, {
                        modelValue: value.value,
                        "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => value.value = $event),
                        items,
                        label: "Default"
                      }, null, 8, ["modelValue"])
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_col, { cols: "12" }, {
                    default: withCtx(() => [
                      createVNode(_component_v_combobox, {
                        modelValue: value.value,
                        "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => value.value = $event),
                        items,
                        density: "comfortable",
                        label: "Comfortable"
                      }, null, 8, ["modelValue"])
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_col, { cols: "12" }, {
                    default: withCtx(() => [
                      createVNode(_component_v_combobox, {
                        modelValue: value.value,
                        "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => value.value = $event),
                        items,
                        density: "compact",
                        label: "Compact"
                      }, null, 8, ["modelValue"])
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __1 = _sfc_main$3;
const __1_raw = `<template>
  <v-card>
    <v-container fluid>
      <v-row>
        <v-col cols="12">
          <v-combobox
            v-model="value"
            :items="items"
            label="Default"
          ></v-combobox>
        </v-col>
        <v-col cols="12">
          <v-combobox
            v-model="value"
            :items="items"
            density="comfortable"
            label="Comfortable"
          ></v-combobox>
        </v-col>
        <v-col cols="12">
          <v-combobox
            v-model="value"
            :items="items"
            density="compact"
            label="Compact"
          ></v-combobox>
        </v-col>
      </v-row>
    </v-container>
  </v-card>
</template>

<script setup>
  import { ref } from 'vue'

  const items = ['foo', 'bar', 'fizz', 'buzz']

  const value = ref('foo')
<\/script>

<script>
  export default {
    data: () => ({
      items: ['foo', 'bar', 'fizz', 'buzz'],
      value: 'foo',
    }),
  }
<\/script>
`;
const _sfc_main$2 = {
  __name: "prop-multiple",
  setup(__props) {
    const select = ref(["Vuetify", "Programming"]);
    const items = [
      "Programming",
      "Design",
      "Vue",
      "Vuetify"
    ];
    return (_ctx, _cache) => {
      const _component_v_combobox = resolveComponent("v-combobox");
      const _component_v_col = resolveComponent("v-col");
      const _component_v_avatar = resolveComponent("v-avatar");
      const _component_v_chip = resolveComponent("v-chip");
      const _component_v_row = resolveComponent("v-row");
      const _component_v_container = resolveComponent("v-container");
      return openBlock(), createBlock(_component_v_container, { fluid: "" }, {
        default: withCtx(() => [
          createVNode(_component_v_row, null, {
            default: withCtx(() => [
              createVNode(_component_v_col, { cols: "12" }, {
                default: withCtx(() => [
                  createVNode(_component_v_combobox, {
                    modelValue: select.value,
                    "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => select.value = $event),
                    items,
                    label: "Select a favorite activity or create a new one",
                    multiple: ""
                  }, null, 8, ["modelValue"])
                ]),
                _: 1
              }),
              createVNode(_component_v_col, { cols: "12" }, {
                default: withCtx(() => [
                  createVNode(_component_v_combobox, {
                    modelValue: select.value,
                    "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => select.value = $event),
                    items,
                    label: "I use chips",
                    chips: "",
                    multiple: ""
                  }, null, 8, ["modelValue"])
                ]),
                _: 1
              }),
              createVNode(_component_v_col, { cols: "12" }, {
                default: withCtx(() => [
                  createVNode(_component_v_combobox, {
                    modelValue: select.value,
                    "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => select.value = $event),
                    items,
                    label: "I use a scoped slot",
                    multiple: ""
                  }, {
                    selection: withCtx((data) => [
                      (openBlock(), createBlock(_component_v_chip, mergeProps({
                        key: JSON.stringify(data.item)
                      }, data.attrs, {
                        disabled: data.disabled,
                        "model-value": data.selected,
                        size: "small",
                        "onClick:close": ($event) => data.parent.selectItem(data.item)
                      }), {
                        prepend: withCtx(() => [
                          createVNode(_component_v_avatar, {
                            class: "bg-accent text-uppercase",
                            start: ""
                          }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(data.item.title.slice(0, 1)), 1)
                            ]),
                            _: 2
                          }, 1024)
                        ]),
                        default: withCtx(() => [
                          createTextVNode(" " + toDisplayString(data.item.title), 1)
                        ]),
                        _: 2
                      }, 1040, ["disabled", "model-value", "onClick:close"]))
                    ]),
                    _: 1
                  }, 8, ["modelValue"])
                ]),
                _: 1
              }),
              createVNode(_component_v_col, { cols: "12" }, {
                default: withCtx(() => [
                  createVNode(_component_v_combobox, {
                    modelValue: select.value,
                    "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => select.value = $event),
                    label: "I'm readonly",
                    chips: "",
                    multiple: "",
                    readonly: ""
                  }, null, 8, ["modelValue"])
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __2 = _sfc_main$2;
const __2_raw = `<template>
  <v-container fluid>
    <v-row>
      <v-col cols="12">
        <v-combobox
          v-model="select"
          :items="items"
          label="Select a favorite activity or create a new one"
          multiple
        ></v-combobox>
      </v-col>
      <v-col cols="12">
        <v-combobox
          v-model="select"
          :items="items"
          label="I use chips"
          chips
          multiple
        ></v-combobox>
      </v-col>
      <v-col cols="12">
        <v-combobox
          v-model="select"
          :items="items"
          label="I use a scoped slot"
          multiple
        >
          <template v-slot:selection="data">
            <v-chip
              :key="JSON.stringify(data.item)"
              v-bind="data.attrs"
              :disabled="data.disabled"
              :model-value="data.selected"
              size="small"
              @click:close="data.parent.selectItem(data.item)"
            >
              <template v-slot:prepend>
                <v-avatar
                  class="bg-accent text-uppercase"
                  start
                >{{ data.item.title.slice(0, 1) }}</v-avatar>
              </template>
              {{ data.item.title }}
            </v-chip>
          </template>
        </v-combobox>
      </v-col>
      <v-col cols="12">
        <v-combobox
          v-model="select"
          label="I'm readonly"
          chips
          multiple
          readonly
        ></v-combobox>
      </v-col>
    </v-row>
  </v-container>
</template>

<script setup>
  import { ref } from 'vue'

  const select = ref(['Vuetify', 'Programming'])

  const items = [
    'Programming',
    'Design',
    'Vue',
    'Vuetify',
  ]
<\/script>

<script>
  export default {
    data () {
      return {
        select: ['Vuetify', 'Programming'],
        items: [
          'Programming',
          'Design',
          'Vue',
          'Vuetify',
        ],
      }
    },
  }
<\/script>
`;
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("kbd", null, "enter", -1);
const _sfc_main$1 = {
  __name: "slot-no-data",
  setup(__props) {
    const items = ["Gaming", "Programming", "Vue", "Vuetify"];
    const model = ref(["Vuetify"]);
    const search = ref(null);
    watch(model, (val) => {
      if (val.length > 5) {
        nextTick(() => model.value.pop());
      }
    });
    return (_ctx, _cache) => {
      const _component_v_list_item_title = resolveComponent("v-list-item-title");
      const _component_v_list_item = resolveComponent("v-list-item");
      const _component_v_combobox = resolveComponent("v-combobox");
      const _component_v_container = resolveComponent("v-container");
      return openBlock(), createBlock(_component_v_container, { fluid: "" }, {
        default: withCtx(() => [
          createVNode(_component_v_combobox, {
            modelValue: model.value,
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => model.value = $event),
            search: search.value,
            "onUpdate:search": _cache[1] || (_cache[1] = ($event) => search.value = $event),
            "hide-no-data": false,
            items,
            hint: "Maximum of 5 tags",
            label: "Add some tags",
            "hide-selected": "",
            multiple: "",
            "persistent-hint": "",
            "small-chips": ""
          }, {
            "no-data": withCtx(() => [
              createVNode(_component_v_list_item, null, {
                default: withCtx(() => [
                  createVNode(_component_v_list_item_title, null, {
                    default: withCtx(() => [
                      createTextVNode(' No results matching "'),
                      createBaseVNode("strong", null, toDisplayString(search.value), 1),
                      createTextVNode('". Press '),
                      _hoisted_1,
                      createTextVNode(" to create a new one ")
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          }, 8, ["modelValue", "search"])
        ]),
        _: 1
      });
    };
  }
};
const __3 = _sfc_main$1;
const __3_raw = `<template>
  <v-container fluid>
    <v-combobox
      v-model="model"
      v-model:search="search"
      :hide-no-data="false"
      :items="items"
      hint="Maximum of 5 tags"
      label="Add some tags"
      hide-selected
      multiple
      persistent-hint
      small-chips
    >
      <template v-slot:no-data>
        <v-list-item>
          <v-list-item-title>
            No results matching "<strong>{{ search }}</strong>". Press <kbd>enter</kbd> to create a new one
          </v-list-item-title>
        </v-list-item>
      </template>
    </v-combobox>
  </v-container>
</template>

<script setup>
  import { nextTick, ref, watch } from 'vue'

  const items = ['Gaming', 'Programming', 'Vue', 'Vuetify']

  const model = ref(['Vuetify'])
  const search = ref(null)

  watch(model, val => {
    if (val.length > 5) {
      nextTick(() => model.value.pop())
    }
  })
<\/script>

<script>
  export default {
    data: () => ({
      items: ['Gaming', 'Programming', 'Vue', 'Vuetify'],
      model: ['Vuetify'],
      search: null,
    }),

    watch: {
      model (val) {
        if (val.length > 5) {
          this.$nextTick(() => this.model.pop())
        }
      },
    },
  }
<\/script>
`;
const name = "v-combobox";
const _sfc_main = {
  __name: "usage",
  setup(__props) {
    const model = ref("default");
    const clear = ref(false);
    const chips = ref(false);
    const multiple = ref(false);
    const options = ["outlined", "underlined", "solo", "solo-filled", "solo-inverted"];
    const props = computed(() => {
      return {
        clearable: clear.value || void 0,
        chips: chips.value || void 0,
        multiple: multiple.value || void 0,
        label: "Combobox",
        items: ["California", "Colorado", "Florida", "Georgia", "Texas", "Wyoming"],
        variant: model.value === "default" ? void 0 : model.value
      };
    });
    const slots = computed(() => {
      return ``;
    });
    const code = computed(() => {
      return `<${name}${propsToString(props.value)}>${slots.value}</${name}>`;
    });
    return (_ctx, _cache) => {
      const _component_v_combobox = resolveComponent("v-combobox");
      const _component_v_checkbox = resolveComponent("v-checkbox");
      const _component_ExamplesUsageExample = _sfc_main$5;
      return openBlock(), createBlock(_component_ExamplesUsageExample, {
        modelValue: unref(model),
        "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => isRef(model) ? model.value = $event : null),
        code: unref(code),
        name,
        options
      }, {
        configuration: withCtx(() => [
          createVNode(_component_v_checkbox, {
            modelValue: unref(clear),
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(clear) ? clear.value = $event : null),
            label: "Clearable"
          }, null, 8, ["modelValue"]),
          createVNode(_component_v_checkbox, {
            modelValue: unref(chips),
            "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(chips) ? chips.value = $event : null),
            label: "Chips"
          }, null, 8, ["modelValue"]),
          createVNode(_component_v_checkbox, {
            modelValue: unref(multiple),
            "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => isRef(multiple) ? multiple.value = $event : null),
            label: "Multiple"
          }, null, 8, ["modelValue"])
        ]),
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createVNode(_component_v_combobox, normalizeProps(guardReactiveProps(unref(props))), null, 16)
          ])
        ]),
        _: 1
      }, 8, ["modelValue", "code"]);
    };
  }
};
const __4 = _sfc_main;
const __4_raw = `<template>
  <ExamplesUsageExample
    v-model="model"
    :code="code"
    :name="name"
    :options="options"
  >
    <div>
      <v-combobox v-bind="props"></v-combobox>
    </div>

    <template v-slot:configuration>
      <v-checkbox v-model="clear" label="Clearable"></v-checkbox>

      <v-checkbox v-model="chips" label="Chips"></v-checkbox>

      <v-checkbox v-model="multiple" label="Multiple"></v-checkbox>
    </template>
  </ExamplesUsageExample>
</template>

<script setup>
  const name = 'v-combobox'
  const model = ref('default')
  const clear = ref(false)
  const chips = ref(false)
  const multiple = ref(false)
  const options = ['outlined', 'underlined', 'solo', 'solo-filled', 'solo-inverted']
  const props = computed(() => {
    return {
      clearable: clear.value || undefined,
      chips: chips.value || undefined,
      multiple: multiple.value || undefined,
      label: 'Combobox',
      items: ['California', 'Colorado', 'Florida', 'Georgia', 'Texas', 'Wyoming'],
      variant: model.value === 'default' ? undefined : model.value,
    }
  })

  const slots = computed(() => {
    return \`\`
  })

  const code = computed(() => {
    return \`<\${name}\${propsToString(props.value)}>\${slots.value}</\${name}>\`
  })
<\/script>
`;
const vCombobox = {
  "misc-advanced": {
    component: __0,
    source: __0_raw
  },
  "prop-density": {
    component: __1,
    source: __1_raw
  },
  "prop-multiple": {
    component: __2,
    source: __2_raw
  },
  "slot-no-data": {
    component: __3,
    source: __3_raw
  },
  "usage": {
    component: __4,
    source: __4_raw
  }
};
export {
  vCombobox as default
};
