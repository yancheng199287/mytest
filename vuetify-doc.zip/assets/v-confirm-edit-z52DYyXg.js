import { B as shallowRef, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, b as createVNode, a2 as resolveDynamicComponent, J as ref, j as computed, ag as propsToString, f as unref, E as isRef, e as createBaseVNode, a9 as mergeProps } from "./index-DGybHjCP.js";
import { _ as _sfc_main$2 } from "./UsageExample-M8CmNipa.js";
const _sfc_main$1 = {
  __name: "misc-date-picker",
  setup(__props) {
    const date = shallowRef();
    return (_ctx, _cache) => {
      const _component_v_date_picker = resolveComponent("v-date-picker");
      const _component_v_confirm_edit = resolveComponent("v-confirm-edit");
      const _component_v_card = resolveComponent("v-card");
      return openBlock(), createBlock(_component_v_card, {
        class: "mx-auto",
        "max-width": "328",
        rounded: "lg",
        border: ""
      }, {
        default: withCtx(() => [
          createVNode(_component_v_confirm_edit, {
            modelValue: date.value,
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => date.value = $event)
          }, {
            default: withCtx(({ model: proxyModel, actions }) => [
              createVNode(_component_v_date_picker, {
                modelValue: proxyModel.value,
                "onUpdate:modelValue": ($event) => proxyModel.value = $event
              }, {
                actions: withCtx(() => [
                  (openBlock(), createBlock(resolveDynamicComponent(actions)))
                ]),
                _: 2
              }, 1032, ["modelValue", "onUpdate:modelValue"])
            ]),
            _: 1
          }, 8, ["modelValue"])
        ]),
        _: 1
      });
    };
  }
};
const __0 = _sfc_main$1;
const __0_raw = `<template>
  <v-card
    class="mx-auto"
    max-width="328"
    rounded="lg"
    border
  >
    <v-confirm-edit v-model="date">
      <template v-slot:default="{ model: proxyModel, actions }">
        <v-date-picker v-model="proxyModel.value">
          <template v-slot:actions>
            <component :is="actions"></component>
          </template>
        </v-date-picker>
      </template>
    </v-confirm-edit>
  </v-card>
</template>

<script setup>
  import { shallowRef } from 'vue'

  const date = shallowRef()
<\/script>
`;
const _sfc_main = {
  __name: "usage",
  setup(__props) {
    const model = ref("default");
    const options = [];
    const value = ref("Egg Plant");
    const okText = ref("Ok");
    const cancelText = ref("Cancel");
    const props = computed(() => {
      return {
        "ok-text": okText.value === "Ok" ? void 0 : okText.value,
        "cancel-text": cancelText.value === "Cancel" ? void 0 : cancelText.value,
        "v-model": "model"
      };
    });
    const slots = computed(() => {
      return `
  <template v-slot:default="{ model: proxyModel, actions }">
    <v-card
      class="mx-auto"
      max-width="320"
      title="Update Field"
    >
      <template v-slot:text>
        <v-text-field
          v-model="proxyModel.value"
          messages="Modify my value"
        ></v-text-field>
      </template>

      <template v-slot:actions>
        <v-spacer></v-spacer>

        <component :is="actions"></component>
      </template>
    </v-card>
  </template>
`;
    });
    const script = computed(() => {
      return `<script setup>
  import { shallowRef } from 'vue'

  const model = shallowRef('Egg plant')
<\/script>`;
    });
    const code = computed(() => {
      return `<v-confirm-edit${propsToString(props.value)}>${slots.value}</v-confirm-edit>`;
    });
    return (_ctx, _cache) => {
      const _component_v_text_field = resolveComponent("v-text-field");
      const _component_v_spacer = resolveComponent("v-spacer");
      const _component_v_card = resolveComponent("v-card");
      const _component_v_confirm_edit = resolveComponent("v-confirm-edit");
      const _component_ExamplesUsageExample = _sfc_main$2;
      return openBlock(), createBlock(_component_ExamplesUsageExample, {
        modelValue: unref(model),
        "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => isRef(model) ? model.value = $event : null),
        code: unref(code),
        options,
        script: unref(script),
        name: "v-avatar"
      }, {
        configuration: withCtx(() => [
          createVNode(_component_v_text_field, {
            modelValue: unref(okText),
            "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(okText) ? okText.value = $event : null),
            label: "Ok text"
          }, null, 8, ["modelValue"]),
          createVNode(_component_v_text_field, {
            modelValue: unref(cancelText),
            "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => isRef(cancelText) ? cancelText.value = $event : null),
            label: "Cancel text"
          }, null, 8, ["modelValue"])
        ]),
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createVNode(_component_v_confirm_edit, mergeProps({
              modelValue: unref(value),
              "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(value) ? value.value = $event : null)
            }, unref(props)), {
              default: withCtx(({ model: proxyModel, actions }) => [
                createVNode(_component_v_card, {
                  class: "mx-auto",
                  "max-width": "320",
                  title: "Update Field"
                }, {
                  text: withCtx(() => [
                    createVNode(_component_v_text_field, {
                      modelValue: proxyModel.value,
                      "onUpdate:modelValue": ($event) => proxyModel.value = $event,
                      messages: "Modify my value"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  actions: withCtx(() => [
                    createVNode(_component_v_spacer),
                    (openBlock(), createBlock(resolveDynamicComponent(actions)))
                  ]),
                  _: 2
                }, 1024)
              ]),
              _: 1
            }, 16, ["modelValue"])
          ])
        ]),
        _: 1
      }, 8, ["modelValue", "code", "script"]);
    };
  }
};
const __1 = _sfc_main;
const __1_raw = `<template>
  <ExamplesUsageExample
    v-model="model"
    :code="code"
    :options="options"
    :script="script"
    name="v-avatar"
  >
    <div>
      <v-confirm-edit v-model="value" v-bind="props">
        <template v-slot:default="{ model: proxyModel, actions }">
          <v-card
            class="mx-auto"
            max-width="320"
            title="Update Field"
          >
            <template v-slot:text>
              <v-text-field
                v-model="proxyModel.value"
                messages="Modify my value"
              ></v-text-field>
            </template>

            <template v-slot:actions>
              <v-spacer></v-spacer>

              <component :is="actions"></component>
            </template>
          </v-card>
        </template>
      </v-confirm-edit>
    </div>

    <template v-slot:configuration>
      <v-text-field v-model="okText" label="Ok text"></v-text-field>
      <v-text-field v-model="cancelText" label="Cancel text"></v-text-field>
    </template>
  </ExamplesUsageExample>
</template>

<script setup>
  const model = ref('default')
  const options = []
  const value = ref('Egg Plant')
  const okText = ref('Ok')
  const cancelText = ref('Cancel')

  const props = computed(() => {
    return {
      'ok-text': okText.value === 'Ok' ? undefined : okText.value,
      'cancel-text': cancelText.value === 'Cancel' ? undefined : cancelText.value,
      'v-model': 'model',
    }
  })

  const slots = computed(() => {
    return \`
  <template v-slot:default="{ model: proxyModel, actions }">
    <v-card
      class="mx-auto"
      max-width="320"
      title="Update Field"
    >
      <template v-slot:text>
        <v-text-field
          v-model="proxyModel.value"
          messages="Modify my value"
        ></v-text-field>
      </template>

      <template v-slot:actions>
        <v-spacer></v-spacer>

        <component :is="actions"></component>
      </template>
    </v-card>
  </template>
\`
  })

  const script = computed(() => {
    return \`<script setup>
  import { shallowRef } from 'vue'

  const model = shallowRef('Egg plant')
<\` + '/script>'
  })

  const code = computed(() => {
    return \`<v-confirm-edit\${propsToString(props.value)}>\${slots.value}</v-confirm-edit>\`
  })
<\/script>
`;
const vConfirmEdit = {
  "misc-date-picker": {
    component: __0,
    source: __0_raw
  },
  "usage": {
    component: __1,
    source: __1_raw
  }
};
export {
  vConfirmEdit as default
};
