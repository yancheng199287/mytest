import { B as shallowRef, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, b as createVNode, l as createElementBlock, F as Fragment, v as renderList, e as createBaseVNode, t as toDisplayString, h as createTextVNode, q as createCommentVNode, J as ref, j as computed, ag as propsToString, a9 as mergeProps, f as unref, ak as normalizeProps, al as guardReactiveProps, E as isRef } from "./index-DGybHjCP.js";
import { _ as _sfc_main$5 } from "./UsageExample-M8CmNipa.js";
const _hoisted_1$4 = { class: "text-h6 mb-2" };
const _hoisted_2$3 = { class: "d-flex justify-space-between px-4" };
const _hoisted_3$2 = { class: "d-flex align-center text-caption text-medium-emphasis me-1" };
const _hoisted_4$2 = { class: "text-truncate" };
const _hoisted_5$2 = { class: "d-flex align-center justify-center pa-4" };
const _hoisted_6$2 = { class: "mx-2 text-caption" };
const _sfc_main$4 = {
  __name: "misc-filter",
  setup(__props) {
    const search = shallowRef("");
    const games = [
      {
        img: "https://cdn.vuetifyjs.com/docs/images/graphics/games/4.png",
        title: "The Sci-Fi Shooter Experience",
        subtitle: "Dive into a futuristic world of intense battles and alien encounters.",
        advanced: false,
        duration: "8 minutes"
      },
      {
        img: "https://cdn.vuetifyjs.com/docs/images/graphics/games/2.png",
        title: "Epic Adventures in Open Worlds",
        subtitle: "Embark on a journey through vast, immersive landscapes and quests.",
        advanced: true,
        duration: "10 minutes"
      },
      {
        img: "https://cdn.vuetifyjs.com/docs/images/graphics/games/3.png",
        title: "Surviving the Space Station Horror",
        subtitle: "Navigate a haunted space station in this chilling survival horror game.",
        advanced: false,
        duration: "9 minutes"
      },
      {
        img: "https://cdn.vuetifyjs.com/docs/images/graphics/games/5.png",
        title: "Neon-Lit High-Speed Racing Thrills",
        subtitle: "Experience adrenaline-pumping races in a futuristic, neon-soaked city.",
        advanced: true,
        duration: "12 minutes"
      },
      {
        img: "https://cdn.vuetifyjs.com/docs/images/graphics/games/6.png",
        title: "Retro-Style Platformer Adventures",
        subtitle: "Jump and dash through pixelated worlds in this classic-style platformer.",
        advanced: false,
        duration: "11 minutes"
      },
      {
        img: "https://cdn.vuetifyjs.com/docs/images/graphics/games/7.png",
        title: "Medieval Strategic War Campaigns",
        subtitle: "Lead armies into epic battles and conquer kingdoms in this strategic war game.",
        advanced: true,
        duration: "10 minutes"
      },
      {
        img: "https://cdn.vuetifyjs.com/docs/images/graphics/games/1.png",
        title: "Underwater VR Exploration Adventure",
        subtitle: "Dive deep into the ocean and discover the mysteries of the underwater world.",
        advanced: true,
        duration: "11 minutes"
      },
      {
        img: "https://cdn.vuetifyjs.com/docs/images/graphics/games/8.png",
        title: "1920s Mystery Detective Chronicles",
        subtitle: "Solve crimes and uncover secrets in the glamourous 1920s era.",
        advanced: false,
        duration: "9 minutes"
      }
    ];
    return (_ctx, _cache) => {
      const _component_v_text_field = resolveComponent("v-text-field");
      const _component_v_toolbar = resolveComponent("v-toolbar");
      const _component_v_img = resolveComponent("v-img");
      const _component_v_list_item = resolveComponent("v-list-item");
      const _component_v_icon = resolveComponent("v-icon");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_card = resolveComponent("v-card");
      const _component_v_col = resolveComponent("v-col");
      const _component_v_row = resolveComponent("v-row");
      const _component_v_container = resolveComponent("v-container");
      const _component_v_data_iterator = resolveComponent("v-data-iterator");
      return openBlock(), createBlock(_component_v_card, null, {
        default: withCtx(() => [
          createVNode(_component_v_data_iterator, {
            items: games,
            "items-per-page": 3,
            search: search.value
          }, {
            header: withCtx(() => [
              createVNode(_component_v_toolbar, { class: "px-2" }, {
                default: withCtx(() => [
                  createVNode(_component_v_text_field, {
                    modelValue: search.value,
                    "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => search.value = $event),
                    density: "comfortable",
                    placeholder: "Search",
                    "prepend-inner-icon": "mdi-magnify",
                    style: { "max-width": "300px" },
                    variant: "solo",
                    clearable: "",
                    "hide-details": ""
                  }, null, 8, ["modelValue"])
                ]),
                _: 1
              })
            ]),
            default: withCtx(({ items }) => [
              createVNode(_component_v_container, {
                class: "pa-2",
                fluid: ""
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_row, { dense: "" }, {
                    default: withCtx(() => [
                      (openBlock(true), createElementBlock(Fragment, null, renderList(items, (item) => {
                        return openBlock(), createBlock(_component_v_col, {
                          key: item.title,
                          cols: "auto",
                          md: "4"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_v_card, {
                              class: "pb-3",
                              border: "",
                              flat: ""
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_v_img, {
                                  src: item.raw.img
                                }, null, 8, ["src"]),
                                createVNode(_component_v_list_item, {
                                  subtitle: item.raw.subtitle,
                                  class: "mb-2"
                                }, {
                                  title: withCtx(() => [
                                    createBaseVNode("strong", _hoisted_1$4, toDisplayString(item.raw.title), 1)
                                  ]),
                                  _: 2
                                }, 1032, ["subtitle"]),
                                createBaseVNode("div", _hoisted_2$3, [
                                  createBaseVNode("div", _hoisted_3$2, [
                                    createVNode(_component_v_icon, {
                                      icon: "mdi-clock",
                                      start: ""
                                    }),
                                    createBaseVNode("div", _hoisted_4$2, toDisplayString(item.raw.duration), 1)
                                  ]),
                                  createVNode(_component_v_btn, {
                                    class: "text-none",
                                    size: "small",
                                    text: "Read",
                                    border: "",
                                    flat: ""
                                  })
                                ])
                              ]),
                              _: 2
                            }, 1024)
                          ]),
                          _: 2
                        }, 1024);
                      }), 128))
                    ]),
                    _: 2
                  }, 1024)
                ]),
                _: 2
              }, 1024)
            ]),
            footer: withCtx(({ page, pageCount, prevPage, nextPage }) => [
              createBaseVNode("div", _hoisted_5$2, [
                createVNode(_component_v_btn, {
                  disabled: page === 1,
                  density: "comfortable",
                  icon: "mdi-arrow-left",
                  variant: "tonal",
                  rounded: "",
                  onClick: prevPage
                }, null, 8, ["disabled", "onClick"]),
                createBaseVNode("div", _hoisted_6$2, " Page " + toDisplayString(page) + " of " + toDisplayString(pageCount), 1),
                createVNode(_component_v_btn, {
                  disabled: page >= pageCount,
                  density: "comfortable",
                  icon: "mdi-arrow-right",
                  variant: "tonal",
                  rounded: "",
                  onClick: nextPage
                }, null, 8, ["disabled", "onClick"])
              ])
            ]),
            _: 1
          }, 8, ["search"])
        ]),
        _: 1
      });
    };
  }
};
const __0 = _sfc_main$4;
const __0_raw = `<template>
  <v-card>
    <v-data-iterator
      :items="games"
      :items-per-page="3"
      :search="search"
    >
      <template v-slot:header>
        <v-toolbar class="px-2">
          <v-text-field
            v-model="search"
            density="comfortable"
            placeholder="Search"
            prepend-inner-icon="mdi-magnify"
            style="max-width: 300px;"
            variant="solo"
            clearable
            hide-details
          ></v-text-field>
        </v-toolbar>
      </template>

      <template v-slot:default="{ items }">
        <v-container class="pa-2" fluid>
          <v-row dense>
            <v-col
              v-for="item in items"
              :key="item.title"
              cols="auto"
              md="4"
            >
              <v-card class="pb-3" border flat>
                <v-img :src="item.raw.img"></v-img>

                <v-list-item :subtitle="item.raw.subtitle" class="mb-2">
                  <template v-slot:title>
                    <strong class="text-h6 mb-2">{{ item.raw.title }}</strong>
                  </template>
                </v-list-item>

                <div class="d-flex justify-space-between px-4">
                  <div class="d-flex align-center text-caption text-medium-emphasis me-1">
                    <v-icon icon="mdi-clock" start></v-icon>

                    <div class="text-truncate">{{ item.raw.duration }}</div>
                  </div>

                  <v-btn
                    class="text-none"
                    size="small"
                    text="Read"
                    border
                    flat
                  >
                  </v-btn>
                </div>
              </v-card>
            </v-col>
          </v-row>
        </v-container>
      </template>

      <template v-slot:footer="{ page, pageCount, prevPage, nextPage }">
        <div class="d-flex align-center justify-center pa-4">
          <v-btn
            :disabled="page === 1"
            density="comfortable"
            icon="mdi-arrow-left"
            variant="tonal"
            rounded
            @click="prevPage"
          ></v-btn>

          <div class="mx-2 text-caption">
            Page {{ page }} of {{ pageCount }}
          </div>

          <v-btn
            :disabled="page >= pageCount"
            density="comfortable"
            icon="mdi-arrow-right"
            variant="tonal"
            rounded
            @click="nextPage"
          ></v-btn>
        </div>
      </template>
    </v-data-iterator>
  </v-card>
</template>

<script setup>
  import { shallowRef } from 'vue'

  const search = shallowRef('')
  const games = [
    {
      img: 'https://cdn.vuetifyjs.com/docs/images/graphics/games/4.png',
      title: 'The Sci-Fi Shooter Experience',
      subtitle: 'Dive into a futuristic world of intense battles and alien encounters.',
      advanced: false,
      duration: '8 minutes',
    },
    {
      img: 'https://cdn.vuetifyjs.com/docs/images/graphics/games/2.png',
      title: 'Epic Adventures in Open Worlds',
      subtitle: 'Embark on a journey through vast, immersive landscapes and quests.',
      advanced: true,
      duration: '10 minutes',
    },
    {
      img: 'https://cdn.vuetifyjs.com/docs/images/graphics/games/3.png',
      title: 'Surviving the Space Station Horror',
      subtitle: 'Navigate a haunted space station in this chilling survival horror game.',
      advanced: false,
      duration: '9 minutes',
    },
    {
      img: 'https://cdn.vuetifyjs.com/docs/images/graphics/games/5.png',
      title: 'Neon-Lit High-Speed Racing Thrills',
      subtitle: 'Experience adrenaline-pumping races in a futuristic, neon-soaked city.',
      advanced: true,
      duration: '12 minutes',
    },
    {
      img: 'https://cdn.vuetifyjs.com/docs/images/graphics/games/6.png',
      title: 'Retro-Style Platformer Adventures',
      subtitle: 'Jump and dash through pixelated worlds in this classic-style platformer.',
      advanced: false,
      duration: '11 minutes',
    },
    {
      img: 'https://cdn.vuetifyjs.com/docs/images/graphics/games/7.png',
      title: 'Medieval Strategic War Campaigns',
      subtitle: 'Lead armies into epic battles and conquer kingdoms in this strategic war game.',
      advanced: true,
      duration: '10 minutes',
    },
    {
      img: 'https://cdn.vuetifyjs.com/docs/images/graphics/games/1.png',
      title: 'Underwater VR Exploration Adventure',
      subtitle: 'Dive deep into the ocean and discover the mysteries of the underwater world.',
      advanced: true,
      duration: '11 minutes',
    },
    {
      img: 'https://cdn.vuetifyjs.com/docs/images/graphics/games/8.png',
      title: '1920s Mystery Detective Chronicles',
      subtitle: 'Solve crimes and uncover secrets in the glamourous 1920s era.',
      advanced: false,
      duration: '9 minutes',
    },
  ]
<\/script>

<script>
  export default {
    data: () => ({
      search: '',
      games: [
        {
          img: 'https://cdn.vuetifyjs.com/docs/images/graphics/games/4.png',
          title: 'The Sci-Fi Shooter Experience',
          subtitle: 'Dive into a futuristic world of intense battles and alien encounters.',
          advanced: false,
          duration: '8 minutes',
        },
        {
          img: 'https://cdn.vuetifyjs.com/docs/images/graphics/games/2.png',
          title: 'Epic Adventures in Open Worlds',
          subtitle: 'Embark on a journey through vast, immersive landscapes and quests.',
          advanced: true,
          duration: '10 minutes',
        },
        {
          img: 'https://cdn.vuetifyjs.com/docs/images/graphics/games/3.png',
          title: 'Surviving the Space Station Horror',
          subtitle: 'Navigate a haunted space station in this chilling survival horror game.',
          advanced: false,
          duration: '9 minutes',
        },
        {
          img: 'https://cdn.vuetifyjs.com/docs/images/graphics/games/5.png',
          title: 'Neon-Lit High-Speed Racing Thrills',
          subtitle: 'Experience adrenaline-pumping races in a futuristic, neon-soaked city.',
          advanced: true,
          duration: '12 minutes',
        },
        {
          img: 'https://cdn.vuetifyjs.com/docs/images/graphics/games/6.png',
          title: 'Retro-Style Platformer Adventures',
          subtitle: 'Jump and dash through pixelated worlds in this classic-style platformer.',
          advanced: false,
          duration: '11 minutes',
        },
        {
          img: 'https://cdn.vuetifyjs.com/docs/images/graphics/games/7.png',
          title: 'Medieval Strategic War Campaigns',
          subtitle: 'Lead armies into epic battles and conquer kingdoms in this strategic game.',
          advanced: true,
          duration: '10 minutes',
        },
        {
          img: 'https://cdn.vuetifyjs.com/docs/images/graphics/games/1.png',
          title: 'Underwater VR Exploration Adventure',
          subtitle: 'Dive deep into the ocean and discover the mysteries of the underwater world.',
          advanced: true,
          duration: '11 minutes',
        },
        {
          img: 'https://cdn.vuetifyjs.com/docs/images/graphics/games/8.png',
          title: '1920s Mystery Detective Chronicles',
          subtitle: 'Solve crimes and uncover secrets in the glamourous 1920s era.',
          advanced: false,
          duration: '9 minutes',
        },
      ],
    }),
  }
<\/script>
`;
const _hoisted_1$3 = { class: "px-4" };
const _hoisted_2$2 = { key: 0 };
const _sfc_main$3 = {
  __name: "slot-default",
  setup(__props) {
    const desserts = [
      {
        name: "Frozen Yogurt",
        description: "A tangy and creamy dessert made from yogurt and sometimes fruit, Frozen Yogurt is a lighter alternative to ice cream. Perfect for those who crave a sweet treat but want to keep it on the healthier side.",
        icon: "mdi-ice-cream",
        color: "#6EC1E4",
        calories: 159,
        fat: 6,
        carbs: 24,
        protein: 4,
        sodium: 87,
        calcium: "14%",
        iron: "1%"
      },
      {
        name: "Ice cream sandwich",
        description: "A classic treat featuring a layer of creamy ice cream sandwiched between two cookies or cake layers. Ideal for those hot summer days when you can't decide between a cookie and ice cream.",
        icon: "mdi-cookie",
        color: "#F4A261",
        calories: 237,
        fat: 9,
        carbs: 37,
        protein: 4.3,
        sodium: 129,
        calcium: "8%",
        iron: "1%"
      },
      {
        name: "Eclair",
        description: "A small, individual cake topped with frosting and often adorned with sprinkles or other decorations. Great for parties or as a quick indulgence when you need a sugar fix.",
        icon: "mdi-cake-variant",
        color: "#6D4C41",
        calories: 262,
        fat: 16,
        carbs: 23,
        protein: 6,
        sodium: 337,
        calcium: "6%",
        iron: "7%"
      },
      {
        name: "Cupcake",
        description: "A small, individual cake topped with frosting and often adorned with sprinkles or other decorations. Great for parties or as a quick indulgence when you need a sugar fix.",
        color: "#FFADAD",
        icon: "mdi-cupcake",
        calories: 305,
        fat: 3.7,
        carbs: 67,
        protein: 4.3,
        sodium: 413,
        calcium: "3%",
        iron: "8%"
      }
    ];
    return (_ctx, _cache) => {
      const _component_v_icon = resolveComponent("v-icon");
      const _component_v_card_title = resolveComponent("v-card-title");
      const _component_v_card_text = resolveComponent("v-card-text");
      const _component_v_switch = resolveComponent("v-switch");
      const _component_v_divider = resolveComponent("v-divider");
      const _component_v_list_item = resolveComponent("v-list-item");
      const _component_v_list = resolveComponent("v-list");
      const _component_v_expand_transition = resolveComponent("v-expand-transition");
      const _component_v_card = resolveComponent("v-card");
      const _component_v_col = resolveComponent("v-col");
      const _component_v_row = resolveComponent("v-row");
      const _component_v_data_iterator = resolveComponent("v-data-iterator");
      return openBlock(), createBlock(_component_v_data_iterator, {
        items: desserts,
        "item-value": "name"
      }, {
        default: withCtx(({ items, isExpanded, toggleExpand }) => [
          createVNode(_component_v_row, null, {
            default: withCtx(() => [
              (openBlock(true), createElementBlock(Fragment, null, renderList(items, (item) => {
                return openBlock(), createBlock(_component_v_col, {
                  key: item.raw.name,
                  cols: "12",
                  md: "6",
                  sm: "12"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_v_card, null, {
                      default: withCtx(() => [
                        createVNode(_component_v_card_title, { class: "d-flex align-center" }, {
                          default: withCtx(() => [
                            createVNode(_component_v_icon, {
                              color: item.raw.color,
                              icon: item.raw.icon,
                              size: "18",
                              start: ""
                            }, null, 8, ["color", "icon"]),
                            createBaseVNode("h4", null, toDisplayString(item.raw.name), 1)
                          ]),
                          _: 2
                        }, 1024),
                        createVNode(_component_v_card_text, null, {
                          default: withCtx(() => [
                            createTextVNode(toDisplayString(item.raw.description), 1)
                          ]),
                          _: 2
                        }, 1024),
                        createBaseVNode("div", _hoisted_1$3, [
                          createVNode(_component_v_switch, {
                            label: `${isExpanded(item) ? "Hide" : "Show"} details`,
                            "model-value": isExpanded(item),
                            density: "compact",
                            inset: "",
                            onClick: () => toggleExpand(item)
                          }, null, 8, ["label", "model-value", "onClick"])
                        ]),
                        createVNode(_component_v_divider),
                        createVNode(_component_v_expand_transition, null, {
                          default: withCtx(() => [
                            isExpanded(item) ? (openBlock(), createElementBlock("div", _hoisted_2$2, [
                              createVNode(_component_v_list, {
                                lines: false,
                                density: "compact"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_v_list_item, {
                                    title: `🔥 Calories: ${item.raw.calories}`,
                                    active: ""
                                  }, null, 8, ["title"]),
                                  createVNode(_component_v_list_item, {
                                    title: `🍔 Fat: ${item.raw.fat}`
                                  }, null, 8, ["title"]),
                                  createVNode(_component_v_list_item, {
                                    title: `🍞 Carbs: ${item.raw.carbs}`
                                  }, null, 8, ["title"]),
                                  createVNode(_component_v_list_item, {
                                    title: `🍗 Protein: ${item.raw.protein}`
                                  }, null, 8, ["title"]),
                                  createVNode(_component_v_list_item, {
                                    title: `🧂 Sodium: ${item.raw.sodium}`
                                  }, null, 8, ["title"]),
                                  createVNode(_component_v_list_item, {
                                    title: `🦴 Calcium: ${item.raw.calcium}`
                                  }, null, 8, ["title"]),
                                  createVNode(_component_v_list_item, {
                                    title: `🧲 Iron: ${item.raw.iron}`
                                  }, null, 8, ["title"])
                                ]),
                                _: 2
                              }, 1024)
                            ])) : createCommentVNode("", true)
                          ]),
                          _: 2
                        }, 1024)
                      ]),
                      _: 2
                    }, 1024)
                  ]),
                  _: 2
                }, 1024);
              }), 128))
            ]),
            _: 2
          }, 1024)
        ]),
        _: 1
      });
    };
  }
};
const __1 = _sfc_main$3;
const __1_raw = `<template>
  <v-data-iterator
    :items="desserts"
    item-value="name"
  >
    <template v-slot:default="{ items, isExpanded, toggleExpand }">
      <v-row>
        <v-col
          v-for="item in items"
          :key="item.raw.name"
          cols="12"
          md="6"
          sm="12"
        >
          <v-card>
            <v-card-title class="d-flex align-center">
              <v-icon
                :color="item.raw.color"
                :icon="item.raw.icon"
                size="18"
                start
              ></v-icon>

              <h4>{{ item.raw.name }}</h4>
            </v-card-title>

            <v-card-text>
              {{ item.raw.description }}
            </v-card-text>

            <div class="px-4">
              <v-switch
                :label="\`\${isExpanded(item) ? 'Hide' : 'Show'} details\`"
                :model-value="isExpanded(item)"
                density="compact"
                inset
                @click="() => toggleExpand(item)"
              ></v-switch>
            </div>

            <v-divider></v-divider>

            <v-expand-transition>
              <div v-if="isExpanded(item)">
                <v-list :lines="false" density="compact">
                  <v-list-item :title="\`🔥 Calories: \${item.raw.calories}\`" active></v-list-item>
                  <v-list-item :title="\`🍔 Fat: \${item.raw.fat}\`"></v-list-item>
                  <v-list-item :title="\`🍞 Carbs: \${item.raw.carbs}\`"></v-list-item>
                  <v-list-item :title="\`🍗 Protein: \${item.raw.protein}\`"></v-list-item>
                  <v-list-item :title="\`🧂 Sodium: \${item.raw.sodium}\`"></v-list-item>
                  <v-list-item :title="\`🦴 Calcium: \${item.raw.calcium}\`"></v-list-item>
                  <v-list-item :title="\`🧲 Iron: \${item.raw.iron}\`"></v-list-item>
                </v-list>
              </div>
            </v-expand-transition>
          </v-card>
        </v-col>
      </v-row>
    </template>
  </v-data-iterator>
</template>

<script setup>
  const desserts = [
    {
      name: 'Frozen Yogurt',
      description: 'A tangy and creamy dessert made from yogurt and sometimes fruit, Frozen Yogurt is a lighter alternative to ice cream. Perfect for those who crave a sweet treat but want to keep it on the healthier side.',
      icon: 'mdi-ice-cream',
      color: '#6EC1E4',
      calories: 159,
      fat: 6,
      carbs: 24,
      protein: 4,
      sodium: 87,
      calcium: '14%',
      iron: '1%',
    },
    {
      name: 'Ice cream sandwich',
      description: 'A classic treat featuring a layer of creamy ice cream sandwiched between two cookies or cake layers. Ideal for those hot summer days when you can\\'t decide between a cookie and ice cream.',
      icon: 'mdi-cookie',
      color: '#F4A261',
      calories: 237,
      fat: 9,
      carbs: 37,
      protein: 4.3,
      sodium: 129,
      calcium: '8%',
      iron: '1%',
    },
    {
      name: 'Eclair',
      description: 'A small, individual cake topped with frosting and often adorned with sprinkles or other decorations. Great for parties or as a quick indulgence when you need a sugar fix.',
      icon: 'mdi-cake-variant',
      color: '#6D4C41',
      calories: 262,
      fat: 16,
      carbs: 23,
      protein: 6,
      sodium: 337,
      calcium: '6%',
      iron: '7%',
    },
    {
      name: 'Cupcake',
      description: 'A small, individual cake topped with frosting and often adorned with sprinkles or other decorations. Great for parties or as a quick indulgence when you need a sugar fix.',
      color: '#FFADAD',
      icon: 'mdi-cupcake',
      calories: 305,
      fat: 3.7,
      carbs: 67,
      protein: 4.3,
      sodium: 413,
      calcium: '3%',
      iron: '8%',
    },
  ]
<\/script>

<script>
  export default {
    data: () => ({
      desserts: [
        {
          name: 'Frozen Yogurt',
          description: 'A tangy and creamy dessert made from yogurt and sometimes fruit, Frozen Yogurt is a lighter alternative to ice cream. Perfect for those who crave a sweet treat but want to keep it on the healthier side.',
          icon: 'mdi-ice-cream',
          color: '#6EC1E4',
          calories: 159,
          fat: 6,
          carbs: 24,
          protein: 4,
          sodium: 87,
          calcium: '14%',
          iron: '1%',
        },
        {
          name: 'Ice cream sandwich',
          description: 'A classic treat featuring a layer of creamy ice cream sandwiched between two cookies or cake layers. Ideal for those hot summer days when you can\\'t decide between a cookie and ice cream.',
          icon: 'mdi-cookie',
          color: '#F4A261',
          calories: 237,
          fat: 9,
          carbs: 37,
          protein: 4.3,
          sodium: 129,
          calcium: '8%',
          iron: '1%',
        },
        {
          name: 'Eclair',
          description: 'A small, individual cake topped with frosting and often adorned with sprinkles or other decorations. Great for parties or as a quick indulgence when you need a sugar fix.',
          icon: 'mdi-cake-variant',
          color: '#6D4C41',
          calories: 262,
          fat: 16,
          carbs: 23,
          protein: 6,
          sodium: 337,
          calcium: '6%',
          iron: '7%',
        },
        {
          name: 'Cupcake',
          description: 'A small, individual cake topped with frosting and often adorned with sprinkles or other decorations. Great for parties or as a quick indulgence when you need a sugar fix.',
          color: '#FFADAD',
          icon: 'mdi-cupcake',
          calories: 305,
          fat: 3.7,
          carbs: 67,
          protein: 4.3,
          sodium: 413,
          calcium: '3%',
          iron: '8%',
        },
      ],
    }),
  }
<\/script>
`;
const _hoisted_1$2 = { class: "text-h4 font-weight-bold d-flex justify-space-between mb-4 align-center" };
const _hoisted_2$1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-truncate" }, " Most popular mice ", -1);
const _hoisted_3$1 = { class: "d-flex align-center" };
const _hoisted_4$1 = /* @__PURE__ */ createBaseVNode("span", { class: "text-decoration-underline text-none" }, "See all", -1);
const _hoisted_5$1 = { class: "d-inline-flex" };
const _hoisted_6$1 = { class: "text-h6" };
const _hoisted_7$1 = { align: "right" };
const _hoisted_8$1 = /* @__PURE__ */ createBaseVNode("th", null, "DPI:", -1);
const _hoisted_9$1 = { align: "right" };
const _hoisted_10$1 = /* @__PURE__ */ createBaseVNode("th", null, "Buttons:", -1);
const _hoisted_11$1 = { align: "right" };
const _hoisted_12 = /* @__PURE__ */ createBaseVNode("th", null, "Weight:", -1);
const _hoisted_13 = { align: "right" };
const _hoisted_14 = /* @__PURE__ */ createBaseVNode("th", null, "Wireless:", -1);
const _hoisted_15 = { align: "right" };
const _hoisted_16 = /* @__PURE__ */ createBaseVNode("th", null, "Price:", -1);
const _sfc_main$2 = {
  __name: "slot-header-and-footer",
  setup(__props) {
    const itemsPerPage = shallowRef(4);
    const mice = [
      {
        name: "Logitech G Pro X",
        color: "14, 151, 210",
        dpi: 16e3,
        buttons: 8,
        weight: "63g",
        wireless: true,
        price: 149.99,
        description: "Logitech G Pro X",
        src: "https://cdn.vuetifyjs.com/docs/images/graphics/mice/1.png"
      },
      {
        name: "Razer DeathAdder V2",
        color: "12, 146, 47",
        dpi: 2e4,
        buttons: 8,
        weight: "82g",
        wireless: false,
        price: 69.99,
        description: "Razer DeathAdder V2",
        src: "https://cdn.vuetifyjs.com/docs/images/graphics/mice/2.png"
      },
      {
        name: "Corsair Dark Core RGB",
        color: "107, 187, 226",
        dpi: 18e3,
        buttons: 9,
        weight: "133g",
        wireless: true,
        price: 89.99,
        description: "Corsair Dark Core RGB",
        src: "https://cdn.vuetifyjs.com/docs/images/graphics/mice/3.png"
      },
      {
        name: "SteelSeries Rival 3",
        color: "228, 196, 69",
        dpi: 8500,
        buttons: 6,
        weight: "77g",
        wireless: false,
        price: 29.99,
        description: "SteelSeries Rival 3",
        src: "https://cdn.vuetifyjs.com/docs/images/graphics/mice/4.png"
      },
      {
        name: "HyperX Pulsefire FPS Pro",
        color: "156, 82, 251",
        dpi: 16e3,
        buttons: 6,
        weight: "95g",
        wireless: false,
        price: 44.99,
        description: "HyperX Pulsefire FPS Pro",
        src: "https://cdn.vuetifyjs.com/docs/images/graphics/mice/5.png"
      },
      {
        name: "Zowie EC2",
        color: "166, 39, 222",
        dpi: 3200,
        buttons: 5,
        weight: "90g",
        wireless: false,
        price: 69.99,
        description: "Zowie EC2",
        src: "https://cdn.vuetifyjs.com/docs/images/graphics/mice/6.png"
      },
      {
        name: "Roccat Kone AIMO",
        color: "131, 9, 10",
        dpi: 16e3,
        buttons: 10,
        weight: "130g",
        wireless: false,
        price: 79.99,
        description: "Roccat Kone AIMO",
        src: "https://cdn.vuetifyjs.com/docs/images/graphics/mice/7.png"
      },
      {
        name: "Logitech G903",
        color: "232, 94, 102",
        dpi: 12e3,
        buttons: 11,
        weight: "110g",
        wireless: true,
        price: 129.99,
        description: "Logitech G903",
        src: "https://cdn.vuetifyjs.com/docs/images/graphics/mice/8.png"
      },
      {
        name: "Cooler Master MM711",
        color: "58, 192, 239",
        dpi: 16e3,
        buttons: 6,
        weight: "60g",
        wireless: false,
        price: 49.99,
        description: "Cooler Master MM711",
        src: "https://cdn.vuetifyjs.com/docs/images/graphics/mice/9.png"
      },
      {
        name: "Glorious Model O",
        color: "161, 252, 250",
        dpi: 12e3,
        buttons: 6,
        weight: "67g",
        wireless: false,
        price: 49.99,
        description: "Glorious Model O",
        src: "https://cdn.vuetifyjs.com/docs/images/graphics/mice/10.png"
      },
      {
        name: "HP Omen Photon",
        color: "201, 1, 2",
        dpi: 16e3,
        buttons: 11,
        weight: "128g",
        wireless: true,
        price: 99.99,
        description: "HP Omen Photon",
        src: "https://cdn.vuetifyjs.com/docs/images/graphics/mice/11.png"
      },
      {
        name: "Asus ROG Chakram",
        color: "10, 181, 19",
        dpi: 16e3,
        buttons: 9,
        weight: "121g",
        wireless: true,
        price: 159.99,
        description: "Asus ROG Chakram",
        src: "https://cdn.vuetifyjs.com/docs/images/graphics/mice/12.png"
      },
      {
        name: "Razer Naga X",
        color: "100, 101, 102",
        dpi: 16e3,
        buttons: 16,
        weight: "85g",
        wireless: false,
        price: 79.99,
        description: "Razer Naga X",
        src: "https://cdn.vuetifyjs.com/docs/images/graphics/mice/13.png"
      },
      {
        name: "Mad Catz R.A.T. 8+",
        color: "136, 241, 242",
        dpi: 16e3,
        buttons: 11,
        weight: "145g",
        wireless: false,
        price: 99.99,
        description: "Mad Catz R.A.T. 8+",
        src: "https://cdn.vuetifyjs.com/docs/images/graphics/mice/14.png"
      },
      {
        name: "Alienware 610M",
        color: "109, 110, 114",
        dpi: 16e3,
        buttons: 7,
        weight: "120g",
        wireless: true,
        price: 99.99,
        description: "Alienware 610M",
        src: "https://cdn.vuetifyjs.com/docs/images/graphics/mice/15.png"
      }
    ];
    function onClickSeeAll() {
      itemsPerPage.value = itemsPerPage.value === 4 ? mice.length : 4;
    }
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_img = resolveComponent("v-img");
      const _component_v_list_item = resolveComponent("v-list-item");
      const _component_v_table = resolveComponent("v-table");
      const _component_v_sheet = resolveComponent("v-sheet");
      const _component_v_col = resolveComponent("v-col");
      const _component_v_row = resolveComponent("v-row");
      const _component_v_footer = resolveComponent("v-footer");
      const _component_v_data_iterator = resolveComponent("v-data-iterator");
      return openBlock(), createBlock(_component_v_data_iterator, {
        items: mice,
        "items-per-page": itemsPerPage.value
      }, {
        header: withCtx(({ page, pageCount, prevPage, nextPage }) => [
          createBaseVNode("h1", _hoisted_1$2, [
            _hoisted_2$1,
            createBaseVNode("div", _hoisted_3$1, [
              createVNode(_component_v_btn, {
                class: "me-8",
                variant: "text",
                onClick: onClickSeeAll
              }, {
                default: withCtx(() => [
                  _hoisted_4$1
                ]),
                _: 1
              }),
              createBaseVNode("div", _hoisted_5$1, [
                createVNode(_component_v_btn, {
                  disabled: page === 1,
                  class: "me-2",
                  icon: "mdi-arrow-left",
                  size: "small",
                  variant: "tonal",
                  onClick: prevPage
                }, null, 8, ["disabled", "onClick"]),
                createVNode(_component_v_btn, {
                  disabled: page === pageCount,
                  icon: "mdi-arrow-right",
                  size: "small",
                  variant: "tonal",
                  onClick: nextPage
                }, null, 8, ["disabled", "onClick"])
              ])
            ])
          ])
        ]),
        default: withCtx(({ items }) => [
          createVNode(_component_v_row, null, {
            default: withCtx(() => [
              (openBlock(true), createElementBlock(Fragment, null, renderList(items, (item, i) => {
                return openBlock(), createBlock(_component_v_col, {
                  key: i,
                  cols: "12",
                  sm: "6",
                  xl: "3"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_v_sheet, { border: "" }, {
                      default: withCtx(() => [
                        createVNode(_component_v_img, {
                          gradient: `to top right, rgba(255, 255, 255, .1), rgba(${item.raw.color}, .15)`,
                          src: item.raw.src,
                          height: "150",
                          cover: ""
                        }, null, 8, ["gradient", "src"]),
                        createVNode(_component_v_list_item, {
                          title: item.raw.name,
                          density: "comfortable",
                          lines: "two",
                          subtitle: "Lorem ipsum dil orei namdie dkaf"
                        }, {
                          title: withCtx(() => [
                            createBaseVNode("strong", _hoisted_6$1, toDisplayString(item.raw.name), 1)
                          ]),
                          _: 2
                        }, 1032, ["title"]),
                        createVNode(_component_v_table, {
                          class: "text-caption",
                          density: "compact"
                        }, {
                          default: withCtx(() => [
                            createBaseVNode("tbody", null, [
                              createBaseVNode("tr", _hoisted_7$1, [
                                _hoisted_8$1,
                                createBaseVNode("td", null, toDisplayString(item.raw.dpi), 1)
                              ]),
                              createBaseVNode("tr", _hoisted_9$1, [
                                _hoisted_10$1,
                                createBaseVNode("td", null, toDisplayString(item.raw.buttons), 1)
                              ]),
                              createBaseVNode("tr", _hoisted_11$1, [
                                _hoisted_12,
                                createBaseVNode("td", null, toDisplayString(item.raw.weight), 1)
                              ]),
                              createBaseVNode("tr", _hoisted_13, [
                                _hoisted_14,
                                createBaseVNode("td", null, toDisplayString(item.raw.wireless ? "Yes" : "No"), 1)
                              ]),
                              createBaseVNode("tr", _hoisted_15, [
                                _hoisted_16,
                                createBaseVNode("td", null, "$" + toDisplayString(item.raw.price), 1)
                              ])
                            ])
                          ]),
                          _: 2
                        }, 1024)
                      ]),
                      _: 2
                    }, 1024)
                  ]),
                  _: 2
                }, 1024);
              }), 128))
            ]),
            _: 2
          }, 1024)
        ]),
        footer: withCtx(({ page, pageCount }) => [
          createVNode(_component_v_footer, {
            class: "justify-space-between text-body-2 mt-4",
            color: "surface-variant"
          }, {
            default: withCtx(() => [
              createTextVNode(" Total mice: " + toDisplayString(mice.length) + " ", 1),
              createBaseVNode("div", null, " Page " + toDisplayString(page) + " of " + toDisplayString(pageCount), 1)
            ]),
            _: 2
          }, 1024)
        ]),
        _: 1
      }, 8, ["items-per-page"]);
    };
  }
};
const __2 = _sfc_main$2;
const __2_raw = `<template>
  <v-data-iterator
    :items="mice"
    :items-per-page="itemsPerPage"
  >
    <template v-slot:header="{ page, pageCount, prevPage, nextPage }">
      <h1 class="text-h4 font-weight-bold d-flex justify-space-between mb-4 align-center">
        <div class="text-truncate">
          Most popular mice
        </div>

        <div class="d-flex align-center">
          <v-btn
            class="me-8"
            variant="text"
            @click="onClickSeeAll"
          >
            <span class="text-decoration-underline text-none">See all</span>
          </v-btn>

          <div class="d-inline-flex">
            <v-btn
              :disabled="page === 1"
              class="me-2"
              icon="mdi-arrow-left"
              size="small"
              variant="tonal"
              @click="prevPage"
            ></v-btn>

            <v-btn
              :disabled="page === pageCount"
              icon="mdi-arrow-right"
              size="small"
              variant="tonal"
              @click="nextPage"
            ></v-btn>
          </div>
        </div>
      </h1>
    </template>

    <template v-slot:default="{ items }">
      <v-row>
        <v-col
          v-for="(item, i) in items"
          :key="i"
          cols="12"
          sm="6"
          xl="3"
        >
          <v-sheet border>
            <v-img
              :gradient="\`to top right, rgba(255, 255, 255, .1), rgba(\${item.raw.color}, .15)\`"
              :src="item.raw.src"
              height="150"
              cover
            ></v-img>

            <v-list-item
              :title="item.raw.name"
              density="comfortable"
              lines="two"
              subtitle="Lorem ipsum dil orei namdie dkaf"
            >
              <template v-slot:title>
                <strong class="text-h6">
                  {{ item.raw.name }}
                </strong>
              </template>
            </v-list-item>

            <v-table class="text-caption" density="compact">
              <tbody>
                <tr align="right">
                  <th>DPI:</th>

                  <td>{{ item.raw.dpi }}</td>
                </tr>

                <tr align="right">
                  <th>Buttons:</th>

                  <td>{{ item.raw.buttons }}</td>
                </tr>

                <tr align="right">
                  <th>Weight:</th>

                  <td>{{ item.raw.weight }}</td>
                </tr>

                <tr align="right">
                  <th>Wireless:</th>

                  <td>{{ item.raw.wireless ? 'Yes' : 'No' }}</td>
                </tr>

                <tr align="right">
                  <th>Price:</th>

                  <td>\${{ item.raw.price }}</td>
                </tr>
              </tbody>
            </v-table>
          </v-sheet>
        </v-col>
      </v-row>
    </template>

    <template v-slot:footer="{ page, pageCount }">
      <v-footer
        class="justify-space-between text-body-2 mt-4"
        color="surface-variant"
      >
        Total mice: {{ mice.length }}

        <div>
          Page {{ page }} of {{ pageCount }}
        </div>
      </v-footer>
    </template>
  </v-data-iterator>
</template>

<script setup>
  import { shallowRef } from 'vue'

  const itemsPerPage = shallowRef(4)
  const mice = [
    {
      name: 'Logitech G Pro X',
      color: '14, 151, 210',
      dpi: 16000,
      buttons: 8,
      weight: '63g',
      wireless: true,
      price: 149.99,
      description: 'Logitech G Pro X',
      src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/1.png',
    },
    {
      name: 'Razer DeathAdder V2',
      color: '12, 146, 47',
      dpi: 20000,
      buttons: 8,
      weight: '82g',
      wireless: false,
      price: 69.99,
      description: 'Razer DeathAdder V2',
      src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/2.png',
    },
    {
      name: 'Corsair Dark Core RGB',
      color: '107, 187, 226',
      dpi: 18000,
      buttons: 9,
      weight: '133g',
      wireless: true,
      price: 89.99,
      description: 'Corsair Dark Core RGB',
      src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/3.png',
    },
    {
      name: 'SteelSeries Rival 3',
      color: '228, 196, 69',
      dpi: 8500,
      buttons: 6,
      weight: '77g',
      wireless: false,
      price: 29.99,
      description: 'SteelSeries Rival 3',
      src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/4.png',
    },
    {
      name: 'HyperX Pulsefire FPS Pro',
      color: '156, 82, 251',
      dpi: 16000,
      buttons: 6,
      weight: '95g',
      wireless: false,
      price: 44.99,
      description: 'HyperX Pulsefire FPS Pro',
      src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/5.png',
    },
    {
      name: 'Zowie EC2',
      color: '166, 39, 222',
      dpi: 3200,
      buttons: 5,
      weight: '90g',
      wireless: false,
      price: 69.99,
      description: 'Zowie EC2',
      src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/6.png',
    },
    {
      name: 'Roccat Kone AIMO',
      color: '131, 9, 10',
      dpi: 16000,
      buttons: 10,
      weight: '130g',
      wireless: false,
      price: 79.99,
      description: 'Roccat Kone AIMO',
      src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/7.png',
    },
    {
      name: 'Logitech G903',
      color: '232, 94, 102',
      dpi: 12000,
      buttons: 11,
      weight: '110g',
      wireless: true,
      price: 129.99,
      description: 'Logitech G903',
      src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/8.png',
    },
    {
      name: 'Cooler Master MM711',
      color: '58, 192, 239',
      dpi: 16000,
      buttons: 6,
      weight: '60g',
      wireless: false,
      price: 49.99,
      description: 'Cooler Master MM711',
      src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/9.png',
    },
    {
      name: 'Glorious Model O',
      color: '161, 252, 250',
      dpi: 12000,
      buttons: 6,
      weight: '67g',
      wireless: false,
      price: 49.99,
      description: 'Glorious Model O',
      src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/10.png',
    },
    {
      name: 'HP Omen Photon',
      color: '201, 1, 2',
      dpi: 16000,
      buttons: 11,
      weight: '128g',
      wireless: true,
      price: 99.99,
      description: 'HP Omen Photon',
      src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/11.png',
    },
    {
      name: 'Asus ROG Chakram',
      color: '10, 181, 19',
      dpi: 16000,
      buttons: 9,
      weight: '121g',
      wireless: true,
      price: 159.99,
      description: 'Asus ROG Chakram',
      src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/12.png',
    },
    {
      name: 'Razer Naga X',
      color: '100, 101, 102',
      dpi: 16000,
      buttons: 16,
      weight: '85g',
      wireless: false,
      price: 79.99,
      description: 'Razer Naga X',
      src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/13.png',
    },
    {
      name: 'Mad Catz R.A.T. 8+',
      color: '136, 241, 242',
      dpi: 16000,
      buttons: 11,
      weight: '145g',
      wireless: false,
      price: 99.99,
      description: 'Mad Catz R.A.T. 8+',
      src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/14.png',
    },
    {
      name: 'Alienware 610M',
      color: '109, 110, 114',
      dpi: 16000,
      buttons: 7,
      weight: '120g',
      wireless: true,
      price: 99.99,
      description: 'Alienware 610M',
      src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/15.png',
    },
  ]

  function onClickSeeAll () {
    itemsPerPage.value = itemsPerPage.value === 4 ? mice.length : 4
  }
<\/script>

<script>
  export default {
    data () {
      return {
        itemsPerPage: 4,
        mice: [
          {
            name: 'Logitech G Pro X',
            color: '14, 151, 210',
            dpi: 16000,
            buttons: 8,
            weight: '63g',
            wireless: true,
            price: 149.99,
            description: 'Logitech G Pro X',
            src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/1.png',
          },
          {
            name: 'Razer DeathAdder V2',
            color: '12, 146, 47',
            dpi: 20000,
            buttons: 8,
            weight: '82g',
            wireless: false,
            price: 69.99,
            description: 'Razer DeathAdder V2',
            src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/2.png',
          },
          {
            name: 'Corsair Dark Core RGB',
            color: '107, 187, 226',
            dpi: 18000,
            buttons: 9,
            weight: '133g',
            wireless: true,
            price: 89.99,
            description: 'Corsair Dark Core RGB',
            src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/3.png',
          },
          {
            name: 'SteelSeries Rival 3',
            color: '228, 196, 69',
            dpi: 8500,
            buttons: 6,
            weight: '77g',
            wireless: false,
            price: 29.99,
            description: 'SteelSeries Rival 3',
            src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/4.png',
          },
          {
            name: 'HyperX Pulsefire FPS Pro',
            color: '156, 82, 251',
            dpi: 16000,
            buttons: 6,
            weight: '95g',
            wireless: false,
            price: 44.99,
            description: 'HyperX Pulsefire FPS Pro',
            src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/5.png',
          },
          {
            name: 'Zowie EC2',
            color: '166, 39, 222',
            dpi: 3200,
            buttons: 5,
            weight: '90g',
            wireless: false,
            price: 69.99,
            description: 'Zowie EC2',
            src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/6.png',
          },
          {
            name: 'Roccat Kone AIMO',
            color: '131, 9, 10',
            dpi: 16000,
            buttons: 10,
            weight: '130g',
            wireless: false,
            price: 79.99,
            description: 'Roccat Kone AIMO',
            src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/7.png',
          },
          {
            name: 'Logitech G903',
            color: '232, 94, 102',
            dpi: 12000,
            buttons: 11,
            weight: '110g',
            wireless: true,
            price: 129.99,
            description: 'Logitech G903',
            src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/8.png',
          },
          {
            name: 'Cooler Master MM711',
            color: '58, 192, 239',
            dpi: 16000,
            buttons: 6,
            weight: '60g',
            wireless: false,
            price: 49.99,
            description: 'Cooler Master MM711',
            src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/9.png',
          },
          {
            name: 'Glorious Model O',
            color: '161, 252, 250',
            dpi: 12000,
            buttons: 6,
            weight: '67g',
            wireless: false,
            price: 49.99,
            description: 'Glorious Model O',
            src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/10.png',
          },
          {
            name: 'HP Omen Photon',
            color: '201, 1, 2',
            dpi: 16000,
            buttons: 11,
            weight: '128g',
            wireless: true,
            price: 99.99,
            description: 'HP Omen Photon',
            src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/11.png',
          },
          {
            name: 'Asus ROG Chakram',
            color: '10, 181, 19',
            dpi: 16000,
            buttons: 9,
            weight: '121g',
            wireless: true,
            price: 159.99,
            description: 'Asus ROG Chakram',
            src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/12.png',
          },
          {
            name: 'Razer Naga X',
            color: '100, 101, 102',
            dpi: 16000,
            buttons: 16,
            weight: '85g',
            wireless: false,
            price: 79.99,
            description: 'Razer Naga X',
            src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/13.png',
          },
          {
            name: 'Mad Catz R.A.T. 8+',
            color: '136, 241, 242',
            dpi: 16000,
            buttons: 11,
            weight: '145g',
            wireless: false,
            price: 99.99,
            description: 'Mad Catz R.A.T. 8+',
            src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/14.png',
          },
          {
            name: 'Alienware 610M',
            color: '109, 110, 114',
            dpi: 16000,
            buttons: 7,
            weight: '120g',
            wireless: true,
            price: 99.99,
            description: 'Alienware 610M',
            src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/15.png',
          },
        ],
      }
    },
    methods: {
      onClickSeeAll () {
        this.itemsPerPage = this.itemsPerPage === 4 ? this.mice.length : 4
      },
    },
  }
<\/script>
`;
const _hoisted_1$1 = { class: "text-h6" };
const _hoisted_2 = { align: "right" };
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("th", null, "DPI:", -1);
const _hoisted_4 = { align: "right" };
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("th", null, "Buttons:", -1);
const _hoisted_6 = { align: "right" };
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("th", null, "Weight:", -1);
const _hoisted_8 = { align: "right" };
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("th", null, "Wireless:", -1);
const _hoisted_10 = { align: "right" };
const _hoisted_11 = /* @__PURE__ */ createBaseVNode("th", null, "Price:", -1);
const _sfc_main$1 = {
  __name: "slot-loader",
  setup(__props) {
    const itemsPerPage = shallowRef(4);
    const mice = [
      {
        name: "Logitech G Pro X",
        color: "14, 151, 210",
        dpi: 16e3,
        buttons: 8,
        weight: "63g",
        wireless: true,
        price: 149.99,
        description: "Logitech G Pro X",
        src: "https://cdn.vuetifyjs.com/docs/images/graphics/mice/1.png"
      },
      {
        name: "Razer DeathAdder V2",
        color: "12, 146, 47",
        dpi: 2e4,
        buttons: 8,
        weight: "82g",
        wireless: false,
        price: 69.99,
        description: "Razer DeathAdder V2",
        src: "https://cdn.vuetifyjs.com/docs/images/graphics/mice/2.png"
      },
      {
        name: "Corsair Dark Core RGB",
        color: "107, 187, 226",
        dpi: 18e3,
        buttons: 9,
        weight: "133g",
        wireless: true,
        price: 89.99,
        description: "Corsair Dark Core RGB",
        src: "https://cdn.vuetifyjs.com/docs/images/graphics/mice/3.png"
      },
      {
        name: "SteelSeries Rival 3",
        color: "228, 196, 69",
        dpi: 8500,
        buttons: 6,
        weight: "77g",
        wireless: false,
        price: 29.99,
        description: "SteelSeries Rival 3",
        src: "https://cdn.vuetifyjs.com/docs/images/graphics/mice/4.png"
      },
      {
        name: "HyperX Pulsefire FPS Pro",
        color: "156, 82, 251",
        dpi: 16e3,
        buttons: 6,
        weight: "95g",
        wireless: false,
        price: 44.99,
        description: "HyperX Pulsefire FPS Pro",
        src: "https://cdn.vuetifyjs.com/docs/images/graphics/mice/5.png"
      },
      {
        name: "Zowie EC2",
        color: "166, 39, 222",
        dpi: 3200,
        buttons: 5,
        weight: "90g",
        wireless: false,
        price: 69.99,
        description: "Zowie EC2",
        src: "https://cdn.vuetifyjs.com/docs/images/graphics/mice/6.png"
      },
      {
        name: "Roccat Kone AIMO",
        color: "131, 9, 10",
        dpi: 16e3,
        buttons: 10,
        weight: "130g",
        wireless: false,
        price: 79.99,
        description: "Roccat Kone AIMO",
        src: "https://cdn.vuetifyjs.com/docs/images/graphics/mice/7.png"
      },
      {
        name: "Logitech G903",
        color: "232, 94, 102",
        dpi: 12e3,
        buttons: 11,
        weight: "110g",
        wireless: true,
        price: 129.99,
        description: "Logitech G903",
        src: "https://cdn.vuetifyjs.com/docs/images/graphics/mice/8.png"
      },
      {
        name: "Cooler Master MM711",
        color: "58, 192, 239",
        dpi: 16e3,
        buttons: 6,
        weight: "60g",
        wireless: false,
        price: 49.99,
        description: "Cooler Master MM711",
        src: "https://cdn.vuetifyjs.com/docs/images/graphics/mice/9.png"
      },
      {
        name: "Glorious Model O",
        color: "161, 252, 250",
        dpi: 12e3,
        buttons: 6,
        weight: "67g",
        wireless: false,
        price: 49.99,
        description: "Glorious Model O",
        src: "https://cdn.vuetifyjs.com/docs/images/graphics/mice/10.png"
      },
      {
        name: "HP Omen Photon",
        color: "201, 1, 2",
        dpi: 16e3,
        buttons: 11,
        weight: "128g",
        wireless: true,
        price: 99.99,
        description: "HP Omen Photon",
        src: "https://cdn.vuetifyjs.com/docs/images/graphics/mice/11.png"
      },
      {
        name: "Asus ROG Chakram",
        color: "10, 181, 19",
        dpi: 16e3,
        buttons: 9,
        weight: "121g",
        wireless: true,
        price: 159.99,
        description: "Asus ROG Chakram",
        src: "https://cdn.vuetifyjs.com/docs/images/graphics/mice/12.png"
      },
      {
        name: "Razer Naga X",
        color: "100, 101, 102",
        dpi: 16e3,
        buttons: 16,
        weight: "85g",
        wireless: false,
        price: 79.99,
        description: "Razer Naga X",
        src: "https://cdn.vuetifyjs.com/docs/images/graphics/mice/13.png"
      },
      {
        name: "Mad Catz R.A.T. 8+",
        color: "136, 241, 242",
        dpi: 16e3,
        buttons: 11,
        weight: "145g",
        wireless: false,
        price: 99.99,
        description: "Mad Catz R.A.T. 8+",
        src: "https://cdn.vuetifyjs.com/docs/images/graphics/mice/14.png"
      },
      {
        name: "Alienware 610M",
        color: "109, 110, 114",
        dpi: 16e3,
        buttons: 7,
        weight: "120g",
        wireless: true,
        price: 99.99,
        description: "Alienware 610M",
        src: "https://cdn.vuetifyjs.com/docs/images/graphics/mice/15.png"
      }
    ];
    return (_ctx, _cache) => {
      const _component_v_img = resolveComponent("v-img");
      const _component_v_list_item = resolveComponent("v-list-item");
      const _component_v_table = resolveComponent("v-table");
      const _component_v_sheet = resolveComponent("v-sheet");
      const _component_v_col = resolveComponent("v-col");
      const _component_v_row = resolveComponent("v-row");
      const _component_v_skeleton_loader = resolveComponent("v-skeleton-loader");
      const _component_v_data_iterator = resolveComponent("v-data-iterator");
      return openBlock(), createBlock(_component_v_data_iterator, {
        items: mice,
        "items-per-page": itemsPerPage.value,
        loading: true
      }, {
        default: withCtx(({ items }) => [
          createVNode(_component_v_row, null, {
            default: withCtx(() => [
              (openBlock(true), createElementBlock(Fragment, null, renderList(items, (item, i) => {
                return openBlock(), createBlock(_component_v_col, {
                  key: i,
                  cols: "12",
                  sm: "6",
                  xl: "3"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_v_sheet, { border: "" }, {
                      default: withCtx(() => [
                        createVNode(_component_v_img, {
                          gradient: `to top right, rgba(255, 255, 255, .1), rgba(${item.raw.color}, .15)`,
                          src: item.raw.src,
                          height: "150",
                          cover: ""
                        }, null, 8, ["gradient", "src"]),
                        createVNode(_component_v_list_item, {
                          title: item.raw.name,
                          density: "comfortable",
                          lines: "two",
                          subtitle: "Lorem ipsum dil orei namdie dkaf"
                        }, {
                          title: withCtx(() => [
                            createBaseVNode("strong", _hoisted_1$1, toDisplayString(item.raw.name), 1)
                          ]),
                          _: 2
                        }, 1032, ["title"]),
                        createVNode(_component_v_table, {
                          class: "text-caption",
                          density: "compact"
                        }, {
                          default: withCtx(() => [
                            createBaseVNode("tbody", null, [
                              createBaseVNode("tr", _hoisted_2, [
                                _hoisted_3,
                                createBaseVNode("td", null, toDisplayString(item.raw.dpi), 1)
                              ]),
                              createBaseVNode("tr", _hoisted_4, [
                                _hoisted_5,
                                createBaseVNode("td", null, toDisplayString(item.raw.buttons), 1)
                              ]),
                              createBaseVNode("tr", _hoisted_6, [
                                _hoisted_7,
                                createBaseVNode("td", null, toDisplayString(item.raw.weight), 1)
                              ]),
                              createBaseVNode("tr", _hoisted_8, [
                                _hoisted_9,
                                createBaseVNode("td", null, toDisplayString(item.raw.wireless ? "Yes" : "No"), 1)
                              ]),
                              createBaseVNode("tr", _hoisted_10, [
                                _hoisted_11,
                                createBaseVNode("td", null, "$" + toDisplayString(item.raw.price), 1)
                              ])
                            ])
                          ]),
                          _: 2
                        }, 1024)
                      ]),
                      _: 2
                    }, 1024)
                  ]),
                  _: 2
                }, 1024);
              }), 128))
            ]),
            _: 2
          }, 1024)
        ]),
        loader: withCtx(() => [
          createVNode(_component_v_row, null, {
            default: withCtx(() => [
              (openBlock(), createElementBlock(Fragment, null, renderList([0, 1, 2, 3], (_, k) => {
                return createVNode(_component_v_col, {
                  key: k,
                  cols: "12",
                  sm: "6",
                  xl: "3"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_v_skeleton_loader, {
                      class: "border",
                      type: "image, article"
                    })
                  ]),
                  _: 2
                }, 1024);
              }), 64))
            ]),
            _: 1
          })
        ]),
        _: 1
      }, 8, ["items-per-page"]);
    };
  }
};
const __3 = _sfc_main$1;
const __3_raw = `<template>
  <v-data-iterator
    :items="mice"
    :items-per-page="itemsPerPage"
    :loading="true"
  >
    <template v-slot:default="{ items }">
      <v-row>
        <v-col
          v-for="(item, i) in items"
          :key="i"
          cols="12"
          sm="6"
          xl="3"
        >
          <v-sheet border>
            <v-img
              :gradient="\`to top right, rgba(255, 255, 255, .1), rgba(\${item.raw.color}, .15)\`"
              :src="item.raw.src"
              height="150"
              cover
            ></v-img>

            <v-list-item
              :title="item.raw.name"
              density="comfortable"
              lines="two"
              subtitle="Lorem ipsum dil orei namdie dkaf"
            >
              <template v-slot:title>
                <strong class="text-h6">
                  {{ item.raw.name }}
                </strong>
              </template>
            </v-list-item>

            <v-table class="text-caption" density="compact">
              <tbody>
                <tr align="right">
                  <th>DPI:</th>

                  <td>{{ item.raw.dpi }}</td>
                </tr>

                <tr align="right">
                  <th>Buttons:</th>

                  <td>{{ item.raw.buttons }}</td>
                </tr>

                <tr align="right">
                  <th>Weight:</th>

                  <td>{{ item.raw.weight }}</td>
                </tr>

                <tr align="right">
                  <th>Wireless:</th>

                  <td>{{ item.raw.wireless ? 'Yes' : 'No' }}</td>
                </tr>

                <tr align="right">
                  <th>Price:</th>

                  <td>\${{ item.raw.price }}</td>
                </tr>
              </tbody>
            </v-table>
          </v-sheet>
        </v-col>
      </v-row>
    </template>

    <template v-slot:loader>
      <v-row>
        <v-col
          v-for="(_, k) in [0, 1, 2, 3]"
          :key="k"
          cols="12"
          sm="6"
          xl="3"
        >
          <v-skeleton-loader
            class="border"
            type="image, article"
          ></v-skeleton-loader>
        </v-col>
      </v-row>
    </template>

  </v-data-iterator>
</template>

<script setup>
  import { shallowRef } from 'vue'

  const itemsPerPage = shallowRef(4)
  const mice = [
    {
      name: 'Logitech G Pro X',
      color: '14, 151, 210',
      dpi: 16000,
      buttons: 8,
      weight: '63g',
      wireless: true,
      price: 149.99,
      description: 'Logitech G Pro X',
      src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/1.png',
    },
    {
      name: 'Razer DeathAdder V2',
      color: '12, 146, 47',
      dpi: 20000,
      buttons: 8,
      weight: '82g',
      wireless: false,
      price: 69.99,
      description: 'Razer DeathAdder V2',
      src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/2.png',
    },
    {
      name: 'Corsair Dark Core RGB',
      color: '107, 187, 226',
      dpi: 18000,
      buttons: 9,
      weight: '133g',
      wireless: true,
      price: 89.99,
      description: 'Corsair Dark Core RGB',
      src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/3.png',
    },
    {
      name: 'SteelSeries Rival 3',
      color: '228, 196, 69',
      dpi: 8500,
      buttons: 6,
      weight: '77g',
      wireless: false,
      price: 29.99,
      description: 'SteelSeries Rival 3',
      src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/4.png',
    },
    {
      name: 'HyperX Pulsefire FPS Pro',
      color: '156, 82, 251',
      dpi: 16000,
      buttons: 6,
      weight: '95g',
      wireless: false,
      price: 44.99,
      description: 'HyperX Pulsefire FPS Pro',
      src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/5.png',
    },
    {
      name: 'Zowie EC2',
      color: '166, 39, 222',
      dpi: 3200,
      buttons: 5,
      weight: '90g',
      wireless: false,
      price: 69.99,
      description: 'Zowie EC2',
      src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/6.png',
    },
    {
      name: 'Roccat Kone AIMO',
      color: '131, 9, 10',
      dpi: 16000,
      buttons: 10,
      weight: '130g',
      wireless: false,
      price: 79.99,
      description: 'Roccat Kone AIMO',
      src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/7.png',
    },
    {
      name: 'Logitech G903',
      color: '232, 94, 102',
      dpi: 12000,
      buttons: 11,
      weight: '110g',
      wireless: true,
      price: 129.99,
      description: 'Logitech G903',
      src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/8.png',
    },
    {
      name: 'Cooler Master MM711',
      color: '58, 192, 239',
      dpi: 16000,
      buttons: 6,
      weight: '60g',
      wireless: false,
      price: 49.99,
      description: 'Cooler Master MM711',
      src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/9.png',
    },
    {
      name: 'Glorious Model O',
      color: '161, 252, 250',
      dpi: 12000,
      buttons: 6,
      weight: '67g',
      wireless: false,
      price: 49.99,
      description: 'Glorious Model O',
      src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/10.png',
    },
    {
      name: 'HP Omen Photon',
      color: '201, 1, 2',
      dpi: 16000,
      buttons: 11,
      weight: '128g',
      wireless: true,
      price: 99.99,
      description: 'HP Omen Photon',
      src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/11.png',
    },
    {
      name: 'Asus ROG Chakram',
      color: '10, 181, 19',
      dpi: 16000,
      buttons: 9,
      weight: '121g',
      wireless: true,
      price: 159.99,
      description: 'Asus ROG Chakram',
      src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/12.png',
    },
    {
      name: 'Razer Naga X',
      color: '100, 101, 102',
      dpi: 16000,
      buttons: 16,
      weight: '85g',
      wireless: false,
      price: 79.99,
      description: 'Razer Naga X',
      src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/13.png',
    },
    {
      name: 'Mad Catz R.A.T. 8+',
      color: '136, 241, 242',
      dpi: 16000,
      buttons: 11,
      weight: '145g',
      wireless: false,
      price: 99.99,
      description: 'Mad Catz R.A.T. 8+',
      src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/14.png',
    },
    {
      name: 'Alienware 610M',
      color: '109, 110, 114',
      dpi: 16000,
      buttons: 7,
      weight: '120g',
      wireless: true,
      price: 99.99,
      description: 'Alienware 610M',
      src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/15.png',
    },
  ]
<\/script>

<script>
  export default {
    data () {
      return {
        itemsPerPage: 4,
        mice: [
          {
            name: 'Logitech G Pro X',
            color: '14, 151, 210',
            dpi: 16000,
            buttons: 8,
            weight: '63g',
            wireless: true,
            price: 149.99,
            description: 'Logitech G Pro X',
            src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/1.png',
          },
          {
            name: 'Razer DeathAdder V2',
            color: '12, 146, 47',
            dpi: 20000,
            buttons: 8,
            weight: '82g',
            wireless: false,
            price: 69.99,
            description: 'Razer DeathAdder V2',
            src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/2.png',
          },
          {
            name: 'Corsair Dark Core RGB',
            color: '107, 187, 226',
            dpi: 18000,
            buttons: 9,
            weight: '133g',
            wireless: true,
            price: 89.99,
            description: 'Corsair Dark Core RGB',
            src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/3.png',
          },
          {
            name: 'SteelSeries Rival 3',
            color: '228, 196, 69',
            dpi: 8500,
            buttons: 6,
            weight: '77g',
            wireless: false,
            price: 29.99,
            description: 'SteelSeries Rival 3',
            src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/4.png',
          },
          {
            name: 'HyperX Pulsefire FPS Pro',
            color: '156, 82, 251',
            dpi: 16000,
            buttons: 6,
            weight: '95g',
            wireless: false,
            price: 44.99,
            description: 'HyperX Pulsefire FPS Pro',
            src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/5.png',
          },
          {
            name: 'Zowie EC2',
            color: '166, 39, 222',
            dpi: 3200,
            buttons: 5,
            weight: '90g',
            wireless: false,
            price: 69.99,
            description: 'Zowie EC2',
            src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/6.png',
          },
          {
            name: 'Roccat Kone AIMO',
            color: '131, 9, 10',
            dpi: 16000,
            buttons: 10,
            weight: '130g',
            wireless: false,
            price: 79.99,
            description: 'Roccat Kone AIMO',
            src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/7.png',
          },
          {
            name: 'Logitech G903',
            color: '232, 94, 102',
            dpi: 12000,
            buttons: 11,
            weight: '110g',
            wireless: true,
            price: 129.99,
            description: 'Logitech G903',
            src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/8.png',
          },
          {
            name: 'Cooler Master MM711',
            color: '58, 192, 239',
            dpi: 16000,
            buttons: 6,
            weight: '60g',
            wireless: false,
            price: 49.99,
            description: 'Cooler Master MM711',
            src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/9.png',
          },
          {
            name: 'Glorious Model O',
            color: '161, 252, 250',
            dpi: 12000,
            buttons: 6,
            weight: '67g',
            wireless: false,
            price: 49.99,
            description: 'Glorious Model O',
            src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/10.png',
          },
          {
            name: 'HP Omen Photon',
            color: '201, 1, 2',
            dpi: 16000,
            buttons: 11,
            weight: '128g',
            wireless: true,
            price: 99.99,
            description: 'HP Omen Photon',
            src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/11.png',
          },
          {
            name: 'Asus ROG Chakram',
            color: '10, 181, 19',
            dpi: 16000,
            buttons: 9,
            weight: '121g',
            wireless: true,
            price: 159.99,
            description: 'Asus ROG Chakram',
            src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/12.png',
          },
          {
            name: 'Razer Naga X',
            color: '100, 101, 102',
            dpi: 16000,
            buttons: 16,
            weight: '85g',
            wireless: false,
            price: 79.99,
            description: 'Razer Naga X',
            src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/13.png',
          },
          {
            name: 'Mad Catz R.A.T. 8+',
            color: '136, 241, 242',
            dpi: 16000,
            buttons: 11,
            weight: '145g',
            wireless: false,
            price: 99.99,
            description: 'Mad Catz R.A.T. 8+',
            src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/14.png',
          },
          {
            name: 'Alienware 610M',
            color: '109, 110, 114',
            dpi: 16000,
            buttons: 7,
            weight: '120g',
            wireless: true,
            price: 99.99,
            description: 'Alienware 610M',
            src: 'https://cdn.vuetifyjs.com/docs/images/graphics/mice/15.png',
          },
        ],
      }
    },
  }
<\/script>
`;
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const name = "v-data-iterator";
const _sfc_main = {
  __name: "usage",
  setup(__props) {
    const model = ref("default");
    const options = [];
    const page = ref(1);
    const cards = Array.from({ length: 15 }, (k, v) => ({
      title: `Item ${v + 1}`,
      text: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!"
    }));
    const props = computed(() => {
      return {
        ":items": "items",
        ":page": "page"
      };
    });
    const slots = computed(() => {
      return `
  <template v-slot:default="{ items }">
    <template
      v-for="(item, i) in items"
      :key="i"
    >
      <v-card v-bind="item.raw"></v-card>

      <br>
    </template>
  </template>
`;
    });
    const code = computed(() => {
      return `<v-data-iterator${propsToString(props.value)}>${slots.value}</v-data-iterator>`;
    });
    const script = computed(() => {
      return `<script setup>
  import { ref } from 'vue'

  const page = ref(1)
  const items = Array.from({ length: 15 }, (k, v) => ({
    title: 'Item ' + v + 1,
    text: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!',
  }))
<\/script>`;
    });
    return (_ctx, _cache) => {
      const _component_v_card = resolveComponent("v-card");
      const _component_v_pagination = resolveComponent("v-pagination");
      const _component_v_data_iterator = resolveComponent("v-data-iterator");
      const _component_ExamplesUsageExample = _sfc_main$5;
      return openBlock(), createBlock(_component_ExamplesUsageExample, {
        modelValue: unref(model),
        "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(model) ? model.value = $event : null),
        code: unref(code),
        name,
        options,
        script: unref(script)
      }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createVNode(_component_v_data_iterator, mergeProps(unref(props), {
              items: unref(cards),
              page: unref(page),
              "items-per-page": "3"
            }), {
              default: withCtx(({ items }) => [
                (openBlock(true), createElementBlock(Fragment, null, renderList(items, (item, i) => {
                  return openBlock(), createElementBlock(Fragment, { key: i }, [
                    createVNode(_component_v_card, normalizeProps(guardReactiveProps(item.raw)), null, 16),
                    _hoisted_1
                  ], 64);
                }), 128))
              ]),
              footer: withCtx(({ pageCount }) => [
                createVNode(_component_v_pagination, {
                  modelValue: unref(page),
                  "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(page) ? page.value = $event : null),
                  length: pageCount
                }, null, 8, ["modelValue", "length"])
              ]),
              _: 1
            }, 16, ["items", "page"])
          ])
        ]),
        _: 1
      }, 8, ["modelValue", "code", "script"]);
    };
  }
};
const __4 = _sfc_main;
const __4_raw = `<template>
  <ExamplesUsageExample
    v-model="model"
    :code="code"
    :name="name"
    :options="options"
    :script="script"
  >
    <div>
      <v-data-iterator
        v-bind="props"
        :items="cards"
        :page="page"
        items-per-page="3"
      >
        <template v-slot:default="{ items }">
          <template
            v-for="(item, i) in items"
            :key="i"
          >
            <v-card v-bind="item.raw"></v-card>

            <br>
          </template>
        </template>

        <template v-slot:footer="{ pageCount }">
          <v-pagination v-model="page" :length="pageCount"></v-pagination>
        </template>
      </v-data-iterator>
    </div>
  </ExamplesUsageExample>
</template>

<script setup>
  const name = 'v-data-iterator'
  const model = ref('default')
  const options = []

  const page = ref(1)

  const cards = Array.from({ length: 15 }, (k, v) => ({
    title: \`Item \${v + 1}\`,
    text: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!',
  }))

  const props = computed(() => {
    return {
      ':items': 'items',
      ':page': 'page',
    }
  })

  const slots = computed(() => {
    return \`
  <template v-slot:default="{ items }">
    <template
      v-for="(item, i) in items"
      :key="i"
    >
      <v-card v-bind="item.raw"></v-card>

      <br>
    </template>
  </template>
\`
  })

  const code = computed(() => {
    return \`<v-data-iterator\${propsToString(props.value)}>\${slots.value}</v-data-iterator>\`
  })

  const script = computed(() => {
    return \`<script setup>
  import { ref } from 'vue'

  const page = ref(1)
  const items = Array.from({ length: 15 }, (k, v) => ({
    title: 'Item ' + v + 1,
    text: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima, at placeat totam, magni doloremque veniam neque porro libero rerum unde voluptatem!',
  }))
<\` + '/script>'
  })
<\/script>
`;
const vDataIterator = {
  "misc-filter": {
    component: __0,
    source: __0_raw
  },
  "slot-default": {
    component: __1,
    source: __1_raw
  },
  "slot-header-and-footer": {
    component: __2,
    source: __2_raw
  },
  "slot-loader": {
    component: __3,
    source: __3_raw
  },
  "usage": {
    component: __4,
    source: __4_raw
  }
};
export {
  vDataIterator as default
};
