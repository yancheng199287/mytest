import { r as resolveComponent, o as openBlock, c as createBlock, J as ref, j as computed, O as watch, w as withCtx, b as createVNode, h as createTextVNode, a9 as mergeProps, e as createBaseVNode, t as toDisplayString, W as nextTick, l as createElementBlock, y as _export_sfc, F as Fragment, v as renderList, q as createCommentVNode, B as shallowRef, S as createSlots, ar as toHandlers, ag as propsToString, f as unref, E as isRef } from "./index-DGybHjCP.js";
import { _ as _sfc_main$A } from "./UsageExample-M8CmNipa.js";
const _sfc_main$z = {
  __name: "headers-multiple",
  setup(__props) {
    const headers = [
      { title: "Pyramid", value: "name" },
      { title: "Location", value: "location" },
      { title: "Construction Date", value: "constructionDate" },
      {
        title: "Dimensions",
        align: "center",
        children: [
          { title: "Height (m)", value: "height" },
          { title: "Base (m)", value: "base" },
          { title: "Volume (m³)", value: "volume" }
        ]
      }
    ];
    const items = [
      {
        name: "Great Pyramid of Giza",
        location: "Egypt",
        height: "146.6",
        base: "230.4",
        volume: "2583285",
        constructionDate: "c. 2580–2560 BC"
      },
      {
        name: "Pyramid of Khafre",
        location: "Egypt",
        height: "136.4",
        base: "215.3",
        volume: "1477485",
        constructionDate: "c. 2570 BC"
      },
      {
        name: "Red Pyramid",
        location: "Egypt",
        height: "104",
        base: "220",
        volume: "1602895",
        constructionDate: "c. 2590 BC"
      },
      {
        name: "Bent Pyramid",
        location: "Egypt",
        height: "101.1",
        base: "188.6",
        volume: "1200690",
        constructionDate: "c. 2600 BC"
      },
      {
        name: "Pyramid of the Sun",
        location: "Mexico",
        height: "65",
        base: "225",
        volume: "1237097",
        constructionDate: "c. 200 CE"
      }
    ];
    return (_ctx, _cache) => {
      const _component_v_data_table = resolveComponent("v-data-table");
      return openBlock(), createBlock(_component_v_data_table, {
        headers,
        items,
        "item-key": "name",
        "items-per-page": "5"
      });
    };
  }
};
const __0 = _sfc_main$z;
const __0_raw = `<template>
  <v-data-table
    :headers="headers"
    :items="items"
    item-key="name"
    items-per-page="5"
  ></v-data-table>
</template>

<script setup>
  const headers = [
    { title: 'Pyramid', value: 'name' },
    { title: 'Location', value: 'location' },
    { title: 'Construction Date', value: 'constructionDate' },
    {
      title: 'Dimensions',
      align: 'center',
      children: [
        { title: 'Height (m)', value: 'height' },
        { title: 'Base (m)', value: 'base' },
        { title: 'Volume (m³)', value: 'volume' },
      ],
    },
  ]

  const items = [
    {
      name: 'Great Pyramid of Giza',
      location: 'Egypt',
      height: '146.6',
      base: '230.4',
      volume: '2583285',
      constructionDate: 'c. 2580–2560 BC',
    },
    {
      name: 'Pyramid of Khafre',
      location: 'Egypt',
      height: '136.4',
      base: '215.3',
      volume: '1477485',
      constructionDate: 'c. 2570 BC',
    },
    {
      name: 'Red Pyramid',
      location: 'Egypt',
      height: '104',
      base: '220',
      volume: '1602895',
      constructionDate: 'c. 2590 BC',
    },
    {
      name: 'Bent Pyramid',
      location: 'Egypt',
      height: '101.1',
      base: '188.6',
      volume: '1200690',
      constructionDate: 'c. 2600 BC',
    },
    {
      name: 'Pyramid of the Sun',
      location: 'Mexico',
      height: '65',
      base: '225',
      volume: '1237097',
      constructionDate: 'c. 200 CE',
    },
  ]
<\/script>

<script>
  export default {
    data: () => ({
      headers: [
        { title: 'Pyramid', value: 'name' },
        { title: 'Location', value: 'location' },
        { title: 'Construction Date', value: 'constructionDate' },
        {
          title: 'Dimensions',
          align: 'center',
          children: [
            { title: 'Height (m)', value: 'height' },
            { title: 'Base (m)', value: 'base' },
            { title: 'Volume (m³)', value: 'volume' },
          ],
        },
      ],
      desserts: [
        {
          name: 'Great Pyramid of Giza',
          location: 'Egypt',
          height: '146.6',
          base: '230.4',
          volume: '2583285',
          constructionDate: 'c. 2580–2560 BC',
        },
        {
          name: 'Pyramid of Khafre',
          location: 'Egypt',
          height: '136.4',
          base: '215.3',
          volume: '1477485',
          constructionDate: 'c. 2570 BC',
        },
        {
          name: 'Red Pyramid',
          location: 'Egypt',
          height: '104',
          base: '220',
          volume: '1602895',
          constructionDate: 'c. 2590 BC',
        },
        {
          name: 'Bent Pyramid',
          location: 'Egypt',
          height: '101.1',
          base: '188.6',
          volume: '1200690',
          constructionDate: 'c. 2600 BC',
        },
        {
          name: 'Pyramid of the Sun',
          location: 'Mexico',
          height: '65',
          base: '225',
          volume: '1237097',
          constructionDate: 'c. 200 CE',
        },
      ],
    }),
  }
<\/script>
`;
const _hoisted_1$9 = { class: "text-h5" };
const _sfc_main$y = {
  __name: "misc-crud",
  setup(__props) {
    const dialog = ref(false);
    const dialogDelete = ref(false);
    const headers = ref([
      {
        title: "Dessert (100g serving)",
        align: "start",
        sortable: false,
        key: "name"
      },
      { title: "Calories", key: "calories" },
      { title: "Fat (g)", key: "fat" },
      { title: "Carbs (g)", key: "carbs" },
      { title: "Protein (g)", key: "protein" },
      { title: "Actions", key: "actions", sortable: false }
    ]);
    const desserts2 = ref([]);
    const editedIndex = ref(-1);
    const editedItem = ref({
      name: "",
      calories: 0,
      fat: 0,
      carbs: 0,
      protein: 0
    });
    const defaultItem = ref({
      name: "",
      calories: 0,
      fat: 0,
      carbs: 0,
      protein: 0
    });
    const formTitle = computed(() => {
      return editedIndex.value === -1 ? "New Item" : "Edit Item";
    });
    function initialize() {
      desserts2.value = [
        {
          name: "Frozen Yogurt",
          calories: 159,
          fat: 6,
          carbs: 24,
          protein: 4
        },
        {
          name: "Ice cream sandwich",
          calories: 237,
          fat: 9,
          carbs: 37,
          protein: 4.3
        },
        {
          name: "Eclair",
          calories: 262,
          fat: 16,
          carbs: 23,
          protein: 6
        },
        {
          name: "Cupcake",
          calories: 305,
          fat: 3.7,
          carbs: 67,
          protein: 4.3
        },
        {
          name: "Gingerbread",
          calories: 356,
          fat: 16,
          carbs: 49,
          protein: 3.9
        },
        {
          name: "Jelly bean",
          calories: 375,
          fat: 0,
          carbs: 94,
          protein: 0
        },
        {
          name: "Lollipop",
          calories: 392,
          fat: 0.2,
          carbs: 98,
          protein: 0
        },
        {
          name: "Honeycomb",
          calories: 408,
          fat: 3.2,
          carbs: 87,
          protein: 6.5
        },
        {
          name: "Donut",
          calories: 452,
          fat: 25,
          carbs: 51,
          protein: 4.9
        },
        {
          name: "KitKat",
          calories: 518,
          fat: 26,
          carbs: 65,
          protein: 7
        }
      ];
    }
    function editItem(item) {
      editedIndex.value = desserts2.value.indexOf(item);
      editedItem.value = Object.assign({}, item);
      dialog.value = true;
    }
    function deleteItem(item) {
      editedIndex.value = desserts2.value.indexOf(item);
      editedItem.value = Object.assign({}, item);
      dialogDelete.value = true;
    }
    function deleteItemConfirm() {
      desserts2.value.splice(editedIndex.value, 1);
      closeDelete();
    }
    function close() {
      dialog.value = false;
      nextTick(() => {
        editedItem.value = Object.assign({}, defaultItem.value);
        editedIndex.value = -1;
      });
    }
    function closeDelete() {
      dialogDelete.value = false;
      nextTick(() => {
        editedItem.value = Object.assign({}, defaultItem.value);
        editedIndex.value = -1;
      });
    }
    function save() {
      if (editedIndex.value > -1) {
        Object.assign(desserts2.value[editedIndex.value], editedItem.value);
      } else {
        desserts2.value.push(editedItem.value);
      }
      close();
    }
    watch(dialog, (val) => {
      val || close();
    });
    watch(dialogDelete, (val) => {
      val || closeDelete();
    });
    initialize();
    return (_ctx, _cache) => {
      const _component_v_toolbar_title = resolveComponent("v-toolbar-title");
      const _component_v_divider = resolveComponent("v-divider");
      const _component_v_spacer = resolveComponent("v-spacer");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_card_title = resolveComponent("v-card-title");
      const _component_v_text_field = resolveComponent("v-text-field");
      const _component_v_col = resolveComponent("v-col");
      const _component_v_row = resolveComponent("v-row");
      const _component_v_container = resolveComponent("v-container");
      const _component_v_card_text = resolveComponent("v-card-text");
      const _component_v_card_actions = resolveComponent("v-card-actions");
      const _component_v_card = resolveComponent("v-card");
      const _component_v_dialog = resolveComponent("v-dialog");
      const _component_v_toolbar = resolveComponent("v-toolbar");
      const _component_v_icon = resolveComponent("v-icon");
      const _component_v_data_table = resolveComponent("v-data-table");
      return openBlock(), createBlock(_component_v_data_table, {
        headers: headers.value,
        items: desserts2.value,
        "sort-by": [{ key: "calories", order: "asc" }]
      }, {
        top: withCtx(() => [
          createVNode(_component_v_toolbar, { flat: "" }, {
            default: withCtx(() => [
              createVNode(_component_v_toolbar_title, null, {
                default: withCtx(() => [
                  createTextVNode("My CRUD")
                ]),
                _: 1
              }),
              createVNode(_component_v_divider, {
                class: "mx-4",
                inset: "",
                vertical: ""
              }),
              createVNode(_component_v_spacer),
              createVNode(_component_v_dialog, {
                modelValue: dialog.value,
                "onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => dialog.value = $event),
                "max-width": "500px"
              }, {
                activator: withCtx(({ props }) => [
                  createVNode(_component_v_btn, mergeProps({
                    class: "mb-2",
                    color: "primary",
                    dark: ""
                  }, props), {
                    default: withCtx(() => [
                      createTextVNode(" New Item ")
                    ]),
                    _: 2
                  }, 1040)
                ]),
                default: withCtx(() => [
                  createVNode(_component_v_card, null, {
                    default: withCtx(() => [
                      createVNode(_component_v_card_title, null, {
                        default: withCtx(() => [
                          createBaseVNode("span", _hoisted_1$9, toDisplayString(formTitle.value), 1)
                        ]),
                        _: 1
                      }),
                      createVNode(_component_v_card_text, null, {
                        default: withCtx(() => [
                          createVNode(_component_v_container, null, {
                            default: withCtx(() => [
                              createVNode(_component_v_row, null, {
                                default: withCtx(() => [
                                  createVNode(_component_v_col, {
                                    cols: "12",
                                    md: "4",
                                    sm: "6"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_v_text_field, {
                                        modelValue: editedItem.value.name,
                                        "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => editedItem.value.name = $event),
                                        label: "Dessert name"
                                      }, null, 8, ["modelValue"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_v_col, {
                                    cols: "12",
                                    md: "4",
                                    sm: "6"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_v_text_field, {
                                        modelValue: editedItem.value.calories,
                                        "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => editedItem.value.calories = $event),
                                        label: "Calories"
                                      }, null, 8, ["modelValue"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_v_col, {
                                    cols: "12",
                                    md: "4",
                                    sm: "6"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_v_text_field, {
                                        modelValue: editedItem.value.fat,
                                        "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => editedItem.value.fat = $event),
                                        label: "Fat (g)"
                                      }, null, 8, ["modelValue"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_v_col, {
                                    cols: "12",
                                    md: "4",
                                    sm: "6"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_v_text_field, {
                                        modelValue: editedItem.value.carbs,
                                        "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => editedItem.value.carbs = $event),
                                        label: "Carbs (g)"
                                      }, null, 8, ["modelValue"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_v_col, {
                                    cols: "12",
                                    md: "4",
                                    sm: "6"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_v_text_field, {
                                        modelValue: editedItem.value.protein,
                                        "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => editedItem.value.protein = $event),
                                        label: "Protein (g)"
                                      }, null, 8, ["modelValue"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_v_card_actions, null, {
                        default: withCtx(() => [
                          createVNode(_component_v_spacer),
                          createVNode(_component_v_btn, {
                            color: "blue-darken-1",
                            variant: "text",
                            onClick: close
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Cancel ")
                            ]),
                            _: 1
                          }),
                          createVNode(_component_v_btn, {
                            color: "blue-darken-1",
                            variant: "text",
                            onClick: save
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Save ")
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }, 8, ["modelValue"]),
              createVNode(_component_v_dialog, {
                modelValue: dialogDelete.value,
                "onUpdate:modelValue": _cache[6] || (_cache[6] = ($event) => dialogDelete.value = $event),
                "max-width": "500px"
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_card, null, {
                    default: withCtx(() => [
                      createVNode(_component_v_card_title, { class: "text-h5" }, {
                        default: withCtx(() => [
                          createTextVNode("Are you sure you want to delete this item?")
                        ]),
                        _: 1
                      }),
                      createVNode(_component_v_card_actions, null, {
                        default: withCtx(() => [
                          createVNode(_component_v_spacer),
                          createVNode(_component_v_btn, {
                            color: "blue-darken-1",
                            variant: "text",
                            onClick: closeDelete
                          }, {
                            default: withCtx(() => [
                              createTextVNode("Cancel")
                            ]),
                            _: 1
                          }),
                          createVNode(_component_v_btn, {
                            color: "blue-darken-1",
                            variant: "text",
                            onClick: deleteItemConfirm
                          }, {
                            default: withCtx(() => [
                              createTextVNode("OK")
                            ]),
                            _: 1
                          }),
                          createVNode(_component_v_spacer)
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }, 8, ["modelValue"])
            ]),
            _: 1
          })
        ]),
        "item.actions": withCtx(({ item }) => [
          createVNode(_component_v_icon, {
            class: "me-2",
            size: "small",
            onClick: ($event) => editItem(item)
          }, {
            default: withCtx(() => [
              createTextVNode(" mdi-pencil ")
            ]),
            _: 2
          }, 1032, ["onClick"]),
          createVNode(_component_v_icon, {
            size: "small",
            onClick: ($event) => deleteItem(item)
          }, {
            default: withCtx(() => [
              createTextVNode(" mdi-delete ")
            ]),
            _: 2
          }, 1032, ["onClick"])
        ]),
        "no-data": withCtx(() => [
          createVNode(_component_v_btn, {
            color: "primary",
            onClick: initialize
          }, {
            default: withCtx(() => [
              createTextVNode(" Reset ")
            ]),
            _: 1
          })
        ]),
        _: 1
      }, 8, ["headers", "items"]);
    };
  }
};
const __1 = _sfc_main$y;
const __1_raw = `<template>
  <v-data-table
    :headers="headers"
    :items="desserts"
    :sort-by="[{ key: 'calories', order: 'asc' }]"
  >
    <template v-slot:top>
      <v-toolbar
        flat
      >
        <v-toolbar-title>My CRUD</v-toolbar-title>
        <v-divider
          class="mx-4"
          inset
          vertical
        ></v-divider>
        <v-spacer></v-spacer>
        <v-dialog
          v-model="dialog"
          max-width="500px"
        >
          <template v-slot:activator="{ props }">
            <v-btn
              class="mb-2"
              color="primary"
              dark
              v-bind="props"
            >
              New Item
            </v-btn>
          </template>
          <v-card>
            <v-card-title>
              <span class="text-h5">{{ formTitle }}</span>
            </v-card-title>

            <v-card-text>
              <v-container>
                <v-row>
                  <v-col
                    cols="12"
                    md="4"
                    sm="6"
                  >
                    <v-text-field
                      v-model="editedItem.name"
                      label="Dessert name"
                    ></v-text-field>
                  </v-col>
                  <v-col
                    cols="12"
                    md="4"
                    sm="6"
                  >
                    <v-text-field
                      v-model="editedItem.calories"
                      label="Calories"
                    ></v-text-field>
                  </v-col>
                  <v-col
                    cols="12"
                    md="4"
                    sm="6"
                  >
                    <v-text-field
                      v-model="editedItem.fat"
                      label="Fat (g)"
                    ></v-text-field>
                  </v-col>
                  <v-col
                    cols="12"
                    md="4"
                    sm="6"
                  >
                    <v-text-field
                      v-model="editedItem.carbs"
                      label="Carbs (g)"
                    ></v-text-field>
                  </v-col>
                  <v-col
                    cols="12"
                    md="4"
                    sm="6"
                  >
                    <v-text-field
                      v-model="editedItem.protein"
                      label="Protein (g)"
                    ></v-text-field>
                  </v-col>
                </v-row>
              </v-container>
            </v-card-text>

            <v-card-actions>
              <v-spacer></v-spacer>
              <v-btn
                color="blue-darken-1"
                variant="text"
                @click="close"
              >
                Cancel
              </v-btn>
              <v-btn
                color="blue-darken-1"
                variant="text"
                @click="save"
              >
                Save
              </v-btn>
            </v-card-actions>
          </v-card>
        </v-dialog>
        <v-dialog v-model="dialogDelete" max-width="500px">
          <v-card>
            <v-card-title class="text-h5">Are you sure you want to delete this item?</v-card-title>
            <v-card-actions>
              <v-spacer></v-spacer>
              <v-btn color="blue-darken-1" variant="text" @click="closeDelete">Cancel</v-btn>
              <v-btn color="blue-darken-1" variant="text" @click="deleteItemConfirm">OK</v-btn>
              <v-spacer></v-spacer>
            </v-card-actions>
          </v-card>
        </v-dialog>
      </v-toolbar>
    </template>
    <template v-slot:item.actions="{ item }">
      <v-icon
        class="me-2"
        size="small"
        @click="editItem(item)"
      >
        mdi-pencil
      </v-icon>
      <v-icon
        size="small"
        @click="deleteItem(item)"
      >
        mdi-delete
      </v-icon>
    </template>
    <template v-slot:no-data>
      <v-btn
        color="primary"
        @click="initialize"
      >
        Reset
      </v-btn>
    </template>
  </v-data-table>
</template>

<script setup>
  import { computed, nextTick, ref, watch } from 'vue'

  const dialog = ref(false)
  const dialogDelete = ref(false)
  const headers = ref([
    {
      title: 'Dessert (100g serving)',
      align: 'start',
      sortable: false,
      key: 'name',
    },
    { title: 'Calories', key: 'calories' },
    { title: 'Fat (g)', key: 'fat' },
    { title: 'Carbs (g)', key: 'carbs' },
    { title: 'Protein (g)', key: 'protein' },
    { title: 'Actions', key: 'actions', sortable: false },
  ])
  const desserts = ref([])
  const editedIndex = ref(-1)
  const editedItem = ref({
    name: '',
    calories: 0,
    fat: 0,
    carbs: 0,
    protein: 0,
  })
  const defaultItem = ref({
    name: '',
    calories: 0,
    fat: 0,
    carbs: 0,
    protein: 0,
  })
  const formTitle = computed(() => {
    return editedIndex.value === -1 ? 'New Item' : 'Edit Item'
  })
  function initialize () {
    desserts.value = [
      {
        name: 'Frozen Yogurt',
        calories: 159,
        fat: 6,
        carbs: 24,
        protein: 4,
      },
      {
        name: 'Ice cream sandwich',
        calories: 237,
        fat: 9,
        carbs: 37,
        protein: 4.3,
      },
      {
        name: 'Eclair',
        calories: 262,
        fat: 16,
        carbs: 23,
        protein: 6,
      },
      {
        name: 'Cupcake',
        calories: 305,
        fat: 3.7,
        carbs: 67,
        protein: 4.3,
      },
      {
        name: 'Gingerbread',
        calories: 356,
        fat: 16,
        carbs: 49,
        protein: 3.9,
      },
      {
        name: 'Jelly bean',
        calories: 375,
        fat: 0,
        carbs: 94,
        protein: 0,
      },
      {
        name: 'Lollipop',
        calories: 392,
        fat: 0.2,
        carbs: 98,
        protein: 0,
      },
      {
        name: 'Honeycomb',
        calories: 408,
        fat: 3.2,
        carbs: 87,
        protein: 6.5,
      },
      {
        name: 'Donut',
        calories: 452,
        fat: 25,
        carbs: 51,
        protein: 4.9,
      },
      {
        name: 'KitKat',
        calories: 518,
        fat: 26,
        carbs: 65,
        protein: 7,
      },
    ]
  }
  function editItem (item) {
    editedIndex.value = desserts.value.indexOf(item)
    editedItem.value = Object.assign({}, item)
    dialog.value = true
  }
  function deleteItem (item) {
    editedIndex.value = desserts.value.indexOf(item)
    editedItem.value = Object.assign({}, item)
    dialogDelete.value = true
  }
  function deleteItemConfirm () {
    desserts.value.splice(editedIndex.value, 1)
    closeDelete()
  }
  function close () {
    dialog.value = false
    nextTick(() => {
      editedItem.value = Object.assign({}, defaultItem.value)
      editedIndex.value = -1
    })
  }
  function closeDelete () {
    dialogDelete.value = false
    nextTick(() => {
      editedItem.value = Object.assign({}, defaultItem.value)
      editedIndex.value = -1
    })
  }
  function save () {
    if (editedIndex.value > -1) {
      Object.assign(desserts.value[editedIndex.value], editedItem.value)
    } else {
      desserts.value.push(editedItem.value)
    }
    close()
  }
  watch(dialog, val => {
    val || close()
  })
  watch(dialogDelete, val => {
    val || closeDelete()
  })
  initialize()
<\/script>

<script>
  export default {
    data: () => ({
      dialog: false,
      dialogDelete: false,
      headers: [
        {
          title: 'Dessert (100g serving)',
          align: 'start',
          sortable: false,
          key: 'name',
        },
        { title: 'Calories', key: 'calories' },
        { title: 'Fat (g)', key: 'fat' },
        { title: 'Carbs (g)', key: 'carbs' },
        { title: 'Protein (g)', key: 'protein' },
        { title: 'Actions', key: 'actions', sortable: false },
      ],
      desserts: [],
      editedIndex: -1,
      editedItem: {
        name: '',
        calories: 0,
        fat: 0,
        carbs: 0,
        protein: 0,
      },
      defaultItem: {
        name: '',
        calories: 0,
        fat: 0,
        carbs: 0,
        protein: 0,
      },
    }),

    computed: {
      formTitle () {
        return this.editedIndex === -1 ? 'New Item' : 'Edit Item'
      },
    },

    watch: {
      dialog (val) {
        val || this.close()
      },
      dialogDelete (val) {
        val || this.closeDelete()
      },
    },

    created () {
      this.initialize()
    },

    methods: {
      initialize () {
        this.desserts = [
          {
            name: 'Frozen Yogurt',
            calories: 159,
            fat: 6.0,
            carbs: 24,
            protein: 4.0,
          },
          {
            name: 'Ice cream sandwich',
            calories: 237,
            fat: 9.0,
            carbs: 37,
            protein: 4.3,
          },
          {
            name: 'Eclair',
            calories: 262,
            fat: 16.0,
            carbs: 23,
            protein: 6.0,
          },
          {
            name: 'Cupcake',
            calories: 305,
            fat: 3.7,
            carbs: 67,
            protein: 4.3,
          },
          {
            name: 'Gingerbread',
            calories: 356,
            fat: 16.0,
            carbs: 49,
            protein: 3.9,
          },
          {
            name: 'Jelly bean',
            calories: 375,
            fat: 0.0,
            carbs: 94,
            protein: 0.0,
          },
          {
            name: 'Lollipop',
            calories: 392,
            fat: 0.2,
            carbs: 98,
            protein: 0,
          },
          {
            name: 'Honeycomb',
            calories: 408,
            fat: 3.2,
            carbs: 87,
            protein: 6.5,
          },
          {
            name: 'Donut',
            calories: 452,
            fat: 25.0,
            carbs: 51,
            protein: 4.9,
          },
          {
            name: 'KitKat',
            calories: 518,
            fat: 26.0,
            carbs: 65,
            protein: 7,
          },
        ]
      },

      editItem (item) {
        this.editedIndex = this.desserts.indexOf(item)
        this.editedItem = Object.assign({}, item)
        this.dialog = true
      },

      deleteItem (item) {
        this.editedIndex = this.desserts.indexOf(item)
        this.editedItem = Object.assign({}, item)
        this.dialogDelete = true
      },

      deleteItemConfirm () {
        this.desserts.splice(this.editedIndex, 1)
        this.closeDelete()
      },

      close () {
        this.dialog = false
        this.$nextTick(() => {
          this.editedItem = Object.assign({}, this.defaultItem)
          this.editedIndex = -1
        })
      },

      closeDelete () {
        this.dialogDelete = false
        this.$nextTick(() => {
          this.editedItem = Object.assign({}, this.defaultItem)
          this.editedIndex = -1
        })
      },

      save () {
        if (this.editedIndex > -1) {
          Object.assign(this.desserts[this.editedIndex], this.editedItem)
        } else {
          this.desserts.push(this.editedItem)
        }
        this.close()
      },
    },
  }
<\/script>
`;
const _hoisted_1$8 = /* @__PURE__ */ createBaseVNode("div", { class: "mt-4 text-h6" }, " Update Iron ", -1);
const _sfc_main$x = {
  __name: "misc-edit-dialog",
  setup(__props) {
    const snack = ref(false);
    const snackColor = ref("");
    const snackText = ref("");
    const max25chars = ref((v) => v.length <= 25 || "Input too long!");
    const headers = ref([
      {
        text: "Dessert (100g serving)",
        align: "start",
        sortable: false,
        value: "name"
      },
      { text: "Calories", value: "calories" },
      { text: "Fat (g)", value: "fat" },
      { text: "Carbs (g)", value: "carbs" },
      { text: "Protein (g)", value: "protein" },
      { text: "Iron (%)", value: "iron" }
    ]);
    const desserts2 = ref([
      {
        name: "Frozen Yogurt",
        calories: 159,
        fat: 6,
        carbs: 24,
        protein: 4,
        iron: 1
      },
      {
        name: "Ice cream sandwich",
        calories: 237,
        fat: 9,
        carbs: 37,
        protein: 4.3,
        iron: 1
      },
      {
        name: "Eclair",
        calories: 262,
        fat: 16,
        carbs: 23,
        protein: 6,
        iron: 7
      },
      {
        name: "Cupcake",
        calories: 305,
        fat: 3.7,
        carbs: 67,
        protein: 4.3,
        iron: 8
      },
      {
        name: "Gingerbread",
        calories: 356,
        fat: 16,
        carbs: 49,
        protein: 3.9,
        iron: 16
      },
      {
        name: "Jelly bean",
        calories: 375,
        fat: 0,
        carbs: 94,
        protein: 0,
        iron: 0
      },
      {
        name: "Lollipop",
        calories: 392,
        fat: 0.2,
        carbs: 98,
        protein: 0,
        iron: 2
      },
      {
        name: "Honeycomb",
        calories: 408,
        fat: 3.2,
        carbs: 87,
        protein: 6.5,
        iron: 45
      },
      {
        name: "Donut",
        calories: 452,
        fat: 25,
        carbs: 51,
        protein: 4.9,
        iron: 22
      },
      {
        name: "KitKat",
        calories: 518,
        fat: 26,
        carbs: 65,
        protein: 7,
        iron: 6
      }
    ]);
    function save() {
      snack.value = true;
      snackColor.value = "success";
      snackText.value = "Data saved";
    }
    function cancel() {
      snack.value = true;
      snackColor.value = "error";
      snackText.value = "Canceled";
    }
    function open() {
      snack.value = true;
      snackColor.value = "info";
      snackText.value = "Dialog opened";
    }
    function close() {
      console.log("Dialog closed");
    }
    return (_ctx, _cache) => {
      const _component_v_text_field = resolveComponent("v-text-field");
      const _component_v_edit_dialog = resolveComponent("v-edit-dialog");
      const _component_v_data_table = resolveComponent("v-data-table");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_snackbar = resolveComponent("v-snackbar");
      return openBlock(), createElementBlock("div", null, [
        createVNode(_component_v_data_table, {
          headers: headers.value,
          items: desserts2.value
        }, {
          "item.name": withCtx((props) => [
            createVNode(_component_v_edit_dialog, {
              "return-value": props.item.name,
              "onUpdate:returnValue": ($event) => props.item.name = $event,
              onCancel: cancel,
              onClose: close,
              onOpen: open,
              onSave: save
            }, {
              input: withCtx(() => [
                createVNode(_component_v_text_field, {
                  modelValue: props.item.name,
                  "onUpdate:modelValue": ($event) => props.item.name = $event,
                  rules: [max25chars.value],
                  label: "Edit",
                  counter: "",
                  "single-line": ""
                }, null, 8, ["modelValue", "onUpdate:modelValue", "rules"])
              ]),
              default: withCtx(() => [
                createTextVNode(toDisplayString(props.item.name) + " ", 1)
              ]),
              _: 2
            }, 1032, ["return-value", "onUpdate:returnValue"])
          ]),
          "item.iron": withCtx((props) => [
            createVNode(_component_v_edit_dialog, {
              "return-value": props.item.iron,
              "onUpdate:returnValue": ($event) => props.item.iron = $event,
              large: "",
              persistent: "",
              onCancel: cancel,
              onClose: close,
              onOpen: open,
              onSave: save
            }, {
              input: withCtx(() => [
                _hoisted_1$8,
                createVNode(_component_v_text_field, {
                  modelValue: props.item.iron,
                  "onUpdate:modelValue": ($event) => props.item.iron = $event,
                  rules: [max25chars.value],
                  label: "Edit",
                  autofocus: "",
                  counter: "",
                  "single-line": ""
                }, null, 8, ["modelValue", "onUpdate:modelValue", "rules"])
              ]),
              default: withCtx(() => [
                createBaseVNode("div", null, toDisplayString(props.item.iron), 1)
              ]),
              _: 2
            }, 1032, ["return-value", "onUpdate:returnValue"])
          ]),
          _: 1
        }, 8, ["headers", "items"]),
        createVNode(_component_v_snackbar, {
          modelValue: snack.value,
          "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => snack.value = $event),
          color: snackColor.value,
          timeout: 3e3
        }, {
          action: withCtx(({ attrs }) => [
            createVNode(_component_v_btn, mergeProps(attrs, {
              variant: "text",
              onClick: _cache[0] || (_cache[0] = ($event) => snack.value = false)
            }), {
              default: withCtx(() => [
                createTextVNode(" Close ")
              ]),
              _: 2
            }, 1040)
          ]),
          default: withCtx(() => [
            createTextVNode(toDisplayString(snackText.value) + " ", 1)
          ]),
          _: 1
        }, 8, ["modelValue", "color"])
      ]);
    };
  }
};
const __2 = _sfc_main$x;
const __2_raw = `<template>
  <div>
    <v-data-table
      :headers="headers"
      :items="desserts"
    >
      <template v-slot:item.name="props">
        <v-edit-dialog
          v-model:return-value="props.item.name"
          @cancel="cancel"
          @close="close"
          @open="open"
          @save="save"
        >
          {{ props.item.name }}
          <template v-slot:input>
            <v-text-field
              v-model="props.item.name"
              :rules="[max25chars]"
              label="Edit"
              counter
              single-line
            ></v-text-field>
          </template>
        </v-edit-dialog>
      </template>
      <template v-slot:item.iron="props">
        <v-edit-dialog
          v-model:return-value="props.item.iron"
          large
          persistent
          @cancel="cancel"
          @close="close"
          @open="open"
          @save="save"
        >
          <div>{{ props.item.iron }}</div>
          <template v-slot:input>
            <div class="mt-4 text-h6">
              Update Iron
            </div>
            <v-text-field
              v-model="props.item.iron"
              :rules="[max25chars]"
              label="Edit"
              autofocus
              counter
              single-line
            ></v-text-field>
          </template>
        </v-edit-dialog>
      </template>
    </v-data-table>

    <v-snackbar
      v-model="snack"
      :color="snackColor"
      :timeout="3000"
    >
      {{ snackText }}

      <template v-slot:action="{ attrs }">
        <v-btn
          v-bind="attrs"
          variant="text"
          @click="snack = false"
        >
          Close
        </v-btn>
      </template>
    </v-snackbar>
  </div>
</template>

<script setup>
  import { ref } from 'vue'

  const snack = ref(false)
  const snackColor = ref('')
  const snackText = ref('')
  const max25chars = ref(v => v.length <= 25 || 'Input too long!')
  const headers = ref([
    {
      text: 'Dessert (100g serving)',
      align: 'start',
      sortable: false,
      value: 'name',
    },
    { text: 'Calories', value: 'calories' },
    { text: 'Fat (g)', value: 'fat' },
    { text: 'Carbs (g)', value: 'carbs' },
    { text: 'Protein (g)', value: 'protein' },
    { text: 'Iron (%)', value: 'iron' },
  ])
  const desserts = ref([
    {
      name: 'Frozen Yogurt',
      calories: 159,
      fat: 6,
      carbs: 24,
      protein: 4,
      iron: 1,
    },
    {
      name: 'Ice cream sandwich',
      calories: 237,
      fat: 9,
      carbs: 37,
      protein: 4.3,
      iron: 1,
    },
    {
      name: 'Eclair',
      calories: 262,
      fat: 16,
      carbs: 23,
      protein: 6,
      iron: 7,
    },
    {
      name: 'Cupcake',
      calories: 305,
      fat: 3.7,
      carbs: 67,
      protein: 4.3,
      iron: 8,
    },
    {
      name: 'Gingerbread',
      calories: 356,
      fat: 16,
      carbs: 49,
      protein: 3.9,
      iron: 16,
    },
    {
      name: 'Jelly bean',
      calories: 375,
      fat: 0,
      carbs: 94,
      protein: 0,
      iron: 0,
    },
    {
      name: 'Lollipop',
      calories: 392,
      fat: 0.2,
      carbs: 98,
      protein: 0,
      iron: 2,
    },
    {
      name: 'Honeycomb',
      calories: 408,
      fat: 3.2,
      carbs: 87,
      protein: 6.5,
      iron: 45,
    },
    {
      name: 'Donut',
      calories: 452,
      fat: 25,
      carbs: 51,
      protein: 4.9,
      iron: 22,
    },
    {
      name: 'KitKat',
      calories: 518,
      fat: 26,
      carbs: 65,
      protein: 7,
      iron: 6,
    },
  ])
  function save () {
    snack.value = true
    snackColor.value = 'success'
    snackText.value = 'Data saved'
  }
  function cancel () {
    snack.value = true
    snackColor.value = 'error'
    snackText.value = 'Canceled'
  }
  function open () {
    snack.value = true
    snackColor.value = 'info'
    snackText.value = 'Dialog opened'
  }
  function close () {
    console.log('Dialog closed')
  }
<\/script>

<script>
  export default {
    data () {
      return {
        snack: false,
        snackColor: '',
        snackText: '',
        max25chars: v => v.length <= 25 || 'Input too long!',
        headers: [
          {
            text: 'Dessert (100g serving)',
            align: 'start',
            sortable: false,
            value: 'name',
          },
          { text: 'Calories', value: 'calories' },
          { text: 'Fat (g)', value: 'fat' },
          { text: 'Carbs (g)', value: 'carbs' },
          { text: 'Protein (g)', value: 'protein' },
          { text: 'Iron (%)', value: 'iron' },
        ],
        desserts: [
          {
            name: 'Frozen Yogurt',
            calories: 159,
            fat: 6.0,
            carbs: 24,
            protein: 4.0,
            iron: 1,
          },
          {
            name: 'Ice cream sandwich',
            calories: 237,
            fat: 9.0,
            carbs: 37,
            protein: 4.3,
            iron: 1,
          },
          {
            name: 'Eclair',
            calories: 262,
            fat: 16.0,
            carbs: 23,
            protein: 6.0,
            iron: 7,
          },
          {
            name: 'Cupcake',
            calories: 305,
            fat: 3.7,
            carbs: 67,
            protein: 4.3,
            iron: 8,
          },
          {
            name: 'Gingerbread',
            calories: 356,
            fat: 16.0,
            carbs: 49,
            protein: 3.9,
            iron: 16,
          },
          {
            name: 'Jelly bean',
            calories: 375,
            fat: 0.0,
            carbs: 94,
            protein: 0.0,
            iron: 0,
          },
          {
            name: 'Lollipop',
            calories: 392,
            fat: 0.2,
            carbs: 98,
            protein: 0,
            iron: 2,
          },
          {
            name: 'Honeycomb',
            calories: 408,
            fat: 3.2,
            carbs: 87,
            protein: 6.5,
            iron: 45,
          },
          {
            name: 'Donut',
            calories: 452,
            fat: 25.0,
            carbs: 51,
            protein: 4.9,
            iron: 22,
          },
          {
            name: 'KitKat',
            calories: 518,
            fat: 26.0,
            carbs: 65,
            protein: 7,
            iron: 6,
          },
        ],
      }
    },
    methods: {
      save () {
        this.snack = true
        this.snackColor = 'success'
        this.snackText = 'Data saved'
      },
      cancel () {
        this.snack = true
        this.snackColor = 'error'
        this.snackText = 'Canceled'
      },
      open () {
        this.snack = true
        this.snackColor = 'info'
        this.snackText = 'Dialog opened'
      },
      close () {
        console.log('Dialog closed')
      },
    },
  }
<\/script>
`;
const _hoisted_1$7 = ["colspan"];
const _sfc_main$w = {
  __name: "misc-expand",
  setup(__props) {
    const expanded = ref([]);
    const dessertHeaders = ref([
      {
        title: "Dessert (100g serving)",
        align: "start",
        sortable: false,
        key: "name"
      },
      { title: "Calories", key: "calories" },
      { title: "Fat (g)", key: "fat" },
      { title: "Carbs (g)", key: "carbs" },
      { title: "Protein (g)", key: "protein" },
      { title: "Iron (%)", key: "iron" },
      { title: "", key: "data-table-expand" }
    ]);
    const desserts2 = ref([
      {
        name: "Frozen Yogurt",
        calories: 159,
        fat: 6,
        carbs: 24,
        protein: 4,
        iron: 1
      },
      {
        name: "Ice cream sandwich",
        calories: 237,
        fat: 9,
        carbs: 37,
        protein: 4.3,
        iron: 1
      },
      {
        name: "Eclair",
        calories: 262,
        fat: 16,
        carbs: 23,
        protein: 6,
        iron: 7
      },
      {
        name: "Cupcake",
        calories: 305,
        fat: 3.7,
        carbs: 67,
        protein: 4.3,
        iron: 8
      },
      {
        name: "Gingerbread",
        calories: 356,
        fat: 16,
        carbs: 49,
        protein: 3.9,
        iron: 16
      },
      {
        name: "Jelly bean",
        calories: 375,
        fat: 0,
        carbs: 94,
        protein: 0,
        iron: 0
      },
      {
        name: "Lollipop",
        calories: 392,
        fat: 0.2,
        carbs: 98,
        protein: 0,
        iron: 2
      },
      {
        name: "Honeycomb",
        calories: 408,
        fat: 3.2,
        carbs: 87,
        protein: 6.5,
        iron: 45
      },
      {
        name: "Donut",
        calories: 452,
        fat: 25,
        carbs: 51,
        protein: 4.9,
        iron: 22
      },
      {
        name: "KitKat",
        calories: 518,
        fat: 26,
        carbs: 65,
        protein: 7,
        iron: 6
      }
    ]);
    return (_ctx, _cache) => {
      const _component_v_toolbar_title = resolveComponent("v-toolbar-title");
      const _component_v_toolbar = resolveComponent("v-toolbar");
      const _component_v_data_table = resolveComponent("v-data-table");
      return openBlock(), createBlock(_component_v_data_table, {
        expanded: expanded.value,
        "onUpdate:expanded": _cache[0] || (_cache[0] = ($event) => expanded.value = $event),
        headers: dessertHeaders.value,
        items: desserts2.value,
        "item-value": "name",
        "show-expand": ""
      }, {
        top: withCtx(() => [
          createVNode(_component_v_toolbar, { flat: "" }, {
            default: withCtx(() => [
              createVNode(_component_v_toolbar_title, null, {
                default: withCtx(() => [
                  createTextVNode("Expandable Table")
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        "expanded-row": withCtx(({ columns, item }) => [
          createBaseVNode("tr", null, [
            createBaseVNode("td", {
              colspan: columns.length
            }, " More info about " + toDisplayString(item.name), 9, _hoisted_1$7)
          ])
        ]),
        _: 1
      }, 8, ["expanded", "headers", "items"]);
    };
  }
};
const __3 = _sfc_main$w;
const __3_raw = `<template>
  <v-data-table
    v-model:expanded="expanded"
    :headers="dessertHeaders"
    :items="desserts"
    item-value="name"
    show-expand
  >
    <template v-slot:top>
      <v-toolbar flat>
        <v-toolbar-title>Expandable Table</v-toolbar-title>
      </v-toolbar>
    </template>
    <template v-slot:expanded-row="{ columns, item }">
      <tr>
        <td :colspan="columns.length">
          More info about {{ item.name }}
        </td>
      </tr>
    </template>
  </v-data-table>
</template>

<script setup>
  import { ref } from 'vue'

  const expanded = ref([])
  const dessertHeaders = ref([
    {
      title: 'Dessert (100g serving)',
      align: 'start',
      sortable: false,
      key: 'name',
    },
    { title: 'Calories', key: 'calories' },
    { title: 'Fat (g)', key: 'fat' },
    { title: 'Carbs (g)', key: 'carbs' },
    { title: 'Protein (g)', key: 'protein' },
    { title: 'Iron (%)', key: 'iron' },
    { title: '', key: 'data-table-expand' },
  ])
  const desserts = ref([
    {
      name: 'Frozen Yogurt',
      calories: 159,
      fat: 6,
      carbs: 24,
      protein: 4,
      iron: 1,
    },
    {
      name: 'Ice cream sandwich',
      calories: 237,
      fat: 9,
      carbs: 37,
      protein: 4.3,
      iron: 1,
    },
    {
      name: 'Eclair',
      calories: 262,
      fat: 16,
      carbs: 23,
      protein: 6,
      iron: 7,
    },
    {
      name: 'Cupcake',
      calories: 305,
      fat: 3.7,
      carbs: 67,
      protein: 4.3,
      iron: 8,
    },
    {
      name: 'Gingerbread',
      calories: 356,
      fat: 16,
      carbs: 49,
      protein: 3.9,
      iron: 16,
    },
    {
      name: 'Jelly bean',
      calories: 375,
      fat: 0,
      carbs: 94,
      protein: 0,
      iron: 0,
    },
    {
      name: 'Lollipop',
      calories: 392,
      fat: 0.2,
      carbs: 98,
      protein: 0,
      iron: 2,
    },
    {
      name: 'Honeycomb',
      calories: 408,
      fat: 3.2,
      carbs: 87,
      protein: 6.5,
      iron: 45,
    },
    {
      name: 'Donut',
      calories: 452,
      fat: 25,
      carbs: 51,
      protein: 4.9,
      iron: 22,
    },
    {
      name: 'KitKat',
      calories: 518,
      fat: 26,
      carbs: 65,
      protein: 7,
      iron: 6,
    },
  ])
<\/script>

<script>
  export default {
    data () {
      return {
        expanded: [],
        dessertHeaders: [
          {
            title: 'Dessert (100g serving)',
            align: 'start',
            sortable: false,
            key: 'name',
          },
          { title: 'Calories', key: 'calories' },
          { title: 'Fat (g)', key: 'fat' },
          { title: 'Carbs (g)', key: 'carbs' },
          { title: 'Protein (g)', key: 'protein' },
          { title: 'Iron (%)', key: 'iron' },
          { title: '', key: 'data-table-expand' },
        ],
        desserts: [
          {
            name: 'Frozen Yogurt',
            calories: 159,
            fat: 6.0,
            carbs: 24,
            protein: 4.0,
            iron: 1,
          },
          {
            name: 'Ice cream sandwich',
            calories: 237,
            fat: 9.0,
            carbs: 37,
            protein: 4.3,
            iron: 1,
          },
          {
            name: 'Eclair',
            calories: 262,
            fat: 16.0,
            carbs: 23,
            protein: 6.0,
            iron: 7,
          },
          {
            name: 'Cupcake',
            calories: 305,
            fat: 3.7,
            carbs: 67,
            protein: 4.3,
            iron: 8,
          },
          {
            name: 'Gingerbread',
            calories: 356,
            fat: 16.0,
            carbs: 49,
            protein: 3.9,
            iron: 16,
          },
          {
            name: 'Jelly bean',
            calories: 375,
            fat: 0.0,
            carbs: 94,
            protein: 0.0,
            iron: 0,
          },
          {
            name: 'Lollipop',
            calories: 392,
            fat: 0.2,
            carbs: 98,
            protein: 0,
            iron: 2,
          },
          {
            name: 'Honeycomb',
            calories: 408,
            fat: 3.2,
            carbs: 87,
            protein: 6.5,
            iron: 45,
          },
          {
            name: 'Donut',
            calories: 452,
            fat: 25.0,
            carbs: 51,
            protein: 4.9,
            iron: 22,
          },
          {
            name: 'KitKat',
            calories: 518,
            fat: 26.0,
            carbs: 65,
            protein: 7,
            iron: 6,
          },
        ],
      }
    },
  }
<\/script>
`;
const _hoisted_1$6 = { class: "text-center pt-2" };
const _sfc_main$v = {
  __name: "misc-external-paginate",
  setup(__props) {
    const page = ref(1);
    const itemsPerPage = ref(5);
    const headers = ref([
      {
        align: "start",
        key: "name",
        sortable: false,
        title: "Dessert (100g serving)"
      },
      { title: "Calories", key: "calories" },
      { title: "Fat (g)", key: "fat" },
      { title: "Carbs (g)", key: "carbs" },
      { title: "Protein (g)", key: "protein" },
      { title: "Iron (%)", key: "iron" }
    ]);
    const desserts2 = ref([
      {
        name: "Frozen Yogurt",
        calories: 159,
        fat: 6,
        carbs: 24,
        protein: 4,
        iron: 1
      },
      {
        name: "Ice cream sandwich",
        calories: 237,
        fat: 9,
        carbs: 37,
        protein: 4.3,
        iron: 1
      },
      {
        name: "Eclair",
        calories: 262,
        fat: 16,
        carbs: 23,
        protein: 6,
        iron: 7
      },
      {
        name: "Cupcake",
        calories: 305,
        fat: 3.7,
        carbs: 67,
        protein: 4.3,
        iron: 8
      },
      {
        name: "Gingerbread",
        calories: 356,
        fat: 16,
        carbs: 49,
        protein: 3.9,
        iron: 16
      },
      {
        name: "Jelly bean",
        calories: 375,
        fat: 0,
        carbs: 94,
        protein: 0,
        iron: 0
      },
      {
        name: "Lollipop",
        calories: 392,
        fat: 0.2,
        carbs: 98,
        protein: 0,
        iron: 2
      },
      {
        name: "Honeycomb",
        calories: 408,
        fat: 3.2,
        carbs: 87,
        protein: 6.5,
        iron: 45
      },
      {
        name: "Donut",
        calories: 452,
        fat: 25,
        carbs: 51,
        protein: 4.9,
        iron: 22
      },
      {
        name: "KitKat",
        calories: 518,
        fat: 26,
        carbs: 65,
        protein: 7,
        iron: 6
      }
    ]);
    const pageCount = computed(() => {
      return Math.ceil(desserts2.value.length / itemsPerPage.value);
    });
    return (_ctx, _cache) => {
      const _component_v_text_field = resolveComponent("v-text-field");
      const _component_v_pagination = resolveComponent("v-pagination");
      const _component_v_data_table = resolveComponent("v-data-table");
      return openBlock(), createBlock(_component_v_data_table, {
        page: page.value,
        "onUpdate:page": _cache[2] || (_cache[2] = ($event) => page.value = $event),
        headers: headers.value,
        items: desserts2.value,
        "items-per-page": itemsPerPage.value
      }, {
        top: withCtx(() => [
          createVNode(_component_v_text_field, {
            "model-value": itemsPerPage.value,
            class: "pa-2",
            label: "Items per page",
            max: "15",
            min: "-1",
            type: "number",
            "hide-details": "",
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => itemsPerPage.value = parseInt($event, 10))
          }, null, 8, ["model-value"])
        ]),
        bottom: withCtx(() => [
          createBaseVNode("div", _hoisted_1$6, [
            createVNode(_component_v_pagination, {
              modelValue: page.value,
              "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => page.value = $event),
              length: pageCount.value
            }, null, 8, ["modelValue", "length"])
          ])
        ]),
        _: 1
      }, 8, ["page", "headers", "items", "items-per-page"]);
    };
  }
};
const __4 = _sfc_main$v;
const __4_raw = `<template>
  <v-data-table
    v-model:page="page"
    :headers="headers"
    :items="desserts"
    :items-per-page="itemsPerPage"
  >
    <template v-slot:top>
      <v-text-field
        :model-value="itemsPerPage"
        class="pa-2"
        label="Items per page"
        max="15"
        min="-1"
        type="number"
        hide-details
        @update:model-value="itemsPerPage = parseInt($event, 10)"
      ></v-text-field>
    </template>

    <template v-slot:bottom>
      <div class="text-center pt-2">
        <v-pagination
          v-model="page"
          :length="pageCount"
        ></v-pagination>
      </div>
    </template>
  </v-data-table>
</template>

<script setup>
  import { computed, ref } from 'vue'

  const page = ref(1)
  const itemsPerPage = ref(5)
  const headers = ref([
    {
      align: 'start',
      key: 'name',
      sortable: false,
      title: 'Dessert (100g serving)',
    },
    { title: 'Calories', key: 'calories' },
    { title: 'Fat (g)', key: 'fat' },
    { title: 'Carbs (g)', key: 'carbs' },
    { title: 'Protein (g)', key: 'protein' },
    { title: 'Iron (%)', key: 'iron' },
  ])
  const desserts = ref([
    {
      name: 'Frozen Yogurt',
      calories: 159,
      fat: 6,
      carbs: 24,
      protein: 4,
      iron: 1,
    },
    {
      name: 'Ice cream sandwich',
      calories: 237,
      fat: 9,
      carbs: 37,
      protein: 4.3,
      iron: 1,
    },
    {
      name: 'Eclair',
      calories: 262,
      fat: 16,
      carbs: 23,
      protein: 6,
      iron: 7,
    },
    {
      name: 'Cupcake',
      calories: 305,
      fat: 3.7,
      carbs: 67,
      protein: 4.3,
      iron: 8,
    },
    {
      name: 'Gingerbread',
      calories: 356,
      fat: 16,
      carbs: 49,
      protein: 3.9,
      iron: 16,
    },
    {
      name: 'Jelly bean',
      calories: 375,
      fat: 0,
      carbs: 94,
      protein: 0,
      iron: 0,
    },
    {
      name: 'Lollipop',
      calories: 392,
      fat: 0.2,
      carbs: 98,
      protein: 0,
      iron: 2,
    },
    {
      name: 'Honeycomb',
      calories: 408,
      fat: 3.2,
      carbs: 87,
      protein: 6.5,
      iron: 45,
    },
    {
      name: 'Donut',
      calories: 452,
      fat: 25,
      carbs: 51,
      protein: 4.9,
      iron: 22,
    },
    {
      name: 'KitKat',
      calories: 518,
      fat: 26,
      carbs: 65,
      protein: 7,
      iron: 6,
    },
  ])
  const pageCount = computed(() => {
    return Math.ceil(desserts.value.length / itemsPerPage.value)
  })
<\/script>

<script>
  export default {
    data () {
      return {
        page: 1,
        itemsPerPage: 5,
        headers: [
          {
            align: 'start',
            key: 'name',
            sortable: false,
            title: 'Dessert (100g serving)',
          },
          { title: 'Calories', key: 'calories' },
          { title: 'Fat (g)', key: 'fat' },
          { title: 'Carbs (g)', key: 'carbs' },
          { title: 'Protein (g)', key: 'protein' },
          { title: 'Iron (%)', key: 'iron' },
        ],
        desserts: [
          {
            name: 'Frozen Yogurt',
            calories: 159,
            fat: 6.0,
            carbs: 24,
            protein: 4.0,
            iron: 1,
          },
          {
            name: 'Ice cream sandwich',
            calories: 237,
            fat: 9.0,
            carbs: 37,
            protein: 4.3,
            iron: 1,
          },
          {
            name: 'Eclair',
            calories: 262,
            fat: 16.0,
            carbs: 23,
            protein: 6.0,
            iron: 7,
          },
          {
            name: 'Cupcake',
            calories: 305,
            fat: 3.7,
            carbs: 67,
            protein: 4.3,
            iron: 8,
          },
          {
            name: 'Gingerbread',
            calories: 356,
            fat: 16.0,
            carbs: 49,
            protein: 3.9,
            iron: 16,
          },
          {
            name: 'Jelly bean',
            calories: 375,
            fat: 0.0,
            carbs: 94,
            protein: 0.0,
            iron: 0,
          },
          {
            name: 'Lollipop',
            calories: 392,
            fat: 0.2,
            carbs: 98,
            protein: 0,
            iron: 2,
          },
          {
            name: 'Honeycomb',
            calories: 408,
            fat: 3.2,
            carbs: 87,
            protein: 6.5,
            iron: 45,
          },
          {
            name: 'Donut',
            calories: 452,
            fat: 25.0,
            carbs: 51,
            protein: 4.9,
            iron: 22,
          },
          {
            name: 'KitKat',
            calories: 518,
            fat: 26.0,
            carbs: 65,
            protein: 7,
            iron: 6,
          },
        ],
      }
    },
    computed: {
      pageCount () {
        return Math.ceil(this.desserts.length / this.itemsPerPage)
      },
    },
  }
<\/script>
`;
const _hoisted_1$5 = { class: "text-center pt-2" };
const _sfc_main$u = {
  __name: "misc-external-sort",
  setup(__props) {
    const sortBy = ref([{ key: "fat", order: "asc" }]);
    const headers = ref([
      {
        title: "Dessert (100g serving)",
        align: "start",
        key: "name"
      },
      { title: "Calories", key: "calories" },
      { title: "Fat (g)", key: "fat" },
      { title: "Carbs (g)", key: "carbs" },
      { title: "Protein (g)", key: "protein" },
      { title: "Iron (%)", key: "iron" }
    ]);
    const desserts2 = ref([
      {
        name: "Frozen Yogurt",
        calories: 159,
        fat: 6,
        carbs: 24,
        protein: 4,
        iron: 1
      },
      {
        name: "Ice cream sandwich",
        calories: 237,
        fat: 9,
        carbs: 37,
        protein: 4.3,
        iron: 1
      },
      {
        name: "Eclair",
        calories: 262,
        fat: 16,
        carbs: 23,
        protein: 6,
        iron: 7
      },
      {
        name: "Cupcake",
        calories: 305,
        fat: 3.7,
        carbs: 67,
        protein: 4.3,
        iron: 8
      },
      {
        name: "Gingerbread",
        calories: 356,
        fat: 16,
        carbs: 49,
        protein: 3.9,
        iron: 16
      },
      {
        name: "Jelly bean",
        calories: 375,
        fat: 0,
        carbs: 94,
        protein: 0,
        iron: 0
      },
      {
        name: "Lollipop",
        calories: 392,
        fat: 0.2,
        carbs: 98,
        protein: 0,
        iron: 2
      },
      {
        name: "Honeycomb",
        calories: 408,
        fat: 3.2,
        carbs: 87,
        protein: 6.5,
        iron: 45
      },
      {
        name: "Donut",
        calories: 452,
        fat: 25,
        carbs: 51,
        protein: 4.9,
        iron: 22
      },
      {
        name: "KitKat",
        calories: 518,
        fat: 26,
        carbs: 65,
        protein: 7,
        iron: 6
      }
    ]);
    function toggleOrder() {
      sortBy.value = [{ key: sortBy.value[0].key, order: sortBy.value[0].order === "asc" ? "desc" : "asc" }];
    }
    function nextSort() {
      let index = headers.value.findIndex((h) => h.key === sortBy.value[0].key);
      index = (index + 1) % headers.value.length;
      sortBy.value = [{ key: headers.value[index].key, order: "asc" }];
    }
    return (_ctx, _cache) => {
      const _component_v_data_table = resolveComponent("v-data-table");
      const _component_v_btn = resolveComponent("v-btn");
      return openBlock(), createElementBlock("div", null, [
        createVNode(_component_v_data_table, {
          "sort-by": sortBy.value,
          "onUpdate:sortBy": _cache[0] || (_cache[0] = ($event) => sortBy.value = $event),
          headers: headers.value,
          items: desserts2.value,
          class: "elevation-1"
        }, null, 8, ["sort-by", "headers", "items"]),
        createBaseVNode("div", _hoisted_1$5, [
          createVNode(_component_v_btn, {
            class: "me-2",
            color: "primary",
            onClick: toggleOrder
          }, {
            default: withCtx(() => [
              createTextVNode(" Toggle sort order ")
            ]),
            _: 1
          }),
          createVNode(_component_v_btn, {
            color: "primary",
            onClick: nextSort
          }, {
            default: withCtx(() => [
              createTextVNode(" Sort next column ")
            ]),
            _: 1
          })
        ])
      ]);
    };
  }
};
const __5 = _sfc_main$u;
const __5_raw = `<template>
  <div>
    <v-data-table
      v-model:sort-by="sortBy"
      :headers="headers"
      :items="desserts"
      class="elevation-1"
    ></v-data-table>
    <div class="text-center pt-2">
      <v-btn
        class="me-2"
        color="primary"
        @click="toggleOrder"
      >
        Toggle sort order
      </v-btn>
      <v-btn
        color="primary"
        @click="nextSort"
      >
        Sort next column
      </v-btn>
    </div>
  </div>
</template>

<script setup>
  import { ref } from 'vue'

  const sortBy = ref([{ key: 'fat', order: 'asc' }])
  const headers = ref([
    {
      title: 'Dessert (100g serving)',
      align: 'start',
      key: 'name',
    },
    { title: 'Calories', key: 'calories' },
    { title: 'Fat (g)', key: 'fat' },
    { title: 'Carbs (g)', key: 'carbs' },
    { title: 'Protein (g)', key: 'protein' },
    { title: 'Iron (%)', key: 'iron' },
  ])
  const desserts = ref([
    {
      name: 'Frozen Yogurt',
      calories: 159,
      fat: 6,
      carbs: 24,
      protein: 4,
      iron: 1,
    },
    {
      name: 'Ice cream sandwich',
      calories: 237,
      fat: 9,
      carbs: 37,
      protein: 4.3,
      iron: 1,
    },
    {
      name: 'Eclair',
      calories: 262,
      fat: 16,
      carbs: 23,
      protein: 6,
      iron: 7,
    },
    {
      name: 'Cupcake',
      calories: 305,
      fat: 3.7,
      carbs: 67,
      protein: 4.3,
      iron: 8,
    },
    {
      name: 'Gingerbread',
      calories: 356,
      fat: 16,
      carbs: 49,
      protein: 3.9,
      iron: 16,
    },
    {
      name: 'Jelly bean',
      calories: 375,
      fat: 0,
      carbs: 94,
      protein: 0,
      iron: 0,
    },
    {
      name: 'Lollipop',
      calories: 392,
      fat: 0.2,
      carbs: 98,
      protein: 0,
      iron: 2,
    },
    {
      name: 'Honeycomb',
      calories: 408,
      fat: 3.2,
      carbs: 87,
      protein: 6.5,
      iron: 45,
    },
    {
      name: 'Donut',
      calories: 452,
      fat: 25,
      carbs: 51,
      protein: 4.9,
      iron: 22,
    },
    {
      name: 'KitKat',
      calories: 518,
      fat: 26,
      carbs: 65,
      protein: 7,
      iron: 6,
    },
  ])
  function toggleOrder () {
    sortBy.value = [{ key: sortBy.value[0].key, order: sortBy.value[0].order === 'asc' ? 'desc' : 'asc' }]
  }
  function nextSort () {
    let index = headers.value.findIndex(h => h.key === sortBy.value[0].key)
    index = (index + 1) % headers.value.length
    sortBy.value = [{ key: headers.value[index].key, order: 'asc' }]
  }
<\/script>

<script>
  export default {
    data () {
      return {
        sortBy: [{ key: 'fat', order: 'asc' }],
        headers: [
          {
            title: 'Dessert (100g serving)',
            align: 'start',
            key: 'name',
          },
          { title: 'Calories', key: 'calories' },
          { title: 'Fat (g)', key: 'fat' },
          { title: 'Carbs (g)', key: 'carbs' },
          { title: 'Protein (g)', key: 'protein' },
          { title: 'Iron (%)', key: 'iron' },
        ],
        desserts: [
          {
            name: 'Frozen Yogurt',
            calories: 159,
            fat: 6.0,
            carbs: 24,
            protein: 4.0,
            iron: 1,
          },
          {
            name: 'Ice cream sandwich',
            calories: 237,
            fat: 9.0,
            carbs: 37,
            protein: 4.3,
            iron: 1,
          },
          {
            name: 'Eclair',
            calories: 262,
            fat: 16.0,
            carbs: 23,
            protein: 6.0,
            iron: 7,
          },
          {
            name: 'Cupcake',
            calories: 305,
            fat: 3.7,
            carbs: 67,
            protein: 4.3,
            iron: 8,
          },
          {
            name: 'Gingerbread',
            calories: 356,
            fat: 16.0,
            carbs: 49,
            protein: 3.9,
            iron: 16,
          },
          {
            name: 'Jelly bean',
            calories: 375,
            fat: 0.0,
            carbs: 94,
            protein: 0.0,
            iron: 0,
          },
          {
            name: 'Lollipop',
            calories: 392,
            fat: 0.2,
            carbs: 98,
            protein: 0,
            iron: 2,
          },
          {
            name: 'Honeycomb',
            calories: 408,
            fat: 3.2,
            carbs: 87,
            protein: 6.5,
            iron: 45,
          },
          {
            name: 'Donut',
            calories: 452,
            fat: 25.0,
            carbs: 51,
            protein: 4.9,
            iron: 22,
          },
          {
            name: 'KitKat',
            calories: 518,
            fat: 26.0,
            carbs: 65,
            protein: 7,
            iron: 6,
          },
        ],
      }
    },
    methods: {
      toggleOrder () {
        this.sortBy = [{ key: this.sortBy[0].key, order: this.sortBy[0].order === 'asc' ? 'desc' : 'asc' }]
      },
      nextSort () {
        let index = this.headers.findIndex(h => h.key === this.sortBy[0].key)
        index = (index + 1) % this.headers.length
        this.sortBy = [{ key: this.headers[index].key, order: 'asc' }]
      },
    },
  }
<\/script>
`;
const _sfc_main$t = {
  __name: "misc-server-side-paginate-and-sort",
  setup(__props) {
    const desserts2 = [
      {
        name: "Frozen Yogurt",
        calories: 159,
        fat: 6,
        carbs: 24,
        protein: 4,
        iron: "1"
      },
      {
        name: "Jelly bean",
        calories: 375,
        fat: 0,
        carbs: 94,
        protein: 0,
        iron: "0"
      },
      {
        name: "KitKat",
        calories: 518,
        fat: 26,
        carbs: 65,
        protein: 7,
        iron: "6"
      },
      {
        name: "Eclair",
        calories: 262,
        fat: 16,
        carbs: 23,
        protein: 6,
        iron: "7"
      },
      {
        name: "Gingerbread",
        calories: 356,
        fat: 16,
        carbs: 49,
        protein: 3.9,
        iron: "16"
      },
      {
        name: "Ice cream sandwich",
        calories: 237,
        fat: 9,
        carbs: 37,
        protein: 4.3,
        iron: "1"
      },
      {
        name: "Lollipop",
        calories: 392,
        fat: 0.2,
        carbs: 98,
        protein: 0,
        iron: "2"
      },
      {
        name: "Cupcake",
        calories: 305,
        fat: 3.7,
        carbs: 67,
        protein: 4.3,
        iron: "8"
      },
      {
        name: "Honeycomb",
        calories: 408,
        fat: 3.2,
        carbs: 87,
        protein: 6.5,
        iron: "45"
      },
      {
        name: "Donut",
        calories: 452,
        fat: 25,
        carbs: 51,
        protein: 4.9,
        iron: "22"
      }
    ];
    const FakeAPI = {
      async fetch({ page, itemsPerPage: itemsPerPage2, sortBy }) {
        return new Promise((resolve) => {
          setTimeout(() => {
            const start = (page - 1) * itemsPerPage2;
            const end = start + itemsPerPage2;
            const items = desserts2.slice();
            if (sortBy.length) {
              const sortKey = sortBy[0].key;
              const sortOrder = sortBy[0].order;
              items.sort((a, b) => {
                const aValue = a[sortKey];
                const bValue = b[sortKey];
                return sortOrder === "desc" ? bValue - aValue : aValue - bValue;
              });
            }
            const paginated = items.slice(start, end);
            resolve({ items: paginated, total: items.length });
          }, 500);
        });
      }
    };
    const itemsPerPage = ref(5);
    const headers = ref([
      {
        title: "Dessert (100g serving)",
        align: "start",
        sortable: false,
        key: "name"
      },
      { title: "Calories", key: "calories", align: "end" },
      { title: "Fat (g)", key: "fat", align: "end" },
      { title: "Carbs (g)", key: "carbs", align: "end" },
      { title: "Protein (g)", key: "protein", align: "end" },
      { title: "Iron (%)", key: "iron", align: "end" }
    ]);
    const search = ref("");
    const serverItems = ref([]);
    const loading = ref(true);
    const totalItems = ref(0);
    function loadItems({ page, itemsPerPage: itemsPerPage2, sortBy }) {
      loading.value = true;
      FakeAPI.fetch({ page, itemsPerPage: itemsPerPage2, sortBy }).then(({ items, total }) => {
        serverItems.value = items;
        totalItems.value = total;
        loading.value = false;
      });
    }
    return (_ctx, _cache) => {
      const _component_v_data_table_server = resolveComponent("v-data-table-server");
      return openBlock(), createBlock(_component_v_data_table_server, {
        "items-per-page": itemsPerPage.value,
        "onUpdate:itemsPerPage": _cache[0] || (_cache[0] = ($event) => itemsPerPage.value = $event),
        headers: headers.value,
        items: serverItems.value,
        "items-length": totalItems.value,
        loading: loading.value,
        search: search.value,
        "item-value": "name",
        "onUpdate:options": loadItems
      }, null, 8, ["items-per-page", "headers", "items", "items-length", "loading", "search"]);
    };
  }
};
const __6 = _sfc_main$t;
const __6_raw = `<template>
  <v-data-table-server
    v-model:items-per-page="itemsPerPage"
    :headers="headers"
    :items="serverItems"
    :items-length="totalItems"
    :loading="loading"
    :search="search"
    item-value="name"
    @update:options="loadItems"
  ></v-data-table-server>
</template>

<script setup>
  import { ref } from 'vue'

  const desserts = [
    {
      name: 'Frozen Yogurt',
      calories: 159,
      fat: 6,
      carbs: 24,
      protein: 4,
      iron: '1',
    },
    {
      name: 'Jelly bean',
      calories: 375,
      fat: 0,
      carbs: 94,
      protein: 0,
      iron: '0',
    },
    {
      name: 'KitKat',
      calories: 518,
      fat: 26,
      carbs: 65,
      protein: 7,
      iron: '6',
    },
    {
      name: 'Eclair',
      calories: 262,
      fat: 16,
      carbs: 23,
      protein: 6,
      iron: '7',
    },
    {
      name: 'Gingerbread',
      calories: 356,
      fat: 16,
      carbs: 49,
      protein: 3.9,
      iron: '16',
    },
    {
      name: 'Ice cream sandwich',
      calories: 237,
      fat: 9,
      carbs: 37,
      protein: 4.3,
      iron: '1',
    },
    {
      name: 'Lollipop',
      calories: 392,
      fat: 0.2,
      carbs: 98,
      protein: 0,
      iron: '2',
    },
    {
      name: 'Cupcake',
      calories: 305,
      fat: 3.7,
      carbs: 67,
      protein: 4.3,
      iron: '8',
    },
    {
      name: 'Honeycomb',
      calories: 408,
      fat: 3.2,
      carbs: 87,
      protein: 6.5,
      iron: '45',
    },
    {
      name: 'Donut',
      calories: 452,
      fat: 25,
      carbs: 51,
      protein: 4.9,
      iron: '22',
    },
  ]
  const FakeAPI = {
    async fetch ({ page, itemsPerPage, sortBy }) {
      return new Promise(resolve => {
        setTimeout(() => {
          const start = (page - 1) * itemsPerPage
          const end = start + itemsPerPage
          const items = desserts.slice()
          if (sortBy.length) {
            const sortKey = sortBy[0].key
            const sortOrder = sortBy[0].order
            items.sort((a, b) => {
              const aValue = a[sortKey]
              const bValue = b[sortKey]
              return sortOrder === 'desc' ? bValue - aValue : aValue - bValue
            })
          }
          const paginated = items.slice(start, end)
          resolve({ items: paginated, total: items.length })
        }, 500)
      })
    },
  }
  const itemsPerPage = ref(5)
  const headers = ref([
    {
      title: 'Dessert (100g serving)',
      align: 'start',
      sortable: false,
      key: 'name',
    },
    { title: 'Calories', key: 'calories', align: 'end' },
    { title: 'Fat (g)', key: 'fat', align: 'end' },
    { title: 'Carbs (g)', key: 'carbs', align: 'end' },
    { title: 'Protein (g)', key: 'protein', align: 'end' },
    { title: 'Iron (%)', key: 'iron', align: 'end' },
  ])
  const search = ref('')
  const serverItems = ref([])
  const loading = ref(true)
  const totalItems = ref(0)
  function loadItems ({ page, itemsPerPage, sortBy }) {
    loading.value = true
    FakeAPI.fetch({ page, itemsPerPage, sortBy }).then(({ items, total }) => {
      serverItems.value = items
      totalItems.value = total
      loading.value = false
    })
  }
<\/script>

<script>
  const desserts = [
    {
      name: 'Frozen Yogurt',
      calories: 159,
      fat: 6.0,
      carbs: 24,
      protein: 4.0,
      iron: '1',
    },
    {
      name: 'Jelly bean',
      calories: 375,
      fat: 0.0,
      carbs: 94,
      protein: 0.0,
      iron: '0',
    },
    {
      name: 'KitKat',
      calories: 518,
      fat: 26.0,
      carbs: 65,
      protein: 7,
      iron: '6',
    },
    {
      name: 'Eclair',
      calories: 262,
      fat: 16.0,
      carbs: 23,
      protein: 6.0,
      iron: '7',
    },
    {
      name: 'Gingerbread',
      calories: 356,
      fat: 16.0,
      carbs: 49,
      protein: 3.9,
      iron: '16',
    },
    {
      name: 'Ice cream sandwich',
      calories: 237,
      fat: 9.0,
      carbs: 37,
      protein: 4.3,
      iron: '1',
    },
    {
      name: 'Lollipop',
      calories: 392,
      fat: 0.2,
      carbs: 98,
      protein: 0,
      iron: '2',
    },
    {
      name: 'Cupcake',
      calories: 305,
      fat: 3.7,
      carbs: 67,
      protein: 4.3,
      iron: '8',
    },
    {
      name: 'Honeycomb',
      calories: 408,
      fat: 3.2,
      carbs: 87,
      protein: 6.5,
      iron: '45',
    },
    {
      name: 'Donut',
      calories: 452,
      fat: 25.0,
      carbs: 51,
      protein: 4.9,
      iron: '22',
    },
  ]

  const FakeAPI = {
    async fetch ({ page, itemsPerPage, sortBy }) {
      return new Promise(resolve => {
        setTimeout(() => {
          const start = (page - 1) * itemsPerPage
          const end = start + itemsPerPage
          const items = desserts.slice()

          if (sortBy.length) {
            const sortKey = sortBy[0].key
            const sortOrder = sortBy[0].order
            items.sort((a, b) => {
              const aValue = a[sortKey]
              const bValue = b[sortKey]
              return sortOrder === 'desc' ? bValue - aValue : aValue - bValue
            })
          }

          const paginated = items.slice(start, end)

          resolve({ items: paginated, total: items.length })
        }, 500)
      })
    },
  }

  export default {
    data: () => ({
      itemsPerPage: 5,
      headers: [
        {
          title: 'Dessert (100g serving)',
          align: 'start',
          sortable: false,
          key: 'name',
        },
        { title: 'Calories', key: 'calories', align: 'end' },
        { title: 'Fat (g)', key: 'fat', align: 'end' },
        { title: 'Carbs (g)', key: 'carbs', align: 'end' },
        { title: 'Protein (g)', key: 'protein', align: 'end' },
        { title: 'Iron (%)', key: 'iron', align: 'end' },
      ],
      search: '',
      serverItems: [],
      loading: true,
      totalItems: 0,
    }),
    methods: {
      loadItems ({ page, itemsPerPage, sortBy }) {
        this.loading = true
        FakeAPI.fetch({ page, itemsPerPage, sortBy }).then(({ items, total }) => {
          this.serverItems = items
          this.totalItems = total
          this.loading = false
        })
      },
    },
  }
<\/script>
`;
const _sfc_main$s = {
  __name: "prop-custom-filter",
  setup(__props) {
    const search = ref("");
    const headers = [
      {
        title: "CPU Model",
        align: "start",
        key: "name"
      },
      {
        title: "Cores",
        align: "end",
        key: "cores"
      },
      {
        title: "Threads",
        align: "end",
        key: "threads"
      },
      {
        title: "Base Clock",
        align: "end",
        key: "baseClock"
      },
      {
        title: "Boost Clock",
        align: "end",
        key: "boostClock"
      },
      {
        title: "TDP (W)",
        align: "end",
        key: "tdp"
      }
    ];
    const items = [
      {
        name: "Intel Core i9-11900K",
        cores: 8,
        threads: 16,
        baseClock: "3.5 GHz",
        boostClock: "5.3 GHz",
        tdp: "125W"
      },
      {
        name: "AMD Ryzen 9 5950X",
        cores: 16,
        threads: 32,
        baseClock: "3.4 GHz",
        boostClock: "4.9 GHz",
        tdp: "105W"
      },
      {
        name: "Intel Core i7-10700K",
        cores: 8,
        threads: 16,
        baseClock: "3.8 GHz",
        boostClock: "5.1 GHz",
        tdp: "125W"
      },
      {
        name: "AMD Ryzen 5 5600X",
        cores: 6,
        threads: 12,
        baseClock: "3.7 GHz",
        boostClock: "4.6 GHz",
        tdp: "65W"
      },
      {
        name: "Intel Core i5-10600K",
        cores: 6,
        threads: 12,
        baseClock: "4.1 GHz",
        boostClock: "4.8 GHz",
        tdp: "125W"
      },
      {
        name: "AMD Ryzen 7 5800X",
        cores: 8,
        threads: 16,
        baseClock: "3.8 GHz",
        boostClock: "4.7 GHz",
        tdp: "105W"
      },
      {
        name: "Intel Core i3-10100",
        cores: 4,
        threads: 8,
        baseClock: "3.6 GHz",
        boostClock: "4.3 GHz",
        tdp: "65W"
      },
      {
        name: "AMD Ryzen 3 3300X",
        cores: 4,
        threads: 8,
        baseClock: "3.8 GHz",
        boostClock: "4.3 GHz",
        tdp: "65W"
      },
      {
        name: "Intel Pentium Gold G6400",
        cores: 2,
        threads: 4,
        baseClock: "4.0 GHz",
        tdp: "58W"
      },
      {
        name: "AMD Athlon 3000G",
        cores: 2,
        threads: 4,
        baseClock: "3.5 GHz",
        tdp: "35W"
      }
    ];
    function filterOnlyCapsText(value, query, item) {
      return value != null && query != null && typeof value === "string" && value.toString().toLocaleUpperCase().indexOf(query) !== -1;
    }
    return (_ctx, _cache) => {
      const _component_v_text_field = resolveComponent("v-text-field");
      const _component_v_data_table = resolveComponent("v-data-table");
      return openBlock(), createBlock(_component_v_data_table, {
        "custom-filter": filterOnlyCapsText,
        headers,
        items,
        search: search.value,
        "item-value": "name"
      }, {
        top: withCtx(() => [
          createVNode(_component_v_text_field, {
            modelValue: search.value,
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => search.value = $event),
            class: "pa-2",
            label: "Search (UPPER CASE ONLY)"
          }, null, 8, ["modelValue"])
        ]),
        _: 1
      }, 8, ["search"]);
    };
  }
};
const __7 = _sfc_main$s;
const __7_raw = `<template>
  <v-data-table
    :custom-filter="filterOnlyCapsText"
    :headers="headers"
    :items="items"
    :search="search"
    item-value="name"
  >
    <template v-slot:top>
      <v-text-field
        v-model="search"
        class="pa-2"
        label="Search (UPPER CASE ONLY)"
      ></v-text-field>
    </template>
  </v-data-table>
</template>

<script setup>
  import { ref } from 'vue'

  const search = ref('')
  const headers = [
    {
      title: 'CPU Model',
      align: 'start',
      key: 'name',
    },
    {
      title: 'Cores',
      align: 'end',
      key: 'cores',
    },
    {
      title: 'Threads',
      align: 'end',
      key: 'threads',
    },
    {
      title: 'Base Clock',
      align: 'end',
      key: 'baseClock',
    },
    {
      title: 'Boost Clock',
      align: 'end',
      key: 'boostClock',
    },
    {
      title: 'TDP (W)',
      align: 'end',
      key: 'tdp',
    },
  ]
  const items = [
    {
      name: 'Intel Core i9-11900K',
      cores: 8,
      threads: 16,
      baseClock: '3.5 GHz',
      boostClock: '5.3 GHz',
      tdp: '125W',
    },
    {
      name: 'AMD Ryzen 9 5950X',
      cores: 16,
      threads: 32,
      baseClock: '3.4 GHz',
      boostClock: '4.9 GHz',
      tdp: '105W',
    },
    {
      name: 'Intel Core i7-10700K',
      cores: 8,
      threads: 16,
      baseClock: '3.8 GHz',
      boostClock: '5.1 GHz',
      tdp: '125W',
    },
    {
      name: 'AMD Ryzen 5 5600X',
      cores: 6,
      threads: 12,
      baseClock: '3.7 GHz',
      boostClock: '4.6 GHz',
      tdp: '65W',
    },
    {
      name: 'Intel Core i5-10600K',
      cores: 6,
      threads: 12,
      baseClock: '4.1 GHz',
      boostClock: '4.8 GHz',
      tdp: '125W',
    },
    {
      name: 'AMD Ryzen 7 5800X',
      cores: 8,
      threads: 16,
      baseClock: '3.8 GHz',
      boostClock: '4.7 GHz',
      tdp: '105W',
    },
    {
      name: 'Intel Core i3-10100',
      cores: 4,
      threads: 8,
      baseClock: '3.6 GHz',
      boostClock: '4.3 GHz',
      tdp: '65W',
    },
    {
      name: 'AMD Ryzen 3 3300X',
      cores: 4,
      threads: 8,
      baseClock: '3.8 GHz',
      boostClock: '4.3 GHz',
      tdp: '65W',
    },
    {
      name: 'Intel Pentium Gold G6400',
      cores: 2,
      threads: 4,
      baseClock: '4.0 GHz',
      tdp: '58W',
    },
    {
      name: 'AMD Athlon 3000G',
      cores: 2,
      threads: 4,
      baseClock: '3.5 GHz',
      tdp: '35W',
    },
  ]

  function filterOnlyCapsText (value, query, item) {
    return value != null && query != null && typeof value === 'string' && value.toString().toLocaleUpperCase().indexOf(query) !== -1
  }
<\/script>

<script>
  export default {
    data: () => ({
      search: '',
      headers: [
        {
          title: 'CPU Model',
          align: 'start',
          key: 'name',
        },
        {
          title: 'Cores',
          align: 'end',
          key: 'cores',
        },
        {
          title: 'Threads',
          align: 'end',
          key: 'threads',
        },
        {
          title: 'Base Clock',
          align: 'end',
          key: 'baseClock',
        },
        {
          title: 'Boost Clock',
          align: 'end',
          key: 'boostClock',
        },
        {
          title: 'TDP (W)',
          align: 'end',
          key: 'tdp',
        },
      ],
      items: [
        {
          name: 'Intel Core i9-11900K',
          cores: 8,
          threads: 16,
          baseClock: '3.5 GHz',
          boostClock: '5.3 GHz',
          tdp: '125W',
        },
        {
          name: 'AMD Ryzen 9 5950X',
          cores: 16,
          threads: 32,
          baseClock: '3.4 GHz',
          boostClock: '4.9 GHz',
          tdp: '105W',
        },
        {
          name: 'Intel Core i7-10700K',
          cores: 8,
          threads: 16,
          baseClock: '3.8 GHz',
          boostClock: '5.1 GHz',
          tdp: '125W',
        },
        {
          name: 'AMD Ryzen 5 5600X',
          cores: 6,
          threads: 12,
          baseClock: '3.7 GHz',
          boostClock: '4.6 GHz',
          tdp: '65W',
        },
        {
          name: 'Intel Core i5-10600K',
          cores: 6,
          threads: 12,
          baseClock: '4.1 GHz',
          boostClock: '4.8 GHz',
          tdp: '125W',
        },
        {
          name: 'AMD Ryzen 7 5800X',
          cores: 8,
          threads: 16,
          baseClock: '3.8 GHz',
          boostClock: '4.7 GHz',
          tdp: '105W',
        },
        {
          name: 'Intel Core i3-10100',
          cores: 4,
          threads: 8,
          baseClock: '3.6 GHz',
          boostClock: '4.3 GHz',
          tdp: '65W',
        },
        {
          name: 'AMD Ryzen 3 3300X',
          cores: 4,
          threads: 8,
          baseClock: '3.8 GHz',
          boostClock: '4.3 GHz',
          tdp: '65W',
        },
        {
          name: 'Intel Pentium Gold G6400',
          cores: 2,
          threads: 4,
          baseClock: '4.0 GHz',
          tdp: '58W',
        },
        {
          name: 'AMD Athlon 3000G',
          cores: 2,
          threads: 4,
          baseClock: '3.5 GHz',
          tdp: '35W',
        },
      ],
    }),

    methods: {
      filterOnlyCapsText (value, query, item) {
        return value != null &&
          query != null &&
          typeof value === 'string' &&
          value.toString().toLocaleUpperCase().indexOf(query) !== -1
      },
    },
  }
<\/script>
`;
const _sfc_main$r = {
  __name: "prop-dense",
  setup(__props) {
    const headers = [
      { title: "Plant", align: "start", sortable: false, key: "name" },
      { title: "Light", align: "end", key: "light" },
      { title: "Height", align: "end", key: "height" },
      { title: "Pet Friendly", align: "end", key: "petFriendly" },
      { title: "Price ($)", align: "end", key: "price" }
    ];
    const plants = [
      {
        name: "Fern",
        light: "Low",
        height: "20cm",
        petFriendly: "Yes",
        price: 20
      },
      {
        name: "Snake Plant",
        light: "Low",
        height: "50cm",
        petFriendly: "No",
        price: 35
      },
      {
        name: "Monstera",
        light: "Medium",
        height: "60cm",
        petFriendly: "No",
        price: 50
      },
      {
        name: "Pothos",
        light: "Low to medium",
        height: "40cm",
        petFriendly: "Yes",
        price: 25
      },
      {
        name: "ZZ Plant",
        light: "Low to medium",
        height: "90cm",
        petFriendly: "Yes",
        price: 30
      },
      {
        name: "Spider Plant",
        light: "Bright, indirect",
        height: "30cm",
        petFriendly: "Yes",
        price: 15
      },
      {
        name: "Air Plant",
        light: "Bright, indirect",
        height: "15cm",
        petFriendly: "Yes",
        price: 10
      },
      {
        name: "Peperomia",
        light: "Bright, indirect",
        height: "25cm",
        petFriendly: "Yes",
        price: 20
      },
      {
        name: "Aloe Vera",
        light: "Bright, direct",
        height: "30cm",
        petFriendly: "Yes",
        price: 15
      },
      {
        name: "Jade Plant",
        light: "Bright, direct",
        height: "40cm",
        petFriendly: "Yes",
        price: 25
      }
    ];
    return (_ctx, _cache) => {
      const _component_v_data_table = resolveComponent("v-data-table");
      return openBlock(), createBlock(_component_v_data_table, {
        headers,
        items: plants,
        density: "compact",
        "item-key": "name"
      });
    };
  }
};
const __8 = _sfc_main$r;
const __8_raw = `<template>
  <v-data-table
    :headers="headers"
    :items="plants"
    density="compact"
    item-key="name"
  ></v-data-table>
</template>

<script setup>
  const headers = [
    { title: 'Plant', align: 'start', sortable: false, key: 'name' },
    { title: 'Light', align: 'end', key: 'light' },
    { title: 'Height', align: 'end', key: 'height' },
    { title: 'Pet Friendly', align: 'end', key: 'petFriendly' },
    { title: 'Price ($)', align: 'end', key: 'price' },
  ]

  const plants = [
    {
      name: 'Fern',
      light: 'Low',
      height: '20cm',
      petFriendly: 'Yes',
      price: 20,
    },
    {
      name: 'Snake Plant',
      light: 'Low',
      height: '50cm',
      petFriendly: 'No',
      price: 35,
    },
    {
      name: 'Monstera',
      light: 'Medium',
      height: '60cm',
      petFriendly: 'No',
      price: 50,
    },
    {
      name: 'Pothos',
      light: 'Low to medium',
      height: '40cm',
      petFriendly: 'Yes',
      price: 25,
    },
    {
      name: 'ZZ Plant',
      light: 'Low to medium',
      height: '90cm',
      petFriendly: 'Yes',
      price: 30,
    },
    {
      name: 'Spider Plant',
      light: 'Bright, indirect',
      height: '30cm',
      petFriendly: 'Yes',
      price: 15,
    },
    {
      name: 'Air Plant',
      light: 'Bright, indirect',
      height: '15cm',
      petFriendly: 'Yes',
      price: 10,
    },
    {
      name: 'Peperomia',
      light: 'Bright, indirect',
      height: '25cm',
      petFriendly: 'Yes',
      price: 20,
    },
    {
      name: 'Aloe Vera',
      light: 'Bright, direct',
      height: '30cm',
      petFriendly: 'Yes',
      price: 15,
    },
    {
      name: 'Jade Plant',
      light: 'Bright, direct',
      height: '40cm',
      petFriendly: 'Yes',
      price: 25,
    },
  ]
<\/script>

<script>
  export default {
    headers: [
      { title: 'Plant', align: 'start', sortable: false, key: 'name' },
      { title: 'Light', align: 'end', key: 'light' },
      { title: 'Height', align: 'end', key: 'height' },
      { title: 'Pet Friendly', align: 'end', key: 'petFriendly' },
      { title: 'Price ($)', align: 'end', key: 'price' },
    ],
    plants: [
      {
        name: 'Fern',
        light: 'Low',
        height: '20cm',
        petFriendly: 'Yes',
        price: 20,
      },
      {
        name: 'Snake Plant',
        light: 'Low',
        height: '50cm',
        petFriendly: 'No',
        price: 35,
      },
      {
        name: 'Monstera',
        light: 'Medium',
        height: '60cm',
        petFriendly: 'No',
        price: 50,
      },
      {
        name: 'Pothos',
        light: 'Low to medium',
        height: '40cm',
        petFriendly: 'Yes',
        price: 25,
      },
      {
        name: 'ZZ Plant',
        light: 'Low to medium',
        height: '90cm',
        petFriendly: 'Yes',
        price: 30,
      },
      {
        name: 'Spider Plant',
        light: 'Bright, indirect',
        height: '30cm',
        petFriendly: 'Yes',
        price: 15,
      },
      {
        name: 'Air Plant',
        light: 'Bright, indirect',
        height: '15cm',
        petFriendly: 'Yes',
        price: 10,
      },
      {
        name: 'Peperomia',
        light: 'Bright, indirect',
        height: '25cm',
        petFriendly: 'Yes',
        price: 20,
      },
      {
        name: 'Aloe Vera',
        light: 'Bright, direct',
        height: '30cm',
        petFriendly: 'Yes',
        price: 15,
      },
      {
        name: 'Jade Plant',
        light: 'Bright, direct',
        height: '40cm',
        petFriendly: 'Yes',
        price: 25,
      },
    ],
  }
<\/script>
`;
const _hoisted_1$4 = /* @__PURE__ */ createBaseVNode("div", { class: "text-end" }, "Stock", -1);
const _hoisted_2$1 = { class: "text-end" };
const _sfc_main$q = {
  __name: "prop-filterable",
  setup(__props) {
    const search = ref("");
    const items = [
      {
        name: "Nebula GTX 3080",
        image: "1.png",
        price: 699.99,
        rating: 5,
        stock: true
      },
      {
        name: "Galaxy RTX 3080",
        image: "2.png",
        price: 799.99,
        rating: 4,
        stock: false
      },
      {
        name: "Orion RX 6800 XT",
        image: "3.png",
        price: 649.99,
        rating: 3,
        stock: true
      },
      {
        name: "Vortex RTX 3090",
        image: "4.png",
        price: 1499.99,
        rating: 4,
        stock: true
      },
      {
        name: "Cosmos GTX 1660 Super",
        image: "5.png",
        price: 299.99,
        rating: 4,
        stock: false
      }
    ];
    return (_ctx, _cache) => {
      const _component_v_icon = resolveComponent("v-icon");
      const _component_v_spacer = resolveComponent("v-spacer");
      const _component_v_text_field = resolveComponent("v-text-field");
      const _component_v_card_title = resolveComponent("v-card-title");
      const _component_v_divider = resolveComponent("v-divider");
      const _component_v_img = resolveComponent("v-img");
      const _component_v_card = resolveComponent("v-card");
      const _component_v_rating = resolveComponent("v-rating");
      const _component_v_chip = resolveComponent("v-chip");
      const _component_v_data_table = resolveComponent("v-data-table");
      return openBlock(), createBlock(_component_v_card, { flat: "" }, {
        default: withCtx(() => [
          createVNode(_component_v_card_title, { class: "d-flex align-center pe-2" }, {
            default: withCtx(() => [
              createVNode(_component_v_icon, { icon: "mdi-video-input-component" }),
              createTextVNode("   Find a Graphics Card "),
              createVNode(_component_v_spacer),
              createVNode(_component_v_text_field, {
                modelValue: search.value,
                "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => search.value = $event),
                density: "compact",
                label: "Search",
                "prepend-inner-icon": "mdi-magnify",
                variant: "solo-filled",
                flat: "",
                "hide-details": "",
                "single-line": ""
              }, null, 8, ["modelValue"])
            ]),
            _: 1
          }),
          createVNode(_component_v_divider),
          createVNode(_component_v_data_table, {
            search: search.value,
            "onUpdate:search": _cache[1] || (_cache[1] = ($event) => search.value = $event),
            items
          }, {
            "header.stock": withCtx(() => [
              _hoisted_1$4
            ]),
            "item.image": withCtx(({ item }) => [
              createVNode(_component_v_card, {
                class: "my-2",
                elevation: "2",
                rounded: ""
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_img, {
                    src: `https://cdn.vuetifyjs.com/docs/images/graphics/gpus/${item.image}`,
                    height: "64",
                    cover: ""
                  }, null, 8, ["src"])
                ]),
                _: 2
              }, 1024)
            ]),
            "item.rating": withCtx(({ item }) => [
              createVNode(_component_v_rating, {
                "model-value": item.rating,
                color: "orange-darken-2",
                density: "compact",
                size: "small",
                readonly: ""
              }, null, 8, ["model-value"])
            ]),
            "item.stock": withCtx(({ item }) => [
              createBaseVNode("div", _hoisted_2$1, [
                createVNode(_component_v_chip, {
                  color: item.stock ? "green" : "red",
                  text: item.stock ? "In stock" : "Out of stock",
                  class: "text-uppercase",
                  size: "small",
                  label: ""
                }, null, 8, ["color", "text"])
              ])
            ]),
            _: 1
          }, 8, ["search"])
        ]),
        _: 1
      });
    };
  }
};
const __9 = _sfc_main$q;
const __9_raw = `<template>
  <v-card flat>
    <v-card-title class="d-flex align-center pe-2">
      <v-icon icon="mdi-video-input-component"></v-icon> &nbsp;
      Find a Graphics Card

      <v-spacer></v-spacer>

      <v-text-field
        v-model="search"
        density="compact"
        label="Search"
        prepend-inner-icon="mdi-magnify"
        variant="solo-filled"
        flat
        hide-details
        single-line
      ></v-text-field>
    </v-card-title>

    <v-divider></v-divider>
    <v-data-table v-model:search="search" :items="items">
      <template v-slot:header.stock>
        <div class="text-end">Stock</div>
      </template>

      <template v-slot:item.image="{ item }">
        <v-card class="my-2" elevation="2" rounded>
          <v-img
            :src="\`https://cdn.vuetifyjs.com/docs/images/graphics/gpus/\${item.image}\`"
            height="64"
            cover
          ></v-img>
        </v-card>
      </template>

      <template v-slot:item.rating="{ item }">
        <v-rating
          :model-value="item.rating"
          color="orange-darken-2"
          density="compact"
          size="small"
          readonly
        ></v-rating>
      </template>

      <template v-slot:item.stock="{ item }">
        <div class="text-end">
          <v-chip
            :color="item.stock ? 'green' : 'red'"
            :text="item.stock ? 'In stock' : 'Out of stock'"
            class="text-uppercase"
            size="small"
            label
          ></v-chip>
        </div>
      </template>
    </v-data-table>
  </v-card>
</template>

<script setup>
  import { ref } from 'vue'

  const search = ref('')
  const items = [
    {
      name: 'Nebula GTX 3080',
      image: '1.png',
      price: 699.99,
      rating: 5,
      stock: true,
    },
    {
      name: 'Galaxy RTX 3080',
      image: '2.png',
      price: 799.99,
      rating: 4,
      stock: false,
    },
    {
      name: 'Orion RX 6800 XT',
      image: '3.png',
      price: 649.99,
      rating: 3,
      stock: true,
    },
    {
      name: 'Vortex RTX 3090',
      image: '4.png',
      price: 1499.99,
      rating: 4,
      stock: true,
    },
    {
      name: 'Cosmos GTX 1660 Super',
      image: '5.png',
      price: 299.99,
      rating: 4,
      stock: false,
    },
  ]
<\/script>

<script>
  export default {
    data () {
      return {
        search: '',
        items: [
          {
            name: 'Nebula GTX 3080',
            image: '1.png',
            price: 699.99,
            rating: 5,
            stock: true,
          },
          {
            name: 'Galaxy RTX 3080',
            image: '2.png',
            price: 799.99,
            rating: 4,
            stock: false,
          },
          {
            name: 'Orion RX 6800 XT',
            image: '3.png',
            price: 649.99,
            rating: 3,
            stock: true,
          },
          {
            name: 'Vortex RTX 3090',
            image: '4.png',
            price: 1499.99,
            rating: 4,
            stock: true,
          },
          {
            name: 'Cosmos GTX 1660 Super',
            image: '5.png',
            price: 299.99,
            rating: 4,
            stock: false,
          },
        ],
      }
    },
  }
<\/script>
`;
const _sfc_main$p = {
  __name: "prop-footer-props",
  setup(__props) {
    const headers = [
      {
        title: "Dessert (100g serving)",
        align: "start",
        value: "name"
      },
      { title: "Category", value: "category" }
    ];
    const desserts2 = [
      {
        name: "Frozen Yogurt",
        category: "Ice cream"
      },
      {
        name: "Ice cream sandwich",
        category: "Ice cream"
      },
      {
        name: "Eclair",
        category: "Cookie"
      },
      {
        name: "Cupcake",
        category: "Pastry"
      },
      {
        name: "Gingerbread",
        category: "Cookie"
      },
      {
        name: "Jelly bean",
        category: "Candy"
      },
      {
        name: "Lollipop",
        category: "Candy"
      },
      {
        name: "Honeycomb",
        category: "Toffee"
      },
      {
        name: "Donut",
        category: "Pastry"
      },
      {
        name: "KitKat",
        category: "Candy"
      }
    ];
    return (_ctx, _cache) => {
      const _component_v_data_table = resolveComponent("v-data-table");
      return openBlock(), createBlock(_component_v_data_table, {
        "footer-props": {
          showFirstLastPage: true,
          firstIcon: "mdi-arrow-collapse-left",
          lastIcon: "mdi-arrow-collapse-right",
          prevIcon: "mdi-minus",
          nextIcon: "mdi-plus"
        },
        headers,
        items: desserts2,
        "items-per-page": 5,
        "item-key": "name"
      });
    };
  }
};
const __10 = _sfc_main$p;
const __10_raw = `<template>
  <v-data-table
    :footer-props="{
      showFirstLastPage: true,
      firstIcon: 'mdi-arrow-collapse-left',
      lastIcon: 'mdi-arrow-collapse-right',
      prevIcon: 'mdi-minus',
      nextIcon: 'mdi-plus'
    }"
    :headers="headers"
    :items="desserts"
    :items-per-page="5"
    item-key="name"
  ></v-data-table>
</template>

<script setup>
  const headers = [
    {
      title: 'Dessert (100g serving)',
      align: 'start',
      value: 'name',
    },
    { title: 'Category', value: 'category' },
  ]
  const desserts = [
    {
      name: 'Frozen Yogurt',
      category: 'Ice cream',
    },
    {
      name: 'Ice cream sandwich',
      category: 'Ice cream',
    },
    {
      name: 'Eclair',
      category: 'Cookie',
    },
    {
      name: 'Cupcake',
      category: 'Pastry',
    },
    {
      name: 'Gingerbread',
      category: 'Cookie',
    },
    {
      name: 'Jelly bean',
      category: 'Candy',
    },
    {
      name: 'Lollipop',
      category: 'Candy',
    },
    {
      name: 'Honeycomb',
      category: 'Toffee',
    },
    {
      name: 'Donut',
      category: 'Pastry',
    },
    {
      name: 'KitKat',
      category: 'Candy',
    },
  ]
<\/script>

<script>
  export default {
    data: () => ({
      headers: [
        {
          title: 'Dessert (100g serving)',
          align: 'start',
          value: 'name',
        },
        { title: 'Category', value: 'category' },
      ],
      desserts: [
        {
          name: 'Frozen Yogurt',
          category: 'Ice cream',
        },
        {
          name: 'Ice cream sandwich',
          category: 'Ice cream',
        },
        {
          name: 'Eclair',
          category: 'Cookie',
        },
        {
          name: 'Cupcake',
          category: 'Pastry',
        },
        {
          name: 'Gingerbread',
          category: 'Cookie',
        },
        {
          name: 'Jelly bean',
          category: 'Candy',
        },
        {
          name: 'Lollipop',
          category: 'Candy',
        },
        {
          name: 'Honeycomb',
          category: 'Toffee',
        },
        {
          name: 'Donut',
          category: 'Pastry',
        },
        {
          name: 'KitKat',
          category: 'Candy',
        },
      ],
    }),
  }
<\/script>
`;
const _sfc_main$o = {
  __name: "prop-grouping",
  setup(__props) {
    const sortBy = ref([{ key: "name", order: "asc" }]);
    const groupBy = ref([{ key: "dairy", order: "asc" }]);
    const headers = [
      {
        title: "Dessert (100g serving)",
        align: "start",
        key: "name",
        groupable: false
      },
      { title: "Category", key: "category", align: "end" },
      { title: "Dairy", key: "dairy", align: "end" }
    ];
    const desserts2 = [
      {
        name: "Frozen Yogurt",
        category: "Ice cream",
        dairy: "Yes"
      },
      {
        name: "Ice cream sandwich",
        category: "Ice cream",
        dairy: "Yes"
      },
      {
        name: "Eclair",
        category: "Cookie",
        dairy: "Yes"
      },
      {
        name: "Cupcake",
        category: "Pastry",
        dairy: "Yes"
      },
      {
        name: "Gingerbread",
        category: "Cookie",
        dairy: "No"
      },
      {
        name: "Jelly bean",
        category: "Candy",
        dairy: "No"
      },
      {
        name: "Lollipop",
        category: "Candy",
        dairy: "No"
      },
      {
        name: "Honeycomb",
        category: "Toffee",
        dairy: "No"
      },
      {
        name: "Donut",
        category: "Pastry",
        dairy: "Yes"
      },
      {
        name: "KitKat",
        category: "Candy",
        dairy: "Yes"
      }
    ];
    return (_ctx, _cache) => {
      const _component_v_data_table = resolveComponent("v-data-table");
      return openBlock(), createBlock(_component_v_data_table, {
        "group-by": groupBy.value,
        headers,
        items: desserts2,
        "sort-by": sortBy.value,
        "item-value": "name"
      }, null, 8, ["group-by", "sort-by"]);
    };
  }
};
const __11 = _sfc_main$o;
const __11_raw = `<template>
  <v-data-table
    :group-by="groupBy"
    :headers="headers"
    :items="desserts"
    :sort-by="sortBy"
    item-value="name"
  ></v-data-table>
</template>
<script setup>
  import { ref } from 'vue'

  const sortBy = ref([{ key: 'name', order: 'asc' }])
  const groupBy = ref([{ key: 'dairy', order: 'asc' }])

  const headers = [
    {
      title: 'Dessert (100g serving)',
      align: 'start',
      key: 'name',
      groupable: false,
    },
    { title: 'Category', key: 'category', align: 'end' },
    { title: 'Dairy', key: 'dairy', align: 'end' },
  ]
  const desserts = [
    {
      name: 'Frozen Yogurt',
      category: 'Ice cream',
      dairy: 'Yes',
    },
    {
      name: 'Ice cream sandwich',
      category: 'Ice cream',
      dairy: 'Yes',
    },
    {
      name: 'Eclair',
      category: 'Cookie',
      dairy: 'Yes',
    },
    {
      name: 'Cupcake',
      category: 'Pastry',
      dairy: 'Yes',
    },
    {
      name: 'Gingerbread',
      category: 'Cookie',
      dairy: 'No',
    },
    {
      name: 'Jelly bean',
      category: 'Candy',
      dairy: 'No',
    },
    {
      name: 'Lollipop',
      category: 'Candy',
      dairy: 'No',
    },
    {
      name: 'Honeycomb',
      category: 'Toffee',
      dairy: 'No',
    },
    {
      name: 'Donut',
      category: 'Pastry',
      dairy: 'Yes',
    },
    {
      name: 'KitKat',
      category: 'Candy',
      dairy: 'Yes',
    },
  ]
<\/script>

<script>
  export default {
    data: () => ({
      sortBy: [{ key: 'name', order: 'asc' }],
      groupBy: [{ key: 'dairy', order: 'asc' }],
      headers: [
        {
          title: 'Dessert (100g serving)',
          align: 'start',
          key: 'name',
          groupable: false,
        },
        { title: 'Category', key: 'category', align: 'end' },
        { title: 'Dairy', key: 'dairy', align: 'end' },
      ],
      desserts: [
        {
          name: 'Frozen Yogurt',
          category: 'Ice cream',
          dairy: 'Yes',
        },
        {
          name: 'Ice cream sandwich',
          category: 'Ice cream',
          dairy: 'Yes',
        },
        {
          name: 'Eclair',
          category: 'Cookie',
          dairy: 'Yes',
        },
        {
          name: 'Cupcake',
          category: 'Pastry',
          dairy: 'Yes',
        },
        {
          name: 'Gingerbread',
          category: 'Cookie',
          dairy: 'No',
        },
        {
          name: 'Jelly bean',
          category: 'Candy',
          dairy: 'No',
        },
        {
          name: 'Lollipop',
          category: 'Candy',
          dairy: 'No',
        },
        {
          name: 'Honeycomb',
          category: 'Toffee',
          dairy: 'No',
        },
        {
          name: 'Donut',
          category: 'Pastry',
          dairy: 'Yes',
        },
        {
          name: 'KitKat',
          category: 'Candy',
          dairy: 'Yes',
        },
      ],
    }),
  }
<\/script>
`;
const _sfc_main$n = {
  __name: "prop-headers-sort-raw",
  setup(__props) {
    function sortRaw(a, b) {
      if (a.location < b.location)
        return -1;
      if (a.location > b.location)
        return 1;
      const dateA = a.constructed.split("-").pop().trim();
      const dateB = b.constructed.split("-").pop().trim();
      return dateA.localeCompare(dateB, void 0, { numeric: true, sensitivity: "base" });
    }
    const headers = [
      { title: "Name", key: "name" },
      { title: "Location", key: "location", sortRaw },
      { title: "Constructed", key: "constructed" },
      { title: "Description", key: "description" }
    ];
    const items = [
      { name: "Great Pyramid of Giza", location: "Egypt", constructed: "2584-2561 BC", description: "The oldest and largest of the three pyramids in the Giza pyramid complex." },
      { name: "Hanging Gardens of Babylon", location: "Iraq", constructed: "600 BC", description: "An ascending series of tiered gardens, said to have been built in ancient Babylon." },
      { name: "Statue of Zeus at Olympia", location: "Greece", constructed: "435 BC", description: "A giant seated figure of Zeus, made by the sculptor Phidias." },
      { name: "Temple of Artemis at Ephesus", location: "Turkey", constructed: "550 BC", description: "A large temple dedicated to the goddess Artemis, one of the Seven Wonders of the Ancient World." },
      { name: "Mausoleum at Halicarnassus", location: "Turkey", constructed: "351 BC", description: "A tomb built for Mausolus, a satrap of the Persian Empire." },
      { name: "Colossus of Rhodes", location: "Greece", constructed: "292-280 BC", description: "A statue of the Greek sun-god Helios, erected in the city of Rhodes." },
      { name: "Lighthouse of Alexandria", location: "Egypt", constructed: "280 BC", description: "A lighthouse built by the Ptolemaic Kingdom on the island of Pharos." },
      { name: "Great Wall of China", location: "China", constructed: "7th century BC - 1644 AD", description: "A series of fortifications made of stone, brick, and other materials." },
      { name: "Petra", location: "Jordan", constructed: "312 BC", description: "A historical city known for its rock-cut architecture and water conduit system." },
      { name: "Taj Mahal", location: "India", constructed: "1632-1653 AD", description: "An ivory-white marble mausoleum on the south bank of the Yamuna river." },
      { name: "Machu Picchu", location: "Peru", constructed: "1450 AD", description: "An Incan citadel set high in the Andes Mountains." },
      { name: "Chichen Itza", location: "Mexico", constructed: "600 AD", description: "A large pre-Columbian archaeological site built by the Maya people." },
      { name: "Roman Colosseum", location: "Italy", constructed: "70-80 AD", description: "An oval amphitheatre in the centre of the city of Rome." },
      { name: "Stonehenge", location: "United Kingdom", constructed: "3000 BC - 2000 BC", description: "A prehistoric monument consisting of a ring of standing stones." },
      { name: "Angkor Wat", location: "Cambodia", constructed: "12th century AD", description: "The largest religious monument in the world, originally constructed as a Hindu temple." },
      { name: "Moai Statues of Easter Island", location: "Chile", constructed: "1250-1500 AD", description: "Monolithic human figures carved by the Rapa Nui people on Easter Island." },
      { name: "Hagia Sophia", location: "Turkey", constructed: "537 AD", description: "A former Greek Orthodox Christian patriarchal basilica, later an Ottoman imperial mosque and now a museum." },
      { name: "Alhambra", location: "Spain", constructed: "13th century AD", description: "A palace and fortress complex located in Granada." },
      { name: "Forbidden City", location: "China", constructed: "1406-1420 AD", description: "A palace complex in central Beijing, serving as the home of emperors and their households." },
      { name: "Christ the Redeemer", location: "Brazil", constructed: "1922-1931 AD", description: "An Art Deco statue of Jesus Christ in Rio de Janeiro." },
      { name: "Acropolis of Athens", location: "Greece", constructed: "5th century BC", description: "An ancient citadel located on a rocky outcrop above the city of Athens." },
      { name: "Terracotta Army", location: "China", constructed: "246-206 BC", description: "A collection of terracotta sculptures depicting the armies of Qin Shi Huang, the first Emperor of China." },
      { name: "Parthenon", location: "Greece", constructed: "447-438 BC", description: "A former temple on the Athenian Acropolis, dedicated to the goddess Athena." },
      { name: "Tower of London", location: "United Kingdom", constructed: "1078 AD", description: "A historic castle located on the north bank of the River Thames in central London." },
      { name: "Neuschwanstein Castle", location: "Germany", constructed: "1869-1886 AD", description: "A 19th-century Romanesque Revival palace on a rugged hill above the village of Hohenschwangau." }
    ];
    return (_ctx, _cache) => {
      const _component_v_data_table = resolveComponent("v-data-table");
      return openBlock(), createBlock(_component_v_data_table, {
        headers,
        items
      });
    };
  }
};
const __12 = _sfc_main$n;
const __12_raw = `<template>
  <v-data-table
    :headers="headers"
    :items="items"
  ></v-data-table>
</template>

<script setup>
  function sortRaw (a, b) {
    if (a.location < b.location) return -1
    if (a.location > b.location) return 1

    const dateA = a.constructed.split('-').pop().trim()
    const dateB = b.constructed.split('-').pop().trim()

    return dateA.localeCompare(dateB, undefined, { numeric: true, sensitivity: 'base' })
  }

  const headers = [
    { title: 'Name', key: 'name' },
    { title: 'Location', key: 'location', sortRaw },
    { title: 'Constructed', key: 'constructed' },
    { title: 'Description', key: 'description' },
  ]

  const items = [
    { name: 'Great Pyramid of Giza', location: 'Egypt', constructed: '2584-2561 BC', description: 'The oldest and largest of the three pyramids in the Giza pyramid complex.' },
    { name: 'Hanging Gardens of Babylon', location: 'Iraq', constructed: '600 BC', description: 'An ascending series of tiered gardens, said to have been built in ancient Babylon.' },
    { name: 'Statue of Zeus at Olympia', location: 'Greece', constructed: '435 BC', description: 'A giant seated figure of Zeus, made by the sculptor Phidias.' },
    { name: 'Temple of Artemis at Ephesus', location: 'Turkey', constructed: '550 BC', description: 'A large temple dedicated to the goddess Artemis, one of the Seven Wonders of the Ancient World.' },
    { name: 'Mausoleum at Halicarnassus', location: 'Turkey', constructed: '351 BC', description: 'A tomb built for Mausolus, a satrap of the Persian Empire.' },
    { name: 'Colossus of Rhodes', location: 'Greece', constructed: '292-280 BC', description: 'A statue of the Greek sun-god Helios, erected in the city of Rhodes.' },
    { name: 'Lighthouse of Alexandria', location: 'Egypt', constructed: '280 BC', description: 'A lighthouse built by the Ptolemaic Kingdom on the island of Pharos.' },
    { name: 'Great Wall of China', location: 'China', constructed: '7th century BC - 1644 AD', description: 'A series of fortifications made of stone, brick, and other materials.' },
    { name: 'Petra', location: 'Jordan', constructed: '312 BC', description: 'A historical city known for its rock-cut architecture and water conduit system.' },
    { name: 'Taj Mahal', location: 'India', constructed: '1632-1653 AD', description: 'An ivory-white marble mausoleum on the south bank of the Yamuna river.' },
    { name: 'Machu Picchu', location: 'Peru', constructed: '1450 AD', description: 'An Incan citadel set high in the Andes Mountains.' },
    { name: 'Chichen Itza', location: 'Mexico', constructed: '600 AD', description: 'A large pre-Columbian archaeological site built by the Maya people.' },
    { name: 'Roman Colosseum', location: 'Italy', constructed: '70-80 AD', description: 'An oval amphitheatre in the centre of the city of Rome.' },
    { name: 'Stonehenge', location: 'United Kingdom', constructed: '3000 BC - 2000 BC', description: 'A prehistoric monument consisting of a ring of standing stones.' },
    { name: 'Angkor Wat', location: 'Cambodia', constructed: '12th century AD', description: 'The largest religious monument in the world, originally constructed as a Hindu temple.' },
    { name: 'Moai Statues of Easter Island', location: 'Chile', constructed: '1250-1500 AD', description: 'Monolithic human figures carved by the Rapa Nui people on Easter Island.' },
    { name: 'Hagia Sophia', location: 'Turkey', constructed: '537 AD', description: 'A former Greek Orthodox Christian patriarchal basilica, later an Ottoman imperial mosque and now a museum.' },
    { name: 'Alhambra', location: 'Spain', constructed: '13th century AD', description: 'A palace and fortress complex located in Granada.' },
    { name: 'Forbidden City', location: 'China', constructed: '1406-1420 AD', description: 'A palace complex in central Beijing, serving as the home of emperors and their households.' },
    { name: 'Christ the Redeemer', location: 'Brazil', constructed: '1922-1931 AD', description: 'An Art Deco statue of Jesus Christ in Rio de Janeiro.' },
    { name: 'Acropolis of Athens', location: 'Greece', constructed: '5th century BC', description: 'An ancient citadel located on a rocky outcrop above the city of Athens.' },
    { name: 'Terracotta Army', location: 'China', constructed: '246-206 BC', description: 'A collection of terracotta sculptures depicting the armies of Qin Shi Huang, the first Emperor of China.' },
    { name: 'Parthenon', location: 'Greece', constructed: '447-438 BC', description: 'A former temple on the Athenian Acropolis, dedicated to the goddess Athena.' },
    { name: 'Tower of London', location: 'United Kingdom', constructed: '1078 AD', description: 'A historic castle located on the north bank of the River Thames in central London.' },
    { name: 'Neuschwanstein Castle', location: 'Germany', constructed: '1869-1886 AD', description: 'A 19th-century Romanesque Revival palace on a rugged hill above the village of Hohenschwangau.' },
  ]
<\/script>

<script>
  export default {
    data: () => ({
      headers: [
        { title: 'Name', key: 'name' },
        {
          title: 'Location',
          key: 'location',
          sortRaw (a, b) {
            if (a.location < b.location) return -1
            if (a.location > b.location) return 1

            const dateA = a.constructed.split('-').pop().trim()
            const dateB = b.constructed.split('-').pop().trim()

            return dateA.localeCompare(dateB, undefined, { numeric: true, sensitivity: 'base' })
          },
        },
        { title: 'Constructed', key: 'constructed' },
        { title: 'Description', key: 'description' },
      ],
      items: [
        { name: 'Great Pyramid of Giza', location: 'Egypt', constructed: '2584-2561 BC', description: 'The oldest and largest of the three pyramids in the Giza pyramid complex.' },
        { name: 'Hanging Gardens of Babylon', location: 'Iraq', constructed: '600 BC', description: 'An ascending series of tiered gardens, said to have been built in ancient Babylon.' },
        { name: 'Statue of Zeus at Olympia', location: 'Greece', constructed: '435 BC', description: 'A giant seated figure of Zeus, made by the sculptor Phidias.' },
        { name: 'Temple of Artemis at Ephesus', location: 'Turkey', constructed: '550 BC', description: 'A large temple dedicated to the goddess Artemis, one of the Seven Wonders of the Ancient World.' },
        { name: 'Mausoleum at Halicarnassus', location: 'Turkey', constructed: '351 BC', description: 'A tomb built for Mausolus, a satrap of the Persian Empire.' },
        { name: 'Colossus of Rhodes', location: 'Greece', constructed: '292-280 BC', description: 'A statue of the Greek sun-god Helios, erected in the city of Rhodes.' },
        { name: 'Lighthouse of Alexandria', location: 'Egypt', constructed: '280 BC', description: 'A lighthouse built by the Ptolemaic Kingdom on the island of Pharos.' },
        { name: 'Great Wall of China', location: 'China', constructed: '7th century BC - 1644 AD', description: 'A series of fortifications made of stone, brick, and other materials.' },
        { name: 'Petra', location: 'Jordan', constructed: '312 BC', description: 'A historical city known for its rock-cut architecture and water conduit system.' },
        { name: 'Taj Mahal', location: 'India', constructed: '1632-1653 AD', description: 'An ivory-white marble mausoleum on the south bank of the Yamuna river.' },
        { name: 'Machu Picchu', location: 'Peru', constructed: '1450 AD', description: 'An Incan citadel set high in the Andes Mountains.' },
        { name: 'Chichen Itza', location: 'Mexico', constructed: '600 AD', description: 'A large pre-Columbian archaeological site built by the Maya people.' },
        { name: 'Roman Colosseum', location: 'Italy', constructed: '70-80 AD', description: 'An oval amphitheatre in the centre of the city of Rome.' },
        { name: 'Stonehenge', location: 'United Kingdom', constructed: '3000 BC - 2000 BC', description: 'A prehistoric monument consisting of a ring of standing stones.' },
        { name: 'Angkor Wat', location: 'Cambodia', constructed: '12th century AD', description: 'The largest religious monument in the world, originally constructed as a Hindu temple.' },
        { name: 'Moai Statues of Easter Island', location: 'Chile', constructed: '1250-1500 AD', description: 'Monolithic human figures carved by the Rapa Nui people on Easter Island.' },
        { name: 'Hagia Sophia', location: 'Turkey', constructed: '537 AD', description: 'A former Greek Orthodox Christian patriarchal basilica, later an Ottoman imperial mosque and now a museum.' },
        { name: 'Alhambra', location: 'Spain', constructed: '13th century AD', description: 'A palace and fortress complex located in Granada.' },
        { name: 'Forbidden City', location: 'China', constructed: '1406-1420 AD', description: 'A palace complex in central Beijing, serving as the home of emperors and their households.' },
        { name: 'Christ the Redeemer', location: 'Brazil', constructed: '1922-1931 AD', description: 'An Art Deco statue of Jesus Christ in Rio de Janeiro.' },
        { name: 'Acropolis of Athens', location: 'Greece', constructed: '5th century BC', description: 'An ancient citadel located on a rocky outcrop above the city of Athens.' },
        { name: 'Terracotta Army', location: 'China', constructed: '246-206 BC', description: 'A collection of terracotta sculptures depicting the armies of Qin Shi Huang, the first Emperor of China.' },
        { name: 'Parthenon', location: 'Greece', constructed: '447-438 BC', description: 'A former temple on the Athenian Acropolis, dedicated to the goddess Athena.' },
        { name: 'Tower of London', location: 'United Kingdom', constructed: '1078 AD', description: 'A historic castle located on the north bank of the River Thames in central London.' },
        { name: 'Neuschwanstein Castle', location: 'Germany', constructed: '1869-1886 AD', description: 'A 19th-century Romanesque Revival palace on a rugged hill above the village of Hohenschwangau.' },
      ],
    }),
  }
<\/script>
`;
const _sfc_main$m = {
  __name: "prop-hide-header-footer",
  setup(__props) {
    const headers = [
      {
        title: "Dessert (100g serving)",
        align: "start",
        key: "name"
      },
      { title: "Calories", align: "end", key: "calories" },
      { title: "Fat (g)", align: "end", key: "fat" },
      { title: "Carbs (g)", align: "end", key: "carbs" },
      { title: "Protein (g)", align: "end", key: "protein" },
      { title: "Iron (%)", align: "end", key: "iron" }
    ];
    const desserts2 = [
      {
        name: "Frozen Yogurt",
        calories: 159,
        fat: 6,
        carbs: 24,
        protein: 4,
        iron: "1%"
      },
      {
        name: "Ice cream sandwich",
        calories: 237,
        fat: 9,
        carbs: 37,
        protein: 4.3,
        iron: "1%"
      },
      {
        name: "Eclair",
        calories: 262,
        fat: 16,
        carbs: 23,
        protein: 6,
        iron: "7%"
      },
      {
        name: "Cupcake",
        calories: 305,
        fat: 3.7,
        carbs: 67,
        protein: 4.3,
        iron: "8%"
      },
      {
        name: "Gingerbread",
        calories: 356,
        fat: 16,
        carbs: 49,
        protein: 3.9,
        iron: "16%"
      },
      {
        name: "Jelly bean",
        calories: 375,
        fat: 0,
        carbs: 94,
        protein: 0,
        iron: "0%"
      },
      {
        name: "Lollipop",
        calories: 392,
        fat: 0.2,
        carbs: 98,
        protein: 0,
        iron: "2%"
      },
      {
        name: "Honeycomb",
        calories: 408,
        fat: 3.2,
        carbs: 87,
        protein: 6.5,
        iron: "45%"
      },
      {
        name: "Donut",
        calories: 452,
        fat: 25,
        carbs: 51,
        protein: 4.9,
        iron: "22%"
      },
      {
        name: "KitKat",
        calories: 518,
        fat: 26,
        carbs: 65,
        protein: 7,
        iron: "6%"
      }
    ];
    return (_ctx, _cache) => {
      const _component_v_data_table = resolveComponent("v-data-table");
      return openBlock(), createBlock(_component_v_data_table, {
        headers,
        items: desserts2,
        "hide-default-footer": "",
        "hide-default-header": ""
      });
    };
  }
};
const __13 = _sfc_main$m;
const __13_raw = `<template>
  <v-data-table
    :headers="headers"
    :items="desserts"
    hide-default-footer
    hide-default-header
  ></v-data-table>
</template>

<script setup>
  const headers = [
    {
      title: 'Dessert (100g serving)',
      align: 'start',
      key: 'name',
    },
    { title: 'Calories', align: 'end', key: 'calories' },
    { title: 'Fat (g)', align: 'end', key: 'fat' },
    { title: 'Carbs (g)', align: 'end', key: 'carbs' },
    { title: 'Protein (g)', align: 'end', key: 'protein' },
    { title: 'Iron (%)', align: 'end', key: 'iron' },
  ]
  const desserts = [
    {
      name: 'Frozen Yogurt',
      calories: 159,
      fat: 6,
      carbs: 24,
      protein: 4,
      iron: '1%',
    },
    {
      name: 'Ice cream sandwich',
      calories: 237,
      fat: 9,
      carbs: 37,
      protein: 4.3,
      iron: '1%',
    },
    {
      name: 'Eclair',
      calories: 262,
      fat: 16,
      carbs: 23,
      protein: 6,
      iron: '7%',
    },
    {
      name: 'Cupcake',
      calories: 305,
      fat: 3.7,
      carbs: 67,
      protein: 4.3,
      iron: '8%',
    },
    {
      name: 'Gingerbread',
      calories: 356,
      fat: 16,
      carbs: 49,
      protein: 3.9,
      iron: '16%',
    },
    {
      name: 'Jelly bean',
      calories: 375,
      fat: 0,
      carbs: 94,
      protein: 0,
      iron: '0%',
    },
    {
      name: 'Lollipop',
      calories: 392,
      fat: 0.2,
      carbs: 98,
      protein: 0,
      iron: '2%',
    },
    {
      name: 'Honeycomb',
      calories: 408,
      fat: 3.2,
      carbs: 87,
      protein: 6.5,
      iron: '45%',
    },
    {
      name: 'Donut',
      calories: 452,
      fat: 25,
      carbs: 51,
      protein: 4.9,
      iron: '22%',
    },
    {
      name: 'KitKat',
      calories: 518,
      fat: 26,
      carbs: 65,
      protein: 7,
      iron: '6%',
    },
  ]
<\/script>

<script>
  export default {
    data: () => ({
      headers: [
        {
          title: 'Dessert (100g serving)',
          align: 'start',
          key: 'name',
        },
        { title: 'Calories', align: 'end', key: 'calories' },
        { title: 'Fat (g)', align: 'end', key: 'fat' },
        { title: 'Carbs (g)', align: 'end', key: 'carbs' },
        { title: 'Protein (g)', align: 'end', key: 'protein' },
        { title: 'Iron (%)', align: 'end', key: 'iron' },
      ],
      desserts: [
        {
          name: 'Frozen Yogurt',
          calories: 159,
          fat: 6.0,
          carbs: 24,
          protein: 4.0,
          iron: '1%',
        },
        {
          name: 'Ice cream sandwich',
          calories: 237,
          fat: 9.0,
          carbs: 37,
          protein: 4.3,
          iron: '1%',
        },
        {
          name: 'Eclair',
          calories: 262,
          fat: 16.0,
          carbs: 23,
          protein: 6.0,
          iron: '7%',
        },
        {
          name: 'Cupcake',
          calories: 305,
          fat: 3.7,
          carbs: 67,
          protein: 4.3,
          iron: '8%',
        },
        {
          name: 'Gingerbread',
          calories: 356,
          fat: 16.0,
          carbs: 49,
          protein: 3.9,
          iron: '16%',
        },
        {
          name: 'Jelly bean',
          calories: 375,
          fat: 0.0,
          carbs: 94,
          protein: 0.0,
          iron: '0%',
        },
        {
          name: 'Lollipop',
          calories: 392,
          fat: 0.2,
          carbs: 98,
          protein: 0,
          iron: '2%',
        },
        {
          name: 'Honeycomb',
          calories: 408,
          fat: 3.2,
          carbs: 87,
          protein: 6.5,
          iron: '45%',
        },
        {
          name: 'Donut',
          calories: 452,
          fat: 25.0,
          carbs: 51,
          protein: 4.9,
          iron: '22%',
        },
        {
          name: 'KitKat',
          calories: 518,
          fat: 26.0,
          carbs: 65,
          protein: 7,
          iron: '6%',
        },
      ],
    }),
  }
<\/script>
`;
const _sfc_main$l = {
  __name: "prop-item-selectable",
  setup(__props) {
    const headers = [
      {
        title: "Dessert (100g serving)",
        align: "start",
        key: "name"
      },
      { title: "Calories", align: "end", key: "calories" },
      { title: "Fat (g)", align: "end", key: "fat" },
      { title: "Carbs (g)", align: "end", key: "carbs" },
      { title: "Protein (g)", align: "end", key: "protein" },
      { title: "Iron (%)", align: "end", key: "iron" }
    ];
    const desserts2 = [
      {
        name: "Frozen Yogurt",
        calories: 159,
        fat: 6,
        carbs: 24,
        protein: 4,
        iron: 1,
        selectable: false
      },
      {
        name: "Ice cream sandwich",
        calories: 237,
        fat: 9,
        carbs: 37,
        protein: 4.3,
        iron: 1,
        selectable: true
      },
      {
        name: "Eclair",
        calories: 262,
        fat: 16,
        carbs: 23,
        protein: 6,
        iron: 7,
        selectable: true
      },
      {
        name: "Cupcake",
        calories: 305,
        fat: 3.7,
        carbs: 67,
        protein: 4.3,
        iron: 8,
        selectable: false
      },
      {
        name: "Gingerbread",
        calories: 356,
        fat: 16,
        carbs: 49,
        protein: 3.9,
        iron: 16,
        selectable: true
      },
      {
        name: "Jelly bean",
        calories: 375,
        fat: 0,
        carbs: 94,
        protein: 0,
        iron: 0,
        selectable: true
      },
      {
        name: "Lollipop",
        calories: 392,
        fat: 0.2,
        carbs: 98,
        protein: 0,
        iron: 2,
        selectable: true
      },
      {
        name: "Honeycomb",
        calories: 408,
        fat: 3.2,
        carbs: 87,
        protein: 6.5,
        iron: 45,
        selectable: false
      },
      {
        name: "Donut",
        calories: 452,
        fat: 25,
        carbs: 51,
        protein: 4.9,
        iron: 22,
        selectable: true
      },
      {
        name: "KitKat",
        calories: 518,
        fat: 26,
        carbs: 65,
        protein: 7,
        iron: 6,
        selectable: true
      }
    ];
    return (_ctx, _cache) => {
      const _component_v_data_table = resolveComponent("v-data-table");
      return openBlock(), createBlock(_component_v_data_table, {
        headers,
        items: desserts2,
        "item-selectable": "selectable",
        "item-value": "name",
        "items-per-page": "5",
        "show-select": ""
      });
    };
  }
};
const __14 = _sfc_main$l;
const __14_raw = `<template>
  <v-data-table
    :headers="headers"
    :items="desserts"
    item-selectable="selectable"
    item-value="name"
    items-per-page="5"
    show-select
  ></v-data-table>
</template>

<script setup>
  const headers = [
    {
      title: 'Dessert (100g serving)',
      align: 'start',
      key: 'name',
    },
    { title: 'Calories', align: 'end', key: 'calories' },
    { title: 'Fat (g)', align: 'end', key: 'fat' },
    { title: 'Carbs (g)', align: 'end', key: 'carbs' },
    { title: 'Protein (g)', align: 'end', key: 'protein' },
    { title: 'Iron (%)', align: 'end', key: 'iron' },
  ]
  const desserts = [
    {
      name: 'Frozen Yogurt',
      calories: 159,
      fat: 6,
      carbs: 24,
      protein: 4,
      iron: 1,
      selectable: false,
    },
    {
      name: 'Ice cream sandwich',
      calories: 237,
      fat: 9,
      carbs: 37,
      protein: 4.3,
      iron: 1,
      selectable: true,
    },
    {
      name: 'Eclair',
      calories: 262,
      fat: 16,
      carbs: 23,
      protein: 6,
      iron: 7,
      selectable: true,
    },
    {
      name: 'Cupcake',
      calories: 305,
      fat: 3.7,
      carbs: 67,
      protein: 4.3,
      iron: 8,
      selectable: false,
    },
    {
      name: 'Gingerbread',
      calories: 356,
      fat: 16,
      carbs: 49,
      protein: 3.9,
      iron: 16,
      selectable: true,
    },
    {
      name: 'Jelly bean',
      calories: 375,
      fat: 0,
      carbs: 94,
      protein: 0,
      iron: 0,
      selectable: true,
    },
    {
      name: 'Lollipop',
      calories: 392,
      fat: 0.2,
      carbs: 98,
      protein: 0,
      iron: 2,
      selectable: true,
    },
    {
      name: 'Honeycomb',
      calories: 408,
      fat: 3.2,
      carbs: 87,
      protein: 6.5,
      iron: 45,
      selectable: false,
    },
    {
      name: 'Donut',
      calories: 452,
      fat: 25,
      carbs: 51,
      protein: 4.9,
      iron: 22,
      selectable: true,
    },
    {
      name: 'KitKat',
      calories: 518,
      fat: 26,
      carbs: 65,
      protein: 7,
      iron: 6,
      selectable: true,
    },
  ]
<\/script>

<script>
  export default {
    data () {
      return {
        headers: [
          {
            title: 'Dessert (100g serving)',
            align: 'start',
            key: 'name',
          },
          { title: 'Calories', align: 'end', key: 'calories' },
          { title: 'Fat (g)', align: 'end', key: 'fat' },
          { title: 'Carbs (g)', align: 'end', key: 'carbs' },
          { title: 'Protein (g)', align: 'end', key: 'protein' },
          { title: 'Iron (%)', align: 'end', key: 'iron' },
        ],
        desserts: [
          {
            name: 'Frozen Yogurt',
            calories: 159,
            fat: 6.0,
            carbs: 24,
            protein: 4.0,
            iron: 1,
            selectable: false,
          },
          {
            name: 'Ice cream sandwich',
            calories: 237,
            fat: 9.0,
            carbs: 37,
            protein: 4.3,
            iron: 1,
            selectable: true,
          },
          {
            name: 'Eclair',
            calories: 262,
            fat: 16.0,
            carbs: 23,
            protein: 6.0,
            iron: 7,
            selectable: true,
          },
          {
            name: 'Cupcake',
            calories: 305,
            fat: 3.7,
            carbs: 67,
            protein: 4.3,
            iron: 8,
            selectable: false,
          },
          {
            name: 'Gingerbread',
            calories: 356,
            fat: 16.0,
            carbs: 49,
            protein: 3.9,
            iron: 16,
            selectable: true,
          },
          {
            name: 'Jelly bean',
            calories: 375,
            fat: 0.0,
            carbs: 94,
            protein: 0.0,
            iron: 0,
            selectable: true,
          },
          {
            name: 'Lollipop',
            calories: 392,
            fat: 0.2,
            carbs: 98,
            protein: 0,
            iron: 2,
            selectable: true,
          },
          {
            name: 'Honeycomb',
            calories: 408,
            fat: 3.2,
            carbs: 87,
            protein: 6.5,
            iron: 45,
            selectable: false,
          },
          {
            name: 'Donut',
            calories: 452,
            fat: 25.0,
            carbs: 51,
            protein: 4.9,
            iron: 22,
            selectable: true,
          },
          {
            name: 'KitKat',
            calories: 518,
            fat: 26.0,
            carbs: 65,
            protein: 7,
            iron: 6,
            selectable: true,
          },
        ],
      }
    },
  }
<\/script>
`;
const _sfc_main$k = {
  __name: "prop-item-value",
  setup(__props) {
    const headers = [
      {
        title: "Operating System",
        align: "start",
        key: "name"
      },
      { title: "Version", align: "end", key: "version" }
    ];
    const desserts2 = [
      {
        name: "Windows",
        version: "3.11"
      },
      {
        name: "Windows",
        version: "95"
      },
      {
        name: "Windows",
        version: "98"
      },
      {
        name: "Windows",
        version: "2000"
      },
      {
        name: "Windows",
        version: "XP"
      },
      {
        name: "Windows",
        version: "Vista"
      },
      {
        name: "Windows",
        version: "7"
      },
      {
        name: "Windows",
        version: "8"
      },
      {
        name: "Windows",
        version: "10"
      },
      {
        name: "Windows",
        version: "11"
      }
    ];
    return (_ctx, _cache) => {
      const _component_v_data_table = resolveComponent("v-data-table");
      return openBlock(), createBlock(_component_v_data_table, {
        headers,
        "item-value": (item) => `${item.name}-${item.version}`,
        items: desserts2,
        "items-per-page": "5",
        "show-select": ""
      }, null, 8, ["item-value"]);
    };
  }
};
const __15 = _sfc_main$k;
const __15_raw = `<template>
  <v-data-table
    :headers="headers"
    :item-value="item => \`\${item.name}-\${item.version}\`"
    :items="desserts"
    items-per-page="5"
    show-select
  ></v-data-table>
</template>

<script setup>
  const headers = [
    {
      title: 'Operating System',
      align: 'start',
      key: 'name',
    },
    { title: 'Version', align: 'end', key: 'version' },
  ]
  const desserts = [
    {
      name: 'Windows',
      version: '3.11',
    },
    {
      name: 'Windows',
      version: '95',
    },
    {
      name: 'Windows',
      version: '98',
    },
    {
      name: 'Windows',
      version: '2000',
    },
    {
      name: 'Windows',
      version: 'XP',
    },
    {
      name: 'Windows',
      version: 'Vista',
    },
    {
      name: 'Windows',
      version: '7',
    },
    {
      name: 'Windows',
      version: '8',
    },
    {
      name: 'Windows',
      version: '10',
    },
    {
      name: 'Windows',
      version: '11',
    },
  ]
<\/script>

<script>
  export default {
    data () {
      return {
        headers: [
          {
            title: 'Operating System',
            align: 'start',
            key: 'name',
          },
          { title: 'Version', align: 'end', key: 'version' },
        ],
        desserts: [
          {
            name: 'Windows',
            version: '3.11',
          },
          {
            name: 'Windows',
            version: '95',
          },
          {
            name: 'Windows',
            version: '98',
          },
          {
            name: 'Windows',
            version: '2000',
          },
          {
            name: 'Windows',
            version: 'XP',
          },
          {
            name: 'Windows',
            version: 'Vista',
          },
          {
            name: 'Windows',
            version: '7',
          },
          {
            name: 'Windows',
            version: '8',
          },
          {
            name: 'Windows',
            version: '10',
          },
          {
            name: 'Windows',
            version: '11',
          },
        ],
      }
    },
  }
<\/script>
`;
const _sfc_main$j = {};
function _sfc_render$1(_ctx, _cache) {
  const _component_v_data_table_server = resolveComponent("v-data-table-server");
  return openBlock(), createBlock(_component_v_data_table_server, {
    "items-length": 0,
    "item-key": "name",
    "loading-text": "Loading... Please wait",
    loading: ""
  });
}
const __16 = /* @__PURE__ */ _export_sfc(_sfc_main$j, [["render", _sfc_render$1]]);
const __16_raw = '<template>\n  <v-data-table-server\n    :items-length="0"\n    item-key="name"\n    loading-text="Loading... Please wait"\n    loading\n  ></v-data-table-server>\n</template>\n';
const _sfc_main$i = {
  __name: "prop-multi-sort",
  setup(__props) {
    const headers = [
      {
        title: "Dessert (100g serving)",
        align: "start",
        sortable: false,
        key: "name"
      },
      { title: "Calories", key: "calories" },
      { title: "Fat (g)", key: "fat" },
      { title: "Carbs (g)", key: "carbs" },
      { title: "Protein (g)", key: "protein" },
      { title: "Iron (%)", key: "iron" }
    ];
    const desserts2 = [
      {
        name: "Frozen Yogurt",
        calories: 200,
        fat: 6,
        carbs: 24,
        protein: 4,
        iron: 1
      },
      {
        name: "Ice cream sandwich",
        calories: 200,
        fat: 9,
        carbs: 37,
        protein: 4.3,
        iron: 1
      },
      {
        name: "Eclair",
        calories: 300,
        fat: 16,
        carbs: 23,
        protein: 6,
        iron: 7
      },
      {
        name: "Cupcake",
        calories: 300,
        fat: 3.7,
        carbs: 67,
        protein: 4.3,
        iron: 8
      },
      {
        name: "Gingerbread",
        calories: 400,
        fat: 16,
        carbs: 49,
        protein: 3.9,
        iron: 16
      },
      {
        name: "Jelly bean",
        calories: 400,
        fat: 0,
        carbs: 94,
        protein: 0,
        iron: 0
      },
      {
        name: "Lollipop",
        calories: 400,
        fat: 0.2,
        carbs: 98,
        protein: 0,
        iron: 2
      },
      {
        name: "Honeycomb",
        calories: 400,
        fat: 3.2,
        carbs: 87,
        protein: 6.5,
        iron: 45
      },
      {
        name: "Donut",
        calories: 500,
        fat: 25,
        carbs: 51,
        protein: 4.9,
        iron: 22
      },
      {
        name: "KitKat",
        calories: 500,
        fat: 26,
        carbs: 65,
        protein: 7,
        iron: 6
      }
    ];
    return (_ctx, _cache) => {
      const _component_v_data_table = resolveComponent("v-data-table");
      return openBlock(), createBlock(_component_v_data_table, {
        headers,
        items: desserts2,
        "sort-by": [{ key: "calories", order: "asc" }, { key: "fat", order: "desc" }],
        "multi-sort": ""
      });
    };
  }
};
const __17 = _sfc_main$i;
const __17_raw = `<template>
  <v-data-table
    :headers="headers"
    :items="desserts"
    :sort-by="[{ key: 'calories', order: 'asc' }, { key: 'fat', order: 'desc' }]"
    multi-sort
  ></v-data-table>
</template>

<script setup>
  const headers = [
    {
      title: 'Dessert (100g serving)',
      align: 'start',
      sortable: false,
      key: 'name',
    },
    { title: 'Calories', key: 'calories' },
    { title: 'Fat (g)', key: 'fat' },
    { title: 'Carbs (g)', key: 'carbs' },
    { title: 'Protein (g)', key: 'protein' },
    { title: 'Iron (%)', key: 'iron' },
  ]
  const desserts = [
    {
      name: 'Frozen Yogurt',
      calories: 200,
      fat: 6,
      carbs: 24,
      protein: 4,
      iron: 1,
    },
    {
      name: 'Ice cream sandwich',
      calories: 200,
      fat: 9,
      carbs: 37,
      protein: 4.3,
      iron: 1,
    },
    {
      name: 'Eclair',
      calories: 300,
      fat: 16,
      carbs: 23,
      protein: 6,
      iron: 7,
    },
    {
      name: 'Cupcake',
      calories: 300,
      fat: 3.7,
      carbs: 67,
      protein: 4.3,
      iron: 8,
    },
    {
      name: 'Gingerbread',
      calories: 400,
      fat: 16,
      carbs: 49,
      protein: 3.9,
      iron: 16,
    },
    {
      name: 'Jelly bean',
      calories: 400,
      fat: 0,
      carbs: 94,
      protein: 0,
      iron: 0,
    },
    {
      name: 'Lollipop',
      calories: 400,
      fat: 0.2,
      carbs: 98,
      protein: 0,
      iron: 2,
    },
    {
      name: 'Honeycomb',
      calories: 400,
      fat: 3.2,
      carbs: 87,
      protein: 6.5,
      iron: 45,
    },
    {
      name: 'Donut',
      calories: 500,
      fat: 25,
      carbs: 51,
      protein: 4.9,
      iron: 22,
    },
    {
      name: 'KitKat',
      calories: 500,
      fat: 26,
      carbs: 65,
      protein: 7,
      iron: 6,
    },
  ]
<\/script>

<script>
  export default {
    data () {
      return {
        headers: [
          {
            title: 'Dessert (100g serving)',
            align: 'start',
            sortable: false,
            key: 'name',
          },
          { title: 'Calories', key: 'calories' },
          { title: 'Fat (g)', key: 'fat' },
          { title: 'Carbs (g)', key: 'carbs' },
          { title: 'Protein (g)', key: 'protein' },
          { title: 'Iron (%)', key: 'iron' },
        ],
        desserts: [
          {
            name: 'Frozen Yogurt',
            calories: 200,
            fat: 6.0,
            carbs: 24,
            protein: 4.0,
            iron: 1,
          },
          {
            name: 'Ice cream sandwich',
            calories: 200,
            fat: 9.0,
            carbs: 37,
            protein: 4.3,
            iron: 1,
          },
          {
            name: 'Eclair',
            calories: 300,
            fat: 16.0,
            carbs: 23,
            protein: 6.0,
            iron: 7,
          },
          {
            name: 'Cupcake',
            calories: 300,
            fat: 3.7,
            carbs: 67,
            protein: 4.3,
            iron: 8,
          },
          {
            name: 'Gingerbread',
            calories: 400,
            fat: 16.0,
            carbs: 49,
            protein: 3.9,
            iron: 16,
          },
          {
            name: 'Jelly bean',
            calories: 400,
            fat: 0.0,
            carbs: 94,
            protein: 0.0,
            iron: 0,
          },
          {
            name: 'Lollipop',
            calories: 400,
            fat: 0.2,
            carbs: 98,
            protein: 0,
            iron: 2,
          },
          {
            name: 'Honeycomb',
            calories: 400,
            fat: 3.2,
            carbs: 87,
            protein: 6.5,
            iron: 45,
          },
          {
            name: 'Donut',
            calories: 500,
            fat: 25.0,
            carbs: 51,
            protein: 4.9,
            iron: 22,
          },
          {
            name: 'KitKat',
            calories: 500,
            fat: 26.0,
            carbs: 65,
            protein: 7,
            iron: 6,
          },
        ],
      }
    },
  }
<\/script>
`;
const _sfc_main$h = {
  __name: "prop-return-object",
  setup(__props) {
    const selected = ref([]);
    const headers = ref([
      {
        title: "Dessert (100g serving)",
        align: "start",
        key: "name"
      },
      { title: "Calories", align: "end", key: "calories" },
      { title: "Fat (g)", align: "end", key: "fat" },
      { title: "Carbs (g)", align: "end", key: "carbs" },
      { title: "Protein (g)", align: "end", key: "protein" },
      { title: "Iron (%)", align: "end", key: "iron" }
    ]);
    const desserts2 = ref([
      {
        name: "Frozen Yogurt",
        calories: 159,
        fat: 6,
        carbs: 24,
        protein: 4,
        iron: 1
      },
      {
        name: "Ice cream sandwich",
        calories: 237,
        fat: 9,
        carbs: 37,
        protein: 4.3,
        iron: 1
      },
      {
        name: "Eclair",
        calories: 262,
        fat: 16,
        carbs: 23,
        protein: 6,
        iron: 7
      },
      {
        name: "Cupcake",
        calories: 305,
        fat: 3.7,
        carbs: 67,
        protein: 4.3,
        iron: 8
      },
      {
        name: "Gingerbread",
        calories: 356,
        fat: 16,
        carbs: 49,
        protein: 3.9,
        iron: 16
      },
      {
        name: "Jelly bean",
        calories: 375,
        fat: 0,
        carbs: 94,
        protein: 0,
        iron: 0
      },
      {
        name: "Lollipop",
        calories: 392,
        fat: 0.2,
        carbs: 98,
        protein: 0,
        iron: 2
      },
      {
        name: "Honeycomb",
        calories: 408,
        fat: 3.2,
        carbs: 87,
        protein: 6.5,
        iron: 45
      },
      {
        name: "Donut",
        calories: 452,
        fat: 25,
        carbs: 51,
        protein: 4.9,
        iron: 22
      },
      {
        name: "KitKat",
        calories: 518,
        fat: 26,
        carbs: 65,
        protein: 7,
        iron: 6
      }
    ]);
    return (_ctx, _cache) => {
      const _component_v_data_table = resolveComponent("v-data-table");
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(_component_v_data_table, {
          modelValue: selected.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => selected.value = $event),
          headers: headers.value,
          items: desserts2.value,
          "item-value": "name",
          "items-per-page": "5",
          "return-object": "",
          "show-select": ""
        }, null, 8, ["modelValue", "headers", "items"]),
        createBaseVNode("pre", null, toDisplayString(selected.value), 1)
      ], 64);
    };
  }
};
const __18 = _sfc_main$h;
const __18_raw = `<template>
  <v-data-table
    v-model="selected"
    :headers="headers"
    :items="desserts"
    item-value="name"
    items-per-page="5"
    return-object
    show-select
  ></v-data-table>

  <pre>{{ selected }}</pre>
</template>

<script setup>
  import { ref } from 'vue'

  const selected = ref([])

  const headers = ref([
    {
      title: 'Dessert (100g serving)',
      align: 'start',
      key: 'name',
    },
    { title: 'Calories', align: 'end', key: 'calories' },
    { title: 'Fat (g)', align: 'end', key: 'fat' },
    { title: 'Carbs (g)', align: 'end', key: 'carbs' },
    { title: 'Protein (g)', align: 'end', key: 'protein' },
    { title: 'Iron (%)', align: 'end', key: 'iron' },
  ])
  const desserts = ref([
    {
      name: 'Frozen Yogurt',
      calories: 159,
      fat: 6,
      carbs: 24,
      protein: 4,
      iron: 1,
    },
    {
      name: 'Ice cream sandwich',
      calories: 237,
      fat: 9,
      carbs: 37,
      protein: 4.3,
      iron: 1,
    },
    {
      name: 'Eclair',
      calories: 262,
      fat: 16,
      carbs: 23,
      protein: 6,
      iron: 7,
    },
    {
      name: 'Cupcake',
      calories: 305,
      fat: 3.7,
      carbs: 67,
      protein: 4.3,
      iron: 8,
    },
    {
      name: 'Gingerbread',
      calories: 356,
      fat: 16,
      carbs: 49,
      protein: 3.9,
      iron: 16,
    },
    {
      name: 'Jelly bean',
      calories: 375,
      fat: 0,
      carbs: 94,
      protein: 0,
      iron: 0,
    },
    {
      name: 'Lollipop',
      calories: 392,
      fat: 0.2,
      carbs: 98,
      protein: 0,
      iron: 2,
    },
    {
      name: 'Honeycomb',
      calories: 408,
      fat: 3.2,
      carbs: 87,
      protein: 6.5,
      iron: 45,
    },
    {
      name: 'Donut',
      calories: 452,
      fat: 25,
      carbs: 51,
      protein: 4.9,
      iron: 22,
    },
    {
      name: 'KitKat',
      calories: 518,
      fat: 26,
      carbs: 65,
      protein: 7,
      iron: 6,
    },
  ])
<\/script>

<script>
  export default {
    data () {
      return {
        selected: [],
        headers: [
          {
            title: 'Dessert (100g serving)',
            align: 'start',
            key: 'name',
          },
          { title: 'Calories', align: 'end', key: 'calories' },
          { title: 'Fat (g)', align: 'end', key: 'fat' },
          { title: 'Carbs (g)', align: 'end', key: 'carbs' },
          { title: 'Protein (g)', align: 'end', key: 'protein' },
          { title: 'Iron (%)', align: 'end', key: 'iron' },
        ],
        desserts: [
          {
            name: 'Frozen Yogurt',
            calories: 159,
            fat: 6.0,
            carbs: 24,
            protein: 4.0,
            iron: 1,
          },
          {
            name: 'Ice cream sandwich',
            calories: 237,
            fat: 9.0,
            carbs: 37,
            protein: 4.3,
            iron: 1,
          },
          {
            name: 'Eclair',
            calories: 262,
            fat: 16.0,
            carbs: 23,
            protein: 6.0,
            iron: 7,
          },
          {
            name: 'Cupcake',
            calories: 305,
            fat: 3.7,
            carbs: 67,
            protein: 4.3,
            iron: 8,
          },
          {
            name: 'Gingerbread',
            calories: 356,
            fat: 16.0,
            carbs: 49,
            protein: 3.9,
            iron: 16,
          },
          {
            name: 'Jelly bean',
            calories: 375,
            fat: 0.0,
            carbs: 94,
            protein: 0.0,
            iron: 0,
          },
          {
            name: 'Lollipop',
            calories: 392,
            fat: 0.2,
            carbs: 98,
            protein: 0,
            iron: 2,
          },
          {
            name: 'Honeycomb',
            calories: 408,
            fat: 3.2,
            carbs: 87,
            protein: 6.5,
            iron: 45,
          },
          {
            name: 'Donut',
            calories: 452,
            fat: 25.0,
            carbs: 51,
            protein: 4.9,
            iron: 22,
          },
          {
            name: 'KitKat',
            calories: 518,
            fat: 26.0,
            carbs: 65,
            protein: 7,
            iron: 6,
          },
        ],
      }
    },
  }
<\/script>
`;
const _sfc_main$g = {
  __name: "prop-row-selection",
  setup(__props) {
    const selected = ref([]);
    const items = [
      {
        name: "🍎 Apple",
        location: "Washington",
        height: "0.1",
        base: "0.07",
        volume: "0.0001"
      },
      {
        name: "🍌 Banana",
        location: "Ecuador",
        height: "0.2",
        base: "0.05",
        volume: "0.0002"
      },
      {
        name: "🍇 Grapes",
        location: "Italy",
        height: "0.02",
        base: "0.02",
        volume: "0.00001"
      },
      {
        name: "🍉 Watermelon",
        location: "China",
        height: "0.4",
        base: "0.3",
        volume: "0.03"
      },
      {
        name: "🍍 Pineapple",
        location: "Thailand",
        height: "0.3",
        base: "0.2",
        volume: "0.005"
      },
      {
        name: "🍒 Cherries",
        location: "Turkey",
        height: "0.02",
        base: "0.02",
        volume: "0.00001"
      },
      {
        name: "🥭 Mango",
        location: "India",
        height: "0.15",
        base: "0.1",
        volume: "0.0005"
      },
      {
        name: "🍓 Strawberry",
        location: "USA",
        height: "0.03",
        base: "0.03",
        volume: "0.00002"
      },
      {
        name: "🍑 Peach",
        location: "China",
        height: "0.09",
        base: "0.08",
        volume: "0.0004"
      },
      {
        name: "🥝 Kiwi",
        location: "New Zealand",
        height: "0.05",
        base: "0.05",
        volume: "0.0001"
      }
    ];
    return (_ctx, _cache) => {
      const _component_v_data_table = resolveComponent("v-data-table");
      return openBlock(), createBlock(_component_v_data_table, {
        modelValue: selected.value,
        "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => selected.value = $event),
        items,
        "item-value": "name",
        "show-select": ""
      }, null, 8, ["modelValue"]);
    };
  }
};
const __19 = _sfc_main$g;
const __19_raw = `<template>
  <v-data-table
    v-model="selected"
    :items="items"
    item-value="name"
    show-select
  ></v-data-table>
</template>

<script setup>
  import { ref } from 'vue'

  const selected = ref([])
  const items = [
    {
      name: '🍎 Apple',
      location: 'Washington',
      height: '0.1',
      base: '0.07',
      volume: '0.0001',
    },
    {
      name: '🍌 Banana',
      location: 'Ecuador',
      height: '0.2',
      base: '0.05',
      volume: '0.0002',
    },
    {
      name: '🍇 Grapes',
      location: 'Italy',
      height: '0.02',
      base: '0.02',
      volume: '0.00001',
    },
    {
      name: '🍉 Watermelon',
      location: 'China',
      height: '0.4',
      base: '0.3',
      volume: '0.03',
    },
    {
      name: '🍍 Pineapple',
      location: 'Thailand',
      height: '0.3',
      base: '0.2',
      volume: '0.005',
    },
    {
      name: '🍒 Cherries',
      location: 'Turkey',
      height: '0.02',
      base: '0.02',
      volume: '0.00001',
    },
    {
      name: '🥭 Mango',
      location: 'India',
      height: '0.15',
      base: '0.1',
      volume: '0.0005',
    },
    {
      name: '🍓 Strawberry',
      location: 'USA',
      height: '0.03',
      base: '0.03',
      volume: '0.00002',
    },
    {
      name: '🍑 Peach',
      location: 'China',
      height: '0.09',
      base: '0.08',
      volume: '0.0004',
    },
    {
      name: '🥝 Kiwi',
      location: 'New Zealand',
      height: '0.05',
      base: '0.05',
      volume: '0.0001',
    },
  ]
<\/script>

<script>
  export default {
    data () {
      return {
        selected: [],
        items: [
          {
            name: '🍎 Apple',
            location: 'Washington',
            height: '0.1',
            base: '0.07',
            volume: '0.0001',
          },
          {
            name: '🍌 Banana',
            location: 'Ecuador',
            height: '0.2',
            base: '0.05',
            volume: '0.0002',
          },
          {
            name: '🍇 Grapes',
            location: 'Italy',
            height: '0.02',
            base: '0.02',
            volume: '0.00001',
          },
          {
            name: '🍉 Watermelon',
            location: 'China',
            height: '0.4',
            base: '0.3',
            volume: '0.03',
          },
          {
            name: '🍍 Pineapple',
            location: 'Thailand',
            height: '0.3',
            base: '0.2',
            volume: '0.005',
          },
          {
            name: '🍒 Cherries',
            location: 'Turkey',
            height: '0.02',
            base: '0.02',
            volume: '0.00001',
          },
          {
            name: '🥭 Mango',
            location: 'India',
            height: '0.15',
            base: '0.1',
            volume: '0.0005',
          },
          {
            name: '🍓 Strawberry',
            location: 'USA',
            height: '0.03',
            base: '0.03',
            volume: '0.00002',
          },
          {
            name: '🍑 Peach',
            location: 'China',
            height: '0.09',
            base: '0.08',
            volume: '0.0004',
          },
          {
            name: '🥝 Kiwi',
            location: 'New Zealand',
            height: '0.05',
            base: '0.05',
            volume: '0.0001',
          },
        ],
      }
    },
  }
<\/script>
`;
const _sfc_main$f = {
  __name: "prop-search",
  setup(__props) {
    const search = ref("");
    const headers = [
      {
        align: "start",
        key: "name",
        sortable: false,
        title: "Dessert (100g serving)"
      },
      { key: "calories", title: "Calories" },
      { key: "fat", title: "Fat (g)" },
      { key: "carbs", title: "Carbs (g)" },
      { key: "protein", title: "Protein (g)" },
      { key: "iron", title: "Iron (%)" }
    ];
    const desserts2 = [
      {
        name: "Frozen Yogurt",
        calories: 159,
        fat: 6,
        carbs: 24,
        protein: 4,
        iron: 1
      },
      {
        name: "Ice cream sandwich",
        calories: 237,
        fat: 9,
        carbs: 37,
        protein: 4.3,
        iron: 1
      },
      {
        name: "Eclair",
        calories: 262,
        fat: 16,
        carbs: 23,
        protein: 6,
        iron: 7
      },
      {
        name: "Cupcake",
        calories: 305,
        fat: 3.7,
        carbs: 67,
        protein: 4.3,
        iron: 8
      },
      {
        name: "Gingerbread",
        calories: 356,
        fat: 16,
        carbs: 49,
        protein: 3.9,
        iron: 16
      },
      {
        name: "Jelly bean",
        calories: 375,
        fat: 0,
        carbs: 94,
        protein: 0,
        iron: 0
      },
      {
        name: "Lollipop",
        calories: 392,
        fat: 0.2,
        carbs: 98,
        protein: 0,
        iron: 2
      },
      {
        name: "Honeycomb",
        calories: 408,
        fat: 3.2,
        carbs: 87,
        protein: 6.5,
        iron: 45
      },
      {
        name: "Donut",
        calories: 452,
        fat: 25,
        carbs: 51,
        protein: 4.9,
        iron: 22
      },
      {
        name: "KitKat",
        calories: 518,
        fat: 26,
        carbs: 65,
        protein: 7,
        iron: 6
      }
    ];
    return (_ctx, _cache) => {
      const _component_v_text_field = resolveComponent("v-text-field");
      const _component_v_data_table = resolveComponent("v-data-table");
      const _component_v_card = resolveComponent("v-card");
      return openBlock(), createBlock(_component_v_card, {
        title: "Nutrition",
        flat: ""
      }, {
        text: withCtx(() => [
          createVNode(_component_v_text_field, {
            modelValue: search.value,
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => search.value = $event),
            label: "Search",
            "prepend-inner-icon": "mdi-magnify",
            variant: "outlined",
            "hide-details": "",
            "single-line": ""
          }, null, 8, ["modelValue"])
        ]),
        default: withCtx(() => [
          createVNode(_component_v_data_table, {
            headers,
            items: desserts2,
            search: search.value
          }, null, 8, ["search"])
        ]),
        _: 1
      });
    };
  }
};
const __20 = _sfc_main$f;
const __20_raw = `<template>
  <v-card
    title="Nutrition"
    flat
  >
    <template v-slot:text>
      <v-text-field
        v-model="search"
        label="Search"
        prepend-inner-icon="mdi-magnify"
        variant="outlined"
        hide-details
        single-line
      ></v-text-field>
    </template>

    <v-data-table
      :headers="headers"
      :items="desserts"
      :search="search"
    ></v-data-table>
  </v-card>
</template>

<script setup>
  import { ref } from 'vue'

  const search = ref('')
  const headers = [
    {
      align: 'start',
      key: 'name',
      sortable: false,
      title: 'Dessert (100g serving)',
    },
    { key: 'calories', title: 'Calories' },
    { key: 'fat', title: 'Fat (g)' },
    { key: 'carbs', title: 'Carbs (g)' },
    { key: 'protein', title: 'Protein (g)' },
    { key: 'iron', title: 'Iron (%)' },
  ]
  const desserts = [
    {
      name: 'Frozen Yogurt',
      calories: 159,
      fat: 6,
      carbs: 24,
      protein: 4,
      iron: 1,
    },
    {
      name: 'Ice cream sandwich',
      calories: 237,
      fat: 9,
      carbs: 37,
      protein: 4.3,
      iron: 1,
    },
    {
      name: 'Eclair',
      calories: 262,
      fat: 16,
      carbs: 23,
      protein: 6,
      iron: 7,
    },
    {
      name: 'Cupcake',
      calories: 305,
      fat: 3.7,
      carbs: 67,
      protein: 4.3,
      iron: 8,
    },
    {
      name: 'Gingerbread',
      calories: 356,
      fat: 16,
      carbs: 49,
      protein: 3.9,
      iron: 16,
    },
    {
      name: 'Jelly bean',
      calories: 375,
      fat: 0,
      carbs: 94,
      protein: 0,
      iron: 0,
    },
    {
      name: 'Lollipop',
      calories: 392,
      fat: 0.2,
      carbs: 98,
      protein: 0,
      iron: 2,
    },
    {
      name: 'Honeycomb',
      calories: 408,
      fat: 3.2,
      carbs: 87,
      protein: 6.5,
      iron: 45,
    },
    {
      name: 'Donut',
      calories: 452,
      fat: 25,
      carbs: 51,
      protein: 4.9,
      iron: 22,
    },
    {
      name: 'KitKat',
      calories: 518,
      fat: 26,
      carbs: 65,
      protein: 7,
      iron: 6,
    },
  ]
<\/script>

<script>
  export default {
    data () {
      return {
        search: '',
        headers: [
          {
            align: 'start',
            key: 'name',
            sortable: false,
            title: 'Dessert (100g serving)',
          },
          { key: 'calories', title: 'Calories' },
          { key: 'fat', title: 'Fat (g)' },
          { key: 'carbs', title: 'Carbs (g)' },
          { key: 'protein', title: 'Protein (g)' },
          { key: 'iron', title: 'Iron (%)' },
        ],
        desserts: [
          {
            name: 'Frozen Yogurt',
            calories: 159,
            fat: 6.0,
            carbs: 24,
            protein: 4.0,
            iron: 1,
          },
          {
            name: 'Ice cream sandwich',
            calories: 237,
            fat: 9.0,
            carbs: 37,
            protein: 4.3,
            iron: 1,
          },
          {
            name: 'Eclair',
            calories: 262,
            fat: 16.0,
            carbs: 23,
            protein: 6.0,
            iron: 7,
          },
          {
            name: 'Cupcake',
            calories: 305,
            fat: 3.7,
            carbs: 67,
            protein: 4.3,
            iron: 8,
          },
          {
            name: 'Gingerbread',
            calories: 356,
            fat: 16.0,
            carbs: 49,
            protein: 3.9,
            iron: 16,
          },
          {
            name: 'Jelly bean',
            calories: 375,
            fat: 0.0,
            carbs: 94,
            protein: 0.0,
            iron: 0,
          },
          {
            name: 'Lollipop',
            calories: 392,
            fat: 0.2,
            carbs: 98,
            protein: 0,
            iron: 2,
          },
          {
            name: 'Honeycomb',
            calories: 408,
            fat: 3.2,
            carbs: 87,
            protein: 6.5,
            iron: 45,
          },
          {
            name: 'Donut',
            calories: 452,
            fat: 25.0,
            carbs: 51,
            protein: 4.9,
            iron: 22,
          },
          {
            name: 'KitKat',
            calories: 518,
            fat: 26.0,
            carbs: 65,
            protein: 7,
            iron: 6,
          },
        ],
      }
    },
  }
<\/script>
`;
const _sfc_main$e = {
  __name: "prop-select-strategy",
  setup(__props) {
    const headers = [
      {
        title: "Dessert (100g serving)",
        align: "start",
        key: "name"
      },
      { title: "Calories", align: "end", key: "calories" },
      { title: "Fat (g)", align: "end", key: "fat" },
      { title: "Carbs (g)", align: "end", key: "carbs" },
      { title: "Protein (g)", align: "end", key: "protein" },
      { title: "Iron (%)", align: "end", key: "iron" }
    ];
    const desserts2 = [
      {
        name: "Frozen Yogurt",
        calories: 159,
        fat: 6,
        carbs: 24,
        protein: 4,
        iron: 1
      },
      {
        name: "Ice cream sandwich",
        calories: 237,
        fat: 9,
        carbs: 37,
        protein: 4.3,
        iron: 1
      },
      {
        name: "Eclair",
        calories: 262,
        fat: 16,
        carbs: 23,
        protein: 6,
        iron: 7
      },
      {
        name: "Cupcake",
        calories: 305,
        fat: 3.7,
        carbs: 67,
        protein: 4.3,
        iron: 8
      },
      {
        name: "Gingerbread",
        calories: 356,
        fat: 16,
        carbs: 49,
        protein: 3.9,
        iron: 16
      },
      {
        name: "Jelly bean",
        calories: 375,
        fat: 0,
        carbs: 94,
        protein: 0,
        iron: 0
      },
      {
        name: "Lollipop",
        calories: 392,
        fat: 0.2,
        carbs: 98,
        protein: 0,
        iron: 2
      },
      {
        name: "Honeycomb",
        calories: 408,
        fat: 3.2,
        carbs: 87,
        protein: 6.5,
        iron: 45
      },
      {
        name: "Donut",
        calories: 452,
        fat: 25,
        carbs: 51,
        protein: 4.9,
        iron: 22
      },
      {
        name: "KitKat",
        calories: 518,
        fat: 26,
        carbs: 65,
        protein: 7,
        iron: 6
      }
    ];
    return (_ctx, _cache) => {
      const _component_v_data_table = resolveComponent("v-data-table");
      return openBlock(), createBlock(_component_v_data_table, {
        headers,
        items: desserts2,
        "item-value": "name",
        "select-strategy": "single",
        "show-select": ""
      });
    };
  }
};
const __21 = _sfc_main$e;
const __21_raw = `<template>
  <v-data-table
    :headers="headers"
    :items="desserts"
    item-value="name"
    select-strategy="single"
    show-select
  ></v-data-table>
</template>

<script setup>
  const headers = [
    {
      title: 'Dessert (100g serving)',
      align: 'start',
      key: 'name',
    },
    { title: 'Calories', align: 'end', key: 'calories' },
    { title: 'Fat (g)', align: 'end', key: 'fat' },
    { title: 'Carbs (g)', align: 'end', key: 'carbs' },
    { title: 'Protein (g)', align: 'end', key: 'protein' },
    { title: 'Iron (%)', align: 'end', key: 'iron' },
  ]
  const desserts = [
    {
      name: 'Frozen Yogurt',
      calories: 159,
      fat: 6,
      carbs: 24,
      protein: 4,
      iron: 1,
    },
    {
      name: 'Ice cream sandwich',
      calories: 237,
      fat: 9,
      carbs: 37,
      protein: 4.3,
      iron: 1,
    },
    {
      name: 'Eclair',
      calories: 262,
      fat: 16,
      carbs: 23,
      protein: 6,
      iron: 7,
    },
    {
      name: 'Cupcake',
      calories: 305,
      fat: 3.7,
      carbs: 67,
      protein: 4.3,
      iron: 8,
    },
    {
      name: 'Gingerbread',
      calories: 356,
      fat: 16,
      carbs: 49,
      protein: 3.9,
      iron: 16,
    },
    {
      name: 'Jelly bean',
      calories: 375,
      fat: 0,
      carbs: 94,
      protein: 0,
      iron: 0,
    },
    {
      name: 'Lollipop',
      calories: 392,
      fat: 0.2,
      carbs: 98,
      protein: 0,
      iron: 2,
    },
    {
      name: 'Honeycomb',
      calories: 408,
      fat: 3.2,
      carbs: 87,
      protein: 6.5,
      iron: 45,
    },
    {
      name: 'Donut',
      calories: 452,
      fat: 25,
      carbs: 51,
      protein: 4.9,
      iron: 22,
    },
    {
      name: 'KitKat',
      calories: 518,
      fat: 26,
      carbs: 65,
      protein: 7,
      iron: 6,
    },
  ]
<\/script>

<script>
  export default {
    data () {
      return {
        headers: [
          {
            title: 'Dessert (100g serving)',
            align: 'start',
            key: 'name',
          },
          { title: 'Calories', align: 'end', key: 'calories' },
          { title: 'Fat (g)', align: 'end', key: 'fat' },
          { title: 'Carbs (g)', align: 'end', key: 'carbs' },
          { title: 'Protein (g)', align: 'end', key: 'protein' },
          { title: 'Iron (%)', align: 'end', key: 'iron' },
        ],
        desserts: [
          {
            name: 'Frozen Yogurt',
            calories: 159,
            fat: 6.0,
            carbs: 24,
            protein: 4.0,
            iron: 1,
          },
          {
            name: 'Ice cream sandwich',
            calories: 237,
            fat: 9.0,
            carbs: 37,
            protein: 4.3,
            iron: 1,
          },
          {
            name: 'Eclair',
            calories: 262,
            fat: 16.0,
            carbs: 23,
            protein: 6.0,
            iron: 7,
          },
          {
            name: 'Cupcake',
            calories: 305,
            fat: 3.7,
            carbs: 67,
            protein: 4.3,
            iron: 8,
          },
          {
            name: 'Gingerbread',
            calories: 356,
            fat: 16.0,
            carbs: 49,
            protein: 3.9,
            iron: 16,
          },
          {
            name: 'Jelly bean',
            calories: 375,
            fat: 0.0,
            carbs: 94,
            protein: 0.0,
            iron: 0,
          },
          {
            name: 'Lollipop',
            calories: 392,
            fat: 0.2,
            carbs: 98,
            protein: 0,
            iron: 2,
          },
          {
            name: 'Honeycomb',
            calories: 408,
            fat: 3.2,
            carbs: 87,
            protein: 6.5,
            iron: 45,
          },
          {
            name: 'Donut',
            calories: 452,
            fat: 25.0,
            carbs: 51,
            protein: 4.9,
            iron: 22,
          },
          {
            name: 'KitKat',
            calories: 518,
            fat: 26.0,
            carbs: 65,
            protein: 7,
            iron: 6,
          },
        ],
      }
    },
  }
<\/script>
`;
const _sfc_main$d = {
  __name: "prop-sort-by",
  setup(__props) {
    const sortBy = ref([{ key: "calories", order: "asc" }]);
    const headers = [
      {
        title: "Dessert (100g serving)",
        align: "start",
        sortable: false,
        key: "name"
      },
      { title: "Calories", key: "calories" },
      { title: "Fat (g)", key: "fat" },
      { title: "Carbs (g)", key: "carbs" },
      { title: "Protein (g)", key: "protein" },
      { title: "Iron (%)", key: "iron" }
    ];
    const desserts2 = [
      {
        name: "Frozen Yogurt",
        calories: 200,
        fat: 6,
        carbs: 24,
        protein: 4,
        iron: "1%"
      },
      {
        name: "Ice cream sandwich",
        calories: 200,
        fat: 9,
        carbs: 37,
        protein: 4.3,
        iron: "1%"
      },
      {
        name: "Eclair",
        calories: 300,
        fat: 16,
        carbs: 23,
        protein: 6,
        iron: "7%"
      },
      {
        name: "Cupcake",
        calories: 300,
        fat: 3.7,
        carbs: 67,
        protein: 4.3,
        iron: "8%"
      },
      {
        name: "Gingerbread",
        calories: 400,
        fat: 16,
        carbs: 49,
        protein: 3.9,
        iron: "16%"
      },
      {
        name: "Jelly bean",
        calories: 400,
        fat: 0,
        carbs: 94,
        protein: 0,
        iron: "0%"
      },
      {
        name: "Lollipop",
        calories: 400,
        fat: 0.2,
        carbs: 98,
        protein: 0,
        iron: "2%"
      },
      {
        name: "Honeycomb",
        calories: 400,
        fat: 3.2,
        carbs: 87,
        protein: 6.5,
        iron: "45%"
      },
      {
        name: "Donut",
        calories: 500,
        fat: 25,
        carbs: 51,
        protein: 4.9,
        iron: "22%"
      },
      {
        name: "KitKat",
        calories: 500,
        fat: 26,
        carbs: 65,
        protein: 7,
        iron: "6%"
      }
    ];
    return (_ctx, _cache) => {
      const _component_v_data_table = resolveComponent("v-data-table");
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(_component_v_data_table, {
          "sort-by": sortBy.value,
          "onUpdate:sortBy": _cache[0] || (_cache[0] = ($event) => sortBy.value = $event),
          headers,
          items: desserts2
        }, null, 8, ["sort-by"]),
        createBaseVNode("pre", null, toDisplayString(sortBy.value), 1)
      ], 64);
    };
  }
};
const __22 = _sfc_main$d;
const __22_raw = `<template>
  <v-data-table
    v-model:sort-by="sortBy"
    :headers="headers"
    :items="desserts"
  ></v-data-table>

  <pre>{{ sortBy }}</pre>
</template>

<script setup>
  import { ref } from 'vue'

  const sortBy = ref([{ key: 'calories', order: 'asc' }])

  const headers = [
    {
      title: 'Dessert (100g serving)',
      align: 'start',
      sortable: false,
      key: 'name',
    },
    { title: 'Calories', key: 'calories' },
    { title: 'Fat (g)', key: 'fat' },
    { title: 'Carbs (g)', key: 'carbs' },
    { title: 'Protein (g)', key: 'protein' },
    { title: 'Iron (%)', key: 'iron' },
  ]
  const desserts = [
    {
      name: 'Frozen Yogurt',
      calories: 200,
      fat: 6,
      carbs: 24,
      protein: 4,
      iron: '1%',
    },
    {
      name: 'Ice cream sandwich',
      calories: 200,
      fat: 9,
      carbs: 37,
      protein: 4.3,
      iron: '1%',
    },
    {
      name: 'Eclair',
      calories: 300,
      fat: 16,
      carbs: 23,
      protein: 6,
      iron: '7%',
    },
    {
      name: 'Cupcake',
      calories: 300,
      fat: 3.7,
      carbs: 67,
      protein: 4.3,
      iron: '8%',
    },
    {
      name: 'Gingerbread',
      calories: 400,
      fat: 16,
      carbs: 49,
      protein: 3.9,
      iron: '16%',
    },
    {
      name: 'Jelly bean',
      calories: 400,
      fat: 0,
      carbs: 94,
      protein: 0,
      iron: '0%',
    },
    {
      name: 'Lollipop',
      calories: 400,
      fat: 0.2,
      carbs: 98,
      protein: 0,
      iron: '2%',
    },
    {
      name: 'Honeycomb',
      calories: 400,
      fat: 3.2,
      carbs: 87,
      protein: 6.5,
      iron: '45%',
    },
    {
      name: 'Donut',
      calories: 500,
      fat: 25,
      carbs: 51,
      protein: 4.9,
      iron: '22%',
    },
    {
      name: 'KitKat',
      calories: 500,
      fat: 26,
      carbs: 65,
      protein: 7,
      iron: '6%',
    },
  ]
<\/script>

<script>
  export default {
    data () {
      return {
        sortBy: [{ key: 'calories', order: 'asc' }],
        headers: [
          {
            title: 'Dessert (100g serving)',
            align: 'start',
            sortable: false,
            key: 'name',
          },
          { title: 'Calories', key: 'calories' },
          { title: 'Fat (g)', key: 'fat' },
          { title: 'Carbs (g)', key: 'carbs' },
          { title: 'Protein (g)', key: 'protein' },
          { title: 'Iron (%)', key: 'iron' },
        ],
        desserts: [
          {
            name: 'Frozen Yogurt',
            calories: 200,
            fat: 6.0,
            carbs: 24,
            protein: 4.0,
            iron: '1%',
          },
          {
            name: 'Ice cream sandwich',
            calories: 200,
            fat: 9.0,
            carbs: 37,
            protein: 4.3,
            iron: '1%',
          },
          {
            name: 'Eclair',
            calories: 300,
            fat: 16.0,
            carbs: 23,
            protein: 6.0,
            iron: '7%',
          },
          {
            name: 'Cupcake',
            calories: 300,
            fat: 3.7,
            carbs: 67,
            protein: 4.3,
            iron: '8%',
          },
          {
            name: 'Gingerbread',
            calories: 400,
            fat: 16.0,
            carbs: 49,
            protein: 3.9,
            iron: '16%',
          },
          {
            name: 'Jelly bean',
            calories: 400,
            fat: 0.0,
            carbs: 94,
            protein: 0.0,
            iron: '0%',
          },
          {
            name: 'Lollipop',
            calories: 400,
            fat: 0.2,
            carbs: 98,
            protein: 0,
            iron: '2%',
          },
          {
            name: 'Honeycomb',
            calories: 400,
            fat: 3.2,
            carbs: 87,
            protein: 6.5,
            iron: '45%',
          },
          {
            name: 'Donut',
            calories: 500,
            fat: 25.0,
            carbs: 51,
            protein: 4.9,
            iron: '22%',
          },
          {
            name: 'KitKat',
            calories: 500,
            fat: 26.0,
            carbs: 65,
            protein: 7,
            iron: '6%',
          },
        ],
      }
    },
  }
<\/script>
`;
const _sfc_main$c = {
  __name: "server-search",
  setup(__props) {
    const desserts2 = [
      {
        name: "Frozen Yogurt",
        calories: 159,
        fat: 6,
        carbs: 24,
        protein: 4,
        iron: "1"
      },
      {
        name: "Jelly bean",
        calories: 375,
        fat: 0,
        carbs: 94,
        protein: 0,
        iron: "0"
      },
      {
        name: "KitKat",
        calories: 518,
        fat: 26,
        carbs: 65,
        protein: 7,
        iron: "6"
      },
      {
        name: "Eclair",
        calories: 262,
        fat: 16,
        carbs: 23,
        protein: 6,
        iron: "7"
      },
      {
        name: "Gingerbread",
        calories: 356,
        fat: 16,
        carbs: 49,
        protein: 3.9,
        iron: "16"
      },
      {
        name: "Ice cream sandwich",
        calories: 237,
        fat: 9,
        carbs: 37,
        protein: 4.3,
        iron: "1"
      },
      {
        name: "Lollipop",
        calories: 392,
        fat: 0.2,
        carbs: 98,
        protein: 0,
        iron: "2"
      },
      {
        name: "Cupcake",
        calories: 305,
        fat: 3.7,
        carbs: 67,
        protein: 4.3,
        iron: "8"
      },
      {
        name: "Honeycomb",
        calories: 408,
        fat: 3.2,
        carbs: 87,
        protein: 6.5,
        iron: "45"
      },
      {
        name: "Donut",
        calories: 452,
        fat: 25,
        carbs: 51,
        protein: 4.9,
        iron: "22"
      }
    ];
    const FakeAPI = {
      async fetch({ page, itemsPerPage: itemsPerPage2, sortBy, search: search2 }) {
        return new Promise((resolve) => {
          setTimeout(() => {
            const start = (page - 1) * itemsPerPage2;
            const end = start + itemsPerPage2;
            const items = desserts2.slice().filter((item) => {
              if (search2.name && !item.name.toLowerCase().includes(search2.name.toLowerCase())) {
                return false;
              }
              if (search2.calories && !(item.calories >= Number(search2.calories))) {
                return false;
              }
              return true;
            });
            if (sortBy.length) {
              const sortKey = sortBy[0].key;
              const sortOrder = sortBy[0].order;
              items.sort((a, b) => {
                const aValue = a[sortKey];
                const bValue = b[sortKey];
                return sortOrder === "desc" ? bValue - aValue : aValue - bValue;
              });
            }
            const paginated = items.slice(start, end);
            resolve({ items: paginated, total: items.length });
          }, 500);
        });
      }
    };
    const itemsPerPage = ref(5);
    const headers = ref([
      {
        title: "Dessert (100g serving)",
        align: "start",
        sortable: false,
        key: "name"
      },
      { title: "Calories", key: "calories", align: "end" },
      { title: "Fat (g)", key: "fat", align: "end" },
      { title: "Carbs (g)", key: "carbs", align: "end" },
      { title: "Protein (g)", key: "protein", align: "end" },
      { title: "Iron (%)", key: "iron", align: "end" }
    ]);
    const serverItems = ref([]);
    const loading = ref(true);
    const totalItems = ref(0);
    const name2 = ref("");
    const calories = ref("");
    const search = ref("");
    function loadItems({ page, itemsPerPage: itemsPerPage2, sortBy }) {
      loading.value = true;
      FakeAPI.fetch({ page, itemsPerPage: itemsPerPage2, sortBy, search: { name: name2.value, calories: calories.value } }).then(({ items, total }) => {
        serverItems.value = items;
        totalItems.value = total;
        loading.value = false;
      });
    }
    watch(name2, () => {
      search.value = String(Date.now());
    });
    watch(calories, () => {
      search.value = String(Date.now());
    });
    return (_ctx, _cache) => {
      const _component_v_text_field = resolveComponent("v-text-field");
      const _component_v_data_table_server = resolveComponent("v-data-table-server");
      return openBlock(), createBlock(_component_v_data_table_server, {
        "items-per-page": itemsPerPage.value,
        "onUpdate:itemsPerPage": _cache[2] || (_cache[2] = ($event) => itemsPerPage.value = $event),
        headers: headers.value,
        items: serverItems.value,
        "items-length": totalItems.value,
        loading: loading.value,
        search: search.value,
        "item-value": "name",
        "onUpdate:options": loadItems
      }, {
        tfoot: withCtx(() => [
          createBaseVNode("tr", null, [
            createBaseVNode("td", null, [
              createVNode(_component_v_text_field, {
                modelValue: name2.value,
                "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => name2.value = $event),
                class: "ma-2",
                density: "compact",
                placeholder: "Search name...",
                "hide-details": ""
              }, null, 8, ["modelValue"])
            ]),
            createBaseVNode("td", null, [
              createVNode(_component_v_text_field, {
                modelValue: calories.value,
                "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => calories.value = $event),
                class: "ma-2",
                density: "compact",
                placeholder: "Minimum calories",
                type: "number",
                "hide-details": ""
              }, null, 8, ["modelValue"])
            ])
          ])
        ]),
        _: 1
      }, 8, ["items-per-page", "headers", "items", "items-length", "loading", "search"]);
    };
  }
};
const __23 = _sfc_main$c;
const __23_raw = `<template>
  <v-data-table-server
    v-model:items-per-page="itemsPerPage"
    :headers="headers"
    :items="serverItems"
    :items-length="totalItems"
    :loading="loading"
    :search="search"
    item-value="name"
    @update:options="loadItems"
  >
    <template v-slot:tfoot>
      <tr>
        <td>
          <v-text-field v-model="name" class="ma-2" density="compact" placeholder="Search name..." hide-details></v-text-field>
        </td>
        <td>
          <v-text-field
            v-model="calories"
            class="ma-2"
            density="compact"
            placeholder="Minimum calories"
            type="number"
            hide-details
          ></v-text-field>
        </td>
      </tr>
    </template>
  </v-data-table-server>
</template>

<script setup>
  import { ref, watch } from 'vue'

  const desserts = [
    {
      name: 'Frozen Yogurt',
      calories: 159,
      fat: 6,
      carbs: 24,
      protein: 4,
      iron: '1',
    },
    {
      name: 'Jelly bean',
      calories: 375,
      fat: 0,
      carbs: 94,
      protein: 0,
      iron: '0',
    },
    {
      name: 'KitKat',
      calories: 518,
      fat: 26,
      carbs: 65,
      protein: 7,
      iron: '6',
    },
    {
      name: 'Eclair',
      calories: 262,
      fat: 16,
      carbs: 23,
      protein: 6,
      iron: '7',
    },
    {
      name: 'Gingerbread',
      calories: 356,
      fat: 16,
      carbs: 49,
      protein: 3.9,
      iron: '16',
    },
    {
      name: 'Ice cream sandwich',
      calories: 237,
      fat: 9,
      carbs: 37,
      protein: 4.3,
      iron: '1',
    },
    {
      name: 'Lollipop',
      calories: 392,
      fat: 0.2,
      carbs: 98,
      protein: 0,
      iron: '2',
    },
    {
      name: 'Cupcake',
      calories: 305,
      fat: 3.7,
      carbs: 67,
      protein: 4.3,
      iron: '8',
    },
    {
      name: 'Honeycomb',
      calories: 408,
      fat: 3.2,
      carbs: 87,
      protein: 6.5,
      iron: '45',
    },
    {
      name: 'Donut',
      calories: 452,
      fat: 25,
      carbs: 51,
      protein: 4.9,
      iron: '22',
    },
  ]
  const FakeAPI = {
    async fetch ({ page, itemsPerPage, sortBy, search }) {
      return new Promise(resolve => {
        setTimeout(() => {
          const start = (page - 1) * itemsPerPage
          const end = start + itemsPerPage
          const items = desserts.slice().filter(item => {
            if (search.name && !item.name.toLowerCase().includes(search.name.toLowerCase())) {
              return false
            }
            // eslint-disable-next-line sonarjs/prefer-single-boolean-return
            if (search.calories && !(item.calories >= Number(search.calories))) {
              return false
            }
            return true
          })
          if (sortBy.length) {
            const sortKey = sortBy[0].key
            const sortOrder = sortBy[0].order
            items.sort((a, b) => {
              const aValue = a[sortKey]
              const bValue = b[sortKey]
              return sortOrder === 'desc' ? bValue - aValue : aValue - bValue
            })
          }
          const paginated = items.slice(start, end)
          resolve({ items: paginated, total: items.length })
        }, 500)
      })
    },
  }
  const itemsPerPage = ref(5)
  const headers = ref([
    {
      title: 'Dessert (100g serving)',
      align: 'start',
      sortable: false,
      key: 'name',
    },
    { title: 'Calories', key: 'calories', align: 'end' },
    { title: 'Fat (g)', key: 'fat', align: 'end' },
    { title: 'Carbs (g)', key: 'carbs', align: 'end' },
    { title: 'Protein (g)', key: 'protein', align: 'end' },
    { title: 'Iron (%)', key: 'iron', align: 'end' },
  ])
  const serverItems = ref([])
  const loading = ref(true)
  const totalItems = ref(0)
  const name = ref('')
  const calories = ref('')
  const search = ref('')
  function loadItems ({ page, itemsPerPage, sortBy }) {
    loading.value = true
    FakeAPI.fetch({ page, itemsPerPage, sortBy, search: { name: name.value, calories: calories.value } }).then(({ items, total }) => {
      serverItems.value = items
      totalItems.value = total
      loading.value = false
    })
  }
  watch(name, () => {
    search.value = String(Date.now())
  })
  watch(calories, () => {
    search.value = String(Date.now())
  })
<\/script>

<script>
  const desserts = [
    {
      name: 'Frozen Yogurt',
      calories: 159,
      fat: 6.0,
      carbs: 24,
      protein: 4.0,
      iron: '1',
    },
    {
      name: 'Jelly bean',
      calories: 375,
      fat: 0.0,
      carbs: 94,
      protein: 0.0,
      iron: '0',
    },
    {
      name: 'KitKat',
      calories: 518,
      fat: 26.0,
      carbs: 65,
      protein: 7,
      iron: '6',
    },
    {
      name: 'Eclair',
      calories: 262,
      fat: 16.0,
      carbs: 23,
      protein: 6.0,
      iron: '7',
    },
    {
      name: 'Gingerbread',
      calories: 356,
      fat: 16.0,
      carbs: 49,
      protein: 3.9,
      iron: '16',
    },
    {
      name: 'Ice cream sandwich',
      calories: 237,
      fat: 9.0,
      carbs: 37,
      protein: 4.3,
      iron: '1',
    },
    {
      name: 'Lollipop',
      calories: 392,
      fat: 0.2,
      carbs: 98,
      protein: 0,
      iron: '2',
    },
    {
      name: 'Cupcake',
      calories: 305,
      fat: 3.7,
      carbs: 67,
      protein: 4.3,
      iron: '8',
    },
    {
      name: 'Honeycomb',
      calories: 408,
      fat: 3.2,
      carbs: 87,
      protein: 6.5,
      iron: '45',
    },
    {
      name: 'Donut',
      calories: 452,
      fat: 25.0,
      carbs: 51,
      protein: 4.9,
      iron: '22',
    },
  ]

  const FakeAPI = {
    async fetch ({ page, itemsPerPage, sortBy, search }) {
      return new Promise(resolve => {
        setTimeout(() => {
          const start = (page - 1) * itemsPerPage
          const end = start + itemsPerPage
          const items = desserts.slice().filter(item => {
            if (search.name && !item.name.toLowerCase().includes(search.name.toLowerCase())) {
              return false
            }

            // eslint-disable-next-line sonarjs/prefer-single-boolean-return
            if (search.calories && !(item.calories >= Number(search.calories))) {
              return false
            }

            return true
          })

          if (sortBy.length) {
            const sortKey = sortBy[0].key
            const sortOrder = sortBy[0].order
            items.sort((a, b) => {
              const aValue = a[sortKey]
              const bValue = b[sortKey]
              return sortOrder === 'desc' ? bValue - aValue : aValue - bValue
            })
          }

          const paginated = items.slice(start, end)

          resolve({ items: paginated, total: items.length })
        }, 500)
      })
    },
  }

  export default {
    data: () => ({
      itemsPerPage: 5,
      headers: [
        {
          title: 'Dessert (100g serving)',
          align: 'start',
          sortable: false,
          key: 'name',
        },
        { title: 'Calories', key: 'calories', align: 'end' },
        { title: 'Fat (g)', key: 'fat', align: 'end' },
        { title: 'Carbs (g)', key: 'carbs', align: 'end' },
        { title: 'Protein (g)', key: 'protein', align: 'end' },
        { title: 'Iron (%)', key: 'iron', align: 'end' },
      ],
      serverItems: [],
      loading: true,
      totalItems: 0,
      name: '',
      calories: '',
      search: '',
    }),
    watch: {
      name () {
        this.search = String(Date.now())
      },
      calories () {
        this.search = String(Date.now())
      },
    },
    methods: {
      loadItems ({ page, itemsPerPage, sortBy }) {
        this.loading = true
        FakeAPI.fetch({ page, itemsPerPage, sortBy, search: { name: this.name, calories: this.calories } }).then(({ items, total }) => {
          this.serverItems = items
          this.totalItems = total
          this.loading = false
        })
      },
    },
  }
<\/script>
`;
const _sfc_main$b = {
  __name: "server",
  setup(__props) {
    const cars = [
      {
        name: "Ford Mustang",
        horsepower: 450,
        fuel: "Gasoline",
        origin: "USA",
        price: 55e3
      },
      {
        name: "Tesla Model S",
        horsepower: 670,
        fuel: "Electric",
        origin: "USA",
        price: 79999
      },
      {
        name: "BMW M3",
        horsepower: 503,
        fuel: "Gasoline",
        origin: "Germany",
        price: 7e4
      },
      {
        name: "Audi RS6",
        horsepower: 591,
        fuel: "Gasoline",
        origin: "Germany",
        price: 109e3
      },
      {
        name: "Chevrolet Camaro",
        horsepower: 650,
        fuel: "Gasoline",
        origin: "USA",
        price: 62e3
      },
      {
        name: "Porsche 911",
        horsepower: 379,
        fuel: "Gasoline",
        origin: "Germany",
        price: 101e3
      },
      {
        name: "Jaguar F-Type",
        horsepower: 575,
        fuel: "Gasoline",
        origin: "UK",
        price: 61e3
      },
      {
        name: "Mazda MX-5",
        horsepower: 181,
        fuel: "Gasoline",
        origin: "Japan",
        price: 26e3
      },
      {
        name: "Nissan GT-R",
        horsepower: 565,
        fuel: "Gasoline",
        origin: "Japan",
        price: 113540
      },
      {
        name: "Mercedes-AMG GT",
        horsepower: 523,
        fuel: "Gasoline",
        origin: "Germany",
        price: 115900
      }
    ];
    const FakeAPI = {
      async fetch({ page, itemsPerPage: itemsPerPage2, sortBy }) {
        return new Promise((resolve) => {
          setTimeout(() => {
            const start = (page - 1) * itemsPerPage2;
            const end = start + itemsPerPage2;
            const items = cars.slice();
            if (sortBy.length) {
              const sortKey = sortBy[0].key;
              const sortOrder = sortBy[0].order;
              items.sort((a, b) => {
                const aValue = a[sortKey];
                const bValue = b[sortKey];
                return sortOrder === "desc" ? bValue - aValue : aValue - bValue;
              });
            }
            const paginated = items.slice(start, end);
            resolve({ items: paginated, total: items.length });
          }, 500);
        });
      }
    };
    const itemsPerPage = ref(5);
    const headers = ref([
      { title: "Car Model", key: "name", align: "start" },
      { title: "Horsepower", key: "horsepower", align: "end" },
      { title: "Fuel Type", key: "fuel", align: "start" },
      { title: "Origin", key: "origin", align: "start" },
      { title: "Price ($)", key: "price", align: "end" }
    ]);
    const serverItems = ref([]);
    const loading = ref(true);
    const totalItems = ref(0);
    function loadItems({ page, itemsPerPage: itemsPerPage2, sortBy }) {
      loading.value = true;
      FakeAPI.fetch({ page, itemsPerPage: itemsPerPage2, sortBy }).then(({ items, total }) => {
        serverItems.value = items;
        totalItems.value = total;
        loading.value = false;
      });
    }
    return (_ctx, _cache) => {
      const _component_v_data_table_server = resolveComponent("v-data-table-server");
      return openBlock(), createBlock(_component_v_data_table_server, {
        "items-per-page": itemsPerPage.value,
        "onUpdate:itemsPerPage": _cache[0] || (_cache[0] = ($event) => itemsPerPage.value = $event),
        headers: headers.value,
        items: serverItems.value,
        "items-length": totalItems.value,
        loading: loading.value,
        "item-value": "name",
        "onUpdate:options": loadItems
      }, null, 8, ["items-per-page", "headers", "items", "items-length", "loading"]);
    };
  }
};
const __24 = _sfc_main$b;
const __24_raw = `<template>
  <v-data-table-server
    v-model:items-per-page="itemsPerPage"
    :headers="headers"
    :items="serverItems"
    :items-length="totalItems"
    :loading="loading"
    item-value="name"
    @update:options="loadItems"
  ></v-data-table-server>
</template>

<script setup>
  import { ref } from 'vue'

  const cars = [
    {
      name: 'Ford Mustang',
      horsepower: 450,
      fuel: 'Gasoline',
      origin: 'USA',
      price: 55000,
    },
    {
      name: 'Tesla Model S',
      horsepower: 670,
      fuel: 'Electric',
      origin: 'USA',
      price: 79999,
    },
    {
      name: 'BMW M3',
      horsepower: 503,
      fuel: 'Gasoline',
      origin: 'Germany',
      price: 70000,
    },
    {
      name: 'Audi RS6',
      horsepower: 591,
      fuel: 'Gasoline',
      origin: 'Germany',
      price: 109000,
    },
    {
      name: 'Chevrolet Camaro',
      horsepower: 650,
      fuel: 'Gasoline',
      origin: 'USA',
      price: 62000,
    },
    {
      name: 'Porsche 911',
      horsepower: 379,
      fuel: 'Gasoline',
      origin: 'Germany',
      price: 101000,
    },
    {
      name: 'Jaguar F-Type',
      horsepower: 575,
      fuel: 'Gasoline',
      origin: 'UK',
      price: 61000,
    },
    {
      name: 'Mazda MX-5',
      horsepower: 181,
      fuel: 'Gasoline',
      origin: 'Japan',
      price: 26000,
    },
    {
      name: 'Nissan GT-R',
      horsepower: 565,
      fuel: 'Gasoline',
      origin: 'Japan',
      price: 113540,
    },
    {
      name: 'Mercedes-AMG GT',
      horsepower: 523,
      fuel: 'Gasoline',
      origin: 'Germany',
      price: 115900,
    },
  ]

  const FakeAPI = {
    async fetch ({ page, itemsPerPage, sortBy }) {
      return new Promise(resolve => {
        setTimeout(() => {
          const start = (page - 1) * itemsPerPage
          const end = start + itemsPerPage
          const items = cars.slice()
          if (sortBy.length) {
            const sortKey = sortBy[0].key
            const sortOrder = sortBy[0].order
            items.sort((a, b) => {
              const aValue = a[sortKey]
              const bValue = b[sortKey]
              return sortOrder === 'desc' ? bValue - aValue : aValue - bValue
            })
          }
          const paginated = items.slice(start, end)
          resolve({ items: paginated, total: items.length })
        }, 500)
      })
    },
  }
  const itemsPerPage = ref(5)
  const headers = ref([
    { title: 'Car Model', key: 'name', align: 'start' },
    { title: 'Horsepower', key: 'horsepower', align: 'end' },
    { title: 'Fuel Type', key: 'fuel', align: 'start' },
    { title: 'Origin', key: 'origin', align: 'start' },
    { title: 'Price ($)', key: 'price', align: 'end' },
  ])
  const serverItems = ref([])
  const loading = ref(true)
  const totalItems = ref(0)
  function loadItems ({ page, itemsPerPage, sortBy }) {
    loading.value = true
    FakeAPI.fetch({ page, itemsPerPage, sortBy }).then(({ items, total }) => {
      serverItems.value = items
      totalItems.value = total
      loading.value = false
    })
  }
<\/script>

<script>
  const desserts = [
    {
      name: 'Frozen Yogurt',
      calories: 159,
      fat: 6.0,
      carbs: 24,
      protein: 4.0,
      iron: '1',
    },
    {
      name: 'Jelly bean',
      calories: 375,
      fat: 0.0,
      carbs: 94,
      protein: 0.0,
      iron: '0',
    },
    {
      name: 'KitKat',
      calories: 518,
      fat: 26.0,
      carbs: 65,
      protein: 7,
      iron: '6',
    },
    {
      name: 'Eclair',
      calories: 262,
      fat: 16.0,
      carbs: 23,
      protein: 6.0,
      iron: '7',
    },
    {
      name: 'Gingerbread',
      calories: 356,
      fat: 16.0,
      carbs: 49,
      protein: 3.9,
      iron: '16',
    },
    {
      name: 'Ice cream sandwich',
      calories: 237,
      fat: 9.0,
      carbs: 37,
      protein: 4.3,
      iron: '1',
    },
    {
      name: 'Lollipop',
      calories: 392,
      fat: 0.2,
      carbs: 98,
      protein: 0,
      iron: '2',
    },
    {
      name: 'Cupcake',
      calories: 305,
      fat: 3.7,
      carbs: 67,
      protein: 4.3,
      iron: '8',
    },
    {
      name: 'Honeycomb',
      calories: 408,
      fat: 3.2,
      carbs: 87,
      protein: 6.5,
      iron: '45',
    },
    {
      name: 'Donut',
      calories: 452,
      fat: 25.0,
      carbs: 51,
      protein: 4.9,
      iron: '22',
    },
  ]

  const FakeAPI = {
    async fetch ({ page, itemsPerPage, sortBy }) {
      return new Promise(resolve => {
        setTimeout(() => {
          const start = (page - 1) * itemsPerPage
          const end = start + itemsPerPage
          const items = desserts.slice()

          if (sortBy.length) {
            const sortKey = sortBy[0].key
            const sortOrder = sortBy[0].order
            items.sort((a, b) => {
              const aValue = a[sortKey]
              const bValue = b[sortKey]
              return sortOrder === 'desc' ? bValue - aValue : aValue - bValue
            })
          }

          const paginated = items.slice(start, end)

          resolve({ items: paginated, total: items.length })
        }, 500)
      })
    },
  }

  export default {
    data: () => ({
      itemsPerPage: 5,
      headers: [
        {
          title: 'Dessert (100g serving)',
          align: 'start',
          sortable: false,
          key: 'name',
        },
        { title: 'Calories', key: 'calories', align: 'end' },
        { title: 'Fat (g)', key: 'fat', align: 'end' },
        { title: 'Carbs (g)', key: 'carbs', align: 'end' },
        { title: 'Protein (g)', key: 'protein', align: 'end' },
        { title: 'Iron (%)', key: 'iron', align: 'end' },
      ],
      serverItems: [],
      loading: true,
      totalItems: 0,
    }),
    methods: {
      loadItems ({ page, itemsPerPage, sortBy }) {
        this.loading = true
        FakeAPI.fetch({ page, itemsPerPage, sortBy }).then(({ items, total }) => {
          this.serverItems = items
          this.totalItems = total
          this.loading = false
        })
      },
    },
  }
<\/script>
`;
const _hoisted_1$3 = ["colspan"];
const _sfc_main$a = {
  __name: "slot-group-header",
  setup(__props) {
    const groupBy = ref([
      {
        key: "gluten",
        order: "asc"
      }
    ]);
    const headers = [
      {
        title: "Dessert (100g serving)",
        align: "start",
        sortable: false,
        key: "name"
      },
      { title: "Calories", key: "calories" },
      { title: "Fat (g)", key: "fat" },
      { title: "Carbs (g)", key: "carbs" },
      { title: "Protein (g)", key: "protein" },
      { title: "Iron (%)", key: "iron" }
    ];
    const desserts2 = [
      {
        name: "Frozen Yogurt",
        calories: 159,
        fat: 6,
        carbs: 24,
        protein: 4,
        iron: "1%",
        gluten: false
      },
      {
        name: "Ice cream sandwich",
        calories: 237,
        fat: 9,
        carbs: 37,
        protein: 4.3,
        iron: "1%",
        gluten: false
      },
      {
        name: "Eclair",
        calories: 262,
        fat: 16,
        carbs: 23,
        protein: 6,
        iron: "7%",
        gluten: true
      },
      {
        name: "Cupcake",
        calories: 305,
        fat: 3.7,
        carbs: 67,
        protein: 4.3,
        iron: "8%",
        gluten: true
      },
      {
        name: "Gingerbread",
        calories: 356,
        fat: 16,
        carbs: 49,
        protein: 3.9,
        iron: "16%",
        gluten: true
      },
      {
        name: "Jelly bean",
        calories: 375,
        fat: 0,
        carbs: 94,
        protein: 0,
        iron: "0%",
        gluten: false
      },
      {
        name: "Lollipop",
        calories: 392,
        fat: 0.2,
        carbs: 98,
        protein: 0,
        iron: "2%",
        gluten: false
      },
      {
        name: "Honeycomb",
        calories: 408,
        fat: 3.2,
        carbs: 87,
        protein: 6.5,
        iron: "45%",
        gluten: true
      },
      {
        name: "Donut",
        calories: 452,
        fat: 25,
        carbs: 51,
        protein: 4.9,
        iron: "22%",
        gluten: true
      },
      {
        name: "KitKat",
        calories: 518,
        fat: 26,
        carbs: 65,
        protein: 7,
        iron: "6%",
        gluten: true
      }
    ];
    return (_ctx, _cache) => {
      const _component_VBtn = resolveComponent("VBtn");
      const _component_v_data_table = resolveComponent("v-data-table");
      return openBlock(), createBlock(_component_v_data_table, {
        "group-by": groupBy.value,
        headers,
        items: desserts2,
        "item-value": "name"
      }, {
        "group-header": withCtx(({ item, columns, toggleGroup, isGroupOpen }) => [
          createBaseVNode("tr", null, [
            createBaseVNode("td", {
              colspan: columns.length
            }, [
              createVNode(_component_VBtn, {
                icon: isGroupOpen(item) ? "$expand" : "$next",
                size: "small",
                variant: "text",
                onClick: ($event) => toggleGroup(item)
              }, null, 8, ["icon", "onClick"]),
              createTextVNode(" " + toDisplayString(item.value ? "Contains gluten" : "Gluten free"), 1)
            ], 8, _hoisted_1$3)
          ])
        ]),
        _: 1
      }, 8, ["group-by"]);
    };
  }
};
const __25 = _sfc_main$a;
const __25_raw = `<template>
  <v-data-table
    :group-by="groupBy"
    :headers="headers"
    :items="desserts"
    item-value="name"
  >
    <template v-slot:group-header="{ item, columns, toggleGroup, isGroupOpen }">
      <tr>
        <td :colspan="columns.length">
          <VBtn
            :icon="isGroupOpen(item) ? '$expand' : '$next'"
            size="small"
            variant="text"
            @click="toggleGroup(item)"
          ></VBtn>
          {{ item.value ? 'Contains gluten' : 'Gluten free' }}
        </td>
      </tr>
    </template>
  </v-data-table>
</template>

<script setup>
  import { ref } from 'vue'

  const groupBy = ref([
    {
      key: 'gluten',
      order: 'asc',
    },
  ])

  const headers = [
    {
      title: 'Dessert (100g serving)',
      align: 'start',
      sortable: false,
      key: 'name',
    },
    { title: 'Calories', key: 'calories' },
    { title: 'Fat (g)', key: 'fat' },
    { title: 'Carbs (g)', key: 'carbs' },
    { title: 'Protein (g)', key: 'protein' },
    { title: 'Iron (%)', key: 'iron' },
  ]
  const desserts = [
    {
      name: 'Frozen Yogurt',
      calories: 159,
      fat: 6,
      carbs: 24,
      protein: 4,
      iron: '1%',
      gluten: false,
    },
    {
      name: 'Ice cream sandwich',
      calories: 237,
      fat: 9,
      carbs: 37,
      protein: 4.3,
      iron: '1%',
      gluten: false,
    },
    {
      name: 'Eclair',
      calories: 262,
      fat: 16,
      carbs: 23,
      protein: 6,
      iron: '7%',
      gluten: true,
    },
    {
      name: 'Cupcake',
      calories: 305,
      fat: 3.7,
      carbs: 67,
      protein: 4.3,
      iron: '8%',
      gluten: true,
    },
    {
      name: 'Gingerbread',
      calories: 356,
      fat: 16,
      carbs: 49,
      protein: 3.9,
      iron: '16%',
      gluten: true,
    },
    {
      name: 'Jelly bean',
      calories: 375,
      fat: 0,
      carbs: 94,
      protein: 0,
      iron: '0%',
      gluten: false,
    },
    {
      name: 'Lollipop',
      calories: 392,
      fat: 0.2,
      carbs: 98,
      protein: 0,
      iron: '2%',
      gluten: false,
    },
    {
      name: 'Honeycomb',
      calories: 408,
      fat: 3.2,
      carbs: 87,
      protein: 6.5,
      iron: '45%',
      gluten: true,
    },
    {
      name: 'Donut',
      calories: 452,
      fat: 25,
      carbs: 51,
      protein: 4.9,
      iron: '22%',
      gluten: true,
    },
    {
      name: 'KitKat',
      calories: 518,
      fat: 26,
      carbs: 65,
      protein: 7,
      iron: '6%',
      gluten: true,
    },
  ]
<\/script>

<script>
  export default {
    data () {
      return {
        groupBy: [
          {
            key: 'gluten',
            order: 'asc',
          },
        ],
        headers: [
          {
            title: 'Dessert (100g serving)',
            align: 'start',
            sortable: false,
            key: 'name',
          },
          { title: 'Calories', key: 'calories' },
          { title: 'Fat (g)', key: 'fat' },
          { title: 'Carbs (g)', key: 'carbs' },
          { title: 'Protein (g)', key: 'protein' },
          { title: 'Iron (%)', key: 'iron' },
        ],
        desserts: [
          {
            name: 'Frozen Yogurt',
            calories: 159,
            fat: 6.0,
            carbs: 24,
            protein: 4.0,
            iron: '1%',
            gluten: false,
          },
          {
            name: 'Ice cream sandwich',
            calories: 237,
            fat: 9.0,
            carbs: 37,
            protein: 4.3,
            iron: '1%',
            gluten: false,
          },
          {
            name: 'Eclair',
            calories: 262,
            fat: 16.0,
            carbs: 23,
            protein: 6.0,
            iron: '7%',
            gluten: true,
          },
          {
            name: 'Cupcake',
            calories: 305,
            fat: 3.7,
            carbs: 67,
            protein: 4.3,
            iron: '8%',
            gluten: true,
          },
          {
            name: 'Gingerbread',
            calories: 356,
            fat: 16.0,
            carbs: 49,
            protein: 3.9,
            iron: '16%',
            gluten: true,
          },
          {
            name: 'Jelly bean',
            calories: 375,
            fat: 0.0,
            carbs: 94,
            protein: 0.0,
            iron: '0%',
            gluten: false,
          },
          {
            name: 'Lollipop',
            calories: 392,
            fat: 0.2,
            carbs: 98,
            protein: 0,
            iron: '2%',
            gluten: false,
          },
          {
            name: 'Honeycomb',
            calories: 408,
            fat: 3.2,
            carbs: 87,
            protein: 6.5,
            iron: '45%',
            gluten: true,
          },
          {
            name: 'Donut',
            calories: 452,
            fat: 25.0,
            carbs: 51,
            protein: 4.9,
            iron: '22%',
            gluten: true,
          },
          {
            name: 'KitKat',
            calories: 518,
            fat: 26.0,
            carbs: 65,
            protein: 7,
            iron: '6%',
            gluten: true,
          },
        ],
      }
    },
  }
<\/script>
`;
const _sfc_main$9 = {
  __name: "slot-header",
  setup(__props) {
    const items = [
      {
        id: 1,
        name: "T-Shirt",
        size: "M",
        color: "Red",
        price: 19.99,
        quantity: 10
      },
      {
        id: 2,
        name: "Jeans",
        size: "32",
        color: "Blue",
        price: 49.99,
        quantity: 5
      },
      {
        id: 3,
        name: "Sweater",
        size: "L",
        color: "Green",
        price: 29.99,
        quantity: 7
      },
      {
        id: 4,
        name: "Jacket",
        size: "XL",
        color: "Black",
        price: 89.99,
        quantity: 3
      },
      {
        id: 5,
        name: "Socks",
        size: "One Size",
        color: "White",
        price: 9.99,
        quantity: 20
      }
    ];
    return (_ctx, _cache) => {
      const _component_v_data_table = resolveComponent("v-data-table");
      return openBlock(), createBlock(_component_v_data_table, { items }, {
        "header.id": withCtx(({ column }) => [
          createTextVNode(toDisplayString(column.title.toUpperCase()), 1)
        ]),
        _: 1
      });
    };
  }
};
const __26 = _sfc_main$9;
const __26_raw = `<template>
  <v-data-table :items="items">
    <template v-slot:header.id="{ column }">
      {{ column.title.toUpperCase() }}
    </template>
  </v-data-table>
</template>

<script setup>
  const items = [
    {
      id: 1,
      name: 'T-Shirt',
      size: 'M',
      color: 'Red',
      price: 19.99,
      quantity: 10,
    },
    {
      id: 2,
      name: 'Jeans',
      size: '32',
      color: 'Blue',
      price: 49.99,
      quantity: 5,
    },
    {
      id: 3,
      name: 'Sweater',
      size: 'L',
      color: 'Green',
      price: 29.99,
      quantity: 7,
    },
    {
      id: 4,
      name: 'Jacket',
      size: 'XL',
      color: 'Black',
      price: 89.99,
      quantity: 3,
    },
    {
      id: 5,
      name: 'Socks',
      size: 'One Size',
      color: 'White',
      price: 9.99,
      quantity: 20,
    },
  ]
<\/script>

<script>
  export default {
    data: () => ({
      items: [
        {
          id: 1,
          name: 'T-Shirt',
          size: 'M',
          color: 'Red',
          price: 19.99,
          quantity: 10,
        },
        {
          id: 2,
          name: 'Jeans',
          size: '32',
          color: 'Blue',
          price: 49.99,
          quantity: 5,
        },
        {
          id: 3,
          name: 'Sweater',
          size: 'L',
          color: 'Green',
          price: 29.99,
          quantity: 7,
        },
        {
          id: 4,
          name: 'Jacket',
          size: 'XL',
          color: 'Black',
          price: 89.99,
          quantity: 3,
        },
        {
          id: 5,
          name: 'Socks',
          size: 'One Size',
          color: 'White',
          price: 9.99,
          quantity: 20,
        },
      ],
    }),
  }
<\/script>
`;
const _hoisted_1$2 = ["onClick"];
const _sfc_main$8 = {
  __name: "slot-headers",
  setup(__props) {
    const headers = ref([
      {
        title: "Dessert (100g serving)",
        align: "start",
        key: "name",
        sortable: false,
        removable: false
      },
      { title: "Calories", key: "calories", removable: true },
      { title: "Fat (g)", key: "fat", removable: true },
      { title: "Carbs (g)", key: "carbs", removable: true },
      { title: "Protein (g)", key: "protein", removable: true },
      { title: "Iron (%)", key: "iron", removable: true }
    ]);
    const desserts2 = [
      {
        name: "Frozen Yogurt",
        calories: 159,
        fat: 6,
        carbs: 24,
        protein: 4,
        iron: 1
      },
      {
        name: "Ice cream sandwich",
        calories: 237,
        fat: 9,
        carbs: 37,
        protein: 4.3,
        iron: 1
      },
      {
        name: "Eclair",
        calories: 262,
        fat: 16,
        carbs: 23,
        protein: 6,
        iron: 7
      },
      {
        name: "Cupcake",
        calories: 305,
        fat: 3.7,
        carbs: 67,
        protein: 4.3,
        iron: 8
      },
      {
        name: "Gingerbread",
        calories: 356,
        fat: 16,
        carbs: 49,
        protein: 3.9,
        iron: 16
      },
      {
        name: "Jelly bean",
        calories: 375,
        fat: 0,
        carbs: 94,
        protein: 0,
        iron: 0
      },
      {
        name: "Lollipop",
        calories: 392,
        fat: 0.2,
        carbs: 98,
        protein: 0,
        iron: 2
      },
      {
        name: "Honeycomb",
        calories: 408,
        fat: 3.2,
        carbs: 87,
        protein: 6.5,
        iron: 45
      },
      {
        name: "Donut",
        calories: 452,
        fat: 25,
        carbs: 51,
        protein: 4.9,
        iron: 22
      },
      {
        name: "KitKat",
        calories: 518,
        fat: 26,
        carbs: 65,
        protein: 7,
        iron: 6
      }
    ];
    function remove(key) {
      headers.value = headers.value.filter((header) => header.key !== key);
    }
    return (_ctx, _cache) => {
      const _component_v_icon = resolveComponent("v-icon");
      const _component_v_data_table = resolveComponent("v-data-table");
      return openBlock(), createBlock(_component_v_data_table, {
        headers: headers.value,
        items: desserts2,
        "item-value": "name"
      }, {
        headers: withCtx(({ columns, isSorted, getSortIcon, toggleSort }) => [
          createBaseVNode("tr", null, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(columns, (column) => {
              return openBlock(), createElementBlock("td", {
                key: column.key
              }, [
                createBaseVNode("span", {
                  class: "mr-2 cursor-pointer",
                  onClick: () => toggleSort(column)
                }, toDisplayString(column.title), 9, _hoisted_1$2),
                isSorted(column) ? (openBlock(), createBlock(_component_v_icon, {
                  key: 0,
                  icon: getSortIcon(column)
                }, null, 8, ["icon"])) : createCommentVNode("", true),
                column.removable ? (openBlock(), createBlock(_component_v_icon, {
                  key: 1,
                  icon: "$close",
                  onClick: () => remove(column.key)
                }, null, 8, ["onClick"])) : createCommentVNode("", true)
              ]);
            }), 128))
          ])
        ]),
        _: 1
      }, 8, ["headers"]);
    };
  }
};
const __27 = _sfc_main$8;
const __27_raw = `<template>
  <v-data-table
    :headers="headers"
    :items="desserts"
    item-value="name"
  >
    <template v-slot:headers="{ columns, isSorted, getSortIcon, toggleSort }">
      <tr>
        <template v-for="column in columns" :key="column.key">
          <td>
            <span class="mr-2 cursor-pointer" @click="() => toggleSort(column)">{{ column.title }}</span>
            <template v-if="isSorted(column)">
              <v-icon :icon="getSortIcon(column)"></v-icon>
            </template>
            <v-icon v-if="column.removable" icon="$close" @click="() => remove(column.key)"></v-icon>
          </td>
        </template>
      </tr>
    </template>
  </v-data-table>
</template>

<script setup>
  import { ref } from 'vue'

  const headers = ref([
    {
      title: 'Dessert (100g serving)',
      align: 'start',
      key: 'name',
      sortable: false,
      removable: false,
    },
    { title: 'Calories', key: 'calories', removable: true },
    { title: 'Fat (g)', key: 'fat', removable: true },
    { title: 'Carbs (g)', key: 'carbs', removable: true },
    { title: 'Protein (g)', key: 'protein', removable: true },
    { title: 'Iron (%)', key: 'iron', removable: true },
  ])

  const desserts = [
    {
      name: 'Frozen Yogurt',
      calories: 159,
      fat: 6,
      carbs: 24,
      protein: 4,
      iron: 1,
    },
    {
      name: 'Ice cream sandwich',
      calories: 237,
      fat: 9,
      carbs: 37,
      protein: 4.3,
      iron: 1,
    },
    {
      name: 'Eclair',
      calories: 262,
      fat: 16,
      carbs: 23,
      protein: 6,
      iron: 7,
    },
    {
      name: 'Cupcake',
      calories: 305,
      fat: 3.7,
      carbs: 67,
      protein: 4.3,
      iron: 8,
    },
    {
      name: 'Gingerbread',
      calories: 356,
      fat: 16,
      carbs: 49,
      protein: 3.9,
      iron: 16,
    },
    {
      name: 'Jelly bean',
      calories: 375,
      fat: 0,
      carbs: 94,
      protein: 0,
      iron: 0,
    },
    {
      name: 'Lollipop',
      calories: 392,
      fat: 0.2,
      carbs: 98,
      protein: 0,
      iron: 2,
    },
    {
      name: 'Honeycomb',
      calories: 408,
      fat: 3.2,
      carbs: 87,
      protein: 6.5,
      iron: 45,
    },
    {
      name: 'Donut',
      calories: 452,
      fat: 25,
      carbs: 51,
      protein: 4.9,
      iron: 22,
    },
    {
      name: 'KitKat',
      calories: 518,
      fat: 26,
      carbs: 65,
      protein: 7,
      iron: 6,
    },
  ]

  function remove (key) {
    headers.value = headers.value.filter(header => header.key !== key)
  }
<\/script>

<script>
  export default {
    data: () => ({
      headers: [
        {
          title: 'Dessert (100g serving)',
          align: 'start',
          key: 'name',
          sortable: false,
          removable: false,
        },
        { title: 'Calories', key: 'calories', removable: true },
        { title: 'Fat (g)', key: 'fat', removable: true },
        { title: 'Carbs (g)', key: 'carbs', removable: true },
        { title: 'Protein (g)', key: 'protein', removable: true },
        { title: 'Iron (%)', key: 'iron', removable: true },
      ],
      desserts: [
        {
          name: 'Frozen Yogurt',
          calories: 159,
          fat: 6.0,
          carbs: 24,
          protein: 4.0,
          iron: 1,
        },
        {
          name: 'Ice cream sandwich',
          calories: 237,
          fat: 9.0,
          carbs: 37,
          protein: 4.3,
          iron: 1,
        },
        {
          name: 'Eclair',
          calories: 262,
          fat: 16.0,
          carbs: 23,
          protein: 6.0,
          iron: 7,
        },
        {
          name: 'Cupcake',
          calories: 305,
          fat: 3.7,
          carbs: 67,
          protein: 4.3,
          iron: 8,
        },
        {
          name: 'Gingerbread',
          calories: 356,
          fat: 16.0,
          carbs: 49,
          protein: 3.9,
          iron: 16,
        },
        {
          name: 'Jelly bean',
          calories: 375,
          fat: 0.0,
          carbs: 94,
          protein: 0.0,
          iron: 0,
        },
        {
          name: 'Lollipop',
          calories: 392,
          fat: 0.2,
          carbs: 98,
          protein: 0,
          iron: 2,
        },
        {
          name: 'Honeycomb',
          calories: 408,
          fat: 3.2,
          carbs: 87,
          protein: 6.5,
          iron: 45,
        },
        {
          name: 'Donut',
          calories: 452,
          fat: 25.0,
          carbs: 51,
          protein: 4.9,
          iron: 22,
        },
        {
          name: 'KitKat',
          calories: 518,
          fat: 26.0,
          carbs: 65,
          protein: 7,
          iron: 6,
        },
      ],
    }),
    methods: {
      remove (key) {
        this.headers = this.headers.filter(header => header.key !== key)
      },
    },
  }
<\/script>
`;
const _sfc_main$7 = {
  __name: "slot-item-key",
  setup(__props) {
    const headers = [
      { title: "Vegetable (100g serving)", key: "name" },
      { title: "Calories", key: "calories" },
      { title: "Fat (g)", key: "fat" },
      { title: "Carbs (g)", key: "carbs" },
      { title: "Protein (g)", key: "protein" },
      { title: "Iron (%)", key: "iron" }
    ];
    const vegetables = [
      {
        name: "Spinach",
        calories: 23,
        fat: 0.4,
        carbs: 3.6,
        protein: 2.9,
        iron: "15%"
      },
      {
        name: "Kael",
        calories: 49,
        fat: 0.9,
        carbs: 8.8,
        protein: 4.3,
        iron: "16%"
      },
      {
        name: "Broccoli",
        calories: 34,
        fat: 0.4,
        carbs: 6.6,
        protein: 2.8,
        iron: "6%"
      },
      {
        name: "Brussels Sprouts",
        calories: 43,
        fat: 0.3,
        carbs: 8.9,
        protein: 3.4,
        iron: "9%"
      },
      {
        name: "Avocado",
        calories: 160,
        fat: 15,
        carbs: 9,
        protein: 2,
        iron: "3%"
      },
      {
        name: "Sweet Potato",
        calories: 86,
        fat: 0.1,
        carbs: 20.1,
        protein: 1.6,
        iron: "3%"
      },
      {
        name: "Corn",
        calories: 96,
        fat: 1.5,
        carbs: 21,
        protein: 3.4,
        iron: "2%"
      },
      {
        name: "Potato",
        calories: 77,
        fat: 0.1,
        carbs: 17.5,
        protein: 2,
        iron: "8%"
      },
      {
        name: "Butternut Squash",
        calories: 45,
        fat: 0.1,
        carbs: 11.7,
        protein: 1,
        iron: "4%"
      },
      {
        name: "Beetroot",
        calories: 43,
        fat: 0.2,
        carbs: 10,
        protein: 1.6,
        iron: "6%"
      },
      {
        name: "Parsnip",
        calories: 75,
        fat: 0.3,
        carbs: 18,
        protein: 1.2,
        iron: "4%"
      },
      {
        name: "Yam",
        calories: 118,
        fat: 0.2,
        carbs: 27.9,
        protein: 1.5,
        iron: "4%"
      },
      {
        name: "Acorn Squash",
        calories: 40,
        fat: 0.1,
        carbs: 10,
        protein: 1,
        iron: "5%"
      },
      {
        name: "Artichoke",
        calories: 47,
        fat: 0.2,
        carbs: 10.5,
        protein: 3.3,
        iron: "7%"
      },
      {
        name: "Peas",
        calories: 81,
        fat: 0.4,
        carbs: 14.5,
        protein: 5.4,
        iron: "25%"
      },
      {
        name: "Green Beans",
        calories: 31,
        fat: 0.1,
        carbs: 6.9,
        protein: 1.8,
        iron: "8%"
      },
      {
        name: "Red Bell Pepper",
        calories: 26,
        fat: 0.2,
        carbs: 6,
        protein: 1,
        iron: "3%"
      },
      {
        name: "Cauliflower",
        calories: 25,
        fat: 0.1,
        carbs: 5,
        protein: 1.9,
        iron: "4%"
      },
      {
        name: "Zucchini",
        calories: 17,
        fat: 0.3,
        carbs: 3.1,
        protein: 1.2,
        iron: "3%"
      },
      {
        name: "Asparagus",
        calories: 20,
        fat: 0.1,
        carbs: 3.9,
        protein: 2.2,
        iron: "16%"
      },
      {
        name: "Eggplant",
        calories: 25,
        fat: 0.2,
        carbs: 6,
        protein: 1,
        iron: "1%"
      },
      {
        name: "Pumpkin",
        calories: 26,
        fat: 0.1,
        carbs: 6.5,
        protein: 1,
        iron: "4%"
      },
      {
        name: "Celery",
        calories: 16,
        fat: 0.2,
        carbs: 3,
        protein: 0.7,
        iron: "1%"
      },
      {
        name: "Cucumber",
        calories: 15,
        fat: 0.1,
        carbs: 3.6,
        protein: 0.7,
        iron: "2%"
      },
      {
        name: "Leek",
        calories: 61,
        fat: 0.3,
        carbs: 14.2,
        protein: 1.5,
        iron: "12%"
      },
      {
        name: "Fennel",
        calories: 31,
        fat: 0.2,
        carbs: 7,
        protein: 1.2,
        iron: "6%"
      },
      {
        name: "Green Peas",
        calories: 81,
        fat: 0.4,
        carbs: 14.5,
        protein: 5.4,
        iron: "25%"
      },
      {
        name: "Okra",
        calories: 33,
        fat: 0.2,
        carbs: 7.5,
        protein: 1.9,
        iron: "3%"
      },
      {
        name: "Chard",
        calories: 19,
        fat: 0.2,
        carbs: 3.7,
        protein: 1.8,
        iron: "22%"
      },
      {
        name: "Collard Greens",
        calories: 32,
        fat: 0.6,
        carbs: 5.4,
        protein: 3,
        iron: "2%"
      }
    ];
    function getColor(calories) {
      if (calories > 100)
        return "red";
      else if (calories > 50)
        return "orange";
      else
        return "green";
    }
    return (_ctx, _cache) => {
      const _component_v_chip = resolveComponent("v-chip");
      const _component_v_data_table = resolveComponent("v-data-table");
      return openBlock(), createBlock(_component_v_data_table, {
        headers,
        items: vegetables
      }, {
        "item.calories": withCtx(({ value }) => [
          createVNode(_component_v_chip, {
            color: getColor(value)
          }, {
            default: withCtx(() => [
              createTextVNode(toDisplayString(value), 1)
            ]),
            _: 2
          }, 1032, ["color"])
        ]),
        _: 1
      });
    };
  }
};
const __28 = _sfc_main$7;
const __28_raw = `<template>
  <v-data-table
    :headers="headers"
    :items="vegetables"
  >
    <template v-slot:item.calories="{ value }">
      <v-chip :color="getColor(value)">
        {{ value }}
      </v-chip>
    </template>
  </v-data-table>
</template>

<script setup>
  const headers = [
    { title: 'Vegetable (100g serving)', key: 'name' },
    { title: 'Calories', key: 'calories' },
    { title: 'Fat (g)', key: 'fat' },
    { title: 'Carbs (g)', key: 'carbs' },
    { title: 'Protein (g)', key: 'protein' },
    { title: 'Iron (%)', key: 'iron' },
  ]
  const vegetables = [
    {
      name: 'Spinach',
      calories: 23,
      fat: 0.4,
      carbs: 3.6,
      protein: 2.9,
      iron: '15%',
    },
    {
      name: 'Kael',
      calories: 49,
      fat: 0.9,
      carbs: 8.8,
      protein: 4.3,
      iron: '16%',
    },
    {
      name: 'Broccoli',
      calories: 34,
      fat: 0.4,
      carbs: 6.6,
      protein: 2.8,
      iron: '6%',
    },
    {
      name: 'Brussels Sprouts',
      calories: 43,
      fat: 0.3,
      carbs: 8.9,
      protein: 3.4,
      iron: '9%',
    },
    {
      name: 'Avocado',
      calories: 160,
      fat: 15,
      carbs: 9,
      protein: 2,
      iron: '3%',
    },
    {
      name: 'Sweet Potato',
      calories: 86,
      fat: 0.1,
      carbs: 20.1,
      protein: 1.6,
      iron: '3%',
    },
    {
      name: 'Corn',
      calories: 96,
      fat: 1.5,
      carbs: 21,
      protein: 3.4,
      iron: '2%',
    },
    {
      name: 'Potato',
      calories: 77,
      fat: 0.1,
      carbs: 17.5,
      protein: 2,
      iron: '8%',
    },
    {
      name: 'Butternut Squash',
      calories: 45,
      fat: 0.1,
      carbs: 11.7,
      protein: 1,
      iron: '4%',
    },
    {
      name: 'Beetroot',
      calories: 43,
      fat: 0.2,
      carbs: 10,
      protein: 1.6,
      iron: '6%',
    },
    {
      name: 'Parsnip',
      calories: 75,
      fat: 0.3,
      carbs: 18,
      protein: 1.2,
      iron: '4%',
    },
    {
      name: 'Yam',
      calories: 118,
      fat: 0.2,
      carbs: 27.9,
      protein: 1.5,
      iron: '4%',
    },
    {
      name: 'Acorn Squash',
      calories: 40,
      fat: 0.1,
      carbs: 10,
      protein: 1,
      iron: '5%',
    },
    {
      name: 'Artichoke',
      calories: 47,
      fat: 0.2,
      carbs: 10.5,
      protein: 3.3,
      iron: '7%',
    },
    {
      name: 'Peas',
      calories: 81,
      fat: 0.4,
      carbs: 14.5,
      protein: 5.4,
      iron: '25%',
    },
    {
      name: 'Green Beans',
      calories: 31,
      fat: 0.1,
      carbs: 6.9,
      protein: 1.8,
      iron: '8%',
    },
    {
      name: 'Red Bell Pepper',
      calories: 26,
      fat: 0.2,
      carbs: 6.0,
      protein: 1.0,
      iron: '3%',
    },
    {
      name: 'Cauliflower',
      calories: 25,
      fat: 0.1,
      carbs: 5.0,
      protein: 1.9,
      iron: '4%',
    },
    {
      name: 'Zucchini',
      calories: 17,
      fat: 0.3,
      carbs: 3.1,
      protein: 1.2,
      iron: '3%',
    },
    {
      name: 'Asparagus',
      calories: 20,
      fat: 0.1,
      carbs: 3.9,
      protein: 2.2,
      iron: '16%',
    },
    {
      name: 'Eggplant',
      calories: 25,
      fat: 0.2,
      carbs: 6,
      protein: 1,
      iron: '1%',
    },
    {
      name: 'Pumpkin',
      calories: 26,
      fat: 0.1,
      carbs: 6.5,
      protein: 1,
      iron: '4%',
    },
    {
      name: 'Celery',
      calories: 16,
      fat: 0.2,
      carbs: 3,
      protein: 0.7,
      iron: '1%',
    },
    {
      name: 'Cucumber',
      calories: 15,
      fat: 0.1,
      carbs: 3.6,
      protein: 0.7,
      iron: '2%',
    },
    {
      name: 'Leek',
      calories: 61,
      fat: 0.3,
      carbs: 14.2,
      protein: 1.5,
      iron: '12%',
    },
    {
      name: 'Fennel',
      calories: 31,
      fat: 0.2,
      carbs: 7,
      protein: 1.2,
      iron: '6%',
    },
    {
      name: 'Green Peas',
      calories: 81,
      fat: 0.4,
      carbs: 14.5,
      protein: 5.4,
      iron: '25%',
    },
    {
      name: 'Okra',
      calories: 33,
      fat: 0.2,
      carbs: 7.5,
      protein: 1.9,
      iron: '3%',
    },
    {
      name: 'Chard',
      calories: 19,
      fat: 0.2,
      carbs: 3.7,
      protein: 1.8,
      iron: '22%',
    },
    {
      name: 'Collard Greens',
      calories: 32,
      fat: 0.6,
      carbs: 5.4,
      protein: 3,
      iron: '2%',
    },
  ]
  function getColor (calories) {
    if (calories > 100) return 'red'
    else if (calories > 50) return 'orange'
    else return 'green'
  }
<\/script>

<script>
  export default {
    data: () => ({
      headers: [
        { title: 'Vegetable (100g serving)', key: 'name' },
        { title: 'Calories', key: 'calories' },
        { title: 'Fat (g)', key: 'fat' },
        { title: 'Carbs (g)', key: 'carbs' },
        { title: 'Protein (g)', key: 'protein' },
        { title: 'Iron (%)', key: 'iron' },
      ],
      vegetables: [
        {
          name: 'Spinach',
          calories: 23,
          fat: 0.4,
          carbs: 3.6,
          protein: 2.9,
          iron: '15%',
        },
        {
          name: 'Kael',
          calories: 49,
          fat: 0.9,
          carbs: 8.8,
          protein: 4.3,
          iron: '16%',
        },
        {
          name: 'Broccoli',
          calories: 34,
          fat: 0.4,
          carbs: 6.6,
          protein: 2.8,
          iron: '6%',
        },
        {
          name: 'Brussels Sprouts',
          calories: 43,
          fat: 0.3,
          carbs: 8.9,
          protein: 3.4,
          iron: '9%',
        },
        {
          name: 'Avocado',
          calories: 160,
          fat: 15,
          carbs: 9,
          protein: 2,
          iron: '3%',
        },
        {
          name: 'Sweet Potato',
          calories: 86,
          fat: 0.1,
          carbs: 20.1,
          protein: 1.6,
          iron: '3%',
        },
        {
          name: 'Corn',
          calories: 96,
          fat: 1.5,
          carbs: 21,
          protein: 3.4,
          iron: '2%',
        },
        {
          name: 'Potato',
          calories: 77,
          fat: 0.1,
          carbs: 17.5,
          protein: 2,
          iron: '8%',
        },
        {
          name: 'Butternut Squash',
          calories: 45,
          fat: 0.1,
          carbs: 11.7,
          protein: 1,
          iron: '4%',
        },
        {
          name: 'Beetroot',
          calories: 43,
          fat: 0.2,
          carbs: 10,
          protein: 1.6,
          iron: '6%',
        },
        {
          name: 'Parsnip',
          calories: 75,
          fat: 0.3,
          carbs: 18,
          protein: 1.2,
          iron: '4%',
        },
        {
          name: 'Yam',
          calories: 118,
          fat: 0.2,
          carbs: 27.9,
          protein: 1.5,
          iron: '4%',
        },
        {
          name: 'Acorn Squash',
          calories: 40,
          fat: 0.1,
          carbs: 10,
          protein: 1,
          iron: '5%',
        },
        {
          name: 'Artichoke',
          calories: 47,
          fat: 0.2,
          carbs: 10.5,
          protein: 3.3,
          iron: '7%',
        },
        {
          name: 'Peas',
          calories: 81,
          fat: 0.4,
          carbs: 14.5,
          protein: 5.4,
          iron: '25%',
        },
        {
          name: 'Green Beans',
          calories: 31,
          fat: 0.1,
          carbs: 6.9,
          protein: 1.8,
          iron: '8%',
        },
        {
          name: 'Red Bell Pepper',
          calories: 26,
          fat: 0.2,
          carbs: 6.0,
          protein: 1.0,
          iron: '3%',
        },
        {
          name: 'Cauliflower',
          calories: 25,
          fat: 0.1,
          carbs: 5.0,
          protein: 1.9,
          iron: '4%',
        },
        {
          name: 'Zucchini',
          calories: 17,
          fat: 0.3,
          carbs: 3.1,
          protein: 1.2,
          iron: '3%',
        },
        {
          name: 'Asparagus',
          calories: 20,
          fat: 0.1,
          carbs: 3.9,
          protein: 2.2,
          iron: '16%',
        },
        {
          name: 'Eggplant',
          calories: 25,
          fat: 0.2,
          carbs: 6,
          protein: 1,
          iron: '1%',
        },
        {
          name: 'Pumpkin',
          calories: 26,
          fat: 0.1,
          carbs: 6.5,
          protein: 1,
          iron: '4%',
        },
        {
          name: 'Celery',
          calories: 16,
          fat: 0.2,
          carbs: 3,
          protein: 0.7,
          iron: '1%',
        },
        {
          name: 'Cucumber',
          calories: 15,
          fat: 0.1,
          carbs: 3.6,
          protein: 0.7,
          iron: '2%',
        },
        {
          name: 'Leek',
          calories: 61,
          fat: 0.3,
          carbs: 14.2,
          protein: 1.5,
          iron: '12%',
        },
        {
          name: 'Fennel',
          calories: 31,
          fat: 0.2,
          carbs: 7,
          protein: 1.2,
          iron: '6%',
        },
        {
          name: 'Green Peas',
          calories: 81,
          fat: 0.4,
          carbs: 14.5,
          protein: 5.4,
          iron: '25%',
        },
        {
          name: 'Okra',
          calories: 33,
          fat: 0.2,
          carbs: 7.5,
          protein: 1.9,
          iron: '3%',
        },
        {
          name: 'Chard',
          calories: 19,
          fat: 0.2,
          carbs: 3.7,
          protein: 1.8,
          iron: '22%',
        },
        {
          name: 'Collard Greens',
          calories: 32,
          fat: 0.6,
          carbs: 5.4,
          protein: 3,
          iron: '2%',
        },
      ],
    }),

    methods: {
      getColor (calories) {
        if (calories > 100) return 'red'
        else if (calories > 50) return 'orange'
        else return 'green'
      },
    },
  }
<\/script>
`;
const _sfc_main$6 = {
  __name: "slot-item",
  setup(__props) {
    const headers = [
      {
        title: "Dessert (100g serving)",
        align: "start",
        sortable: false,
        key: "name"
      },
      { title: "Calories", key: "calories" },
      { title: "Fat (g)", key: "fat" },
      { title: "Carbs (g)", key: "carbs" },
      { title: "Protein (g)", key: "protein" },
      { title: "Iron (%)", key: "iron" }
    ];
    const desserts2 = [
      {
        name: "Frozen Yogurt",
        calories: 159,
        fat: 6,
        carbs: 24,
        protein: 4,
        iron: 1
      },
      {
        name: "Ice cream sandwich",
        calories: 237,
        fat: 9,
        carbs: 37,
        protein: 4.3,
        iron: 1
      },
      {
        name: "Eclair",
        calories: 262,
        fat: 16,
        carbs: 23,
        protein: 6,
        iron: 7
      },
      {
        name: "Cupcake",
        calories: 305,
        fat: 3.7,
        carbs: 67,
        protein: 4.3,
        iron: 8
      },
      {
        name: "Gingerbread",
        calories: 356,
        fat: 16,
        carbs: 49,
        protein: 3.9,
        iron: 16
      },
      {
        name: "Jelly bean",
        calories: 375,
        fat: 0,
        carbs: 94,
        protein: 0,
        iron: 0
      },
      {
        name: "Lollipop",
        calories: 392,
        fat: 0.2,
        carbs: 98,
        protein: 0,
        iron: 2
      },
      {
        name: "Honeycomb",
        calories: 408,
        fat: 3.2,
        carbs: 87,
        protein: 6.5,
        iron: 45
      },
      {
        name: "Donut",
        calories: 452,
        fat: 25,
        carbs: 51,
        protein: 4.9,
        iron: 22
      },
      {
        name: "KitKat",
        calories: 518,
        fat: 26,
        carbs: 65,
        protein: 7,
        iron: 6
      }
    ];
    return (_ctx, _cache) => {
      const _component_v_data_table = resolveComponent("v-data-table");
      return openBlock(), createBlock(_component_v_data_table, {
        headers,
        items: desserts2,
        "item-value": "name"
      }, {
        item: withCtx(({ item }) => [
          createBaseVNode("tr", null, [
            createBaseVNode("td", null, toDisplayString(item.name), 1),
            createBaseVNode("td", null, toDisplayString(item.calories), 1),
            createBaseVNode("td", null, toDisplayString(item.fat), 1),
            createBaseVNode("td", null, toDisplayString(item.carbs), 1),
            createBaseVNode("td", null, toDisplayString(item.protein), 1),
            createBaseVNode("td", null, toDisplayString(item.iron), 1)
          ])
        ]),
        _: 1
      });
    };
  }
};
const __29 = _sfc_main$6;
const __29_raw = `<template>
  <v-data-table
    :headers="headers"
    :items="desserts"
    item-value="name"
  >
    <template v-slot:item="{ item }">
      <tr>
        <td>{{ item.name }}</td>
        <td>{{ item.calories }}</td>
        <td>{{ item.fat }}</td>
        <td>{{ item.carbs }}</td>
        <td>{{ item.protein }}</td>
        <td>{{ item.iron }}</td>
      </tr>
    </template>
  </v-data-table>
</template>

<script setup>
  const headers = [
    {
      title: 'Dessert (100g serving)',
      align: 'start',
      sortable: false,
      key: 'name',
    },
    { title: 'Calories', key: 'calories' },
    { title: 'Fat (g)', key: 'fat' },
    { title: 'Carbs (g)', key: 'carbs' },
    { title: 'Protein (g)', key: 'protein' },
    { title: 'Iron (%)', key: 'iron' },
  ]
  const desserts = [
    {
      name: 'Frozen Yogurt',
      calories: 159,
      fat: 6,
      carbs: 24,
      protein: 4,
      iron: 1,
    },
    {
      name: 'Ice cream sandwich',
      calories: 237,
      fat: 9,
      carbs: 37,
      protein: 4.3,
      iron: 1,
    },
    {
      name: 'Eclair',
      calories: 262,
      fat: 16,
      carbs: 23,
      protein: 6,
      iron: 7,
    },
    {
      name: 'Cupcake',
      calories: 305,
      fat: 3.7,
      carbs: 67,
      protein: 4.3,
      iron: 8,
    },
    {
      name: 'Gingerbread',
      calories: 356,
      fat: 16,
      carbs: 49,
      protein: 3.9,
      iron: 16,
    },
    {
      name: 'Jelly bean',
      calories: 375,
      fat: 0,
      carbs: 94,
      protein: 0,
      iron: 0,
    },
    {
      name: 'Lollipop',
      calories: 392,
      fat: 0.2,
      carbs: 98,
      protein: 0,
      iron: 2,
    },
    {
      name: 'Honeycomb',
      calories: 408,
      fat: 3.2,
      carbs: 87,
      protein: 6.5,
      iron: 45,
    },
    {
      name: 'Donut',
      calories: 452,
      fat: 25,
      carbs: 51,
      protein: 4.9,
      iron: 22,
    },
    {
      name: 'KitKat',
      calories: 518,
      fat: 26,
      carbs: 65,
      protein: 7,
      iron: 6,
    },
  ]
<\/script>

<script>
  export default {
    data () {
      return {
        headers: [
          {
            title: 'Dessert (100g serving)',
            align: 'start',
            sortable: false,
            key: 'name',
          },
          { title: 'Calories', key: 'calories' },
          { title: 'Fat (g)', key: 'fat' },
          { title: 'Carbs (g)', key: 'carbs' },
          { title: 'Protein (g)', key: 'protein' },
          { title: 'Iron (%)', key: 'iron' },
        ],
        desserts: [
          {
            name: 'Frozen Yogurt',
            calories: 159,
            fat: 6.0,
            carbs: 24,
            protein: 4.0,
            iron: 1,
          },
          {
            name: 'Ice cream sandwich',
            calories: 237,
            fat: 9.0,
            carbs: 37,
            protein: 4.3,
            iron: 1,
          },
          {
            name: 'Eclair',
            calories: 262,
            fat: 16.0,
            carbs: 23,
            protein: 6.0,
            iron: 7,
          },
          {
            name: 'Cupcake',
            calories: 305,
            fat: 3.7,
            carbs: 67,
            protein: 4.3,
            iron: 8,
          },
          {
            name: 'Gingerbread',
            calories: 356,
            fat: 16.0,
            carbs: 49,
            protein: 3.9,
            iron: 16,
          },
          {
            name: 'Jelly bean',
            calories: 375,
            fat: 0.0,
            carbs: 94,
            protein: 0.0,
            iron: 0,
          },
          {
            name: 'Lollipop',
            calories: 392,
            fat: 0.2,
            carbs: 98,
            protein: 0,
            iron: 2,
          },
          {
            name: 'Honeycomb',
            calories: 408,
            fat: 3.2,
            carbs: 87,
            protein: 6.5,
            iron: 45,
          },
          {
            name: 'Donut',
            calories: 452,
            fat: 25.0,
            carbs: 51,
            protein: 4.9,
            iron: 22,
          },
          {
            name: 'KitKat',
            calories: 518,
            fat: 26.0,
            carbs: 65,
            protein: 7,
            iron: 6,
          },
        ],
      }
    },
  }
<\/script>
`;
const _hoisted_1$1 = { class: "text-center" };
const _sfc_main$5 = {
  __name: "slot-loading",
  setup(__props) {
    const loading = shallowRef(false);
    const items = [
      { name: "Chevrolet Camaro", year: 1967, engine: "V8", horsepower: 375, torque: 415 },
      { name: "Ford Mustang", year: 1965, engine: "V8", horsepower: 271, torque: 312 },
      { name: "Dodge Charger", year: 1968, engine: "V8", horsepower: 425, torque: 490 },
      { name: "Pontiac GTO", year: 1964, engine: "V8", horsepower: 350, torque: 445 },
      { name: "Plymouth Barracuda", year: 1964, engine: "V8", horsepower: 330, torque: 425 },
      { name: "Chevrolet Chevelle SS", year: 1970, engine: "V8", horsepower: 450, torque: 500 },
      { name: "Oldsmobile 442", year: 1971, engine: "V8", horsepower: 340, torque: 440 },
      { name: "Dodge Challenger", year: 1970, engine: "V8", horsepower: 425, torque: 490 },
      { name: "AMC Javelin", year: 1968, engine: "V8", horsepower: 315, torque: 425 },
      { name: "Mercury Cougar", year: 1967, engine: "V8", horsepower: 335, torque: 427 }
    ];
    function onClick() {
      loading.value = true;
      setTimeout(() => {
        loading.value = false;
      }, 2e3);
    }
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_skeleton_loader = resolveComponent("v-skeleton-loader");
      const _component_v_data_table = resolveComponent("v-data-table");
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("div", _hoisted_1$1, [
          createVNode(_component_v_btn, {
            disabled: loading.value,
            "append-icon": "mdi-refresh",
            text: "Refresh",
            variant: "outlined",
            onClick
          }, null, 8, ["disabled"])
        ]),
        createVNode(_component_v_data_table, {
          items,
          loading: loading.value
        }, {
          loading: withCtx(() => [
            createVNode(_component_v_skeleton_loader, { type: "table-row@10" })
          ]),
          _: 1
        }, 8, ["loading"])
      ], 64);
    };
  }
};
const __30 = _sfc_main$5;
const __30_raw = `<template>
  <div class="text-center">
    <v-btn
      :disabled="loading"
      append-icon="mdi-refresh"
      text="Refresh"
      variant="outlined"
      @click="onClick"
    ></v-btn>
  </div>

  <v-data-table :items="items" :loading="loading">
    <template v-slot:loading>
      <v-skeleton-loader type="table-row@10"></v-skeleton-loader>
    </template>
  </v-data-table>
</template>

<script setup>
  import { shallowRef } from 'vue'

  const loading = shallowRef(false)

  const items = [
    { name: 'Chevrolet Camaro', year: 1967, engine: 'V8', horsepower: 375, torque: 415 },
    { name: 'Ford Mustang', year: 1965, engine: 'V8', horsepower: 271, torque: 312 },
    { name: 'Dodge Charger', year: 1968, engine: 'V8', horsepower: 425, torque: 490 },
    { name: 'Pontiac GTO', year: 1964, engine: 'V8', horsepower: 350, torque: 445 },
    { name: 'Plymouth Barracuda', year: 1964, engine: 'V8', horsepower: 330, torque: 425 },
    { name: 'Chevrolet Chevelle SS', year: 1970, engine: 'V8', horsepower: 450, torque: 500 },
    { name: 'Oldsmobile 442', year: 1971, engine: 'V8', horsepower: 340, torque: 440 },
    { name: 'Dodge Challenger', year: 1970, engine: 'V8', horsepower: 425, torque: 490 },
    { name: 'AMC Javelin', year: 1968, engine: 'V8', horsepower: 315, torque: 425 },
    { name: 'Mercury Cougar', year: 1967, engine: 'V8', horsepower: 335, torque: 427 },
  ]

  function onClick () {
    loading.value = true
    setTimeout(() => {
      loading.value = false
    }, 2000)
  }
<\/script>

<script>
  import { shallowRef } from 'vue'

  export default {
    data () {
      return {
        loading: false,
        items: [
          { name: 'Chevrolet Camaro', year: 1967, engine: 'V8', horsepower: 375, torque: 415 },
          { name: 'Ford Mustang', year: 1965, engine: 'V8', horsepower: 271, torque: 312 },
          { name: 'Dodge Charger', year: 1968, engine: 'V8', horsepower: 425, torque: 490 },
          { name: 'Pontiac GTO', year: 1964, engine: 'V8', horsepower: 350, torque: 445 },
          { name: 'Plymouth Barracuda', year: 1964, engine: 'V8', horsepower: 330, torque: 425 },
          { name: 'Chevrolet Chevelle SS', year: 1970, engine: 'V8', horsepower: 450, torque: 500 },
          { name: 'Oldsmobile 442', year: 1971, engine: 'V8', horsepower: 340, torque: 440 },
          { name: 'Dodge Challenger', year: 1970, engine: 'V8', horsepower: 425, torque: 490 },
          { name: 'AMC Javelin', year: 1968, engine: 'V8', horsepower: 315, torque: 425 },
          { name: 'Mercury Cougar', year: 1967, engine: 'V8', horsepower: 335, torque: 427 },
        ],
      }
    },
    methods: {
      onClick () {
        this.loading = true
        setTimeout(() => {
          this.loading = false
        }, 2000)
      },
    },
  }
<\/script>
`;
const desserts = [
  {
    name: "Frozen Yogurt",
    calories: 159,
    fat: 6,
    carbs: 24,
    protein: 4,
    iron: 1
  },
  {
    name: "Ice cream sandwich",
    calories: 237,
    fat: 9,
    carbs: 37,
    protein: 4.3,
    iron: 1
  },
  {
    name: "Eclair",
    calories: 262,
    fat: 16,
    carbs: 23,
    protein: 6,
    iron: 7
  },
  {
    name: "Cupcake",
    calories: 305,
    fat: 3.7,
    carbs: 67,
    protein: 4.3,
    iron: 8
  },
  {
    name: "Gingerbread",
    calories: 356,
    fat: 16,
    carbs: 49,
    protein: 3.9,
    iron: 16
  },
  {
    name: "Jelly bean",
    calories: 375,
    fat: 0,
    carbs: 94,
    protein: 0,
    iron: 0
  },
  {
    name: "Lollipop",
    calories: 392,
    fat: 0.2,
    carbs: 98,
    protein: 0,
    iron: 2
  },
  {
    name: "Honeycomb",
    calories: 408,
    fat: 3.2,
    carbs: 87,
    protein: 6.5,
    iron: 45
  },
  {
    name: "Donut",
    calories: 452,
    fat: 25,
    carbs: 51,
    protein: 4.9,
    iron: 22
  },
  {
    name: "KitKat",
    calories: 518,
    fat: 26,
    carbs: 65,
    protein: 7,
    iron: 6
  }
];
const _sfc_main$4 = {
  data() {
    return {
      enabled: null,
      itemsArray: desserts,
      search: null,
      slots: [
        "body",
        "body.append",
        "body.prepend",
        "footer",
        "header.data-table-select",
        "header",
        "progress",
        "item.data-table-select",
        "item.<name>",
        "no-data",
        "no-results",
        "top"
      ],
      headerArray: [
        {
          text: "Dessert (100g serving)",
          align: "start",
          sortable: false,
          value: "name"
        },
        { text: "Calories", value: "calories" },
        { text: "Fat (g)", value: "fat" },
        { text: "Carbs (g)", value: "carbs" },
        { text: "Protein (g)", value: "protein" },
        { text: "Iron (%)", value: "iron" }
      ]
    };
  },
  computed: {
    showSelect() {
      return this.isEnabled("header.data-table-select") || this.isEnabled("item.data-table-select");
    },
    hideHeaders() {
      return !this.showSelect;
    },
    isLoading() {
      return this.isEnabled("progress");
    }
  },
  watch: {
    enabled(slot) {
      if (slot === "no-data") {
        this.items = [];
      } else if (slot === "no-results") {
        this.search = "...";
      } else {
        this.search = null;
        this.itemsArray = desserts;
      }
    }
  },
  methods: {
    isEnabled(slot) {
      return this.enabled === slot;
    }
  }
};
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("div", null, "This is content above the actual table", -1);
const _hoisted_2 = ["colspan"];
const _hoisted_3 = ["colspan"];
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("td", null, "CONTENT", -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("td", null, "CONTENT", -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("td", null, "CONTENT", -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("td", null, "CONTENT", -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("td", null, "CONTENT", -1);
const _hoisted_9 = ["colspan"];
const _hoisted_10 = /* @__PURE__ */ createBaseVNode("div", null, " This is a footer ", -1);
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_v_select = resolveComponent("v-select");
  const _component_v_checkbox_btn = resolveComponent("v-checkbox-btn");
  const _component_v_progress_linear = resolveComponent("v-progress-linear");
  const _component_v_data_table = resolveComponent("v-data-table");
  return openBlock(), createElementBlock("div", null, [
    createVNode(_component_v_select, {
      modelValue: $data.enabled,
      "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => $data.enabled = $event),
      items: $data.slots,
      label: "Slot",
      clearable: ""
    }, null, 8, ["modelValue", "items"]),
    createVNode(_component_v_data_table, {
      headers: $data.headerArray,
      "hide-default-header": $options.hideHeaders,
      items: $data.itemsArray,
      loading: $options.isLoading,
      search: $data.search,
      "show-select": $options.showSelect,
      class: "elevation-1",
      "item-key": "name",
      "hide-default-footer": ""
    }, createSlots({ _: 2 }, [
      $options.isEnabled("top") ? {
        name: "top",
        fn: withCtx(() => [
          _hoisted_1
        ]),
        key: "0"
      } : void 0,
      $options.isEnabled("header.data-table-select") ? {
        name: "header.data-table-select",
        fn: withCtx(({ on, props }) => [
          createVNode(_component_v_checkbox_btn, mergeProps({ color: "purple" }, props, toHandlers(on)), null, 16)
        ]),
        key: "1"
      } : void 0,
      $options.isEnabled("header") ? {
        name: "header",
        fn: withCtx(({ props: { headers } }) => [
          createBaseVNode("thead", null, [
            createBaseVNode("tr", null, [
              createBaseVNode("th", {
                colspan: headers.length
              }, " This is a header ", 8, _hoisted_2)
            ])
          ])
        ]),
        key: "2"
      } : void 0,
      $options.isEnabled("progress") ? {
        name: "progress",
        fn: withCtx(() => [
          createVNode(_component_v_progress_linear, {
            height: 10,
            color: "purple",
            indeterminate: ""
          })
        ]),
        key: "3"
      } : void 0,
      $options.isEnabled("item.data-table-select") ? {
        name: "item.data-table-select",
        fn: withCtx(({ isSelected, select }) => [
          createVNode(_component_v_checkbox_btn, {
            value: isSelected,
            color: "green",
            onInput: ($event) => select($event)
          }, null, 8, ["value", "onInput"])
        ]),
        key: "4"
      } : void 0,
      $options.isEnabled("item.<name>") ? {
        name: "item.name",
        fn: withCtx(({ value }) => [
          createTextVNode(toDisplayString(value.toUpperCase()), 1)
        ]),
        key: "5"
      } : void 0,
      $options.isEnabled("body.prepend") ? {
        name: "body.prepend",
        fn: withCtx(({ headers }) => [
          createBaseVNode("tr", null, [
            createBaseVNode("td", {
              colspan: headers.length
            }, " This is a prepended row ", 8, _hoisted_3)
          ])
        ]),
        key: "6"
      } : void 0,
      $options.isEnabled("body") ? {
        name: "body",
        fn: withCtx(({ items }) => [
          createBaseVNode("tbody", null, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(items, (item) => {
              return openBlock(), createElementBlock("tr", {
                key: item.raw.name
              }, [
                createBaseVNode("td", null, toDisplayString(item.raw.name), 1),
                _hoisted_4,
                _hoisted_5,
                _hoisted_6,
                _hoisted_7,
                _hoisted_8
              ]);
            }), 128))
          ])
        ]),
        key: "7"
      } : void 0,
      $options.isEnabled("no-data") ? {
        name: "no-data",
        fn: withCtx(() => [
          createTextVNode(" NO DATA HERE! ")
        ]),
        key: "8"
      } : void 0,
      $options.isEnabled("no-results") ? {
        name: "no-results",
        fn: withCtx(() => [
          createTextVNode(" NO RESULTS HERE! ")
        ]),
        key: "9"
      } : void 0,
      $options.isEnabled("body.append") ? {
        name: "body.append",
        fn: withCtx(({ headers }) => [
          createBaseVNode("tr", null, [
            createBaseVNode("td", {
              colspan: headers.length
            }, " This is an appended row ", 8, _hoisted_9)
          ])
        ]),
        key: "10"
      } : void 0,
      $options.isEnabled("footer") ? {
        name: "footer",
        fn: withCtx(() => [
          _hoisted_10
        ]),
        key: "11"
      } : void 0
    ]), 1032, ["headers", "hide-default-header", "items", "loading", "search", "show-select"])
  ]);
}
const __31 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["render", _sfc_render]]);
const __31_raw = `<template>
  <div>
    <v-select
      v-model="enabled"
      :items="slots"
      label="Slot"
      clearable
    ></v-select>
    <v-data-table
      :headers="headerArray"
      :hide-default-header="hideHeaders"
      :items="itemsArray"
      :loading="isLoading"
      :search="search"
      :show-select="showSelect"
      class="elevation-1"
      item-key="name"
      hide-default-footer
    >
      <template
        v-if="isEnabled('top')"
        v-slot:top
      >
        <div>This is content above the actual table</div>
      </template>

      <template
        v-if="isEnabled('header.data-table-select')"
        v-slot:header.data-table-select="{ on, props }"
      >
        <v-checkbox-btn
          color="purple"
          v-bind="props"
          v-on="on"
        ></v-checkbox-btn>
      </template>

      <template
        v-if="isEnabled('header')"
        v-slot:header="{ props: { headers } }"
      >
        <thead>
          <tr>
            <th :colspan="headers.length">
              This is a header
            </th>
          </tr>
        </thead>
      </template>

      <template
        v-if="isEnabled('progress')"
        v-slot:progress
      >
        <v-progress-linear
          :height="10"
          color="purple"
          indeterminate
        ></v-progress-linear>
      </template>

      <template
        v-if="isEnabled('item.data-table-select')"
        v-slot:item.data-table-select="{ isSelected, select }"
      >
        <v-checkbox-btn
          :value="isSelected"
          color="green"
          @input="select($event)"
        ></v-checkbox-btn>
      </template>

      <template
        v-if="isEnabled('item.<name>')"
        v-slot:item.name="{ value }"
      >
        {{ value.toUpperCase() }}
      </template>

      <template
        v-if="isEnabled('body.prepend')"
        v-slot:body.prepend="{ headers }"
      >
        <tr>
          <td :colspan="headers.length">
            This is a prepended row
          </td>
        </tr>
      </template>

      <template
        v-if="isEnabled('body')"
        v-slot:body="{ items }"
      >
        <tbody>
          <tr
            v-for="item in items"
            :key="item.raw.name"
          >
            <td>{{ item.raw.name }}</td>
            <td>CONTENT</td>
            <td>CONTENT</td>
            <td>CONTENT</td>
            <td>CONTENT</td>
            <td>CONTENT</td>
          </tr>
        </tbody>
      </template>

      <template
        v-if="isEnabled('no-data')"
        v-slot:no-data
      >
        NO DATA HERE!
      </template>

      <template
        v-if="isEnabled('no-results')"
        v-slot:no-results
      >
        NO RESULTS HERE!
      </template>

      <template
        v-if="isEnabled('body.append')"
        v-slot:body.append="{ headers }"
      >
        <tr>
          <td :colspan="headers.length">
            This is an appended row
          </td>
        </tr>
      </template>

      <template
        v-if="isEnabled('footer')"
        v-slot:footer
      >
        <div>
          This is a footer
        </div>
      </template>
    </v-data-table>
  </div>
</template>

<script>
  const desserts = [
    {
      name: 'Frozen Yogurt',
      calories: 159,
      fat: 6.0,
      carbs: 24,
      protein: 4.0,
      iron: 1,
    },
    {
      name: 'Ice cream sandwich',
      calories: 237,
      fat: 9.0,
      carbs: 37,
      protein: 4.3,
      iron: 1,
    },
    {
      name: 'Eclair',
      calories: 262,
      fat: 16.0,
      carbs: 23,
      protein: 6.0,
      iron: 7,
    },
    {
      name: 'Cupcake',
      calories: 305,
      fat: 3.7,
      carbs: 67,
      protein: 4.3,
      iron: 8,
    },
    {
      name: 'Gingerbread',
      calories: 356,
      fat: 16.0,
      carbs: 49,
      protein: 3.9,
      iron: 16,
    },
    {
      name: 'Jelly bean',
      calories: 375,
      fat: 0.0,
      carbs: 94,
      protein: 0.0,
      iron: 0,
    },
    {
      name: 'Lollipop',
      calories: 392,
      fat: 0.2,
      carbs: 98,
      protein: 0,
      iron: 2,
    },
    {
      name: 'Honeycomb',
      calories: 408,
      fat: 3.2,
      carbs: 87,
      protein: 6.5,
      iron: 45,
    },
    {
      name: 'Donut',
      calories: 452,
      fat: 25.0,
      carbs: 51,
      protein: 4.9,
      iron: 22,
    },
    {
      name: 'KitKat',
      calories: 518,
      fat: 26.0,
      carbs: 65,
      protein: 7,
      iron: 6,
    },
  ]

  export default {
    data () {
      return {
        enabled: null,
        itemsArray: desserts,
        search: null,
        slots: [
          'body',
          'body.append',
          'body.prepend',
          'footer',
          'header.data-table-select',
          'header',
          'progress',
          'item.data-table-select',
          'item.<name>',
          'no-data',
          'no-results',
          'top',
        ],
        headerArray: [
          {
            text: 'Dessert (100g serving)',
            align: 'start',
            sortable: false,
            value: 'name',
          },
          { text: 'Calories', value: 'calories' },
          { text: 'Fat (g)', value: 'fat' },
          { text: 'Carbs (g)', value: 'carbs' },
          { text: 'Protein (g)', value: 'protein' },
          { text: 'Iron (%)', value: 'iron' },
        ],
      }
    },

    computed: {
      showSelect () {
        return this.isEnabled('header.data-table-select') || this.isEnabled('item.data-table-select')
      },
      hideHeaders () {
        return !this.showSelect
      },
      isLoading () {
        return this.isEnabled('progress')
      },
    },

    watch: {
      enabled (slot) {
        if (slot === 'no-data') {
          this.items = []
        } else if (slot === 'no-results') {
          this.search = '...'
        } else {
          this.search = null
          this.itemsArray = desserts
        }
      },
    },

    methods: {
      isEnabled (slot) {
        return this.enabled === slot
      },
    },
  }
<\/script>
`;
const _sfc_main$3 = {
  __name: "slot-simple-checkbox",
  setup(__props) {
    const consoles = [
      {
        name: "PlayStation 5",
        manufacturer: "Sony",
        year: 2020,
        sales: "10M",
        exclusive: true
      },
      {
        name: "Xbox Series X",
        manufacturer: "Microsoft",
        year: 2020,
        sales: "6.5M",
        exclusive: false
      },
      {
        name: "Nintendo Switch",
        manufacturer: "Nintendo",
        year: 2017,
        sales: "89M",
        exclusive: true
      },
      {
        name: "PlayStation 4",
        manufacturer: "Sony",
        year: 2013,
        sales: "116M",
        exclusive: true
      },
      {
        name: "Xbox One",
        manufacturer: "Microsoft",
        year: 2013,
        sales: "50M",
        exclusive: false
      },
      {
        name: "Nintendo Wii",
        manufacturer: "Nintendo",
        year: 2006,
        sales: "101M",
        exclusive: true
      }
    ];
    return (_ctx, _cache) => {
      const _component_v_checkbox = resolveComponent("v-checkbox");
      const _component_v_data_table = resolveComponent("v-data-table");
      return openBlock(), createBlock(_component_v_data_table, { items: consoles }, {
        "item.exclusive": withCtx(({ item }) => [
          createVNode(_component_v_checkbox, {
            modelValue: item.exclusive,
            "onUpdate:modelValue": ($event) => item.exclusive = $event,
            readonly: ""
          }, null, 8, ["modelValue", "onUpdate:modelValue"])
        ]),
        _: 1
      });
    };
  }
};
const __32 = _sfc_main$3;
const __32_raw = `<template>
  <v-data-table :items="consoles">
    <template v-slot:item.exclusive="{ item }">
      <v-checkbox
        v-model="item.exclusive"
        readonly
      ></v-checkbox>
    </template>
  </v-data-table>
</template>

<script setup>
  const consoles = [
    {
      name: 'PlayStation 5',
      manufacturer: 'Sony',
      year: 2020,
      sales: '10M',
      exclusive: true,
    },
    {
      name: 'Xbox Series X',
      manufacturer: 'Microsoft',
      year: 2020,
      sales: '6.5M',
      exclusive: false,
    },
    {
      name: 'Nintendo Switch',
      manufacturer: 'Nintendo',
      year: 2017,
      sales: '89M',
      exclusive: true,
    },
    {
      name: 'PlayStation 4',
      manufacturer: 'Sony',
      year: 2013,
      sales: '116M',
      exclusive: true,
    },
    {
      name: 'Xbox One',
      manufacturer: 'Microsoft',
      year: 2013,
      sales: '50M',
      exclusive: false,
    },
    {
      name: 'Nintendo Wii',
      manufacturer: 'Nintendo',
      year: 2006,
      sales: '101M',
      exclusive: true,
    },
  ]
<\/script>

<script>
  export default {
    data: () => ({
      consoles: [
        {
          name: 'PlayStation 5',
          manufacturer: 'Sony',
          year: 2020,
          sales: '10M',
          exclusive: true,
        },
        {
          name: 'Xbox Series X',
          manufacturer: 'Microsoft',
          year: 2020,
          sales: '6.5M',
          exclusive: false,
        },
        {
          name: 'Nintendo Switch',
          manufacturer: 'Nintendo',
          year: 2017,
          sales: '89M',
          exclusive: true,
        },
        {
          name: 'PlayStation 4',
          manufacturer: 'Sony',
          year: 2013,
          sales: '116M',
          exclusive: true,
        },
        {
          name: 'Xbox One',
          manufacturer: 'Microsoft',
          year: 2013,
          sales: '50M',
          exclusive: false,
        },
        {
          name: 'Nintendo Wii',
          manufacturer: 'Nintendo',
          year: 2006,
          sales: '101M',
          exclusive: true,
        },
      ],
    }),
  }
<\/script>
`;
const name = "v-data-table";
const _sfc_main$2 = {
  __name: "usage",
  setup(__props) {
    const model = ref("default");
    const options = [];
    const items = [
      {
        name: "African Elephant",
        species: "Loxodonta africana",
        diet: "Herbivore",
        habitat: "Savanna, Forests"
      },
      {
        name: "Lion",
        species: "Panthera leo",
        diet: "Carnivore",
        habitat: "Savanna, Grassland"
      },
      {
        name: "Giraffe",
        species: "Giraffa camelopardalis",
        diet: "Herbivore",
        habitat: "Savanna, Grassland"
      },
      {
        name: "Zebra",
        species: "Equus quagga",
        diet: "Herbivore",
        habitat: "Savanna, Grassland"
      },
      {
        name: "Hippopotamus",
        species: "Hippopotamus amphibius",
        diet: "Herbivore",
        habitat: "Riverbanks, Lakes"
      },
      {
        name: "Meerkat",
        species: "Suricata suricatta",
        diet: "Omnivore",
        habitat: "Desert, Savanna"
      },
      {
        name: "Hyena",
        species: "Crocuta crocuta",
        diet: "Carnivore",
        habitat: "Savanna, Grassland"
      },
      {
        name: "Zebra",
        species: "Equus quagga",
        diet: "Herbivore",
        habitat: "Savanna, Grassland"
      },
      {
        name: "Ostrich",
        species: "Struthio camelus",
        diet: "Omnivore",
        habitat: "Savanna, Grassland"
      },
      {
        name: "Cheetah",
        species: "Acinonyx jubatus",
        diet: "Carnivore",
        habitat: "Savanna, Grassland"
      }
    ];
    const props = computed(() => {
      return {
        ":items": "items"
      };
    });
    const script = computed(() => {
      return `<script setup>
  const items = [
    {
      name: 'African Elephant',
      species: 'Loxodonta africana',
      diet: 'Herbivore',
      habitat: 'Savanna, Forests',
    },
    // ... more items
  ]
<\/script>`;
    });
    const code = computed(() => {
      return `<v-data-table${propsToString(props.value, 2)}></v-data-table>`;
    });
    return (_ctx, _cache) => {
      const _component_v_data_table = resolveComponent("v-data-table");
      const _component_ExamplesUsageExample = _sfc_main$A;
      return openBlock(), createBlock(_component_ExamplesUsageExample, {
        modelValue: unref(model),
        "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(model) ? model.value = $event : null),
        code: unref(code),
        name,
        options,
        script: unref(script)
      }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createVNode(_component_v_data_table, mergeProps(unref(props), { items }), null, 16)
          ])
        ]),
        _: 1
      }, 8, ["modelValue", "code", "script"]);
    };
  }
};
const __33 = _sfc_main$2;
const __33_raw = `<template>
  <ExamplesUsageExample
    v-model="model"
    :code="code"
    :name="name"
    :options="options"
    :script="script"
  >
    <div>
      <v-data-table
        v-bind="props"
        :items="items"
      ></v-data-table>
    </div>
  </ExamplesUsageExample>
</template>

<script setup>
  const name = 'v-data-table'
  const model = ref('default')
  const options = []

  const items = [
    {
      name: 'African Elephant',
      species: 'Loxodonta africana',
      diet: 'Herbivore',
      habitat: 'Savanna, Forests',
    },
    {
      name: 'Lion',
      species: 'Panthera leo',
      diet: 'Carnivore',
      habitat: 'Savanna, Grassland',
    },
    {
      name: 'Giraffe',
      species: 'Giraffa camelopardalis',
      diet: 'Herbivore',
      habitat: 'Savanna, Grassland',
    },
    {
      name: 'Zebra',
      species: 'Equus quagga',
      diet: 'Herbivore',
      habitat: 'Savanna, Grassland',
    },
    {
      name: 'Hippopotamus',
      species: 'Hippopotamus amphibius',
      diet: 'Herbivore',
      habitat: 'Riverbanks, Lakes',
    },
    {
      name: 'Meerkat',
      species: 'Suricata suricatta',
      diet: 'Omnivore',
      habitat: 'Desert, Savanna',
    },
    {
      name: 'Hyena',
      species: 'Crocuta crocuta',
      diet: 'Carnivore',
      habitat: 'Savanna, Grassland',
    },
    {
      name: 'Zebra',
      species: 'Equus quagga',
      diet: 'Herbivore',
      habitat: 'Savanna, Grassland',
    },
    {
      name: 'Ostrich',
      species: 'Struthio camelus',
      diet: 'Omnivore',
      habitat: 'Savanna, Grassland',
    },
    {
      name: 'Cheetah',
      species: 'Acinonyx jubatus',
      diet: 'Carnivore',
      habitat: 'Savanna, Grassland',
    },
  ]

  const props = computed(() => {
    return {
      ':items': 'items',
    }
  })

  // eslint doesn't like the script tag inside the template
  const script = computed(() => {
    return \`<script setup>
  const items = [
    {
      name: 'African Elephant',
      species: 'Loxodonta africana',
      diet: 'Herbivore',
      habitat: 'Savanna, Forests',
    },
    // ... more items
  ]
<\` + '/script>'
  })

  const code = computed(() => {
    return \`<v-data-table\${propsToString(props.value, 2)}></v-data-table>\`
  })
<\/script>
`;
const _sfc_main$1 = {
  __name: "virtual",
  setup(__props) {
    const headers = [
      { title: "Boat Type", align: "start", key: "name" },
      { title: "Speed (knots)", align: "end", key: "speed" },
      { title: "Length (m)", align: "end", key: "length" },
      { title: "Price ($)", align: "end", key: "price" },
      { title: "Year", align: "end", key: "year" }
    ];
    const boats = [
      {
        name: "Speedster",
        speed: 35,
        length: 22,
        price: 3e5,
        year: 2021
      },
      {
        name: "OceanMaster",
        speed: 25,
        length: 35,
        price: 5e5,
        year: 2020
      },
      {
        name: "Voyager",
        speed: 20,
        length: 45,
        price: 7e5,
        year: 2019
      },
      {
        name: "WaveRunner",
        speed: 40,
        length: 19,
        price: 25e4,
        year: 2022
      },
      {
        name: "SeaBreeze",
        speed: 28,
        length: 31,
        price: 45e4,
        year: 2018
      },
      {
        name: "HarborGuard",
        speed: 18,
        length: 50,
        price: 8e5,
        year: 2017
      },
      {
        name: "SlickFin",
        speed: 33,
        length: 24,
        price: 35e4,
        year: 2021
      },
      {
        name: "StormBreaker",
        speed: 22,
        length: 38,
        price: 6e5,
        year: 2020
      },
      {
        name: "WindSail",
        speed: 15,
        length: 55,
        price: 9e5,
        year: 2019
      },
      {
        name: "FastTide",
        speed: 37,
        length: 20,
        price: 28e4,
        year: 2022
      }
    ];
    const virtualBoats = computed(() => {
      return [...Array(1e4).keys()].map((i) => {
        const boat = { ...boats[i % 10] };
        boat.name = `${boat.name} #${i}`;
        return boat;
      });
    });
    return (_ctx, _cache) => {
      const _component_v_data_table_virtual = resolveComponent("v-data-table-virtual");
      return openBlock(), createBlock(_component_v_data_table_virtual, {
        headers,
        items: virtualBoats.value,
        height: "400",
        "item-value": "name"
      }, null, 8, ["items"]);
    };
  }
};
const __34 = _sfc_main$1;
const __34_raw = "<template>\n  <v-data-table-virtual\n    :headers=\"headers\"\n    :items=\"virtualBoats\"\n    height=\"400\"\n    item-value=\"name\"\n  ></v-data-table-virtual>\n</template>\n\n<script setup>\n  import { computed } from 'vue'\n\n  const headers = [\n    { title: 'Boat Type', align: 'start', key: 'name' },\n    { title: 'Speed (knots)', align: 'end', key: 'speed' },\n    { title: 'Length (m)', align: 'end', key: 'length' },\n    { title: 'Price ($)', align: 'end', key: 'price' },\n    { title: 'Year', align: 'end', key: 'year' },\n  ]\n\n  const boats = [\n    {\n      name: 'Speedster',\n      speed: 35,\n      length: 22,\n      price: 300000,\n      year: 2021,\n    },\n    {\n      name: 'OceanMaster',\n      speed: 25,\n      length: 35,\n      price: 500000,\n      year: 2020,\n    },\n    {\n      name: 'Voyager',\n      speed: 20,\n      length: 45,\n      price: 700000,\n      year: 2019,\n    },\n    {\n      name: 'WaveRunner',\n      speed: 40,\n      length: 19,\n      price: 250000,\n      year: 2022,\n    },\n    {\n      name: 'SeaBreeze',\n      speed: 28,\n      length: 31,\n      price: 450000,\n      year: 2018,\n    },\n    {\n      name: 'HarborGuard',\n      speed: 18,\n      length: 50,\n      price: 800000,\n      year: 2017,\n    },\n    {\n      name: 'SlickFin',\n      speed: 33,\n      length: 24,\n      price: 350000,\n      year: 2021,\n    },\n    {\n      name: 'StormBreaker',\n      speed: 22,\n      length: 38,\n      price: 600000,\n      year: 2020,\n    },\n    {\n      name: 'WindSail',\n      speed: 15,\n      length: 55,\n      price: 900000,\n      year: 2019,\n    },\n    {\n      name: 'FastTide',\n      speed: 37,\n      length: 20,\n      price: 280000,\n      year: 2022,\n    },\n  ]\n\n  const virtualBoats = computed(() => {\n    return [...Array(10000).keys()].map(i => {\n      const boat = { ...boats[i % 10] }\n      boat.name = `${boat.name} #${i}`\n      return boat\n    })\n  })\n<\/script>\n\n<script>\n  export default {\n    data () {\n      return {\n        headers: [\n          { title: 'Boat Type', align: 'start', key: 'name' },\n          { title: 'Speed (knots)', align: 'end', key: 'speed' },\n          { title: 'Length (m)', align: 'end', key: 'length' },\n          { title: 'Price ($)', align: 'end', key: 'price' },\n          { title: 'Year', align: 'end', key: 'year' },\n        ],\n        boats: [\n          {\n            name: 'Speedster',\n            speed: 35,\n            length: 22,\n            price: 300000,\n            year: 2021,\n          },\n          {\n            name: 'OceanMaster',\n            speed: 25,\n            length: 35,\n            price: 500000,\n            year: 2020,\n          },\n          {\n            name: 'Voyager',\n            speed: 20,\n            length: 45,\n            price: 700000,\n            year: 2019,\n          },\n          {\n            name: 'WaveRunner',\n            speed: 40,\n            length: 19,\n            price: 250000,\n            year: 2022,\n          },\n          {\n            name: 'SeaBreeze',\n            speed: 28,\n            length: 31,\n            price: 450000,\n            year: 2018,\n          },\n          {\n            name: 'HarborGuard',\n            speed: 18,\n            length: 50,\n            price: 800000,\n            year: 2017,\n          },\n          {\n            name: 'SlickFin',\n            speed: 33,\n            length: 24,\n            price: 350000,\n            year: 2021,\n          },\n          {\n            name: 'StormBreaker',\n            speed: 22,\n            length: 38,\n            price: 600000,\n            year: 2020,\n          },\n          {\n            name: 'WindSail',\n            speed: 15,\n            length: 55,\n            price: 900000,\n            year: 2019,\n          },\n          {\n            name: 'FastTide',\n            speed: 37,\n            length: 20,\n            price: 280000,\n            year: 2022,\n          },\n        ],\n      }\n    },\n\n    computed: {\n      virtualBoats () {\n        return [...Array(10000).keys()].map(i => {\n          const boat = { ...this.boats[i % this.boats.length] }\n          boat.name = `${boat.name} #${i}`\n          return boat\n        })\n      },\n    },\n  }\n<\/script>\n";
const _sfc_main = {
  __name: "virtualized",
  setup(__props) {
    const desserts2 = [
      {
        name: "Frozen Yogurt",
        calories: 159,
        fat: 6,
        carbs: 24,
        protein: 4,
        iron: 1
      },
      {
        name: "Ice cream sandwich",
        calories: 237,
        fat: 9,
        carbs: 37,
        protein: 4.3,
        iron: 1
      },
      {
        name: "Eclair",
        calories: 262,
        fat: 16,
        carbs: 23,
        protein: 6,
        iron: 7
      },
      {
        name: "Cupcake",
        calories: 305,
        fat: 3.7,
        carbs: 67,
        protein: 4.3,
        iron: 8
      },
      {
        name: "Gingerbread",
        calories: 356,
        fat: 16,
        carbs: 49,
        protein: 3.9,
        iron: 16
      },
      {
        name: "Jelly bean",
        calories: 375,
        fat: 0,
        carbs: 94,
        protein: 0,
        iron: 0
      },
      {
        name: "Lollipop",
        calories: 392,
        fat: 0.2,
        carbs: 98,
        protein: 0,
        iron: 2
      },
      {
        name: "Honeycomb",
        calories: 408,
        fat: 3.2,
        carbs: 87,
        protein: 6.5,
        iron: 45
      },
      {
        name: "Donut",
        calories: 452,
        fat: 25,
        carbs: 51,
        protein: 4.9,
        iron: 22
      },
      {
        name: "KitKat",
        calories: 518,
        fat: 26,
        carbs: 65,
        protein: 7,
        iron: 6
      }
    ];
    const headers = [
      {
        title: "Dessert (100g serving)",
        align: "start",
        sortable: false,
        key: "name"
      },
      { title: "Calories", key: "calories" },
      { title: "Fat (g)", key: "fat" },
      { title: "Carbs (g)", key: "carbs" },
      { title: "Protein (g)", key: "protein" },
      { title: "Iron (%)", key: "iron" }
    ];
    const items = computed(() => {
      return [...new Array(100)].reduce((items2) => {
        items2.push(...desserts2);
        return items2;
      }, []);
    });
    return (_ctx, _cache) => {
      const _component_v_data_table = resolveComponent("v-data-table");
      return openBlock(), createBlock(_component_v_data_table, {
        headers,
        items: items.value,
        "items-per-page": -1,
        height: "500",
        "hide-default-footer": "",
        "virtual-rows": ""
      }, null, 8, ["items"]);
    };
  }
};
const __35 = _sfc_main;
const __35_raw = `<template>
  <v-data-table
    :headers="headers"
    :items="items"
    :items-per-page="-1"
    height="500"
    hide-default-footer
    virtual-rows
  ></v-data-table>
</template>

<script setup>
  import { computed } from 'vue'

  const desserts = [
    {
      name: 'Frozen Yogurt',
      calories: 159,
      fat: 6,
      carbs: 24,
      protein: 4,
      iron: 1,
    },
    {
      name: 'Ice cream sandwich',
      calories: 237,
      fat: 9,
      carbs: 37,
      protein: 4.3,
      iron: 1,
    },
    {
      name: 'Eclair',
      calories: 262,
      fat: 16,
      carbs: 23,
      protein: 6,
      iron: 7,
    },
    {
      name: 'Cupcake',
      calories: 305,
      fat: 3.7,
      carbs: 67,
      protein: 4.3,
      iron: 8,
    },
    {
      name: 'Gingerbread',
      calories: 356,
      fat: 16,
      carbs: 49,
      protein: 3.9,
      iron: 16,
    },
    {
      name: 'Jelly bean',
      calories: 375,
      fat: 0,
      carbs: 94,
      protein: 0,
      iron: 0,
    },
    {
      name: 'Lollipop',
      calories: 392,
      fat: 0.2,
      carbs: 98,
      protein: 0,
      iron: 2,
    },
    {
      name: 'Honeycomb',
      calories: 408,
      fat: 3.2,
      carbs: 87,
      protein: 6.5,
      iron: 45,
    },
    {
      name: 'Donut',
      calories: 452,
      fat: 25,
      carbs: 51,
      protein: 4.9,
      iron: 22,
    },
    {
      name: 'KitKat',
      calories: 518,
      fat: 26,
      carbs: 65,
      protein: 7,
      iron: 6,
    },
  ]
  const headers = [
    {
      title: 'Dessert (100g serving)',
      align: 'start',
      sortable: false,
      key: 'name',
    },
    { title: 'Calories', key: 'calories' },
    { title: 'Fat (g)', key: 'fat' },
    { title: 'Carbs (g)', key: 'carbs' },
    { title: 'Protein (g)', key: 'protein' },
    { title: 'Iron (%)', key: 'iron' },
  ]

  const items = computed(() => {
    return [...new Array(100)].reduce(items => {
      items.push(...desserts)
      return items
    }, [])
  })
<\/script>

<script>
  const desserts = [
    {
      name: 'Frozen Yogurt',
      calories: 159,
      fat: 6.0,
      carbs: 24,
      protein: 4.0,
      iron: 1,
    },
    {
      name: 'Ice cream sandwich',
      calories: 237,
      fat: 9.0,
      carbs: 37,
      protein: 4.3,
      iron: 1,
    },
    {
      name: 'Eclair',
      calories: 262,
      fat: 16.0,
      carbs: 23,
      protein: 6.0,
      iron: 7,
    },
    {
      name: 'Cupcake',
      calories: 305,
      fat: 3.7,
      carbs: 67,
      protein: 4.3,
      iron: 8,
    },
    {
      name: 'Gingerbread',
      calories: 356,
      fat: 16.0,
      carbs: 49,
      protein: 3.9,
      iron: 16,
    },
    {
      name: 'Jelly bean',
      calories: 375,
      fat: 0.0,
      carbs: 94,
      protein: 0.0,
      iron: 0,
    },
    {
      name: 'Lollipop',
      calories: 392,
      fat: 0.2,
      carbs: 98,
      protein: 0,
      iron: 2,
    },
    {
      name: 'Honeycomb',
      calories: 408,
      fat: 3.2,
      carbs: 87,
      protein: 6.5,
      iron: 45,
    },
    {
      name: 'Donut',
      calories: 452,
      fat: 25.0,
      carbs: 51,
      protein: 4.9,
      iron: 22,
    },
    {
      name: 'KitKat',
      calories: 518,
      fat: 26.0,
      carbs: 65,
      protein: 7,
      iron: 6,
    },
  ]

  export default {
    data: () => ({
      headers: [
        {
          title: 'Dessert (100g serving)',
          align: 'start',
          sortable: false,
          key: 'name',
        },
        { title: 'Calories', key: 'calories' },
        { title: 'Fat (g)', key: 'fat' },
        { title: 'Carbs (g)', key: 'carbs' },
        { title: 'Protein (g)', key: 'protein' },
        { title: 'Iron (%)', key: 'iron' },
      ],
    }),
    computed: {
      items () {
        return [...new Array(100)].reduce(items => {
          items.push(...desserts)
          return items
        }, [])
      },
    },
  }
<\/script>
`;
const vDataTable = {
  "headers-multiple": {
    component: __0,
    source: __0_raw
  },
  "misc-crud": {
    component: __1,
    source: __1_raw
  },
  "misc-edit-dialog": {
    component: __2,
    source: __2_raw
  },
  "misc-expand": {
    component: __3,
    source: __3_raw
  },
  "misc-external-paginate": {
    component: __4,
    source: __4_raw
  },
  "misc-external-sort": {
    component: __5,
    source: __5_raw
  },
  "misc-server-side-paginate-and-sort": {
    component: __6,
    source: __6_raw
  },
  "prop-custom-filter": {
    component: __7,
    source: __7_raw
  },
  "prop-dense": {
    component: __8,
    source: __8_raw
  },
  "prop-filterable": {
    component: __9,
    source: __9_raw
  },
  "prop-footer-props": {
    component: __10,
    source: __10_raw
  },
  "prop-grouping": {
    component: __11,
    source: __11_raw
  },
  "prop-headers-sort-raw": {
    component: __12,
    source: __12_raw
  },
  "prop-hide-header-footer": {
    component: __13,
    source: __13_raw
  },
  "prop-item-selectable": {
    component: __14,
    source: __14_raw
  },
  "prop-item-value": {
    component: __15,
    source: __15_raw
  },
  "prop-loading": {
    component: __16,
    source: __16_raw
  },
  "prop-multi-sort": {
    component: __17,
    source: __17_raw
  },
  "prop-return-object": {
    component: __18,
    source: __18_raw
  },
  "prop-row-selection": {
    component: __19,
    source: __19_raw
  },
  "prop-search": {
    component: __20,
    source: __20_raw
  },
  "prop-select-strategy": {
    component: __21,
    source: __21_raw
  },
  "prop-sort-by": {
    component: __22,
    source: __22_raw
  },
  "server-search": {
    component: __23,
    source: __23_raw
  },
  "server": {
    component: __24,
    source: __24_raw
  },
  "slot-group-header": {
    component: __25,
    source: __25_raw
  },
  "slot-header": {
    component: __26,
    source: __26_raw
  },
  "slot-headers": {
    component: __27,
    source: __27_raw
  },
  "slot-item-key": {
    component: __28,
    source: __28_raw
  },
  "slot-item": {
    component: __29,
    source: __29_raw
  },
  "slot-loading": {
    component: __30,
    source: __30_raw
  },
  "slot-main": {
    component: __31,
    source: __31_raw
  },
  "slot-simple-checkbox": {
    component: __32,
    source: __32_raw
  },
  "usage": {
    component: __33,
    source: __33_raw
  },
  "virtual": {
    component: __34,
    source: __34_raw
  },
  "virtualized": {
    component: __35,
    source: __35_raw
  }
};
export {
  vDataTable as default
};
