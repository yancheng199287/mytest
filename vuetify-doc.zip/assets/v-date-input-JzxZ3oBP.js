import { y as _export_sfc, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, b as createVNode, h as createTextVNode, e as createBaseVNode, B as shallowRef, l as createElementBlock, J as ref, j as computed, ag as propsToString, f as unref, E as isRef, ak as normalizeProps, al as guardReactiveProps } from "./index-DGybHjCP.js";
import { _ as _sfc_main$6 } from "./UsageExample-M8CmNipa.js";
const _sfc_main$5 = {};
const _hoisted_1$3 = { class: "d-flex ga-2" };
function _sfc_render$1(_ctx, _cache) {
  const _component_v_icon = resolveComponent("v-icon");
  const _component_v_system_bar = resolveComponent("v-system-bar");
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_app_bar = resolveComponent("v-app-bar");
  const _component_v_text_field = resolveComponent("v-text-field");
  const _component_v_date_input = resolveComponent("v-date-input");
  const _component_v_container = resolveComponent("v-container");
  const _component_v_main = resolveComponent("v-main");
  const _component_v_layout = resolveComponent("v-layout");
  const _component_v_spacer = resolveComponent("v-spacer");
  const _component_v_card = resolveComponent("v-card");
  return openBlock(), createBlock(_component_v_card, {
    class: "mx-auto",
    "max-width": "420"
  }, {
    actions: withCtx(() => [
      createVNode(_component_v_btn, {
        color: "#4603c0",
        disabled: ""
      }, {
        default: withCtx(() => [
          createTextVNode("Prev")
        ]),
        _: 1
      }),
      createVNode(_component_v_spacer),
      createVNode(_component_v_btn, { color: "#4603c0" }, {
        default: withCtx(() => [
          createTextVNode("Next")
        ]),
        _: 1
      })
    ]),
    default: withCtx(() => [
      createVNode(_component_v_layout, null, {
        default: withCtx(() => [
          createVNode(_component_v_system_bar, { color: "#4603c0" }, {
            default: withCtx(() => [
              createVNode(_component_v_icon, { icon: "mdi-square" }),
              createVNode(_component_v_icon, { icon: "mdi-circle" }),
              createVNode(_component_v_icon, { icon: "mdi-triangle" })
            ]),
            _: 1
          }),
          createVNode(_component_v_app_bar, {
            color: "#6200ee",
            title: "Passenger information",
            flat: ""
          }, {
            prepend: withCtx(() => [
              createVNode(_component_v_btn, { icon: "mdi-arrow-left" })
            ]),
            _: 1
          }),
          createVNode(_component_v_main, null, {
            default: withCtx(() => [
              createVNode(_component_v_container, { class: "pt-8" }, {
                default: withCtx(() => [
                  createVNode(_component_v_text_field, {
                    label: "Name",
                    "model-value": "John Leider",
                    variant: "outlined"
                  }),
                  createVNode(_component_v_date_input, {
                    label: "Date of birth",
                    "prepend-icon": "",
                    variant: "outlined",
                    "persistent-placeholder": ""
                  }),
                  createVNode(_component_v_text_field, {
                    label: "Address",
                    variant: "outlined"
                  }),
                  createVNode(_component_v_text_field, {
                    label: "City",
                    variant: "outlined"
                  }),
                  createBaseVNode("div", _hoisted_1$3, [
                    createVNode(_component_v_text_field, {
                      label: "State",
                      variant: "outlined"
                    }),
                    createVNode(_component_v_text_field, {
                      label: "Zip code",
                      variant: "outlined"
                    })
                  ])
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __0 = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["render", _sfc_render$1]]);
const __0_raw = '<template>\n  <v-card class="mx-auto" max-width="420">\n    <v-layout>\n      <v-system-bar color="#4603c0">\n        <v-icon icon="mdi-square"></v-icon>\n\n        <v-icon icon="mdi-circle"></v-icon>\n\n        <v-icon icon="mdi-triangle"></v-icon>\n      </v-system-bar>\n\n      <v-app-bar color="#6200ee" title="Passenger information" flat>\n        <template v-slot:prepend>\n          <v-btn icon="mdi-arrow-left"></v-btn>\n        </template>\n      </v-app-bar>\n\n      <v-main>\n        <v-container class="pt-8">\n          <v-text-field\n            label="Name"\n            model-value="John Leider"\n            variant="outlined"\n          ></v-text-field>\n\n          <v-date-input\n            label="Date of birth"\n            prepend-icon=""\n            variant="outlined"\n            persistent-placeholder\n          ></v-date-input>\n\n          <v-text-field label="Address" variant="outlined"></v-text-field>\n          <v-text-field label="City" variant="outlined"></v-text-field>\n\n          <div class="d-flex ga-2">\n            <v-text-field label="State" variant="outlined"></v-text-field>\n\n            <v-text-field label="Zip code" variant="outlined"></v-text-field>\n          </div>\n        </v-container>\n      </v-main>\n    </v-layout>\n\n    <template v-slot:actions>\n      <v-btn color="#4603c0" disabled>Prev</v-btn>\n\n      <v-spacer></v-spacer>\n\n      <v-btn color="#4603c0">Next</v-btn>\n    </template>\n  </v-card>\n</template>\n';
const _hoisted_1$2 = { class: "d-flex justify-center" };
const _sfc_main$4 = {
  __name: "prop-model",
  setup(__props) {
    const model = shallowRef(null);
    return (_ctx, _cache) => {
      const _component_v_date_input = resolveComponent("v-date-input");
      return openBlock(), createElementBlock("div", _hoisted_1$2, [
        createVNode(_component_v_date_input, {
          modelValue: model.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => model.value = $event),
          label: "Select a date",
          "max-width": "368"
        }, null, 8, ["modelValue"])
      ]);
    };
  }
};
const __1 = _sfc_main$4;
const __1_raw = `<template>
  <div class="d-flex justify-center">
    <v-date-input
      v-model="model"
      label="Select a date"
      max-width="368"
    ></v-date-input>
  </div>
</template>

<script setup>
  import { shallowRef } from 'vue'

  const model = shallowRef(null)
<\/script>

<script>
  export default {
    data: () => ({
      model: null,
    }),
  }
<\/script>
`;
const _hoisted_1$1 = { class: "d-flex justify-center" };
const _sfc_main$3 = {
  __name: "prop-multiple-range",
  setup(__props) {
    const model = shallowRef(null);
    return (_ctx, _cache) => {
      const _component_v_date_input = resolveComponent("v-date-input");
      return openBlock(), createElementBlock("div", _hoisted_1$1, [
        createVNode(_component_v_date_input, {
          modelValue: model.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => model.value = $event),
          label: "Select range",
          "max-width": "368",
          multiple: "range"
        }, null, 8, ["modelValue"])
      ]);
    };
  }
};
const __2 = _sfc_main$3;
const __2_raw = `<template>
  <div class="d-flex justify-center">
    <v-date-input
      v-model="model"
      label="Select range"
      max-width="368"
      multiple="range"
    ></v-date-input>
  </div>
</template>

<script setup>
  import { shallowRef } from 'vue'

  const model = shallowRef(null)
<\/script>

<script>
  export default {
    data: () => ({
      model: null,
    }),
  }
<\/script>
`;
const _hoisted_1 = { class: "d-flex justify-center" };
const _sfc_main$2 = {
  __name: "prop-multiple",
  setup(__props) {
    const model = shallowRef(null);
    return (_ctx, _cache) => {
      const _component_v_date_input = resolveComponent("v-date-input");
      return openBlock(), createElementBlock("div", _hoisted_1, [
        createVNode(_component_v_date_input, {
          modelValue: model.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => model.value = $event),
          label: "Select day(s)",
          "max-width": "368",
          multiple: ""
        }, null, 8, ["modelValue"])
      ]);
    };
  }
};
const __3 = _sfc_main$2;
const __3_raw = `<template>
  <div class="d-flex justify-center">
    <v-date-input
      v-model="model"
      label="Select day(s)"
      max-width="368"
      multiple
    ></v-date-input>
  </div>
</template>

<script setup>
  import { shallowRef } from 'vue'

  const model = shallowRef(null)
<\/script>

<script>
  export default {
    data: () => ({
      model: null,
    }),
  }
<\/script>
`;
const _sfc_main$1 = {};
function _sfc_render(_ctx, _cache) {
  const _component_v_date_input = resolveComponent("v-date-input");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  return openBlock(), createBlock(_component_v_row, { dense: "" }, {
    default: withCtx(() => [
      createVNode(_component_v_col, {
        cols: "12",
        md: "6"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_date_input, {
            label: "Select a date",
            "prepend-icon": "",
            "prepend-inner-icon": "$calendar",
            variant: "solo"
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_col, {
        cols: "12",
        md: "6"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_date_input, {
            label: "Select a date",
            "prepend-icon": "",
            variant: "solo"
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __4 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["render", _sfc_render]]);
const __4_raw = '<template>\n  <v-row dense>\n    <v-col cols="12" md="6">\n      <v-date-input\n        label="Select a date"\n        prepend-icon=""\n        prepend-inner-icon="$calendar"\n        variant="solo"\n      ></v-date-input>\n\n    </v-col>\n\n    <v-col cols="12" md="6">\n      <v-date-input\n        label="Select a date"\n        prepend-icon=""\n        variant="solo"\n      ></v-date-input>\n\n    </v-col>\n  </v-row>\n</template>\n';
const name = "v-date-input";
const _sfc_main = {
  __name: "usage",
  setup(__props) {
    const model = ref("default");
    const options = ["outlined", "underlined", "solo", "solo-filled", "solo-inverted"];
    const clear = ref(false);
    const counter = ref(false);
    const disabled = ref(false);
    const props = computed(() => {
      return {
        clearable: clear.value || void 0,
        counter: counter.value || void 0,
        disabled: disabled.value || void 0,
        label: "Date input",
        variant: model.value === "default" ? void 0 : model.value
      };
    });
    const slots = computed(() => {
      return ``;
    });
    const code = computed(() => {
      return `<${name}${propsToString(props.value)}>${slots.value}</${name}>`;
    });
    return (_ctx, _cache) => {
      const _component_v_date_input = resolveComponent("v-date-input");
      const _component_v_checkbox = resolveComponent("v-checkbox");
      const _component_ExamplesUsageExample = _sfc_main$6;
      return openBlock(), createBlock(_component_ExamplesUsageExample, {
        modelValue: unref(model),
        "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => isRef(model) ? model.value = $event : null),
        code: unref(code),
        name,
        options
      }, {
        configuration: withCtx(() => [
          createVNode(_component_v_checkbox, {
            modelValue: unref(clear),
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(clear) ? clear.value = $event : null),
            label: "Clearable"
          }, null, 8, ["modelValue"]),
          createVNode(_component_v_checkbox, {
            modelValue: unref(disabled),
            "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(disabled) ? disabled.value = $event : null),
            label: "Disabled"
          }, null, 8, ["modelValue"])
        ]),
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createVNode(_component_v_date_input, normalizeProps(guardReactiveProps(unref(props))), null, 16)
          ])
        ]),
        _: 1
      }, 8, ["modelValue", "code"]);
    };
  }
};
const __5 = _sfc_main;
const __5_raw = `<template>
  <ExamplesUsageExample
    v-model="model"
    :code="code"
    :name="name"
    :options="options"
  >
    <div>
      <v-date-input v-bind="props"></v-date-input>
    </div>

    <template v-slot:configuration>
      <v-checkbox v-model="clear" label="Clearable"></v-checkbox>

      <v-checkbox v-model="disabled" label="Disabled"></v-checkbox>
    </template>
  </ExamplesUsageExample>
</template>

<script setup>
  const name = 'v-date-input'
  const model = ref('default')
  const options = ['outlined', 'underlined', 'solo', 'solo-filled', 'solo-inverted']
  const clear = ref(false)
  const counter = ref(false)
  const disabled = ref(false)
  const props = computed(() => {
    return {
      clearable: clear.value || undefined,
      counter: counter.value || undefined,
      disabled: disabled.value || undefined,
      label: 'Date input',
      variant: model.value === 'default' ? undefined : model.value,
    }
  })

  const slots = computed(() => {
    return \`\`
  })

  const code = computed(() => {
    return \`<\${name}\${propsToString(props.value)}>\${slots.value}</\${name}>\`
  })
<\/script>
`;
const vDateInput = {
  "misc-passenger": {
    component: __0,
    source: __0_raw
  },
  "prop-model": {
    component: __1,
    source: __1_raw
  },
  "prop-multiple-range": {
    component: __2,
    source: __2_raw
  },
  "prop-multiple": {
    component: __3,
    source: __3_raw
  },
  "prop-prepend-icon": {
    component: __4,
    source: __4_raw
  },
  "usage": {
    component: __5,
    source: __5_raw
  }
};
export {
  vDateInput as default
};
