import { d as defineComponent, u as useHead, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, e as createBaseVNode, b as createVNode, h as createTextVNode } from "./index-DGybHjCP.js";
const _hoisted_1 = { id: "vdatepickeryears-api" };
const _hoisted_2 = { id: "props" };
const _hoisted_3 = { id: "events" };
const _hoisted_4 = { id: "slots" };
const frontmatter = { "meta": { "title": "VDatePickerYears API", "description": "API for the VDatePickerYears component.", "keywords": "VDatePickerYears, api, vuetify" } };
const excerpt = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "v-date-picker-years",
  setup(__props, { expose: __expose }) {
    const head = { "meta": { "title": "VDatePickerYears API", "description": "API for the VDatePickerYears component.", "keywords": "VDatePickerYears, api, vuetify" } };
    useHead(head);
    __expose({ frontmatter: { "meta": { "title": "VDatePickerYears API", "description": "API for the VDatePickerYears component.", "keywords": "VDatePickerYears, api, vuetify" } }, excerpt: void 0 });
    return (_ctx, _cache) => {
      const _component_app_heading = resolveComponent("app-heading");
      const _component_page_features = resolveComponent("page-features");
      const _component_promoted_entry = resolveComponent("promoted-entry");
      const _component_api_search = resolveComponent("api-search");
      const _component_api_section = resolveComponent("api-section");
      const _component_unwrap_markdown = resolveComponent("unwrap-markdown");
      return openBlock(), createBlock(_component_unwrap_markdown, { frontmatter }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createBaseVNode("section", _hoisted_1, [
              createVNode(_component_app_heading, {
                href: "#vdatepickeryears-api",
                level: "1"
              }, {
                default: withCtx(() => [
                  createTextVNode("VDatePickerYears API")
                ]),
                _: 1
              }),
              createVNode(_component_page_features),
              createVNode(_component_promoted_entry),
              createVNode(_component_api_search),
              createBaseVNode("section", _hoisted_2, [
                createVNode(_component_app_heading, {
                  href: "#props",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Props")
                  ]),
                  _: 1
                }),
                createVNode(_component_api_section, {
                  name: "VDatePickerYears",
                  section: "props"
                })
              ]),
              createBaseVNode("section", _hoisted_3, [
                createVNode(_component_app_heading, {
                  href: "#events",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Events")
                  ]),
                  _: 1
                }),
                createVNode(_component_api_section, {
                  name: "VDatePickerYears",
                  section: "events"
                })
              ]),
              createBaseVNode("section", _hoisted_4, [
                createVNode(_component_app_heading, {
                  href: "#slots",
                  level: "2"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Slots")
                  ]),
                  _: 1
                }),
                createVNode(_component_api_section, {
                  name: "VDatePickerYears",
                  section: "slots"
                })
              ])
            ])
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default,
  excerpt,
  frontmatter
};
