import { J as ref, r as resolveComponent, o as openBlock, l as createElementBlock, b as createVNode, w as withCtx, j as computed, ag as propsToString, c as createBlock, f as unref, E as isRef, e as createBaseVNode, h as createTextVNode } from "./index-DGybHjCP.js";
import { _ as _sfc_main$2 } from "./UsageExample-M8CmNipa.js";
const _sfc_main$1 = {
  __name: "prop-defaults",
  setup(__props) {
    const defaults = ref({
      global: {
        elevation: 10
      },
      VCard: {
        color: "secondary"
      }
    });
    return (_ctx, _cache) => {
      const _component_v_card = resolveComponent("v-card");
      const _component_v_defaults_provider = resolveComponent("v-defaults-provider");
      return openBlock(), createElementBlock("div", null, [
        createVNode(_component_v_card, {
          class: "ma-10",
          subtitle: "Subtitle",
          title: "Title"
        }),
        createVNode(_component_v_defaults_provider, { defaults: defaults.value }, {
          default: withCtx(() => [
            createVNode(_component_v_card, {
              class: "ma-10",
              subtitle: "Subtitle",
              title: "Title"
            })
          ]),
          _: 1
        }, 8, ["defaults"])
      ]);
    };
  }
};
const __0 = _sfc_main$1;
const __0_raw = `<template>
  <div>
    <v-card class="ma-10" subtitle="Subtitle" title="Title"></v-card>
    <v-defaults-provider :defaults="defaults">
      <v-card class="ma-10" subtitle="Subtitle" title="Title"></v-card>
    </v-defaults-provider>
  </div>
</template>

<script setup>
  import { ref } from 'vue'

  const defaults = ref({
    global: {
      elevation: 10,
    },
    VCard: {
      color: 'secondary',
    },
  })
<\/script>

<script>
  export default {
    data: () => ({
      defaults: {
        global: {
          elevation: 10,
        },
        VCard: {
          color: 'secondary',
        },
      },
    }),
  }
<\/script>
`;
const _hoisted_1 = { class: "text-center" };
const name = "v-defaults-provider";
const _sfc_main = {
  __name: "usage",
  setup(__props) {
    const model = ref("default");
    const button = ref(false);
    const options = [];
    const props = computed(() => {
      return {
        defaults: button.value ? {
          VBtn: {
            color: "primary",
            size: "large",
            variant: "tonal"
          }
        } : void 0
      };
    });
    const slots = computed(() => {
      return `
  <v-btn>Button</v-btn>
`;
    });
    const code = computed(() => {
      return `<${name}${propsToString(props.value)}>${slots.value}</${name}>`;
    });
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_defaults_provider = resolveComponent("v-defaults-provider");
      const _component_v_checkbox = resolveComponent("v-checkbox");
      const _component_ExamplesUsageExample = _sfc_main$2;
      return openBlock(), createBlock(_component_ExamplesUsageExample, {
        modelValue: unref(model),
        "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(model) ? model.value = $event : null),
        code: unref(code),
        name,
        options
      }, {
        configuration: withCtx(() => [
          createVNode(_component_v_checkbox, {
            modelValue: unref(button),
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(button) ? button.value = $event : null),
            label: "Use v-btn defaults"
          }, null, 8, ["modelValue"])
        ]),
        default: withCtx(() => [
          createBaseVNode("div", _hoisted_1, [
            createVNode(_component_v_defaults_provider, {
              defaults: {
                VBtn: !unref(button) ? {} : {
                  color: "primary",
                  size: "large",
                  variant: "tonal"
                }
              }
            }, {
              default: withCtx(() => [
                createVNode(_component_v_btn, null, {
                  default: withCtx(() => [
                    createTextVNode("Button")
                  ]),
                  _: 1
                })
              ]),
              _: 1
            }, 8, ["defaults"])
          ])
        ]),
        _: 1
      }, 8, ["modelValue", "code"]);
    };
  }
};
const __1 = _sfc_main;
const __1_raw = `<template>
  <ExamplesUsageExample
    v-model="model"
    :code="code"
    :name="name"
    :options="options"
  >
    <div class="text-center">
      <v-defaults-provider
        :defaults="{
          VBtn: !button ? {} : {
            color: 'primary',
            size: 'large',
            variant: 'tonal',
          },
        }"
      >
        <v-btn>Button</v-btn>
      </v-defaults-provider>
    </div>

    <template v-slot:configuration>
      <v-checkbox v-model="button" label="Use v-btn defaults"></v-checkbox>
    </template>
  </ExamplesUsageExample>
</template>

<script setup>
  const name = 'v-defaults-provider'
  const model = ref('default')
  const button = ref(false)
  const options = []
  const props = computed(() => {
    return {
      defaults: button.value ? {
        VBtn: {
          color: 'primary',
          size: 'large',
          variant: 'tonal',
        },
      } : undefined,
    }
  })

  const slots = computed(() => {
    return \`
  <v-btn>Button</v-btn>
\`
  })

  const code = computed(() => {
    return \`<\${name}\${propsToString(props.value)}>\${slots.value}</\${name}>\`
  })
<\/script>
`;
const vDefaultsProvider = {
  "prop-defaults": {
    component: __0,
    source: __0_raw
  },
  "usage": {
    component: __1,
    source: __1_raw
  }
};
export {
  vDefaultsProvider as default
};
