import { B as shallowRef, r as resolveComponent, o as openBlock, l as createElementBlock, b as createVNode, w as withCtx, a9 as mergeProps, e as createBaseVNode, y as _export_sfc, O as watch, h as createTextVNode, J as ref, c as createBlock, V as withModifiers, ak as normalizeProps, al as guardReactiveProps, j as computed, ag as propsToString, f as unref, E as isRef } from "./index-DGybHjCP.js";
import { _ as _sfc_main$e } from "./UsageExample-M8CmNipa.js";
const _hoisted_1$a = { class: "pa-4 text-center" };
const _hoisted_2$3 = /* @__PURE__ */ createBaseVNode("small", { class: "text-caption text-medium-emphasis" }, "*indicates required field", -1);
const _sfc_main$d = {
  __name: "misc-form",
  setup(__props) {
    const dialog = shallowRef(false);
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_text_field = resolveComponent("v-text-field");
      const _component_v_col = resolveComponent("v-col");
      const _component_v_select = resolveComponent("v-select");
      const _component_v_autocomplete = resolveComponent("v-autocomplete");
      const _component_v_row = resolveComponent("v-row");
      const _component_v_card_text = resolveComponent("v-card-text");
      const _component_v_divider = resolveComponent("v-divider");
      const _component_v_spacer = resolveComponent("v-spacer");
      const _component_v_card_actions = resolveComponent("v-card-actions");
      const _component_v_card = resolveComponent("v-card");
      const _component_v_dialog = resolveComponent("v-dialog");
      return openBlock(), createElementBlock("div", _hoisted_1$a, [
        createVNode(_component_v_dialog, {
          modelValue: dialog.value,
          "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => dialog.value = $event),
          "max-width": "600"
        }, {
          activator: withCtx(({ props: activatorProps }) => [
            createVNode(_component_v_btn, mergeProps({
              class: "text-none font-weight-regular",
              "prepend-icon": "mdi-account",
              text: "Edit Profile",
              variant: "tonal"
            }, activatorProps), null, 16)
          ]),
          default: withCtx(() => [
            createVNode(_component_v_card, {
              "prepend-icon": "mdi-account",
              title: "User Profile"
            }, {
              default: withCtx(() => [
                createVNode(_component_v_card_text, null, {
                  default: withCtx(() => [
                    createVNode(_component_v_row, { dense: "" }, {
                      default: withCtx(() => [
                        createVNode(_component_v_col, {
                          cols: "12",
                          md: "4",
                          sm: "6"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_v_text_field, {
                              label: "First name*",
                              required: ""
                            })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_v_col, {
                          cols: "12",
                          md: "4",
                          sm: "6"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_v_text_field, {
                              hint: "example of helper text only on focus",
                              label: "Middle name"
                            })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_v_col, {
                          cols: "12",
                          md: "4",
                          sm: "6"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_v_text_field, {
                              hint: "example of persistent helper text",
                              label: "Last name*",
                              "persistent-hint": "",
                              required: ""
                            })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_v_col, {
                          cols: "12",
                          md: "4",
                          sm: "6"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_v_text_field, {
                              label: "Email*",
                              required: ""
                            })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_v_col, {
                          cols: "12",
                          md: "4",
                          sm: "6"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_v_text_field, {
                              label: "Password*",
                              type: "password",
                              required: ""
                            })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_v_col, {
                          cols: "12",
                          md: "4",
                          sm: "6"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_v_text_field, {
                              label: "Confirm Password*",
                              type: "password",
                              required: ""
                            })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_v_col, {
                          cols: "12",
                          sm: "6"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_v_select, {
                              items: ["0-17", "18-29", "30-54", "54+"],
                              label: "Age*",
                              required: ""
                            })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_v_col, {
                          cols: "12",
                          sm: "6"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_v_autocomplete, {
                              items: ["Skiing", "Ice hockey", "Soccer", "Basketball", "Hockey", "Reading", "Writing", "Coding", "Basejump"],
                              label: "Interests",
                              "auto-select-first": "",
                              multiple: ""
                            })
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }),
                    _hoisted_2$3
                  ]),
                  _: 1
                }),
                createVNode(_component_v_divider),
                createVNode(_component_v_card_actions, null, {
                  default: withCtx(() => [
                    createVNode(_component_v_spacer),
                    createVNode(_component_v_btn, {
                      text: "Close",
                      variant: "plain",
                      onClick: _cache[0] || (_cache[0] = ($event) => dialog.value = false)
                    }),
                    createVNode(_component_v_btn, {
                      color: "primary",
                      text: "Save",
                      variant: "tonal",
                      onClick: _cache[1] || (_cache[1] = ($event) => dialog.value = false)
                    })
                  ]),
                  _: 1
                })
              ]),
              _: 1
            })
          ]),
          _: 1
        }, 8, ["modelValue"])
      ]);
    };
  }
};
const __0 = _sfc_main$d;
const __0_raw = `<template>
  <div class="pa-4 text-center">
    <v-dialog
      v-model="dialog"
      max-width="600"
    >
      <template v-slot:activator="{ props: activatorProps }">
        <v-btn
          class="text-none font-weight-regular"
          prepend-icon="mdi-account"
          text="Edit Profile"
          variant="tonal"
          v-bind="activatorProps"
        ></v-btn>
      </template>

      <v-card
        prepend-icon="mdi-account"
        title="User Profile"
      >
        <v-card-text>
          <v-row dense>
            <v-col
              cols="12"
              md="4"
              sm="6"
            >
              <v-text-field
                label="First name*"
                required
              ></v-text-field>
            </v-col>

            <v-col
              cols="12"
              md="4"
              sm="6"
            >
              <v-text-field
                hint="example of helper text only on focus"
                label="Middle name"
              ></v-text-field>
            </v-col>

            <v-col
              cols="12"
              md="4"
              sm="6"
            >
              <v-text-field
                hint="example of persistent helper text"
                label="Last name*"
                persistent-hint
                required
              ></v-text-field>
            </v-col>

            <v-col
              cols="12"
              md="4"
              sm="6"
            >
              <v-text-field
                label="Email*"
                required
              ></v-text-field>
            </v-col>

            <v-col
              cols="12"
              md="4"
              sm="6"
            >
              <v-text-field
                label="Password*"
                type="password"
                required
              ></v-text-field>
            </v-col>

            <v-col
              cols="12"
              md="4"
              sm="6"
            >
              <v-text-field
                label="Confirm Password*"
                type="password"
                required
              ></v-text-field>
            </v-col>

            <v-col
              cols="12"
              sm="6"
            >
              <v-select
                :items="['0-17', '18-29', '30-54', '54+']"
                label="Age*"
                required
              ></v-select>
            </v-col>

            <v-col
              cols="12"
              sm="6"
            >
              <v-autocomplete
                :items="['Skiing', 'Ice hockey', 'Soccer', 'Basketball', 'Hockey', 'Reading', 'Writing', 'Coding', 'Basejump']"
                label="Interests"
                auto-select-first
                multiple
              ></v-autocomplete>
            </v-col>
          </v-row>

          <small class="text-caption text-medium-emphasis">*indicates required field</small>
        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          <v-spacer></v-spacer>

          <v-btn
            text="Close"
            variant="plain"
            @click="dialog = false"
          ></v-btn>

          <v-btn
            color="primary"
            text="Save"
            variant="tonal"
            @click="dialog = false"
          ></v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </div>
</template>

<script setup>
  import { shallowRef } from 'vue'

  const dialog = shallowRef(false)
<\/script>

<script>
  export default {
    data: () => ({
      dialog: false,
    }),
  }
<\/script>
`;
const _sfc_main$c = {};
const _hoisted_1$9 = { class: "pa-4 text-center" };
const _hoisted_2$2 = /* @__PURE__ */ createBaseVNode("div", { class: "text-none font-weight-regular" }, " Share ", -1);
const _hoisted_3$1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-h5 text-medium-emphasis ps-2" }, " Invite John to connect ", -1);
const _hoisted_4$1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-medium-emphasis mb-4" }, " Invite collaborators to your network and grow your connections. ", -1);
const _hoisted_5$1 = /* @__PURE__ */ createBaseVNode("div", { class: "mb-2" }, "Message (optional)", -1);
const _hoisted_6$1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-overline mb-2" }, "💎 PREMIUM", -1);
const _hoisted_7$1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-medium-emphasis mb-1" }, " Share with unlimited people and get more insights about your network. Try Premium Free for 30 days. ", -1);
const _hoisted_8$1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, " Shared with John + 1 more ", -1);
function _sfc_render$2(_ctx, _cache) {
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_card_title = resolveComponent("v-card-title");
  const _component_v_divider = resolveComponent("v-divider");
  const _component_v_textarea = resolveComponent("v-textarea");
  const _component_v_card_text = resolveComponent("v-card-text");
  const _component_v_card_actions = resolveComponent("v-card-actions");
  const _component_v_card = resolveComponent("v-card");
  const _component_v_dialog = resolveComponent("v-dialog");
  const _component_v_icon = resolveComponent("v-icon");
  const _component_v_list_item = resolveComponent("v-list-item");
  const _component_v_list = resolveComponent("v-list");
  const _component_v_menu = resolveComponent("v-menu");
  const _component_v_btn_group = resolveComponent("v-btn-group");
  return openBlock(), createElementBlock("div", _hoisted_1$9, [
    createVNode(_component_v_btn_group, {
      color: "#b2d7ef",
      density: "comfortable",
      rounded: "pill",
      divided: ""
    }, {
      default: withCtx(() => [
        createVNode(_component_v_btn, {
          class: "pe-2",
          "prepend-icon": "mdi-account-multiple-outline",
          variant: "flat"
        }, {
          default: withCtx(() => [
            _hoisted_2$2,
            createVNode(_component_v_dialog, {
              activator: "parent",
              "max-width": "500"
            }, {
              default: withCtx(({ isActive }) => [
                createVNode(_component_v_card, { rounded: "lg" }, {
                  default: withCtx(() => [
                    createVNode(_component_v_card_title, { class: "d-flex justify-space-between align-center" }, {
                      default: withCtx(() => [
                        _hoisted_3$1,
                        createVNode(_component_v_btn, {
                          icon: "mdi-close",
                          variant: "text",
                          onClick: ($event) => isActive.value = false
                        }, null, 8, ["onClick"])
                      ]),
                      _: 2
                    }, 1024),
                    createVNode(_component_v_divider, { class: "mb-4" }),
                    createVNode(_component_v_card_text, null, {
                      default: withCtx(() => [
                        _hoisted_4$1,
                        _hoisted_5$1,
                        createVNode(_component_v_textarea, {
                          counter: 300,
                          class: "mb-2",
                          rows: "2",
                          variant: "outlined",
                          "persistent-counter": ""
                        }),
                        _hoisted_6$1,
                        _hoisted_7$1,
                        createVNode(_component_v_btn, {
                          class: "text-none font-weight-bold ms-n4",
                          color: "primary",
                          text: "Retry Premium Free",
                          variant: "text"
                        })
                      ]),
                      _: 1
                    }),
                    createVNode(_component_v_divider, { class: "mt-2" }),
                    createVNode(_component_v_card_actions, { class: "my-2 d-flex justify-end" }, {
                      default: withCtx(() => [
                        createVNode(_component_v_btn, {
                          class: "text-none",
                          rounded: "xl",
                          text: "Cancel",
                          onClick: ($event) => isActive.value = false
                        }, null, 8, ["onClick"]),
                        createVNode(_component_v_btn, {
                          class: "text-none",
                          color: "primary",
                          rounded: "xl",
                          text: "Send",
                          variant: "flat",
                          onClick: ($event) => isActive.value = false
                        }, null, 8, ["onClick"])
                      ]),
                      _: 2
                    }, 1024)
                  ]),
                  _: 2
                }, 1024)
              ]),
              _: 1
            })
          ]),
          _: 1
        }),
        createVNode(_component_v_btn, {
          size: "small",
          icon: ""
        }, {
          default: withCtx(() => [
            createVNode(_component_v_icon, { icon: "mdi-menu-down" }),
            createVNode(_component_v_menu, {
              activator: "parent",
              location: "bottom end",
              transition: "fade-transition"
            }, {
              default: withCtx(() => [
                createVNode(_component_v_list, {
                  density: "compact",
                  "min-width": "250",
                  rounded: "lg",
                  slim: ""
                }, {
                  default: withCtx(() => [
                    createVNode(_component_v_list_item, {
                      "prepend-icon": "mdi-link",
                      title: "Copy link",
                      link: ""
                    }),
                    createVNode(_component_v_divider, { class: "my-2" }),
                    createVNode(_component_v_list_item, { "min-height": "24" }, {
                      subtitle: withCtx(() => [
                        _hoisted_8$1
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                })
              ]),
              _: 1
            })
          ]),
          _: 1
        })
      ]),
      _: 1
    })
  ]);
}
const __1 = /* @__PURE__ */ _export_sfc(_sfc_main$c, [["render", _sfc_render$2]]);
const __1_raw = '<template>\n  <div class="pa-4 text-center">\n    <v-btn-group\n      color="#b2d7ef"\n      density="comfortable"\n      rounded="pill"\n      divided\n    >\n      <v-btn\n        class="pe-2"\n        prepend-icon="mdi-account-multiple-outline"\n        variant="flat"\n      >\n        <div class="text-none font-weight-regular">\n          Share\n        </div>\n\n        <v-dialog activator="parent" max-width="500">\n          <template v-slot:default="{ isActive }">\n            <v-card rounded="lg">\n              <v-card-title class="d-flex justify-space-between align-center">\n                <div class="text-h5 text-medium-emphasis ps-2">\n                  Invite John to connect\n                </div>\n\n                <v-btn\n                  icon="mdi-close"\n                  variant="text"\n                  @click="isActive.value = false"\n                ></v-btn>\n              </v-card-title>\n\n              <v-divider class="mb-4"></v-divider>\n\n              <v-card-text>\n                <div class="text-medium-emphasis mb-4">\n                  Invite collaborators to your network and grow your connections.\n                </div>\n\n                <div class="mb-2">Message (optional)</div>\n\n                <v-textarea\n                  :counter="300"\n                  class="mb-2"\n                  rows="2"\n                  variant="outlined"\n                  persistent-counter\n                ></v-textarea>\n\n                <div class="text-overline mb-2">💎 PREMIUM</div>\n\n                <div class="text-medium-emphasis mb-1">\n                  Share with unlimited people and get more insights about your network. Try Premium Free for 30 days.\n                </div>\n\n                <v-btn\n                  class="text-none font-weight-bold ms-n4"\n                  color="primary"\n                  text="Retry Premium Free"\n                  variant="text"\n                ></v-btn>\n              </v-card-text>\n\n              <v-divider class="mt-2"></v-divider>\n\n              <v-card-actions class="my-2 d-flex justify-end">\n                <v-btn\n                  class="text-none"\n                  rounded="xl"\n                  text="Cancel"\n                  @click="isActive.value = false"\n                ></v-btn>\n\n                <v-btn\n                  class="text-none"\n                  color="primary"\n                  rounded="xl"\n                  text="Send"\n                  variant="flat"\n                  @click="isActive.value = false"\n                ></v-btn>\n              </v-card-actions>\n            </v-card>\n          </template>\n        </v-dialog>\n      </v-btn>\n\n      <v-btn\n        size="small"\n        icon\n      >\n        <v-icon icon="mdi-menu-down"></v-icon>\n\n        <v-menu\n          activator="parent"\n          location="bottom end"\n          transition="fade-transition"\n        >\n          <v-list\n            density="compact"\n            min-width="250"\n            rounded="lg"\n            slim\n          >\n            <v-list-item\n              prepend-icon="mdi-link"\n              title="Copy link"\n              link\n            ></v-list-item>\n\n            <v-divider class="my-2"></v-divider>\n\n            <v-list-item min-height="24">\n              <template v-slot:subtitle>\n                <div class="text-caption">\n                  Shared with John + 1 more\n                </div>\n              </template>\n            </v-list-item>\n          </v-list>\n        </v-menu>\n      </v-btn>\n    </v-btn-group>\n  </div>\n</template>\n';
const _hoisted_1$8 = { class: "pa-4 text-center" };
const _hoisted_2$1 = { class: "pe-4" };
const _sfc_main$b = {
  __name: "misc-loader",
  setup(__props) {
    const dialog = shallowRef(false);
    watch(dialog, (val) => {
      if (!val)
        return;
      setTimeout(() => dialog.value = false, 4e3);
    });
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_icon = resolveComponent("v-icon");
      const _component_v_progress_circular = resolveComponent("v-progress-circular");
      const _component_v_list_item = resolveComponent("v-list-item");
      const _component_v_list = resolveComponent("v-list");
      const _component_v_dialog = resolveComponent("v-dialog");
      return openBlock(), createElementBlock("div", _hoisted_1$8, [
        createVNode(_component_v_btn, {
          disabled: dialog.value,
          color: "primary",
          icon: "mdi-refresh",
          text: "Start loading",
          onClick: _cache[0] || (_cache[0] = ($event) => dialog.value = true)
        }, null, 8, ["disabled"]),
        createVNode(_component_v_dialog, {
          modelValue: dialog.value,
          "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => dialog.value = $event),
          "max-width": "320",
          persistent: ""
        }, {
          default: withCtx(() => [
            createVNode(_component_v_list, {
              class: "py-2",
              color: "primary",
              elevation: "12",
              rounded: "lg"
            }, {
              default: withCtx(() => [
                createVNode(_component_v_list_item, {
                  "prepend-icon": "$vuetify-outline",
                  title: "Refreshing Application..."
                }, {
                  prepend: withCtx(() => [
                    createBaseVNode("div", _hoisted_2$1, [
                      createVNode(_component_v_icon, {
                        color: "primary",
                        size: "x-large"
                      })
                    ])
                  ]),
                  append: withCtx(() => [
                    createVNode(_component_v_progress_circular, {
                      color: "primary",
                      indeterminate: "disable-shrink",
                      size: "16",
                      width: "2"
                    })
                  ]),
                  _: 1
                })
              ]),
              _: 1
            })
          ]),
          _: 1
        }, 8, ["modelValue"])
      ]);
    };
  }
};
const __2 = _sfc_main$b;
const __2_raw = `<template>
  <div class="pa-4 text-center">
    <v-btn
      :disabled="dialog"
      color="primary"
      icon="mdi-refresh"
      text="Start loading"
      @click="dialog = true"
    ></v-btn>

    <v-dialog
      v-model="dialog"
      max-width="320"
      persistent
    >
      <v-list
        class="py-2"
        color="primary"
        elevation="12"
        rounded="lg"
      >
        <v-list-item
          prepend-icon="$vuetify-outline"
          title="Refreshing Application..."
        >
          <template v-slot:prepend>
            <div class="pe-4">
              <v-icon color="primary" size="x-large"></v-icon>
            </div>
          </template>

          <template v-slot:append>
            <v-progress-circular
              color="primary"
              indeterminate="disable-shrink"
              size="16"
              width="2"
            ></v-progress-circular>
          </template>
        </v-list-item>
      </v-list>
    </v-dialog>
  </div>
</template>

<script setup>
  import { shallowRef, watch } from 'vue'

  const dialog = shallowRef(false)
  watch(dialog, val => {
    if (!val) return
    setTimeout(() => (dialog.value = false), 4000)
  })
<\/script>

<script>
  export default {
    data () {
      return {
        dialog: false,
      }
    },

    watch: {
      dialog (val) {
        if (!val) return

        setTimeout(() => (this.dialog = false), 4000)
      },
    },
  }
<\/script>
`;
const _hoisted_1$7 = { class: "pa-4 text-center" };
const _sfc_main$a = {
  __name: "misc-nesting",
  setup(__props) {
    const dialog = shallowRef(false);
    const dialog2 = shallowRef(false);
    const dialog3 = shallowRef(false);
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_spacer = resolveComponent("v-spacer");
      const _component_v_card_actions = resolveComponent("v-card-actions");
      const _component_v_card = resolveComponent("v-card");
      const _component_v_dialog = resolveComponent("v-dialog");
      return openBlock(), createElementBlock("div", _hoisted_1$7, [
        createVNode(_component_v_btn, {
          text: "Open Dialog 1",
          onClick: _cache[0] || (_cache[0] = ($event) => dialog.value = true)
        }),
        createVNode(_component_v_dialog, {
          modelValue: dialog.value,
          "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => dialog.value = $event),
          "max-width": "480"
        }, {
          default: withCtx(() => [
            createVNode(_component_v_card, { title: "Dialog 1" }, {
              text: withCtx(() => [
                createVNode(_component_v_btn, {
                  class: "my-2",
                  text: "Open Dialog 2",
                  onClick: _cache[1] || (_cache[1] = ($event) => dialog2.value = true)
                })
              ]),
              default: withCtx(() => [
                createVNode(_component_v_card_actions, null, {
                  default: withCtx(() => [
                    createVNode(_component_v_spacer),
                    createVNode(_component_v_btn, {
                      text: "Close",
                      variant: "text",
                      onClick: _cache[2] || (_cache[2] = ($event) => dialog.value = false)
                    })
                  ]),
                  _: 1
                })
              ]),
              _: 1
            })
          ]),
          _: 1
        }, 8, ["modelValue"]),
        createVNode(_component_v_dialog, {
          modelValue: dialog2.value,
          "onUpdate:modelValue": _cache[6] || (_cache[6] = ($event) => dialog2.value = $event),
          "max-width": "240"
        }, {
          default: withCtx(() => [
            createVNode(_component_v_card, { title: "Dialog 2" }, {
              text: withCtx(() => [
                createVNode(_component_v_btn, {
                  class: "my-2",
                  text: "Open Dialog 3",
                  onClick: _cache[4] || (_cache[4] = ($event) => dialog3.value = !dialog3.value)
                })
              ]),
              default: withCtx(() => [
                createVNode(_component_v_card_actions, null, {
                  default: withCtx(() => [
                    createVNode(_component_v_spacer),
                    createVNode(_component_v_btn, {
                      text: "Close",
                      variant: "text",
                      onClick: _cache[5] || (_cache[5] = ($event) => dialog2.value = false)
                    })
                  ]),
                  _: 1
                })
              ]),
              _: 1
            })
          ]),
          _: 1
        }, 8, ["modelValue"]),
        createVNode(_component_v_dialog, {
          modelValue: dialog3.value,
          "onUpdate:modelValue": _cache[8] || (_cache[8] = ($event) => dialog3.value = $event),
          width: "auto"
        }, {
          default: withCtx(() => [
            createVNode(_component_v_card, { title: "Dialog 3" }, {
              default: withCtx(() => [
                createVNode(_component_v_card_actions, null, {
                  default: withCtx(() => [
                    createVNode(_component_v_spacer),
                    createVNode(_component_v_btn, {
                      text: "Close",
                      variant: "text",
                      onClick: _cache[7] || (_cache[7] = ($event) => dialog3.value = false)
                    })
                  ]),
                  _: 1
                })
              ]),
              _: 1
            })
          ]),
          _: 1
        }, 8, ["modelValue"])
      ]);
    };
  }
};
const __3 = _sfc_main$a;
const __3_raw = `<template>
  <div class="pa-4 text-center">
    <v-btn
      text="Open Dialog 1"
      @click="dialog = true"
    ></v-btn>

    <v-dialog
      v-model="dialog"
      max-width="480"
    >
      <v-card title="Dialog 1">
        <template v-slot:text>
          <v-btn
            class="my-2"
            text="Open Dialog 2"
            @click="dialog2 = true"
          ></v-btn>
        </template>

        <v-card-actions>
          <v-spacer></v-spacer>

          <v-btn
            text="Close"
            variant="text"
            @click="dialog = false"
          ></v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-dialog
      v-model="dialog2"
      max-width="240"
    >
      <v-card title="Dialog 2">
        <template v-slot:text>
          <v-btn
            class="my-2"
            text="Open Dialog 3"
            @click="dialog3 = !dialog3"
          ></v-btn>
        </template>

        <v-card-actions>
          <v-spacer></v-spacer>

          <v-btn
            text="Close"
            variant="text"
            @click="dialog2 = false"
          ></v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-dialog
      v-model="dialog3"
      width="auto"
    >
      <v-card title="Dialog 3">
        <v-card-actions>
          <v-spacer></v-spacer>

          <v-btn
            text="Close"
            variant="text"
            @click="dialog3 = false"
          ></v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </div>
</template>

<script setup>
  import { shallowRef } from 'vue'

  const dialog = shallowRef(false)
  const dialog2 = shallowRef(false)
  const dialog3 = shallowRef(false)
<\/script>

<script>
  export default {
    data () {
      return {
        dialog: false,
        dialog2: false,
        dialog3: false,
      }
    },
  }
<\/script>
`;
const _sfc_main$9 = {};
const _hoisted_1$6 = { class: "pa-4 text-center" };
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_7 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_8 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_9 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
function _sfc_render$1(_ctx, _cache) {
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_spacer = resolveComponent("v-spacer");
  const _component_v_card_actions = resolveComponent("v-card-actions");
  const _component_v_card = resolveComponent("v-card");
  const _component_v_dialog = resolveComponent("v-dialog");
  return openBlock(), createElementBlock("div", _hoisted_1$6, [
    createVNode(_component_v_dialog, { "max-width": "800" }, {
      activator: withCtx(({ props: activatorProps }) => [
        createVNode(_component_v_btn, mergeProps(activatorProps, { text: "Open Dialog" }), null, 16)
      ]),
      default: withCtx(({ isActive }) => [
        createVNode(_component_v_card, { title: "Use Google's location service?" }, {
          text: withCtx(() => [
            createTextVNode(" Lorem ipsum dolor sit amet, semper quis, sapien id natoque elit. Nostra urna at, magna at neque sed sed ante imperdiet, dolor mauris cursus velit, velit non, sem nec. Volutpat sem ridiculus placerat leo, augue in, duis erat proin condimentum in a eget, sed fermentum sed vestibulum varius ac, vestibulum volutpat orci ut elit eget tortor. Ultrices nascetur nulla gravida ante arcu. Pharetra rhoncus morbi ipsum, nunc tempor debitis, ipsum pellentesque, vitae id quam ut mauris dui tempor, aptent non. Quisque turpis. Phasellus quis lectus luctus orci eget rhoncus. Amet donec vestibulum mattis commodo, nulla aliquet, nibh praesent, elementum nulla. Sit lacus pharetra tempus magna neque pellentesque, nulla vel erat. "),
            _hoisted_2,
            createTextVNode(" Justo ex quisque nulla accusamus venenatis, sed quis. Nibh phasellus gravida metus in, fusce aenean ut erat commodo eros. Ut turpis, dui integer, nonummy pede placeat nec in sit leo. Faucibus porttitor illo taciti odio, amet viverra scelerisque quis quis et tortor, curabitur morbi a. Enim tempor at, rutrum elit condimentum, amet rutrum vitae tempor torquent nunc. Praesent vestibulum integer maxime felis. Neque aenean quia vitae nostra, tempus elit enim id dui, at egestas pulvinar. Integer libero vestibulum, quis blandit scelerisque mattis fermentum nulla, tortor donec vestibulum dolor amet eget, elit nullam. Aliquam leo phasellus aliquam curabitur metus a, nulla justo mattis duis interdum vel, mollis vitae et id, vestibulum erat ridiculus sit pulvinar justo sed. Vehicula convallis, et nulla wisi, amet vestibulum risus, quam ac egestas. "),
            _hoisted_3,
            createTextVNode(" Et vitae, nulla gravida erat scelerisque nullam nunc pellentesque, a dictumst cras augue, purus imperdiet non. Varius montes cursus varius vel tortor, nec leo a qui, magni cras, velit vel consectetuer lobortis vel. Nibh erat et wisi felis leo porttitor, sapien nibh sapien pede mi, sed eget porttitor, repellendus arcu ac quis. Luctus vulputate aut est sem magna, placerat accumsan nunc vestibulum ipsum ac auctor, maecenas lorem in ut nec mauris tortor, doloribus varius sem tortor vestibulum mollis, eleifend tortor felis tempus lacus eu eu. Eleifend vel eu, nullam maecenas mauris nec nunc euismod, tortor porta ridiculus potenti, massa tristique nam magna, et wisi placerat et erat ante. Eget pede erat in facilisis, fermentum venenatis sodales. Ac tortor sociis et non animi tristique, rhoncus malesuada, ut arcu volutpat scelerisque sollicitudin, elit curabitur dui pede purus dolor, integer aenean risus taciti nulla eleifend accumsan. At pulvinar diam parturient, interdum mi velit aliquet et a. Arcu at ac placerat eget justo semper, purus sociis curabitur mi ipsum consequat ut, mollis vestibulum, est ante ornare lacus sem. Neque magna mauris, commodo quisque, praesent semper suscipit lobortis nam. Justo malesuada cursus ac nunc litora nunc. Tellus ac, in lobortis nunc, montes lectus purus fermentum. "),
            _hoisted_4,
            createTextVNode(" Ac sit wisi. Sodales aliquam, sed vestibulum nullam arcu sit risus arcu, id luctus vitae lorem nibh, integer nec nullam class cursus mi, purus arcu lectus. Vel ante suscipit volutpat potenti mattis sed, wisi eu placerat aliquam erat, lectus morbi lobortis at assumenda. Consequat neque purus ipsum voluptas odio, netus vestibulum ut nec, suspendisse pellentesque nec enim in. Wisi dictum sed semper a, ipsum erat tellus habitasse est, erat sem ornare, vitae quisque ultricies. Dui sed blandit. Tempor et faucibus justo sed luctus, nec vitae vitae. Nunc nibh pede, ipsum vestibulum aenean leo ante ultricies, nam cras quis sed penatibus amet. In mauris a. Integer metus mauris tortor, et rutrum vestibulum ultricies, ut phasellus in ullamcorper ut mollit, eu justo. Cursus pretium venenatis. Cras pellentesque vel sodales accumsan aenean. Feugiat metus sit nec in aliquet amet, porttitor pretium vulputate massa. Consequat ipsum luctus quisque adipiscing libero. Wisi sollicitudin. Eget vitae ac lobortis, lorem natoque vestibulum et, aliquet faucibus at morbi nibh, vel condimentum. Massa unde orci sed id sed, odio donec congue nec praesent amet. Hymenaeos velit lacus, quis vivamus libero tempus duis, eu nisi eu, ipsum at accumsan pede justo morbi donec, massa et libero sit risus neque tortor. Ut sed sed etiam hendrerit dapibus, quis metus suspendisse nibh. "),
            _hoisted_5,
            createTextVNode(" Fringilla tempor felis augue magna. Cum arcu a, id vitae. Pellentesque pharetra in cras sociis adipiscing est. Nibh nec mattis at maecenas, nisl orci aliquam nulla justo egestas venenatis, elementum duis vel porta eros, massa vitae, eligendi imperdiet amet. Nec neque luctus suscipit, justo sem praesent, ut nisl quisque, volutpat torquent wisi tellus aliquam reprehenderit, curabitur cras at quis massa porttitor mauris. Eros sed ultrices. Amet dignissim justo urna feugiat mauris litora, etiam accumsan, lobortis a orci suspendisse. Semper ac mauris, varius bibendum pretium, orci urna nunc ullamcorper auctor, saepe sem integer quam, at feugiat egestas duis. Urna ligula ante. Leo elementum nonummy. Sagittis mauris est in ipsum, nulla amet non justo, proin id potenti platea posuere sit ut, nunc sit erat bibendum. Nibh id auctor, ab nulla vivamus ultrices, posuere morbi nunc tellus gravida vivamus. "),
            _hoisted_6,
            createTextVNode(" Mauris nec, facilisi quam fermentum, ut mauris integer, orci tellus tempus diam ut in pellentesque. Wisi faucibus tempor et odio leo diam, eleifend quis integer curabitur sit scelerisque ac, mauris consequat luctus quam penatibus fringilla dis, vitae lacus in, est eu ac tempus. Consectetuer amet ipsum amet dui, sed blandit id sed. Tellus integer, dignissim id pede sodales quis, felis dolorem id mauris orci, orci tempus ut. Nullam hymenaeos. Curabitur in a, tortor ut praesent placerat tincidunt interdum, ac dignissim metus nonummy hendrerit wisi, etiam ut. "),
            _hoisted_7,
            createTextVNode(" Semper praesent integer fusce, tortor suspendisse, augue ligula orci ante asperiores ullamcorper. In sit per mi sed sed, mi vestibulum mus nam, morbi mauris neque vitae aliquam proin senectus. Ac amet arcu mollis ante congue elementum, inceptos eget optio quam pellentesque quis lobortis, sollicitudin sed vestibulum sollicitudin, lectus parturient nullam, leo orci ligula ultrices. At tincidunt enim, suspendisse est sit sem ac. Amet tellus molestie est purus magna augue, non etiam et in wisi id. Non commodo, metus lorem facilisi lobortis ac velit, montes neque sed risus consectetuer fringilla dolor. Quam justo et integer aliquam, cursus nulla enim orci, nam cursus adipiscing, integer torquent non, fringilla per maecenas. Libero ipsum sed tellus purus et. Duis molestie placerat erat donec ut. Dolor enim erat massa faucibus ultrices in, ante ultricies orci lacus, libero consectetuer mauris magna feugiat neque dapibus, donec pretium et. Aptent dui, aliquam et et amet nostra ligula. "),
            _hoisted_8,
            createTextVNode(" Augue curabitur duis dui volutpat, tempus sed ut pede donec. Interdum luctus, lectus nulla aenean elit, id sit magna, vulputate ultrices pellentesque vel id fermentum morbi. Tortor et. Adipiscing augue lorem cum non lacus, rutrum sodales laoreet duis tortor, modi placerat facilisis et malesuada eros ipsum, vehicula tempus. Ac vivamus amet non aliquam venenatis lectus, sociosqu adipiscing consequat nec arcu odio. Blandit orci nec nec, posuere in pretium, enim ut, consectetuer nullam urna, risus vel. Nullam odio vehicula massa sed, etiam sociis mauris, lacus ullamcorper, libero imperdiet non sodales placerat justo vehicula. Nec morbi imperdiet. Fermentum sem libero iaculis bibendum et eros, eget maecenas non nunc, ad pellentesque. Ut nec diam elementum interdum. Elementum vitae tellus lacus vitae, ipsum phasellus, corporis vehicula in ac sed massa vivamus, rutrum elit, ultricies metus volutpat. "),
            _hoisted_9,
            createTextVNode(" Semper wisi et, sollicitudin nunc vestibulum, cursus accumsan nunc pede tempus mi ipsum, ligula sed. Non condimentum ac dolor sit. Mollis eu aliquam, vel mattis mollis massa ut dolor ante, tempus lacinia arcu. Urna vestibulum lorem, nulla fermentum, iaculis ut congue ac vivamus. Nam libero orci, pulvinar nulla, enim pellentesque consectetuer leo, feugiat rhoncus rhoncus vel. Magna sociosqu donec, dictum cursus ullamcorper viverra. Ultricies quis orci lorem, suspendisse ut vestibulum integer, purus sed lorem pulvinar habitasse turpis. ")
          ]),
          default: withCtx(() => [
            createVNode(_component_v_card_actions, null, {
              default: withCtx(() => [
                createVNode(_component_v_spacer),
                createVNode(_component_v_btn, {
                  text: "Disagree",
                  variant: "text",
                  onClick: ($event) => isActive.value = false
                }, null, 8, ["onClick"]),
                createVNode(_component_v_btn, {
                  color: "surface-variant",
                  text: "Agree",
                  variant: "flat",
                  onClick: ($event) => isActive.value = false
                }, null, 8, ["onClick"])
              ]),
              _: 2
            }, 1024)
          ]),
          _: 2
        }, 1024)
      ]),
      _: 1
    })
  ]);
}
const __4 = /* @__PURE__ */ _export_sfc(_sfc_main$9, [["render", _sfc_render$1]]);
const __4_raw = `<template>
  <div class="pa-4 text-center">
    <v-dialog max-width="800">
      <template v-slot:activator="{ props: activatorProps }">
        <v-btn
          v-bind="activatorProps"
          text="Open Dialog"
        ></v-btn>
      </template>

      <template v-slot:default="{ isActive }">
        <v-card title="Use Google's location service?">
          <template v-slot:text>
            Lorem ipsum dolor sit amet, semper quis, sapien id natoque elit. Nostra urna at, magna at neque sed sed ante imperdiet, dolor mauris cursus velit, velit non, sem nec. Volutpat sem ridiculus placerat leo, augue in, duis erat proin condimentum in a eget, sed fermentum sed vestibulum varius ac, vestibulum volutpat orci ut elit eget tortor. Ultrices nascetur nulla gravida ante arcu. Pharetra rhoncus morbi ipsum, nunc tempor debitis, ipsum pellentesque, vitae id quam ut mauris dui tempor, aptent non. Quisque turpis. Phasellus quis lectus luctus orci eget rhoncus. Amet donec vestibulum mattis commodo, nulla aliquet, nibh praesent, elementum nulla. Sit lacus pharetra tempus magna neque pellentesque, nulla vel erat.

            <br>

            Justo ex quisque nulla accusamus venenatis, sed quis. Nibh phasellus gravida metus in, fusce aenean ut erat commodo eros. Ut turpis, dui integer, nonummy pede placeat nec in sit leo. Faucibus porttitor illo taciti odio, amet viverra scelerisque quis quis et tortor, curabitur morbi a. Enim tempor at, rutrum elit condimentum, amet rutrum vitae tempor torquent nunc. Praesent vestibulum integer maxime felis. Neque aenean quia vitae nostra, tempus elit enim id dui, at egestas pulvinar. Integer libero vestibulum, quis blandit scelerisque mattis fermentum nulla, tortor donec vestibulum dolor amet eget, elit nullam. Aliquam leo phasellus aliquam curabitur metus a, nulla justo mattis duis interdum vel, mollis vitae et id, vestibulum erat ridiculus sit pulvinar justo sed. Vehicula convallis, et nulla wisi, amet vestibulum risus, quam ac egestas.

            <br>

            Et vitae, nulla gravida erat scelerisque nullam nunc pellentesque, a dictumst cras augue, purus imperdiet non. Varius montes cursus varius vel tortor, nec leo a qui, magni cras, velit vel consectetuer lobortis vel. Nibh erat et wisi felis leo porttitor, sapien nibh sapien pede mi, sed eget porttitor, repellendus arcu ac quis. Luctus vulputate aut est sem magna, placerat accumsan nunc vestibulum ipsum ac auctor, maecenas lorem in ut nec mauris tortor, doloribus varius sem tortor vestibulum mollis, eleifend tortor felis tempus lacus eu eu. Eleifend vel eu, nullam maecenas mauris nec nunc euismod, tortor porta ridiculus potenti, massa tristique nam magna, et wisi placerat et erat ante. Eget pede erat in facilisis, fermentum venenatis sodales. Ac tortor sociis et non animi tristique, rhoncus malesuada, ut arcu volutpat scelerisque sollicitudin, elit curabitur dui pede purus dolor, integer aenean risus taciti nulla eleifend accumsan. At pulvinar diam parturient, interdum mi velit aliquet et a. Arcu at ac placerat eget justo semper, purus sociis curabitur mi ipsum consequat ut, mollis vestibulum, est ante ornare lacus sem. Neque magna mauris, commodo quisque, praesent semper suscipit lobortis nam. Justo malesuada cursus ac nunc litora nunc. Tellus ac, in lobortis nunc, montes lectus purus fermentum.

            <br>

            Ac sit wisi. Sodales aliquam, sed vestibulum nullam arcu sit risus arcu, id luctus vitae lorem nibh, integer nec nullam class cursus mi, purus arcu lectus. Vel ante suscipit volutpat potenti mattis sed, wisi eu placerat aliquam erat, lectus morbi lobortis at assumenda. Consequat neque purus ipsum voluptas odio, netus vestibulum ut nec, suspendisse pellentesque nec enim in. Wisi dictum sed semper a, ipsum erat tellus habitasse est, erat sem ornare, vitae quisque ultricies. Dui sed blandit. Tempor et faucibus justo sed luctus, nec vitae vitae. Nunc nibh pede, ipsum vestibulum aenean leo ante ultricies, nam cras quis sed penatibus amet. In mauris a. Integer metus mauris tortor, et rutrum vestibulum ultricies, ut phasellus in ullamcorper ut mollit, eu justo. Cursus pretium venenatis.
            Cras pellentesque vel sodales accumsan aenean. Feugiat metus sit nec in aliquet amet, porttitor pretium vulputate massa. Consequat ipsum luctus quisque adipiscing libero. Wisi sollicitudin. Eget vitae ac lobortis, lorem natoque vestibulum et, aliquet faucibus at morbi nibh, vel condimentum. Massa unde orci sed id sed, odio donec congue nec praesent amet. Hymenaeos velit lacus, quis vivamus libero tempus duis, eu nisi eu, ipsum at accumsan pede justo morbi donec, massa et libero sit risus neque tortor. Ut sed sed etiam hendrerit dapibus, quis metus suspendisse nibh.

            <br>

            Fringilla tempor felis augue magna. Cum arcu a, id vitae. Pellentesque pharetra in cras sociis adipiscing est. Nibh nec mattis at maecenas, nisl orci aliquam nulla justo egestas venenatis, elementum duis vel porta eros, massa vitae, eligendi imperdiet amet. Nec neque luctus suscipit, justo sem praesent, ut nisl quisque, volutpat torquent wisi tellus aliquam reprehenderit, curabitur cras at quis massa porttitor mauris. Eros sed ultrices. Amet dignissim justo urna feugiat mauris litora, etiam accumsan, lobortis a orci suspendisse. Semper ac mauris, varius bibendum pretium, orci urna nunc ullamcorper auctor, saepe sem integer quam, at feugiat egestas duis. Urna ligula ante. Leo elementum nonummy. Sagittis mauris est in ipsum, nulla amet non justo, proin id potenti platea posuere sit ut, nunc sit erat bibendum. Nibh id auctor, ab nulla vivamus ultrices, posuere morbi nunc tellus gravida vivamus.

            <br>

            Mauris nec, facilisi quam fermentum, ut mauris integer, orci tellus tempus diam ut in pellentesque. Wisi faucibus tempor et odio leo diam, eleifend quis integer curabitur sit scelerisque ac, mauris consequat luctus quam penatibus fringilla dis, vitae lacus in, est eu ac tempus. Consectetuer amet ipsum amet dui, sed blandit id sed. Tellus integer, dignissim id pede sodales quis, felis dolorem id mauris orci, orci tempus ut. Nullam hymenaeos. Curabitur in a, tortor ut praesent placerat tincidunt interdum, ac dignissim metus nonummy hendrerit wisi, etiam ut.

            <br>

            Semper praesent integer fusce, tortor suspendisse, augue ligula orci ante asperiores ullamcorper. In sit per mi sed sed, mi vestibulum mus nam, morbi mauris neque vitae aliquam proin senectus. Ac amet arcu mollis ante congue elementum, inceptos eget optio quam pellentesque quis lobortis, sollicitudin sed vestibulum sollicitudin, lectus parturient nullam, leo orci ligula ultrices. At tincidunt enim, suspendisse est sit sem ac. Amet tellus molestie est purus magna augue, non etiam et in wisi id. Non commodo, metus lorem facilisi lobortis ac velit, montes neque sed risus consectetuer fringilla dolor. Quam justo et integer aliquam, cursus nulla enim orci, nam cursus adipiscing, integer torquent non, fringilla per maecenas. Libero ipsum sed tellus purus et. Duis molestie placerat erat donec ut. Dolor enim erat massa faucibus ultrices in, ante ultricies orci lacus, libero consectetuer mauris magna feugiat neque dapibus, donec pretium et. Aptent dui, aliquam et et amet nostra ligula.

            <br>

            Augue curabitur duis dui volutpat, tempus sed ut pede donec. Interdum luctus, lectus nulla aenean elit, id sit magna, vulputate ultrices pellentesque vel id fermentum morbi. Tortor et. Adipiscing augue lorem cum non lacus, rutrum sodales laoreet duis tortor, modi placerat facilisis et malesuada eros ipsum, vehicula tempus. Ac vivamus amet non aliquam venenatis lectus, sociosqu adipiscing consequat nec arcu odio. Blandit orci nec nec, posuere in pretium, enim ut, consectetuer nullam urna, risus vel. Nullam odio vehicula massa sed, etiam sociis mauris, lacus ullamcorper, libero imperdiet non sodales placerat justo vehicula. Nec morbi imperdiet. Fermentum sem libero iaculis bibendum et eros, eget maecenas non nunc, ad pellentesque. Ut nec diam elementum interdum. Elementum vitae tellus lacus vitae, ipsum phasellus, corporis vehicula in ac sed massa vivamus, rutrum elit, ultricies metus volutpat.

            <br>

            Semper wisi et, sollicitudin nunc vestibulum, cursus accumsan nunc pede tempus mi ipsum, ligula sed. Non condimentum ac dolor sit. Mollis eu aliquam, vel mattis mollis massa ut dolor ante, tempus lacinia arcu. Urna vestibulum lorem, nulla fermentum, iaculis ut congue ac vivamus. Nam libero orci, pulvinar nulla, enim pellentesque consectetuer leo, feugiat rhoncus rhoncus vel. Magna sociosqu donec, dictum cursus ullamcorper viverra. Ultricies quis orci lorem, suspendisse ut vestibulum integer, purus sed lorem pulvinar habitasse turpis.
          </template>

          <v-card-actions>
            <v-spacer></v-spacer>

            <v-btn
              text="Disagree"
              variant="text"
              @click="isActive.value = false"
            ></v-btn>

            <v-btn
              color="surface-variant"
              text="Agree"
              variant="flat"
              @click="isActive.value = false"
            ></v-btn>
          </v-card-actions>
        </v-card>
      </template>
    </v-dialog>
  </div>
</template>
`;
const _sfc_main$8 = {
  __name: "misc-without-activator",
  setup(__props) {
    const dialog = ref(false);
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_card_title = resolveComponent("v-card-title");
      const _component_v_card_text = resolveComponent("v-card-text");
      const _component_v_spacer = resolveComponent("v-spacer");
      const _component_v_card_actions = resolveComponent("v-card-actions");
      const _component_v_card = resolveComponent("v-card");
      const _component_v_dialog = resolveComponent("v-dialog");
      const _component_v_row = resolveComponent("v-row");
      return openBlock(), createBlock(_component_v_row, { justify: "center" }, {
        default: withCtx(() => [
          createVNode(_component_v_btn, {
            color: "primary",
            dark: "",
            onClick: _cache[0] || (_cache[0] = withModifiers(($event) => dialog.value = true, ["stop"]))
          }, {
            default: withCtx(() => [
              createTextVNode(" Open Dialog ")
            ]),
            _: 1
          }),
          createVNode(_component_v_dialog, {
            modelValue: dialog.value,
            "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => dialog.value = $event),
            "max-width": "290"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_card, null, {
                default: withCtx(() => [
                  createVNode(_component_v_card_title, { class: "text-h5" }, {
                    default: withCtx(() => [
                      createTextVNode(" Use Google's location service? ")
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_card_text, null, {
                    default: withCtx(() => [
                      createTextVNode(" Let Google help apps determine location. This means sending anonymous location data to Google, even when no apps are running. ")
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_card_actions, null, {
                    default: withCtx(() => [
                      createVNode(_component_v_spacer),
                      createVNode(_component_v_btn, {
                        color: "green-darken-1",
                        variant: "text",
                        onClick: _cache[1] || (_cache[1] = ($event) => dialog.value = false)
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" Disagree ")
                        ]),
                        _: 1
                      }),
                      createVNode(_component_v_btn, {
                        color: "green-darken-1",
                        variant: "text",
                        onClick: _cache[2] || (_cache[2] = ($event) => dialog.value = false)
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" Agree ")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          }, 8, ["modelValue"])
        ]),
        _: 1
      });
    };
  }
};
const __5 = _sfc_main$8;
const __5_raw = `<template>
  <v-row justify="center">
    <v-btn
      color="primary"
      dark
      @click.stop="dialog = true"
    >
      Open Dialog
    </v-btn>

    <v-dialog
      v-model="dialog"
      max-width="290"
    >
      <v-card>
        <v-card-title class="text-h5">
          Use Google's location service?
        </v-card-title>

        <v-card-text>
          Let Google help apps determine location. This means sending anonymous location data to Google, even when no apps are running.
        </v-card-text>

        <v-card-actions>
          <v-spacer></v-spacer>

          <v-btn
            color="green-darken-1"
            variant="text"
            @click="dialog = false"
          >
            Disagree
          </v-btn>

          <v-btn
            color="green-darken-1"
            variant="text"
            @click="dialog = false"
          >
            Agree
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-row>
</template>

<script setup>
  import { ref } from 'vue'

  const dialog = ref(false)
<\/script>

<script>
  export default {
    data () {
      return {
        dialog: false,
      }
    },
  }
<\/script>
`;
const _sfc_main$7 = {
  __name: "prop-activator",
  setup(__props) {
    const btn = ref(null);
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_card = resolveComponent("v-card");
      const _component_v_dialog = resolveComponent("v-dialog");
      const _component_v_col = resolveComponent("v-col");
      const _component_v_row = resolveComponent("v-row");
      const _component_v_container = resolveComponent("v-container");
      return openBlock(), createBlock(_component_v_container, null, {
        default: withCtx(() => [
          createVNode(_component_v_row, { class: "text-center" }, {
            default: withCtx(() => [
              createVNode(_component_v_col, {
                cols: "12",
                md: "6"
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_dialog, { "max-width": "340" }, {
                    activator: withCtx(({ props: activatorProps }) => [
                      createVNode(_component_v_btn, mergeProps(activatorProps, {
                        "prepend-icon": "mdi-package",
                        width: "204"
                      }), {
                        default: withCtx(() => [
                          createTextVNode(" Slot Activator ")
                        ]),
                        _: 2
                      }, 1040)
                    ]),
                    default: withCtx(({ isActive }) => [
                      createVNode(_component_v_card, {
                        "prepend-icon": "mdi-package",
                        text: "When using the activator slot, you must bind the slot props to the activator element.",
                        title: "Slot Activator"
                      }, {
                        actions: withCtx(() => [
                          createVNode(_component_v_btn, {
                            class: "ml-auto",
                            text: "Close",
                            onClick: ($event) => isActive.value = false
                          }, null, 8, ["onClick"])
                        ]),
                        _: 2
                      }, 1024)
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }),
              createVNode(_component_v_col, {
                cols: "12",
                md: "6"
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_btn, {
                    "prepend-icon": "mdi-picture-in-picture-bottom-right",
                    width: "204"
                  }, {
                    default: withCtx(() => [
                      createTextVNode(" Parent Activator "),
                      createVNode(_component_v_dialog, {
                        activator: "parent",
                        "max-width": "340"
                      }, {
                        default: withCtx(({ isActive }) => [
                          createVNode(_component_v_card, {
                            "prepend-icon": "mdi-picture-in-picture-bottom-right",
                            text: "When using the parent as the activator, the dialog will bind its listeners to the parent element.",
                            title: "Parent Activator"
                          }, {
                            actions: withCtx(() => [
                              createVNode(_component_v_btn, {
                                class: "ml-auto",
                                text: "Close",
                                onClick: ($event) => isActive.value = false
                              }, null, 8, ["onClick"])
                            ]),
                            _: 2
                          }, 1024)
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }),
              createVNode(_component_v_col, {
                cols: "12",
                md: "6"
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_btn, {
                    ref_key: "btn",
                    ref: btn,
                    "prepend-icon": "mdi-variable",
                    width: "204"
                  }, {
                    default: withCtx(() => [
                      createTextVNode(" Ref Activator ")
                    ]),
                    _: 1
                  }, 512),
                  createVNode(_component_v_dialog, {
                    activator: btn.value,
                    "max-width": "340"
                  }, {
                    default: withCtx(({ isActive }) => [
                      createVNode(_component_v_card, {
                        "prepend-icon": "mdi-variable",
                        text: "When using a ref, the dialog will bind its listeners to the ref element. This works for any element and custom components.",
                        title: "Ref Activator"
                      }, {
                        actions: withCtx(() => [
                          createVNode(_component_v_btn, {
                            class: "ml-auto",
                            text: "Close",
                            onClick: ($event) => isActive.value = false
                          }, null, 8, ["onClick"])
                        ]),
                        _: 2
                      }, 1024)
                    ]),
                    _: 1
                  }, 8, ["activator"])
                ]),
                _: 1
              }),
              createVNode(_component_v_col, {
                cols: "12",
                md: "6"
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_btn, {
                    id: "activator-target",
                    "prepend-icon": "mdi-bullseye-arrow",
                    width: "204"
                  }, {
                    default: withCtx(() => [
                      createTextVNode(" Target Activator ")
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_dialog, {
                    activator: "#activator-target",
                    "max-width": "340"
                  }, {
                    default: withCtx(({ isActive }) => [
                      createVNode(_component_v_card, {
                        "prepend-icon": "mdi-bullseye-arrow",
                        text: "Pass any valid querySelector to the activator prop to bind the dialog to the target element.",
                        title: "Target Activator"
                      }, {
                        actions: withCtx(() => [
                          createVNode(_component_v_btn, {
                            class: "ml-auto",
                            text: "Close",
                            onClick: ($event) => isActive.value = false
                          }, null, 8, ["onClick"])
                        ]),
                        _: 2
                      }, 1024)
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __6 = _sfc_main$7;
const __6_raw = `<template>
  <v-container>
    <v-row class="text-center">
      <v-col cols="12" md="6">
        <v-dialog max-width="340">
          <template v-slot:activator="{ props: activatorProps }">
            <v-btn
              v-bind="activatorProps"
              prepend-icon="mdi-package"
              width="204"
            >
              Slot Activator
            </v-btn>
          </template>

          <template v-slot:default="{ isActive }">
            <v-card
              prepend-icon="mdi-package"
              text="When using the activator slot, you must bind the slot props to the activator element."
              title="Slot Activator"
            >
              <template v-slot:actions>
                <v-btn
                  class="ml-auto"
                  text="Close"
                  @click="isActive.value = false"
                ></v-btn>
              </template>
            </v-card>
          </template>
        </v-dialog>
      </v-col>

      <v-col cols="12" md="6">
        <v-btn
          prepend-icon="mdi-picture-in-picture-bottom-right"
          width="204"
        >
          Parent Activator

          <v-dialog activator="parent" max-width="340">
            <template v-slot:default="{ isActive }">
              <v-card
                prepend-icon="mdi-picture-in-picture-bottom-right"
                text="When using the parent as the activator, the dialog will bind its listeners to the parent element."
                title="Parent Activator"
              >
                <template v-slot:actions>
                  <v-btn
                    class="ml-auto"
                    text="Close"
                    @click="isActive.value = false"
                  ></v-btn>
                </template>
              </v-card>
            </template>
          </v-dialog>
        </v-btn>
      </v-col>

      <v-col cols="12" md="6">
        <v-btn
          ref="btn"
          prepend-icon="mdi-variable"
          width="204"
        >
          Ref Activator
        </v-btn>

        <v-dialog :activator="btn" max-width="340">
          <template v-slot:default="{ isActive }">
            <v-card
              prepend-icon="mdi-variable"
              text="When using a ref, the dialog will bind its listeners to the ref element. This works for any element and custom components."
              title="Ref Activator"
            >
              <template v-slot:actions>
                <v-btn
                  class="ml-auto"
                  text="Close"
                  @click="isActive.value = false"
                ></v-btn>
              </template>
            </v-card>
          </template>
        </v-dialog>
      </v-col>

      <v-col cols="12" md="6">
        <v-btn
          id="activator-target"
          prepend-icon="mdi-bullseye-arrow"
          width="204"
        >
          Target Activator
        </v-btn>

        <v-dialog activator="#activator-target" max-width="340">
          <template v-slot:default="{ isActive }">
            <v-card
              prepend-icon="mdi-bullseye-arrow"
              text="Pass any valid querySelector to the activator prop to bind the dialog to the target element."
              title="Target Activator"
            >
              <template v-slot:actions>
                <v-btn
                  class="ml-auto"
                  text="Close"
                  @click="isActive.value = false"
                ></v-btn>
              </template>
            </v-card>
          </template>
        </v-dialog>
      </v-col>
    </v-row>
  </v-container>
</template>

<script setup>
  import { ref } from 'vue'

  const btn = ref(null)
<\/script>

<script>
  export default {
    data () {
      return {
        btn: null,
      }
    },
  }
<\/script>
`;
const _hoisted_1$5 = { class: "text-center pa-4" };
const _sfc_main$6 = {
  __name: "prop-fullscreen",
  setup(__props) {
    const dialog = shallowRef(false);
    const notifications = shallowRef(false);
    const sound = shallowRef(true);
    const widgets = shallowRef(false);
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_toolbar_title = resolveComponent("v-toolbar-title");
      const _component_v_spacer = resolveComponent("v-spacer");
      const _component_v_toolbar_items = resolveComponent("v-toolbar-items");
      const _component_v_toolbar = resolveComponent("v-toolbar");
      const _component_v_list_subheader = resolveComponent("v-list-subheader");
      const _component_v_list_item = resolveComponent("v-list-item");
      const _component_v_divider = resolveComponent("v-divider");
      const _component_v_checkbox_btn = resolveComponent("v-checkbox-btn");
      const _component_v_list_item_action = resolveComponent("v-list-item-action");
      const _component_v_list = resolveComponent("v-list");
      const _component_v_card = resolveComponent("v-card");
      const _component_v_dialog = resolveComponent("v-dialog");
      return openBlock(), createElementBlock("div", _hoisted_1$5, [
        createVNode(_component_v_dialog, {
          modelValue: dialog.value,
          "onUpdate:modelValue": _cache[8] || (_cache[8] = ($event) => dialog.value = $event),
          transition: "dialog-bottom-transition",
          fullscreen: ""
        }, {
          activator: withCtx(({ props: activatorProps }) => [
            createVNode(_component_v_btn, mergeProps({
              "prepend-icon": "mdi-cog",
              size: "small",
              text: "Settings"
            }, activatorProps), null, 16)
          ]),
          default: withCtx(() => [
            createVNode(_component_v_card, null, {
              default: withCtx(() => [
                createVNode(_component_v_toolbar, null, {
                  default: withCtx(() => [
                    createVNode(_component_v_btn, {
                      icon: "mdi-close",
                      onClick: _cache[0] || (_cache[0] = ($event) => dialog.value = false)
                    }),
                    createVNode(_component_v_toolbar_title, null, {
                      default: withCtx(() => [
                        createTextVNode("Settings")
                      ]),
                      _: 1
                    }),
                    createVNode(_component_v_spacer),
                    createVNode(_component_v_toolbar_items, null, {
                      default: withCtx(() => [
                        createVNode(_component_v_btn, {
                          text: "Save",
                          variant: "text",
                          onClick: _cache[1] || (_cache[1] = ($event) => dialog.value = false)
                        })
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                }),
                createVNode(_component_v_list, {
                  lines: "two",
                  subheader: ""
                }, {
                  default: withCtx(() => [
                    createVNode(_component_v_list_subheader, null, {
                      default: withCtx(() => [
                        createTextVNode("User Controls")
                      ]),
                      _: 1
                    }),
                    createVNode(_component_v_list_item, {
                      subtitle: "Set the content filtering level to restrict apps that can be downloaded",
                      title: "Content filtering",
                      link: ""
                    }),
                    createVNode(_component_v_list_item, {
                      subtitle: "Require password for purchase or use password to restrict purchase",
                      title: "Password",
                      link: ""
                    }),
                    createVNode(_component_v_divider),
                    createVNode(_component_v_list_subheader, null, {
                      default: withCtx(() => [
                        createTextVNode("General")
                      ]),
                      _: 1
                    }),
                    createVNode(_component_v_list_item, {
                      subtitle: "Notify me about updates to apps or games that I downloaded",
                      title: "Notifications",
                      onClick: _cache[3] || (_cache[3] = ($event) => notifications.value = !notifications.value)
                    }, {
                      prepend: withCtx(() => [
                        createVNode(_component_v_list_item_action, { start: "" }, {
                          default: withCtx(() => [
                            createVNode(_component_v_checkbox_btn, {
                              modelValue: notifications.value,
                              "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => notifications.value = $event),
                              color: "primary"
                            }, null, 8, ["modelValue"])
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }),
                    createVNode(_component_v_list_item, {
                      subtitle: "Auto-update apps at any time. Data charges may apply",
                      title: "Sound",
                      onClick: _cache[5] || (_cache[5] = ($event) => sound.value = !sound.value)
                    }, {
                      prepend: withCtx(() => [
                        createVNode(_component_v_list_item_action, { start: "" }, {
                          default: withCtx(() => [
                            createVNode(_component_v_checkbox_btn, {
                              modelValue: sound.value,
                              "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => sound.value = $event),
                              color: "primary"
                            }, null, 8, ["modelValue"])
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }),
                    createVNode(_component_v_list_item, {
                      subtitle: "Automatically add home screen widgets",
                      title: "Auto-add widgets",
                      onClick: _cache[7] || (_cache[7] = ($event) => widgets.value = !widgets.value)
                    }, {
                      prepend: withCtx(() => [
                        createVNode(_component_v_list_item_action, { start: "" }, {
                          default: withCtx(() => [
                            createVNode(_component_v_checkbox_btn, {
                              modelValue: widgets.value,
                              "onUpdate:modelValue": _cache[6] || (_cache[6] = ($event) => widgets.value = $event),
                              color: "primary"
                            }, null, 8, ["modelValue"])
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                })
              ]),
              _: 1
            })
          ]),
          _: 1
        }, 8, ["modelValue"])
      ]);
    };
  }
};
const __7 = _sfc_main$6;
const __7_raw = `<template>
  <div class="text-center pa-4">
    <v-dialog
      v-model="dialog"
      transition="dialog-bottom-transition"
      fullscreen
    >
      <template v-slot:activator="{ props: activatorProps }">
        <v-btn
          prepend-icon="mdi-cog"
          size="small"
          text="Settings"
          v-bind="activatorProps"
        ></v-btn>
      </template>

      <v-card>
        <v-toolbar>
          <v-btn
            icon="mdi-close"
            @click="dialog = false"
          ></v-btn>

          <v-toolbar-title>Settings</v-toolbar-title>

          <v-spacer></v-spacer>

          <v-toolbar-items>
            <v-btn
              text="Save"
              variant="text"
              @click="dialog = false"
            ></v-btn>
          </v-toolbar-items>
        </v-toolbar>

        <v-list
          lines="two"
          subheader
        >
          <v-list-subheader>User Controls</v-list-subheader>

          <v-list-item
            subtitle="Set the content filtering level to restrict apps that can be downloaded"
            title="Content filtering"
            link
          ></v-list-item>

          <v-list-item
            subtitle="Require password for purchase or use password to restrict purchase"
            title="Password"
            link
          ></v-list-item>

          <v-divider></v-divider>

          <v-list-subheader>General</v-list-subheader>

          <v-list-item
            subtitle="Notify me about updates to apps or games that I downloaded"
            title="Notifications"
            @click="notifications = !notifications"
          >
            <template v-slot:prepend>
              <v-list-item-action start>
                <v-checkbox-btn v-model="notifications" color="primary"></v-checkbox-btn>
              </v-list-item-action>
            </template>
          </v-list-item>

          <v-list-item
            subtitle="Auto-update apps at any time. Data charges may apply"
            title="Sound"
            @click="sound = !sound"
          >
            <template v-slot:prepend>
              <v-list-item-action start>
                <v-checkbox-btn v-model="sound" color="primary"></v-checkbox-btn>
              </v-list-item-action>
            </template>
          </v-list-item>

          <v-list-item
            subtitle="Automatically add home screen widgets"
            title="Auto-add widgets"
            @click="widgets = !widgets"
          >
            <template v-slot:prepend>
              <v-list-item-action start>
                <v-checkbox-btn v-model="widgets" color="primary"></v-checkbox-btn>
              </v-list-item-action>
            </template>
          </v-list-item>
        </v-list>
      </v-card>
    </v-dialog>
  </div>
</template>

<script setup>
  import { shallowRef } from 'vue'

  const dialog = shallowRef(false)
  const notifications = shallowRef(false)
  const sound = shallowRef(true)
  const widgets = shallowRef(false)
<\/script>

<script>
  export default {
    data () {
      return {
        dialog: false,
        notifications: false,
        sound: true,
        widgets: false,
      }
    },
  }
<\/script>
`;
const _hoisted_1$4 = { class: "text-center pa-4" };
const _sfc_main$5 = {
  __name: "prop-model",
  setup(__props) {
    const dialog = ref(false);
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_card = resolveComponent("v-card");
      const _component_v_dialog = resolveComponent("v-dialog");
      return openBlock(), createElementBlock("div", _hoisted_1$4, [
        createVNode(_component_v_btn, {
          onClick: _cache[0] || (_cache[0] = ($event) => dialog.value = true)
        }, {
          default: withCtx(() => [
            createTextVNode(" Open Dialog ")
          ]),
          _: 1
        }),
        createVNode(_component_v_dialog, {
          modelValue: dialog.value,
          "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => dialog.value = $event),
          width: "auto"
        }, {
          default: withCtx(() => [
            createVNode(_component_v_card, {
              "max-width": "400",
              "prepend-icon": "mdi-update",
              text: "Your application will relaunch automatically after the update is complete.",
              title: "Update in progress"
            }, {
              actions: withCtx(() => [
                createVNode(_component_v_btn, {
                  class: "ms-auto",
                  text: "Ok",
                  onClick: _cache[1] || (_cache[1] = ($event) => dialog.value = false)
                })
              ]),
              _: 1
            })
          ]),
          _: 1
        }, 8, ["modelValue"])
      ]);
    };
  }
};
const __8 = _sfc_main$5;
const __8_raw = `<template>
  <div class="text-center pa-4">
    <v-btn @click="dialog = true">
      Open Dialog
    </v-btn>

    <v-dialog
      v-model="dialog"
      width="auto"
    >
      <v-card
        max-width="400"
        prepend-icon="mdi-update"
        text="Your application will relaunch automatically after the update is complete."
        title="Update in progress"
      >
        <template v-slot:actions>
          <v-btn
            class="ms-auto"
            text="Ok"
            @click="dialog = false"
          ></v-btn>
        </template>
      </v-card>
    </v-dialog>
  </div>
</template>

<script setup>
  import { ref } from 'vue'

  const dialog = ref(false)
<\/script>

<script>
  export default {
    data () {
      return {
        dialog: false,
      }
    },
  }
<\/script>
`;
const _hoisted_1$3 = { class: "text-center pa-4" };
const _sfc_main$4 = {
  __name: "prop-persistent",
  setup(__props) {
    const dialog = ref(false);
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_spacer = resolveComponent("v-spacer");
      const _component_v_card = resolveComponent("v-card");
      const _component_v_dialog = resolveComponent("v-dialog");
      return openBlock(), createElementBlock("div", _hoisted_1$3, [
        createVNode(_component_v_dialog, {
          modelValue: dialog.value,
          "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => dialog.value = $event),
          "max-width": "400",
          persistent: ""
        }, {
          activator: withCtx(({ props: activatorProps }) => [
            createVNode(_component_v_btn, normalizeProps(guardReactiveProps(activatorProps)), {
              default: withCtx(() => [
                createTextVNode(" Open Dialog ")
              ]),
              _: 2
            }, 1040)
          ]),
          default: withCtx(() => [
            createVNode(_component_v_card, {
              "prepend-icon": "mdi-map-marker",
              text: "Let Google help apps determine location. This means sending anonymous location data to Google, even when no apps are running.",
              title: "Use Google's location service?"
            }, {
              actions: withCtx(() => [
                createVNode(_component_v_spacer),
                createVNode(_component_v_btn, {
                  onClick: _cache[0] || (_cache[0] = ($event) => dialog.value = false)
                }, {
                  default: withCtx(() => [
                    createTextVNode(" Disagree ")
                  ]),
                  _: 1
                }),
                createVNode(_component_v_btn, {
                  onClick: _cache[1] || (_cache[1] = ($event) => dialog.value = false)
                }, {
                  default: withCtx(() => [
                    createTextVNode(" Agree ")
                  ]),
                  _: 1
                })
              ]),
              _: 1
            })
          ]),
          _: 1
        }, 8, ["modelValue"])
      ]);
    };
  }
};
const __9 = _sfc_main$4;
const __9_raw = `<template>
  <div class="text-center pa-4">
    <v-dialog
      v-model="dialog"
      max-width="400"
      persistent
    >
      <template v-slot:activator="{ props: activatorProps }">
        <v-btn v-bind="activatorProps">
          Open Dialog
        </v-btn>
      </template>

      <v-card
        prepend-icon="mdi-map-marker"
        text="Let Google help apps determine location. This means sending anonymous location data to Google, even when no apps are running."
        title="Use Google's location service?"
      >
        <template v-slot:actions>
          <v-spacer></v-spacer>

          <v-btn @click="dialog = false">
            Disagree
          </v-btn>

          <v-btn @click="dialog = false">
            Agree
          </v-btn>
        </template>
      </v-card>
    </v-dialog>
  </div>
</template>

<script setup>
  import { ref } from 'vue'

  const dialog = ref(false)
<\/script>

<script>
  export default {
    data () {
      return {
        dialog: false,
      }
    },
  }
<\/script>
`;
const _hoisted_1$2 = { class: "pa-4 text-center" };
const _sfc_main$3 = {
  __name: "prop-scrollable",
  setup(__props) {
    const dialog = ref("");
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_divider = resolveComponent("v-divider");
      const _component_v_radio = resolveComponent("v-radio");
      const _component_v_radio_group = resolveComponent("v-radio-group");
      const _component_v_card_text = resolveComponent("v-card-text");
      const _component_v_spacer = resolveComponent("v-spacer");
      const _component_v_card_actions = resolveComponent("v-card-actions");
      const _component_v_card = resolveComponent("v-card");
      const _component_v_dialog = resolveComponent("v-dialog");
      return openBlock(), createElementBlock("div", _hoisted_1$2, [
        createVNode(_component_v_dialog, {
          width: "auto",
          scrollable: ""
        }, {
          activator: withCtx(({ props: activatorProps }) => [
            createVNode(_component_v_btn, mergeProps({
              color: "brown",
              "prepend-icon": "mdi-earth",
              text: "Select Country",
              variant: "outlined"
            }, activatorProps), null, 16)
          ]),
          default: withCtx(({ isActive }) => [
            createVNode(_component_v_card, {
              "prepend-icon": "mdi-earth",
              title: "Select Country"
            }, {
              default: withCtx(() => [
                createVNode(_component_v_divider, { class: "mt-3" }),
                createVNode(_component_v_card_text, {
                  class: "px-4",
                  style: { "height": "300px" }
                }, {
                  default: withCtx(() => [
                    createVNode(_component_v_radio_group, {
                      modelValue: dialog.value,
                      "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => dialog.value = $event),
                      messages: "Select a Country from the radio group",
                      column: ""
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_v_radio, {
                          label: "Bahamas, The",
                          value: "bahamas"
                        }),
                        createVNode(_component_v_radio, {
                          label: "Bahrain",
                          value: "bahrain"
                        }),
                        createVNode(_component_v_radio, {
                          label: "Bangladesh",
                          value: "bangladesh"
                        }),
                        createVNode(_component_v_radio, {
                          label: "Barbados",
                          value: "barbados"
                        }),
                        createVNode(_component_v_radio, {
                          label: "Belarus",
                          value: "belarus"
                        }),
                        createVNode(_component_v_radio, {
                          label: "Belgium",
                          value: "belgium"
                        }),
                        createVNode(_component_v_radio, {
                          label: "Belize",
                          value: "belize"
                        }),
                        createVNode(_component_v_radio, {
                          label: "Benin",
                          value: "benin"
                        }),
                        createVNode(_component_v_radio, {
                          label: "Bhutan",
                          value: "bhutan"
                        }),
                        createVNode(_component_v_radio, {
                          label: "Bolivia",
                          value: "bolivia"
                        }),
                        createVNode(_component_v_radio, {
                          label: "Bosnia and Herzegovina",
                          value: "bosnia"
                        }),
                        createVNode(_component_v_radio, {
                          label: "Botswana",
                          value: "botswana"
                        }),
                        createVNode(_component_v_radio, {
                          label: "Brazil",
                          value: "brazil"
                        }),
                        createVNode(_component_v_radio, {
                          label: "Brunei",
                          value: "brunei"
                        }),
                        createVNode(_component_v_radio, {
                          label: "Bulgaria",
                          value: "bulgaria"
                        }),
                        createVNode(_component_v_radio, {
                          label: "Burkina Faso",
                          value: "burkina"
                        }),
                        createVNode(_component_v_radio, {
                          label: "Burma",
                          value: "burma"
                        }),
                        createVNode(_component_v_radio, {
                          label: "Burundi",
                          value: "burundi"
                        })
                      ]),
                      _: 1
                    }, 8, ["modelValue"])
                  ]),
                  _: 1
                }),
                createVNode(_component_v_divider),
                createVNode(_component_v_card_actions, null, {
                  default: withCtx(() => [
                    createVNode(_component_v_btn, {
                      text: "Close",
                      onClick: ($event) => isActive.value = false
                    }, null, 8, ["onClick"]),
                    createVNode(_component_v_spacer),
                    createVNode(_component_v_btn, {
                      color: "surface-variant",
                      text: "Save",
                      variant: "flat",
                      onClick: ($event) => isActive.value = false
                    }, null, 8, ["onClick"])
                  ]),
                  _: 2
                }, 1024)
              ]),
              _: 2
            }, 1024)
          ]),
          _: 1
        })
      ]);
    };
  }
};
const __10 = _sfc_main$3;
const __10_raw = `<template>
  <div class="pa-4 text-center">
    <v-dialog
      width="auto"
      scrollable
    >
      <template v-slot:activator="{ props: activatorProps }">
        <v-btn
          color="brown"
          prepend-icon="mdi-earth"
          text="Select Country"
          variant="outlined"
          v-bind="activatorProps"
        ></v-btn>
      </template>

      <template v-slot:default="{ isActive }">
        <v-card
          prepend-icon="mdi-earth"
          title="Select Country"
        >
          <v-divider class="mt-3"></v-divider>

          <v-card-text class="px-4" style="height: 300px;">
            <v-radio-group
              v-model="dialog"
              messages="Select a Country from the radio group"
              column
            >
              <v-radio
                label="Bahamas, The"
                value="bahamas"
              ></v-radio>

              <v-radio
                label="Bahrain"
                value="bahrain"
              ></v-radio>

              <v-radio
                label="Bangladesh"
                value="bangladesh"
              ></v-radio>

              <v-radio
                label="Barbados"
                value="barbados"
              ></v-radio>

              <v-radio
                label="Belarus"
                value="belarus"
              ></v-radio>

              <v-radio
                label="Belgium"
                value="belgium"
              ></v-radio>

              <v-radio
                label="Belize"
                value="belize"
              ></v-radio>

              <v-radio
                label="Benin"
                value="benin"
              ></v-radio>

              <v-radio
                label="Bhutan"
                value="bhutan"
              ></v-radio>

              <v-radio
                label="Bolivia"
                value="bolivia"
              ></v-radio>

              <v-radio
                label="Bosnia and Herzegovina"
                value="bosnia"
              ></v-radio>

              <v-radio
                label="Botswana"
                value="botswana"
              ></v-radio>

              <v-radio
                label="Brazil"
                value="brazil"
              ></v-radio>

              <v-radio
                label="Brunei"
                value="brunei"
              ></v-radio>

              <v-radio
                label="Bulgaria"
                value="bulgaria"
              ></v-radio>

              <v-radio
                label="Burkina Faso"
                value="burkina"
              ></v-radio>

              <v-radio
                label="Burma"
                value="burma"
              ></v-radio>

              <v-radio
                label="Burundi"
                value="burundi"
              ></v-radio>
            </v-radio-group>
          </v-card-text>

          <v-divider></v-divider>

          <v-card-actions>
            <v-btn
              text="Close"
              @click="isActive.value = false"
            ></v-btn>

            <v-spacer></v-spacer>

            <v-btn
              color="surface-variant"
              text="Save"
              variant="flat"
              @click="isActive.value = false"
            ></v-btn>
          </v-card-actions>
        </v-card>
      </template>
    </v-dialog>
  </div>
</template>

<script setup>
  import { ref } from 'vue'

  const dialog = ref('')
<\/script>

<script>
  export default {
    data () {
      return {
        dialog: '',
      }
    },
  }
<\/script>
`;
const _sfc_main$2 = {};
function _sfc_render(_ctx, _cache) {
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_toolbar = resolveComponent("v-toolbar");
  const _component_v_card_text = resolveComponent("v-card-text");
  const _component_v_card_actions = resolveComponent("v-card-actions");
  const _component_v_card = resolveComponent("v-card");
  const _component_v_dialog = resolveComponent("v-dialog");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  return openBlock(), createBlock(_component_v_container, null, {
    default: withCtx(() => [
      createVNode(_component_v_row, { justify: "space-around" }, {
        default: withCtx(() => [
          createVNode(_component_v_col, {
            cols: "12",
            md: "6"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_dialog, {
                transition: "dialog-bottom-transition",
                width: "auto"
              }, {
                activator: withCtx(({ props: activatorProps }) => [
                  createVNode(_component_v_btn, mergeProps(activatorProps, {
                    text: "Transition from Bottom",
                    block: ""
                  }), null, 16)
                ]),
                default: withCtx(({ isActive }) => [
                  createVNode(_component_v_card, null, {
                    default: withCtx(() => [
                      createVNode(_component_v_toolbar, { title: "Opening from the Bottom" }),
                      createVNode(_component_v_card_text, { class: "text-h2 pa-12" }, {
                        default: withCtx(() => [
                          createTextVNode(" Hello world! ")
                        ]),
                        _: 1
                      }),
                      createVNode(_component_v_card_actions, { class: "justify-end" }, {
                        default: withCtx(() => [
                          createVNode(_component_v_btn, {
                            text: "Close",
                            onClick: ($event) => isActive.value = false
                          }, null, 8, ["onClick"])
                        ]),
                        _: 2
                      }, 1024)
                    ]),
                    _: 2
                  }, 1024)
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_col, {
            cols: "12",
            md: "6"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_dialog, {
                transition: "dialog-top-transition",
                width: "auto"
              }, {
                activator: withCtx(({ props: activatorProps }) => [
                  createVNode(_component_v_btn, mergeProps(activatorProps, {
                    text: "Transition from Top",
                    block: ""
                  }), null, 16)
                ]),
                default: withCtx(({ isActive }) => [
                  createVNode(_component_v_card, null, {
                    default: withCtx(() => [
                      createVNode(_component_v_toolbar, { title: "Opening from the Top" }),
                      createVNode(_component_v_card_text, { class: "text-h2 pa-12" }, {
                        default: withCtx(() => [
                          createTextVNode(" Hello world! ")
                        ]),
                        _: 1
                      }),
                      createVNode(_component_v_card_actions, { class: "justify-end" }, {
                        default: withCtx(() => [
                          createVNode(_component_v_btn, {
                            text: "Close",
                            onClick: ($event) => isActive.value = false
                          }, null, 8, ["onClick"])
                        ]),
                        _: 2
                      }, 1024)
                    ]),
                    _: 2
                  }, 1024)
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __11 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["render", _sfc_render]]);
const __11_raw = '<template>\n  <v-container>\n    <v-row justify="space-around">\n      <v-col cols="12" md="6">\n        <v-dialog\n          transition="dialog-bottom-transition"\n          width="auto"\n        >\n          <template v-slot:activator="{ props: activatorProps }">\n            <v-btn\n              v-bind="activatorProps"\n              text="Transition from Bottom"\n              block\n            ></v-btn>\n          </template>\n\n          <template v-slot:default="{ isActive }">\n            <v-card>\n              <v-toolbar title="Opening from the Bottom"></v-toolbar>\n\n              <v-card-text class="text-h2 pa-12">\n                Hello world!\n              </v-card-text>\n\n              <v-card-actions class="justify-end">\n                <v-btn\n                  text="Close"\n                  @click="isActive.value = false"\n                ></v-btn>\n              </v-card-actions>\n            </v-card>\n          </template>\n        </v-dialog>\n      </v-col>\n\n      <v-col cols="12" md="6">\n        <v-dialog\n          transition="dialog-top-transition"\n          width="auto"\n        >\n          <template v-slot:activator="{ props: activatorProps }">\n            <v-btn\n              v-bind="activatorProps"\n              text="Transition from Top"\n              block\n            ></v-btn>\n          </template>\n          <template v-slot:default="{ isActive }">\n            <v-card>\n              <v-toolbar title="Opening from the Top"></v-toolbar>\n\n              <v-card-text class="text-h2 pa-12">\n                Hello world!\n              </v-card-text>\n\n              <v-card-actions class="justify-end">\n                <v-btn\n                  text="Close"\n                  @click="isActive.value = false"\n                ></v-btn>\n              </v-card-actions>\n            </v-card>\n          </template>\n        </v-dialog>\n      </v-col>\n    </v-row>\n  </v-container>\n</template>\n';
const _hoisted_1$1 = { class: "text-center pa-4" };
const _sfc_main$1 = {
  __name: "slot-default",
  setup(__props) {
    const dialog = ref(false);
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_card = resolveComponent("v-card");
      const _component_v_dialog = resolveComponent("v-dialog");
      return openBlock(), createElementBlock("div", _hoisted_1$1, [
        createVNode(_component_v_btn, {
          onClick: _cache[0] || (_cache[0] = ($event) => dialog.value = true)
        }, {
          default: withCtx(() => [
            createTextVNode(" Open Dialog ")
          ]),
          _: 1
        }),
        createVNode(_component_v_dialog, {
          modelValue: dialog.value,
          "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => dialog.value = $event),
          width: "auto"
        }, {
          default: withCtx(() => [
            createVNode(_component_v_card, {
              "max-width": "400",
              "prepend-icon": "mdi-update",
              text: "Your application will relaunch automatically after the update is complete.",
              title: "Update in progress"
            }, {
              actions: withCtx(() => [
                createVNode(_component_v_btn, {
                  class: "ms-auto",
                  text: "Ok",
                  onClick: _cache[1] || (_cache[1] = ($event) => dialog.value = false)
                })
              ]),
              _: 1
            })
          ]),
          _: 1
        }, 8, ["modelValue"])
      ]);
    };
  }
};
const __12 = _sfc_main$1;
const __12_raw = `<template>
  <div class="text-center pa-4">
    <v-btn @click="dialog = true">
      Open Dialog
    </v-btn>

    <v-dialog
      v-model="dialog"
      width="auto"
    >
      <v-card
        max-width="400"
        prepend-icon="mdi-update"
        text="Your application will relaunch automatically after the update is complete."
        title="Update in progress"
      >
        <template v-slot:actions>
          <v-btn
            class="ms-auto"
            text="Ok"
            @click="dialog = false"
          ></v-btn>
        </template>
      </v-card>
    </v-dialog>
  </div>
</template>

<script setup>
  import { ref } from 'vue'

  const dialog = ref(false)
<\/script>

<script>
  export default {
    data () {
      return {
        dialog: false,
      }
    },
  }
<\/script>
`;
const _hoisted_1 = { class: "text-center" };
const name = "v-dialog";
const _sfc_main = {
  __name: "usage",
  setup(__props) {
    const model = ref("default");
    const dialog = ref(false);
    const options = [];
    const props = computed(() => {
      return {
        "max-width": "500"
      };
    });
    const slots = computed(() => {
      return `
  <template v-slot:activator="{ props: activatorProps }">
    <v-btn
      v-bind="activatorProps"
      color="surface-variant"
      text="Open Dialog"
      variant="flat"
    ></v-btn>
  </template>

  <template v-slot:default="{ isActive }">
    <v-card title="Dialog">
      <v-card-text>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
      </v-card-text>

      <v-card-actions>
        <v-spacer></v-spacer>

        <v-btn
          text="Close Dialog"
          @click="isActive.value = false"
        ></v-btn>
      </v-card-actions>
    </v-card>
  </template>
`;
    });
    const code = computed(() => {
      return `<v-dialog${propsToString(props.value)}>${slots.value}</v-dialog>`;
    });
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_card_text = resolveComponent("v-card-text");
      const _component_v_spacer = resolveComponent("v-spacer");
      const _component_v_card_actions = resolveComponent("v-card-actions");
      const _component_v_card = resolveComponent("v-card");
      const _component_v_dialog = resolveComponent("v-dialog");
      const _component_ExamplesUsageExample = _sfc_main$e;
      return openBlock(), createBlock(_component_ExamplesUsageExample, {
        modelValue: unref(model),
        "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(model) ? model.value = $event : null),
        code: unref(code),
        name,
        options
      }, {
        default: withCtx(() => [
          createBaseVNode("div", _hoisted_1, [
            createVNode(_component_v_dialog, mergeProps({
              modelValue: unref(dialog),
              "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(dialog) ? dialog.value = $event : null)
            }, unref(props)), {
              activator: withCtx(({ props: activatorProps }) => [
                createVNode(_component_v_btn, normalizeProps(guardReactiveProps(activatorProps)), {
                  default: withCtx(() => [
                    createTextVNode(" Open Dialog ")
                  ]),
                  _: 2
                }, 1040)
              ]),
              default: withCtx(({ isActive }) => [
                createVNode(_component_v_card, { title: "Dialog" }, {
                  default: withCtx(() => [
                    createVNode(_component_v_card_text, null, {
                      default: withCtx(() => [
                        createTextVNode(" Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ")
                      ]),
                      _: 1
                    }),
                    createVNode(_component_v_card_actions, null, {
                      default: withCtx(() => [
                        createVNode(_component_v_spacer),
                        createVNode(_component_v_btn, {
                          text: "Close Dialog",
                          onClick: ($event) => isActive.value = false
                        }, null, 8, ["onClick"])
                      ]),
                      _: 2
                    }, 1024)
                  ]),
                  _: 2
                }, 1024)
              ]),
              _: 1
            }, 16, ["modelValue"])
          ])
        ]),
        _: 1
      }, 8, ["modelValue", "code"]);
    };
  }
};
const __13 = _sfc_main;
const __13_raw = `<template>
  <ExamplesUsageExample
    v-model="model"
    :code="code"
    :name="name"
    :options="options"
  >
    <div class="text-center">
      <v-dialog
        v-model="dialog"
        v-bind="props"
      >
        <template v-slot:activator="{ props: activatorProps }">
          <v-btn v-bind="activatorProps">
            Open Dialog
          </v-btn>
        </template>

        <template v-slot:default="{ isActive }">
          <v-card title="Dialog">
            <v-card-text>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
            </v-card-text>

            <v-card-actions>
              <v-spacer></v-spacer>

              <v-btn
                text="Close Dialog"
                @click="isActive.value = false"
              ></v-btn>
            </v-card-actions>
          </v-card>
        </template>
      </v-dialog>
    </div>
  </ExamplesUsageExample>
</template>

<script setup>
  const name = 'v-dialog'
  const model = ref('default')
  const dialog = ref(false)
  const options = []

  const props = computed(() => {
    return {
      'max-width': '500',
    }
  })

  const slots = computed(() => {
    return \`
  <template v-slot:activator="{ props: activatorProps }">
    <v-btn
      v-bind="activatorProps"
      color="surface-variant"
      text="Open Dialog"
      variant="flat"
    ></v-btn>
  </template>

  <template v-slot:default="{ isActive }">
    <v-card title="Dialog">
      <v-card-text>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
      </v-card-text>

      <v-card-actions>
        <v-spacer></v-spacer>

        <v-btn
          text="Close Dialog"
          @click="isActive.value = false"
        ></v-btn>
      </v-card-actions>
    </v-card>
  </template>
\`
  })

  const code = computed(() => {
    return \`<v-dialog\${propsToString(props.value)}>\${slots.value}</v-dialog>\`
  })
<\/script>
`;
const vDialog = {
  "misc-form": {
    component: __0,
    source: __0_raw
  },
  "misc-invite-dialog": {
    component: __1,
    source: __1_raw
  },
  "misc-loader": {
    component: __2,
    source: __2_raw
  },
  "misc-nesting": {
    component: __3,
    source: __3_raw
  },
  "misc-overflowed": {
    component: __4,
    source: __4_raw
  },
  "misc-without-activator": {
    component: __5,
    source: __5_raw
  },
  "prop-activator": {
    component: __6,
    source: __6_raw
  },
  "prop-fullscreen": {
    component: __7,
    source: __7_raw
  },
  "prop-model": {
    component: __8,
    source: __8_raw
  },
  "prop-persistent": {
    component: __9,
    source: __9_raw
  },
  "prop-scrollable": {
    component: __10,
    source: __10_raw
  },
  "prop-transitions": {
    component: __11,
    source: __11_raw
  },
  "slot-default": {
    component: __12,
    source: __12_raw
  },
  "usage": {
    component: __13,
    source: __13_raw
  }
};
export {
  vDialog as default
};
