import { y as _export_sfc, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, b as createVNode, e as createBaseVNode, h as createTextVNode, l as createElementBlock, F as Fragment, v as renderList, t as toDisplayString, J as ref, j as computed, ag as propsToString, f as unref, E as isRef, ak as normalizeProps, al as guardReactiveProps } from "./index-DGybHjCP.js";
import { _ as _sfc_main$6 } from "./UsageExample-M8CmNipa.js";
const _sfc_main$5 = {};
const _hoisted_1$5 = /* @__PURE__ */ createBaseVNode("span", { class: "text-h5" }, "Sarah Mcbeal", -1);
function _sfc_render$3(_ctx, _cache) {
  const _component_v_card_title = resolveComponent("v-card-title");
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_defaults_provider = resolveComponent("v-defaults-provider");
  const _component_v_card_item = resolveComponent("v-card-item");
  const _component_v_list_item = resolveComponent("v-list-item");
  const _component_v_divider = resolveComponent("v-divider");
  const _component_v_list = resolveComponent("v-list");
  const _component_v_img = resolveComponent("v-img");
  const _component_v_card = resolveComponent("v-card");
  return openBlock(), createBlock(_component_v_card, {
    class: "mx-auto",
    "max-width": "500"
  }, {
    default: withCtx(() => [
      createVNode(_component_v_card_item, { class: "bg-cyan-darken-1" }, {
        append: withCtx(() => [
          createVNode(_component_v_defaults_provider, { defaults: {
            VBtn: {
              variant: "text",
              density: "comfortable"
            }
          } }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, { icon: "mdi-chevron-left" }),
              createVNode(_component_v_btn, { icon: "mdi-pencil" }),
              createVNode(_component_v_btn, { icon: "mdi-dots-vertical" })
            ]),
            _: 1
          })
        ]),
        default: withCtx(() => [
          createVNode(_component_v_card_title, null, {
            default: withCtx(() => [
              _hoisted_1$5
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_list, null, {
        default: withCtx(() => [
          createVNode(_component_v_list_item, {
            "append-icon": "mdi-message-text",
            "prepend-icon": "mdi-phone",
            title: "(650) 555-1234"
          }),
          createVNode(_component_v_divider, { inset: "" }),
          createVNode(_component_v_list_item, {
            "append-icon": "mdi-message-text",
            "prepend-icon": "mdi-phone",
            title: "(323) 555-6789"
          }),
          createVNode(_component_v_divider, { inset: "" }),
          createVNode(_component_v_list_item, {
            "prepend-icon": "mdi-email",
            title: "mcbeal@example.com"
          }),
          createVNode(_component_v_divider, { inset: "" }),
          createVNode(_component_v_list_item, {
            "prepend-icon": "mdi-map-marker",
            title: "Orlando, FL 79938"
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_img, {
        height: "200",
        src: "https://picsum.photos/700?image=996",
        cover: ""
      })
    ]),
    _: 1
  });
}
const __0 = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["render", _sfc_render$3]]);
const __0_raw = `<template>
  <v-card
    class="mx-auto"
    max-width="500"
  >
    <v-card-item class="bg-cyan-darken-1">
      <v-card-title>
        <span class="text-h5">Sarah Mcbeal</span>
      </v-card-title>

      <template v-slot:append>
        <v-defaults-provider
          :defaults="{
            VBtn: {
              variant: 'text',
              density: 'comfortable',
            }
          }"
        >
          <v-btn icon="mdi-chevron-left"></v-btn>

          <v-btn icon="mdi-pencil"></v-btn>

          <v-btn icon="mdi-dots-vertical"></v-btn>
        </v-defaults-provider>
      </template>
    </v-card-item>

    <v-list>
      <v-list-item
        append-icon="mdi-message-text"
        prepend-icon="mdi-phone"
        title="(650) 555-1234"
      ></v-list-item>

      <v-divider inset></v-divider>

      <v-list-item
        append-icon="mdi-message-text"
        prepend-icon="mdi-phone"
        title="(323) 555-6789"
      ></v-list-item>

      <v-divider inset></v-divider>

      <v-list-item
        prepend-icon="mdi-email"
        title="mcbeal@example.com"
      ></v-list-item>

      <v-divider inset></v-divider>

      <v-list-item
        prepend-icon="mdi-map-marker"
        title="Orlando, FL 79938"
      ></v-list-item>
    </v-list>

    <v-img
      height="200"
      src="https://picsum.photos/700?image=996"
      cover
    ></v-img>
  </v-card>
</template>
`;
const _hoisted_1$4 = ["innerHTML"];
const _hoisted_2$1 = ["innerHTML"];
const _sfc_main$4 = {
  __name: "misc-subheaders",
  setup(__props) {
    const items = [
      {
        header: "Today"
      },
      { divider: true },
      {
        avatar: "https://picsum.photos/250/300?image=660",
        title: "Meeting @ Noon",
        subtitle: `<span class="font-weight-bold">Spike Lee</span> &mdash; I'll be in your neighborhood`
      },
      {
        avatar: "https://picsum.photos/250/300?image=821",
        title: 'Summer BBQ <span class="text-grey-lighten-1"></span>',
        subtitle: '<span class="font-weight-bold">to Operations support</span> &mdash; Wish I could come.'
      },
      {
        avatar: "https://picsum.photos/250/300?image=783",
        title: "Yes yes",
        subtitle: '<span class="font-weight-bold">Bella</span> &mdash; Do you have Paris recommendations'
      },
      {
        header: "Yesterday"
      },
      { divider: true },
      {
        avatar: "https://picsum.photos/250/300?image=1006",
        title: "Dinner tonight?",
        subtitle: '<span class="font-weight-bold">LaToya</span> &mdash; Do you want to hang out?'
      },
      {
        avatar: "https://picsum.photos/250/300?image=146",
        title: "So long",
        subtitle: '<span class="font-weight-bold">Nancy</span> &mdash; Do you see what time it is?'
      },
      {
        header: "Last Week"
      },
      { divider: true },
      {
        avatar: "https://picsum.photos/250/300?image=1008",
        title: "Breakfast?",
        subtitle: '<span class="font-weight-bold">LaToya</span> &mdash; Do you want to hang out?'
      },
      {
        avatar: "https://picsum.photos/250/300?image=839",
        title: 'Winter Porridge <span class="text-grey-lighten-1"></span>',
        subtitle: '<span class="font-weight-bold">cc: Daniel</span> &mdash; Tell me more...'
      },
      {
        avatar: "https://picsum.photos/250/300?image=145",
        title: "Oui oui",
        subtitle: '<span class="font-weight-bold">Nancy</span> &mdash; Do you see what time it is?'
      }
    ];
    return (_ctx, _cache) => {
      const _component_v_app_bar_nav_icon = resolveComponent("v-app-bar-nav-icon");
      const _component_v_toolbar_title = resolveComponent("v-toolbar-title");
      const _component_v_icon = resolveComponent("v-icon");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_toolbar = resolveComponent("v-toolbar");
      const _component_v_list_subheader = resolveComponent("v-list-subheader");
      const _component_v_divider = resolveComponent("v-divider");
      const _component_v_list_item = resolveComponent("v-list-item");
      const _component_v_list = resolveComponent("v-list");
      const _component_v_card = resolveComponent("v-card");
      return openBlock(), createBlock(_component_v_card, {
        class: "mx-auto",
        "max-width": "400"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_toolbar, {
            color: "orange-lighten-1",
            dark: ""
          }, {
            default: withCtx(() => [
              createVNode(_component_v_app_bar_nav_icon),
              createVNode(_component_v_toolbar_title, null, {
                default: withCtx(() => [
                  createTextVNode("Message Board")
                ]),
                _: 1
              }),
              createVNode(_component_v_btn, { icon: "" }, {
                default: withCtx(() => [
                  createVNode(_component_v_icon, null, {
                    default: withCtx(() => [
                      createTextVNode("mdi-magnify")
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_list, { lines: "two" }, {
            default: withCtx(() => [
              (openBlock(), createElementBlock(Fragment, null, renderList(items, (item, index) => {
                return openBlock(), createElementBlock(Fragment, null, [
                  item.header ? (openBlock(), createBlock(_component_v_list_subheader, {
                    key: item.header,
                    inset: ""
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(item.header), 1)
                    ]),
                    _: 2
                  }, 1024)) : item.divider ? (openBlock(), createBlock(_component_v_divider, {
                    key: index,
                    inset: ""
                  })) : (openBlock(), createBlock(_component_v_list_item, {
                    key: item.title,
                    "prepend-avatar": item.avatar,
                    ripple: ""
                  }, {
                    title: withCtx(() => [
                      createBaseVNode("div", {
                        innerHTML: item.title
                      }, null, 8, _hoisted_1$4)
                    ]),
                    subtitle: withCtx(() => [
                      createBaseVNode("div", {
                        innerHTML: item.subtitle
                      }, null, 8, _hoisted_2$1)
                    ]),
                    _: 2
                  }, 1032, ["prepend-avatar"]))
                ], 64);
              }), 64))
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __1 = _sfc_main$4;
const __1_raw = `<template>
  <v-card
    class="mx-auto"
    max-width="400"
  >
    <v-toolbar
      color="orange-lighten-1"
      dark
    >
      <v-app-bar-nav-icon></v-app-bar-nav-icon>

      <v-toolbar-title>Message Board</v-toolbar-title>

      <v-btn icon>
        <v-icon>mdi-magnify</v-icon>
      </v-btn>
    </v-toolbar>

    <v-list lines="two">
      <template v-for="(item, index) in items">
        <v-list-subheader
          v-if="item.header"
          :key="item.header"
          inset
        >
          {{ item.header }}
        </v-list-subheader>

        <v-divider
          v-else-if="item.divider"
          :key="index"
          inset
        ></v-divider>

        <v-list-item
          v-else
          :key="item.title"
          :prepend-avatar="item.avatar"
          ripple
        >
          <template v-slot:title>
            <div v-html="item.title"></div>
          </template>

          <template v-slot:subtitle>
            <div v-html="item.subtitle"></div>
          </template>
        </v-list-item>
      </template>
    </v-list>
  </v-card>
</template>

<script setup>
  const items = [
    {
      header: 'Today',
    },
    { divider: true },
    {
      avatar: 'https://picsum.photos/250/300?image=660',
      title: 'Meeting @ Noon',
      subtitle: \`<span class="font-weight-bold">Spike Lee</span> &mdash; I'll be in your neighborhood\`,
    },
    {
      avatar: 'https://picsum.photos/250/300?image=821',
      title: 'Summer BBQ <span class="text-grey-lighten-1"></span>',
      subtitle: '<span class="font-weight-bold">to Operations support</span> &mdash; Wish I could come.',
    },
    {
      avatar: 'https://picsum.photos/250/300?image=783',
      title: 'Yes yes',
      subtitle: '<span class="font-weight-bold">Bella</span> &mdash; Do you have Paris recommendations',
    },
    {
      header: 'Yesterday',
    },
    { divider: true },
    {
      avatar: 'https://picsum.photos/250/300?image=1006',
      title: 'Dinner tonight?',
      subtitle: '<span class="font-weight-bold">LaToya</span> &mdash; Do you want to hang out?',
    },
    {
      avatar: 'https://picsum.photos/250/300?image=146',
      title: 'So long',
      subtitle: '<span class="font-weight-bold">Nancy</span> &mdash; Do you see what time it is?',
    },
    {
      header: 'Last Week',
    },
    { divider: true },
    {
      avatar: 'https://picsum.photos/250/300?image=1008',
      title: 'Breakfast?',
      subtitle: '<span class="font-weight-bold">LaToya</span> &mdash; Do you want to hang out?',
    },
    {
      avatar: 'https://picsum.photos/250/300?image=839',
      title: 'Winter Porridge <span class="text-grey-lighten-1"></span>',
      subtitle: '<span class="font-weight-bold">cc: Daniel</span> &mdash; Tell me more...',
    },
    {
      avatar: 'https://picsum.photos/250/300?image=145',
      title: 'Oui oui',
      subtitle: '<span class="font-weight-bold">Nancy</span> &mdash; Do you see what time it is?',
    },
  ]
<\/script>

<script>
  export default {
    data: () => ({
      items: [
        {
          header: 'Today',
        },
        { divider: true },
        {
          avatar: 'https://picsum.photos/250/300?image=660',
          title: 'Meeting @ Noon',
          subtitle: \`<span class="font-weight-bold">Spike Lee</span> &mdash; I'll be in your neighborhood\`,
        },
        {
          avatar: 'https://picsum.photos/250/300?image=821',
          title: 'Summer BBQ <span class="text-grey-lighten-1"></span>',
          subtitle: '<span class="font-weight-bold">to Operations support</span> &mdash; Wish I could come.',
        },
        {
          avatar: 'https://picsum.photos/250/300?image=783',
          title: 'Yes yes',
          subtitle: '<span class="font-weight-bold">Bella</span> &mdash; Do you have Paris recommendations',
        },
        {
          header: 'Yesterday',
        },
        { divider: true },
        {
          avatar: 'https://picsum.photos/250/300?image=1006',
          title: 'Dinner tonight?',
          subtitle: '<span class="font-weight-bold">LaToya</span> &mdash; Do you want to hang out?',
        },
        {
          avatar: 'https://picsum.photos/250/300?image=146',
          title: 'So long',
          subtitle: '<span class="font-weight-bold">Nancy</span> &mdash; Do you see what time it is?',
        },
        {
          header: 'Last Week',
        },
        { divider: true },
        {
          avatar: 'https://picsum.photos/250/300?image=1008',
          title: 'Breakfast?',
          subtitle: '<span class="font-weight-bold">LaToya</span> &mdash; Do you want to hang out?',
        },
        {
          avatar: 'https://picsum.photos/250/300?image=839',
          title: 'Winter Porridge <span class="text-grey-lighten-1"></span>',
          subtitle: '<span class="font-weight-bold">cc: Daniel</span> &mdash; Tell me more...',
        },
        {
          avatar: 'https://picsum.photos/250/300?image=145',
          title: 'Oui oui',
          subtitle: '<span class="font-weight-bold">Nancy</span> &mdash; Do you see what time it is?',
        },
      ],
    }),
  }
<\/script>
`;
const _sfc_main$3 = {};
const _hoisted_1$3 = /* @__PURE__ */ createBaseVNode("span", { class: "font-weight-bold" }, "Ali Connors", -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("span", { class: "text-grey-lighten-1" }, "4", -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("span", { class: "font-weight-bold" }, "to Alex, Scott, Jennifer", -1);
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("span", { class: "font-weight-bold" }, "Sandra Adams", -1);
function _sfc_render$2(_ctx, _cache) {
  const _component_v_list_subheader = resolveComponent("v-list-subheader");
  const _component_v_list_item = resolveComponent("v-list-item");
  const _component_v_divider = resolveComponent("v-divider");
  const _component_v_list = resolveComponent("v-list");
  const _component_v_card = resolveComponent("v-card");
  return openBlock(), createBlock(_component_v_card, {
    class: "mx-auto",
    "max-width": "425"
  }, {
    default: withCtx(() => [
      createVNode(_component_v_list, { lines: "two" }, {
        default: withCtx(() => [
          createVNode(_component_v_list_subheader, null, {
            default: withCtx(() => [
              createTextVNode("Today")
            ]),
            _: 1
          }),
          createVNode(_component_v_list_item, {
            "prepend-avatar": "https://cdn.vuetifyjs.com/images/lists/1.jpg",
            title: "Brunch this weekend?"
          }, {
            subtitle: withCtx(() => [
              _hoisted_1$3,
              createTextVNode(" — I'll be in your neighborhood doing errands this weekend. Do you want to hang out? ")
            ]),
            _: 1
          }),
          createVNode(_component_v_divider, { inset: "" }),
          createVNode(_component_v_list_item, { "prepend-avatar": "https://cdn.vuetifyjs.com/images/lists/2.jpg" }, {
            title: withCtx(() => [
              createTextVNode(" Summer BBQ "),
              _hoisted_2
            ]),
            subtitle: withCtx(() => [
              _hoisted_3,
              createTextVNode(" — Wish I could come, but I'm out of town this weekend. ")
            ]),
            _: 1
          }),
          createVNode(_component_v_divider, { inset: "" }),
          createVNode(_component_v_list_item, {
            "prepend-avatar": "https://cdn.vuetifyjs.com/images/lists/3.jpg",
            title: "Oui oui"
          }, {
            subtitle: withCtx(() => [
              _hoisted_4,
              createTextVNode(" — Do you have Paris recommendations? Have you ever been? ")
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __2 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["render", _sfc_render$2]]);
const __2_raw = `<template>
  <v-card
    class="mx-auto"
    max-width="425"
  >
    <v-list lines="two">
      <v-list-subheader>Today</v-list-subheader>

      <v-list-item
        prepend-avatar="https://cdn.vuetifyjs.com/images/lists/1.jpg"
        title="Brunch this weekend?"
      >
        <template v-slot:subtitle>
          <span class="font-weight-bold">Ali Connors</span> &mdash; I'll be in your neighborhood doing errands this weekend. Do you want to hang out?
        </template>
      </v-list-item>

      <v-divider inset></v-divider>

      <v-list-item
        prepend-avatar="https://cdn.vuetifyjs.com/images/lists/2.jpg"
      >
        <template v-slot:title>
          Summer BBQ <span class="text-grey-lighten-1">4</span>
        </template>

        <template v-slot:subtitle>
          <span class="font-weight-bold">to Alex, Scott, Jennifer</span> &mdash; Wish I could come, but I'm out of town this weekend.
        </template>
      </v-list-item>

      <v-divider inset></v-divider>

      <v-list-item
        prepend-avatar="https://cdn.vuetifyjs.com/images/lists/3.jpg"
        title="Oui oui"
      >
        <template v-slot:subtitle>
          <span class="font-weight-bold">Sandra Adams</span> &mdash; Do you have Paris recommendations? Have you ever been?
        </template>
      </v-list-item>
    </v-list>
  </v-card>
</template>
`;
const _sfc_main$2 = {};
const _hoisted_1$2 = /* @__PURE__ */ createBaseVNode("span", { class: "subheading" }, "My Home", -1);
function _sfc_render$1(_ctx, _cache) {
  const _component_v_toolbar_title = resolveComponent("v-toolbar-title");
  const _component_v_divider = resolveComponent("v-divider");
  const _component_v_spacer = resolveComponent("v-spacer");
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_toolbar_items = resolveComponent("v-toolbar-items");
  const _component_v_app_bar_nav_icon = resolveComponent("v-app-bar-nav-icon");
  const _component_v_toolbar = resolveComponent("v-toolbar");
  return openBlock(), createBlock(_component_v_toolbar, {
    color: "teal",
    dark: ""
  }, {
    default: withCtx(() => [
      createVNode(_component_v_toolbar_title, null, {
        default: withCtx(() => [
          createTextVNode("Title")
        ]),
        _: 1
      }),
      createVNode(_component_v_divider, {
        class: "mx-4",
        inset: "",
        vertical: ""
      }),
      _hoisted_1$2,
      createVNode(_component_v_spacer),
      createVNode(_component_v_toolbar_items, { class: "hidden-sm-and-down" }, {
        default: withCtx(() => [
          createVNode(_component_v_btn, { variant: "text" }, {
            default: withCtx(() => [
              createTextVNode(" News ")
            ]),
            _: 1
          }),
          createVNode(_component_v_divider, {
            inset: "",
            vertical: ""
          }),
          createVNode(_component_v_btn, { variant: "text" }, {
            default: withCtx(() => [
              createTextVNode(" Blog ")
            ]),
            _: 1
          }),
          createVNode(_component_v_divider, {
            inset: "",
            vertical: ""
          }),
          createVNode(_component_v_btn, { variant: "text" }, {
            default: withCtx(() => [
              createTextVNode(" Music ")
            ]),
            _: 1
          }),
          createVNode(_component_v_divider, {
            inset: "",
            vertical: ""
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_app_bar_nav_icon)
    ]),
    _: 1
  });
}
const __3 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["render", _sfc_render$1]]);
const __3_raw = '<template>\n  <v-toolbar\n    color="teal"\n    dark\n  >\n    <v-toolbar-title>Title</v-toolbar-title>\n\n    <v-divider\n      class="mx-4"\n      inset\n      vertical\n    ></v-divider>\n\n    <span class="subheading">My Home</span>\n\n    <v-spacer></v-spacer>\n\n    <v-toolbar-items class="hidden-sm-and-down">\n      <v-btn variant="text">\n        News\n      </v-btn>\n\n      <v-divider\n        inset\n        vertical\n      ></v-divider>\n\n      <v-btn variant="text">\n        Blog\n      </v-btn>\n\n      <v-divider\n        inset\n        vertical\n      ></v-divider>\n\n      <v-btn variant="text">\n        Music\n      </v-btn>\n\n      <v-divider\n        inset\n        vertical\n      ></v-divider>\n    </v-toolbar-items>\n\n    <v-app-bar-nav-icon></v-app-bar-nav-icon>\n  </v-toolbar>\n</template>\n';
const _sfc_main$1 = {};
const _hoisted_1$1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-h5" }, "Title", -1);
function _sfc_render(_ctx, _cache) {
  const _component_v_divider = resolveComponent("v-divider");
  const _component_v_toolbar_title = resolveComponent("v-toolbar-title");
  const _component_v_spacer = resolveComponent("v-spacer");
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_toolbar_items = resolveComponent("v-toolbar-items");
  const _component_v_app_bar_nav_icon = resolveComponent("v-app-bar-nav-icon");
  const _component_v_toolbar = resolveComponent("v-toolbar");
  return openBlock(), createBlock(_component_v_toolbar, { color: "purple" }, {
    prepend: withCtx(() => [
      _hoisted_1$1
    ]),
    default: withCtx(() => [
      createVNode(_component_v_divider, {
        class: "ms-3",
        inset: "",
        vertical: ""
      }),
      createVNode(_component_v_toolbar_title, null, {
        default: withCtx(() => [
          createTextVNode("My Home")
        ]),
        _: 1
      }),
      createVNode(_component_v_spacer),
      createVNode(_component_v_spacer),
      createVNode(_component_v_toolbar_items, null, {
        default: withCtx(() => [
          createVNode(_component_v_btn, { variant: "text" }, {
            default: withCtx(() => [
              createTextVNode("News")
            ]),
            _: 1
          }),
          createVNode(_component_v_divider, { vertical: "" }),
          createVNode(_component_v_btn, { variant: "text" }, {
            default: withCtx(() => [
              createTextVNode("Blog")
            ]),
            _: 1
          }),
          createVNode(_component_v_divider, { vertical: "" }),
          createVNode(_component_v_btn, { variant: "text" }, {
            default: withCtx(() => [
              createTextVNode("Music")
            ]),
            _: 1
          })
        ]),
        _: 1
      }),
      createVNode(_component_v_divider, { vertical: "" }),
      createVNode(_component_v_app_bar_nav_icon, { class: "ms-2" })
    ]),
    _: 1
  });
}
const __4 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["render", _sfc_render]]);
const __4_raw = '<template>\n  <v-toolbar color="purple">\n    <template v-slot:prepend>\n      <div class="text-h5">Title</div>\n    </template>\n\n    <v-divider\n      class="ms-3"\n      inset\n      vertical\n    ></v-divider>\n\n    <v-toolbar-title>My Home</v-toolbar-title>\n\n    <v-spacer></v-spacer>\n\n    <v-spacer></v-spacer>\n\n    <v-toolbar-items>\n      <v-btn variant="text">News</v-btn>\n\n      <v-divider vertical></v-divider>\n\n      <v-btn variant="text">Blog</v-btn>\n\n      <v-divider vertical></v-divider>\n\n      <v-btn variant="text">Music</v-btn>\n    </v-toolbar-items>\n\n    <v-divider vertical></v-divider>\n\n    <v-app-bar-nav-icon class="ms-2"></v-app-bar-nav-icon>\n  </v-toolbar>\n</template>\n';
const _hoisted_1 = {
  class: "d-flex align-center justify-center",
  style: { "height": "200px" }
};
const name = "v-divider";
const _sfc_main = {
  __name: "usage",
  setup(__props) {
    const model = ref("default");
    const color = ref();
    const opacity = ref("default");
    const thickness = ref(1);
    const colors = [
      "success",
      "info",
      "warning",
      "error"
    ];
    const opacities = [100, 75, 50, 25, "default", 0];
    const options = ["inset", "vertical"];
    const props = computed(() => {
      let classes;
      if (opacity.value != null && opacity.value !== "default") {
        classes = `border-opacity-${opacity.value}`;
      }
      return {
        thickness: thickness.value !== 1 ? thickness.value : void 0,
        class: classes || void 0,
        color: color.value || void 0,
        inset: model.value === "inset" || void 0,
        vertical: model.value === "vertical" || void 0
      };
    });
    const slots = computed(() => {
      return ``;
    });
    const code = computed(() => {
      return `<${name}${propsToString(props.value)}>${slots.value}</${name}>`;
    });
    return (_ctx, _cache) => {
      const _component_v_divider = resolveComponent("v-divider");
      const _component_v_slider = resolveComponent("v-slider");
      const _component_v_select = resolveComponent("v-select");
      const _component_ExamplesUsageExample = _sfc_main$6;
      return openBlock(), createBlock(_component_ExamplesUsageExample, {
        modelValue: unref(model),
        "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => isRef(model) ? model.value = $event : null),
        code: unref(code),
        name,
        options
      }, {
        configuration: withCtx(() => [
          createVNode(_component_v_slider, {
            modelValue: unref(thickness),
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(thickness) ? thickness.value = $event : null),
            label: "Thickness",
            max: "20",
            min: "1"
          }, null, 8, ["modelValue"]),
          createVNode(_component_v_select, {
            modelValue: unref(opacity),
            "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(opacity) ? opacity.value = $event : null),
            items: opacities,
            label: "Opacity"
          }, null, 8, ["modelValue"]),
          createVNode(_component_v_select, {
            modelValue: unref(color),
            "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => isRef(color) ? color.value = $event : null),
            items: colors,
            label: "Color"
          }, null, 8, ["modelValue"])
        ]),
        default: withCtx(() => [
          createBaseVNode("div", _hoisted_1, [
            createVNode(_component_v_divider, normalizeProps(guardReactiveProps(unref(props))), null, 16)
          ])
        ]),
        _: 1
      }, 8, ["modelValue", "code"]);
    };
  }
};
const __5 = _sfc_main;
const __5_raw = `<template>
  <ExamplesUsageExample
    v-model="model"
    :code="code"
    :name="name"
    :options="options"
  >
    <div class="d-flex align-center justify-center" style="height: 200px;">
      <v-divider v-bind="props"></v-divider>
    </div>

    <template v-slot:configuration>
      <v-slider v-model="thickness" label="Thickness" max="20" min="1"></v-slider>

      <v-select v-model="opacity" :items="opacities" label="Opacity"></v-select>

      <v-select v-model="color" :items="colors" label="Color"></v-select>
    </template>
  </ExamplesUsageExample>
</template>

<script setup>
  const name = 'v-divider'
  const model = ref('default')
  const color = ref()
  const opacity = ref('default')
  const thickness = ref(1)
  const colors = [
    'success',
    'info',
    'warning',
    'error',
  ]
  const opacities = [100, 75, 50, 25, 'default', 0]
  const options = ['inset', 'vertical']
  const props = computed(() => {
    let classes

    if (opacity.value != null && opacity.value !== 'default') {
      classes = \`border-opacity-\${opacity.value}\`
    }
    return {
      thickness: thickness.value !== 1 ? thickness.value : undefined,
      class: classes || undefined,
      color: color.value || undefined,
      inset: model.value === 'inset' || undefined,
      vertical: model.value === 'vertical' || undefined,
    }
  })

  const slots = computed(() => {
    return \`\`
  })

  const code = computed(() => {
    return \`<\${name}\${propsToString(props.value)}>\${slots.value}</\${name}>\`
  })
<\/script>
`;
const vDivider = {
  "misc-portrait-view": {
    component: __0,
    source: __0_raw
  },
  "misc-subheaders": {
    component: __1,
    source: __1_raw
  },
  "prop-inset": {
    component: __2,
    source: __2_raw
  },
  "prop-vertical-inset": {
    component: __3,
    source: __3_raw
  },
  "prop-vertical": {
    component: __4,
    source: __4_raw
  },
  "usage": {
    component: __5,
    source: __5_raw
  }
};
export {
  vDivider as default
};
