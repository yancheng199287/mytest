import { B as shallowRef, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, b as createVNode, e as createBaseVNode, y as _export_sfc, J as ref, j as computed, ag as propsToString, ak as normalizeProps, al as guardReactiveProps, f as unref, E as isRef } from "./index-DGybHjCP.js";
import { _ as _sfc_main$9 } from "./UsageExample-M8CmNipa.js";
const _hoisted_1$3 = { class: "pt-4 pb-16" };
const _hoisted_2$3 = /* @__PURE__ */ createBaseVNode("div", { class: "text-h6 text-high-emphasis" }, "Get Started", -1);
const _hoisted_3$1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-body-2 font-weight-medium text-medium-emphasis" }, " Find a great movie, then relax and enjoy with the Movies & TV app. ", -1);
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("div", { class: "text-h6 text-high-emphasis" }, "Get Started", -1);
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("div", { class: "text-body-2 font-weight-medium text-medium-emphasis" }, " Watch your favorite TV Shows with the Movies & TV app. ", -1);
const _sfc_main$8 = {
  __name: "misc-astro-cat",
  setup(__props) {
    const tabs = shallowRef(0);
    return (_ctx, _cache) => {
      const _component_v_icon = resolveComponent("v-icon");
      const _component_v_system_bar = resolveComponent("v-system-bar");
      const _component_v_app_bar_nav_icon = resolveComponent("v-app-bar-nav-icon");
      const _component_v_tab = resolveComponent("v-tab");
      const _component_v_tabs = resolveComponent("v-tabs");
      const _component_v_app_bar = resolveComponent("v-app-bar");
      const _component_v_img = resolveComponent("v-img");
      const _component_v_sheet = resolveComponent("v-sheet");
      const _component_v_spacer = resolveComponent("v-spacer");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_empty_state = resolveComponent("v-empty-state");
      const _component_v_card = resolveComponent("v-card");
      const _component_v_window_item = resolveComponent("v-window-item");
      const _component_v_window = resolveComponent("v-window");
      const _component_v_main = resolveComponent("v-main");
      const _component_v_layout = resolveComponent("v-layout");
      return openBlock(), createBlock(_component_v_card, {
        class: "mx-auto",
        "max-width": "360",
        variant: "flat",
        border: ""
      }, {
        default: withCtx(() => [
          createVNode(_component_v_layout, null, {
            default: withCtx(() => [
              createVNode(_component_v_system_bar, {
                class: "ga-1",
                color: "surface-light"
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_icon, {
                    icon: "mdi-square",
                    size: "x-small"
                  }),
                  createVNode(_component_v_icon, {
                    icon: "mdi-circle",
                    size: "x-small"
                  }),
                  createVNode(_component_v_icon, {
                    icon: "mdi-triangle",
                    size: "x-small"
                  })
                ]),
                _: 1
              }),
              createVNode(_component_v_app_bar, { title: "My Library" }, {
                prepend: withCtx(() => [
                  createVNode(_component_v_app_bar_nav_icon)
                ]),
                extension: withCtx(() => [
                  createVNode(_component_v_tabs, {
                    modelValue: tabs.value,
                    "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => tabs.value = $event),
                    color: "#4c00d5",
                    grow: ""
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_v_tab, { text: "My Movies" }),
                      createVNode(_component_v_tab, { text: "My Tv Shows" })
                    ]),
                    _: 1
                  }, 8, ["modelValue"])
                ]),
                _: 1
              }),
              createVNode(_component_v_main, null, {
                default: withCtx(() => [
                  createBaseVNode("div", _hoisted_1$3, [
                    createVNode(_component_v_window, {
                      modelValue: tabs.value,
                      "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => tabs.value = $event)
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_v_window_item, {
                          class: "pa-2",
                          value: "0"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_v_card, null, {
                              default: withCtx(() => [
                                createVNode(_component_v_empty_state, {
                                  class: "pa-0",
                                  image: "https://vuetifyjs.b-cdn.net/docs/images/components/v-empty-state/astro-cat.svg",
                                  size: "200"
                                }, {
                                  media: withCtx(() => [
                                    createVNode(_component_v_sheet, {
                                      class: "py-4 mb-4",
                                      color: "#fdefff"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_v_img)
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  title: withCtx(() => [
                                    _hoisted_2$3
                                  ]),
                                  text: withCtx(() => [
                                    _hoisted_3$1
                                  ]),
                                  actions: withCtx(() => [
                                    createVNode(_component_v_spacer),
                                    createVNode(_component_v_btn, {
                                      color: "#4c00d5",
                                      text: "Shop Movies"
                                    }),
                                    createVNode(_component_v_spacer)
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_v_window_item, {
                          class: "pa-2",
                          value: "0"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_v_card, null, {
                              default: withCtx(() => [
                                createVNode(_component_v_empty_state, {
                                  class: "pa-0",
                                  image: "https://vuetifyjs.b-cdn.net/docs/images/components/v-empty-state/astro-dog.svg",
                                  size: "200"
                                }, {
                                  media: withCtx(() => [
                                    createVNode(_component_v_sheet, {
                                      class: "py-4 mb-4",
                                      color: "#fdefff"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_v_img)
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  title: withCtx(() => [
                                    _hoisted_4
                                  ]),
                                  text: withCtx(() => [
                                    _hoisted_5
                                  ]),
                                  actions: withCtx(() => [
                                    createVNode(_component_v_spacer),
                                    createVNode(_component_v_btn, {
                                      color: "#4c00d5",
                                      text: "Shop TV Shows"
                                    }),
                                    createVNode(_component_v_spacer)
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }, 8, ["modelValue"])
                  ])
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __0 = _sfc_main$8;
const __0_raw = `<template>
  <v-card
    class="mx-auto"
    max-width="360"
    variant="flat"
    border
  >
    <v-layout>
      <v-system-bar class="ga-1" color="surface-light">
        <v-icon icon="mdi-square" size="x-small"></v-icon>

        <v-icon icon="mdi-circle" size="x-small"></v-icon>

        <v-icon icon="mdi-triangle" size="x-small"></v-icon>
      </v-system-bar>

      <v-app-bar title="My Library">
        <template v-slot:prepend>
          <v-app-bar-nav-icon></v-app-bar-nav-icon>
        </template>

        <template v-slot:extension>
          <v-tabs v-model="tabs" color="#4c00d5" grow>
            <v-tab text="My Movies"></v-tab>

            <v-tab text="My Tv Shows"></v-tab>
          </v-tabs>
        </template>
      </v-app-bar>

      <v-main>
        <div class="pt-4 pb-16">
          <v-window v-model="tabs">
            <v-window-item class="pa-2" value="0">
              <v-card>
                <v-empty-state
                  class="pa-0"
                  image="https://vuetifyjs.b-cdn.net/docs/images/components/v-empty-state/astro-cat.svg"
                  size="200"
                >
                  <template v-slot:media>
                    <v-sheet class="py-4 mb-4" color="#fdefff">
                      <v-img></v-img>
                    </v-sheet>
                  </template>

                  <template v-slot:title>
                    <div class="text-h6 text-high-emphasis">Get Started</div>
                  </template>

                  <template v-slot:text>
                    <div class="text-body-2 font-weight-medium text-medium-emphasis">
                      Find a great movie, then relax and enjoy with the Movies & TV app.
                    </div>
                  </template>

                  <template v-slot:actions>
                    <v-spacer></v-spacer>

                    <v-btn color="#4c00d5" text="Shop Movies"></v-btn>

                    <v-spacer></v-spacer>
                  </template>
                </v-empty-state>
              </v-card>
            </v-window-item>

            <v-window-item class="pa-2" value="0">
              <v-card>
                <v-empty-state
                  class="pa-0"
                  image="https://vuetifyjs.b-cdn.net/docs/images/components/v-empty-state/astro-dog.svg"
                  size="200"
                >
                  <template v-slot:media>
                    <v-sheet class="py-4 mb-4" color="#fdefff">
                      <v-img></v-img>
                    </v-sheet>
                  </template>

                  <template v-slot:title>
                    <div class="text-h6 text-high-emphasis">Get Started</div>
                  </template>

                  <template v-slot:text>
                    <div class="text-body-2 font-weight-medium text-medium-emphasis">
                      Watch your favorite TV Shows with the Movies & TV app.
                    </div>
                  </template>

                  <template v-slot:actions>
                    <v-spacer></v-spacer>

                    <v-btn color="#4c00d5" text="Shop TV Shows"></v-btn>

                    <v-spacer></v-spacer>
                  </template>
                </v-empty-state>
              </v-card>
            </v-window-item>
          </v-window>
        </div>
      </v-main>
    </v-layout>
  </v-card>
</template>

<script setup>
  import { shallowRef } from 'vue'

  const tabs = shallowRef(0)
<\/script>

<script>
  export default {
    data: () => ({
      tabs: 0,
    }),
  }
<\/script>
`;
const _sfc_main$7 = {};
const _hoisted_1$2 = /* @__PURE__ */ createBaseVNode("div", { class: "text-h6 text-high-emphasis" }, "Empty in drafts", -1);
const _hoisted_2$2 = /* @__PURE__ */ createBaseVNode("div", { class: "text-body-1" }, "Save a draft message and it will show up here", -1);
function _sfc_render$4(_ctx, _cache) {
  const _component_v_icon = resolveComponent("v-icon");
  const _component_v_system_bar = resolveComponent("v-system-bar");
  const _component_v_app_bar_nav_icon = resolveComponent("v-app-bar-nav-icon");
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_app_bar = resolveComponent("v-app-bar");
  const _component_v_img = resolveComponent("v-img");
  const _component_v_empty_state = resolveComponent("v-empty-state");
  const _component_v_main = resolveComponent("v-main");
  const _component_v_layout_item = resolveComponent("v-layout-item");
  const _component_v_layout = resolveComponent("v-layout");
  const _component_v_card = resolveComponent("v-card");
  return openBlock(), createBlock(_component_v_card, {
    class: "mx-auto",
    "max-width": "360"
  }, {
    default: withCtx(() => [
      createVNode(_component_v_layout, null, {
        default: withCtx(() => [
          createVNode(_component_v_system_bar, {
            class: "ga-1",
            color: "#4c00d5"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_icon, {
                icon: "mdi-square",
                size: "x-small"
              }),
              createVNode(_component_v_icon, {
                icon: "mdi-circle",
                size: "x-small"
              }),
              createVNode(_component_v_icon, {
                icon: "mdi-triangle",
                size: "x-small"
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_app_bar, {
            color: "#6200ee",
            title: "Drafts"
          }, {
            prepend: withCtx(() => [
              createVNode(_component_v_app_bar_nav_icon)
            ]),
            append: withCtx(() => [
              createVNode(_component_v_btn, { icon: "mdi-magnify" }),
              createVNode(_component_v_btn, { icon: "mdi-dots-vertical" })
            ]),
            _: 1
          }),
          createVNode(_component_v_main, null, {
            default: withCtx(() => [
              createVNode(_component_v_empty_state, {
                image: "https://vuetifyjs.b-cdn.net/docs/images/components/v-empty-state/astro-dog.svg",
                size: "200",
                "text-width": "250"
              }, {
                media: withCtx(() => [
                  createVNode(_component_v_img, { class: "mb-8" })
                ]),
                title: withCtx(() => [
                  _hoisted_1$2
                ]),
                text: withCtx(() => [
                  _hoisted_2$2
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_layout_item, {
            class: "text-end",
            position: "bottom",
            size: "80",
            "model-value": ""
          }, {
            default: withCtx(() => [
              createVNode(_component_v_btn, {
                class: "ma-4",
                color: "#4c00d5",
                elevation: "8",
                icon: "mdi-plus"
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __1 = /* @__PURE__ */ _export_sfc(_sfc_main$7, [["render", _sfc_render$4]]);
const __1_raw = '<template>\n  <v-card class="mx-auto" max-width="360">\n    <v-layout>\n      <v-system-bar class="ga-1" color="#4c00d5">\n        <v-icon icon="mdi-square" size="x-small"></v-icon>\n\n        <v-icon icon="mdi-circle" size="x-small"></v-icon>\n\n        <v-icon icon="mdi-triangle" size="x-small"></v-icon>\n      </v-system-bar>\n\n      <v-app-bar color="#6200ee" title="Drafts">\n        <template v-slot:prepend>\n          <v-app-bar-nav-icon></v-app-bar-nav-icon>\n        </template>\n\n        <template v-slot:append>\n          <v-btn icon="mdi-magnify"></v-btn>\n\n          <v-btn icon="mdi-dots-vertical"></v-btn>\n        </template>\n      </v-app-bar>\n\n      <v-main>\n        <v-empty-state\n          image="https://vuetifyjs.b-cdn.net/docs/images/components/v-empty-state/astro-dog.svg"\n          size="200"\n          text-width="250"\n        >\n          <template v-slot:media>\n            <v-img class="mb-8"></v-img>\n          </template>\n\n          <template v-slot:title>\n            <div class="text-h6 text-high-emphasis">Empty in drafts</div>\n          </template>\n\n          <template v-slot:text>\n            <div class="text-body-1">Save a draft message and it will show up here</div>\n          </template>\n        </v-empty-state>\n      </v-main>\n\n      <v-layout-item\n        class="text-end"\n        position="bottom"\n        size="80"\n        model-value\n      >\n        <v-btn\n          class="ma-4"\n          color="#4c00d5"\n          elevation="8"\n          icon="mdi-plus"\n        ></v-btn>\n      </v-layout-item>\n    </v-layout>\n  </v-card>\n</template>\n';
const _sfc_main$6 = {
  __name: "prop-actions",
  setup(__props) {
    function onClickAction() {
      alert("You clicked the action button");
    }
    return (_ctx, _cache) => {
      const _component_v_empty_state = resolveComponent("v-empty-state");
      return openBlock(), createBlock(_component_v_empty_state, {
        "action-text": "Retry Request",
        image: "https://cdn.vuetifyjs.com/docs/images/components/v-empty-state/connection.svg",
        text: "There might be a problem with your connection or our servers. Please check your internet connection or try again later. We appreciate your patience.",
        title: "Something Went Wrong",
        "onClick:action": onClickAction
      });
    };
  }
};
const __2 = _sfc_main$6;
const __2_raw = `<template>
  <v-empty-state
    action-text="Retry Request"
    image="https://cdn.vuetifyjs.com/docs/images/components/v-empty-state/connection.svg"
    text="There might be a problem with your connection or our servers. Please check your internet connection or try again later. We appreciate your patience."
    title="Something Went Wrong"
    @click:action="onClickAction"
  ></v-empty-state>
</template>

<script setup>
  function onClickAction () {
    alert('You clicked the action button')
  }
<\/script>

<script>
  export default {
    methods: {
      onClickAction () {
        alert('You clicked the action button')
      },
    },
  }
<\/script>
`;
const _sfc_main$5 = {
  __name: "prop-content",
  setup(__props) {
    function onClickAction() {
      alert("You clicked the action button");
    }
    return (_ctx, _cache) => {
      const _component_v_empty_state = resolveComponent("v-empty-state");
      return openBlock(), createBlock(_component_v_empty_state, {
        headline: "No Messages Yet",
        text: "You haven't received any messages yet. When you do, they'll appear here.",
        title: "Check back later.",
        "onClick:action": onClickAction
      });
    };
  }
};
const __3 = _sfc_main$5;
const __3_raw = `<template>
  <v-empty-state
    headline="No Messages Yet"
    text="You haven't received any messages yet. When you do, they'll appear here."
    title="Check back later."
    @click:action="onClickAction"
  ></v-empty-state>
</template>

<script setup>
  function onClickAction () {
    alert('You clicked the action button')
  }
<\/script>
`;
const _sfc_main$4 = {};
function _sfc_render$3(_ctx, _cache) {
  const _component_v_empty_state = resolveComponent("v-empty-state");
  return openBlock(), createBlock(_component_v_empty_state, {
    icon: "mdi-magnify",
    text: "Try adjusting your search terms or filters. Sometimes less specific terms or broader queries can help you find what you're looking for.",
    title: "We couldn't find a match."
  });
}
const __4 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["render", _sfc_render$3]]);
const __4_raw = `<template>
  <v-empty-state
    icon="mdi-magnify"
    text="Try adjusting your search terms or filters. Sometimes less specific terms or broader queries can help you find what you're looking for."
    title="We couldn't find a match."
  ></v-empty-state>
</template>
`;
const _sfc_main$3 = {};
const _hoisted_1$1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-subtitle-2 mt-8" }, " Manage your inventory transfers ", -1);
const _hoisted_2$1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-caption" }, " Track and receive your incoming inventory from suppliers ", -1);
function _sfc_render$2(_ctx, _cache) {
  const _component_v_btn = resolveComponent("v-btn");
  const _component_v_empty_state = resolveComponent("v-empty-state");
  return openBlock(), createBlock(_component_v_empty_state, { image: "https://cdn.vuetifyjs.com/docs/images/components/v-empty-state/teamwork.png" }, {
    title: withCtx(() => [
      _hoisted_1$1
    ]),
    text: withCtx(() => [
      _hoisted_2$1
    ]),
    actions: withCtx(() => [
      createVNode(_component_v_btn, {
        class: "text-none",
        color: "white",
        elevation: "1",
        rounded: "lg",
        size: "small",
        text: "Learn more",
        width: "96"
      }),
      createVNode(_component_v_btn, {
        class: "text-none",
        elevation: "1",
        rounded: "lg",
        size: "small",
        text: "Add transfer",
        width: "96"
      })
    ]),
    _: 1
  });
}
const __5 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["render", _sfc_render$2]]);
const __5_raw = '<template>\n  <v-empty-state image="https://cdn.vuetifyjs.com/docs/images/components/v-empty-state/teamwork.png">\n    <template v-slot:title>\n      <div class="text-subtitle-2 mt-8">\n        Manage your inventory transfers\n      </div>\n    </template>\n\n    <template v-slot:text>\n      <div class="text-caption">\n        Track and receive your incoming inventory from suppliers\n      </div>\n    </template>\n\n    <template v-slot:actions>\n      <v-btn\n        class="text-none"\n        color="white"\n        elevation="1"\n        rounded="lg"\n        size="small"\n        text="Learn more"\n        width="96"\n      ></v-btn>\n\n      <v-btn\n        class="text-none"\n        elevation="1"\n        rounded="lg"\n        size="small"\n        text="Add transfer"\n        width="96"\n      ></v-btn>\n    </template>\n  </v-empty-state>\n</template>\n';
const _sfc_main$2 = {};
function _sfc_render$1(_ctx, _cache) {
  const _component_v_card = resolveComponent("v-card");
  const _component_v_col = resolveComponent("v-col");
  const _component_v_row = resolveComponent("v-row");
  const _component_v_container = resolveComponent("v-container");
  const _component_v_empty_state = resolveComponent("v-empty-state");
  return openBlock(), createBlock(_component_v_empty_state, {
    headline: "Welcome,",
    icon: "$vuetify",
    title: "What would you like to do today?"
  }, {
    default: withCtx(() => [
      createVNode(_component_v_container, null, {
        default: withCtx(() => [
          createVNode(_component_v_row, null, {
            default: withCtx(() => [
              createVNode(_component_v_col, {
                cols: "12",
                md: "6"
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_card, {
                    href: "https://vuetifyjs.com/introduction/why-vuetify/#feature-guides",
                    "prepend-icon": "$vuetify",
                    target: "_blank",
                    text: "Start with our dedicated feature guides",
                    title: "Learn Vuetify"
                  })
                ]),
                _: 1
              }),
              createVNode(_component_v_col, {
                cols: "12",
                md: "6"
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_card, {
                    href: "https://play.vuetifyjs.com",
                    "prepend-icon": "$vuetify-play",
                    target: "_blank",
                    text: "Test Vuetify out in our playground",
                    title: "Create a Playground"
                  })
                ]),
                _: 1
              }),
              createVNode(_component_v_col, {
                cols: "12",
                md: "6"
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_card, {
                    href: "https://bin.vuetifyjs.com",
                    "prepend-icon": "mdi-delete",
                    target: "_blank",
                    text: "Create a new bin to store your code",
                    title: "Create a Bin"
                  })
                ]),
                _: 1
              }),
              createVNode(_component_v_col, {
                cols: "12",
                md: "6"
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_card, {
                    href: "https://issues.vuetifyjs.com",
                    "prepend-icon": "$warning",
                    target: "_blank",
                    text: "File a bug report for Vuetify",
                    title: "Report a Bug"
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      })
    ]),
    _: 1
  });
}
const __6 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["render", _sfc_render$1]]);
const __6_raw = '<template>\n  <v-empty-state\n    headline="Welcome,"\n    icon="$vuetify"\n    title="What would you like to do today?"\n  >\n    <v-container>\n      <v-row>\n        <v-col cols="12" md="6">\n          <v-card\n            href="https://vuetifyjs.com/introduction/why-vuetify/#feature-guides"\n            prepend-icon="$vuetify"\n            target="_blank"\n            text="Start with our dedicated feature guides"\n            title="Learn Vuetify"\n          ></v-card>\n        </v-col>\n\n        <v-col cols="12" md="6">\n          <v-card\n            href="https://play.vuetifyjs.com"\n            prepend-icon="$vuetify-play"\n            target="_blank"\n            text="Test Vuetify out in our playground"\n            title="Create a Playground"\n          ></v-card>\n        </v-col>\n\n        <v-col cols="12" md="6">\n          <v-card\n            href="https://bin.vuetifyjs.com"\n            prepend-icon="mdi-delete"\n            target="_blank"\n            text="Create a new bin to store your code"\n            title="Create a Bin"\n          ></v-card>\n        </v-col>\n\n        <v-col cols="12" md="6">\n          <v-card\n            href="https://issues.vuetifyjs.com"\n            prepend-icon="$warning"\n            target="_blank"\n            text="File a bug report for Vuetify"\n            title="Report a Bug"\n          ></v-card>\n        </v-col>\n      </v-row>\n    </v-container>\n  </v-empty-state>\n</template>\n';
const _sfc_main$1 = {};
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-h4" }, " All Done For Now! ", -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("div", { class: "text-h6" }, " You're all caught up. ", -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("div", { class: "text-medium-emphasis text-caption" }, " Great job on completing all your tasks! This might be a good time to relax or consider planning your next set of goals. If you think of something new, just hit the button below to add a new task. ", -1);
function _sfc_render(_ctx, _cache) {
  const _component_v_icon = resolveComponent("v-icon");
  const _component_v_empty_state = resolveComponent("v-empty-state");
  return openBlock(), createBlock(_component_v_empty_state, { icon: "$success" }, {
    media: withCtx(() => [
      createVNode(_component_v_icon, { color: "surface-variant" })
    ]),
    headline: withCtx(() => [
      _hoisted_1
    ]),
    title: withCtx(() => [
      _hoisted_2
    ]),
    text: withCtx(() => [
      _hoisted_3
    ]),
    _: 1
  });
}
const __7 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["render", _sfc_render]]);
const __7_raw = `<template>
  <v-empty-state icon="$success">
    <template v-slot:media>
      <v-icon color="surface-variant"></v-icon>
    </template>

    <template v-slot:headline>
      <div class="text-h4">
        All Done For Now!
      </div>
    </template>

    <template v-slot:title>
      <div class="text-h6">
        You're all caught up.
      </div>
    </template>

    <template v-slot:text>
      <div class="text-medium-emphasis text-caption">
        Great job on completing all your tasks! This might be a good time to relax or consider planning your next set of goals. If you think of something new, just hit the button below to add a new task.
      </div>
    </template>
  </v-empty-state>
</template>
`;
const name = "v-empty-state";
const _sfc_main = {
  __name: "usage",
  setup(__props) {
    const model = ref("default");
    const options = [];
    const props = computed(() => {
      return {
        headline: "Whoops, 404",
        title: "Page not found",
        text: "The page you were looking for does not exist",
        image: "https://vuetifyjs.b-cdn.net/docs/images/logos/v.png"
      };
    });
    const slots = computed(() => {
      return "";
    });
    const code = computed(() => {
      return `<${name}${propsToString(props.value)}>${slots.value}</${name}>`;
    });
    return (_ctx, _cache) => {
      const _component_v_empty_state = resolveComponent("v-empty-state");
      const _component_ExamplesUsageExample = _sfc_main$9;
      return openBlock(), createBlock(_component_ExamplesUsageExample, {
        modelValue: unref(model),
        "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(model) ? model.value = $event : null),
        code: unref(code),
        name,
        options
      }, {
        default: withCtx(() => [
          createVNode(_component_v_empty_state, normalizeProps(guardReactiveProps(unref(props))), null, 16)
        ]),
        _: 1
      }, 8, ["modelValue", "code"]);
    };
  }
};
const __8 = _sfc_main;
const __8_raw = `<template>
  <ExamplesUsageExample
    v-model="model"
    :code="code"
    :name="name"
    :options="options"
  >
    <v-empty-state
      v-bind="props"
    ></v-empty-state>
  </ExamplesUsageExample>
</template>

<script setup>
  const name = 'v-empty-state'
  const model = ref('default')
  const options = []

  const props = computed(() => {
    return {
      headline: 'Whoops, 404',
      title: 'Page not found',
      text: 'The page you were looking for does not exist',
      image: 'https://vuetifyjs.b-cdn.net/docs/images/logos/v.png',
    }
  })

  const slots = computed(() => {
    return ''
  })

  const code = computed(() => {
    return \`<\${name}\${propsToString(props.value)}>\${slots.value}</\${name}>\`
  })
<\/script>
`;
const vEmptyState = {
  "misc-astro-cat": {
    component: __0,
    source: __0_raw
  },
  "misc-astro-dog": {
    component: __1,
    source: __1_raw
  },
  "prop-actions": {
    component: __2,
    source: __2_raw
  },
  "prop-content": {
    component: __3,
    source: __3_raw
  },
  "prop-media": {
    component: __4,
    source: __4_raw
  },
  "slot-actions": {
    component: __5,
    source: __5_raw
  },
  "slot-default": {
    component: __6,
    source: __6_raw
  },
  "slot-title": {
    component: __7,
    source: __7_raw
  },
  "usage": {
    component: __8,
    source: __8_raw
  }
};
export {
  vEmptyState as default
};
