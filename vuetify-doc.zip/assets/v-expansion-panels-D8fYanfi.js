import { J as ref, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, b as createVNode, h as createTextVNode, l as createElementBlock, t as toDisplayString, e as createBaseVNode, y as _export_sfc, F as Fragment, v as renderList, j as computed, ag as propsToString, ak as normalizeProps, al as guardReactiveProps, f as unref, E as isRef } from "./index-DGybHjCP.js";
import { _ as _sfc_main$8 } from "./UsageExample-M8CmNipa.js";
const _hoisted_1$4 = { key: "0" };
const _hoisted_2$2 = { key: "1" };
const _hoisted_3$1 = { key: "0" };
const _hoisted_4$1 = { key: "1" };
const _hoisted_5 = /* @__PURE__ */ createBaseVNode("br", null, null, -1);
const _hoisted_6 = /* @__PURE__ */ createBaseVNode("a", { href: "#" }, "Learn more", -1);
const _hoisted_7 = { key: 0 };
const _sfc_main$7 = {
  __name: "misc-advanced",
  setup(__props) {
    const locations = ["Australia", "Barbados", "Chile", "Denmark", "Ecuador", "France"];
    const trip = ref({
      name: "",
      location: null,
      start: null,
      end: null
    });
    return (_ctx, _cache) => {
      const _component_v_col = resolveComponent("v-col");
      const _component_v_fade_transition = resolveComponent("v-fade-transition");
      const _component_v_row = resolveComponent("v-row");
      const _component_v_expansion_panel_title = resolveComponent("v-expansion-panel-title");
      const _component_v_text_field = resolveComponent("v-text-field");
      const _component_v_expansion_panel_text = resolveComponent("v-expansion-panel-text");
      const _component_v_expansion_panel = resolveComponent("v-expansion-panel");
      const _component_v_spacer = resolveComponent("v-spacer");
      const _component_v_select = resolveComponent("v-select");
      const _component_v_divider = resolveComponent("v-divider");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_card_actions = resolveComponent("v-card-actions");
      const _component_v_expansion_panels = resolveComponent("v-expansion-panels");
      return openBlock(), createBlock(_component_v_expansion_panels, null, {
        default: withCtx(() => [
          createVNode(_component_v_expansion_panel, null, {
            default: withCtx(() => [
              createVNode(_component_v_expansion_panel_title, null, {
                default: withCtx(({ expanded }) => [
                  createVNode(_component_v_row, { "no-gutters": "" }, {
                    default: withCtx(() => [
                      createVNode(_component_v_col, {
                        class: "d-flex justify-start",
                        cols: "4"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" Trip name ")
                        ]),
                        _: 1
                      }),
                      createVNode(_component_v_col, {
                        class: "text-grey",
                        cols: "8"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_v_fade_transition, { "leave-absolute": "" }, {
                            default: withCtx(() => [
                              expanded ? (openBlock(), createElementBlock("span", _hoisted_1$4, " Enter a name for the trip ")) : (openBlock(), createElementBlock("span", _hoisted_2$2, toDisplayString(trip.value.name), 1))
                            ]),
                            _: 2
                          }, 1024)
                        ]),
                        _: 2
                      }, 1024)
                    ]),
                    _: 2
                  }, 1024)
                ]),
                _: 1
              }),
              createVNode(_component_v_expansion_panel_text, null, {
                default: withCtx(() => [
                  createVNode(_component_v_text_field, {
                    modelValue: trip.value.name,
                    "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => trip.value.name = $event),
                    placeholder: "Caribbean Cruise",
                    "hide-details": ""
                  }, null, 8, ["modelValue"])
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_expansion_panel, null, {
            default: withCtx(() => [
              createVNode(_component_v_expansion_panel_title, null, {
                default: withCtx(({ expanded }) => [
                  createVNode(_component_v_row, { "no-gutters": "" }, {
                    default: withCtx(() => [
                      createVNode(_component_v_col, {
                        class: "d-flex justify-start",
                        cols: "4"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" Location ")
                        ]),
                        _: 1
                      }),
                      createVNode(_component_v_col, {
                        class: "text--secondary",
                        cols: "8"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_v_fade_transition, { "leave-absolute": "" }, {
                            default: withCtx(() => [
                              expanded ? (openBlock(), createElementBlock("span", _hoisted_3$1, " Select trip destination ")) : (openBlock(), createElementBlock("span", _hoisted_4$1, toDisplayString(trip.value.location), 1))
                            ]),
                            _: 2
                          }, 1024)
                        ]),
                        _: 2
                      }, 1024)
                    ]),
                    _: 2
                  }, 1024)
                ]),
                _: 1
              }),
              createVNode(_component_v_expansion_panel_text, null, {
                default: withCtx(() => [
                  createVNode(_component_v_row, { "no-gutters": "" }, {
                    default: withCtx(() => [
                      createVNode(_component_v_spacer),
                      createVNode(_component_v_col, { cols: "5" }, {
                        default: withCtx(() => [
                          createVNode(_component_v_select, {
                            modelValue: trip.value.location,
                            "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => trip.value.location = $event),
                            items: locations,
                            variant: "solo",
                            chips: "",
                            flat: ""
                          }, null, 8, ["modelValue"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_v_divider, {
                        class: "mx-4",
                        vertical: ""
                      }),
                      createVNode(_component_v_col, { cols: "3" }, {
                        default: withCtx(() => [
                          createTextVNode(" Select your destination of choice "),
                          _hoisted_5,
                          _hoisted_6
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_card_actions, null, {
                    default: withCtx(() => [
                      createVNode(_component_v_spacer),
                      createVNode(_component_v_btn, {
                        color: "secondary",
                        variant: "text"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" Cancel ")
                        ]),
                        _: 1
                      }),
                      createVNode(_component_v_btn, {
                        color: "primary",
                        variant: "text"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" Save ")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_expansion_panel, null, {
            default: withCtx(() => [
              createVNode(_component_v_expansion_panel_title, null, {
                default: withCtx(({ expanded }) => [
                  createVNode(_component_v_row, { "no-gutters": "" }, {
                    default: withCtx(() => [
                      createVNode(_component_v_col, {
                        class: "d-flex justify-start",
                        cols: "4"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" Start and end dates ")
                        ]),
                        _: 1
                      }),
                      createVNode(_component_v_col, {
                        class: "text--secondary",
                        cols: "8"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_v_fade_transition, { "leave-absolute": "" }, {
                            default: withCtx(() => [
                              expanded ? (openBlock(), createElementBlock("span", _hoisted_7, "When do you want to travel?")) : (openBlock(), createBlock(_component_v_row, {
                                key: 1,
                                style: { "width": "100%" },
                                "no-gutters": ""
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_v_col, {
                                    class: "d-flex justify-start",
                                    cols: "6"
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode(" Start date: " + toDisplayString(trip.value.start || "Not set"), 1)
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_v_col, {
                                    class: "d-flex justify-start",
                                    cols: "6"
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode(" End date: " + toDisplayString(trip.value.end || "Not set"), 1)
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }))
                            ]),
                            _: 2
                          }, 1024)
                        ]),
                        _: 2
                      }, 1024)
                    ]),
                    _: 2
                  }, 1024)
                ]),
                _: 1
              }),
              createVNode(_component_v_expansion_panel_text, null, {
                default: withCtx(() => [
                  createVNode(_component_v_row, {
                    justify: "space-around",
                    "no-gutters": ""
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_v_col, { cols: "3" }, {
                        default: withCtx(() => [
                          createVNode(_component_v_text_field, {
                            modelValue: trip.value.start,
                            "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => trip.value.start = $event),
                            label: "Start date",
                            type: "date"
                          }, null, 8, ["modelValue"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_v_col, { cols: "3" }, {
                        default: withCtx(() => [
                          createVNode(_component_v_text_field, {
                            modelValue: trip.value.end,
                            "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => trip.value.end = $event),
                            label: "End date",
                            type: "date"
                          }, null, 8, ["modelValue"])
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __0 = _sfc_main$7;
const __0_raw = `<template>
  <v-expansion-panels>
    <v-expansion-panel>
      <v-expansion-panel-title>
        <template v-slot:default="{ expanded }">
          <v-row no-gutters>
            <v-col class="d-flex justify-start" cols="4">
              Trip name
            </v-col>
            <v-col
              class="text-grey"
              cols="8"
            >
              <v-fade-transition leave-absolute>
                <span
                  v-if="expanded"
                  key="0"
                >
                  Enter a name for the trip
                </span>
                <span
                  v-else
                  key="1"
                >
                  {{ trip.name }}
                </span>
              </v-fade-transition>
            </v-col>
          </v-row>
        </template>
      </v-expansion-panel-title>
      <v-expansion-panel-text>
        <v-text-field
          v-model="trip.name"
          placeholder="Caribbean Cruise"
          hide-details
        ></v-text-field>
      </v-expansion-panel-text>
    </v-expansion-panel>

    <v-expansion-panel>
      <v-expansion-panel-title v-slot="{ expanded }">
        <v-row no-gutters>
          <v-col class="d-flex justify-start" cols="4">
            Location
          </v-col>
          <v-col
            class="text--secondary"
            cols="8"
          >
            <v-fade-transition leave-absolute>
              <span
                v-if="expanded"
                key="0"
              >
                Select trip destination
              </span>
              <span
                v-else
                key="1"
              >
                {{ trip.location }}
              </span>
            </v-fade-transition>
          </v-col>
        </v-row>
      </v-expansion-panel-title>
      <v-expansion-panel-text>
        <v-row no-gutters>
          <v-spacer></v-spacer>
          <v-col cols="5">
            <v-select
              v-model="trip.location"
              :items="locations"
              variant="solo"
              chips
              flat
            ></v-select>
          </v-col>

          <v-divider
            class="mx-4"
            vertical
          ></v-divider>

          <v-col cols="3">
            Select your destination of choice
            <br>
            <a href="#">Learn more</a>
          </v-col>
        </v-row>

        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn
            color="secondary"
            variant="text"
          >
            Cancel
          </v-btn>
          <v-btn
            color="primary"
            variant="text"
          >
            Save
          </v-btn>
        </v-card-actions>
      </v-expansion-panel-text>
    </v-expansion-panel>

    <v-expansion-panel>
      <v-expansion-panel-title v-slot="{ expanded }">
        <v-row no-gutters>
          <v-col class="d-flex justify-start" cols="4">
            Start and end dates
          </v-col>
          <v-col
            class="text--secondary"
            cols="8"
          >
            <v-fade-transition leave-absolute>
              <span v-if="expanded">When do you want to travel?</span>
              <v-row
                v-else
                style="width: 100%"
                no-gutters
              >
                <v-col class="d-flex justify-start" cols="6">
                  Start date: {{ trip.start || 'Not set' }}
                </v-col>
                <v-col class="d-flex justify-start" cols="6">
                  End date: {{ trip.end || 'Not set' }}
                </v-col>
              </v-row>
            </v-fade-transition>
          </v-col>
        </v-row>
      </v-expansion-panel-title>
      <v-expansion-panel-text>
        <v-row
          justify="space-around"
          no-gutters
        >
          <v-col cols="3">
            <v-text-field
              v-model="trip.start"
              label="Start date"
              type="date"
            ></v-text-field>
          </v-col>

          <v-col cols="3">
            <v-text-field
              v-model="trip.end"
              label="End date"
              type="date"
            ></v-text-field>
          </v-col>
        </v-row>
      </v-expansion-panel-text>
    </v-expansion-panel>
  </v-expansion-panels>
</template>

<script setup>
  import { ref } from 'vue'

  const locations = ['Australia', 'Barbados', 'Chile', 'Denmark', 'Ecuador', 'France']

  const trip = ref({
    name: '',
    location: null,
    start: null,
    end: null,
  })
<\/script>

<script>
  export default {
    data: () => ({
      trip: {
        name: '',
        location: null,
        start: null,
        end: null,
      },
      locations: ['Australia', 'Barbados', 'Chile', 'Denmark', 'Ecuador', 'France'],
    }),
  }
<\/script>
`;
const _sfc_main$6 = {};
function _sfc_render$2(_ctx, _cache) {
  const _component_v_expansion_panel_title = resolveComponent("v-expansion-panel-title");
  const _component_v_expansion_panel_text = resolveComponent("v-expansion-panel-text");
  const _component_v_expansion_panel = resolveComponent("v-expansion-panel");
  const _component_v_expansion_panels = resolveComponent("v-expansion-panels");
  const _component_v_icon = resolveComponent("v-icon");
  return openBlock(), createElementBlock("div", null, [
    createVNode(_component_v_expansion_panels, { class: "mb-6" }, {
      default: withCtx(() => [
        (openBlock(), createElementBlock(Fragment, null, renderList(3, (i) => {
          return createVNode(_component_v_expansion_panel, { key: i }, {
            default: withCtx(() => [
              createVNode(_component_v_expansion_panel_title, { "expand-icon": "mdi-menu-down" }, {
                default: withCtx(() => [
                  createTextVNode(" Item ")
                ]),
                _: 1
              }),
              createVNode(_component_v_expansion_panel_text, null, {
                default: withCtx(() => [
                  createTextVNode("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.")
                ]),
                _: 1
              })
            ]),
            _: 2
          }, 1024);
        }), 64))
      ]),
      _: 1
    }),
    createVNode(_component_v_expansion_panels, null, {
      default: withCtx(() => [
        createVNode(_component_v_expansion_panel, null, {
          default: withCtx(() => [
            createVNode(_component_v_expansion_panel_title, {
              "collapse-icon": "mdi-minus",
              "expand-icon": "mdi-plus"
            }, {
              default: withCtx(() => [
                createTextVNode(" Item ")
              ]),
              _: 1
            }),
            createVNode(_component_v_expansion_panel_text, null, {
              default: withCtx(() => [
                createTextVNode(" Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. ")
              ]),
              _: 1
            })
          ]),
          _: 1
        }),
        createVNode(_component_v_expansion_panel, null, {
          default: withCtx(() => [
            createVNode(_component_v_expansion_panel_title, null, {
              actions: withCtx(({ expanded }) => [
                createVNode(_component_v_icon, {
                  color: !expanded ? "teal" : "",
                  icon: expanded ? "mdi-pencil" : "mdi-check"
                }, null, 8, ["color", "icon"])
              ]),
              default: withCtx(() => [
                createTextVNode(" Item ")
              ]),
              _: 1
            }),
            createVNode(_component_v_expansion_panel_text, null, {
              default: withCtx(() => [
                createTextVNode(" Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. ")
              ]),
              _: 1
            })
          ]),
          _: 1
        }),
        createVNode(_component_v_expansion_panel, null, {
          default: withCtx(() => [
            createVNode(_component_v_expansion_panel_title, { "disable-icon-rotate": "" }, {
              actions: withCtx(() => [
                createVNode(_component_v_icon, {
                  color: "error",
                  icon: "mdi-alert-circle"
                })
              ]),
              default: withCtx(() => [
                createTextVNode(" Item ")
              ]),
              _: 1
            }),
            createVNode(_component_v_expansion_panel_text, null, {
              default: withCtx(() => [
                createTextVNode(" Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. ")
              ]),
              _: 1
            })
          ]),
          _: 1
        })
      ]),
      _: 1
    })
  ]);
}
const __1 = /* @__PURE__ */ _export_sfc(_sfc_main$6, [["render", _sfc_render$2]]);
const __1_raw = `<template>
  <div>
    <v-expansion-panels class="mb-6">
      <v-expansion-panel
        v-for="i in 3"
        :key="i"
      >
        <v-expansion-panel-title expand-icon="mdi-menu-down">
          Item
        </v-expansion-panel-title>
        <v-expansion-panel-text>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</v-expansion-panel-text>
      </v-expansion-panel>
    </v-expansion-panels>

    <v-expansion-panels>
      <v-expansion-panel>
        <v-expansion-panel-title collapse-icon="mdi-minus" expand-icon="mdi-plus">
          Item
        </v-expansion-panel-title>
        <v-expansion-panel-text>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
        </v-expansion-panel-text>
      </v-expansion-panel>

      <v-expansion-panel>
        <v-expansion-panel-title>
          Item
          <template v-slot:actions="{ expanded }">
            <v-icon :color="!expanded ? 'teal' : ''" :icon="expanded ? 'mdi-pencil' : 'mdi-check'"></v-icon>
          </template>
        </v-expansion-panel-title>
        <v-expansion-panel-text>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
        </v-expansion-panel-text>
      </v-expansion-panel>

      <v-expansion-panel>
        <v-expansion-panel-title disable-icon-rotate>
          Item
          <template v-slot:actions>
            <v-icon color="error" icon="mdi-alert-circle">
            </v-icon>
          </template>
        </v-expansion-panel-title>
        <v-expansion-panel-text>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
        </v-expansion-panel-text>
      </v-expansion-panel>
    </v-expansion-panels>
  </div>
</template>
`;
const _hoisted_1$3 = { class: "d-flex" };
const _sfc_main$5 = {
  __name: "prop-disabled",
  setup(__props) {
    const panel = ref([0, 1]);
    const disabled = ref(false);
    return (_ctx, _cache) => {
      const _component_v_checkbox = resolveComponent("v-checkbox");
      const _component_v_expansion_panel_title = resolveComponent("v-expansion-panel-title");
      const _component_v_expansion_panel_text = resolveComponent("v-expansion-panel-text");
      const _component_v_expansion_panel = resolveComponent("v-expansion-panel");
      const _component_v_expansion_panels = resolveComponent("v-expansion-panels");
      return openBlock(), createElementBlock("div", null, [
        createBaseVNode("div", _hoisted_1$3, [
          createVNode(_component_v_checkbox, {
            modelValue: disabled.value,
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => disabled.value = $event),
            label: "Disabled"
          }, null, 8, ["modelValue"])
        ]),
        createVNode(_component_v_expansion_panels, {
          modelValue: panel.value,
          "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => panel.value = $event),
          disabled: disabled.value,
          multiple: ""
        }, {
          default: withCtx(() => [
            createVNode(_component_v_expansion_panel, null, {
              default: withCtx(() => [
                createVNode(_component_v_expansion_panel_title, null, {
                  default: withCtx(() => [
                    createTextVNode("Panel 1")
                  ]),
                  _: 1
                }),
                createVNode(_component_v_expansion_panel_text, null, {
                  default: withCtx(() => [
                    createTextVNode(" Some content ")
                  ]),
                  _: 1
                })
              ]),
              _: 1
            }),
            createVNode(_component_v_expansion_panel, null, {
              default: withCtx(() => [
                createVNode(_component_v_expansion_panel_title, null, {
                  default: withCtx(() => [
                    createTextVNode("Panel 2")
                  ]),
                  _: 1
                }),
                createVNode(_component_v_expansion_panel_text, null, {
                  default: withCtx(() => [
                    createTextVNode(" Some content ")
                  ]),
                  _: 1
                })
              ]),
              _: 1
            }),
            createVNode(_component_v_expansion_panel, null, {
              default: withCtx(() => [
                createVNode(_component_v_expansion_panel_title, null, {
                  default: withCtx(() => [
                    createTextVNode("Panel 3")
                  ]),
                  _: 1
                }),
                createVNode(_component_v_expansion_panel_text, null, {
                  default: withCtx(() => [
                    createTextVNode(" Some content ")
                  ]),
                  _: 1
                })
              ]),
              _: 1
            })
          ]),
          _: 1
        }, 8, ["modelValue", "disabled"])
      ]);
    };
  }
};
const __2 = _sfc_main$5;
const __2_raw = `<template>
  <div>
    <div class="d-flex">
      <v-checkbox
        v-model="disabled"
        label="Disabled"
      ></v-checkbox>
    </div>

    <v-expansion-panels
      v-model="panel"
      :disabled="disabled"
      multiple
    >
      <v-expansion-panel>
        <v-expansion-panel-title>Panel 1</v-expansion-panel-title>
        <v-expansion-panel-text>
          Some content
        </v-expansion-panel-text>
      </v-expansion-panel>

      <v-expansion-panel>
        <v-expansion-panel-title>Panel 2</v-expansion-panel-title>
        <v-expansion-panel-text>
          Some content
        </v-expansion-panel-text>
      </v-expansion-panel>

      <v-expansion-panel>
        <v-expansion-panel-title>Panel 3</v-expansion-panel-title>
        <v-expansion-panel-text>
          Some content
        </v-expansion-panel-text>
      </v-expansion-panel>
    </v-expansion-panels>
  </div>
</template>

<script setup>
  import { ref } from 'vue'

  const panel = ref([0, 1])
  const disabled = ref(false)
<\/script>

<script>
  export default {
    data: () => ({
      panel: [0, 1],
      disabled: false,
    }),
  }
<\/script>
`;
const _sfc_main$4 = {};
function _sfc_render$1(_ctx, _cache) {
  const _component_v_expansion_panel_title = resolveComponent("v-expansion-panel-title");
  const _component_v_expansion_panel_text = resolveComponent("v-expansion-panel-text");
  const _component_v_expansion_panel = resolveComponent("v-expansion-panel");
  const _component_v_expansion_panels = resolveComponent("v-expansion-panels");
  return openBlock(), createBlock(_component_v_expansion_panels, { focusable: "" }, {
    default: withCtx(() => [
      (openBlock(), createElementBlock(Fragment, null, renderList(5, (i) => {
        return createVNode(_component_v_expansion_panel, { key: i }, {
          default: withCtx(() => [
            createVNode(_component_v_expansion_panel_title, null, {
              default: withCtx(() => [
                createTextVNode("Item")
              ]),
              _: 1
            }),
            createVNode(_component_v_expansion_panel_text, null, {
              default: withCtx(() => [
                createTextVNode(" Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. ")
              ]),
              _: 1
            })
          ]),
          _: 2
        }, 1024);
      }), 64))
    ]),
    _: 1
  });
}
const __3 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["render", _sfc_render$1]]);
const __3_raw = '<template>\n  <v-expansion-panels focusable>\n    <v-expansion-panel\n      v-for="i in 5"\n      :key="i"\n    >\n      <v-expansion-panel-title>Item</v-expansion-panel-title>\n      <v-expansion-panel-text>\n        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.\n      </v-expansion-panel-text>\n    </v-expansion-panel>\n  </v-expansion-panels>\n</template>\n';
const _hoisted_1$2 = { class: "text-center d-flex pb-4" };
const _hoisted_2$1 = { class: "pb-4" };
const _sfc_main$3 = {
  __name: "prop-model",
  setup(__props) {
    const panel = ref([]);
    function all() {
      panel.value = ["foo", "bar", "baz"];
    }
    function none() {
      panel.value = [];
    }
    return (_ctx, _cache) => {
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_expansion_panel = resolveComponent("v-expansion-panel");
      const _component_v_expansion_panels = resolveComponent("v-expansion-panels");
      return openBlock(), createElementBlock("div", null, [
        createBaseVNode("div", _hoisted_1$2, [
          createVNode(_component_v_btn, {
            class: "ma-2",
            onClick: all
          }, {
            default: withCtx(() => [
              createTextVNode(" All ")
            ]),
            _: 1
          }),
          createVNode(_component_v_btn, {
            class: "ma-2",
            onClick: none
          }, {
            default: withCtx(() => [
              createTextVNode(" None ")
            ]),
            _: 1
          })
        ]),
        createBaseVNode("div", _hoisted_2$1, "v-model " + toDisplayString(panel.value), 1),
        createVNode(_component_v_expansion_panels, {
          modelValue: panel.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => panel.value = $event),
          multiple: ""
        }, {
          default: withCtx(() => [
            createVNode(_component_v_expansion_panel, {
              text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
              title: "Foo",
              value: "foo"
            }),
            createVNode(_component_v_expansion_panel, {
              text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
              title: "Bar",
              value: "bar"
            }),
            createVNode(_component_v_expansion_panel, {
              text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
              title: "Baz",
              value: "baz"
            })
          ]),
          _: 1
        }, 8, ["modelValue"])
      ]);
    };
  }
};
const __4 = _sfc_main$3;
const __4_raw = `<template>
  <div>
    <div class="text-center d-flex pb-4">
      <v-btn class="ma-2" @click="all">
        All
      </v-btn>
      <v-btn class="ma-2" @click="none">
        None
      </v-btn>
    </div>

    <div class="pb-4">v-model {{ panel }}</div>

    <v-expansion-panels
      v-model="panel"
      multiple
    >
      <v-expansion-panel
        text="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
        title="Foo"
        value="foo"
      ></v-expansion-panel>

      <v-expansion-panel
        text="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
        title="Bar"
        value="bar"
      ></v-expansion-panel>

      <v-expansion-panel
        text="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
        title="Baz"
        value="baz"
      ></v-expansion-panel>
    </v-expansion-panels>
  </div>
</template>

<script setup>
  import { ref } from 'vue'

  const panel = ref([])
  function all () {
    panel.value = ['foo', 'bar', 'baz']
  }
  function none () {
    panel.value = []
  }
<\/script>

<script>
  export default {
    data () {
      return {
        panel: [],
      }
    },
    methods: {
      all () {
        this.panel = ['foo', 'bar', 'baz']
      },
      none () {
        this.panel = []
      },
    },
  }
<\/script>
`;
const _hoisted_1$1 = { class: "d-flex" };
const _sfc_main$2 = {
  __name: "prop-readonly",
  setup(__props) {
    const panel = ref([0, 1]);
    const readonly = ref(false);
    return (_ctx, _cache) => {
      const _component_v_checkbox = resolveComponent("v-checkbox");
      const _component_v_expansion_panel_title = resolveComponent("v-expansion-panel-title");
      const _component_v_expansion_panel_text = resolveComponent("v-expansion-panel-text");
      const _component_v_expansion_panel = resolveComponent("v-expansion-panel");
      const _component_v_expansion_panels = resolveComponent("v-expansion-panels");
      return openBlock(), createElementBlock("div", null, [
        createBaseVNode("div", _hoisted_1$1, [
          createVNode(_component_v_checkbox, {
            modelValue: readonly.value,
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => readonly.value = $event),
            label: "Readonly"
          }, null, 8, ["modelValue"])
        ]),
        createVNode(_component_v_expansion_panels, {
          modelValue: panel.value,
          "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => panel.value = $event),
          readonly: readonly.value,
          multiple: ""
        }, {
          default: withCtx(() => [
            createVNode(_component_v_expansion_panel, null, {
              default: withCtx(() => [
                createVNode(_component_v_expansion_panel_title, null, {
                  default: withCtx(() => [
                    createTextVNode("Panel 1")
                  ]),
                  _: 1
                }),
                createVNode(_component_v_expansion_panel_text, null, {
                  default: withCtx(() => [
                    createTextVNode(" Some content ")
                  ]),
                  _: 1
                })
              ]),
              _: 1
            }),
            createVNode(_component_v_expansion_panel, null, {
              default: withCtx(() => [
                createVNode(_component_v_expansion_panel_title, null, {
                  default: withCtx(() => [
                    createTextVNode("Panel 2")
                  ]),
                  _: 1
                }),
                createVNode(_component_v_expansion_panel_text, null, {
                  default: withCtx(() => [
                    createTextVNode(" Some content ")
                  ]),
                  _: 1
                })
              ]),
              _: 1
            }),
            createVNode(_component_v_expansion_panel, null, {
              default: withCtx(() => [
                createVNode(_component_v_expansion_panel_title, null, {
                  default: withCtx(() => [
                    createTextVNode("Panel 3")
                  ]),
                  _: 1
                }),
                createVNode(_component_v_expansion_panel_text, null, {
                  default: withCtx(() => [
                    createTextVNode(" Some content ")
                  ]),
                  _: 1
                })
              ]),
              _: 1
            })
          ]),
          _: 1
        }, 8, ["modelValue", "readonly"])
      ]);
    };
  }
};
const __5 = _sfc_main$2;
const __5_raw = `<template>
  <div>
    <div class="d-flex">
      <v-checkbox
        v-model="readonly"
        label="Readonly"
      ></v-checkbox>
    </div>

    <v-expansion-panels
      v-model="panel"
      :readonly="readonly"
      multiple
    >
      <v-expansion-panel>
        <v-expansion-panel-title>Panel 1</v-expansion-panel-title>
        <v-expansion-panel-text>
          Some content
        </v-expansion-panel-text>
      </v-expansion-panel>

      <v-expansion-panel>
        <v-expansion-panel-title>Panel 2</v-expansion-panel-title>
        <v-expansion-panel-text>
          Some content
        </v-expansion-panel-text>
      </v-expansion-panel>

      <v-expansion-panel>
        <v-expansion-panel-title>Panel 3</v-expansion-panel-title>
        <v-expansion-panel-text>
          Some content
        </v-expansion-panel-text>
      </v-expansion-panel>
    </v-expansion-panels>
  </div>
</template>

<script setup>
  import { ref } from 'vue'

  const panel = ref([0, 1])
  const readonly = ref(false)
<\/script>

<script>
  export default {
    data: () => ({
      panel: [0, 1],
      readonly: false,
    }),
  }
<\/script>
`;
const _sfc_main$1 = {};
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-subtitle-2 mb-2" }, "Default", -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("div", { class: "text-subtitle-2 mt-4 mb-2" }, "Accordion", -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("div", { class: "text-subtitle-2 mt-4 mb-2" }, "Inset", -1);
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("div", { class: "text-subtitle-2 mt-4 mb-2" }, "Popout", -1);
function _sfc_render(_ctx, _cache) {
  const _component_v_expansion_panel = resolveComponent("v-expansion-panel");
  const _component_v_expansion_panels = resolveComponent("v-expansion-panels");
  return openBlock(), createElementBlock("div", null, [
    _hoisted_1,
    createVNode(_component_v_expansion_panels, null, {
      default: withCtx(() => [
        (openBlock(), createElementBlock(Fragment, null, renderList(3, (i) => {
          return createVNode(_component_v_expansion_panel, {
            key: i,
            text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
            title: "Item"
          });
        }), 64))
      ]),
      _: 1
    }),
    _hoisted_2,
    createVNode(_component_v_expansion_panels, { variant: "accordion" }, {
      default: withCtx(() => [
        (openBlock(), createElementBlock(Fragment, null, renderList(3, (i) => {
          return createVNode(_component_v_expansion_panel, {
            key: i,
            text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
            title: "Item"
          });
        }), 64))
      ]),
      _: 1
    }),
    _hoisted_3,
    createVNode(_component_v_expansion_panels, {
      class: "my-4",
      variant: "inset"
    }, {
      default: withCtx(() => [
        (openBlock(), createElementBlock(Fragment, null, renderList(3, (i) => {
          return createVNode(_component_v_expansion_panel, {
            key: i,
            text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
            title: "Item"
          });
        }), 64))
      ]),
      _: 1
    }),
    _hoisted_4,
    createVNode(_component_v_expansion_panels, {
      class: "my-4",
      variant: "popout"
    }, {
      default: withCtx(() => [
        (openBlock(), createElementBlock(Fragment, null, renderList(3, (i) => {
          return createVNode(_component_v_expansion_panel, {
            key: i,
            text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
            title: "Item"
          });
        }), 64))
      ]),
      _: 1
    })
  ]);
}
const __6 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["render", _sfc_render]]);
const __6_raw = '<template>\n  <div>\n    <div class="text-subtitle-2 mb-2">Default</div>\n    <v-expansion-panels>\n      <v-expansion-panel\n        v-for="i in 3"\n        :key="i"\n        text="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."\n        title="Item"\n      ></v-expansion-panel>\n    </v-expansion-panels>\n\n    <div class="text-subtitle-2 mt-4 mb-2">Accordion</div>\n\n    <v-expansion-panels variant="accordion">\n      <v-expansion-panel\n        v-for="i in 3"\n        :key="i"\n        text="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."\n        title="Item"\n      ></v-expansion-panel>\n    </v-expansion-panels>\n\n    <div class="text-subtitle-2 mt-4 mb-2">Inset</div>\n\n    <v-expansion-panels class="my-4" variant="inset">\n      <v-expansion-panel\n        v-for="i in 3"\n        :key="i"\n        text="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."\n        title="Item"\n      ></v-expansion-panel>\n    </v-expansion-panels>\n\n    <div class="text-subtitle-2 mt-4 mb-2">Popout</div>\n\n    <v-expansion-panels class="my-4" variant="popout">\n      <v-expansion-panel\n        v-for="i in 3"\n        :key="i"\n        text="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."\n        title="Item"\n      ></v-expansion-panel>\n    </v-expansion-panels>\n  </div>\n</template>\n';
const name = "v-expansion-panels";
const _sfc_main = {
  __name: "usage",
  setup(__props) {
    const model = ref("default");
    const options = [];
    const props = computed(() => {
      return {};
    });
    const slots = computed(() => {
      return `
  <v-expansion-panel
    title="Title"
    text="Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima"
  >
  </v-expansion-panel>
`;
    });
    const code = computed(() => {
      return `<${name}${propsToString(props.value)}>${slots.value}</${name}>`;
    });
    return (_ctx, _cache) => {
      const _component_v_expansion_panel = resolveComponent("v-expansion-panel");
      const _component_v_expansion_panels = resolveComponent("v-expansion-panels");
      const _component_ExamplesUsageExample = _sfc_main$8;
      return openBlock(), createBlock(_component_ExamplesUsageExample, {
        modelValue: unref(model),
        "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(model) ? model.value = $event : null),
        code: unref(code),
        name,
        options
      }, {
        default: withCtx(() => [
          createBaseVNode("div", null, [
            createVNode(_component_v_expansion_panels, normalizeProps(guardReactiveProps(unref(props))), {
              default: withCtx(() => [
                createVNode(_component_v_expansion_panel, {
                  text: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima",
                  title: "Title"
                })
              ]),
              _: 1
            }, 16)
          ])
        ]),
        _: 1
      }, 8, ["modelValue", "code"]);
    };
  }
};
const __7 = _sfc_main;
const __7_raw = '<template>\n  <ExamplesUsageExample\n    v-model="model"\n    :code="code"\n    :name="name"\n    :options="options"\n  >\n    <div>\n      <v-expansion-panels v-bind="props">\n        <v-expansion-panel\n          text="Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima"\n          title="Title"\n        >\n        </v-expansion-panel>\n      </v-expansion-panels>\n    </div>\n  </ExamplesUsageExample>\n</template>\n\n<script setup>\n  const name = \'v-expansion-panels\'\n  const model = ref(\'default\')\n  const options = []\n  const props = computed(() => {\n    return {}\n  })\n\n  const slots = computed(() => {\n    return `\n  <v-expansion-panel\n    title="Title"\n    text="Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima"\n  >\n  </v-expansion-panel>\n`\n  })\n\n  const code = computed(() => {\n    return `<${name}${propsToString(props.value)}>${slots.value}</${name}>`\n  })\n<\/script>\n';
const vExpansionPanels = {
  "misc-advanced": {
    component: __0,
    source: __0_raw
  },
  "misc-custom-icons": {
    component: __1,
    source: __1_raw
  },
  "prop-disabled": {
    component: __2,
    source: __2_raw
  },
  "prop-focusable": {
    component: __3,
    source: __3_raw
  },
  "prop-model": {
    component: __4,
    source: __4_raw
  },
  "prop-readonly": {
    component: __5,
    source: __5_raw
  },
  "prop-variant": {
    component: __6,
    source: __6_raw
  },
  "usage": {
    component: __7,
    source: __7_raw
  }
};
export {
  vExpansionPanels as default
};
