import { J as ref, r as resolveComponent, o as openBlock, c as createBlock, w as withCtx, b as createVNode, j as computed, h as createTextVNode, l as createElementBlock, F as Fragment, v as renderList, U as normalizeClass, t as toDisplayString, e as createBaseVNode, O as watch, B as shallowRef, ag as propsToString, f as unref, E as isRef, ak as normalizeProps, al as guardReactiveProps } from "./index-DGybHjCP.js";
import { _ as _sfc_main$5 } from "./UsageExample-M8CmNipa.js";
const _sfc_main$4 = {
  __name: "misc-display-animation",
  setup(__props) {
    const hidden = ref(false);
    return (_ctx, _cache) => {
      const _component_v_app_bar_nav_icon = resolveComponent("v-app-bar-nav-icon");
      const _component_v_fab = resolveComponent("v-fab");
      const _component_v_app_bar = resolveComponent("v-app-bar");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_sheet = resolveComponent("v-sheet");
      const _component_v_main = resolveComponent("v-main");
      const _component_v_layout = resolveComponent("v-layout");
      const _component_v_card = resolveComponent("v-card");
      return openBlock(), createBlock(_component_v_card, {
        class: "mx-auto",
        "max-width": "360"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_layout, null, {
            default: withCtx(() => [
              createVNode(_component_v_app_bar, {
                absolute: "",
                extended: ""
              }, {
                extension: withCtx(() => [
                  createVNode(_component_v_fab, {
                    active: !hidden.value,
                    class: "ms-4",
                    icon: "mdi-plus",
                    location: "bottom start",
                    size: "small",
                    absolute: "",
                    offset: ""
                  }, null, 8, ["active"])
                ]),
                default: withCtx(() => [
                  createVNode(_component_v_app_bar_nav_icon)
                ]),
                _: 1
              }),
              createVNode(_component_v_main, null, {
                default: withCtx(() => [
                  createVNode(_component_v_sheet, {
                    class: "pa-4 text-center",
                    color: "surface-light",
                    height: "300"
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_v_btn, {
                        text: hidden.value ? "Show" : "Hide",
                        color: "surface-variant",
                        width: "80",
                        onClick: _cache[0] || (_cache[0] = ($event) => hidden.value = !hidden.value)
                      }, null, 8, ["text"])
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_sheet, { height: "125" }, {
                    default: withCtx(() => [
                      createVNode(_component_v_fab, {
                        active: !hidden.value,
                        class: "me-4",
                        icon: "mdi-plus",
                        location: "top end",
                        absolute: "",
                        offset: ""
                      }, null, 8, ["active"])
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __0 = _sfc_main$4;
const __0_raw = `<template>
  <v-card
    class="mx-auto"
    max-width="360"
  >
    <v-layout>
      <v-app-bar absolute extended>
        <v-app-bar-nav-icon></v-app-bar-nav-icon>

        <template v-slot:extension>
          <v-fab
            :active="!hidden"
            class="ms-4"
            icon="mdi-plus"
            location="bottom start"
            size="small"
            absolute
            offset
          ></v-fab>
        </template>
      </v-app-bar>

      <v-main>
        <v-sheet class="pa-4 text-center" color="surface-light" height="300">
          <v-btn
            :text="hidden ? 'Show' : 'Hide'"
            color="surface-variant"
            width="80"
            @click="hidden = !hidden"
          >
          </v-btn>
        </v-sheet>

        <v-sheet height="125">
          <v-fab
            :active="!hidden"
            class="me-4"
            icon="mdi-plus"
            location="top end"
            absolute
            offset
          ></v-fab>
        </v-sheet>
      </v-main>
    </v-layout>
  </v-card>
</template>

<script setup>
  import { ref } from 'vue'

  const hidden = ref(false)
<\/script>

<script>
  export default {
    data: () => ({
      hidden: false,
    }),
  }
<\/script>
`;
const _sfc_main$3 = {
  __name: "misc-lateral-screens",
  setup(__props) {
    const tabs = ref(null);
    const activeFab = computed(() => {
      switch (tabs.value) {
        case "one":
          return { color: "success", icon: "mdi-share-variant" };
        case "two":
          return { color: "red", icon: "mdi-pencil" };
        case "three":
          return { color: "green", icon: "mdi-chevron-up" };
        default:
          return {};
      }
    });
    return (_ctx, _cache) => {
      const _component_v_app_bar_nav_icon = resolveComponent("v-app-bar-nav-icon");
      const _component_v_app_bar_title = resolveComponent("v-app-bar-title");
      const _component_v_spacer = resolveComponent("v-spacer");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_icon = resolveComponent("v-icon");
      const _component_v_tab = resolveComponent("v-tab");
      const _component_v_tabs_slider = resolveComponent("v-tabs-slider");
      const _component_v_tabs = resolveComponent("v-tabs");
      const _component_v_app_bar = resolveComponent("v-app-bar");
      const _component_v_sheet = resolveComponent("v-sheet");
      const _component_v_main = resolveComponent("v-main");
      const _component_v_fab = resolveComponent("v-fab");
      const _component_v_layout = resolveComponent("v-layout");
      const _component_v_card = resolveComponent("v-card");
      return openBlock(), createBlock(_component_v_card, null, {
        default: withCtx(() => [
          createVNode(_component_v_layout, null, {
            default: withCtx(() => [
              createVNode(_component_v_app_bar, {
                color: "indigo",
                absolute: "",
                flat: ""
              }, {
                extension: withCtx(() => [
                  createVNode(_component_v_tabs, {
                    modelValue: tabs.value,
                    "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => tabs.value = $event),
                    "align-tabs": "title"
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_v_tab, {
                        text: "Item One",
                        value: "one"
                      }),
                      createVNode(_component_v_tab, {
                        text: "Item Two",
                        value: "two"
                      }),
                      createVNode(_component_v_tab, {
                        text: "Item Three",
                        value: "three"
                      }),
                      createVNode(_component_v_tabs_slider, { color: "pink" })
                    ]),
                    _: 1
                  }, 8, ["modelValue"])
                ]),
                default: withCtx(() => [
                  createVNode(_component_v_app_bar_nav_icon),
                  createVNode(_component_v_app_bar_title, null, {
                    default: withCtx(() => [
                      createTextVNode("Page title")
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_spacer),
                  createVNode(_component_v_btn, { icon: "mdi-magnify" }),
                  createVNode(_component_v_btn, { icon: "mdi-dots-vertical" }, {
                    default: withCtx(() => [
                      createVNode(_component_v_icon)
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }),
              createVNode(_component_v_main, null, {
                default: withCtx(() => [
                  createVNode(_component_v_sheet, { height: "150" })
                ]),
                _: 1
              }),
              (openBlock(), createBlock(_component_v_fab, {
                key: activeFab.value.icon,
                color: activeFab.value.color,
                icon: activeFab.value.icon,
                class: "ms-4 mb-4",
                location: "bottom start",
                size: "64",
                absolute: "",
                app: "",
                appear: ""
              }, null, 8, ["color", "icon"]))
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
};
const __1 = _sfc_main$3;
const __1_raw = `<template>
  <v-card>
    <v-layout>
      <v-app-bar
        color="indigo"
        absolute
        flat
      >
        <v-app-bar-nav-icon></v-app-bar-nav-icon>

        <v-app-bar-title>Page title</v-app-bar-title>

        <v-spacer></v-spacer>

        <v-btn icon="mdi-magnify"></v-btn>

        <v-btn icon="mdi-dots-vertical">
          <v-icon></v-icon>
        </v-btn>

        <template v-slot:extension>
          <v-tabs
            v-model="tabs"
            align-tabs="title"
          >
            <v-tab text="Item One" value="one"></v-tab>

            <v-tab text="Item Two" value="two"></v-tab>

            <v-tab text="Item Three" value="three"></v-tab>

            <v-tabs-slider color="pink"></v-tabs-slider>
          </v-tabs>
        </template>
      </v-app-bar>

      <v-main>
        <v-sheet height="150"></v-sheet>
      </v-main>

      <v-fab
        :key="activeFab.icon"
        :color="activeFab.color"
        :icon="activeFab.icon"
        class="ms-4 mb-4"
        location="bottom start"
        size="64"
        absolute
        app
        appear
      ></v-fab>
    </v-layout>
  </v-card>
</template>

<script setup>
  import { computed, ref } from 'vue'

  const tabs = ref(null)
  const activeFab = computed(() => {
    switch (tabs.value) {
      case 'one': return { color: 'success', icon: 'mdi-share-variant' }
      case 'two': return { color: 'red', icon: 'mdi-pencil' }
      case 'three': return { color: 'green', icon: 'mdi-chevron-up' }
      default: return {}
    }
  })
<\/script>

<script>
  export default {
    data: () => ({
      tabs: null,
    }),

    computed: {
      activeFab () {
        switch (this.tabs) {
          case 'one': return { color: 'success', icon: 'mdi-share-variant' }
          case 'two': return { color: 'red', icon: 'mdi-pencil' }
          case 'three': return { color: 'green', icon: 'mdi-chevron-up' }
          default: return {}
        }
      },
    },
  }
<\/script>
`;
const _hoisted_1$2 = /* @__PURE__ */ createBaseVNode("small", { class: "text-grey" }, "* This doesn't actually save.", -1);
const _sfc_main$2 = {
  __name: "misc-small",
  setup(__props) {
    const dialog = ref(false);
    const items = ref([
      { icon: "mdi-folder", iconClass: "bg-grey-lighten-1 text-white", title: "Photos", subtitle: "Jan 9, 2014" },
      { icon: "mdi-folder", iconClass: "bg-grey-lighten-1 text-white", title: "Recipes", subtitle: "Jan 17, 2014" },
      { icon: "mdi-folder", iconClass: "bg-grey-lighten-1 text-white", title: "Work", subtitle: "Jan 28, 2014" }
    ]);
    const items2 = ref([
      { icon: "mdi-clipboard-text", iconClass: "bg-blue text-white", title: "Vacation itinerary", subtitle: "Jan 20, 2014" },
      { icon: "mdi-gesture-tap-button", iconClass: "bg-amber text-white", title: "Kitchen remodel", subtitle: "Jan 10, 2014" }
    ]);
    return (_ctx, _cache) => {
      const _component_v_app_bar_nav_icon = resolveComponent("v-app-bar-nav-icon");
      const _component_v_toolbar_title = resolveComponent("v-toolbar-title");
      const _component_v_spacer = resolveComponent("v-spacer");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_fab = resolveComponent("v-fab");
      const _component_v_toolbar = resolveComponent("v-toolbar");
      const _component_v_list_subheader = resolveComponent("v-list-subheader");
      const _component_v_avatar = resolveComponent("v-avatar");
      const _component_v_list_item_title = resolveComponent("v-list-item-title");
      const _component_v_list_item_subtitle = resolveComponent("v-list-item-subtitle");
      const _component_v_list_item_action = resolveComponent("v-list-item-action");
      const _component_v_list_item = resolveComponent("v-list-item");
      const _component_v_divider = resolveComponent("v-divider");
      const _component_v_list = resolveComponent("v-list");
      const _component_v_text_field = resolveComponent("v-text-field");
      const _component_v_card_text = resolveComponent("v-card-text");
      const _component_v_card_actions = resolveComponent("v-card-actions");
      const _component_v_card = resolveComponent("v-card");
      const _component_v_dialog = resolveComponent("v-dialog");
      return openBlock(), createBlock(_component_v_card, {
        class: "mx-auto",
        "max-width": "365"
      }, {
        default: withCtx(() => [
          createVNode(_component_v_toolbar, {
            color: "light-blue",
            extended: "",
            light: ""
          }, {
            extension: withCtx(() => [
              createVNode(_component_v_fab, {
                class: "ms-4",
                color: "cyan-accent-2",
                icon: "mdi-plus",
                location: "bottom left",
                size: "40",
                absolute: "",
                offset: "",
                onClick: _cache[0] || (_cache[0] = ($event) => dialog.value = !dialog.value)
              })
            ]),
            default: withCtx(() => [
              createVNode(_component_v_app_bar_nav_icon, { color: "grey-darken-4" }),
              createVNode(_component_v_toolbar_title, null, {
                default: withCtx(() => [
                  createTextVNode("My files")
                ]),
                _: 1
              }),
              createVNode(_component_v_spacer),
              createVNode(_component_v_btn, {
                color: "grey-darken-4",
                icon: "mdi-magnify"
              }),
              createVNode(_component_v_btn, {
                color: "grey-darken-4",
                icon: "mdi-view-module"
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_list, {
            lines: "two",
            subheader: ""
          }, {
            default: withCtx(() => [
              createVNode(_component_v_list_subheader, {
                title: "Folders",
                inset: ""
              }),
              (openBlock(true), createElementBlock(Fragment, null, renderList(items.value, (item) => {
                return openBlock(), createBlock(_component_v_list_item, {
                  key: item.title,
                  link: ""
                }, {
                  prepend: withCtx(() => [
                    createVNode(_component_v_avatar, {
                      class: normalizeClass([item.iconClass]),
                      icon: item.icon
                    }, null, 8, ["class", "icon"])
                  ]),
                  append: withCtx(() => [
                    createVNode(_component_v_list_item_action, null, {
                      default: withCtx(() => [
                        createVNode(_component_v_btn, {
                          color: "grey-lighten-1",
                          icon: "mdi-information",
                          variant: "text"
                        })
                      ]),
                      _: 1
                    })
                  ]),
                  default: withCtx(() => [
                    createVNode(_component_v_list_item_title, null, {
                      default: withCtx(() => [
                        createTextVNode(toDisplayString(item.title), 1)
                      ]),
                      _: 2
                    }, 1024),
                    createVNode(_component_v_list_item_subtitle, null, {
                      default: withCtx(() => [
                        createTextVNode(toDisplayString(item.subtitle), 1)
                      ]),
                      _: 2
                    }, 1024)
                  ]),
                  _: 2
                }, 1024);
              }), 128)),
              createVNode(_component_v_divider, { inset: "" }),
              createVNode(_component_v_list_subheader, {
                title: "Files",
                inset: ""
              }),
              (openBlock(true), createElementBlock(Fragment, null, renderList(items2.value, (item) => {
                return openBlock(), createBlock(_component_v_list_item, {
                  key: item.title,
                  link: ""
                }, {
                  prepend: withCtx(() => [
                    createVNode(_component_v_avatar, {
                      class: normalizeClass([item.iconClass]),
                      icon: item.icon
                    }, null, 8, ["class", "icon"])
                  ]),
                  append: withCtx(() => [
                    createVNode(_component_v_list_item_action, null, {
                      default: withCtx(() => [
                        createVNode(_component_v_btn, {
                          color: "grey-lighten-1",
                          icon: "mdi-information",
                          variant: "text"
                        })
                      ]),
                      _: 1
                    })
                  ]),
                  default: withCtx(() => [
                    createVNode(_component_v_list_item_title, null, {
                      default: withCtx(() => [
                        createTextVNode(toDisplayString(item.title), 1)
                      ]),
                      _: 2
                    }, 1024),
                    createVNode(_component_v_list_item_subtitle, null, {
                      default: withCtx(() => [
                        createTextVNode(toDisplayString(item.subtitle), 1)
                      ]),
                      _: 2
                    }, 1024)
                  ]),
                  _: 2
                }, 1024);
              }), 128))
            ]),
            _: 1
          }),
          createVNode(_component_v_dialog, {
            modelValue: dialog.value,
            "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => dialog.value = $event),
            "max-width": "500"
          }, {
            default: withCtx(() => [
              createVNode(_component_v_card, null, {
                default: withCtx(() => [
                  createVNode(_component_v_card_text, null, {
                    default: withCtx(() => [
                      createVNode(_component_v_text_field, { label: "File name" }),
                      _hoisted_1$2
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_card_actions, null, {
                    default: withCtx(() => [
                      createVNode(_component_v_spacer),
                      createVNode(_component_v_btn, {
                        color: "primary",
                        variant: "text",
                        onClick: _cache[1] || (_cache[1] = ($event) => dialog.value = false)
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" Submit ")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          }, 8, ["modelValue"])
        ]),
        _: 1
      });
    };
  }
};
const __2 = _sfc_main$2;
const __2_raw = `<template>
  <v-card class="mx-auto" max-width="365">
    <v-toolbar
      color="light-blue"
      extended
      light
    >
      <v-app-bar-nav-icon color="grey-darken-4"></v-app-bar-nav-icon>

      <v-toolbar-title>My files</v-toolbar-title>

      <v-spacer></v-spacer>

      <v-btn color="grey-darken-4" icon="mdi-magnify"></v-btn>

      <v-btn color="grey-darken-4" icon="mdi-view-module"></v-btn>

      <template v-slot:extension>
        <v-fab
          class="ms-4"
          color="cyan-accent-2"
          icon="mdi-plus"
          location="bottom left"
          size="40"
          absolute
          offset
          @click="dialog = !dialog"
        ></v-fab>
      </template>
    </v-toolbar>

    <v-list
      lines="two"
      subheader
    >
      <v-list-subheader title="Folders" inset></v-list-subheader>

      <v-list-item
        v-for="item in items"
        :key="item.title"
        link
      >
        <template v-slot:prepend>
          <v-avatar :class="[item.iconClass]" :icon="item.icon"></v-avatar>
        </template>

        <v-list-item-title>{{ item.title }}</v-list-item-title>

        <v-list-item-subtitle>{{ item.subtitle }}</v-list-item-subtitle>

        <template v-slot:append>
          <v-list-item-action>
            <v-btn color="grey-lighten-1" icon="mdi-information" variant="text"></v-btn>
          </v-list-item-action>
        </template>
      </v-list-item>

      <v-divider inset></v-divider>

      <v-list-subheader title="Files" inset></v-list-subheader>

      <v-list-item
        v-for="item in items2"
        :key="item.title"
        link
      >
        <template v-slot:prepend>
          <v-avatar :class="[item.iconClass]" :icon="item.icon"></v-avatar>
        </template>

        <v-list-item-title>{{ item.title }}</v-list-item-title>

        <v-list-item-subtitle>{{ item.subtitle }}</v-list-item-subtitle>

        <template v-slot:append>
          <v-list-item-action>
            <v-btn color="grey-lighten-1" icon="mdi-information" variant="text"></v-btn>
          </v-list-item-action>
        </template>
      </v-list-item>
    </v-list>

    <v-dialog
      v-model="dialog"
      max-width="500"
    >
      <v-card>
        <v-card-text>
          <v-text-field label="File name"></v-text-field>

          <small class="text-grey">* This doesn't actually save.</small>
        </v-card-text>

        <v-card-actions>
          <v-spacer></v-spacer>

          <v-btn
            color="primary"
            variant="text"
            @click="dialog = false"
          >
            Submit
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-card>
</template>

<script setup>
  import { ref } from 'vue'

  const dialog = ref(false)
  const items = ref([
    { icon: 'mdi-folder', iconClass: 'bg-grey-lighten-1 text-white', title: 'Photos', subtitle: 'Jan 9, 2014' },
    { icon: 'mdi-folder', iconClass: 'bg-grey-lighten-1 text-white', title: 'Recipes', subtitle: 'Jan 17, 2014' },
    { icon: 'mdi-folder', iconClass: 'bg-grey-lighten-1 text-white', title: 'Work', subtitle: 'Jan 28, 2014' },
  ])
  const items2 = ref([
    { icon: 'mdi-clipboard-text', iconClass: 'bg-blue text-white', title: 'Vacation itinerary', subtitle: 'Jan 20, 2014' },
    { icon: 'mdi-gesture-tap-button', iconClass: 'bg-amber text-white', title: 'Kitchen remodel', subtitle: 'Jan 10, 2014' },
  ])
<\/script>
`;
const _hoisted_1$1 = /* @__PURE__ */ createBaseVNode("div", { class: "text-subheader-2 pa-2" }, "Options", -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("div", { class: "text-subheader-2 pa-2" }, "FAB location", -1);
const _hoisted_3 = /* @__PURE__ */ createBaseVNode("div", { class: "text-subheader-2 pa-2" }, "Speed dial direction", -1);
const _hoisted_4 = /* @__PURE__ */ createBaseVNode("div", { class: "text-subheader-2 pa-2" }, "Transition", -1);
const _sfc_main$1 = {
  __name: "misc-speed-dial",
  setup(__props) {
    const direction = ref("top");
    const fab = ref(false);
    const hover = ref(false);
    const top = ref(false);
    const right = ref(true);
    const bottom = ref(true);
    const left = ref(false);
    const transition = ref("slide-y-reverse-transition");
    watch(top, (val) => {
      bottom.value = !val;
    });
    watch(right, (val) => {
      left.value = !val;
    });
    watch(bottom, (val) => {
      top.value = !val;
    });
    watch(left, (val) => {
      right.value = !val;
    });
    return (_ctx, _cache) => {
      const _component_v_checkbox = resolveComponent("v-checkbox");
      const _component_v_col = resolveComponent("v-col");
      const _component_v_radio = resolveComponent("v-radio");
      const _component_v_radio_group = resolveComponent("v-radio-group");
      const _component_v_row = resolveComponent("v-row");
      const _component_v_container = resolveComponent("v-container");
      const _component_v_icon = resolveComponent("v-icon");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_speed_dial = resolveComponent("v-speed-dial");
      const _component_v_card = resolveComponent("v-card");
      return openBlock(), createBlock(_component_v_card, { id: "create" }, {
        default: withCtx(() => [
          createVNode(_component_v_container, { fluid: "" }, {
            default: withCtx(() => [
              createVNode(_component_v_row, { class: "child-flex" }, {
                default: withCtx(() => [
                  createVNode(_component_v_col, {
                    cols: "12",
                    md: "4",
                    sm: "6"
                  }, {
                    default: withCtx(() => [
                      _hoisted_1$1,
                      createVNode(_component_v_checkbox, {
                        modelValue: hover.value,
                        "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => hover.value = $event),
                        label: "Open on hover",
                        "hide-details": ""
                      }, null, 8, ["modelValue"])
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_col, {
                    cols: "12",
                    md: "4",
                    sm: "6"
                  }, {
                    default: withCtx(() => [
                      _hoisted_2,
                      createVNode(_component_v_checkbox, {
                        modelValue: top.value,
                        "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => top.value = $event),
                        label: "Top",
                        "hide-details": ""
                      }, null, 8, ["modelValue"]),
                      createVNode(_component_v_checkbox, {
                        modelValue: right.value,
                        "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => right.value = $event),
                        label: "Right",
                        "hide-details": ""
                      }, null, 8, ["modelValue"]),
                      createVNode(_component_v_checkbox, {
                        modelValue: bottom.value,
                        "onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => bottom.value = $event),
                        label: "Bottom",
                        "hide-details": ""
                      }, null, 8, ["modelValue"]),
                      createVNode(_component_v_checkbox, {
                        modelValue: left.value,
                        "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => left.value = $event),
                        label: "Left",
                        "hide-details": ""
                      }, null, 8, ["modelValue"])
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_col, {
                    cols: "12",
                    md: "4",
                    sm: "6"
                  }, {
                    default: withCtx(() => [
                      _hoisted_3,
                      createVNode(_component_v_radio_group, {
                        modelValue: direction.value,
                        "onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => direction.value = $event),
                        "hide-details": ""
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_v_radio, {
                            label: "Top",
                            value: "top"
                          }),
                          createVNode(_component_v_radio, {
                            label: "Right",
                            value: "right"
                          }),
                          createVNode(_component_v_radio, {
                            label: "Bottom",
                            value: "bottom"
                          }),
                          createVNode(_component_v_radio, {
                            label: "Left",
                            value: "left"
                          })
                        ]),
                        _: 1
                      }, 8, ["modelValue"])
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_col, {
                    cols: "12",
                    md: "4",
                    sm: "6"
                  }, {
                    default: withCtx(() => [
                      _hoisted_4,
                      createVNode(_component_v_radio_group, {
                        modelValue: transition.value,
                        "onUpdate:modelValue": _cache[6] || (_cache[6] = ($event) => transition.value = $event),
                        "hide-details": ""
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_v_radio, {
                            label: "Slide y",
                            value: "slide-y-transition"
                          }),
                          createVNode(_component_v_radio, {
                            label: "Slide y reverse",
                            value: "slide-y-reverse-transition"
                          }),
                          createVNode(_component_v_radio, {
                            label: "Slide x",
                            value: "slide-x-transition"
                          }),
                          createVNode(_component_v_radio, {
                            label: "Slide x reverse",
                            value: "slide-x-reverse-transition"
                          }),
                          createVNode(_component_v_radio, {
                            label: "Scale",
                            value: "scale-transition"
                          })
                        ]),
                        _: 1
                      }, 8, ["modelValue"])
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          }),
          createVNode(_component_v_speed_dial, {
            modelValue: fab.value,
            "onUpdate:modelValue": _cache[8] || (_cache[8] = ($event) => fab.value = $event),
            bottom: bottom.value,
            direction: direction.value,
            left: left.value,
            "open-on-hover": hover.value,
            right: right.value,
            top: top.value,
            transition: transition.value
          }, {
            activator: withCtx(() => [
              createVNode(_component_v_btn, {
                modelValue: fab.value,
                "onUpdate:modelValue": _cache[7] || (_cache[7] = ($event) => fab.value = $event),
                color: "blue-darken-2",
                dark: "",
                fab: ""
              }, {
                default: withCtx(() => [
                  fab.value ? (openBlock(), createBlock(_component_v_icon, { key: 0 }, {
                    default: withCtx(() => [
                      createTextVNode(" mdi-close ")
                    ]),
                    _: 1
                  })) : (openBlock(), createBlock(_component_v_icon, { key: 1 }, {
                    default: withCtx(() => [
                      createTextVNode(" mdi-account-circle ")
                    ]),
                    _: 1
                  }))
                ]),
                _: 1
              }, 8, ["modelValue"])
            ]),
            default: withCtx(() => [
              createVNode(_component_v_btn, {
                color: "green",
                size: "small",
                dark: "",
                fab: ""
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_icon, null, {
                    default: withCtx(() => [
                      createTextVNode("mdi-pencil")
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }),
              createVNode(_component_v_btn, {
                color: "indigo",
                size: "small",
                dark: "",
                fab: ""
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_icon, null, {
                    default: withCtx(() => [
                      createTextVNode("mdi-plus")
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }),
              createVNode(_component_v_btn, {
                color: "red",
                size: "small",
                dark: "",
                fab: ""
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_icon, null, {
                    default: withCtx(() => [
                      createTextVNode("mdi-delete")
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ]),
            _: 1
          }, 8, ["modelValue", "bottom", "direction", "left", "open-on-hover", "right", "top", "transition"])
        ]),
        _: 1
      });
    };
  }
};
const __3 = _sfc_main$1;
const __3_raw = `<template>
  <v-card id="create">
    <v-container fluid>
      <v-row class="child-flex">
        <v-col
          cols="12"
          md="4"
          sm="6"
        >
          <div class="text-subheader-2 pa-2">Options</div>
          <v-checkbox
            v-model="hover"
            label="Open on hover"
            hide-details
          ></v-checkbox>
        </v-col>
        <v-col
          cols="12"
          md="4"
          sm="6"
        >
          <div class="text-subheader-2 pa-2">FAB location</div>
          <v-checkbox
            v-model="top"
            label="Top"
            hide-details
          ></v-checkbox>
          <v-checkbox
            v-model="right"
            label="Right"
            hide-details
          ></v-checkbox>
          <v-checkbox
            v-model="bottom"
            label="Bottom"
            hide-details
          ></v-checkbox>
          <v-checkbox
            v-model="left"
            label="Left"
            hide-details
          ></v-checkbox>
        </v-col>
        <v-col
          cols="12"
          md="4"
          sm="6"
        >
          <div class="text-subheader-2 pa-2">Speed dial direction</div>
          <v-radio-group
            v-model="direction"
            hide-details
          >
            <v-radio
              label="Top"
              value="top"
            ></v-radio>
            <v-radio
              label="Right"
              value="right"
            ></v-radio>
            <v-radio
              label="Bottom"
              value="bottom"
            ></v-radio>
            <v-radio
              label="Left"
              value="left"
            ></v-radio>
          </v-radio-group>
        </v-col>
        <v-col
          cols="12"
          md="4"
          sm="6"
        >
          <div class="text-subheader-2 pa-2">Transition</div>
          <v-radio-group
            v-model="transition"
            hide-details
          >
            <v-radio
              label="Slide y"
              value="slide-y-transition"
            ></v-radio>
            <v-radio
              label="Slide y reverse"
              value="slide-y-reverse-transition"
            ></v-radio>
            <v-radio
              label="Slide x"
              value="slide-x-transition"
            ></v-radio>
            <v-radio
              label="Slide x reverse"
              value="slide-x-reverse-transition"
            ></v-radio>
            <v-radio
              label="Scale"
              value="scale-transition"
            ></v-radio>
          </v-radio-group>
        </v-col>
      </v-row>
    </v-container>
    <v-speed-dial
      v-model="fab"
      :bottom="bottom"
      :direction="direction"
      :left="left"
      :open-on-hover="hover"
      :right="right"
      :top="top"
      :transition="transition"
    >
      <template v-slot:activator>
        <v-btn
          v-model="fab"
          color="blue-darken-2"
          dark
          fab
        >
          <v-icon v-if="fab">
            mdi-close
          </v-icon>
          <v-icon v-else>
            mdi-account-circle
          </v-icon>
        </v-btn>
      </template>
      <v-btn
        color="green"
        size="small"
        dark
        fab
      >
        <v-icon>mdi-pencil</v-icon>
      </v-btn>
      <v-btn
        color="indigo"
        size="small"
        dark
        fab
      >
        <v-icon>mdi-plus</v-icon>
      </v-btn>
      <v-btn
        color="red"
        size="small"
        dark
        fab
      >
        <v-icon>mdi-delete</v-icon>
      </v-btn>
    </v-speed-dial>
  </v-card>
</template>

<script setup>
  import { ref, watch } from 'vue'

  const direction = ref('top')
  const fab = ref(false)
  const hover = ref(false)
  const top = ref(false)
  const right = ref(true)
  const bottom = ref(true)
  const left = ref(false)
  const transition = ref('slide-y-reverse-transition')
  watch(top, val => {
    bottom.value = !val
  })
  watch(right, val => {
    left.value = !val
  })
  watch(bottom, val => {
    top.value = !val
  })
  watch(left, val => {
    right.value = !val
  })
<\/script>

<script>
  export default {
    data: () => ({
      direction: 'top',
      fab: false,
      hover: false,
      top: false,
      right: true,
      bottom: true,
      left: false,
      transition: 'slide-y-reverse-transition',
    }),

    watch: {
      top (val) {
        this.bottom = !val
      },
      right (val) {
        this.left = !val
      },
      bottom (val) {
        this.top = !val
      },
      left (val) {
        this.right = !val
      },
    },
  }
<\/script>

<style>
  /* This is for documentation purposes and will not be needed in your application */
  #create .v-speed-dial {
    position: absolute;
  }

  #create .v-btn--floating {
    position: relative;
  }
</style>
`;
const _hoisted_1 = { class: "text-center" };
const name = "v-fab";
const _sfc_main = {
  __name: "usage",
  setup(__props) {
    const variants = ["outlined", "tonal", "flat", "text", "plain"];
    const model = shallowRef("default");
    const options = [...variants];
    const extended = shallowRef(false);
    const color = shallowRef();
    const items = ["primary", "success", "surface-variant"];
    const props = computed(() => {
      return {
        color: color.value,
        extended: extended.value || void 0,
        icon: !extended.value ? "$vuetify" : void 0,
        "prepend-icon": extended.value ? "$vuetify" : void 0,
        text: extended.value ? "Extended" : void 0,
        variant: variants.includes(model.value) ? model.value : void 0
      };
    });
    const slots = computed(() => {
      return "";
    });
    const code = computed(() => {
      return `<${name}${propsToString(props.value)}>${slots.value}</${name}>`;
    });
    return (_ctx, _cache) => {
      const _component_v_fab = resolveComponent("v-fab");
      const _component_v_select = resolveComponent("v-select");
      const _component_v_checkbox = resolveComponent("v-checkbox");
      const _component_ExamplesUsageExample = _sfc_main$5;
      return openBlock(), createBlock(_component_ExamplesUsageExample, {
        modelValue: unref(model),
        "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => isRef(model) ? model.value = $event : null),
        code: unref(code),
        name,
        options
      }, {
        configuration: withCtx(() => [
          createVNode(_component_v_select, {
            modelValue: unref(color),
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(color) ? color.value = $event : null),
            items,
            label: "Color",
            clearable: ""
          }, null, 8, ["modelValue"]),
          createVNode(_component_v_checkbox, {
            modelValue: unref(extended),
            "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(extended) ? extended.value = $event : null),
            label: "Extended"
          }, null, 8, ["modelValue"])
        ]),
        default: withCtx(() => [
          createBaseVNode("div", _hoisted_1, [
            createVNode(_component_v_fab, normalizeProps(guardReactiveProps(unref(props))), null, 16)
          ])
        ]),
        _: 1
      }, 8, ["modelValue", "code"]);
    };
  }
};
const __4 = _sfc_main;
const __4_raw = `<template>
  <ExamplesUsageExample
    v-model="model"
    :code="code"
    :name="name"
    :options="options"
  >
    <div class="text-center">
      <v-fab v-bind="props"></v-fab>
    </div>

    <template v-slot:configuration>
      <v-select
        v-model="color"
        :items="items"
        label="Color"
        clearable
      ></v-select>
      <v-checkbox v-model="extended" label="Extended"></v-checkbox>
    </template>
  </ExamplesUsageExample>
</template>

<script setup>
  const variants = ['outlined', 'tonal', 'flat', 'text', 'plain']
  const name = 'v-fab'
  const model = shallowRef('default')
  const options = [...variants]
  const extended = shallowRef(false)
  const color = shallowRef()
  const items = ['primary', 'success', 'surface-variant']

  const props = computed(() => {
    return {
      color: color.value,
      extended: extended.value || undefined,
      icon: !extended.value ? '$vuetify' : undefined,
      'prepend-icon': extended.value ? '$vuetify' : undefined,
      text: extended.value ? 'Extended' : undefined,
      variant: variants.includes(model.value) ? model.value : undefined,
    }
  })

  const slots = computed(() => {
    return ''
  })

  const code = computed(() => {
    return \`<\${name}\${propsToString(props.value)}>\${slots.value}</\${name}>\`
  })
<\/script>
`;
const vFab = {
  "misc-display-animation": {
    component: __0,
    source: __0_raw
  },
  "misc-lateral-screens": {
    component: __1,
    source: __1_raw
  },
  "misc-small": {
    component: __2,
    source: __2_raw
  },
  "misc-speed-dial": {
    component: __3,
    source: __3_raw
  },
  "usage": {
    component: __4,
    source: __4_raw
  }
};
export {
  vFab as default
};
