
import { callLuaFunction } from './luaLoader';

const my_lua_functions = {
  add: (...args: any[]) => callLuaFunction('G:\watch-lua-script\scripts\my_lua_functions.lua', 'add', ...args),
  multiply: (...args: any[]) => callLuaFunction('G:\watch-lua-script\scripts\my_lua_functions.lua', 'multiply', ...args)
};

export default my_lua_functions;
  