function add(a, b)
    return a + b
end

function multiply(a, b)
    return a * b
end
