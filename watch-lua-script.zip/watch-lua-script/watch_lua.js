const fs = require('fs');
const path = require('path');
const chokidar = require('chokidar');

// 解析Lua脚本文件中的函数名
function parseLuaFunctions(luaScript) {
  const functionRegex = /^function\s+(\w+)\s*\(/gm;
  const functions = [];
  let match;
  while ((match = functionRegex.exec(luaScript)) !== null) {
    functions.push(match[1]);
  }
  return functions;
}

// 生成TypeScript接口文件
function generateLuaInterface(scriptPath, functions) {
  const scriptName = path.basename(scriptPath, '.lua');
  const tsFilePath = path.resolve(__dirname, `${scriptName}.ts`);
  const luaFunctions = functions.map(func => {
    return `  ${func}: (...args: any[]) => callLuaFunction('${scriptPath}', '${func}', ...args)`;
  }).join(',\n');

  const tsContent = `
import { callLuaFunction } from './luaLoader';

const ${scriptName} = {
${luaFunctions}
};

export default ${scriptName};
  `;

  fs.writeFileSync(tsFilePath, tsContent, 'utf8');
  console.log(`Generated TypeScript interface for ${scriptName}: ${tsFilePath}`);
}

// 更新Lua函数接口
function updateLuaFunctions(luaScriptPath) {
  fs.readFile(luaScriptPath, 'utf-8', (err, data) => {
    if (err) {
      console.error(`Error reading Lua script: ${err}`);
      return;
    }
    const functions = parseLuaFunctions(data);
    generateLuaInterface(luaScriptPath, functions);
  });
}

// 初始化监视器
function setupWatcher(luaDir) {
  const watcher = chokidar.watch(luaDir, {
    persistent: true,
    ignored: /(^|[\/\\])\../, // 忽略点文件
    ignoreInitial: false
  });

  watcher.on('add', filePath => {
    if (path.extname(filePath) === '.lua') {
      console.log(`Lua script added: ${filePath}`);
      updateLuaFunctions(filePath);
    }
  }).on('change', filePath => {
    if (path.extname(filePath) === '.lua') {
      console.log(`Lua script changed: ${filePath}`);
      updateLuaFunctions(filePath);
    }
  }).on('unlink', filePath => {
    if (path.extname(filePath) === '.lua') {
      console.log(`Lua script removed: ${filePath}`);
      const tsFilePath = path.resolve(__dirname, `${path.basename(filePath, '.lua')}.ts`);
      if (fs.existsSync(tsFilePath)) {
        fs.unlinkSync(tsFilePath);
        console.log(`Removed TypeScript interface: ${tsFilePath}`);
      }
    }
  });
}

// 启动监视器
const luaDir = path.resolve(__dirname, 'scripts');
setupWatcher(luaDir);

// 保持进程活跃
console.log(`Watching for changes in ${luaDir}`);
