use sea_orm::{DatabaseConnection, EntityTrait, QueryFilter, DbErr, ActiveModelTrait, DeleteResult, PrimaryKeyTrait, ActiveModelBehavior, IntoActiveModel, ConnectionTrait};
use std::sync::Arc;
use tokio::sync::RwLock;
use crate::db::pool::mysql_pool::{get_db_pool};
use crate::entity::user::ActiveModel;

#[derive(Clone)]
pub struct BaseDao {
    pub(crate) db: &'static DatabaseConnection,
}

impl BaseDao {
    pub async fn new() -> Self {
        BaseDao {
            db: get_db_pool(),
        }
    }

    pub async fn find_by_id<E, T>(&self, id: T) -> Result<Option<E::Model>, DbErr>
        where
            E: EntityTrait,
            T: Into<<E::PrimaryKey as PrimaryKeyTrait>::ValueType>,
    {
        E::find_by_id(id).one(self.db).await
    }

    pub async fn insert<E>(&self, model: E::Model) -> Result<E::Model, DbErr>
        where
            E: EntityTrait,
            E::Model: ActiveModelTrait<Entity=E> + ActiveModelBehavior,
            E::Model: IntoActiveModel<E::Model>,
    {
        ActiveModelTrait::insert(model, self.db).await
    }


    pub async fn update<E>(&self, model: E::Model) -> Result<E::Model, DbErr>
        where
            E: EntityTrait,
            E::Model: ActiveModelTrait<Entity=E> + ActiveModelBehavior,
            E::Model: IntoActiveModel<E::Model>,

    {
        model.update(self.db).await
    }

    pub async fn delete<E>(&self, model: E::Model) -> Result<DeleteResult, DbErr>
        where
            E: EntityTrait,
            E::Model: ActiveModelTrait<Entity=E> + ActiveModelBehavior,
            E::Model: IntoActiveModel<E::Model>,
    {
        model.delete(self.db).await
    }
}
