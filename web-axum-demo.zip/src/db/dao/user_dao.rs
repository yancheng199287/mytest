use sea_orm::entity::prelude::*;
use crate::db::dao::base_dao::BaseDao;
use crate::entity::user;

pub struct UserDao {
   pub base_dao: BaseDao,
}

impl UserDao {
    pub async fn new() -> Self {
        UserDao {
            base_dao: BaseDao::new().await,
        }
    }

    // UserDao 特定的方法，可以在这里添加
    pub async fn find_by_name(&self, name: &str) -> Result<Option<user::Model>, DbErr> {
        user::Entity::find()
            .filter(user::Column::Name.eq(name))
            .one(self.base_dao.db)
            .await
    }
}

