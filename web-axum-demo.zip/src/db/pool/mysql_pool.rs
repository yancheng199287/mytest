use std::time::Duration;
use once_cell::sync::OnceCell;
use sea_orm::{ConnectionTrait, ConnectOptions, Database, DatabaseConnection, DbBackend, SqlxMySqlConnector, Statement};
use sqlx::mysql::MySqlPoolOptions;

static DB_POOL: OnceCell<DatabaseConnection> = OnceCell::new();

pub async fn initialize_pool() {
    let db = connect().await;
    DB_POOL.set(db).unwrap();
}


pub fn get_db_pool() -> &'static DatabaseConnection {
    DB_POOL.get().expect("Database connection pool is not initialized")
}


pub async fn connect() -> DatabaseConnection {
    // 配置 MySQL 连接池
    let mut connect_options = ConnectOptions::new("mysql://yancheng:3sad@51231as!@520code.net:3306/miniapp?useUnicode=true&characterEncoding=utf8mb4&serverTimezone=Asia/Shanghai");
    // 最大连接池数量
    connect_options
        .max_connections(50)
        // 最小连接池数量
        .min_connections(3)
        // 连接最大生存周期，无论是否空闲 一个小时
        .max_lifetime(Duration::from_secs(60 * 60))
        // 连接最大空闲时间，超过这个时间就会被释放，默认为 None，即不会被释放
        .idle_timeout(Duration::from_secs(60 * 10))
        // 是否在获取连接前测试连接是否可用
        .test_before_acquire(true)
        // 从连接池获取连接的超时时间
        .acquire_timeout(Duration::from_secs(30));
    let db = Database::connect(connect_options).await.unwrap();
    return db;
}


#[tokio::test]
async fn main() {
    connect().await;
}