use tokio::sync::mpsc;
use std::thread;
use std::time::Duration;
use tokio::runtime::Handle;
use crate::tokio::tokio_runtime::GLOBAL_TOKIO_RUNTIME;
use dashmap::DashMap;
use std::sync::Once;
use std::sync::{Arc, Mutex};


use crate::engine::id_generator;

/*lazy_static::lazy_static! {
  static ref GLOBAL_DELAY_TASK_STORAGE: DelayTaskManager= {
   DelayTaskManager::new()
  };
}*/


/*type Task = Box<dyn Fn()>;*/


struct delay_task {
    id: i64,
    closure: Box<dyn Fn()>,
}


pub struct DelayTaskManager {
    channel: mpsc::Sender<i64>,
    // 存储闭包的映射：任务ID映射到对应的闭包
    closures_map: DashMap<i64, Box<dyn Fn()>>,
}

impl DelayTaskManager {
    pub fn new() -> DelayTaskManager {
        let (tx, mut rx) = mpsc::channel::<i64>(32);
        let mut delay_task = DelayTaskManager {
            channel: tx,
            closures_map: DashMap::new(),
        };
        delay_task.start_delay_task(rx);
        delay_task
    }

    fn start_delay_task(&mut self, mut rx: mpsc::Receiver<i64>) {
        let handler = Handle::try_current();
        match handler {
            Ok(handle) => {
                handle.spawn(async move {
                    while let Some(func) = rx.recv().await {
                        // 直接在这个线程里调用非 Send 类型的回调函数
                    }
                });
            }
            Err(_) => {
                // 如果获取当前线程的运行时失败，则使用tokio::spawn创建一个新线程
            }
        }
    }

    pub fn push_delay_task<F: Fn() + 'static>(&mut self, closure: F, time: u64) {
        let delay_task = delay_task { id: id_generator::next_id(), closure: Box::new(closure) };
        self.closures_map.insert(delay_task.id, delay_task.closure);
        self.delay_task_run(delay_task.id, time);
    }

    fn delay_task_run(&mut self, id: i64, time: u64) {
        let tx = self.channel.clone();

        let handler = Handle::try_current();
        match handler {
            Ok(handle) => {
                handle.spawn(async move {
                    tokio::time::sleep(Duration::from_secs(time)).await; // 延迟
                    tx.send(id).await.unwrap();
                });
            }
            Err(_) => {
                // 如果获取当前线程的运行时失败，则使用tokio::spawn创建一个新线程
                GLOBAL_TOKIO_RUNTIME.get_runtime().spawn(async move {
                    tokio::time::sleep(Duration::from_secs(time)).await; // 延迟
                    tx.send(id).await.unwrap();
                });
            }
        }
    }
}
