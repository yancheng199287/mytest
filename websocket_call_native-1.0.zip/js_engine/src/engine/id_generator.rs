use idgenerator::*;
use std::time::Instant;


lazy_static::lazy_static! {
  static ref  GLOBAL_DELAY_TASK_STORAGE: ()= {
     let options = IdGeneratorOptions::new().worker_id(1).worker_id_bit_len(6);
     IdInstance::init(options).unwrap();
  };
}

pub(crate) fn next_id() -> i64 {
    IdInstance::next_id()
}