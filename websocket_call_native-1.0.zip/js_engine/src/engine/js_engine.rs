use rquickjs::loader::{FileResolver, ModuleLoader, NativeLoader, ScriptLoader};
use rquickjs::{async_with, AsyncContext, AsyncRuntime, CatchResultExt, Context, Ctx, Object, Runtime, Value};
use std::sync::{Arc, Mutex};
use std::time::Duration;
use crate::engine::add_global_function::add_global_function;
use once_cell::sync::OnceCell;
use tokio::runtime::Handle;
use tokio::sync::mpsc;
use tokio::sync::mpsc::Receiver;

pub struct JSEngine {
    runtime: AsyncRuntime,
    context: AsyncContext,
}

pub static GLOBAL_JS_ENGINE: OnceCell<Arc<JSEngine>> = OnceCell::new();


//JS_ENGINE: engine::js_engine::JSEngine = engine::js_engine::JSEngine::new();
impl JSEngine {
    /// 内置一个全局的单例的JS引擎
    pub async fn global() -> &'static Arc<JSEngine> {
        let option = GLOBAL_JS_ENGINE.get();
        if option.is_none() {
            tokio::spawn(async move {
                tokio::task::block_in_place(move || {
                    Handle::current().block_on(async move {
                        let js_engine = JSEngine::new().await;
                        GLOBAL_JS_ENGINE.set(Arc::new(js_engine));
                    });
                });
            }).await;
        }
        let js_engine = GLOBAL_JS_ENGINE.get().expect("JSEngine is not initialized");
        js_engine
    }

    /// JS引擎如果需要多线程执行，需要new一个JS引擎去执行
    pub async fn new() -> Self {
        let runtime = AsyncRuntime::new().unwrap();
        let context = AsyncContext::full(&runtime).await.unwrap();
        let js_engine = JSEngine {
            runtime,
            context,
        };
        js_engine.init().await;
        js_engine
    }


    pub fn run_eval_task(self: &Arc<Self>, script: String) -> Result<Option<String>, String> {
        let self_clone1 = self.clone(); // 假设 self 是一个 Arc<YourStruct>
        return tokio::task::block_in_place(move || {
            let result = Handle::current().block_on(async move {
                return self_clone1.eval(script).await;
            });
            result
        });
    }


    async fn eval(self: &Arc<Self>, source: String) -> Result<Option<String>, String> {
        let ctx = &self.context;
        let result = async_with!(ctx => |ctx|{
            let caught_result = ctx.eval::<Option<Value>, &str>(&source).catch(&ctx);
            if caught_result.is_err() {
                let error = caught_result.unwrap_err().to_string();
                return Err(error);
            }
            let mut value_result = String::default();
            match caught_result {
                 Ok(str_option) => {
                      match str_option {
                          Some(str) => {
                            value_result = ctx.json_stringify(str).unwrap().unwrap().to_string().unwrap();
                        }
                          None => {}
                     }
                  }
                Err(e) => {}
             }
           return Ok(Some(value_result));
        }).await;

        let rt = &self.runtime;
        rt.idle().await;
        return result;
    }

    async fn init(&self) {
        let mut rt = &self.runtime;
        let mut ctx = &self.context;
        // 设置最大内存 2GB
        rt.set_memory_limit(2 * 1024 * 1024 * 1024);
        // 50MB，开始收集
        rt.set_gc_threshold(50 * 1024 * 1024);
        // 堆栈1MB
        rt.set_max_stack_size(1024 * 1024);
        self.set_loader_resolver(rt);
        add_global_function(&ctx).await
    }
    /*   pub fn with_ctx<F>(&self, f: F)
           where
               F: FnOnce(Ctx),
       {
           self.context.with(|ctx| f(ctx));
       }*/


    fn set_loader_resolver(&self, rt: &AsyncRuntime) {
        let resolver = (FileResolver::default()
                            .with_path("./")
                            .with_path("./js_bundle")
                            .with_path("./../target/debug")
                            .with_native(), );
        let loader = (
            // ModuleLoader::default().with_module("bundle/native_module", CommonModule),
            ScriptLoader::default(),
            NativeLoader::default(),
        );
        rt.set_loader(resolver, loader);
    }
}

//#[tokio::test]  #[tokio::main]

//#[tokio::test]
#[test]
pub fn test1() {
    let runtime = tokio::runtime::Builder::new_multi_thread().enable_all().build().unwrap();
    runtime.block_on(async {
        let runtime = AsyncRuntime::new().unwrap();
        let context = AsyncContext::full(&runtime).await.unwrap();
        add_global_function(&context).await;

        let ctx = &context;
        async_with!(ctx => |ctx|{
        let source = r#"
         setTimeout(function(){
    log("i am from settimeout");
  },3000);
  "Ok"
        "#;
            let caught_result = ctx.eval::<Option<String>, &str>(source).catch(&ctx);
            if caught_result.is_err() {
                let error = caught_result.unwrap_err().to_string();
                return Err(error);
            }
           return Ok(caught_result.unwrap());
        }).await;
        runtime.idle().await;
    });
    std::thread::sleep(Duration::from_secs(5));
}