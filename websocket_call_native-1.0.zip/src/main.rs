mod websocket;
mod model;

fn main() {
    println!("Hello, world!");

    log4rs::init_file("config/log4rs.yaml", Default::default()).unwrap();

    websocket::start_websocket().unwrap();
}
