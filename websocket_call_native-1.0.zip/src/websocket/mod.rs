mod handle_client_message;
mod receiver_sender_response;

use std::error::Error;
use std::future::Future;
use std::io;
use std::sync::Arc;
use bytes::Bytes;
use fastwebsockets::{FragmentCollector, Frame, OpCode, Payload, upgrade, WebSocketError};
use hyper::{Request, Response};
use http_body_util::Empty;
use tokio::runtime::Builder;
use hyper::server::conn::http1;
use hyper::service::service_fn;
use hyper::upgrade::Upgraded;
use hyper_util::rt::TokioIo;
use log::info;
use serde::de::value;
use tokio::select;
use tokio::sync::{mpsc, Mutex, oneshot};
use tokio::sync::mpsc::Receiver;
use js_engine::engine::js_engine::JSEngine;
use crate::model::response_payload::ResponseData;
use crate::websocket::handle_client_message::decode_json_and_set_map;
use crate::websocket::receiver_sender_response::MyMQ;

pub fn block_on<F: Future>(future: F) -> F::Output {
    let runtime = Builder::new_multi_thread()
        .enable_all()
        .worker_threads(30)
        .thread_name("my-websocket-name")
        .thread_stack_size(10 * 1024 * 1024)
        .build()
        .unwrap();

    runtime.block_on(future)
}

async fn server_upgrade<T>(mut req: Request<T>) -> Result<Response<Empty<Bytes>>, WebSocketError> {
    // 对request对象进行升级websocket
    //
    let (response, fut) = upgrade::upgrade(&mut req)?;
    // 这个地方继续开启异步任务去处理流的相关操作
    tokio::task::spawn(async move {
        // unconstrained代表一个不受tokio运行时限制的异步任务，tokio默认有最大线程数和最大等待时间，而这个方法不受这个限制
        // 请确保处理不太耗时和资源的操作
        if let Err(e) = tokio::task::unconstrained(handle_client(fut)).await {
            eprintln!("Error in websocket connection: {:?}", e);
        }
    });
    // let response = Response::new("hello world");
    // let response = Response::builder().status(200).body(Body::from("hello world")).unwrap();
    // 升级完成立即返回，注意这里返回之后，上面的异步任务还在继续执行
    Ok(response)
}


pub fn start_websocket() -> Result<(), WebSocketError> {
    block_on(async {
          let listener = tokio::net::TcpListener::bind("127.0.0.1:8080").await?;
        println!("Server started, listening on {}", "127.0.0.1:8080");
        // 循环获取客户端连接事件，这个循环是阻塞的
        loop {
            let (stream, _) = listener.accept().await?;
            println!("Client connected ip addr: {}", stream.peer_addr().unwrap());
            // 处理客户端连接请求
            tokio::spawn(async move {
                let builder = http1::Builder::new();
                let io = hyper_util::rt::TokioIo::new(stream);
                let conn_fut = builder.serve_connection(io, service_fn(server_upgrade)).with_upgrades();
                if let Err(e) = conn_fut.await {
                    println!("An error occurred: {:?}", e);
                }
            });
        }
    })
}


async fn handle_client1(fut: upgrade::UpgradeFut) -> Result<(), WebSocketError> {
    // 这里await获取到一个websocket对象是因为 UpgradeFut 实现了Future，最终调用了创建的 WebSocket::after_handshake(upgraded?, Role::Server)
    let websocket = fut.await?;
    let mut ws = fastwebsockets::FragmentCollector::new(websocket);
    let my_mq = MyMQ::new();
    let mut sender = my_mq.eval_script_channel.0;
    let mut rec = my_mq.eval_script_channel.1;
    loop {
        let frame = ws.read_frame().await?;
        match frame.opcode {
            OpCode::Close => break,
            OpCode::Text | OpCode::Binary => {
                let result = utf8::decode(&frame.payload);
                match result {
                    Ok(msg) => {
                        info!("服务端收到消息内容：{}",msg);
                        decode_json_and_set_map(msg, &mut sender).await;
                    }
                    Err(error) => {
                        info!("服务端解码消息失败");
                    }
                }
            }
            _ => {}
        }
    }
    Ok(())
}


async fn handle_client(fut: upgrade::UpgradeFut) -> Result<(), WebSocketError> {
    let websocket = fut.await?;
    let mut ws = FragmentCollector::new(websocket);
    let my_mq = MyMQ::new();

    // 用于发送消息的句柄
    let mut sender = my_mq.eval_script_channel.0;
    let mut receiver = my_mq.eval_script_channel.1;
    loop {
        // 使用 tokio::select! 同时处理接收客户端消息和发送消息
        select! {
            // 读取客户端发送的消息
            Ok(frame) = ws.read_frame()=> {
                if let Err(e) = handle_received_frame(&frame, &mut ws, &mut sender).await {
                    eprintln!("Error handling received frame: {:?}", e);
                    break;
                }
            },
            // 接收发送的消息
            Some(value) = receiver.recv() => {
                if let Err(e) = send_response(&mut ws, value).await {
                    eprintln!("Error sending response: {:?}", e);
                    break;
                }
            },
            else => break, // 如果两个分支都没有准备好，退出循环
        }
    }

    Ok(())
}


async fn handle_received_frame(frame: &Frame<'_>, ws: &mut FragmentCollector<TokioIo<Upgraded>>, sender: &mpsc::Sender<ResponseData>) -> Result<(), Box<dyn Error>> {
    match frame.opcode {
        OpCode::Close => {
            Ok(())
        }
        OpCode::Text | OpCode::Binary => {
            let result = utf8::decode(&frame.payload);
            match result {
                Ok(msg) => {
                    println!("服务端收到消息内容：{}", msg);
                    decode_json_and_set_map(msg, sender).await;
                    return Ok(());
                }
                Err(error) => {
                    println!("服务端解码消息失败: {:?}", error);
                }
            }
            Ok(())
        }
        _ => Ok(()),
    }
}


async fn send_response(ws: &mut FragmentCollector<TokioIo<Upgraded>>, value: ResponseData) -> Result<(), WebSocketError> {
    let value_str = serde_json::to_string(&value).unwrap();
    let payload = Payload::from(value_str.into_bytes());
    let frame = Frame::text(payload);
    ws.write_frame(frame).await
}

async fn send_response_message(mut ws: &mut FragmentCollector<TokioIo<Upgraded>>) {
    // 创建文本消息帧
    let text_message = "Hello, WebSocket!";
    let payload = Payload::from(text_message.as_bytes());
    let text_frame = Frame::text(payload);
    if let Err(err) = ws.write_frame(text_frame).await {
        eprintln!("Error sending text frame: {}", err);
    }
}


fn parser_binary_frame() {}