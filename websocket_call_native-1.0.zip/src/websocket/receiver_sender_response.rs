use tokio::sync::mpsc;
use crate::model::response_payload::ResponseData;

pub struct MyMQ {
   pub eval_script_channel: (mpsc::Sender<ResponseData>, mpsc::Receiver<ResponseData>),
}


impl MyMQ {
    pub fn new() -> MyMQ {
        MyMQ {
            eval_script_channel: mpsc::channel(100)
        }
    }
}