use chrono::{DateTime, Local};
use rquickjs::function::{Rest, This};
use rquickjs::Type::Bool;
use rquickjs::{Context, Ctx, Function, Object, Runtime, Value};
use std::borrow::Borrow;
use std::fmt::{Debug, Error};
use std::process::{Command, Stdio};
use std::ptr;
use std::rc::Rc;
use std::sync::Arc;
use std::thread::sleep;
use std::time::Duration;
use serde_json::Map;
use windows::core::imp::Point;
use windows::core::PCWSTR;
use crate::tokio::tokio_runtime::GLOBAL_TOKIO_RUNTIME;


fn console_log<'js>(ctx: Ctx<'js>, var_args: Rest<rquickjs::Value<'js>>) {
    let str_content = var_args
        .iter()
        .clone()
        .map(|item| {
            let value_result = ctx.json_stringify(item);
            let mut value = String::new();
            if value_result.is_ok() {
                let string_option = value_result.unwrap();
                if string_option.is_some() {
                    value = string_option.unwrap().to_string().unwrap();
                }
            }
            let value = value.trim_matches('"');
            value.to_string()
        })
        .collect::<Vec<_>>()
        .join(" ");
    let now: DateTime<Local> = Local::now();
    println!("{} {}", now.format("%Y-%m-%d %H:%M:%S%.3f"), str_content);
}

fn set_timeout<'js>(ctx: Ctx, func: rquickjs::Value, time: u64) -> String {
    println!("set_timeoutset_timeoutset_timeout");
    let callback = func.as_function().unwrap();
    let rt = GLOBAL_TOKIO_RUNTIME.get_runtime();
    rt.spawn(async move {
        let _ = tokio::time::sleep(Duration::from_millis(time));
    });
    callback.call::<(), ()>(()).unwrap();
    String::from("测试返回字符串")
    //Ok(Value::new_undefined(ctx.clone()))
    // let un = rquickjs::Value::new_undefined(ctx.clone());
    // Ok(un)
}


fn open_dir(str_dir: String) {
    let output = Command::new("explorer")
        .arg(str_dir)
        .output()
        .expect("failed to execute process");
    println!("status: {}", output.status);
    println!("stdout: {}", String::from_utf8_lossy(&output.stdout));
    println!("stderr: {}", String::from_utf8_lossy(&output.stderr));
}

fn open_browser_url(url: String) {
    Command::new("cmd")
        .arg("/c")
        .arg("start")
        .arg(url)
        .spawn()
        .expect("failed to execute process");
}

/// cmd /c start /d "E:\temp"\ cmd
fn open_cmd_dir(dir_path: String) {
    Command::new("cmd")
        .arg("/c")
        .arg("start")
        .arg("/d")
        .arg(dir_path)
        .arg("cmd")
        .spawn()
        .expect("failed to execute process");
}

fn execute_cmd(ctx: Ctx, program_name: String, rest: Rest<String>) -> String {
    let mut command = Command::new(program_name);
    rest.iter().for_each(|item| {
        &command.arg(item);
    });
    let child = command
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .expect("failed to execute command");
    let output = child.wait_with_output().expect("failed to wait on child");
    println!("stdout: {}", String::from_utf8_lossy(&output.stdout));
    println!("stderr: {}", String::from_utf8_lossy(&output.stderr));
    println!("exit status: {}", &output.status);

    // 创建一个空的 Map
    let mut json_map = Map::new();

    let out = String::from_utf8_lossy(&output.stdout).to_string();
    let error = String::from_utf8_lossy(&output.stderr).to_string();
    let exit_status = output.status.to_string();

    // 向 Map 中添加键值对
    json_map.insert("stdout".to_string(), serde_json::value::Value::from(out));
    json_map.insert("stderr".to_string(), serde_json::value::Value::from(error));
    json_map.insert("exit_status".to_string(), serde_json::value::Value::from(exit_status));

    // 将 Map 序列化为 JSON 字符串
    let json_string = serde_json::to_string(&json_map).unwrap();

    println!("{}", json_string);
    // let js_value = ctx.json_parse(json_string);
    // println!("{:?}",js_value.is_ok());

    return json_string;
}

pub fn add_global_function(ctx: &Context) {
    ctx.with(|ctx| {
        let global = ctx.globals();
        global
            .set(
                "execute_cmd",
                Function::new(ctx.clone(), execute_cmd).unwrap(),
            )
            .unwrap();
        global
            .set(
                "open_browser",
                Function::new(ctx.clone(), open_browser_url).unwrap(),
            )
            .unwrap();
        global
            .set("open_dir", Function::new(ctx.clone(), open_dir).unwrap())
            .unwrap();
        global
            .set(
                "open_cmd_dir",
                Function::new(ctx.clone(), open_cmd_dir).unwrap(),
            )
            .unwrap();
        global
            .set(
                "setTimeout",
                Function::new(ctx.clone(), set_timeout).unwrap(),
            )
            .unwrap();
        global
            .set("log", Function::new(ctx.clone(), console_log).unwrap())
            .unwrap();
    });
}