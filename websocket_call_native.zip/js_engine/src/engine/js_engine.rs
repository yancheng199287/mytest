use rquickjs::loader::{FileResolver, ModuleLoader, NativeLoader, ScriptLoader};
use rquickjs::{CatchResultExt, Context, Ctx, Runtime};
use std::sync::{Arc, Mutex};
use crate::engine::add_global_function::add_global_function;

pub struct JSEngine {
    runtime: Runtime,
    context: Context,
}
//JS_ENGINE: engine::js_engine::JSEngine = engine::js_engine::JSEngine::new();
impl JSEngine {
    pub fn new() -> JSEngine {
        let runtime = Runtime::new().unwrap();
        let context = Context::full(&runtime).unwrap();
        let js_engine = JSEngine {
            runtime,
            context,
        };
        js_engine.init();
        js_engine
    }
    pub fn eval(&self, source: &str) -> Result<Option<String>, String> {
        let ctx = &self.context;
        let result = ctx.with(|ctx| {
            let caught_result = ctx.eval::<Option<String>, &str>(source).catch(&ctx);
            if caught_result.is_err() {
                let error = caught_result.unwrap_err().to_string();
                return Err(error);
            }
            return Ok(caught_result.unwrap());
        });
        return result;
    }
    fn init(&self) {
        let mut rt = &self.runtime;
        let mut ctx = &self.context;
        // 设置最大内存 2GB
        rt.set_memory_limit(2 * 1024 * 1024 * 1024);
        // 50MB，开始收集
        rt.set_gc_threshold(50 * 1024 * 1024);
        // 堆栈1MB
        rt.set_max_stack_size(1024 * 1024);
        self.set_loader_resolver(rt);
        add_global_function(ctx)
    }
    pub fn with_ctx<F>(&self, f: F)
        where
            F: FnOnce(Ctx),
    {
        self.context.with(|ctx| f(ctx));
    }
    fn set_loader_resolver(&self, rt: &Runtime) {
        let resolver = (FileResolver::default()
                            .with_path("./")
                            .with_path("./js_bundle")
                            .with_path("./../target/debug")
                            .with_native(), );
        let loader = (
            // ModuleLoader::default().with_module("bundle/native_module", CommonModule),
            ScriptLoader::default(),
            NativeLoader::default(),
        );
        rt.set_loader(resolver, loader);
    }
}