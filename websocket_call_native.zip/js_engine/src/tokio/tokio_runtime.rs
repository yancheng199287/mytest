use std::sync::Arc;
use tokio::runtime::Builder;
use tokio::runtime::Runtime;


lazy_static::lazy_static! {
 pub static ref GLOBAL_TOKIO_RUNTIME: TokioRuntime = {
   TokioRuntime::new()
  };
}
pub struct TokioRuntime {
    runtime: Arc<Runtime>,
}
impl TokioRuntime {
    fn new() -> Self {
        let runtime = Builder::new_multi_thread()
            .enable_io()
            .build()
            .unwrap();
        TokioRuntime {
            runtime: Arc::new(runtime),
        }
    }
    pub fn get_runtime(&self) -> Arc<Runtime> {
        self.runtime.clone()
    }
}

#[test]
fn test1() {
    let global_runtime = TokioRuntime::new();
    // 使用全局异步任务执行
    let runtime = global_runtime.get_runtime();
    runtime.block_on(async {
        // 异步任务代码
    });
}