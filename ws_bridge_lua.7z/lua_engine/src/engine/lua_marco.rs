#[macro_export]
macro_rules! set_global_function {
    ($engine:expr, $name:expr, $func:expr) => {
        {
            let func = $engine.lua.create_function($func).unwrap();
            $engine.set_global_function($name, func).unwrap();
        }
    };
}

#[macro_export]
macro_rules! set_global_property {
    ($engine:expr, $name:expr, $value:expr) => {
        $engine.set_global_property($name, $value).unwrap();
    };
}



#[macro_export]
macro_rules! set_global_module {
    ($engine:expr, $module_name:expr, [$(($prop_key:expr, $prop_value:expr)),*], [$(($func_key:expr, $func_value:expr)),*], [$(($async_func_key:expr, $async_func_value:expr)),*]) => {
        $engine.register_module($module_name, |lua| {
            let exports = lua.create_table().unwrap();

            $(
                exports.set($prop_key, $prop_value).unwrap();
            )*

            $(
                let func = lua.create_function($func_value).unwrap();
                exports.set($func_key, func).unwrap();
            )*

            $(
                let async_func = lua.create_async_function($async_func_value).unwrap();
                exports.set($async_func_key, async_func).unwrap();
            )*

            Ok(exports)
        }).unwrap();
    };
}