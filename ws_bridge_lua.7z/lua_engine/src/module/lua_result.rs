use std::fmt::Display;
use mlua::prelude::{LuaError, LuaResult};

// 定义一个将AnyhowError转换为LuaError的函数
pub fn anyhow_to_lua_error(err: anyhow::Error) -> LuaError {
    LuaError::RuntimeError(err.to_string())
}


// 包装函数，用于解析返回Result的闭包并转换为LuaResult
pub fn wrap_lua_result<T, E, F>(f: F) -> LuaResult<T>
where
    E: Display + Into<anyhow::Error>,
    F: FnOnce() -> Result<T, E>,
{
    f().map_err(|err| anyhow_to_lua_error(err.into()))
}
