use std::process::{Command, Stdio};
use std::time::Duration;
use crate::engine::lua_engine::LuaEngine;
use crate::set_global_module;
use mlua::{Lua, Result as LuaResult, Variadic};
use mlua::prelude::LuaString;
use serde_json::Map;


async fn run_command_with_timeout(lua: &Lua, (program_name, vec_content): (LuaString<'_>, Variadic<LuaString<'_>>)) -> LuaResult<String> {
    let mut command = tokio::process::Command::new(program_name.to_str().unwrap());
    vec_content.iter().for_each(|item| {
        &command.arg(item.to_str().unwrap());
    });
    let child = command
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()?;
    match tokio::time::timeout(Duration::from_secs(5), child.wait_with_output()).await {
        Ok(output) => match output {
            Ok(output) => {
                if output.status.success() {
                    let stdout = String::from_utf8_lossy(&output.stdout);
                    let stderr = String::from_utf8_lossy(&output.stderr);
                    let exit_code = output.status.code().unwrap();
                    // 创建一个空的 Map
                    let mut json_map = Map::new();
                    // 向 Map 中添加键值对
                    json_map.insert("stdout".to_string(), serde_json::value::Value::from(stdout));
                    json_map.insert("stderr".to_string(), serde_json::value::Value::from(stderr));
                    json_map.insert("exit_status".to_string(), serde_json::value::Value::from(exit_code));
                    let json_string = serde_json::to_string(&json_map).unwrap();
                    Ok(json_string)
                } else {
                    Err(mlua::Error::external(format!("Command failed: {}", String::from_utf8_lossy(&output.stderr))))
                }
            }
            Err(e) => Err(mlua::Error::external(format!("Failed to wait for command output: {}", e))),
        },
        Err(_) => Err(mlua::Error::external("Command timed out")),
    }
}


fn execute_std_cmd(lua: &Lua, (program_name, vec_content): (LuaString, Variadic<LuaString>)) -> LuaResult<String> {
    let mut command = Command::new(program_name.to_str().unwrap());
    vec_content.iter().for_each(|item| {
        &command.arg(item.to_str().unwrap());
    });
    let child = command
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()?;
    let output = child.wait_with_output()?;
    let stdout = String::from_utf8_lossy(&output.stdout);
    let stderr = String::from_utf8_lossy(&output.stderr);
    let exit_code = output.status.code().unwrap();
    // 创建一个空的 Map
    let mut json_map = Map::new();
    // 向 Map 中添加键值对
    json_map.insert("stdout".to_string(), serde_json::value::Value::from(stdout));
    json_map.insert("stderr".to_string(), serde_json::value::Value::from(stderr));
    json_map.insert("exit_status".to_string(), serde_json::value::Value::from(exit_code));
    let json_string = serde_json::to_string(&json_map).unwrap();
    Ok(json_string)
}

pub fn register_lua_module1(lua_engine: &LuaEngine) {
    set_global_module!(lua_engine,"command",
    [],
    [],
    [("execute_std_cmd",run_command_with_timeout)]
    );
}

pub fn register_lua_module12(lua_engine: &LuaEngine) {
    set_global_module!(lua_engine,"command",
    [],
    [("execute_std_cmd",execute_std_cmd)],
    []
    );
}

/*
如果需要些脚本，内置一个模板，设置好utf-8编码
@echo start execute script...
chcp 65001 > null
echo "好咯，编码正确处理显示吧"
copy "E:\workspace\ui\123.txt" "d:\"
cd "E:\workspace\rust\mlua_demo"
cargo build
*/