use std::any::Any;
use std::collections::HashMap;
use std::fs::OpenOptions;
use std::path::Path;
use std::sync::{Arc, Mutex};
use async_trait::async_trait;
use idgenerator::IdInstance;
use log::error;
use mlua::{Lua, UserData};
use mlua::prelude::LuaString;
use serde_json::Value;
use tokio::task::JoinHandle;
use warp::{Filter, Rejection, Reply};
use tokio::runtime::Runtime;
use crate::engine::lua_engine::LuaEngine;
use crate::module::config::Config;
use crate::reuse::long_object::LongObject;
use crate::reuse::long_object_factory;
use crate::set_global_module;

pub struct WarpServer {
    handle: Option<JoinHandle<()>>,
    rt: Arc<Mutex<Runtime>>,
    web_dir: String,
}

impl WarpServer {
    pub fn new(web_dir: String) -> Self {
        let rt = Arc::new(Mutex::new(Runtime::new().unwrap()));
        Self {
            handle: None,
            rt,
            web_dir,
        }
    }

    pub fn start(&mut self) {
        let rt = Arc::clone(&self.rt);
        let web_dir = self.web_dir.clone();
        let func = start_warp_server(web_dir);
        self.handle = Some(rt.lock().unwrap().spawn(func));
    }

    pub fn stop(&mut self) {
        if let Some(handle) = &self.handle {
            handle.abort();
            self.handle = None;
        }
    }
}

pub fn start_web_server(web_dir: String) -> Arc<Mutex<WarpServer>> {
    let mut warp_server = WarpServer::new(web_dir);
    warp_server.start();
    Arc::new(Mutex::new(warp_server))
}

async fn start_warp_server(web_dir: String) {
    let route = router(web_dir).await;
    warp::serve(route).run(([127, 0, 0, 1], 3030)).await;
}


pub fn stop_warp_server(warp_server: Arc<Mutex<WarpServer>>) {
    warp_server.lock().unwrap().stop();
}


async fn router(web_dir: String) -> impl Filter<Extract=impl Reply + 'static, Error=Rejection> + Clone + 'static {
    // 检查静态目录路径
    let static_path = Path::new(&web_dir);
    if !static_path.exists() || !static_path.is_dir() {
        error!("Static directory does not exist or is not a directory");
        std::process::exit(1);
    }
    let index_file = "index.html".to_string(); // 索引文件
    let index_route = warp::path::end()
        .and(warp::fs::file(static_path.join(index_file)));

    let web_static_router = warp::path("web")
        .and(warp::fs::dir(web_dir))
        .recover(handle_rejection);
    let routes = index_route.or(web_static_router);
    routes
}

async fn handle_rejection(err: Rejection) -> Result<impl Reply, Rejection> {
    println!("{:?}", err);
    if err.is_not_found() {
        println!("Error: {:?}", err);
        Ok(warp::reply::with_status(
            "NOT_FOUND".to_string(),
            warp::http::StatusCode::NOT_FOUND,
        ))
    } else {
        Err(err)
    }
}


impl UserData for WarpServer {
    fn add_methods<'lua, M: mlua::UserDataMethods<'lua, Self>>(methods: &mut M) {
        methods.add_method_mut("getInstanceId", |_, this, _: ()| {
            this.start();
            Ok(())
        });


        methods.add_method_mut("start", |_, this, _: ()| {
            this.start();
            Ok(())
        });
        methods.add_method_mut("stop", |_, this, _: ()| {
            this.stop();
            Ok(())
        });
    }
}

#[async_trait]
impl LongObject for WarpServer {
    async fn init(&mut self) {
        self.start();
        println!("WarpServer init");
    }

    fn as_any(&self) -> &dyn Any {
        self
    }

    async fn destroy(&mut self) {
        self.stop();
    }
}


pub async fn new(lua: &Lua, static_dir: (String)) -> mlua::Result<i64> {
    let app_name: String = lua.globals().get("APP_NAME").unwrap();
    //let static_dir = "C:\\Users\\yancheng\\AppData\\Local\\com.oneinlet.app\\miniProgram".to_string(); // 静态文件目录
    let warp_server = WarpServer::new(static_dir);
    let factory = long_object_factory::get_global_long_object_factory();
    let object_id = factory.create_object(app_name.as_str(), warp_server).await;
    Ok(object_id)
}


pub fn register_lua_module(lua_engine: &LuaEngine) {
    set_global_module!(lua_engine,"module_config",
        [],
        [],
        [("new", new)]
        );
}