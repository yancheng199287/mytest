use std::any::Any;
use async_trait::async_trait;


#[async_trait]
pub trait LongObject: Any + Send + Sync {
    async fn init(&mut self);

    // 添加 as_any 方法
    fn as_any(&self) -> &dyn Any;

    async fn destroy(&mut self);
}
