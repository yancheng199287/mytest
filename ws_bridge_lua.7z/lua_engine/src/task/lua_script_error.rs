use std::fmt;
use mlua::prelude::LuaError;
use anyhow::{Error as AnyhowError, Result as AnyhowResult};

// 定义一个新的错误类型，其 Err 变体包含一个 String 对象
// 定义错误类型
#[derive(Debug)]
pub struct LuaScriptError {
    pub code: u16,
    pub msg: String,
}

// 实现 Display trait，以便可以将 MyError 类型转换为字符串

// 实现 `Display` 特征用于格式化错误消息
// 实现 `Display` 特征用于格式化错误消息
impl fmt::Display for LuaScriptError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "code: {}, msg: {}", self.code, self.msg)
    }
}

// 实现 Error trait，以便可以将 MyError 类型转换为标准库的错误类型
impl std::error::Error for LuaScriptError {}



// 定义错误码和消息的宏
#[macro_export]
// 定义错误码和消息的宏
// 定义宏来创建带有详细消息的错误
macro_rules! define_error_with_detail {
    ($name:ident, $code:expr, $default_msg:expr) => {
        pub fn $name(detail: String) -> LuaScriptError {
            LuaScriptError {
                code: $code,
                msg: format!("{}, {}", $default_msg, detail),
            }
        }
    };
}

// 定义宏来创建不带详细消息的错误
#[macro_export]
macro_rules! define_error {
    ($name:ident, $code:expr, $default_msg:expr) => {
        pub fn $name() -> LuaScriptError {
            LuaScriptError {
                code: $code,
                msg: $default_msg.to_string(),
            }
        }
    };
}
// 定义一些常见的错误码和消息
/// js无缝调用lua，lua无缝调用rust/c/c++    满足 速度 性能 体积，配合前端大生态UI，桌面软件的最佳之选。
impl LuaScriptError {
    define_error_with_detail!(lua_script_eval_error, 1001, "script error");
    define_error!(lua_script_eval_timeout_error, 1002, "task timed out, limit 5 seconds");
    define_error!(lua_script_return_value_error, 1003, "only supports returning one [String] type data");
    define_error_with_detail!(database_error, 1004, "database error");
    define_error!(network_error, 1005, "network error");
    define_error!(invalid_input, 1006, "invalidated input");
    define_error!(unknown_error, 1007, "unknown error");
}



// 在业务逻辑中使用自定义错误类型
fn some_database_operation() -> Result<(), LuaScriptError> {
    Err(LuaScriptError::database_error("连接失败".to_string()))
}

fn some_network_operation() -> Result<(), LuaScriptError> {
    Err(LuaScriptError::network_error())
}

#[test]
fn test() {
    match some_network_operation() {
        Ok(_) => println!("请求成功"),
        Err(e) => println!("{}", e),
    }
}