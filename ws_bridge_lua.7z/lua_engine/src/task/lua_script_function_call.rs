use mlua::prelude::*;
use mlua::{Value as LuaValue};
use serde_json::{Value as JsonValue, Value};
use std::time::Duration;
use moka::future::Cache;
use serde::Deserialize;

lazy_static::lazy_static! {
   static ref GLOBAL_LUA_SCRIPT_CACHE: Cache<String, String>= {
            // 创建一个缓存，容量为 200，条目
    let cache = Cache::builder()
        .max_capacity(200)
        // time_to_live（生存时间）参数设置缓存条目的固定存活时间。无论条目是否被访问，只要存活时间到期，条目就会被自动移除
        .time_to_live(Duration::from_secs(60 * 60))// 最大存活60分钟
        // time_to_idle（闲置时间）参数设置条目在闲置状态下的存活时间。如果在指定的时间内条目没有被访问，它就会被移除。
        .time_to_idle(Duration::from_secs(60 * 30))// 最大空闲30分钟
        // expire_after 参数允许对条目过期的策略进行更细粒度的控制，可以基于自定义逻辑确定条目何时过期。它可以同时包含 create, update 和 access 三种过期策略。
        // .expire_after(Duration::from_secs(30)) // 基于创建时间的过期策略，设置为30秒
        .build();
   cache
  };
}

async fn load_cache_script(path: &str) -> LuaResult<String> {
    if !GLOBAL_LUA_SCRIPT_CACHE.contains_key(path) {
        let script_content = std::fs::read_to_string(path).map_err(|e| mlua::Error::external("read script file error,".to_owned() + &e.to_string()))?;
        let script_content_clone = script_content.clone();
        GLOBAL_LUA_SCRIPT_CACHE.insert(path.to_string(), script_content).await;
        return Ok(script_content_clone);
    }
    let source_code_option = GLOBAL_LUA_SCRIPT_CACHE.get(path).await;
    match source_code_option {
        Some(source_code) => Ok(source_code),
        None => Err(mlua::Error::external("read script file is empty from cache"))
    }
}

async fn load_file_script(path: &str) -> LuaResult<String> {
    let script_content = std::fs::read_to_string(path).map_err(|e| mlua::Error::external("read script file error,".to_owned() + &e.to_string()))?;
    return Ok(script_content);
}

#[derive(Deserialize)]
struct LuaScriptFunctionPayload {
    lua_file_path: String,
    function_name: String,
    function_params: Value,
}

fn json_to_lua_value(lua: &Lua, json_value: JsonValue) -> LuaResult<LuaValue> {
    match json_value {
        JsonValue::Null => Ok(LuaValue::Nil),
        JsonValue::Bool(b) => Ok(LuaValue::Boolean(b)),
        JsonValue::Number(n) => {
            if let Some(i) = n.as_i64() {
                Ok(LuaValue::Integer(i))
            } else if let Some(f) = n.as_f64() {
                Ok(LuaValue::Number(f))
            } else {
                Err(LuaError::RuntimeError("Invalid JSON number".to_string()))
            }
        }
        JsonValue::String(s) => Ok(LuaValue::String(lua.create_string(&s)?)),
        JsonValue::Array(arr) => {
            let tbl = lua.create_table()?;
            for (i, val) in arr.into_iter().enumerate() {
                tbl.set(i + 1, json_to_lua_value(lua, val)?)?;
            }
            Ok(LuaValue::Table(tbl))
        }
        JsonValue::Object(obj) => {
            let tbl = lua.create_table()?;
            for (k, val) in obj.into_iter() {
                tbl.set(k, json_to_lua_value(lua, val)?)?;
            }
            Ok(LuaValue::Table(tbl))
        }
    }
}

/// 对前端传参过来的请求参数转换为可执行的脚本字符串，给lua引擎执行
pub async fn generate_lua_script(json_payload: &str) -> LuaResult<String> {
    let payload: LuaScriptFunctionPayload = serde_json::from_str(json_payload).map_err(|e| mlua::Error::external("serde json error,".to_owned() + &json_payload))?;
    let file_path = &payload.lua_file_path;
    // 加载Lua脚本到缓存
    //let mut source_code = load_cache_script(file_path).await?;
    let mut source_code = load_file_script(file_path).await?;
    let params = &payload.function_params;
    println!("===>{}",params);
    let params = json_value_to_lua_table_str(&payload.function_params);
    source_code = format!("{}\n return {}({})", source_code, payload.function_name, params);
    println!("{}", source_code);
    Ok(source_code)
}

/// 将json对象值转换为lua的table形式的字符串
fn json_value_to_lua_table_str(value: &JsonValue) -> String {
    match value {
        JsonValue::Null => "nil".to_string(),
        JsonValue::Bool(b) => b.to_string(),
        JsonValue::Number(n) => n.to_string(),
        JsonValue::String(s) => format!("\"{}\"", s),
        JsonValue::Array(arr) => {
            let elements: Vec<String> = arr.iter().map(|v| json_value_to_lua_table_str(v)).collect();
            format!("{{ {} }}", elements.join(", "))
        }
        JsonValue::Object(obj) => {
            let mut elements: Vec<String> = Vec::new();
            for (k, v) in obj.iter() {
                elements.push(format!("{} = {}", escape_key(k), json_value_to_lua_table_str(v)));
            }
            format!("{{ {} }}", elements.join(", "))
        }
    }
}

fn escape_key(key: &str) -> String {
    if key.chars().all(|c| c.is_alphanumeric() || c == '_') {
        key.to_string()
    } else {
        format!("[\"{}\"]", key)
    }
}
