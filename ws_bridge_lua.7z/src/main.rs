use crate::websocket::call_lua_script::start_lua_script_task_scheduler;

mod websocket;
mod model;
mod util;


fn main() {
    println!("Hello, world!");

    log4rs::init_file("config/log4rs.yaml", Default::default()).unwrap();

    websocket::start_websocket().unwrap();
}


