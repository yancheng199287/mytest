use tokio::runtime::{Builder, Runtime};
use tokio::task::JoinHandle;


pub struct TokioWrapper {
    runtime: Runtime,
}

impl TokioWrapper {
    pub fn new() -> Self {
        let runtime = Builder::new_multi_thread()
            .enable_all()
            .worker_threads(30)
            .thread_name("my-websocket-name")
            .thread_stack_size(10 * 1024 * 1024)
            .build()
            .unwrap();
        TokioWrapper { runtime }
    }
    pub fn new_num_thread(num_threads: usize) -> Self {
        let runtime = Builder::new_multi_thread()
            .enable_all()
            .worker_threads(num_threads)
            .thread_name("my-websocket-name")
            .thread_stack_size(10 * 1024 * 1024)
            .build()
            .unwrap();
        TokioWrapper { runtime }
    }

    pub fn spawn<F>(&self, task: F) -> JoinHandle<F::Output>
        where
            F: std::future::Future + Send + 'static,
            F::Output: Send + 'static,
    {
        self.runtime.spawn(task)
    }

    pub fn block_on<F>(&self, future: F) -> F::Output
        where
            F: std::future::Future + Send,
            F::Output: Send,
    {
        self.runtime.block_on(future)
    }
}