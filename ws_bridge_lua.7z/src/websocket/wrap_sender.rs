use tokio::sync::mpsc;
use crate::model::response_payload::ResponseData;

pub struct WrapSender {
    pub id: i64,
    sender: mpsc::Sender<ResponseData>,
}

impl WrapSender {
    pub fn new(id: i64, sender: mpsc::Sender<ResponseData>) -> WrapSender {
        WrapSender {
            id,
            sender,
        }
    }

    pub async fn send(&self, data: ResponseData) {
        self.sender.send(data).await.unwrap();
    }
}