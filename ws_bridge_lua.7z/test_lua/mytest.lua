local json = require("json")
local function listen_clipboard(table)
    local json_str = json.encode(table)
    print("hello,")
    print(json_str)
    return json_str
end
local function read_clipboard(request_table_data)
    local table = {
        your_name = request_table_data["name"],
        your_age = request_table_data["age"],
    }
    local json_str = json.encode(table)
    local cc = complex_computation(10000000);
    print("cc",cc)
    print("hello,")
    print(json_str)
    local str3 = "这是将json转换入参 table，再将入参table转换json的一个测试函数，转换结果：" .. " " .. json_str..cc
    return str3
end

local function test1()
    local cc = complex_computation(100);
    return tostring(cc)
end

function complex_computation(iterations)
    local sum = 0
    for i = 1, iterations do
        sum = sum + math.sqrt(i) * math.sin(i)
    end
    return sum
end