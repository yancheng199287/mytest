local file_util = require("file_util")

local book_path = "E:\\temp\\mybook2.txt"
local book1_path = "E:\\temp\\mybook1.txt"

local index = 1
start_timer(function()
    log("timer index:",index)
    index= index+1
end,0,800,-1)

-- 文件如果不存在就创建这个文件，false是针对目录的时候需要循环递归创建子目录，如果是文件就填写false
if not file_util.file_exists(book_path) then
    file_util.create(book_path, false)
end

-- 读取文件内容
local content = file_util.read(book_path)
log(content)

-- 写入文件内容
file_util.write(book_path, "New content, OK!~")

-- 复制目录，递归复制，包括文件
file_util.copy_dir("E:\\temp\\my", "E:\\temp\\the1")

-- 仅仅复制一个文件到另外一个地方
file_util.copy_file(book_path, book1_path)

-- 休眠之后删除文件，删除文件或者目录
sleep(function()
    file_util.delete(book_path)
    file_util.delete(book1_path)
    log("delete ok!")
end, 2000)

