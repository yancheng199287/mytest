local json = require("json")

local data = {
    name = "json",
    age = 18,
    sex = "man",
    hobby = {
        "football",
        "basketball",
        "swimming",
        "running"
    }
}
local json_str = json.encode(data)
print("json_str: ", json_str)

local json_object = json.decode(json_str)


-- 使用索引访问数组，从1开始
print(json_object.hobby[1])


-- 使用 ipairs 迭代数组
for index, element in ipairs(json_object.hobby) do
    print("element==>",index, element)
end

for key, value in pairs(json_object) do
    log("==>", key, value)
end




return json_str