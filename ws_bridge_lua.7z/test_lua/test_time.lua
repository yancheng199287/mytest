-- 导入 Rust 时间处理模块
local time = require("module_time")

-- 创建时间处理实例
local t = time.new()
log("ttt",t)

local aa = t:current_time()
log("year",aa.year)
log("month",aa.month)
for key, value in pairs(aa) do
    print(key, value)
end

-- 获取当前时间
print("Current Time:", t:current_time())

-- 格式化时间
print("Formatted Time:", t:format_time("2024-05-03T12:34:56", "%Y-%m-%d %H:%M:%S"))

-- 解析时间字符串
local parsed_time = t:parse_time("2024-05-03T12:34:56")
print("Parsed Time:", parsed_time)

-- 比较时间
local time_diff = t:compare_time("2024-05-03T12:00:00", "2024-05-03T11:00:00")
print("Time Difference (seconds):", time_diff)

-- 其他方法测试
-- 这里可以添加其他时间处理方法的测试

-- 结果测试
local start_time = "2024-05-01T00:00:00"
local end_time = "2024-05-10T23:59:59"
local test_time = "2024-05-05T12:00:00"
print("Is within interval:", t:is_within_interval(test_time, start_time, end_time))
