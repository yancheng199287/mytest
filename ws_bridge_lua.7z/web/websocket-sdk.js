//import './payload';

class WebSocketSDK {
    constructor(url, connectCallback) {
        this.url = url;
        this.socket = null;
        /// 注意内存泄露，这里会缓存消息id，如果没有及时清理会导致内存泄露
        this.callbacks = {};
        this.connectCallback = connectCallback;
        this.connect();
    }

    connect() {
        this.socket = new WebSocket(this.url);
        this.socket.onopen = () => {
            console.log('WebSocket connected');
            this.connectCallback(true);
        };
        this.socket.onmessage = (event) => {
            console.log("WebSocket Receive data：", event)
            const response_data = JSON.parse(event.data);
            const {msg_id, data, code, msg} = response_data;
            const callbackObject = this.callbacks[msg_id];
            if (!callbackObject) {
                console.log("can not find callback id: ", msg_id)
                return;
            }
            if (code !== 0) {
                callbackObject.reject(msg);
            } else {
                callbackObject.resolve(data);
            }

            console.log("callbacks:", this.callbacks[msg_id]);
            // 长连接的任务不断获取的数据函数，需要手动调用stop来删除， 这里如果是一次性的就删除，如果不是就需要用户自己手动关闭
            if (!callbackObject.isStream) {
                delete this.callbacks[msg_id];
            }
        };
        this.socket.onerror = (error) => {
            console.error('WebSocket error:', error);
            this.connectCallback(false);
        };
        this.socket.onclose = () => {
            console.log('WebSocket closed');
            // 重置回调清空
            this.callbacks = {};
            setTimeout(() => {
                this.connect();
            }, 3000);
        };
    }

    /// 设置一个变量 布尔值 isStream， 如果true，在接收到对应id的消息的时候不要立即删除  delete this.callbacks[id];，而是手动去删除关闭
    /// 默认 isStream 是关闭的，即一次性，适用于调用一个函数之类的
    send(wsPayload, isStream) {
        const message = JSON.stringify(wsPayload);
        return new Promise((resolve, reject) => {
            this.callbacks[wsPayload.header.msg_id] = {resolve, reject, isStream};
            this.socket.send(message);
        });
    }

    sendShortRequest(wsPayload) {
        return this.send(wsPayload, false)
    }

    /// 模拟长链接，某个任务id需要长期获取数据，如实时获取cpu占用率, 其实websocket肯定是长链接，这里指代的是长时间接收服务器发来的数据响应
    /// 而不是收到立即就结束掉了，可以长时间接收。
    sendLongRequest(wsPayload) {
        return this.send(wsPayload, true)
    }

    /// 长链接的任务需要手动关闭,避免id膨胀，内存泄露
    closeLongRequest(id) {
        delete this.callbacks[id];
    }

    close() {
        this.socket.close();
    }
}