use std::cell::RefCell;
use std::sync::{Arc, Mutex, MutexGuard};
use chrono::{DateTime, Local};
use log::error;
use mlua::{Lua, Result, Function, Value, FromLuaMulti, IntoLuaMulti, IntoLua, Table, LuaOptions, HookTriggers, Error, Variadic};
use mlua::prelude::{LuaStdLib, LuaValue};
use once_cell::sync::OnceCell;
use crate::module::lua_public_module::{log, sleep, start_timer};

pub struct LuaEngine {
    lua: Lua,  // 将Lua实例包装在Arc中,可以支持多线程共享lua引擎对象
}

/// 这里默认一个全局的lua引擎，如果是多线程并发使用计算脚本，需要创建多个引擎，可以使用 new()函数创建
static LUA_ENGINE_INSTANCE: OnceCell<Arc<Mutex<LuaEngine>>> = OnceCell::new();


impl LuaEngine {
    pub fn get_lua_engine() -> MutexGuard<'static, LuaEngine> {
        let lua_engine = LUA_ENGINE_INSTANCE.get_or_init(|| {
            Arc::new(Mutex::new(LuaEngine::new()))
        });
        return lua_engine.lock().unwrap();
    }

    pub fn new() -> Self {
        let option = LuaOptions::new().thread_pool_size(10).catch_rust_panics(true);
        /// unsafe_new_with支持c模块加载
        let lua = unsafe { Lua::unsafe_new_with(LuaStdLib::ALL, option) };
        lua.set_memory_limit(4 * 1024 * 1024 * 1024).unwrap();
        let lua_engine = LuaEngine { lua };
        init(&lua_engine);
        lua_engine
    }

    pub fn init_lua_engine<F: Fn(&LuaEngine)>(&self, f: F) {
        f(self);
    }


    // 设置自定义模块路径
    pub fn set_custom_module_path(&self, path_option: Option<&str>, cpath_option: Option<&str>) {
        let package: Table = self.lua.globals().get("package").unwrap();
        let current_path: String = package.get("path").unwrap();
        let current_cpath: String = package.get("cpath").unwrap();

        if let Some(path) = path_option {
            let new_path = format!("{};{}", current_path, path);
            package.set("path", new_path).unwrap();
        }
        if let Some(path) = cpath_option {
            let new_path = format!("{};{}", current_cpath, path);
            package.set("cpath", new_path).unwrap();
        }
    }

    /// 获取 loaded的table，这个table可以放其他的table模块，以便你可以使用 require("module")来找到并加载成功
    pub fn get_package_loaded_module_table(&self) -> Table {
        let table = self.lua.globals().get::<_, Table>("package").unwrap();
        let loaded_table = table.get::<_, Table>("loaded").unwrap();
        return loaded_table;
    }

    /// 设置loaded的table
    pub fn set_package_loaded_module_table(&self, name: &str, module_table: Table) -> Result<()> {
        self.get_package_loaded_module_table().set(name, module_table).unwrap();
        Ok(())
    }

    // 注册Rust模块到Lua
    pub fn register_module<F>(&self, module_name: &str, module_func: F) -> Result<()>
        where
            F: Fn(&Lua) -> Result<Table> + 'static,
    {
        let module = module_func(&self.lua).unwrap();
        self.lua.globals().set(module_name, module.clone()).unwrap();
        self.set_package_loaded_module_table(module_name, module.clone()).unwrap();
        Ok(())
    }


    // 添加全局函数
    pub fn set_global_function<'lua>(&self, name: &str, value: Function<'lua>) -> Result<()> {
        self.lua.globals().set(name, value)?;
        Ok(())
    }

    // 添加全局属性
    pub fn set_global_property<V: for<'lua> IntoLua<'lua>>(&self, name: &str, value: V) -> Result<()> {
        self.lua.globals().set(name, value)?;
        Ok(())
    }


    pub fn process_result<'lua>(&self, result: Result<Value<'lua>>) -> Result<Value<'lua>> {
        if result.is_err() {
            error!("exec_script: {:?}",result);
            return Err(result.expect_err("exec script error "));
        }
        return result;
    }

    // 执行Lua脚本
    pub fn exec_script(&self, code: &str) -> Result<Value> {
        let result = self.lua.load(code).exec();
        if result.is_ok() {
            return self.process_result(Ok(Value::Nil));
        }
        return self.process_result(Err(result.unwrap_err()));
    }

    // 执行Lua脚本
    pub fn eval_script(&self, code: &str) -> Result<Value> {
        let result = self.lua.load(code).eval::<Value>();
        if result.is_ok() {
            return self.process_result(Ok(Value::Nil));
        }
        return self.process_result(Err(result.unwrap_err()));
    }

    // 异步执行Lua脚本
    pub async fn async_exec_script(&self, code: String) -> Result<Value> {
        let result = self.lua.load(code).eval_async().await;
        return self.process_result(result);
    }

    pub async fn async_exec_script1(&self, code: &str) -> Result<Value> {
        let result = self.lua.load(code).eval_async().await;
        return self.process_result(result);
    }
}


pub fn init(lua_engine: &LuaEngine) {

    lua_engine.init_lua_engine(|lua_engine| {
        let path_option: Option<&str> = Some("F:\\workspace\\rust\\ws_bridge_lua\\external_lua_module\\lua_script\\?.lua");
        let cpath_option: Option<&str> = Some("F:\\workspace\\rust\\ws_bridge_lua\\external_lua_module\\lua_native\\?.dll");
        lua_engine.set_custom_module_path(path_option, cpath_option);


        lua_engine.set_global_property("APP_NAME", "FastOpen").unwrap();
        let log_func = lua_engine.lua.create_function(log).unwrap();
        let sleep_func = lua_engine.lua.create_async_function(sleep).unwrap();
        let start_timer_func = lua_engine.lua.create_async_function(start_timer).unwrap();
        lua_engine.set_global_function("log", log_func).unwrap();
        lua_engine.set_global_function("sleep", sleep_func).unwrap();
        lua_engine.set_global_function("start_timer", start_timer_func).unwrap();

        crate::module::config::register_lua_module1(lua_engine);
        crate::module::file::file_util::register_lua_module1(lua_engine);
        crate::module::std::time::register_lua_module1(lua_engine);
    });
}


#[test]
fn test_lua_engine() {
    let lua_engine = LuaEngine::get_lua_engine();
    lua_engine.exec_script("print('hello world')");
}