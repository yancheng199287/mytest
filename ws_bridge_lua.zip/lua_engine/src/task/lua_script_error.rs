use std::fmt;

// 定义一个新的错误类型，其 Err 变体包含一个 String 对象
#[derive(Debug)]
pub struct LuaScriptError(pub String);

// 实现 Display trait，以便可以将 MyError 类型转换为字符串
impl fmt::Display for LuaScriptError {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        write!(f, "{}", self.0)
    }
}

// 实现 Error trait，以便可以将 MyError 类型转换为标准库的错误类型
impl std::error::Error for LuaScriptError {}


