use std::borrow::Borrow;
use std::cell::{Cell, RefCell};
use std::cmp::max;
use crossbeam_channel::{bounded, Receiver, Sender, TrySendError};
use std::sync::{Arc, Mutex};
use std::time::Duration;
use log::info;
use rand::{random, Rng, thread_rng};
use rayon::ThreadPool;
use crate::task::lua_script_task::{LuaScriptTask, LuaScriptTaskResult};
use crate::task::{lua_script_task, scheduler};
use crate::task::thread_local_container::ThreadContainer;

// 任务调度器
pub struct LuaTaskScheduler<LuaScriptTask> {
    pub thread_pool: ThreadPool,
    pub task_sender: Sender<LuaScriptTask>,
    pub task_receiver: Receiver<LuaScriptTask>,
    pub notification_sender: Sender<LuaScriptTaskResult>,
    pub notification_receiver: Receiver<LuaScriptTaskResult>,
    pub vec_local_thread_bounded: Vec<(Sender<LuaScriptTask>, Receiver<LuaScriptTask>)>,
}


impl LuaTaskScheduler<LuaScriptTask> {
    pub fn new(max_threads: usize, max_queue_size: usize) -> Self {
        // 创建线程池
        let thread_pool = crate::task::thread_pool::create_thread_pool(max_threads);
        // 根据线程大小，为每个线程创建一个队列，方便调度任务
        let mut vec_local_thread_bounded: Vec<(Sender<LuaScriptTask>, Receiver<LuaScriptTask>)> = Vec::with_capacity(max_threads);
        for _ in 0..max_threads {
            vec_local_thread_bounded.push(bounded(max_queue_size))
        }
        //  外部客户端向调度器发送消息，调度器接收之后，根据调度规则，向线程的通道队列发送消息
        let (task_sender, task_receiver) = bounded(max_queue_size);
        let (notification_sender, notification_receiver) = bounded(max_queue_size);
        // 启动通知处理线程
        /*  std::thread::spawn(move || {
              while let Ok(notification) = notification_receiver.recv() {
                  println!("任务完成: {}", notification);
              }
          });*/
        LuaTaskScheduler {
            thread_pool,
            task_sender,
            task_receiver,
            notification_sender,
            notification_receiver,
            vec_local_thread_bounded,
        }
    }
    // 非阻塞添加任务
    pub fn try_add_task(&self, task: LuaScriptTask) {
        match self.task_sender.try_send(task) {
            Ok(value) => {
                println!("任务添加成功");
            }
            Err(TrySendError::Full(_)) => {
                println!("任务队列已满，丢弃任务");
            }
            Err(e) => {
                println!("无法添加任务: {:?}", e);
            }
        }
    }

    /// 基于轮询的负载均衡器，统一对外接收消息，然后根据轮询索引下标规则，发送给对应的线程处理任务
    fn load_balance_scheduler_event(&self) {
        let task_receiver_clone = self.task_receiver.clone();
        let vec_local_thread_bounded = self.vec_local_thread_bounded.clone();
        // 轮询调度器线程
        std::thread::spawn(move || {
            let vec_sender = vec_local_thread_bounded.clone();
            let task_receiver_clone = task_receiver_clone.clone();
            let num_threads = vec_sender.len();
            let mut round_robin_index = 0;
            while let Ok(task) = task_receiver_clone.recv() {
                println!("接收task--------- {}", task.task_id);
                if let Some(bound) = vec_sender.get(round_robin_index) {
                    bound.0.send(task).expect("Failed to send task");
                }
                round_robin_index = (round_robin_index + 1) % num_threads;
            }
        });
    }
    // 开始任务调度
    pub fn start(&self) {
        self.load_balance_scheduler_event();
        let task_receiver = Arc::new(Mutex::new(self.task_receiver.clone()));
        let vec_local_thread_bounded = self.vec_local_thread_bounded.clone();
        let notification_sender = self.notification_sender.clone();
        self.thread_pool.install(|| {
            rayon::scope(|s| {
                for index in 0..self.thread_pool.current_num_threads() {
                    let task_receiver = task_receiver.clone();
                    let notification_sender = notification_sender.clone();
                    // 定义线程本地状态，缓存lua引擎和tokio运行时
                    thread_local! {
                       pub static GLOBAL_THREAD_CONTAINER: RefCell<ThreadContainer> = RefCell::new(ThreadContainer::new());
                    }
                    let local_thread_task_bound = vec_local_thread_bounded.get(index).unwrap();
                    let local_thread_task_receiver = local_thread_task_bound.clone().1.clone();
                    s.spawn(move |_| {
                        let mut random = thread_rng();
                        GLOBAL_THREAD_CONTAINER.with(|local_thread_container| {
                            println!("初始化线程");
                            while let Ok(task) = local_thread_task_receiver.recv() {
                                let id = std::thread::current().id();
                                info!("接受到任务，准备执行: id = {:?}", id);

                                let result = task.execute(local_thread_container);

                                let lua_script_task_result = LuaScriptTaskResult::new(task.task_id, task.client_sender_id, result);
                                info!("执行结果：lua_script_task_result{:?}", lua_script_task_result);

                                notification_sender.send(lua_script_task_result).expect("Failed to send notification");
                            }
                        });
                    });
                }
            });
        });
    }
}