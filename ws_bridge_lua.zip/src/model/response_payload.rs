use fastwebsockets::{Frame, Payload};
use serde::{Deserialize, Serialize};

#[derive(Debug, Serialize, Deserialize)]
pub struct ResponseData {
    pub(crate) app_id: String,
    pub(crate) msg_id: String,
    pub(crate) code: u8,
    pub(crate) msg: Option<String>,
    pub(crate) data: Option<String>,
}

impl ResponseData {
    pub fn build_ok(app_id: String, msg_id: String) -> ResponseData {
        return ResponseData {
            app_id,
            msg_id,
            code: 0,
            msg: None,
            data: None,
        };
    }

    pub fn build_content_ok(app_id: String, msg_id: String, content: String) -> ResponseData {
        return ResponseData {
            app_id,
            msg_id,
            code: 0,
            msg: None,
            data: Some(content),
        };
    }


    pub fn build_error(app_id: String, msg_id: String, error_code: u8, error_msg: String) -> ResponseData {
        return ResponseData {
            app_id,
            msg_id,
            code: error_code,
            msg: Some(error_msg),
            data: None,
        };
    }

    pub fn convert_to_text_frame(&self) -> Frame {
        // 创建文本消息帧
        let text_message = serde_json::to_string(&self).unwrap();
        let payload = Payload::from(text_message.into_bytes());
        return Frame::text(payload);
    }
}


