use idgenerator::{IdGeneratorOptions, IdInstance, IdVecInstance};

pub fn init_id_generator() {
    let options = IdGeneratorOptions::new().worker_id(1).worker_id_bit_len(6);
    let options = IdGeneratorOptions::new().worker_id(1).worker_id_bit_len(6);
    let options = IdGeneratorOptions::new().worker_id(1).worker_id_bit_len(6);
    let options = IdGeneratorOptions::new().worker_id(1).worker_id_bit_len(6);
    IdInstance::set_options(options).unwrap();

}


#[test]
fn test1(){
    for i in 0..10 {
       let id =  IdInstance::next_id();
        IdVecInstance::next_id(0);
        println!("id==>{}",id)
    }
}