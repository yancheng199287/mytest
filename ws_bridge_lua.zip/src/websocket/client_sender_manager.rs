use std::sync::Arc;
use dashmap::DashMap;
use idgenerator::IdInstance;
use tokio::sync::mpsc;
use crate::model::response_payload::ResponseData;




lazy_static::lazy_static! {
  pub static ref GLOBAL_CLIENT_SENDER_MANAGER: Arc<ClientSenderManager>= {
    Arc::new(ClientSenderManager::new())
  };
}


pub struct ClientSenderManager {
    pub client_sender_map: DashMap<i64, mpsc::Sender<ResponseData>>,
}

impl ClientSenderManager {
    pub fn new() -> ClientSenderManager {
        ClientSenderManager {
            client_sender_map: DashMap::new(),
        }
    }

    pub fn add_client_sender(&self, sender: mpsc::Sender<ResponseData>) -> i64 {
        let id = IdInstance::next_id();
        self.client_sender_map.insert(id, sender);
        id
    }

    pub fn get_client_sender(&self, client_id: i64) -> Option<mpsc::Sender<ResponseData>> {
        self.client_sender_map.get(&client_id).map(|entry| entry.value().clone())
    }

    pub fn send_response(&self, client_id: i64, response_data: ResponseData) {
        if let Some(sender) = self.get_client_sender(client_id) {
            sender.try_send(response_data).unwrap()
        }
    }
    pub fn remove_client_sender(&self, client_id: i64) {
        self.client_sender_map.remove(&client_id);
    }
}



