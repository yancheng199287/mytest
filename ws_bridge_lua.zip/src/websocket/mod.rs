pub mod handle_client_message;
pub mod call_lua_script;
pub mod client_sender_manager;
pub mod wrap_sender;

use std::any::Any;
use std::error::Error;
use std::future::Future;
use bytes::Bytes;
use fastwebsockets::{FragmentCollector, Frame, OpCode, Payload, upgrade, WebSocketError};
use hyper::{Request, Response};
use http_body_util::Empty;
use tokio::runtime::Builder;
use hyper::server::conn::http1;
use hyper::service::service_fn;
use hyper::upgrade::Upgraded;
use hyper_util::rt::TokioIo;
use log::info;
use tokio::select;
use tokio::sync::{mpsc};
use crate::model::response_payload::ResponseData;
use crate::util::tokio_runtime;
use crate::websocket::call_lua_script::start_lua_script_task_scheduler;
use crate::websocket::client_sender_manager::GLOBAL_CLIENT_SENDER_MANAGER;
use crate::websocket::handle_client_message::decode_json_and_set_map;
use crate::websocket::wrap_sender::WrapSender;


async fn server_upgrade<T>(mut req: Request<T>) -> Result<Response<Empty<Bytes>>, WebSocketError> {
    // 对request对象进行升级websocket
    let (response, fut) = upgrade::upgrade(&mut req)?;
    // 这个地方继续开启异步任务去处理流的相关操作
    tokio::task::spawn(async move {
        // unconstrained代表一个不受tokio运行时限制的异步任务，tokio默认有最大线程数和最大等待时间，而这个方法不受这个限制
        // 请确保处理不太耗时和资源的操作
        if let Err(e) = tokio::task::unconstrained(handle_client(fut)).await {
            eprintln!("Error in websocket connection: {:?}", e);
        }
        println!("客户端结束了...");
    });
    // let response = Response::new("hello world");
    // let response = Response::builder().status(200).body(Body::from("hello world")).unwrap();
    // 升级完成立即返回，注意这里返回之后，上面的异步任务还在继续执行
    Ok(response)
}


pub fn start_websocket() -> Result<(), WebSocketError> {
    let runtime = tokio_runtime::TokioWrapper::new();
    runtime.spawn(async {
        start_lua_script_task_scheduler();
    });

    runtime.block_on(async {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:8080").await?;
        println!("Server started, listening on {}", "127.0.0.1:8080");
        // 循环获取客户端连接事件，这个循环是阻塞的
        loop {
            let (stream, _) = listener.accept().await?;
            println!("Client connected ip addr: {}", stream.peer_addr().unwrap());
            // 处理客户端连接请求
            tokio::spawn(async move {
                let builder = http1::Builder::new();
                let io = hyper_util::rt::TokioIo::new(stream);
                let conn_fut = builder.serve_connection(io, service_fn(server_upgrade)).with_upgrades();
                if let Err(e) = conn_fut.await {
                    println!("An error occurred: {:?}", e);
                }
            });
        }
    })
}


async fn handle_client(fut: upgrade::UpgradeFut) -> Result<(), WebSocketError> {
    let websocket = fut.await?;
    let mut ws = FragmentCollector::new(websocket);
    /// 一个客户端一个通道，用于客户端内收发消息
    let (sender, mut receiver) = mpsc::channel(5000);


    let sender_id = GLOBAL_CLIENT_SENDER_MANAGER.add_client_sender(sender.clone());
    let wrap_sender = WrapSender::new(sender_id, sender.clone());
    // 使用 tokio::select! 同时处理接收客户端消息和发送消息
    loop {
        select! {
            // 读取客户端发送的消息
            Ok(frame) = ws.read_frame()=> {
                if let Err(e) = handle_received_frame(&frame, &wrap_sender).await {
                    eprintln!("Error handling received frame: {:?}", e);
                }
            },
            // 接收发送的消息
            Some(value) = receiver.recv() => {
                if let Err(e) = send_response(&mut ws, value).await {
                    eprintln!("Error sending response: {:?}", e);
                }
            },
        }
    }
    GLOBAL_CLIENT_SENDER_MANAGER.remove_client_sender(sender_id);
    println!("客户端连接断开啦,移除map中的通道");
    Ok(())
}


async fn handle_received_frame(frame: &Frame<'_>, sender: &WrapSender) -> Result<(), Box<dyn Error>> {
    match frame.opcode {
        OpCode::Close => {
            Ok(())
        }
        OpCode::Text | OpCode::Binary => {
            let result = utf8::decode(&frame.payload);
            match result {
                Ok(msg) => {
                    info!("服务端收到消息内容：{}", msg);
                    decode_json_and_set_map(msg, sender).await;
                    return Ok(());
                }
                Err(error) => {
                    println!("服务端解码消息失败: {:?}", error);
                }
            }
            Ok(())
        }
        _ => Ok(()),
    }
}


async fn send_response(ws: &mut FragmentCollector<TokioIo<Upgraded>>, value: ResponseData) -> Result<(), WebSocketError> {
    let value_str = serde_json::to_string(&value).unwrap();
    let payload = Payload::from(value_str.into_bytes());
    let frame = Frame::text(payload);
    ws.write_frame(frame).await
}

async fn send_response_message(mut ws: &mut FragmentCollector<TokioIo<Upgraded>>) {
    // 创建文本消息帧
    let text_message = "Hello, WebSocket!";
    let payload = Payload::from(text_message.as_bytes());
    let text_frame = Frame::text(payload);
    if let Err(err) = ws.write_frame(text_frame).await {
        eprintln!("Error sending text frame: {}", err);
    }
}


fn parser_binary_frame() {}