const PROTOCOL_VERSION = "v1.0.0"
const PROTOCOL_VERSION_NUMBER = 1
const DELIMITER = '|'; // 分隔符
const DELIMITER_BLOB = new Blob([DELIMITER]);

const CHUNK_SIZE = 512; // 512KB
const TEXT_ENCODER = new TextEncoder();

/// 会话标识，协议版本
class Header {
    constructor(app_id, session_id) {
        /// 应用id，从应用的配置文件读取，变为全局常量
        this.app_id = app_id;
        /// 会话id，服务端返回生成的会话id，这个保存到当前客户端的会话配置参数里
        this.session_id = session_id;
        // 每次请求和响应的唯一标识，这个很关键，响应的时候会根据msg_id去回调函数，在回调函数可以接收响应值
        this.msg_id = app_id + "_" + this.getUuid();
        /// 协议版本，随时升级，需要记录每次变化，每次升级做兼容性处理
        this.version = PROTOCOL_VERSION_NUMBER;
        /// 请求的时间
        this.datetime = new Date().toString();
    }

    // 生成唯一性id
    getUuid() {
        return Number(Math.random().toString().slice(2, 10) + Date.now()).toString(36)
    }
}

// 纯碎是为二进制流数据服务的，仅在大流量文件数据的时候启用，相当于header的扩展项目
class MetaData {
    constructor(name, type, length, chunk_total, chunk_index) {
        // "流的名称"  可以是文件名称，图片名称，如果是脚本，文本 取个默认的名称接口
        this.name = name;
        //  "word/excel/img/text" 流的具体类型
        this.stream_type = type;
        // 字节数组长度， 单纯的  流的数据
        this.stream_length = length;
        // 总共的分块数量  小于或者等于0 代表不需要分块， 用分块总量除以总长度可以得到每块的大小
        this.chunk_total = chunk_total;
        // 分块的索引     1  代表第一块 ， 如果当前分块索引等于chunkTotal则分块传输完毕
        this.chunk_index = chunk_index;
    }
}

///
const TASK_TYPE = {
    /// js脚本一次性执行，有返回值就返回，无返回值也要返回成功或者失败
    Script: "Script",
    /// 订阅响应流，开启或者关闭，持续监听消息的响应
    Subscription: "Subscription",
}
/// 这个设计比较复杂，这里列举了一些考虑的关注点
// 这里订阅一般是系统消息，或者第三方的实时数据，比如鼠标的移动事件，cpu的使用率， 或者是获取文件的视频流
// 一个生产者任务的订阅响应可以同时共享传播给多个消费者，即多个消息广播响应。当有订阅的时候，计数为0的时候，计数+1，任务启动，如果计数大于1，只需要计数+1，加入消费者队列即可
//为了保证订阅消费者没有及时退订，需要设置过期时间，定时扫描清理长时间没有响应的消费者。程序退出自动清理所有的消费者。
class SubscribeStream {
    constructor(name, status) {
        // 订阅什么流，只能名称区分，然后原生代码去执行监听，实时传输数据到客户端
        this.name = name;
        // 开启和关闭当前订阅,注意，开启只会开启一次，已经在运行了，不用重复开启，只需要计数+1，加入消费者队列中，同样关闭也是 计数-1，移除消费者
        // 如果当前计数减去是0，那么关闭生产者，因为没有消费者了。
        this.status = status;
    }
}

class RequestBody {
    constructor(task_type, data) {
        // 根据消息类型不同，对应的data会有不同的class数据载体
        this.task_type = task_type;
        this.data = data;
    }
}

// 构建脚本消息
function buildScriptPayload(source) {
    let header = new Header("com.miniapp", "1as46a54sda6daasdasd");
    let requestBody = new RequestBody(TASK_TYPE.Script, source);
    return {
        header: header,
        requestBody: requestBody
    };
}

/// 构建实时消费者订阅指定的消息
function buildSubscribeStream(name, status) {
    let header = new Header("com.miniapp", "1as46a54sda6daasdasd");
    let requestBody = new RequestBody(TASK_TYPE.Subscription, source);
    return {
        header: header,
        requestBody: new SubscribeStream(name, status)
    };
}

/// 构建大字节流分块传输
function buildByteStream(name, status) {
}