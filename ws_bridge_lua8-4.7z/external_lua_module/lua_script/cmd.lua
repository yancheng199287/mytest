local command = require("command")
-- 定义一个名为 cmd 的模块
local cmd = { _version = "0.1.1" }

function cmd.open_cmd(dir_path)
    return command.execute_std_cmd("cmd", "/c", "start", "/d", dir_path, "cmd")
end

function cmd.open_dir(dir_path)
    return command.execute_std_cmd("explorer", dir_path)
end

function cmd.open_browser_url(url)
    return command.execute_std_cmd("cmd", "/c", "start", url)
end

function cmd.execute_cmd(program, ...)
     command.execute_std_cmd("cmd", "/c", program, ...)
end


function cmd.get_cmd_result(program, ...)
    --设置utf - 8b编码, 设置编码之后，必须开启一个新的cmd，所以这里用了两个命令执行
    command.execute_std_cmd("cmd", "/c", "chcp 65001")
    return command.execute_std_cmd("cmd", "/c", program, ...)
end

function cmd.execute_std_cmd(program, ...)
    --设置utf - 8b编码, 设置编码之后，必须开启一个新的cmd，所以这里用了两个命令执行
    command.execute_std_cmd("cmd", "/c", "chcp 65001")
    return command.execute_std_cmd("cmd", "/c", program, ...)
end

return cmd