use std::collections::HashMap;
use reqwest::{Client, Error, Proxy, Response};
use std::time::Duration;
use reqwest::header::HeaderMap;
use serde_json::Value;

fn create_http_client() -> anyhow::Result<Client> {
    // 创建一个具有各种配置的 Client
    let client = Client::builder()
        // 设置连接超时时间
        .connect_timeout(Duration::from_secs(10))
        // 设置请求超时时间
        .timeout(Duration::from_secs(30))
        // 设置最大连接池大小
        .pool_max_idle_per_host(10)
        // 设置代理
        //.proxy(Proxy::https("https://proxy.example.com:8080")?)
        // 设置自定义 HTTPS 证书
        //   .add_root_certificate(reqwest::Certificate::from_pem(include_bytes!("cert.pem"))?)
        // 设置默认 Headers
        .default_headers({
            let mut headers = reqwest::header::HeaderMap::new();
            headers.insert("agent", "rust_http_client".parse().unwrap());
            headers
        })
        // 禁用自动重定向
        .redirect(reqwest::redirect::Policy::none())
        .build()?;
    Ok(client)
}

pub struct HttpClient {
    client: Client,
}


impl HttpClient {
    pub async fn new() -> Self {
        let client = create_http_client().unwrap();
        HttpClient { client }
    }

    // 处理 JSON 格式的请求
    pub async fn request_json(
        &self,
        method: &str,
        url: &str,
        headers: Value,
        body: Value,
    ) -> Result<Response, Error> {
        let mut req = self.client.request(method.parse().unwrap(), url);

        let headers_map = self.parse_headers(headers);
        req = req.headers(headers_map);

        req = req.json(&body);

        req.send().await
    }

    // 处理 urlencoded 格式的请求
    pub async fn request_urlencoded(
        &self,
        method: &str,
        url: &str,
        headers: Value,
        body: Value,
    ) -> Result<Response, Error> {
        let mut req = self.client.request(method.parse().unwrap(), url);

        let headers_map = self.parse_headers(headers);
        req = req.headers(headers_map);

        let params = self.parse_urlencoded_body(body);
        req = req.form(&params);

        req.send().await
    }

    // 处理 form-data 格式的请求
    pub async fn request_formdata(
        &self,
        url: &str,
        headers: Value,
        body: Value,
    ) -> Result<Response, Error> {
        let mut req = self.client.post(url);

        let headers_map = self.parse_headers(headers);
        req = req.headers(headers_map);

        let form = self.parse_form_data_body(body)?;
        req = req.multipart(form);

        req.send().await
    }

    // 解析 headers
    fn parse_headers(&self, headers: Value) -> HeaderMap {
        let mut headers_map = HeaderMap::new();
        if let Value::Object(map) = headers {
            for (key, value) in map {
                if let Some(val) = value.as_str() {
                  //  headers_map.insert(key.as_str(), val.parse().unwrap());
                }
            }
        }
        headers_map
    }

    // 解析 urlencoded body
    fn parse_urlencoded_body(&self, body: Value) -> HashMap<String, String> {
        let mut params = HashMap::new();
        if let Value::Object(map) = body {
            for (key, value) in map {
                if let Some(val) = value.as_str() {
                    params.insert(key, val.to_string());
                }
            }
        }
        params
    }

    // 解析 form-data body
    fn parse_form_data_body(&self, body: Value) -> Result<reqwest::multipart::Form, Error> {
        let mut form = reqwest::multipart::Form::new();
        if let Value::Object(map) = body {
            for (key, value) in map {
                if let Some(val) = value.as_str() {
                    form = form.text(key, val.to_string());
                } else if let Some(file_path) = value.as_str() {
                  //  form = form.bytes(key.as_str(), file_path)?;
                }
            }
        }
        Ok(form)
    }
}


#[tokio::test]
pub async fn test1() -> anyhow::Result<()> {
    let client = create_http_client()?;
    // 发送一个 GET 请求
    let response = client
        .get("https://api.github.com/repos/rust-lang/rust")
        .header("User-Agent", "reqwest")
        .send()
        .await?;

    // 解析响应文本
    let body = response.text().await?;
    println!("{}", body);

    Ok(())
}