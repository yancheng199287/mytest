use std::sync::{Arc, MutexGuard};
use std::time::Duration;
use mlua::{Lua, MetaMethod, Table, UserData};
use mlua::prelude::{LuaResult, LuaTable};
use crate::engine::lua_engine::LuaEngine;
use crate::set_global_module;


const NAME: &str = "module1";
const AGE: i32 = 18;

#[derive(Default)]
struct Rectangle {
    length: u32,
    width: u32,
}


fn sub(lua: &Lua, this: &Rectangle, (a, b): (i64, i64)) -> LuaResult<i64> {
    Ok(a - b)
}

impl UserData for Rectangle {
    fn add_fields<'lua, F: mlua::UserDataFields<'lua, Self>>(fields: &mut F) {
        fields.add_field_method_get("length", |lua, this| Ok(this.length));
        fields.add_field_method_set("length", |lua, this, val| {
            this.length = val;
            Ok(())
        });
        fields.add_field_method_get("width", |lua, this| Ok(this.width));
        fields.add_field_method_set("width", |lua, this, val| {
            this.width = val;
            Ok(())
        });
    }
    fn add_methods<'lua, M: mlua::UserDataMethods<'lua, Self>>(methods: &mut M) {
        methods.add_method("sub", sub);
    }
}


fn new_instance(lua: &Lua, (length, width): (u32, u32)) -> Result<Rectangle, mlua::Error> {
    let re = Rectangle {
        length,
        width,
    };
    Ok(re)
}

pub fn rust_module(lua: &Lua, loaded_table: &Table) {
    let exports_table = lua.create_table().unwrap();
    exports_table.set("new_instance", lua.create_function(new_instance).unwrap()).unwrap();
    let _ = loaded_table.set("module1", exports_table);
}


fn func(lua: &Lua, (a, b): (i32, i32)) -> mlua::Result<i32> {
    Ok(a + b)
}

fn rust_print(lua: &Lua, (name): (u64)) -> mlua::Result<()> {
    println!("Hello, {}!", name);
    Ok(())
}

async fn sleep(lua: &Lua, (time): (u64)) -> mlua::Result<()> {
    tokio::time::sleep(Duration::from_millis(time)).await;
    println!("sleep {}", time);
    Ok(())
}

pub fn register_lua_module(lua_engine: Arc<MutexGuard<'_, LuaEngine>>) {
    set_global_module!(lua_engine,"module_person",
        [("name", NAME),("age", AGE)],
        [("rust_print", rust_print),("func", func)],
        [("sleep", sleep)]
        );
}

pub fn register_lua_module1(lua_engine: &LuaEngine) {
    set_global_module!(lua_engine,"module_person",
        [("name", NAME),("age", AGE)],
        [("rust_print", rust_print),("func", func)],
        [("sleep", sleep)]
        );
}
