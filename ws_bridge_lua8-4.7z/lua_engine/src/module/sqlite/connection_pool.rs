use std::str::FromStr;
use std::time::Duration;
use sqlx::sqlite::{SqliteConnectOptions, SqliteJournalMode, SqlitePoolOptions};
use sqlx::{Row, SqlitePool};

struct Person {
    id: i32,
    name: String,
}

#[tokio::test]
async fn test1() -> anyhow::Result<()> {
    // 配置sqlite连接参数，sqlite很多特性参数，可以设置
    let sqlite_connection_option = SqliteConnectOptions::from_str("sqlite://data.db")?
        .journal_mode(SqliteJournalMode::Wal)
        .create_if_missing(true)
        .read_only(false);
    // 配置连接池参数，里面很多属性可以设置
    let sqlite_pool: SqlitePool = SqlitePoolOptions::new()
        .max_connections(50)
        .min_connections(1)
        .acquire_timeout(Duration::from_secs(50))
        .idle_timeout(Duration::from_secs(5 * 60))
        .connect_lazy_with(sqlite_connection_option);
    test_query1(sqlite_pool.clone()).await;
    Ok(())
}

async fn test_query1(sqlite_pool: SqlitePool) -> anyhow::Result<()> {
    // 执行创建表的SQL语句
    sqlx::query("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, name TEXT NOT NULL)")
        .execute(&sqlite_pool)
        .await?;
    // 插入数据
    sqlx::query("INSERT INTO users (name) VALUES (?1)")
        .bind("Alice")
        .execute(&sqlite_pool)
        .await?;
    // 查询数据
    let rows = sqlx::query("SELECT id, name FROM users")
        .fetch_all(&sqlite_pool)
        .await?;
    for row in rows {
        let id: i32 = row.get("id");
        let name: String = row.get("name");
        println!("id: {}, name: {}", id, name);
    }
    Ok(())
}