use std::str::FromStr;
use std::sync::Arc;
use std::time::Duration;
use sqlx::{Column, Row, SqlitePool, TypeInfo};

use sqlx::{query};
use anyhow::Result;
use log::{debug, info};
use mlua::{AnyUserData, Lua, Table, UserData, UserDataFields, UserDataMethods};
use mlua::prelude::{LuaResult, LuaValue};
use serde_json::{json, Value};
use sqlx::sqlite::{SqliteConnectOptions, SqliteJournalMode, SqlitePoolOptions};
use tokio::runtime::Handle;
use crate::engine::lua_engine::LuaEngine;
use crate::module::lua_result::wrap_lua_result;
use crate::set_global_module;


struct AppDatabase {
    pool: SqlitePool,
    data: Arc<Vec<u8>>,
}


impl Drop for AppDatabase {
     fn drop(&mut self) {
         self.pool.close();
         info!("AppDatabase dropped, num_idle：{}  is_closed:{}",  self.pool.num_idle(), self.pool.is_closed());
     }
}

impl AppDatabase {
    /// 支持对表结构的操作,支持对表数据的 修改，新增，删除
    pub async fn execute_sql(&self, sql: &str) -> Result<Value> {
        println!("sql:{}",sql);
        let query = query(sql).execute(&self.pool).await?;
        let rows_affected = query.rows_affected();
        let value = json!({ "rows_affected": rows_affected});
        Ok(value)
    }

    pub async fn query_record(&self, sql: &str) -> Result<Value> {
        // 执行查询并获取所有行
        let rows = match query(sql).fetch_all(&self.pool).await {
            Ok(rows) => rows,
            Err(e) => {
                eprintln!("Error executing query: {:?}", e);
                return Err(e.into());
            }
        };

        // 解析行数据
        let result: Vec<Value> = rows.iter().map(|row| {
            let mut map = serde_json::Map::new();
            for column in row.columns() {
                let column_name = column.name();
                let type_info = column.type_info();

                // 根据列类型进行适当的转换
                let value: Value = match type_info.name() {
                    "TEXT" | "VARCHAR" | "CHAR" | "STRING" => {
                        row.try_get::<String, _>(column_name).map(Value::String).unwrap_or(Value::Null)
                    },
                    "INTEGER" | "INT" | "INT4" | "INT8" | "BIGINT" => {
                        row.try_get::<i64, _>(column_name).map(|val| Value::Number(val.into())).unwrap_or(Value::Null)
                    },
                    "REAL" | "FLOAT" | "DOUBLE" | "NUMERIC" => {
                        row.try_get::<f64, _>(column_name).map(|val| serde_json::Number::from_f64(val).map(Value::Number).unwrap_or(Value::Null)).unwrap_or(Value::Null)
                    },
                    "BOOL" | "BOOLEAN" => {
                        row.try_get::<bool, _>(column_name).map(Value::Bool).unwrap_or(Value::Null)
                    },
                    "DATE" => {
                        row.try_get::<chrono::NaiveDate, _>(column_name).map(|val| Value::String(val.to_string())).unwrap_or(Value::Null)
                    },
                    "TIME" => {
                        row.try_get::<chrono::NaiveTime, _>(column_name).map(|val| Value::String(val.to_string())).unwrap_or(Value::Null)
                    },
                    "TIMESTAMP" | "DATETIME" => {
                        row.try_get::<chrono::NaiveDateTime, _>(column_name).map(|val| Value::String(val.to_string())).unwrap_or(Value::Null)
                    },
                    "BLOB" | "BINARY" => {
                        row.try_get::<Vec<u8>, _>(column_name).map(|val| Value::String(base64::encode(val))).unwrap_or(Value::Null)
                    },
                    _ => {
                        // 针对聚合函数的特殊处理
                        if column_name.starts_with("count") || column_name.starts_with("sum") || column_name.starts_with("avg") {
                            row.try_get::<i64, _>(column_name).map(|val| Value::Number(val.into())).unwrap_or_else(|_| {
                                row.try_get::<f64, _>(column_name).map(|val| serde_json::Number::from_f64(val).map(Value::Number).unwrap_or(Value::Null)).unwrap_or(Value::Null)
                            })
                        } else {
                            eprintln!("Unsupported column_name: {}, column type: {}", column_name, type_info.name());
                            Value::Null
                        }
                    }
                };

                map.insert(column_name.to_string(), value);
            }
            Value::Object(map)
        }).collect();

        let json = serde_json::json!(result);
        Ok(json)
    }

    pub async fn close(self) -> Result<()> {
        self.pool.close().await;
        std::mem::drop(self);
        Ok(())
    }
}


impl UserData for AppDatabase {
    fn add_fields<'lua, F: UserDataFields<'lua, Self>>(fields: &mut F) {}

    fn add_methods<'lua, M: UserDataMethods<'lua, Self>>(methods: &mut M) {
        methods.add_async_method("execute_sql", |lua, this, sql: String| async move {
            let sql = sql.as_str();
            let result = this.execute_sql(sql).await;
            match result {
                Ok(rows_affected) => {
                    let value = lua.create_string(rows_affected.to_string()).unwrap();
                    Ok( mlua::Value::String(value))
                },
                Err(err) => Err(mlua::Error::external(err))
            }
        });

        methods.add_async_method("query_record", |lua, this, sql: String| async move {
            let sql = sql.as_str();
            let result = this.query_record(sql).await;
            match result {
                Ok(vec_result) =>{
                    let value = lua.create_string(vec_result.to_string()).unwrap();
                   Ok( mlua::Value::String(value))
                },
                Err(err) => Err(mlua::Error::runtime(err))
            }
        });


        // 使用 `add_function` 添加方法以获取所有权并手动 drop 对象
        methods.add_function("close", |_, (this,): (AnyUserData,)| {
            // 尝试将 `AnyUserData` 转换为 `MyObject`，以便获取所有权并手动 drop
            if let Ok(obj) = this.take::<AppDatabase>() {
                drop(obj); // 手动 drop 对象
            }
            Ok(())
        });
    }
}


pub fn new(lua: &Lua, _: ()) -> LuaResult<AppDatabase> {
    let app_name: String = lua.globals().get("APP_NAME").unwrap();
    // "sqlite://data.db"
    let path = format!("sqlite://{}_data.db", app_name);

    let sqlite_connection_option = wrap_lua_result(|| SqliteConnectOptions::from_str(&path))?
        .journal_mode(SqliteJournalMode::Wal)
        .create_if_missing(true)
        .read_only(false);
    // 配置连接池参数，里面很多属性可以设置
    let sqlite_pool: SqlitePool = SqlitePoolOptions::new()
        .max_connections(50)
        .min_connections(0)
        .acquire_timeout(Duration::from_secs(35))
        .idle_timeout(Duration::from_secs(3 * 60))
        .connect_lazy_with(sqlite_connection_option);

    Ok(
        AppDatabase { pool: sqlite_pool,  data: Arc::new(vec![0; 100 * 1024 * 1024]), }
    )
}


/// 注册成lua中一个模块，可以通过require("module_config")来使用
/// 其中 new 函数可以创建一个Config对象，然后就可以基于这个对象调用我定义的方法
pub fn register_lua_module(lua_engine: &LuaEngine) {
    set_global_module!(lua_engine,"module_sqlite",
        [],
        [("new", new)],
        []
        );
}


fn json_to_lua_table(lua: &Lua, json: Value) -> LuaResult<Table> {
    let table = wrap_lua_result(|| lua.create_table())?;
    if let Value::Array(arr) = json {
        for (i, item) in arr.iter().enumerate() {
            let item_table = lua.create_table()?;
            if let Value::Object(map) = item {
                for (key, value) in map {
                    match value {
                        Value::String(s) => item_table.set(key.as_str(), s.as_str())?,
                        Value::Number(n) => item_table.set(key.as_str(), n.as_f64().unwrap())?,
                        Value::Bool(b) => item_table.set(key.as_str(), *b)?,
                        _ => item_table.set(key.as_str(), LuaValue::Nil)?,
                    }
                }
            }
            table.set(i + 1, item_table)?;
        }
    }
    Ok(table)
}