use std::collections::HashMap;
use lazy_static::lazy_static;
use mlua::prelude::LuaError;
use mlua::UserData;
use serde_json::Value;
use tokio::io::AsyncReadExt;
use crate::engine::lua_engine::LuaEngine;
use crate::module::web_server::warp_server::WarpServer;
use crate::reuse::long_object_factory;
use crate::set_global_module;


lazy_static! {
     static ref GLOBAL_OBJECT_FACTORY:ObjectFactory = ObjectFactory::new();
}


pub struct ObjectFactory {}


fn get_object_factory() -> &'static ObjectFactory {
    return &GLOBAL_OBJECT_FACTORY;
}

impl ObjectFactory {
    pub fn new() -> Self {
        ObjectFactory {}
    }


    async fn call_method(&self, app_name: &str, id: &str, is_mut: bool, method: &str, args: &Value) -> mlua::Result<String> {
        let factory = long_object_factory::get_global_long_object_factory();
        if let Some(obj) = factory.get_long_object(app_name, id) {
            return if is_mut {
                let mut long_object = obj.write().await;
                let result = long_object.call_mut_method(method, args).await;
                if result.is_ok() {
                    let result = result.unwrap();
                    return if result.is_some() {
                        Ok(result.unwrap())
                    } else {
                        Ok("".to_string())
                    };
                } else {
                    Err(mlua::Error::RuntimeError(format!("Error calling method: {}", result.err().unwrap())))
                }
            } else {
                let long_object = obj.read().await;
                let result = long_object.call_method(method, args).await;
                if result.is_ok() {
                    Ok(result.unwrap().unwrap())
                } else {
                    Err(mlua::Error::RuntimeError(format!("Error calling method: {}", result.err().unwrap())))
                }
            };
        } else {
            Err(mlua::Error::RuntimeError(format!("Object with id {} not found", id)))
        }
    }
}

impl UserData for ObjectFactory {
    fn add_methods<'lua, M: mlua::UserDataMethods<'lua, Self>>(methods: &mut M) {
        /*    methods.add_async_method("get_object", |lua, this, (id): (i64)| async move {
                let app_name: String = lua.globals().get("APP_NAME").unwrap();
                let factory = long_object_factory::get_global_long_object_factory();
                let object = factory.get_long_object(app_name.as_str(), id).unwrap();
                let object = object.read().await;
                Ok(object)
            });*/

        //TODO 剩下要完成工厂对象的创建，根据对象的名称来枚举动态创建对象，或者对象本身的new 获取id
        methods.add_async_method("call_object_method", |lua, this, (id, is_mut, method_name, args): (String, bool, String, String)| async move {
            let args: Value = serde_json::from_str(&args).unwrap();
            let app_name: String = lua.globals().get("APP_NAME").unwrap();
            println!("调用方法：app_name :{},id:{}, method:{}", app_name, id, method_name);
            this.call_method(app_name.as_str(), &id, is_mut, &method_name, &args).await
        })
    }
}

pub fn new(lua: &mlua::Lua, _: ()) -> mlua::Result<&ObjectFactory> {
    Ok(get_object_factory())
}

pub fn register_lua_module(lua_engine: &LuaEngine) {
    set_global_module!(lua_engine,"module_object_factory",
        [("object_factory",ObjectFactory::new())],
        [],
        []
        );
}