use std::any::Any;
use std::collections::HashMap;
use std::fs::OpenOptions;
use std::future::{Future, IntoFuture};
use std::net::SocketAddr;
use std::panic;
use std::panic::AssertUnwindSafe;
use std::path::Path;
use std::sync::{Arc, Mutex};
use async_trait::async_trait;
use idgenerator::IdInstance;
use log::{error, info};
use mlua::{Lua, UserData, UserDataFields};
use mlua::prelude::{LuaError, LuaString};
use serde_json::Value;
use tokio::task::JoinHandle;
use warp::{Error, Filter, Rejection, Reply};
use tokio::runtime::Runtime;
use tokio::sync::oneshot;
use tokio::sync::oneshot::Sender;
use crate::engine::lua_engine::LuaEngine;
use crate::module::config::Config;
use crate::reuse::long_object::LongObject;
use crate::reuse::long_object_factory;
use crate::reuse::long_object::LongObjectMethods;
use crate::{impl_long_object_methods, set_global_module};
use crate::task::lua_script_error::LuaScriptError;

pub struct WarpServer {
    handler_id: String,
    handle: Option<(JoinHandle<()>, Sender<()>)>,
    web_dir: String,
}

impl WarpServer {
    pub fn new(web_dir: String) -> Self {
        Self {
            handler_id: String::default(),
            handle: None,
            web_dir,
        }
    }

    pub async fn start(&mut self) -> anyhow::Result<()> {
        let web_dir = self.web_dir.clone();
        let func = start_warp_server(web_dir);
        match func {
            Ok((handle, shutdown_sender)) => {
                self.handle = Some((handle, shutdown_sender));
                Ok(())
            }
            Err(err) => {
                error!("Error starting server: {}", err);
                Err(err)
            }
        }
    }

    pub async fn do_something(&self, args: &Value) -> anyhow::Result<Option<String>> {
        Ok(None)
    }

    pub async fn do_something1(&self) -> anyhow::Result<Option<String>> {
        Ok(None)
    }

    pub async fn stop(&mut self) -> anyhow::Result<Option<String>> {
        if let Some((handle, shutdown_sender)) = self.handle.take() {
            println!("stop server");
            shutdown_sender.send(()).unwrap();
            handle.await.unwrap();
        }
        Ok(None)
    }

    pub async fn stop1(&mut self, args: &Value) -> anyhow::Result<Option<String>> {
        Ok(None)
    }
}

pub fn start_web_server(web_dir: String) -> Arc<Mutex<WarpServer>> {
    let mut warp_server = WarpServer::new(web_dir);
    warp_server.start();
    Arc::new(Mutex::new(warp_server))
}

fn start_warp_server(web_dir: String) -> anyhow::Result<(JoinHandle<()>, Sender<()>)> {
    let (shutdown_tx, shutdown_rx) = oneshot::channel::<()>();

    let route = router(web_dir);
    // warp::serve(route).run(([127, 0, 0, 1], 3030)).await;
    let server_result = warp::serve(route).try_bind_ephemeral(([127, 0, 0, 1], 3030));
    match server_result {
        Ok((addr, server)) => {
            // 如果绑定成功，启动服务器并发送成功消息
            println!("服务器绑定在地址: {}", addr);
            let server_handle = tokio::task::spawn_blocking(move || {
                let rt = tokio::runtime::Handle::current();
                rt.block_on(async move {
                    tokio::select! {
                       _ =  server => {},
                       _ = shutdown_rx => {
                            println!("服务接收到停止信号");
                        }
                    }
                });
                println!("停止服务成功");
            });
            Ok((server_handle, shutdown_tx))
        }
        Err(e) => {
            // 如果绑定失败，发送错误信息
            Err(anyhow::anyhow!("Error starting server: {}", e))
        }
    }
}


pub fn stop_warp_server(warp_server: Arc<Mutex<WarpServer>>) {
    warp_server.lock().unwrap().stop();
}


fn router(web_dir: String) -> impl Filter<Extract=impl Reply + 'static, Error=Rejection> + Clone + 'static {
    // 检查静态目录路径
    let static_path = Path::new(&web_dir);
    if !static_path.exists() || !static_path.is_dir() {
        error!("Static directory does not exist or is not a directory");
        std::process::exit(1);
    }
    let index_file = "index.html".to_string(); // 索引文件
    let index_route = warp::path::end()
        .and(warp::fs::file(static_path.join(index_file)));

    let web_static_router = warp::path("web")
        .and(warp::fs::dir(web_dir))
        .recover(handle_rejection);
    let routes = index_route.or(web_static_router);
    routes
}

async fn handle_rejection(err: Rejection) -> Result<impl Reply, Rejection> {
    println!("{:?}", err);
    if err.is_not_found() {
        println!("Error: {:?}", err);
        Ok(warp::reply::with_status(
            "NOT_FOUND".to_string(),
            warp::http::StatusCode::NOT_FOUND,
        ))
    } else {
        Err(err)
    }
}


impl UserData for WarpServer {
    fn add_methods<'lua, M: mlua::UserDataMethods<'lua, Self>>(methods: &mut M) {
        methods.add_method_mut("getInstanceId", |lua, this, _: ()| {
            this.start();
            Ok(())
        });

        methods.add_async_method("start", |lua, this, id: String| async move {
            let app_name: String = lua.globals().get("APP_NAME").unwrap();
            let factory = long_object_factory::get_global_long_object_factory();
            let object_id = factory.get_object::<WarpServer>(app_name.as_str(), id.as_str());
            if let Some(object) = object_id {
                let mut warp_server = object.write().await;
                warp_server.start();
                return Ok(());
            }
            Err(LuaError::RuntimeError("WarpServer Object not found".to_string()))
        });


        methods.add_async_method("stop", |lua, this, id: String| async move {
            let app_name: String = lua.globals().get("APP_NAME").unwrap();
            let factory = long_object_factory::get_global_long_object_factory();
            let object_id = factory.get_object::<WarpServer>(app_name.as_str(), id.as_str());
            if let Some(object) = object_id {
                let mut warp_server = object.write().await;
                warp_server.stop();
                return Ok(());
            }
            Err(LuaError::RuntimeError("WarpServer Object not found".to_string()))
        });
    }


    fn add_fields<'lua, F: UserDataFields<'lua, Self>>(fields: &mut F) {
        fields.add_field_method_get("handler_id", |_, this| Ok(this.handler_id.clone()));
    }
}

#[async_trait]
impl LongObject for WarpServer {
    async fn init(&mut self, object_id: &str) -> anyhow::Result<()> {
        println!("WarpServer init");
        self.handler_id = object_id.to_string();
        self.start().await
    }

    fn as_any(&self) -> &dyn Any {
        self
    }

    async fn call_method(&self, method: &str, args: &Value) -> anyhow::Result<Option<String>> {
        self.call_method_impl(method, args).await
    }

    async fn call_mut_method(&mut self, method: &str, args: &Value) -> anyhow::Result<Option<String>> {
        self.call_mut_method_impl(method, args).await
    }

    async fn destroy(&mut self) -> anyhow::Result<Option<String>> {
        return self.stop().await;
    }
}


// 使用宏实现 LongObjectMethods 的方法匹配

// 使用宏实现 LongObjectMethods 的方法匹配
// 使用宏实现 LongObjectMethods 的方法匹配
impl_long_object_methods!(WarpServer,
    mutable => {
        no_args => {
              stop => "stop",
              destroy => "destroy"
        },
        with_args => {
             stop1 => "stop1"
        }
    },
    immutable => {
        no_args => {
            do_something1 => "do_something1"
        },
        with_args => {
          do_something => "do_something"
        }
    }
);



pub async fn new(lua: &Lua, static_dir: (String)) -> mlua::Result<String> {
    let app_name: String = lua.globals().get("APP_NAME").unwrap();
    //let static_dir = "C:\\Users\\yancheng\\AppData\\Local\\com.oneinlet.app\\miniProgram".to_string(); // 静态文件目录
    let mut warp_server = WarpServer::new(static_dir);
    let factory = long_object_factory::get_global_long_object_factory();
    let object_id = factory.create_object(app_name.as_str(), warp_server).await;
    match object_id {
        Ok(id) => {
            println!("WarpServer created with ID: {}", id);
            Ok(id)
        }
        Err(e) => {
            println!("Error creating WarpServer: {}", e);
            let error_message = format!("Error creating WarpServer: {}", e);
            Err(LuaError::RuntimeError(error_message))
        }
    }
}


pub fn register_lua_module(lua_engine: &LuaEngine) {
    set_global_module!(lua_engine,"module_warp_server",
        [],
        [],
        [("new", new)]
        );
}