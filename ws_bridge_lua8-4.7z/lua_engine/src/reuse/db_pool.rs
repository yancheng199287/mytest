use std::any::{Any, TypeId};
use std::time::Duration;
use async_trait::async_trait;
use serde_json::Value;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::time::sleep;
use crate::impl_long_object_methods;
use crate::reuse::long_object::LongObject;
use crate::reuse::long_object::LongObjectMethods;
use crate::reuse::long_object_factory;
use crate::task::lua_script_error::LuaScriptError;

pub struct DbPool {
    connection_string: String,
}

impl DbPool {
    pub fn new(connection_string: &str) -> Self {
        DbPool {
            connection_string: connection_string.to_string(),
        }
    }

    pub async fn execute_query(&self, args: &Value) -> anyhow::Result<Option<String>> {
        let value = args.get(0).unwrap().to_string();
        println!("执行SQL查询: {}", value);
        Ok(None)
    }

    pub async fn do_connect(&self, connection_string: &Value) -> anyhow::Result<Option<String>> {
        println!("执行数据库连接: {}", connection_string);
        Ok(None)
    }
}

#[async_trait]
impl LongObject for DbPool {
    async fn init(&mut self, object_id: &str)  -> anyhow::Result<()> {
        sleep(Duration::from_secs(1)).await;
        // 这里是你的异步代码
        println!("进行数据库链接..id:{}  {}", object_id, self.connection_string);
        Ok(())
    }

    fn as_any(&self) -> &dyn Any {
        self
    }

    async fn call_method(&self, method: &str, args: &Value) -> anyhow::Result<Option<String>> {
        self.call_method_impl(method, args).await
    }

    async fn call_mut_method(&mut self, method: &str, args: &Value) -> anyhow::Result<Option<String>> {
        self.call_mut_method_impl(method, args).await
    }

    async fn destroy(&mut self)  -> anyhow::Result<Option<String>>{
        sleep(Duration::from_secs(1)).await;
        // 这里是你的异步代码
        println!("进行数据库销毁操作...");
        Ok(None)
    }
}

// 使用宏实现 LongObjectMethods 的方法匹配
// 使用宏实现 LongObjectMethods 的方法匹配
impl_long_object_methods!(DbPool,
    mutable => {
        no_args => {
        },
        with_args => {
            execute_query => "execute_query",
            do_connect => "do_connect"
        }
    },
    immutable => {
        no_args => {
        },
        with_args => {
        }
    }
);



#[tokio::test]
async fn main1() {
    let factory = long_object_factory::get_global_long_object_factory();

    // 创建一个数据库连接池
    let object = DbPool::new("postgres://user:password@localhost/dbname1");
    let object_id = factory.create_object("app1", object).await;
    if object_id.is_err() {
        println!("create object error");
        return;
    }


    // 获取数据库连接池并使用
    if let Some(pool) = factory.get_object::<DbPool>("app1", object_id.unwrap().as_str()) {
        // 使用连接执行查询
        let sql = "SELECT * FROM users";
        let mysql_pool = pool.read().await;
        let db_pool = mysql_pool.as_any().downcast_ref::<DbPool>().unwrap();
        let sql = Value::String(sql.to_string());
        let result = db_pool.execute_query(&sql).await;
    }


    // 创建一个数据库连接池
    let object1 = DbPool::new("postgres://user:password@localhost/dbname2");
    let object_id1 = factory.create_object("app2", object1).await;
    if object_id1.is_err() {
        println!("create object error");
        return;
    }
    // 获取数据库连接池并使用
    if let Some(pool) = factory.get_object::<DbPool>("app2", object_id1.unwrap().as_str()) {
        // 使用连接执行查询
        let sql = "SELECT * FROM users where id =10";
        let mysql_pool = pool.read().await;
        let sql = Value::String(sql.to_string());
        let result = mysql_pool.execute_query(&sql).await;
    }

    // 销毁所有长对象
    // factory.destroy_all("app1").await;
    factory.destroy_all_app_object().await;
}





