use std::any::Any;
use async_trait::async_trait;
use mlua::{Result};
use serde_json::Value;
use crate::task::lua_script_error::LuaScriptError;


#[async_trait]
pub trait LongObject: Any + Send + Sync {
    async fn init(&mut self, object_id: &str) -> anyhow::Result<()>;

    // 添加 as_any 方法
    fn as_any(&self) -> &dyn Any;

    async fn call_method(&self, method: &str, args: &Value) -> anyhow::Result<Option<String>>;

    async fn call_mut_method(&mut self, method: &str, args: &Value) -> anyhow::Result<Option<String>>;


    async fn destroy(&mut self) -> anyhow::Result<Option<String>>;
}

#[async_trait]
pub trait LongObjectMethods: Any + Send + Sync {
    async fn call_method_impl(&self, method: &str, args: &Value) -> anyhow::Result<Option<String>>;
    async fn call_mut_method_impl(&mut self, method: &str, value: &Value) -> anyhow::Result<Option<String>>;
}


// 使用宏生成 LongObjectMethods 的实现
#[macro_export]
macro_rules! impl_long_object_methods {
    (
        $struct_name:ident,
        mutable => {
            no_args => { $($mut_no_arg_method_name:ident => $mut_no_arg_method_str:expr),* $(,)? },
            with_args => { $($mut_arg_method_name:ident => $mut_arg_method_str:expr),* $(,)? }
        },
        immutable => {
            no_args => { $($imm_no_arg_method_name:ident => $imm_no_arg_method_str:expr),* $(,)? },
            with_args => { $($imm_arg_method_name:ident => $imm_arg_method_str:expr),* $(,)? }
        }
    ) => {
        #[async_trait::async_trait]
        impl LongObjectMethods for $struct_name {
            async fn call_method_impl(&self, method: &str, args: &serde_json::Value) -> anyhow::Result<Option<String>> {
                match method {
                    $(
                        $imm_no_arg_method_str => {
                            return self.$imm_no_arg_method_name().await;
                        }
                    )*
                    $(
                        $imm_arg_method_str => {
                            return self.$imm_arg_method_name(args).await;
                        }
                    )*
                    _ => {
                        let err = format!("Unknown or mutable method: {}", method);
                        return Err(anyhow::anyhow!(err));
                    }
                }
            }

            async fn call_mut_method_impl(&mut self, method: &str, args: &serde_json::Value) -> anyhow::Result<Option<String>> {
                match method {
                    $(
                        $mut_no_arg_method_str => {
                            return self.$mut_no_arg_method_name().await;
                        }
                    )*
                    $(
                        $mut_arg_method_str => {
                            return self.$mut_arg_method_name(args).await;
                        }
                    )*
                    _ => {
                        let err = format!("Unknown or immutable method: {}", method);
                        return Err(anyhow::anyhow!(err));
                    }
                }
            }
        }
    };
}


/*
#[macro_export]
macro_rules! impl_long_object_methods {
    ($struct_name:ident, $(($method_name:ident, $method_str:expr)),*) => {
        #[async_trait]
        impl LongObjectMethods for $struct_name {
           async fn call_method_impl(&self, method: &str, args: &Value) -> mlua::Result<String> {
                match method {
                    $(
                        $method_str => self.$method_name(args).await,
                    )*
                    _ => Err(mlua::Error::RuntimeError(format!("Unknown method: {}", method))),
                }
            }
        }
    };
}*/