use dashmap::DashMap;
use std::sync::{Arc};
use std::any::TypeId;
use idgenerator::IdInstance;
use lazy_static::lazy::Lazy;
use lazy_static::lazy_static;
use log::debug;
use rand::distributions::uniform::SampleBorrow;
use sqlx::encode::IsNull::No;
use tokio::sync::RwLock;
use crate::reuse::long_object::LongObject;


lazy_static! {
     static ref GLOBAL_LONG_OBJECT_FACTORY:LongObjectFactory = LongObjectFactory::new();
}


pub fn get_global_long_object_factory() -> &'static LongObjectFactory {
    &GLOBAL_LONG_OBJECT_FACTORY
}


pub struct LongObjectFactory {
    objects: DashMap<String, DashMap<String, (TypeId, Arc<RwLock<dyn LongObject>>)>>,
}

impl LongObjectFactory {
    fn new() -> Self {
        LongObjectFactory {
            objects: DashMap::new(),
        }
    }
    pub async fn create_object<T: LongObject + 'static>(&self, appid: &str, mut object: T) -> anyhow::Result<String> {
        let object_id = IdInstance::next_id().to_string();
        let init_result = object.init(object_id.as_str()).await;
        if init_result.is_err() {
            return Err(init_result.err().unwrap());
        }
        println!("add new object, key:{} {:?}", object_id, object.type_id());
        let object_id_clone = object_id.to_string();
        self.objects.entry(appid.to_string()).or_default().insert(object_id, (TypeId::of::<T>(), Arc::new(RwLock::new(object))));
        // let type_map = self.objects.entry(appid.to_string()).or_insert_with(DashMap::new);
        //  println!("调用方法：app_name :{},id:{}", appid, object_id);
        // type_map.insert(object_id, (TypeId::of::<T>(), Arc::new(RwLock::new(object))));
        return Ok(object_id_clone);
    }

    pub fn get_object<T: LongObject + 'static>(&self, appid: &str, object_id: &str) -> Option<Arc<RwLock<T>>> {
        if let Some(app_objects) = self.objects.get(appid) {
            if let Some(object) = app_objects.get(object_id) {
                if object.0 == TypeId::of::<T>() {
                    let value = object.1.clone();
                    // 将 object 转换为原始指针
                    let object = Arc::into_raw(value);
                    // 将原始指针转换为我们实际的实现目标类型
                    let object = unsafe { Arc::from_raw(object as *const RwLock<T>) };
                    return Some(object);
                }
            }
        }
        return None;
    }


    pub fn get_long_object(&self, appid: &str, object_id: &str) -> Option<Arc<RwLock<dyn LongObject>>> {
        if let Some(app_objects) = self.objects.get(appid) {
            println!("ssss app_objects.len(){} object_id:{}", app_objects.len(), object_id);
            let inner_map = app_objects.value();
            let value = inner_map.get(object_id);
            if value.is_some() {
                let object = value.unwrap();
                let value = object.1.clone();
                println!("get_long_object 获取结果成功");
                return Some(value);
            }
            println!("get_long_object 获取结果失败");
        }
        return None;
    }

    pub async fn destroy_object_of_app_object(&self, appid: &str, object_id: &str) -> anyhow::Result<Option<String>> {
        if let Some(app_objects) = self.objects.get(appid) {
            debug!("before destroy_object_of_app_object: app_objects.len(){} object_id:{}", app_objects.len(), object_id);
            let inner_map = app_objects.value();
            let value = inner_map.get(object_id);
            if value.is_some() {
                let object = value.unwrap();
                let value = object.1.clone();
                let mut write_lock_value = value.write().await;
                let destroy_result = write_lock_value.destroy().await;
                if destroy_result.is_ok() {
                    inner_map.remove(object_id);
                }
                return destroy_result;
            }
        } else {
            debug!("can not find object id in object map {}, appid :{}",object_id, appid);
        }
        Ok(None)
    }

    pub async fn destroy_app_object(&self, appid: &str) {
        if let Some(app_objects) = self.objects.remove(appid) {
            let values = app_objects.1;
            let values_ref = &values;
            for value in values_ref {
                let mut obj = value.1.write().await;
                obj.destroy().await;
            }
            values.clear();
            println!("destroy app long object,appid Key: {}", appid);
        }
    }

    pub async fn destroy_all_app_object(&self) {
        // 迭代获取所有的键
        // 迭代获取所有的键，并收集到一个 Vec 中
        let keys: Vec<String> = self.objects.iter().map(|entry| entry.key().clone()).collect();
        // 打印所有的键
        for key in keys {
            self.destroy_app_object(key.as_str()).await;
        }
        self.objects.clear();
    }
}
