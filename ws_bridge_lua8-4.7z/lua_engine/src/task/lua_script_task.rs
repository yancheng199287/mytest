use std::cell::RefCell;
use std::future::Future;
use std::time::Duration;
use mlua::{Error, Value};
use crate::task::lua_script_error::LuaScriptError;
use crate::task::thread_local_container::ThreadContainer;


static LIMIT_EXECUTE_TASK_TIMEOUT: u64 = 30;
static LIMIT_EXECUTE_TASK_TIMEOUT_DURATION: Duration = Duration::from_secs(LIMIT_EXECUTE_TASK_TIMEOUT);

// 定义任务结构
pub struct LuaScriptTask {
    /// 任务id，由前端生成，这样前端在调试阶段可以知道自己的请求任务id，然后对应可以去看后端的日志文件里查看执行结果
    pub task_id: String,
    /// 客户端的Sender ID，由于找到对应的客户端的Sender，所以需要记录一下，获取到执行结果之后，需要将结果发送给对应的客户端
    pub client_sender_id: i64,
    pub script: String,
}

impl LuaScriptTask {
    pub fn new(task_id: String, client_sender_id: i64, script: String) -> Self {
        LuaScriptTask {
            task_id,
            client_sender_id,
            script,
        }
    }

    pub fn execute(&self, thread_container: &RefCell<ThreadContainer>) -> Result<Option<String>, LuaScriptError> {
        let thread_container_ref = thread_container.borrow();
        let script_result = thread_container_ref.runtime.block_on(run_with_timeout_and_interrupt(async {
            let lua_engine = &thread_container_ref.lua_engine;
            return lua_engine.async_exec_script1(self.script.as_str()).await;
        }, LIMIT_EXECUTE_TASK_TIMEOUT_DURATION));
        match script_result {
            Err(err) => Err(LuaScriptError::lua_script_eval_error(err.to_string())),
            Ok(value) => {
                match value {
                    Value::Nil => {
                        Ok(None)
                    }
                    Value::String(value) => {
                        let result = value.to_str().unwrap().to_string();
                        Ok(Some(result))
                    }
                    _ => {
                        let result = value.to_string().unwrap().to_string();
                        Ok(Some(result))
                    },
                  /*  _ => Err(LuaScriptError::lua_script_return_value_error()),*/
                }
            }
        }
    }


    pub fn execute1(&self, thread_container: &RefCell<ThreadContainer>) -> Result<Option<String>, LuaScriptError> {
        let thread_container_ref = thread_container.borrow();
        let result = thread_container_ref.runtime.block_on(async {
            // 设置任务的超时时间为 5 秒
            let duration = Duration::from_secs(1);
            // 使用 timeout 包装任务，并匹配结果
            let timeout_result = tokio::time::timeout(duration, async {
                let lua_engine = &thread_container_ref.lua_engine;
                return lua_engine.async_exec_script1(self.script.as_str()).await;
            }).await;

            match timeout_result {
                /// 处理lua引擎执行返回的结果，我们约定只能返回字符串，一般是json字符串或者什么也不返回，这里是 Nil，返回一个空字符串，如果不是，则返回错误，提示只能返回字符串
                Ok(script_result) => match script_result {
                    Err(err) => Err(LuaScriptError::lua_script_eval_error(err.to_string())),
                    Ok(Value) => {
                        match Value {
                            Value::Nil => {
                                Ok(None)
                            }
                            Value::String(value) => {
                                let result = value.to_str().unwrap().to_string();
                                Ok(Some(result))
                            }
                            _ => Err(LuaScriptError::lua_script_return_value_error()),
                        }
                    }
                }
                Err(_) => Err(LuaScriptError::lua_script_eval_timeout_error())
            }
        });
        return result;
    }
}


#[derive(Debug)]
pub struct LuaScriptTaskResult {
    /// 任务id，由前端生成，这样前端在调试阶段可以知道自己的请求任务id，然后对应可以去看后端的日志文件里查看执行结果
    pub task_id: String,
    /// 客户端的Sender ID，由于找到对应的客户端的Sender，所以需要记录一下，获取到执行结果之后，需要将结果发送给对应的客户端
    pub client_sender_id: i64,
    pub script_result: Result<Option<String>, LuaScriptError>,
}

impl LuaScriptTaskResult {
    pub fn new(task_id: String, client_sender_id: i64, script_result: Result<Option<String>, LuaScriptError>) -> Self {
        LuaScriptTaskResult {
            task_id,
            client_sender_id,
            script_result,
        }
    }
}


pub async fn run_with_timeout_and_interrupt<'lua, F>(
    fut: F,
    duration: Duration,
) -> Result<Value<'lua>, Error>
    where F: Future<Output=Result<Value<'lua>, Error>>,
{
    tokio::select! {
        result = fut => {
           result
        }
        _ = tokio::time::sleep(duration) => {
           Err(Error::external(format!("eval script timed out, limit {} seconds", LIMIT_EXECUTE_TASK_TIMEOUT)))
        }
        _ = tokio::signal::ctrl_c() => {
             Err(Error::external(String::from("eval script task interrupted by signal")))
        }
    }
}

