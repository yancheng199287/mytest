use rayon::ThreadPoolBuilder;

// 创建线程池的函数
pub fn create_thread_pool(max_threads: usize) -> rayon::ThreadPool {
    ThreadPoolBuilder::new()
        .thread_name(|num| {
             format!("lua-thread-name-{}!", num)
        })
        .num_threads(max_threads)
        .build()
        .expect("can not crate thread pool")
}
