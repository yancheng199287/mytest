use crate::websocket::call_lua_script::start_lua_script_task_scheduler;
use std::panic;
use log::error;
use std::io::Write;

mod websocket;
mod model;
mod util;


fn main() {
    println!("Hello, world!");

    log4rs::init_file("config/log4rs.yaml", Default::default()).unwrap();
    set_panic_hook();
    websocket::start_websocket().unwrap();
}


fn set_panic_hook() {
    panic::set_hook(Box::new(move |panic_info| {
        let location = panic_info.location().unwrap();
        let message = if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
            s.to_string()
        } else if let Some(s) = panic_info.payload().downcast_ref::<String>() {
            s.clone()
        } else {
            "Unknown panic message".to_string()
        };
        let mut w = Vec::new();
        writeln!(&mut w, "formatted {}", "arguments").unwrap();
        error!("Global Panic occurred: {} \n {}", message,location);
    }));
}
