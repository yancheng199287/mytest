use lua_engine::task::lua_script_task::{LuaScriptTask, LuaScriptTaskResult};
use lua_engine::task::scheduler::LuaTaskScheduler;
use crate::model::response_payload::ResponseData;
use crate::websocket::client_sender_manager::GLOBAL_CLIENT_SENDER_MANAGER;


/// 全局的任务调度器
lazy_static::lazy_static! {
  static ref GLOBAL_LUA_TASK_SCHEDULER:LuaTaskScheduler<LuaScriptTask>= {
    LuaTaskScheduler::new(3, 5000)
  };
}


/// 启动任务调度器
/// 1. 接收线程计算发出来的结果
/// 2. 启动线程池和轮询调度器
pub fn start_lua_script_task_scheduler() {
    receive_lua_script_task_result();
    GLOBAL_LUA_TASK_SCHEDULER.start();
}

/// 发送任务到线程池
pub fn send_lua_script_task(task: LuaScriptTask) {
    let sender = &GLOBAL_LUA_TASK_SCHEDULER.task_sender;
    sender.try_send(task).expect("send LuaScriptTask failed");
}

/// 接收lua脚本任务结果，线程处理完成脚本计算，会将结果发送到这里，然后这里会将结果转换成一个ResponseData对象，最终发送给客户端
pub fn receive_lua_script_task_result() {
    std::thread::spawn(move || {
        while let Ok(notification) = GLOBAL_LUA_TASK_SCHEDULER.notification_receiver.recv() {
            let sender_id = notification.client_sender_id;
            let result = transfer_lua_script_task_result(notification);
            GLOBAL_CLIENT_SENDER_MANAGER.send_response(sender_id, result);
        }
    });
}

/// 对线程计算的lua脚本任务结果转换为ResponseData对象
pub fn transfer_lua_script_task_result(task_result: LuaScriptTaskResult) -> ResponseData {
    let msg_id = task_result.task_id.clone();
    let app_id = msg_id.clone();
    let response_data;
    match task_result.script_result {
        Ok(str_option) => {
            // 处理成功的情况
            match str_option {
                /// 执行正确并且有返回值
                Some(str) => {
                    response_data = ResponseData::build_content_ok(app_id, msg_id, str);
                }
                /// 执行正确无返回值
                None => {
                    response_data = ResponseData::build_ok(app_id, msg_id);
                }
            }
        }
        /// 执行脚本报错，获取错误信息
        Err(error) => {
            // 处理错误的情况
            response_data = ResponseData::build_error(app_id, msg_id, error.code, error.msg);
        }
    }
    response_data
}

