use std::any::Any;
use bytes::BytesMut;
use dashmap::DashMap;
use log::{info, warn};
use parking_lot::lock_api::RwLockReadGuard;
use parking_lot::{RawRwLock, RwLock};
use std::borrow::{Borrow, BorrowMut};
use std::cell::RefCell;
use std::collections::HashMap;
use std::io::Cursor;
use std::ops::Deref;
use std::sync::{Arc, Mutex, Once, OnceLock};
use std::thread;
use std::time::Duration;
use fastwebsockets::FragmentCollector;
use hyper::upgrade::Upgraded;
use hyper_util::rt::TokioIo;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::sync::mpsc;
use tokio::sync::mpsc::{Receiver, Sender};
use tokio::time;
use tokio::sync::oneshot;
use tokio::task::LocalSet;
use lua_engine::task::lua_script_function_call;
use lua_engine::task::lua_script_task::LuaScriptTask;
use crate::model::request_payload::{Header, RequestData};
use crate::model::response_payload::ResponseData;
use crate::model::task_type::TaskType;
use crate::websocket::call_lua_script;
use crate::websocket::wrap_sender::WrapSender;

// DashMap 是一个并发的map 类似 concurrentHashMap
lazy_static::lazy_static! {
  static ref GLOBAL_MESSAGE_STORAGE: DashMap<String, DashMap<String, Arc<RwLock<RequestData>>>> = {
   DashMap::new()
  };
}

lazy_static::lazy_static! {
  static ref GLOBAL_WS_CLIENT: DashMap<String,Arc<Mutex<FragmentCollector<TokioIo<Upgraded>>>>> = {
   DashMap::new()
  };
}


/*lazy_static::lazy_static! {
    static ref EVAL_SCRIPT_CHANNEL: (mpsc::Sender<ResponseData>, mpsc::Receiver<ResponseData>) = {
        mpsc::channel(100)
    };
}*/


pub async fn decode_msg_pack_and_set_map(msg_pack_data: &mut [u8], sender: &WrapSender) {
    let request_data: RequestData = rmp_serde::from_slice(&msg_pack_data).unwrap();
    info!("消息解析完成，执行原生函数任务");
    execute_native_by_request_data(request_data, sender).await;
}

pub async fn decode_json_and_set_map(json_data: &str, sender: &WrapSender) {
    let request_data: RequestData = serde_json::from_str(&json_data).expect("Failed to deserialize header");
    info!("消息解析完成，执行原生函数任务");

    execute_native_by_request_data(request_data, sender).await;
    // return Some(clone_header);
}

pub async fn decode_stream_and_set_map(mut binary_data: Vec<u8>) {
    let request_data = decode_stream(binary_data);
    let clone_header = request_data.header.clone();
    let mut is_finish = false;
    let meta_data_option = &request_data.meta_data;
    if meta_data_option.is_some() {
        let meta_data = meta_data_option.as_ref().unwrap();
        /// 判断是否传参完成，完成需要执行原生函数调用计算任务
        if meta_data.chunk_index == meta_data.chunk_total {
            is_finish = true;
        }
    } else {
        // 如果不存在
        is_finish = true;
    }
    /// 保存对象到全局map中
    save_request_data_to_map(request_data);
    if is_finish {
        info!("消息解析完成，执行原生函数任务");
        // return Some(clone_header);
        execute_native(clone_header).await;
    }
}

pub fn decode_stream(mut binary_data: Vec<u8>) -> RequestData {
    // 分隔流数据，用分隔符 '|'，如果有流数据，那么分隔的数组大小是size=2
    let parts: Vec<&[u8]> = binary_data.split(|&b| b == b'|').collect();
    // 获取第一步部分数据 header+meta+businessData = RequestData
    let request_data_bytes = parts[0];
    let request_data_str = String::from_utf8(Vec::from(request_data_bytes))
        .expect("Failed to convert header bytes to string");
    //println!("request_data_str:{}", request_data_str);
    let mut request_data: RequestData =
        serde_json::from_str(&request_data_str).expect("Failed to deserialize header");
    // 如果有第二部分数据流，那么将流set到 request_data.stream
    if parts.len() == 2 {
        let mut file_chunk = BytesMut::new();
        file_chunk.extend_from_slice(parts[1]);
        request_data.stream = Some(file_chunk);
    }
    println!("服务端接收到消息内容decode_stream: {:?}", request_data);
    return request_data;
}


fn save_request_data_to_map(mut request_data: RequestData) {
    let app_id = request_data.header.app_id.clone();
    let msg_id = request_data.header.msg_id.clone();
    // 获取全局w_storage中应用id对应的hashmap，如果不存在，会执行or_default，创建一个空的map，存在不会创建，直接返回存在的map
    let app_storage = GLOBAL_MESSAGE_STORAGE.entry(app_id).or_default();
    // 判断 这个app的map里是否有这个消息id
    if app_storage.contains_key(&msg_id) {
        if let Some(stream) = request_data.stream {
            // 获取arc的读取锁的 RequestData
            let mut task_state_arc = app_storage.get_mut(&msg_id).unwrap();
            // 获取写锁的 RequestData
            let mut task_state = task_state_arc.write();
            // 获取 RequestData 的 stream流
            // let mut map_stream = &task_state.stream;
            // 对流进行追加
            if let Some(raw_stream) = &mut task_state.stream {
                raw_stream.extend(stream);
            }
        }
    } else {
        app_storage.insert(msg_id, Arc::new(RwLock::new(request_data)));
    }
}

fn get_request_data(app_id: String, msg_id: String) -> Option<Arc<RwLock<RequestData>>> {
    let app_storage_option = GLOBAL_MESSAGE_STORAGE.get(&app_id);
    if app_storage_option.is_none() {
        info!("can not find app_storage_option by app_id,{}", app_id);
        return None;
    }
    let app_map = app_storage_option.unwrap();
    let msg_option = app_map.get(&msg_id);
    if msg_option.is_none() {
        info!("can not find msg_option by app_id,{}", msg_id);
        return None;
    }
    let lock_value = msg_option.unwrap();
    return Some(lock_value.clone());
}

async fn execute_native(header: Header) {
    let app_id = header.app_id;
    let msg_id = header.msg_id;
    let lock_value_option = get_request_data(app_id, msg_id);
    if lock_value_option.is_none() {
        warn!("can not find lock_value_option");
        return;
    }
    let lock_value = lock_value_option.unwrap();
    let value = lock_value.read();
    info!("find RequestData:{:?}", value);
}


async fn execute_native_by_request_data(request_data: RequestData, sender: &WrapSender) {
    info!(
    "execute_native_by_request_data find RequestData:{:?}",
    request_data
  );
    let body_option = request_data.request_body;
    let body = body_option.unwrap();
    let mut script = body.data;

    if body.task_type == TaskType::ScriptFunction {
        script = lua_script_function_call::generate_lua_script(&script).await.unwrap()
    }


    let msg_id = request_data.header.msg_id;
    let app_id = request_data.header.app_id;

    let client_sender_id = sender.id;

    let lua_task = LuaScriptTask::new(msg_id.clone(), client_sender_id, script);
    call_lua_script::send_lua_script_task(lua_task);


    //  sender.send(response_data).await;
}


