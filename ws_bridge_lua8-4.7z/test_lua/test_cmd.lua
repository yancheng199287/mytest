local cmd = require("cmd")


local dir = "D:\\tool-list"

local url = "http://www.baidu.com"


-- 打开指定的cmd目录
local info = cmd.open_cmd(dir)


-- 打开网站url
local info = cmd.open_browser_url(url)


-- 打开文件资源管理器目录
local info = cmd.open_dir(dir)

-- 执行cmd命令

local info = cmd.execute_std_cmd("echo '我在干嘛呢'")

-- 获取返回信息
return info
