local json = require("json")
local sqlite_module = require("module_sqlite")
local sqlite = sqlite_module.new()

local function create_table()

    local create_table_sql = [[
   CREATE TABLE IF NOT EXISTS users (
    user_id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL,
    email TEXT NOT NULL,
    password TEXT NOT NULL,
    age INTEGER,
    points INTEGER DEFAULT 0,
    balance REAL DEFAULT 0.0,
    rating REAL,
    is_active BOOLEAN DEFAULT 1,
    is_admin BOOLEAN DEFAULT 0,
    registered_date DATE DEFAULT (DATE('now')),
    last_login DATETIME DEFAULT (DATETIME('now')),
    profile_picture BLOB
);

]]
    local rows_affected = sqlite:execute_sql(create_table_sql);
    log("rows_affected,", rows_affected);
end

local function add_record()

    local create_user_sql1 = [[
INSERT INTO users (username, email, password, age, points, balance, rating, is_active, is_admin, profile_picture)
VALUES
('john_doe', 'john@example.com', 'password123', 30, 100, 250.75, 4.5, 1, 0, X'89504E470D0A1A0A0000000D49484452000000100000001008060000001F' ||
    'F3FF61DE000000017352474200AECE1CE90000000467414D410000B18F0BFC61' ||
    '05000000097048597300000B1300000B1301009A9C180000000774494D4507E4' ||
    '07070D1A170B3A4D31560000001D494441546890CDC1310D000300C2A0500BC4' ||
    'C68C1800000000000000000000000000000000000000000000000000000000A1' ||
    'FD3F4E0000000049454E44AE426082');
    ]];

    local create_user_sql2 = [[
INSERT INTO users (username, email, password, age, points, balance, rating, is_active, is_admin)
VALUES
('jane_doe', 'jane@example.com', 'password456', 28, 200, 500.00, 4.7, 1, 1);
    ]];

    local create_user_sql3 = [[
INSERT INTO users (username, email, password, age, points, balance, rating, is_active, is_admin)
VALUES
('alice_smith', 'alice@example.com', 'password789', 22, 150, 300.50, 4.8, 1, 0);
    ]];

    local create_user_sql4 = [[
INSERT INTO users (username, email, password, age, points, balance, rating, is_active, is_admin)
VALUES
('bob_jones', 'bob@example.com', 'password321', 35, 50, 150.25, 4.2, 0, 0);
    ]];

    sqlite:execute_sql(create_user_sql1);

    sqlite:execute_sql(create_user_sql2);

    sqlite:execute_sql(create_user_sql3);

    sqlite:execute_sql(create_user_sql4);


end

local function update_record()

    local update_user_sql1 = [[
UPDATE users SET age = 29 WHERE username = 'john_doe';
    ]];

    local update_user_sql2 = [[
DELETE FROM users WHERE user_id IN (SELECT user_id FROM users LIMIT 1);
    ]];

    local rows_affected1 = sqlite:execute_sql(update_user_sql);
    local rows_affected2 = sqlite:execute_sql(update_user_sql2);
    log("rows_affected,", rows_affected1, rows_affected2);
end

local function select_record()
    local select_user_sql1 = [[
select  * from users limit 5
    ]];

    local select_user_sql2 = [[
select  count(*) as count from users limit 1
    ]];

    local result1 = sqlite:query_record(select_user_sql1);
    local result2 = sqlite:query_record(select_user_sql2);

end

local function select_record_by_sql(param_table)
    local result = sqlite:query_record(param_table["sql"]);
    return result
end

local function execute_sql(sql)
    local result = sqlite:execute_sql(sql["sql"]);
    return result
end


--[[
调用传参即可测试
{
    "sql":"select * from users limit 5"
}
]]
local function init_db(sql)
    -- create_table();
    -- add_record();
    --  local result =   select_record_by_sql(sql);
    -- add_record();
    log("执行的sql", json.encode(sql))
    local result = select_record_by_sql(sql)
    sqlite:close();
    return result;
end


--[[
local function init_db()
     create_table();
     add_record();
    local result =    select_record();
    sqlite:close();
    return result
  --  local large_table = create_large_table(1000) -- 创建一个包含100个1MB字符串的表，总共占用约100MB内存+
   -- sqlite =nil
   -- sqlite_module=nil
end
]]






