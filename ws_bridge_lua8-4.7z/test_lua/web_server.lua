local json = require("json")
local warp_server_module = require("module_warp_server")
local object_factory_module = require("module_object_factory")

local function start_server()
    local path = "F:\\workspace\\tauri\\simple-mini-app\\dist"
    local handler_id = warp_server_module.new(path)
    log("启动web server：", handler_id)
    return handler_id
end

local function stop_server(args_table)
    sleep(function()
        object_factory_module.object_factory:call_object_method(args_table.handler_id, true, "destroy", "{}");
        log("stop web server：", args_table.handler_id)
    end, 2000)
    return handler_id
end

local function start_and_stop_server()
    local path = "F:\\workspace\\tauri\\simple-mini-app\\dist"
    local handler_id = warp_server_module.new(path)
    log("启动web server：", handler_id)

    sleep(function()
        --[[  object_factory_module.object_factory:call_object_method(handler_id, true, "stop", "{}");]]
        log("stop web server：", handler_id)
    end, 2000)
    return handler_id
end


